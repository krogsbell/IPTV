#!/usr/bin/env python
# -*- coding: utf-8 -*-
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import time
import os
try:
    from os import statvfs
except:
    pass
import xbmc,xbmcvfs
import xbmcgui
import xbmcaddon
import utils
import shutil
import re
import net
import locking
import json
import urllib
import glob
import urllib
import base64

from sqlite3 import dbapi2 as sqlite3
from operator import itemgetter

import findtvguidenotifications

"""
To run plugin use : xbmc.executebuiltin('RunPlugin("plugin.video.something")')
To run script use : xbmc.executebuiltin('RunAddon("script.something")')
cmd = 'AlarmClock(%s,RunScript(%s,%s),%d,True)' % (nameAlarm, script, args, timeToRecording/60)

RunAddon(id)	Runs the specified plugin/script	
RunAppleScript(script[,args]*)	Run the specified AppleScript command	
RunPlugin(plugin)	Runs the plugin. Full path must be specified. Does not work for folder plugins	
RunScript(script[,args]*)	Runs the python script. You must specify the full path to the script. One way to specify the full path is through the special protocol. If the script is an add-on, you can also execute it using its add-on id. As of 2007/02/24, all extra parameters are passed to the script as arguments and can be accessed by python using sys.argv

playlist = playlist.create_playlist( ( self.settings[ "music_path" ], ), self.settings[ "shuffle" ] )
        xbmc.Player().play( playlist )
        xbmc.executebuiltin( "RunScript(%s)" % os.path.join( os.getcwd(), "default.py" ) )

start_exec='XBMC.RunPlugin(%s)' % ('%s?action=%s&url=%s&ind=%s&storage=%s') % (
                     sys.argv[0], 'downloadLibtorrent', urllib.quote_plus(torrent.encode('utf-8')), str(ind), storage)
            xbmc.executebuiltin(start_exec)
            xbmc.executebuiltin('Container.Refresh')        

xbmc.executebuiltin("RunScript(script.extendedinfo,info=youtubebrowser)")


"""
e = 'Kodi 19 Exception missing'
RECORDS_DB  = 'recordings_adc.db'
CHANNEL_DB  = 'channels.db'
EPG_DB      = 'master.db'
FILES_DB    = 'files.db' ### 2019-02-24
SETTINGSXML = 'settings.xml'
#ADDON      = xbmcaddon.Addon(id='plugin.video.wozboxntv')
import definition
ADDON       = definition.getADDON()
ADDONid     = ADDON.getAddonInfo('id')
ADDONname   = ADDON.getAddonInfo('name')
xbmc.log('recordings.py in %s' % ADDONname)
datapath    = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
progpath    = ADDON.getAddonInfo('path')
module      = 'recordings.py'
origin = ADDONid +' available_channels'
RECURSIVEMARKER = 'Recursive:'

def log(infotext):
    if 'err' in infotext.lower():
        utils.logdev('err',module + ': ' + infotext)
    else:
        utils.logdev(module,infotext)

def logd1(infotext):
    log('err: ' + infotext)

def logarray(Name,Array,nelements=1):
    i = 0
    for rec in Array:
        try:
            if nelements==1:
                log('logarray in %s= %r %r' % (Name,i,rec))
                i += 1
            else:
                records = []
                for index in range(0, nelements):
                    records.append(rec[index])
                log('logarray in %s= %r %r' % (Name,i,records))
                i += 1
        except Exception as e:
            pass
            log('ERROR: logarray in %s= %r' % (Name,e))
            
def sleep(sleeptime):
    utils.logdev('sleep','sleep %r (sleeptime= %r)' % (module,sleeptime))
    xbmc.sleep(sleeptime)

"""
def adapt_datetime(ts):
    try:
        ### TypeError is raised unless the comparison is == or !=
        if ts is None:
            return None
        return time.mktime(ts.timetuple())
    except Exception as  e:
            pass
            utils.logdev('adapt_datetime(ts) FAILED 1', 'ts= %r ERROR= %r' % (ts,e))
            return None
def convert_datetime(ts):
        try:
            ### TypeError is raised unless the comparison is == or !=
            if ts is None:
                return None
            return datetime.fromtimestamp(float(ts))
        except Exception as  e:
            pass
            utils.logdev('convert_datetime(ts) FAILED 1', 'ts= %r ERROR= %r' % (ts,e))
            return None

def convert_datetimeORIGINAL(ts):
        try:
            return datetime.fromtimestamp(float(ts))
        except ValueError:

            return None
               
# http://docs.python.org/2/library/sqlite3.html#registering-an-adapter-callable
###sqlite3.register_adapter(datetime, adapt_datetime)
sqlite3.register_adapter(datetime, adapt_datetime)
sqlite3.register_converter('timestamp', convert_datetime)
"""

def cleanTempFiles():
    channelsxml = os.path.join(datapath, 'channelsxml*.xml')
    channelsdict = os.path.join(datapath, 'channelsdict*.dict')
    LockFiles = glob.glob(channelsxml)
    # delete lock files
    for file in LockFiles:
        locking.deleteLockFile(file)
        log('recordUnlockAll(file= %r)' % (file))
        
    LockFiles = glob.glob(channelsdict)
    # delete lock files
    for file in LockFiles:
        locking.deleteLockFile(file)
        log('recordUnlockAll(file= %r)' % (file))

def SelectSetupxmlFiles():
    path = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    files =  glob.glob(os.path.join(path, '*'))
    defaultfile = os.path.join(path, SETTINGSXML)
    files1 = sorted(files, reverse=True)
    activeDB = SETTINGSXML.split('.')[0]+ ' - ' + utils.username(defaultfile) 
    index = 0
    contextMenu = []
    contextFile = []
    try:
        BackupCount = int(ADDON.getSetting('BackupCount'))  
    except:
        pass
        BackupCount = 5
    for infile in files1:
        if index < BackupCount:
            index += 1
            try:
                if infile[-4:].lower()=='.xml':
                    mail = utils.username(infile)
                    folder = utils.folder(defaultfile)
                    name = infile.replace(path,'').replace('.xml','') + ' - ' + mail + ': ' + folder
                
                    ###if '@' in mail: 
                    contextMenu.append(name)
                    contextFile.append(infile)
            except:
                pass
    if len(contextMenu) == 0 or len(contextMenu) == 1:   ### Dont ask if only one entry
        xbmcaddon.Addon(id=ADDONid).openSettings()
    else:
        SelectedChannel = xbmcgui.Dialog().select('Select a setupxml file', contextMenu)
        if SelectedChannel >= 0:
            ADDON.setSetting('fixsetup','true')
            try:
                id = contextFile[SelectedChannel]
                utils.notification('Seletced setupxml: ' + repr(id))
                ### copy file
                shutil.copyfile(id, defaultfile)
                xbmc.executebuiltin("XBMC.Container.Update(path,replace)")  ### Exit AddOn after setup.xml update
                xbmc.executebuiltin("XBMC.ActivateWindow(Home)")
            except:
                pass
                ADDON.setSetting('fixsetup','false')
            
def TestHDD(path):
    try:
        ###st = os.statvfs(path)

        ###if st.f_frsize:
        ###    freespace = st.f_frsize * st.f_bavail/1024/1024/1024
        ###else:
        ###    freespace = st.f_bsize * st.f_bavail/1024/1024/1024
        freespace = utils.get_free_space_gb(path,'L')
        log("Free Space: %dGB"%(freespace))
        if(freespace < 3) and ADDON.getSetting('enable_record') == 'true':
            text = "You have less than 3GB of free space on your Record Path"
            text1 = path
            text2 = "Free up some space!"
            utils.notificationforced('[COLOR red]Less than 3GB of free space on[/COLOR] \n'+path)
            ###xbmcgui.Dialog().ok(ADDONname, text, text1, text2)
    except Exception as e:
            pass
            log('Error in get TestHDD path= %r \nError: %r' %(path,e))
    """
    if Platform.system == 'android': 
-            # http://stackoverflow.com/questions/1749928/replacement-for-python-statvfs#comment42443537_1749950
-            # https://github.com/Diblo/KODI-Popcorn-Time/issues/68
-            return 16106127360 # 15 GB
+            if hasattr(os, 'statvfs'):
+                st = os.statvfs(download_path)
+                return st.f_bavail * st.f_frsize
+            else:
+                import commands, b2h
+                return b2h.human2bytes(commands.getoutput('df %s' % download_path).split('\n')[1].split()[3])
         if Platform.system == 'windows':
             free_bytes = ctypes.c_ulonglong(0)
             ctypes.windll.kernel32.GetDiskFreeSpaceExW(ctypes.c_wchar_p(self.mediaSettings.download_path), None, None, ctypes.pointer(free_bytes))
© 2017 GitH
    """
    ###while not xbmc.abortRequested:    
    ###    sleep(502)          

recordPath = xbmcvfs.translatePath(os.path.join(utils.ADDONgetSetting('record_path')))
log('recordPath= %r Writable? %r' % (recordPath,utils.folderwritable(recordPath,module)))
TestHDD(recordPath)

### Is FFMPEG installed? 2018-05-26
try:
    ffmpeginstalled = utils.runCommandTest('ffmpeg')
except:
    pass
    ffmpeginstalled = False
if ADDON.getSetting('enable_record')=='true' and not ffmpeginstalled and ADDON.getSetting('enable_ffmpegtest')=='true' :
    ADDON.setSetting('enable_record','false')
    ###Dialog().ok(heading=heading, message=message)
    xbmcgui.Dialog().ok(ADDONname, 'FFMPEG is not installed!\n\nRecording is disabled in the settings')
if ffmpeginstalled and ADDON.getSetting('enable_record')=='true' and not utils.folderwritable(recordPath,module):
    ###utils.notification('Recording not possible [COLOR red]You must set the recording path writable![/COLOR] \nGoto Settings/Recording/Record Path and set that to a writable path')
    log('ERROR: You must set the recording path writable!')
    if not ADDON.getSetting('fixsetup') == 'true':  ### Only run setup once
        if ADDON.getSetting('user') == '':
            SelectSetupxmlFiles()
            if ADDON.getSetting('user') == '':
                xbmcaddon.Addon(id=ADDONid).openSettings()
        else:
            xbmcaddon.Addon(id=ADDONid).openSettings() 
"""
recordPath = xbmcvfs.translatePath(os.path.join(ADDON.getSetting('record_path')))
log('recordPath= %s' %recordPath)
if ADDON.getSetting('enable_record')=='true' and not utils.folderwritable(recordPath):
    ###utils.notification('Recording not possible [COLOR red]You must set the recording path writable![/COLOR] \nGoto Settings/Recording/Record Path and set that to a writable path')
    log('You must set the recording path writable! ')
    xbmcaddon.Addon(id=ADDONid).openSettings()
"""
def downloadicons():
    utils.logdevreset()
    return    #### REMOVE TO DOWNLOAD ALL ICONS AGAIN TO DATA FOLDER ####

    iconsfolder = os.path.join(datapath,'icons')
    if os.path.exists(iconsfolder) == False:
        os.makedirs(iconsfolder)    
    c = getIconConnection().cursor()
    ### c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (title, source))") ###
    c.execute("SELECT * FROM channels")
    logos = c.fetchall()
    ###utils.logdev('downloadicons','size= ' + repr(len(logos)))
    for logo in logos:
        logoid= logo[0]
        title= logo[1]
        logolink= logo[2]
        ###utils.logdev('downloadicons','id= ' + repr(logoid) + ' title= ' + repr(title) + ' logolink= ' + repr(logolink))
        logofilename= os.path.join(datapath,'icons',logoid) + '.png'
        ###utils.logdev('downloadicons','logofilename= ' + repr(logofilename))
        try:
            ###iconfile = urllib.urlopen(logolink)
            ###with open(logofilename,'wb') as output:
            ###    output.write(iconfile.read())
            data = utils.readlink(logolink,logofilename,module)
        except:
            pass
            ###utils.logdev('downloadicons','FAILED id= ' + repr(logoid) + ' title= ' + repr(title) + ' logolink= ' + repr(logolink))
    c.close()

def getIcon(title,cat):
    ###https://raw.githubusercontent.com/krogsbell/Logos/master/99.png
    return IconFromCat(cat)
    """
    if ADDON.getSetting('geticonfromweb') == 'true':
        return getIconFromWeb(title,cat)
    else:
        logofilename= os.path.join(progpath,'resources','logo',cat) + '.png'
        if os.path.isfile(logofilename) == True:
            ### ###utils.logdev('getIcon','logofilename= ' + repr(logofilename))
            return logofilename
        else:
            ###utils.logdev('getIcon FAILED','logofilename= ' + repr(logofilename))
            return logofilename
"""

"""
ROQ TV - M3U Playlist URL
'http://roq-tv.net:25461/get.php?username=xxxx&password=xxxx&type=m3u_plus&output=ts'
definition.getBASEURL() + '/get.php?username=xxxx&password=xxxx&type=m3u_plus&output=ts'

ROQ TV - EPG url
http://roq-tv.net:25461/xmltv.php?username=xxxx&password=xxxx

You can access the online viewing platform here: 
http://roq-tv.net:25461/client_area/index.php?username=xxxx&password=xxxx
with or without username and password

"""

def ftvntvlist():
# Create a FTVNTV.INI file with all channels from ROQ TV
## This file contains the "built-in" channels
## It is parsed by Pythons ConfigParser
#
#[plugin.video.ntv]
#* * * * * *  NEW NTV CHANNELS 2015-05-01 * * * * * * *=
#24 Techno=plugin://plugin.video.ntv/?url=url&mode=200&name=24+Techno+-+%5BCOLOR+yellow%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fwww.ntv.mx%2Fres%2Fcontent%2Ftv%2F179.png&cat=179
#2x2=plugin://plugin.video.ntv/?url=url&mode=200&name=2x2+-+%5BCOLOR+yellow%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fwww.ntv.mx%2Fres%2Fcontent%2Ftv%2F177.png&cat=177
#5 Star=plugin://plugin.video.ntv/?url=url&mode=200&name=5+Star+-+%5BCOLOR+yellow%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fwww.ntv.mx%2Fres%2Fcontent%2Ftv%2F86.png&cat=86
#5 USA=plugin://plugin.video.ntv/?url=url&mode=200&name=5+USA+-+%5BCOLOR+yellow%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fwww.ntv.mx%2Fres%2Fcontent%2Ftv%2F64.png&cat=64
    channellist = os.path.join(datapath,'channels') + '.csv'
    ftvntvini = os.path.join(datapath,'ftv'+ADDONname) + '.ini'
    ntvchannelsm3u = os.path.join(datapath,ADDONname + 'channels') + '.m3u'
    favoritesm3u = os.path.join(datapath,ADDONname + ' Favorites') + '.m3u'
    ###utils.logdev('ftvntvlist','ftvroqtv= %s for %s' % (repr(os.path.isfile(ftvntvini)), repr(ftvntvini)))
    if os.path.isfile(channellist) == True: 
        ###utils.logdev('ftvntvlist','channellist exists - deleting')
        locking.deleteLockFile(channellist)
    if os.path.isfile(ftvntvini) == True: 
        ftvntviniOLD = os.path.join(datapath,'ftv'+ADDONname+'OLD') + '.ini'
        shutil.copyfile(ftvntvini, ftvntviniOLD)
        locking.deleteLockFile(ftvntvini)
    if os.path.isfile(ntvchannelsm3u) == True: 
        locking.deleteLockFile(ntvchannelsm3u)
    if os.path.isfile(favoritesm3u) == True: 
        locking.deleteLockFile(favoritesm3u)
    if os.path.isfile(favoritesm3u) == False: 
        now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        LF = open(favoritesm3u, 'a')
        LF.write('#EXTM3U \n')
        ### #EXTINF:-1 tvg-id="epg_channel 9" tvg-name="id 0" tvg-logo="logo 2" group-title="",title 1
        ### stream_url 3  like http://<url>/live/xxxxx/yyyyy/16537.ts
        
        conn = getConnection()
        c = conn.cursor()
        try:
            c.execute("SELECT * FROM channels WHERE favorite<>? and favorite<>? and visible=? and source=?  COLLATE NOCASE", ['False','false',1,origin]) 
            favorites = c.fetchall()
        except Exception as e:
            pass
            log('c.execute("SELECT * FROM channels ERROR: %r' % e)
            favorites = []
        favorites = sorted(favorites, key=itemgetter(1)) ### Sort by name
        favorites = sorted(favorites, key=itemgetter(9)) ### Sort by EPG name
        ADDID1 = ADDON.getSetting('my_referral_init')
        ADDID  = ADDID1[:3].upper()
        if len(ADDID) < 3 or ADDID1 == 'Not Set':
            ADDID = ADDON.getSetting('basicuserinfo').split(os.sep)[-1][:3].upper()
            ADDON.setSetting('my_referral_init',ADDID)
        if ADDID != ADDID1:
            ADDON.setSetting('my_referral_init',ADDID)
        for index in range(0, len(favorites)):
            ch = []
            for i in range(0, len(favorites[index])):
                if favorites[index][i] == None:
                    ch.append('')
                else:
                    ch.append(favorites[index][i])
            if ' (D' in ch[1]:
                ADDIDhere = ''
            else:
                ADDIDhere = ADDID + ' '
            if ch[7] != 'True':
                favo = ' ' + ch[7]
            else:
                favo = ''
            LF.write('#EXTINF:-1 tvg-id="' + ch[9] + '" tvg-name="' + ch[0] + '" tvg-logo="'+  ch[2] + '" group-title="'+ADDONname +'",' + ch[9] + favo + ': ' + ADDIDhere + ch[1] + '\n')
            LF.write(ch[3] + '\n')
        c.close()  
        LF.close()
    if os.path.isfile(ftvntvini) == False:
        now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        # create file
        ###utils.logdev('ftvntvlist','ftvroqtv.ini beeing created ' + now)
        LF = open(ftvntvini, 'a')
        # Write to our text file the information we have provided and then goto next line in our file.
        LF.write('# This file contains the TV channels for your Package\n')
        LF.write('# Created by ' + ADDON.getAddonInfo('name') +' at ' + now + '\n')
        LF.write('[' + ADDON.getAddonInfo('id') + ']\n')
        LF.write('\n')
        ftvntvinifile = ftvntvini.replace(datapath,'')
        try:
            CHANNELlist(LF)
            if ADDON.getSetting('notifyduringepgupdate') == 'true':    
                utils.notification('[COLOR green]'+ftvntvinifile+' created[/COLOR]')
        except Exception as e:
            pass
            utils.logdev('ftvntvlist','Error in get CHANNELlist: ' + repr(e))
            utils.notificationforced('[COLOR red]%r - Access to %s channel list is not available[CR]%s NOT generated![/COLOR]' % (e,ADDONname,ftvntvinifile) )
            ###utils.notificationbox('[COLOR red]Check your internet connection![/COLOR][CR][CR][COLOR green]Access to %s channel list is not available[CR]ftvroqtv.ini NOT generated![/COLOR]' % ADDON.getAddonInfo('name') )
        LF.write('\n')
        now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        LF.write('# End of ' + ADDONname + ' channels - ended at ' + now + '\n')
        # Close our file so no further writing is posible.
        LF.close()
        
        ftvntvini = os.path.join(datapath,'Channels '+ADDONname) + '.txt'
        LF = open(ftvntvini, 'w')
        # Write to our text file the information we have provided and then goto next line in our file.
        LF.write('# This file contains the TV channels for your Package\n')
        LF.write('# Created by ' + ADDON.getAddonInfo('name') +' at ' + now + '\n')
        LF.write('[' + ADDON.getAddonInfo('id') + ']\n')
        LF.write('\n')
        ftvntvinifile = ftvntvini.replace(datapath,'')
        try:
            CHANNELDisplaylist(LF)
            if ADDON.getSetting('notifyduringepgupdate') == 'true':
                utils.notificationforced('[COLOR green]'+ftvntvinifile+' created[/COLOR]')
        except Exception as e:
            pass
            utils.logdev('ftvntvlist','Error in get CHANNELlist: ' + repr(e))
            utils.notificationforced('[COLOR red]Access to %s channel list is not available[CR]%s NOT generated![/COLOR]' % (ADDONname,ftvntvinifile) )
            ###utils.notificationbox('[COLOR red]Check your internet connection![/COLOR][CR][CR][COLOR green]Access to %s channel list is not available[CR]ftvroqtv.ini NOT generated![/COLOR]' % ADDON.getAddonInfo('name') )
        LF.write('\n')
        now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        LF.write('# End of ' + ADDONname + ' channels - ended at ' + now + '\n')
        # Close our file so no further writing is posible.
        LF.close()
        
    if os.path.isfile(channellist) == False:
        now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        # create file
        utils.logdev('CHANNELcsvlist','channellist beeing created ' + now)
        LF = open(channellist, 'a')
        # Write to our text file the information we have provided and then goto next line in our file.
        try:
            CHANNELcsvlist(LF)
            if ADDON.getSetting('notifyduringepgupdate') == 'true':
                utils.notificationforced('[COLOR green]channels.csv created[/COLOR]')
        except Exception as e:
            utils.notificationforced('[COLOR red]channels.csv not created[/COLOR][CR]Error= %r' % e)
        LF.write('\n')
        # Close our file so no further writing is posible.
        LF.close()
        
def CHANNELcsvlist(LF):   
    nowDate= datetime.today().strftime('%Y-%m-%d')
    channels = getAllChannelsList()
    ###channels = sorted(channels, key=itemgetter(1))
    ###channels = sorted(channels,key=lambda i:i[1].lower())  ### Sort ignore case coloum 1
    krogsbelladdons = []
    KrogsbellAddOns = definition.getKrogsbellAddOns()
    log('KrogsbellAddOns= %r' % KrogsbellAddOns)
    for kaddon in KrogsbellAddOns:
        log('kaddon= %r' % kaddon)
        try:
            kaddonID = kaddon.split('.')[2][:3].upper()
            taddonID = ADDONid.split('.')[2][:3].upper()
        except Exception as e:
            pass
            EpgError = 'Error in getting AddOn ID\n' + repr(e) 
            kaddonID = ''
            taddonID = ''
        log('kaddonID= %r' % kaddonID)
        log('taddonID= %r' % taddonID)
        if kaddonID != '' and kaddonID != taddonID:
            krogsbelladdons.append(kaddonID)
    log('krogsbelladdons= %r' % krogsbelladdons)
    for field in channels:
        cat          = field[0]
        name         = field[1]
        url          = field[2]
        epg_channel  = field[3]
        logo         = field[4]
        otheraddon = False
        for id in krogsbelladdons:
            if ' (' + id + ')' in name:
                otheraddon = True
        ###log('url != %r and /live/ in url.lower() %r and not (D) in name %r and not otheraddon %r and name[:2] != ▬  %r ' % (url != 'url',not '/live/' in url.lower(),' (D)' in name, not otheraddon, name[:2]))
        ###if url != 'url' and '/live/' in url.lower() and not ' (D)' in name and not otheraddon and name[:2] != '▬ ':
        if url != 'url' and '/live/' in url.lower() and not ' (D' in name and not otheraddon and name[:2] != '▬ ' and name[:4] != '\xe2\x96\xac ':
            line=cat + ',' + name + ',' + epg_channel + ',' + logo + ',,,,'
            LF.write(line + '\n')     

def CHANNELlist(LF):   ### ROQ TV
    nowDate= datetime.today().strftime('%Y-%m-%d')
    ###utils.logdev('CHANNELlist','LF= ' + repr(LF))
    krogsbelladdons = []
    KrogsbellAddOns = definition.getKrogsbellAddOns()
    log('KrogsbellAddOns= %r' % KrogsbellAddOns)
    for kaddon in KrogsbellAddOns:
        log('kaddon= %r' % kaddon)
        try:
            kaddonID = kaddon.split('.')[2][:3].upper()
            taddonID = ADDONid.split('.')[2][:3].upper()
        except Exception as e:
            pass
            EpgError = 'Error in getting AddOn ID\n' + repr(e) 
            kaddonID = ''
            taddonID = ''
        log('kaddonID= %r' % kaddonID)
        log('taddonID= %r' % taddonID)
        if kaddonID != '' and kaddonID != taddonID:
            krogsbelladdons.append(kaddonID)
    LF.write('# My ' + ADDON.getAddonInfo('name') + ' Channels\n')
    LF.write(' \n \n \n*** My ' + ADDON.getAddonInfo('name') + ' Live Channels at ' + nowDate + ' ***********************=\n')
    ### channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER)
    ### channels = []
    channels = getAllChannelsList()
    ###channels = sorted(channels, key=itemgetter(1))
    ###channels = sorted(channels,key=lambda i:i[1].lower())  ### Sort ignore case coloum 1
    LIVE  = '/live/'
    MOVIE = '/movie/'
    SERIES= '/series/'
    for field in channels:
        cat          = field[0]
        name         = field[1]
        url          = field[2]
        otheraddon = False
        for id in krogsbelladdons:
            if ' (' + id + ')' in name:
                otheraddon = True
        ###if url != 'url' and '/live/' in url.lower():
        ###if url != 'url' and '/live/' in url.lower() and not ' (D)' in name and not otheraddon and name[:2] != '▬ ':
        urll = url.lower()
        if url != 'url' and (LIVE in urll or not MOVIE in urll and not SERIES in urll) and not ' (D' in name and not otheraddon and name[:2] != '▬ ' and name[:4] != '\xe2\x96\xac ':
            line=name + '=' + url
            LF.write(line + '\n')
    
    LF.write(' \n \n \n*** My ' + ADDON.getAddonInfo('name') + ' Videos at ' + nowDate + ' ***********************=\n')
    for field in channels:

        cat          = field[0]
        name         = field[1]
        url          = field[2]
        
        ###if url != 'url' and not '/live/' in url.lower() and not ' (D)' in name and not otheraddon and name[:2] != '▬ ':
        urll = url.lower()
        if url != 'url' and MOVIE in urll and not ' (D' in name and not otheraddon and name[:2] != '▬ ' and name[:4] != '\xe2\x96\xac ':
            line=name + '=' + url
            LF.write(line + '\n')
            
    LF.write(' \n \n \n*** My ' + ADDON.getAddonInfo('name') + ' Series at ' + nowDate + ' ***********************=\n')
    for field in channels:

        cat          = field[0]
        name         = field[1]
        url          = field[2]
        
        ###if url != 'url' and not '/live/' in url.lower() and not ' (D)' in name and not otheraddon and name[:2] != '▬ ':
        urll = url.lower()
        if url != 'url' and SERIES in urll and not ' (D' in name and not otheraddon and name[:2] != '▬ ' and name[:4] != '\xe2\x96\xac ':
            line=name + '=' + url
            LF.write(line + '\n')
    
def CHANNELDisplaylist(LF):   ### ROQ TV
    nowDate= datetime.today().strftime('%Y-%m-%d')
    krogsbelladdons = []
    KrogsbellAddOns = definition.getKrogsbellAddOns()
    log('KrogsbellAddOns= %r' % KrogsbellAddOns)
    for kaddon in KrogsbellAddOns:
        log('kaddon= %r' % kaddon)
        try:
            kaddonID = kaddon.split('.')[2][:3].upper()
            taddonID = ADDONid.split('.')[2][:3].upper()
        except Exception as e:
            pass
            EpgError = 'Error in getting AddOn ID\n' + repr(e) 
            kaddonID = ''
            taddonID = ''
        log('kaddonID= %r' % kaddonID)
        log('taddonID= %r' % taddonID)
        if kaddonID != '' and kaddonID != taddonID:
            krogsbelladdons.append(kaddonID)
    ###utils.logdev('CHANNELlist','LF= ' + repr(LF))
    LF.write('# My ' + ADDON.getAddonInfo('name') + ' Channels\n')
    LF.write(' \n \n \n*** My ' + ADDON.getAddonInfo('name') + ' Live Channels at ' + nowDate + ' ***********************=\n')
    ### channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER)
    ### channels = []
    channels = getAllChannelsList()
    ###channels = sorted(channels, key=itemgetter(1))
    i = 0
    LIVE  = '/live/'
    MOVIE = '/movie/'
    SERIES= '/series/'
    for field in channels:
        cat          = field[0]
        name         = field[1]
        url          = field[2]
        otheraddon = False
        for id in krogsbelladdons:
            if ' (' + id + ')' in name:
                otheraddon = True
        ###if url != 'url' and 'live' in url.lower() and not ' (D)' in name:
        urll = url.lower()
        if url != 'url' and (LIVE in urll or not MOVIE in urll and not SERIES in urll) and not ' (D' in name and not otheraddon and name[:2] != '▬ ' and name[:4] != '\xe2\x96\xac ':
            i += 1
            line=format(i, '04d') + ' ' + name
            LF.write(line + '\n')
    
    LF.write(' \n \n \n*** My ' + ADDON.getAddonInfo('name') + ' Videos at ' + nowDate + ' ***********************=\n')
    i = 0
    for field in channels:

        cat          = field[0]
        name         = field[1]
        url          = field[2]
        otheraddon = False
        for id in krogsbelladdons:
            if ' (' + id + ')' in name:
                otheraddon = True
        ###if url != 'url' and not 'live' in url.lower() and not ' (D)' in name:
        urll = url.lower()
        if url != 'url' and MOVIE in urll and not ' (D' in name and not otheraddon and name[:2] != '▬ ' and name[:4] != '\xe2\x96\xac ':
        ###if url != 'url' and not '/live/' in url.lower() and not ' (D)' in name and not otheraddon and name[:2] != '▬ ':
            i += 1
            line=format(i, '04d') + ' ' + name
            LF.write(line + '\n')
            
    LF.write(' \n \n \n*** My ' + ADDON.getAddonInfo('name') + ' Series at ' + nowDate + ' ***********************=\n')
    i = 0
    for field in channels:

        cat          = field[0]
        name         = field[1]
        url          = field[2]
        otheraddon = False
        for id in krogsbelladdons:
            if ' (' + id + ')' in name:
                otheraddon = True
        ###if url != 'url' and not 'live' in url.lower() and not ' (D)' in name:
        urll = url.lower()
        if url != 'url' and SERIES in urll and not ' (D' in name and not otheraddon and name[:2] != '▬ ' and name[:4] != '\xe2\x96\xac ':
        ###if url != 'url' and not '/live/' in url.lower() and not ' (D)' in name and not otheraddon and name[:2] != '▬ ':
            i += 1
            line=format(i, '04d') + ' ' + name
            LF.write(line + '\n')
    

def CHANNELlistNTV(LF):
    #cat = '16' # NTV Ultimate
    #cat = '-2' # My Channels
    #cat = '-1' # My Favorites
    #cat = '10' # Indian Tv
    #cat = '15' # Scandinavian
    #cat = '12' # DK + UK ?
    #cats = ['-2','-1','0','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30']
    nowDate= datetime.today().strftime('%Y-%m-%d')
    if referralLink() == '1':
        cats = ['-2','-1','16']
    if referralLink() == '2':
        cats = ['10']
    if referralLink() == '3':
        cats = ['-2','10','20','25']
    if not referralLink() == '1' and not referralLink() == '2' and not referralLink() == '3'  :
        cats = ['-2','-1','16']
    for cat in cats:
        if cat == '-2':
            LF.write('# cat= ' + cat + ' My ' + ADDON.getAddonInfo('name') + ' Channels\n')
            LF.write('*** My ' + ADDON.getAddonInfo('name') + ' Channels at ' + nowDate + ' ***********************=\n')
        elif cat == '-1':
            LF.write('# cat= ' + cat + ' My Favorites ' + ADDON.getAddonInfo('name') + ' Channels\n')
            LF.write('*** My Favorites ' + ADDON.getAddonInfo('name') + ' Channels at ' + nowDate + ' ***********************=\n')
        elif cat == '16':
            LF.write('# cat= ' + cat + ' ' + ADDON.getAddonInfo('name') + ' Ultimate Channels\n')
            LF.write('*** ' + ADDON.getAddonInfo('name') + ' Ultimate Channels at ' + nowDate + ' ***********************=\n')
        else:
            LF.write('# cat= ' + cat + '\n')
            LF.write('*** ' + ADDON.getAddonInfo('name') + ' Channels #' + cat + ' at ' + nowDate + ' ***********************=\n')
        """
        from hashlib import md5
        streamtype = ADDON.getSetting('streamtype')
        if streamtype == '0':
            STREAMTYPE = 'NTV-XBMC-HLS-'
        elif streamtype == '1':
            STREAMTYPE = 'NTV-XBMC-'
        site=definition.getBASEURL() + '/index.php?' + referral()+ 'c=6&a=0'
        datapath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        cookie_path = os.path.join(datapath, 'cookies')
        cookie_jar = os.path.join(cookie_path, "ntv.lwp")
        UA=STREAMTYPE + ADDON.getAddonInfo('version') 
        #print  "UA=STREAMTYPE + ADDON.getAddonInfo('version')= " + str(repr(UA))
        netX=net.Net()
        loginurl = definition.getBASEURL() + '/index.php?' + referral() + 'c=3&a=4'
        username    =ADDON.getSetting('user')
        password =md5(ADDON.getSetting('pass')).hexdigest()

        data     = {'email': username,
                                                'psw2': password,
                                                'rmbme': 'on'}
        headers  = {'Host':definition.getBASEURL().replace('http://',''),
                                                'Origin':definition.getBASEURL() + '',
                                                'Referer':definition.getBASEURL() + '/index.php?' + referral() + 'c=3&a=0','User-Agent' : UA}

        html = netX.http_POST(loginurl, data, headers).content
        if 'success' in html:
            if os.path.exists(cookie_path) == False:
                os.makedirs(cookie_path)
            netX.save_cookies(cookie_jar)


        #print 'default.py CHANNELS(name= %s, cat= %s)' % (repr(name),repr(cat))
        netX.set_cookies(cookie_jar)
        imageUrl=definition.getBASEURL() + '/res/content/tv/'
        now= datetime.today().strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20')
        url='&mwAction=category&xbmc=1&mwData={"id":"%s","time":"%s","type":"tv"}'%(cat,now)
        #print 'default.py YYYY site+url= %s%s'  % (site,url)
        link = netX.http_GET(site+url, headers={'User-Agent' : UA}).content
        """
        
        data = json.loads(link)
        channels=data['contents']
        
        channels = sorted(channels, key=itemgetter('name'))
        BASE=data['base_url']
        utils.logdev('CHANNELlist','cat= %s with BASE= %s' % (cat, repr(BASE)))
        utils.logdev('CHANNELlist','imageUrl= %s' % repr(imageUrl))
        for field in channels:
            #iconimage=BASE+field['icon']
            endTime      =  field['time_to']
            name         =  field['name'].encode("utf-8")
            channel      =  field['id']
            whatsup      =  field['whatsup'].encode("utf-8")
            description  =  field['descr'].encode("utf-8")
            iconimage = getIcon(name,channel)   ##############################################################################################
            if referralLink() == '-1':   ### 2016-05-04 don't show (record)/(view) for wozbox any more
                line=name + ' (record)=plugin://' + ADDON.getAddonInfo('id') + '/?url=url&mode=2009&name=' + urllib.quote_plus(name) + '+-+%5BCOLOR+red%5Dn+a%5B%2FCOLOR%5D&iconimage=' + urllib.quote_plus(iconimage) + '&cat=' + channel 
                LF.write(line + '\n')
                line=name + ' (view)=plugin://' + ADDON.getAddonInfo('id') + '/?url=url&mode=200&name=' + urllib.quote_plus(name) + '+-+%5BCOLOR+green%5Dn+a%5B%2FCOLOR%5D&iconimage=' + urllib.quote_plus(iconimage) + '&cat=' + channel 
            if not referralLink() == '-1':
                line=name + ' =plugin://' + ADDON.getAddonInfo('id') + '/?url=url&mode=200&name=' + urllib.quote_plus(name) + '+-+' + urllib.quote_plus(name) + '&iconimage=' + urllib.quote_plus(iconimage) + '&cat=' + channel 
            LF.write(line + '\n')

def referralLink():
    # 0= NTV, 1= WOZBOX www.wozboxtv.com
    referralLink=ADDON.getSetting('my_referral_link')
    return referralLink

def referral():
    #site=definition.getBASEURL() + '/index.php?c=6&a=0'
    #referralLink=ADDON.getSetting('my_referral_link')
    #if referralLink == '1':
    #   referral = 'r=wb&'
    #else:
    referral = ''
    #referralsite='http://www.ntv.mx/index.php?' + referral+ 'c=6&a=0'
    return referral

def parseDate(dateString):
    ### dateString ==> dt_obj
    x = 'start'
    try:   ### Keep dt_obj
        if type(dateString) == datetime:
            log('parseDate(return 1 dateString= %r)' % dateString)
            return dateString
    except Exception as e:
        pass
        log('parseDate(pass 2 dateString= %r, ERROR: %r)' % (dateString,e))
    try:   ### truncate to seconds
        dateString = dateString.split('.')[0]  ### 2017-09-20 02:37:26.143149 ==> 2017-09-20 02:37:26
    except:
        pass
    try:   ### replace 'web space'
        x = dateString.replace('%20', ' ')
        dateString = x
    except:
        pass
    try:   ### normal datestring as input
        #dateString = '2050-01-01 00:00:00'
        time_tuple = datetime.strptime(dateString, "%Y-%m-%d %H:%M:%S")
        x = datetime(*time_tuple[0:6])
        return x
    except:
        pass
    try:   ### is dateString timestamp
        dateString = int(dateString)
        x = datetime.fromtimestamp(time.mktime(dateString))
        return x
    except:
        pass
    try:
        if isinstance(dateString, datetime.date):
            time_tuple = dateString.timetuple()
            x = datetime(*time_tuple[0:6])
            return x
    except:
        pass
    try:
        x = datetime.fromtimestamp(time.mktime(time.strptime(dateString.encode('utf-8', 'replace'), "%Y-%m-%d")))
        return x
    except:
        pass
    try:
        x = datetime.fromtimestamp(time.mktime(time.strptime(dateString.encode('utf-8', 'replace'), "%Y-%m-%d %H:%M:%S")))
        return x
    except:
        pass 
    try:
        time_tuple = time.strptime(dateString, "%Y-%m-%d %H:%M:%S")
        dt_obj = datetime(*time_tuple[0:6])
        return dt_obj
    except:
        pass
    try:
        x = datetime.fromtimestamp(time.mktime(time.strptime(dateString.encode('utf-8', 'replace'), "%Y-%m-%d %H:%M:%S")))
        return x
    except:
        pass
    try:
        date_str = safe_str(dateString)
        time_tuple = time.strptime(date_str, "%Y-%m-%d %H:%M:%S")
        x = datetime(*time_tuple[0:6])
        return x
    except:
        pass
    try:
        xint = float(dateString)
        x = datetime.fromtimestamp(xint)
        return x
    except:
        pass
    x = datetime.today() ### + timedelta(days = 100) # ERROR RETURN
    ###log('parseDate FAILED returning some time in the future + 100 days: parseDate(dateString= %r) ==> %r' %(dateString,x))
    log('parseDate FAILED returning now: parseDate(dateString= %r) ==> %r' %(dateString,x))
    return x 

def parseDateNEW(dateString):
    ### dateString ==> dt_obj
    modulex = 'parseDate'
    log('parseDate(dateString= %r)' % dateString)
    x = datetime.now()
    log('parseDate(now x= %r)' % x)
    
    try:
        if dateString == None:
            log('parseDate(return 1 x= %r)' % x)
            return x
    except Exception as e:
        pass
        log('parseDate(pass 1 dateString= %r, ERROR: %r)' % (dateString,e))
    try:
        x = dateString.replace('%20', ' ')
        log('parseDate(replace 1,5 x= %r, dateString= %r)' % (x,dateString))
        dateString = x
    except Exception as e:
        pass
        log('parseDate(pass 2 dateString= %r, ERROR: %r)' % (dateString,e))
    try:
        dateString = int(dateString)
        x = datetime.fromtimestamp(time.mktime(dateString))
        log('parseDate(return 2 x= %r)' % x)
        return x
    except Exception as e:
        pass
        log('parseDate(pass 3 dateString= %r, ERROR: %r)' % (dateString,e))
    try:
        dateString = dateString.split('.')[0]  ### 2017-09-20 02:37:26.143149 ==> 2017-09-20 02:37:26
    except Exception as e:
        pass
        log('parseDate(pass 4 dateString= %r, ERROR: %r)' % (dateString,e))
    log('parseDate(pass 3 dateString= %r)' % dateString)
    try:
        if type(dateString) == datetime:
            log('parseDate(return 4 dateString= %r)' % dateString)
            return dateString
    except Exception as e:
        pass
        log('parseDate(pass 5 dateString= %r, ERROR: %r)' % (dateString,e))
    try:
        #dateString = '2050-01-01 00:00:00'
        time_tuple = datetime.strptime(dateString, "%Y-%m-%d %H:%M:%S")
        #time_tuple = time.strptime(dateString, "%Y-%m-%d %H:%M:%S")
        x = datetime(*time_tuple[0:6])
        log('parseDate(return 5 x= %r)' % x)
        return x
    except Exception as e:
        pass
        log('parseDate(pass 6 dateString= %r, ERROR: %r)' % (dateString,e))
    try:
        if isinstance(dateString, datetime.date):
            time_tuple = dateString.timetuple()
            x = datetime(*time_tuple[0:6])
            log('parseDate(return 6 x= %r, dateString= %r)' % (x,dateString))
            return x
    except Exception as e:
        pass
        log('parseDate(pass 7 dateString= %r, ERROR: %r)' % (dateString,e))
    try:
        x = datetime.fromtimestamp(time.mktime(time.strptime(dateString.encode('utf-8', 'replace'), "%Y-%m-%d")))
        log('parseDate(return 8 x= %r, dateString= %r)' % (x,dateString))
        return x
    except Exception as e:
        pass
        log('parseDate(pass 8 dateString= %r, ERROR: %r)' % (dateString,e))
    try:
        x = datetime.fromtimestamp(time.mktime(time.strptime(dateString.encode('utf-8', 'replace'), "%Y-%m-%d %H:%M:%S")))
        log('parseDate(return 9 x= %r, dateString= %r)' % (x,dateString))
        return x
    except Exception as e:
        pass
        log('parseDate(pass 9 dateString= %r, ERROR: %r)' % (dateString,e))
    try:
        time_tuple = time.strptime(dateString, "%Y-%m-%d %H:%M:%S")
        dt_obj = datetime(*time_tuple[0:6])
        log('parseDate(return 10 dt_obj= %r, dateString= %r)' % (dt_obj,dateString))
        return dt_obj
    except Exception as e:
        pass
        log('parseDate(pass 10 dateString= %r, ERROR: %r)' % (dateString,e))
    try:
        x = datetime.fromtimestamp(time.mktime(time.strptime(dateString.encode('utf-8', 'replace'), "%Y-%m-%d %H:%M:%S")))
        log('parseDate(return 11 x= %r, dateString= %r)' % (x,dateString))
        return x
    except Exception as e:
        pass
        log('parseDate(pass 11 dateString= %r, ERROR: %r)' % (dateString,e))
    try:
        date_str = safe_str(dateString)
        time_tuple = time.strptime(date_str, "%Y-%m-%d %H:%M:%S")
        x = datetime(*time_tuple[0:6])
        log('parseDate(return 12 x= %r, dateString= %r)' % (x,dateString))
        return x
    except Exception as e:
        pass
        log('parseDate(pass 12 dateString= %r, ERROR: %r)' % (dateString,e))
    try:
        xint = float(dateString)
        x = datetime.fromtimestamp(xint)
        log('parseDate(return 13 x= %r, dateString= %r)' % (x,dateString))
        return x
    except Exception as e:
        pass
        log('parseDate(pass 13 dateString= %r, ERROR: %r)' % (dateString,e))
    x = datetime.today()  + timedelta(days = 100) # ERROR RETURN
    log('parseDate FAILED returning some time in the future + 100 days: parseDate(dateString= %r) ==> %r' %(dateString,x))
    return x 
    
def filesize(infile):
    try:
        file = open(infile,'r')
        contents = file.read()
        return len(contents)
    except Exception as e:
        pass
        log('filesize(infile= %r) ERROR: %r' % (infile,e))
        return 0
       
def backupSetupxml():
    try:
        dbPath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        if not os.path.exists(dbPath):
            os.mkdir(dbPath)        
        timestampnow = datetime.now()
        timestampnowS = str(datetime.now()).split('.')[0].replace('-','').replace(' ','').replace(':','') + '-'
        backupSrc = os.path.join(dbPath, SETTINGSXML)
        if filesize(backupSrc) > 0:
            backupDst = os.path.join(dbPath, timestampnowS + SETTINGSXML)
            shutil.copyfile(backupSrc, backupDst)
    except Exception as e:
        pass
        log('backupSetupxml recordings.py backup SETTINGSXML Failed!\nERROR: %r' % e)  # Put in LOG
        
    path = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    files =  glob.glob(os.path.join(path, '*-' + SETTINGSXML))
    files1 = sorted(files, reverse=True)
    index = 0   
    try:
        BackupCount = int(ADDON.getSetting('BackupCount'))  
    except:
        pass
        BackupCount = 5
    for infile in files1:
        ###log('index= %r, Filename start= %r' % (index,infile))
        infileBasic = os.path.basename(infile)
        if infileBasic != SETTINGSXML : ### SETTINGSXML skipped
            size = filesize(infile)
            if index < BackupCount and size > 0:
                try:
                    index += 1
                except:
                    pass
                    utils.notificationforced('[COLOR red]Restoring %s cleanup FAILED![/COLOR]' % RECORDS_DB)
            else:
                try:
                    if size > 0:
                        index += 1
                    deleteFile(infile)
                except:
                    pass
                    utils.notificationforced('[COLOR red]Restoring %s cleanup FAILED![/COLOR]' % RECORDS_DB)
    
def restoreSetupXml(backupSrc):
    try:
        utils.notificationforced('[COLOR green]Restoring %s[/COLOR]' % SETTINGSXML,time=1000)
        backupSetupxml()
        dbPath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        if not os.path.exists(dbPath):
            os.mkdir(dbPath)
        backupDst = os.path.join(dbPath, SETTINGSXML)
        if filesize(backupDst) > 0:
            deleteFile(backupDst)
            shutil.copyfile(backupSrc, backupDst)
            #reschedule()
            utils.notificationforced('[COLOR green]Restoring %s Finished![/COLOR]' % SETTINGSXML)
        else:
            utils.notificationforced('[COLOR red]Restoring %s NOT done - file size is zero![/COLOR]' % SETTINGSXML)
    except:
        pass
        utils.notificationforced('[COLOR red]Restoring %s FAILED![/COLOR]' % SETTINGSXML)

def restoreLastSetupXml():
    #utils.notification('[COLOR green]Restoring %s[/COLOR]' % SETTINGSXML,time=1000)
    path = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    files =  glob.glob(os.path.join(path, '*.xml'))
    defaultfile = os.path.join(path, SETTINGSXML)
    files1 = sorted(files, reverse=True)
    storedusers = []
    index = 0
    try:
        BackupCount = int(ADDON.getSetting('BackupCount'))  
    except:
        pass
        BackupCount = 5
    restored = False
    for infile in files1:
        mail = utils.username(infile)
        firstmailoccurance = True
        for xmail in storedusers:   ######
            if xmail == mail:
                firstmailoccurance = False
        if firstmailoccurance:
            storedusers.append(mail)
            log('Storedusers: ' +repr(storedusers))  
        if index < BackupCount:
            try:
                index += 1
                mail = utils.username(infile)
                if restored == False and not infile == defaultfile and not mail == '': 
                    if filesize(infile) > 0:
                        deleteFile(defaultfile)
                        shutil.copyfile(infile, defaultfile)
                        #utils.notification('[COLOR green]Restoring %s Finished![/COLOR]' % SETTINGSXML)
                        restored = True
            except:
                pass
                utils.notificationforced('[COLOR red]Restoring %s FAILED![/COLOR]' % SETTINGSXML)
        else:
            try:
                if restored == True:
                    index += 1
                    if not infile == defaultfile and not firstmailoccurance: 
                        deleteFile(infile)
            except:
                pass
                utils.notificationforced('[COLOR red]Restoring %s cleanup FAILED![/COLOR]' % SETTINGSXML)
    return restored
        
def backupDataBase():
    try:
        dbPath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        if not os.path.exists(dbPath):
            os.mkdir(dbPath)
        backupSrc = os.path.join(dbPath, RECORDS_DB)
        timestampnow = datetime.now()
        timestampnowS = str(datetime.now()).split('.')[0].replace('-','').replace(' ','').replace(':','') + '-'
        usernamed = ADDON.getSetting('user') + '-'
        backupDst = os.path.join(dbPath, timestampnowS + usernamed + RECORDS_DB)
        log('backupDst= %r' % backupDst)
        shutil.copyfile(backupSrc, backupDst)
    except:
        pass
        log('BackupDataBase Failed!')  # Put in LOG
    
    path = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    files =  glob.glob(os.path.join(path, '*.db'))
    defaultfile = os.path.join(path, RECORDS_DB)
    files1 = sorted(files, reverse=True)
    index = 0   
    try:
        BackupCount = int(ADDON.getSetting('BackupCount'))  
    except:
        pass
        BackupCount = 5
    for infile in files1:
        ###log('index= %r, Filename start= %r' % (index,infile))
        infileBasic = os.path.basename(infile)
        if infileBasic != FILES_DB and infileBasic != RECORDS_DB : ### files.db and active recordings_adb.db skipped
            if index < BackupCount:
                try:
                    index += 1
                except:
                    pass
                    utils.notificationforced('[COLOR red]Restoring %s cleanup FAILED![/COLOR]' % RECORDS_DB)
            else:
                try:
                    if not infile == defaultfile: 
                        index += 1
                        deleteFile(infile)
                except:
                    pass
                    utils.notificationforced('[COLOR red]Restoring %s cleanup FAILED![/COLOR]' % RECORDS_DB)

def deleteDataBase():
    try:
        utils.notificationforced('[COLOR green]Delete Database[/COLOR]',time=100000)
        backupDataBase()
        delAllPlannedPrograms()
        dbPath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        if not os.path.exists(dbPath):
            os.mkdir(dbPath)
        backupDst = os.path.join(dbPath, RECORDS_DB)
        deleteFile(backupDst)
        utils.notificationforced('[COLOR green]Delete Database Finished![/COLOR]')
    except Exception as e:
        pass
        log('Error in deleteDataBase: ' + repr(e))
        utils.notificationforced('[COLOR red]Delete Database FAILED![/COLOR]')

def restoreBackupDataBase(backupSrc):
    try:
        utils.notificationforced('[COLOR green]Restoring Database[/COLOR]',time=100000)
        backupDataBase()
        delAllPlannedPrograms()
        dbPath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        if not os.path.exists(dbPath):
            os.mkdir(dbPath)
        backupDst = os.path.join(dbPath, RECORDS_DB)
        
        deleteFile(backupDst)
        shutil.copyfile(backupSrc, backupDst)
        reschedule()
        utils.notificationforced('[COLOR green]Restoring Database Finished![/COLOR]')
    except Exception as e:
        pass
        utils.notificationforced('[COLOR red]Restoring Database FAILED![/COLOR]')
        log('restoreBackupDataBase recordings.py backupDataBase Failed/ERROR: %r' % e)

def restoreRecursiveRecordings(url):
    try:
        utils.notificationforced('[COLOR green]Restoring Recursive Records[/COLOR]',time=100000)
        log('restoreRecursiveRecordings Restoring Recursive Records url= ' + repr(url))
        restorecount = RecursiveRecordings(url)
        utils.notificationforced('[COLOR green]Restoring Recursive Records Finished![/COLOR] %s records restored' % repr(restorecount))
    except Exception as e:
        pass
        log('restoreRecursiveRecordings error in Restoring Recursive Records: ' + repr(e))
        utils.notificationforced('[COLOR red]Restoring Recursive Records FAILED![/COLOR] ' + repr(restorecount) + ' records restored: ' + repr(e))

def RecursiveRecordings(dbPath):
    RECURSIVEMARKER = 'Recursive:'
    restorecount = 0
    recur = getDatabaseConnection(dbPath)
    conn = getConnection()
    d = conn.cursor()
    c = recur.cursor()
    c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE '%Recursive:%' COLLATE NOCASE")  # Find all recursive recordings
    recordingsE = c.fetchall()
    # Put recursive recordings changed last - first
    reC = sorted(recordingsE, key=itemgetter(2), reverse=True)
    
    for i in range(0, len(reC)):
        log('RecursiveRecordings Recursive Records: ' + repr(i) + '= ' + repr(reC[i][1].replace(RECURSIVEMARKER,'')))
        d.execute("SELECT DISTINCT cat, name FROM recordings_adc WHERE cat=? and name=? COLLATE NOCASE", [reC[i][0],reC[i][1]])
        recExists = d.fetchall()
        if len(recExists) < 1:
            ### Log which records that restore to find out why they don't stay on reschedule
            
            d.execute("INSERT OR REPLACE INTO recordings_adc(cat, name, start, end, alarmname, description, playchannel) VALUES(?, ?, ?, ?, ?, ?, ?)", reC[i]) ## insert recursive
            restorecount += 1
            log('RecursiveRecordings Add Recursive Record: ' + repr(i) + '= ' + repr(reC[i][1].replace(RECURSIVEMARKER,'')))
    recur.commit()
    conn.commit()
    c.close()
    d.close()
    return restorecount
"""
def setEPGChannel(cat,channel):  ### Code Copy... 2017-09-04
    try:
        log('setEPGChannel(cat)')
        conn = recordings.getConnection()
        c = conn.cursor()
        c.execute("SELECT * FROM channels WHERE id=?", [cat])
        favorites = c.fetchall()
        result = []

        for index in range(0, len(favorites)):
            ch = []
            for i in range(0, len(favorites[index])):
                if favorites[index][i] == None:
                    ch.append('')
                else:
                    ch.append(favorites[index][i])
            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [ch[0], ch[1], ch[2], ch[3], ch[4], ch[5], ch[6], ch[7], ch[8], channel,ch[10],ch[11],ch[12]])
        if result == []:
            log('EPG not found for cat= %r' % cat)

        conn.commit()
        c.close() 
    except Exception as  e:
        pass
        utils.notification('Error in setEPGChannel(cat) '+ cat + ' \n' + repr(e))
"""    
 
def RestoreOldFavorites(dbPath):
    restorecount = 0
    recur = getDatabaseConnection(dbPath)
    conn = getConnection()
    d = conn.cursor()
    c = recur.cursor()
    c.execute("SELECT * FROM channels WHERE favorite!=?",['False'])  # Find all favorite channels
    favorites = c.fetchall()
    errorcount = 0
    for index in range(0, len(favorites)):
        ch = []
       
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None or favorites[index][i] == '':
                """
                if i == 7:
                    ch.append('True')
                elif i == 8:
                    ch.append(0)
                elif i != 7 and i != 8:
                """
                ch.append('')
            else:
                ch.append(favorites[index][i])
        ###d.execute("SELECT DISTINCT id, source FROM channels WHERE id=? and source=? COLLATE NOCASE", [ch[0],ch[4]])
        ###recExists = d.fetchall()
        ###if len(recExists) < 1:
        log( 'len(favorites[index])= %r' % len(favorites[index]))
        if len(favorites[index]) == 13:
            d.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [ch[0],ch[1],ch[2],ch[3],ch[4],ch[5],ch[6],ch[7],ch[8],ch[9],ch[10],ch[11],ch[12]])
            restorecount += 1
        else:
            if errorcount < 10:
                xbmcgui.Dialog().ok(ADDONname, 'Not 13 items in channel definition!\n' + repr(ch)+'Channel not updated')
                log( 'Not 13 items in channel definition!\n'+ repr(ch)+'\nChannel not updated')
            errorcount += 1
    recur.commit()
    conn.commit()
    c.close()
    d.close()
    return restorecount

def RestoreOldRecursiveChannels(dbPath):
    restorecount = 0
    recur = getDatabaseConnection(dbPath)
    conn = getConnection()
    d = conn.cursor()
    c = recur.cursor()
    c.execute("SELECT * FROM channelsRecursive")  # Find all Recursive channels
    favorites = c.fetchall()
    errorcount = 0
    for index in range(0, len(favorites)):
        ch = []
       
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None or favorites[index][i] == '':
                if i == 7:
                    ch.append('False')
                elif i == 8:
                    ch.append(0)
                elif i != 7 and i != 8:
                    ch.append('')
            else:
                ch.append(favorites[index][i])
        ###d.execute("SELECT DISTINCT id, source FROM channels WHERE id=? and source=? COLLATE NOCASE", [ch[0],ch[4]])
        ###recExists = d.fetchall()
        ###if len(recExists) < 1:
        log( 'len(favorites[index])= %r' % len(favorites[index]))
        if len(favorites[index]) == 13:
            d.execute("INSERT OR REPLACE INTO channelsRecursive(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [ch[0],ch[1],ch[2],ch[3],ch[4],ch[5],ch[6],ch[7],ch[8],ch[9],ch[10],ch[11],ch[12]])
            restorecount += 1
        else:
            if errorcount < 10:
                xbmcgui.Dialog().ok(ADDONname, 'Not 13 items in channel definition!\n\n'+ repr(ch)+'Channel not updated')
                log( 'Not 13 items in channel definition!\n'+ repr(ch)+'\nChannel not updated')
            errorcount += 1
    recur.commit()
    conn.commit()
    c.close()
    d.close()
    return restorecount
    
def RestoreOldChannels(dbPath):
    restorecount = 0
    recur = getDatabaseConnection(dbPath)
    conn = getConnection()
    d = conn.cursor()
    c = recur.cursor()
    c.execute("SELECT * FROM channels")  # Find all channels
    favorites = c.fetchall()
    errorcount = 0
    for index in range(0, len(favorites)):
        ch = []
       
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None or favorites[index][i] == '':
                if i == 7:
                    ch.append('False')
                elif i == 8:
                    ch.append(0)
                elif i != 7 and i != 8:
                    ch.append('')
            else:
                ch.append(favorites[index][i])
        ###d.execute("SELECT DISTINCT id, source FROM channels WHERE id=? and source=? COLLATE NOCASE", [ch[0],ch[4]])
        ###recExists = d.fetchall()
        ###if len(recExists) < 1:
        log( 'len(favorites[index])= %r' % len(favorites[index]))
        if len(favorites[index]) == 13:
            d.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [ch[0],ch[1],ch[2],ch[3],ch[4],ch[5],ch[6],ch[7],ch[8],ch[9],ch[10],ch[11],ch[12]])
            restorecount += 1
        else:
            if errorcount < 10:
                xbmcgui.Dialog().ok(ADDONname, 'Not 13 items in channel definition!\n\n'+ repr(ch)+'Channel not updated')
                log( 'Not 13 items in channel definition!\n'+ repr(ch)+'\nChannel not updated')
            errorcount += 1
    recur.commit()
    conn.commit()
    c.close()
    d.close()
    return restorecount

def RestoreOldEPG(dbPath):
    restorecount = 0
    recur = getDatabaseConnection(dbPath)
    conn = getConnection()
    d = conn.cursor()
    c = recur.cursor()
    c.execute("SELECT * FROM programs")  # Find all old programs
    favorites = c.fetchall()
    for index in range(0, len(favorites)):
        ch = []
        ###for i in range(0, len(favorites[index])):
        for i in range(0, 15):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        
        d.execute("SELECT DISTINCT channel, start_date, end_date FROM programs WHERE channel=? and start_date=? and end_date=? COLLATE NOCASE", [ch[0],ch[3],ch[4]])
        recExists = d.fetchall()
        if len(recExists) < 1:
            
            d.execute("INSERT OR REPLACE INTO programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source, updates_id) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [ch[0], ch[1], ch[2], ch[3], ch[4], ch[5], ch[6], ch[7], ch[8], ch[9],ch[10],ch[11],ch[12],ch[13],ch[14]])
            restorecount += 1
    recur.commit()
    conn.commit()
    c.close()
    d.close()
    return restorecount

def RecursiveChannels():
    try:
        recur = getDatabaseConnection(os.path.join(datapath, RECORDS_DB))
        c = recur.cursor()
        recrecordings = c.fetchall()
        ###CREATE TABLE channelsRecursive(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, favorite BOLEAN, catchup BOLEAN, epg_channel TEXT, description TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (id, title, source))
        c.execute("SELECT DISTINCT id FROM channelsRecursive")
        recordings = c.fetchall()
        ###recur.commit()
        c.close()
        recursiveChannels = []
        for chan in recordings:
            recursiveChannels.append(chan[0])
        log('err recursiveChannels= %r' % recursiveChannels)
        return recursiveChannels
    except Exception as e:
        pass
        log('RecursiveChannels error: ' + repr(e))
        utils.notificationforced('[COLOR red]RecursiveChannels FAILED![/COLOR]: ' + repr(e))
        return []

def RecursiveRecordingsCount(dbPath):
    try:
        RECURSIVEMARKER = 'Recursive:'
        recur = getDatabaseConnection(dbPath)
        c = recur.cursor()
        ###c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE '%Recursive:%' COLLATE NOCASE")  # Find all recursive recordings
        c.execute("SELECT DISTINCT cat FROM recordings_adc WHERE name LIKE ? COLLATE NOCASE",['%' + RECURSIVEMARKER + '%'])# Find all recursive recordings
        recrecordings = c.fetchall()
        c.execute("SELECT DISTINCT cat FROM recordings_adc")
        recordings = c.fetchall()
        recur.commit()
        c.close()
        plrecordings = len(recordings) - len(recrecordings)
        return ' (P' + str(plrecordings) +'/R' + str(len(recrecordings)) + ')'
    except Exception as e:
        pass
        log('RecursiveRecordingsCount error in RecursiveRecordingsCount: ' + repr(e))
        utils.notificationforced('[COLOR red]RecursiveRecordingsCount FAILED![/COLOR]: ' + repr(e))
        return '-'

def stopAllRecordings():
    recordings = getRecordings()
    
    for index in range(0, len(recordings)): 
        cat       = recordings[index][0]
        name      = recordings[index][1]
        startDate = recordings[index][2]
        endDate   = recordings[index][3]
        try:
            log('err delRecordingPlanned(cat, startDate, endDate, name)' % (cat, startDate, endDate, name))
            delRecordingPlanned(cat, startDate, endDate, name)
        except:
            pass
            log('stopAllRecordings delRecordingPlanned FAILED(index= %r, cat= %r, startDate= %r, endDate= %r, name= %r)' %(index, cat, startDate, endDate, name))  # Put in LOG

def deleteFile(file):
    tries    = 0
    maxTries = 10
    while os.path.exists(file) and tries < maxTries:
        try:
            os.remove(file)
            break
        except:
            sleep(501)
            tries = tries + 1

def FindPlatformMoved():
    # Find the actual platform
    Platform = ''
    try:
        kodilog = xbmcvfs.translatePath(os.path.join('special://logpath' , 'kodi.log'))
        
        try: logfile = open(kodilog,'r')
        except:
            pass
            kodilog = xbmcvfs.translatePath(os.path.join('special://logpath' , 'xbmc.log'))
            
            try: logfile = open(kodilog,'r')
            except:
                pass
                kodilog = xbmcvfs.translatePath(os.path.join('special://logpath' , 'tvmc.log'))
                
                logfile = open(kodilog,'r')
        
        line0 = logfile.readline()
        
        line1 = logfile.readline()
        
        line2 = logfile.readline()
        
        line3 = logfile.readline()
        
        line4 = logfile.readline()
        
        line5 = logfile.readline()
        
        line6 = logfile.readline()
        
        line7 = logfile.readline()
        
        Platform = line2.split('Platform:')[1].strip()
        
        ADDON.setSetting('platform',Platform)
        RunningOn = line5.split('Running on ')[1].split(' ')[0].strip()
        
        ADDON.setSetting('runningon',RunningOn)
        log('FindPlatformMoved RunningOn: %s' % repr(ADDON.getSetting('runningon')))   # Put in LOG
        
        log('FindPlatformMoved ' + os.environ['OS'])  # Put in LOG
    except: 
        pass
        log('FindPlatformMoved recordings.py FindPlatform FAILED/Error')   # Put in LOG
    finally:
        logfile.close()
    return Platform

def getConnection():    
    dbPath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not os.path.exists(dbPath):
        os.mkdir(dbPath)

    conn   = sqlite3.connect(os.path.join(dbPath, RECORDS_DB), timeout = 20, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    ###conn.execute('PRAGMA case_sensitive_like = true;')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    createTable(conn)
    return conn

def getEPGConnection():    
    dbPath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not os.path.exists(dbPath):
        os.mkdir(dbPath)
    conn   = sqlite3.connect(os.path.join(dbPath, EPG_DB), timeout = 20, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    createTable(conn)
    return conn

def createEPGchannelsTable(conn):
    c = conn.cursor()
    try:
        c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, favorite BOLEAN, catchup BOLEAN, epg_channel TEXT, description TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (id, title, source))")  ### 2017-09-17
        c.execute("CREATE TABLE IF NOT EXISTS channelsRecursive(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, favorite BOLEAN, catchup BOLEAN, epg_channel TEXT, description TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (id, title, source))")
        conn.commit()
    except Exception as e:
        pass
        log('createEPGchannelsTable ERROR: %r' % e)
    c.close()

def createEPGNotificationTable(conn):
    c = conn.cursor()
    try:
        c.execute("CREATE TABLE IF NOT EXISTS CREATE TABLE notifications(channel TEXT, program_title TEXT, source TEXT, start_date INTEGER, type TEXT)")
        conn.commit()
    except Exception as e:
        pass
        log('createEPGNotificationTable ERROR: %r' % e)
    c.close()

def createEPGProgramsTable(conn):
    c = conn.cursor()
    ###c.execute("CREATE TABLE IF NOT EXISTS programs(channel TEXT, title TEXT, sub_title TEXT, start_date TIMESTAMP, end_date TIMESTAMP, description TEXT, categories TEXT, image_large TEXT, image_small TEXT, season TEXT, episode TEXT, is_movie TEXT, language TEXT, source TEXT, updates_id INTEGER, UNIQUE (channel, start_date, end_date))")
    try:   ### 2020-03-30 channel TEXT <<COLLATE NOCASE>>,
        c.execute("CREATE TABLE IF NOT EXISTS programs(channel TEXT COLLATE NOCASE, title TEXT, sub_title TEXT, start_date INTEGER, end_date INTEGER, description TEXT, categories TEXT, image_large TEXT, image_small TEXT, season TEXT, episode TEXT, is_movie TEXT, language TEXT, source TEXT, updates_id INTEGER, UNIQUE (channel, start_date, end_date), PRIMARY KEY (channel, start_date, end_date))")
        conn.commit()
    except Exception as e:
        pass
        log('createEPGProgramsTable ERROR: %r' % e)
    c.close()

def getDatabaseConnection(dbPath):    
    conn   = sqlite3.connect(dbPath, timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    ###conn.execute('PRAGMA case_sensitive_like = true;')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    createTable(conn)
    return conn

def getIconConnection():    
    dbPath = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo('path')),'resources')
    #xbmc.log('recordings.py: getIconConnection dbPath= %s' % repr(dbPath))
    if not os.path.exists(dbPath):
        os.mkdir(dbPath)
    conn   = sqlite3.connect(os.path.join(dbPath, CHANNEL_DB), timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    createIconTable(conn)
    return conn

""" WOZBOX TVGUIDE 2.0
CREATE TABLE channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, lineup TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)

CREATE TABLE notifications(channel TEXT, program_title TEXT, source TEXT, start_date TIMESTAMP, type TEXT, FOREIGN KEY(channel, source) REFERENCES channels(id, source) ON DELETE CASCADE)

CREATE TABLE programs(channel TEXT, title TEXT, sub_title TEXT, start_date INTEGER, end_date INTEGER, description TEXT, categories TEXT, image_large TEXT, image_small TEXT, season TEXT, episode TEXT, is_movie TEXT, language TEXT, source TEXT, updates_id INTEGER, UNIQUE (channel, start_date, end_date), FOREIGN KEY(channel, source) REFERENCES channels(id, source) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED, FOREIGN KEY(updates_id) REFERENCES updates(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)
"""
def createWozboxTVguidechannelsTable(conn):
    c = conn.cursor()
    ###c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, lineup TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
    c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, lineup TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, source))")
    conn.commit()
    c.close()

def createWozboxTVguideNotificationTable(conn):
    c = conn.cursor()
    ###c.execute("CREATE TABLE IF NOT EXISTS CREATE TABLE notifications(channel TEXT, program_title TEXT, source TEXT, start_date INTEGER, type TEXT, FOREIGN KEY(channel, source) REFERENCES channels(id, source) ON DELETE CASCADE)") ### 2017-08-14
    c.execute("CREATE TABLE IF NOT EXISTS CREATE TABLE notifications(channel TEXT, program_title TEXT, source TEXT, start_date INTEGER, type TEXT)")
    conn.commit()
    c.close()

def createWozboxTVguideProgramsTable(conn):
    c = conn.cursor()
    ###c.execute("CREATE TABLE IF NOT EXISTS programs(channel TEXT, title TEXT, sub_title TEXT, start_date TIMESTAMP, end_date TIMESTAMP, description TEXT, categories TEXT, image_large TEXT, image_small TEXT, season TEXT, episode TEXT, is_movie TEXT, language TEXT, source TEXT, updates_id INTEGER, UNIQUE (channel, start_date, end_date), FOREIGN KEY(channel, source) REFERENCES channels(id, source) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED, FOREIGN KEY(updates_id) REFERENCES updates(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
    c.execute("CREATE TABLE IF NOT EXISTS programs(channel TEXT, title TEXT, sub_title TEXT, start_date INTEGER, end_date INTEGER, description TEXT, categories TEXT, image_large TEXT, image_small TEXT, season TEXT, episode TEXT, is_movie TEXT, language TEXT, source TEXT, updates_id INTEGER, UNIQUE (channel, start_date, end_date), PRIMARY KEY (channel, start_date, end_date))")
    conn.commit()
    c.close()

def createTableORG(conn):
    c = conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS recordings_adc (cat TEXT, name TEXT, start TEXT, end TEXT, alarmname TEXT, description TEXT, playchannel TEXT, PRIMARY KEY (cat,name,start,end))")
    conn.commit()
    c.close()

def createTable(conn):   ###WozboxTVguidechannels
    try:
        c = conn.cursor()
        c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, favorite BOLEAN, catchup BOLEAN, epg_channel TEXT, description TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (id, title, source))")
        c.execute("CREATE TABLE IF NOT EXISTS channelsRecursive(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, favorite BOLEAN, catchup BOLEAN, epg_channel TEXT, description TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (id, title, source))")
        c.execute("CREATE TABLE IF NOT EXISTS recordings_adc (cat TEXT, name TEXT, start TEXT, end TEXT, alarmname TEXT, description TEXT, playchannel TEXT, PRIMARY KEY (cat,name,start,end))")
        c.execute("CREATE TABLE IF NOT EXISTS tvseries (name TEXT, episodes TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (name))")
        conn.commit()
        c.close()
    except Exception as e:
        pass
        log( 'createTable(conn) failed! \nERROR= %r' % (e))

def createIconTable(conn):
    try:
        c = conn.cursor()
        ##c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT NOT NULL, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (title), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)") ### 2016-05-15
        c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, favorite BOLEAN, catchup BOLEAN, epg_channel TEXT, description TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (id, title, source))")
        conn.commit()
        c.close()
    except Exception as e:
        pass
        log( 'createIconTable(conn) failed! \nERROR= %r' % (e))

def getFilesConnection():     
    dbPath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not os.path.exists(dbPath):
        os.mkdir(dbPath)
    conn   = sqlite3.connect(os.path.join(dbPath, FILES_DB), timeout = 20, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    ###conn.execute('PRAGMA case_sensitive_like = true;')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    createFileTable(conn)
    return conn
    
def deleteFileBase():
    try:
        utils.notificationforced('[COLOR green]Delete File Database[/COLOR]',time=100000)
        dbPath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        if not os.path.exists(dbPath):
            os.mkdir(dbPath)
        backupDst = os.path.join(dbPath, FILES_DB)
        deleteFile(backupDst)
        sleep(1001)
        if os.path.isfile(backupDst) != True:
            utils.notificationforced('[COLOR green]Delete File Database Finished![/COLOR]')
        else:
            utils.notificationforced('[COLOR red]Delete File Database FAILED![/COLOR]')
    except Exception as e:
        pass
        log('Error in deleteFileDataBase: ' + repr(e))
        utils.notificationforced('[COLOR red]Delete File Database FAILED![/COLOR]')
    
def createFileTable(conn):
    try:
        c = conn.cursor()
        c.execute("CREATE TABLE IF NOT EXISTS files(filename TEXT, ext TEXT, path TEXT, video TEXT, description TEXT, size TEXT, archive TEXT, updated INTEGER, created INTEGER, updatedHuman INTEGER, command TEXT, options TEXT, realtitle TEXT, startmark TEXT, PRIMARY KEY (filename, ext, path, archive))")
        conn.commit()
        c.close()
    except Exception as e:
        pass
        log( 'createFileTable(conn) failed! \nERROR= %r' % (e))
        
def realTitle(c, filename, ext, path, archive):
    try:
        log('err realTitle(c, filename= %r, ext= %r, path= %r, archive= %r)' % (filename, ext, path, archive))
        ###c = conn.cursor()
        ###c.execute("CREATE TABLE IF NOT EXISTS files(filename TEXT, ext TEXT, path TEXT, video TEXT, description TEXT, size TEXT, archive TEXT, updated INTEGER, created INTEGER, updatedHuman INTEGER, command TEXT, options TEXT, realtitle TEXT, PRIMARY KEY (filename, ext, path, archive))")
        c.execute("SELECT realtitle FROM files WHERE filename=? and ext=? and (path=? or path=?) and archive=? and video=?" , [filename, ext, path.replace('\\','/'), path.replace('/','\\'), archive, 'True'])
        ###c.execute("SELECT * FROM files WHERE filename=? and ext=? and video=?" , [filename, ext,'True'])
        realtitle = c.fetchall()
        log('err realtitle count= %r' % len(realtitle))
        return realtitle[0][0]
        ###conn.commit()
        ###c.close()
    except Exception as e:
        pass
        log( 'realTitle failed! ERROR= %r' % (e))

def addFileCleanup(c,folderpath,archive,cutoffnowTS):
    try:
        c.execute("SELECT * FROM files WHERE archive=? AND updated>=?" , [archive,cutoffnowTS])
        channels = c.fetchall()
        recordsupdated = len(channels)
        log('recordsupdated: %r' % recordsupdated)
        if recordsupdated > 0:   ### Only delete records if records have been updated
            c.execute("SELECT * FROM files WHERE archive=? AND updated<?" , [archive,cutoffnowTS])
            channels = c.fetchall()
            recordstodelete = len(channels)
            log('records to delete: %r' % recordstodelete)
            c.execute("DELETE FROM files WHERE archive=? AND updated<?" , [archive,cutoffnowTS])
    except Exception as e:
        pass
        log('addFileCleanup ERROR: %r' % e)
        
def addFileCommand(c, filename, ext, path, archive, command, options):
    log('err addFileCommand(c, filename= %r, ext= %r, path= %r, archive= %r, command= %r, options= %r)'% (filename, ext, path, archive, command, options))
    filename = filename.replace('+','xXx')   ### 2019-03-16 + seems to fuck up SQlite
    urldirectorypath = xbmcvfs.translatePath(os.path.join(utils.ADDONgetSetting('record_path')))
    if '\\' in urldirectorypath:
        path = path.replace('/','\\')
    log('addFileCommand(c= %r, filename= %r, ext= %r, path= %r, archive= %r, command= %r, options= %r)' % (c, filename, ext, path, archive, command, options))
    now = datetime.now()
    nowTS = int(time.mktime(now.timetuple()))
    nowTSold =    nowTS - 31536000    ### 365 * 24 * 60 * 60  now-timedelta(days=365)
    now = parseDate(datetime.now()) 
    filename = filename.strip()
    if filename != '':
        try:
            c.execute("SELECT * FROM files WHERE filename=? AND ext=? AND path=? AND archive=? AND video=?", [filename,ext,path,archive,'True'])
            ###c.execute("SELECT * FROM files WHERE filename=? AND path=? AND archive=? AND video=?", [filename,path,archive,'True']) 
            channels = c.fetchall()
            if len(channels) > 0:
                for chan in channels:
                    c.execute("INSERT OR REPLACE INTO files(filename, ext, path, video, description, size, archive, updated, created, updatedHuman, command, options, realtitle, startmark) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [filename, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], nowTS, chan[8], humantime(nowTS), command, options, chan[12], chan[13]])
            else:
                log('addFileCommand Error - DB record not found for %r' % filename)
        except Exception as e:
            log('addFileCommand ERROR %r' % e)
            pass
        
def addFile(c, filename, ext, path, video, description, size, archive, realtitle='', startmark=''):
    filename = filename.replace('+','xXx')   ### 2019-03-16 + seems to fuck up SQlite
    log('addFile(c= %r, filename= %r, ext= %r, path= %r, video= %r, description= %r, size= %r, archive= %r, realtitle= %r, startmark= %r)' % (c, filename, ext, path, video, description, size, archive, realtitle, startmark))
    now = datetime.now()
    nowTS = int(time.mktime(now.timetuple()))
    nowTSold =    nowTS - 31536000    ### 365 * 24 * 60 * 60  now-timedelta(days=365)
    now = parseDate(datetime.now()) 
    filename = filename.strip()
    if filename != '':
        try:
            c.execute("SELECT * FROM files WHERE filename=? AND ext=? AND path=? AND archive=?", [filename,ext,path,archive]) 
            channels = c.fetchall()
            if len(channels) > 0:
                for chan in channels:
                    c.execute("INSERT OR REPLACE INTO files(filename, ext, path, video, description,  size, archive, updated, created, updatedHuman, command, options, realtitle, startmark) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [filename, ext, path, video, description, size, archive, nowTS, chan[8], humantime(nowTS), chan[10], chan[11], realtitle, startmark])
            else:
                c.execute("INSERT OR REPLACE INTO files(filename, ext, path, video, description, size, archive, updated, created, updatedHuman, command, options, realtitle, startmark) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [filename, ext, path, video, description, size, archive, nowTS, nowTS, humantime(nowTS),'','',realtitle, startmark])    
        except Exception as e:
            log('addFile ERROR %r' % e)
            pass

def addTVSeries(c, name, episodes):
    ###name = name.replace('+','xXx')   ### 2019-03-16 + seems to fuck up SQlite
    log('addTVSeries(c= %r, name= %r, episodes= %r)' % (c, name, episodes))
    now = datetime.now()
    nowTS = int(time.mktime(now.timetuple()))
    nowTSold =    nowTS - 31536000    ### 365 * 24 * 60 * 60  now-timedelta(days=365)
    now = parseDate(datetime.now()) 
    name = name.strip()
    if name != '':
        try:
            c.execute("SELECT * FROM tvseries WHERE name=?", [name]) 
            channels = c.fetchall()
            if len(channels) > 0:
                for chan in channels:
                    c.execute("INSERT OR REPLACE INTO tvseries(name, episodes, updated, created) VALUES(?, ?, ?, ?)", [name, episodes, nowTS, chan[3]])
            else:
                c.execute("INSERT OR REPLACE INTO tvseries(name, episodes, updated, created) VALUES(?, ?, ?, ?)", [name, episodes, nowTS, nowTS]) 
        except Exception as e:
            log('addTVSeries ERROR %r' % e)
            pass
       
def addChannel(name,url,iconimage,cat,origin,visible=1,weight=0,epg_channel='',description=''):
    try:
        weight = utils.SeriesEpisodeVOD(name)[0]  ###2021-01-17
        epg_channel = epg_channel.lower()
        log('0err addChannel name= %r,url= %r,iconimage= %r,cat= %r,origin= %r, weight= %r, epg_channel= %r' % (name,url,iconimage,cat,origin,weight,epg_channel))
        ### add to channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER)
        now = datetime.now()
        log('01 addChannel name= %r' % name)
        nowTS = int(time.mktime(now.timetuple()))
        log('02 addChannel name= %r' % name)
        nowTSold =    nowTS - 31536000    ### 365 * 24 * 60 * 60  
        log('03 addChannel name= %r' % name)
        now-timedelta(days=365)
        log('04 addChannel name= %r' % name)
        now = parseDate(datetime.now())  ### 2017-09-30
        log('05 addChannel name= %r' % name)
        cat = cat.strip()
        log('06 addChannel name= %r' % name)
        name = name.strip()
        log('1 addChannel name= %r' % name)
        if name != '':
            log('2 addChannel name= %r' % name)
            try:
                log('3 addChannel name= %r' % name)
                conn = getConnection()
                c = conn.cursor()
                c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])  ### 2017-08-26
                ###c.execute("SELECT * FROM channels WHERE id=?", [cat])
                channels = c.fetchall()
                log('4 addChannel name= %r' % name)
                logarray('5 addChannel channels',channels,nelements=3)
                
                if len(channels) > 0:
                    for chan in channels:
                        log('6 addChannel chan[0]= %r, chan[1]= %r, len(chan)= %r, weight= %r' % (chan[0], chan[1],len(chan),weight))
                        ChannelEpg = getChannelEpgid(c,cat)   ### 2020-04-13
                        if ChannelEpg == '':
                            epg_channel = chan[9].lower()
                        else:
                            epg_channel = ChannelEpg.lower()
                        if description in chan[10]:   ### 2018-07-20
                            log('7 addChannel c.execute("INSERT OR REPLACE INTO channels')
                            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, name, iconimage, url, origin, chan[5], weight, chan[7], chan[8], epg_channel, chan[10], nowTS, chan[12]]) ### 2019-02-11 test
                            log('8 addChannel c.execute("INSERT OR REPLACE INTO channels')
                        else:
                            log('9 addChannel c.execute("INSERT OR REPLACE INTO channels')
                            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, name, iconimage, url, origin, chan[5], weight, chan[7], chan[8], epg_channel, chan[10]+'\n' + description, nowTS, chan[12]])
                            log('10 addChannel c.execute("INSERT OR REPLACE INTO channels')
                else:
                    log('11 addChannel c.execute("INSERT OR REPLACE INTO channels')
                    c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, name, iconimage, url, origin, visible, weight, 'False', 0,epg_channel, description,nowTS,nowTSold]) 
                    log('12 addChannel c.execute("INSERT OR REPLACE INTO channels')                    
                ###c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite) VALUES(?, ?, ?, ?, ?, ?, ?)", [cat, name, iconimage, url, origin, 'True', '0'])
            
                log('13 addChannel conn.commit()')
                conn.commit()
            except Exception as e:
                pass
                log('14 addChannel 1 ERROR: %r' % e)
            c.close()
    except Exception as e:
        pass
        log('15 addChannel ERROR: %r' % e)

### recordings.addEPGChannel(c,stream_id,name,url,stream_icon,epg_channel_id,EPGgenerator)  
def addEPGChannel(c,cid,name,url,iconimage,cat,origin,visible=1,weight=0,epg_channel='',description=''):
    epg_channel = epg_channel.lower()
    ### add to channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER)
    weight = utils.SeriesEpisodeVOD(name)[0]  ###2021-01-17
    log('0err addEPGChannel name= %r,url= %r,iconimage= %r,cat= %r,origin= %r, weight= %r, epg_channel= %r' % (name,url,iconimage,cat,origin,weight,epg_channel))
    now = datetime.now()
    nowTS = int(time.mktime(now.timetuple()))
    nowTSold =    nowTS - 31536000    ### 365 * 24 * 60 * 60  now-timedelta(days=365)
    if cid == '' or cid == None:
        return
    try:
        cid = cid.strip()
    except:
        pass
    try:
        if ',' in name:
            log('name.replace(, with ;).strip() name= %r'% (name))
        name = name.replace(',',';').strip()   ### 2018-07-18
    except Exception as e:
        pass
        log('name.replace(, with ¤).strip() name= %r, Error: %r'% (name,e))
    ###conn = getConnection()
    ###c = conn.cursor()
    try:
        ###c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, description) VALUES(?, ?, ?, ?, ?, ?)", [cid, name, iconimage, url, origin, cat])
        c.execute("SELECT * FROM channels WHERE id=?", [cid])
        channels = c.fetchall()
        ###utils.logdevarray(module+'-addChannel',channels)
        if len(channels) > 0:
            for chan in channels:
                ###utils.logdevarray(module+'-addChannel',chan)
                if chan[9] != '':
                    epg_channel = chan[9].lower()   ### 2020-04-01 Save EPG channel in lower
                c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cid, name, iconimage, url, origin, chan[5], weight, chan[7], chan[8], epg_channel, description, nowTS, chan[12]])  ### 2018-02-13 description <== chan[10]
        else:
            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cid, name, iconimage, url, origin, visible, weight, 'False', 0, epg_channel, description, nowTS, nowTSold])
    except Exception as e:
        pass
        ###ADDON.setSetting('KeyErrorStop',repr(e))
        log('ChannelId= %r' % cid)
        log( 'c.execute("INSERT OR REPLACE INTO channels(id= %r, title= %r, logo= %r, stream_url= %r, source= %r, description= %r, now= %r) failed! \nERROR= %r' % (cid, name, iconimage, url, origin, description, now, e))
    ###conn.commit()
    ###c.close()

###c.execute("CREATE TABLE IF NOT EXISTS programs(channel TEXT, title TEXT, sub_title TEXT, start_date TIMESTAMP, end_date TIMESTAMP, description TEXT, categories TEXT, image_large TEXT, image_small TEXT, season TEXT, episode TEXT, is_movie TEXT, language TEXT, source TEXT, updates_id INTEGER, UNIQUE (channel, start_date, end_date))")    

def addEPGProgram(c, prog, channel, title, sub_title, start_date, end_date, description='', categories='', image_large='', image_small='', season= '', episode='', is_movie='', language='', source=''):
    ### add to channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER)
    channel = channel.strip().lower()  ### 2020-04-01
    ###title = title.strip()
    ###conn = getConnection()
    ###c = conn.cursor()
    now = datetime.now()
    nowTS = int(time.mktime(now.timetuple()))
    updates_id = nowTS
    try:
        c.execute("INSERT OR REPLACE INTO programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source, updates_id) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source, updates_id])
    except Exception as e:
        pass
        ###ADDON.setSetting('KeyErrorStop',repr(e))
        log('Programdict= %r' % prog)
        log( 'c.execute("INSERT OR REPLACE INTO programs(channel= %r, title= %r, sub_title= %r, start_date= %r, end_date= %r, description= %r, categories= %r, image_large= %r, image_small= %r, season= %r, episode= %r, is_movie= %r, language= %r, source= %r) failed! \nERROR= %r' % (channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source, e))
    
    ###conn.commit()
    ###c.close()
    
def getEPGPrograms(channel):
    ###log('getEPGPrograms: channel= %r' % channel)
    channel = channel.strip().lower()  ### 2020-04-01
    conn = getConnection()
    c = conn.cursor()
    ###programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
    try:
        ###c.execute("SELECT * FROM programs WHERE channel=?", [channel])
        ###c.execute("SELECT DISTINCT title, description, source, start_date, end_date  FROM programs WHERE channel=? COLLATE NOCASE", [channel])
        c.execute("SELECT DISTINCT title, description, source, start_date, end_date  FROM programs WHERE channel=? ", [channel]) ### 2018-12-07
        programs = c.fetchall()
        programs = sorted(programs, key=itemgetter('start_date')) ### Sort by startdate
    except Exception as e:
        pass
        log( 'c.execute(SELECT DISTINCT title, description, start_date, end_date, source FROM programs WHERE channel=?, [channel]) failed! \nERROR= %r' % e)
        programs = []
    c.close()
    ###utils.logdevarray(module+' TEST',programs)
    return programs

def getEPGProgramsNow(channel):
    ###now= datetime.today()
    ###nowplus = now + timedelta(hours = 2)
    channel = channel.strip().lower()  ### 2020-04-01
    now = datetime.now()
    nowTS = int(time.mktime(now.timetuple()))
    nowTSplus =    nowTS + 7200    ### 2 * 60 * 60  now-timedelta(hours=2)
    ###log('now= datetime.today(%r) nowplus = %r' % (nowTS,nowTSplus))
    conn = getConnection()
    c = conn.cursor()
    ###programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
    ###c.execute("SELECT * FROM programs WHERE channel=?", [channel])
    try:
        channel = channel.replace(' (R)','').replace(' (r)','')   ### 2017-07-27
        c.execute("SELECT DISTINCT title, description, source, start_date, end_date  FROM programs WHERE channel=? and start_date < ? and end_date > ? COLLATE NOCASE", [channel,nowTSplus,nowTS])
        ###c.execute("SELECT DISTINCT title, description, source, start_date, end_date  FROM programs WHERE channel=? and start_date < ? and end_date > ? COLLATE NOCASE", [channel,nowplus,now])
        programs = c.fetchall()
        programs = sorted(programs, key=itemgetter('start_date')) ### Sort by startdate
    except Exception as e:
        pass
        log( 'c.execute(SELECT DISTINCT title, description, start_date, end_date, source FROM programs WHERE channel=?and start_date < ? and end_date > ? , [channel]) failed! \nERROR= %r' % e)
        programs = []
    c.close()
    return programs

def delEPGProgram(channel, start_date, end_date):
    channel = channel.strip().lower()  ### 2020-04-01
    log( 'delEPGProgram(channel= %r, start_date= %r, end_date= %r)'% (channel, ht(start_date), ht(end_date)))
    success = False
    conn = getConnection()
    c = conn.cursor()
    ###programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
    c.execute("SELECT * FROM programs WHERE channel=? AND start_date=? AND end_date=?", [channel, start_date, end_date])
    favorites = c.fetchall()
    log( 'delEPGProgram favorites= %r, len(favorites)= %r' % (favorites, len(favorites)))
    if len(favorites) >= 1:   ### 2019-09-16 == to >=
        c.execute("DELETE FROM programs WHERE channel=? AND start_date=? AND end_date=?", [channel, start_date, end_date])
        conn.commit()
        log( 'delEPGProgram Succeded')
        success = True
    c.close()
    return success

    
def delOldEPGPrograms():
    log( 'Start to delete old programs, channels and TV series - cutoffdate')
    conn = getConnection()
    c = conn.cursor()
    ###programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
    ###c.execute("SELECT * FROM programs WHERE channel=?", [channel])
    cutoffdate = 'Unknown'
    try:
        tv_archive_duration = ADDON.getSetting('tv_archive_duration')
        if tv_archive_duration == '':
            tv_archive_duration = '2'
            ADDON.setSetting('tv_archive_duration',tv_archive_duration)
        daystoremove = int(tv_archive_duration)
        if daystoremove <= 1 :
            daystoremove = 2
        cutoffdate = (datetime.today() - timedelta(days = daystoremove + 1)).timetuple()
        log('Programs: cutoffdate(tuple)= %r' % cutoffdate)
    except Exception as e:
        pass
        log( 'c.execute(DELETE FROM programs, programsForHumans or channels WHERE end_date or updated<? , [cutoffdate]= %r) failed in beginning! \nERROR= %r' % (cutoffdate,e))
    try:
        ###time_tuple = dt_obj.timetuple()
        ###timestamp = time.mktime(time_tuple)
        ###datetime.fromtimestamp(timestamp)
        cutoffdate = int(time.mktime(cutoffdate))
        log('Programs: cutoffdate(timestamp)= %r' % cutoffdate)
        ###c4.execute("DELETE FROM recordings_adc WHERE alarmname=? and end=?",  [alarmname,endDate])
        c.execute("DELETE FROM programs WHERE end_date<? ", [cutoffdate])
    except Exception as e:
        pass
        log( 'c.execute(DELETE FROM programs  WHERE end_date<? , [cutoffdate]= %r) failed! \nERROR= %r' % (cutoffdate,e))
    try:
        cutoffdate = (datetime.today() - timedelta(days = daystoremove + 10)).strftime("%Y-%m-%d %H:%M:%S")
        log('recordings_adc: cutoffdate= %r' % cutoffdate)
        c.execute("DELETE FROM recordings_adc WHERE end<? and not name LIKE '%Recursive:%' ", [cutoffdate])  ### 2019-01-21 Only delete recursive manually
    except Exception as e:
        pass
        log( 'c.execute(DELETE FROM recordings_adc WHERE end<? , [cutoffdate]= %r) failed! \nERROR= %r' % (cutoffdate,e))
    try:
        c.execute("DELETE FROM programsForHumans WHERE end_date<? ", [cutoffdate])   ### 2017-09-18
    except Exception as e:
        pass
        log( 'c.execute(DELETE FROM programsForHumans WHERE end_date <? , [cutoffdate]= %r) failed! \nERROR= %r' % (cutoffdate,e))
    try:
        cutoffdate = (datetime.today() - timedelta(days = 2)).timetuple()
        log('Channels: cutoffdate(tuple)= %r' % cutoffdate)
        cutoffdate = int(time.mktime(cutoffdate))
        log('Channels: cutoffdate(timestamp)= %r' % cutoffdate)
        ###c4.execute("DELETE FROM recordings_adc WHERE alarmname=? and end=?",  [alarmname,endDate])
        c.execute("DELETE FROM channels WHERE updated<? ", [cutoffdate])
        c.execute("DELETE FROM tvseries WHERE updated<? ", [cutoffdate])
    except Exception as e:
        pass
        log( 'c.execute(DELETE FROM channels WHERE updated<? , [cutoffdate]= %r) failed! \nERROR= %r' % (cutoffdate,e))
    conn.commit()
    c.close()
    return

def delNewEPGPrograms():   ### If to many programs have changed - update full afterwards
    log( 'Start to delete new programs - cutoffdate')
    conn = getConnection()
    c = conn.cursor()
    ###programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
    ###c.execute("SELECT * FROM programs WHERE channel=?", [channel])
    try:
        ###time_tuple = dt_obj.timetuple()
        ###timestamp = time.mktime(time_tuple)
        ###datetime.fromtimestamp(timestamp)
        cutoffdate = datetime.today().timetuple()   ### now
        log('Programs: cutoffdate(tuple)= %r' % cutoffdate)
        cutoffdate = time.mktime(cutoffdate)
        log('Programs: cutoffdate(timestamp)= %r' % cutoffdate)
        ###c4.execute("DELETE FROM recordings_adc WHERE alarmname=? and end=?",  [alarmname,endDate])
        c.execute("DELETE FROM programs WHERE end_date>? ", [cutoffdate])
    except Exception as e:
        pass
        log( 'c.execute(DELETE FROM programs WHERE start_date or updated<? , [cutoffdate]= %r) failed! \nERROR= %r' % (cutoffdate,e))
    conn.commit()
    c.close()
    return

def RestoreFavorites(url):
    utils.notificationforced('[COLOR green]Restoring Favorites[/COLOR]',time=100000)
    log('Restoring Favorites url= ' + repr(url))
    restorecount = RestoreOldFavorites(url)
    utils.notificationforced('[COLOR green]Restoring Favorites Finished![/COLOR] %s records restored' % repr(restorecount))
    
def RestoreRecursiveChannels(url):
    utils.notificationforced('[COLOR green]Restoring Recursive Channels[/COLOR]',time=100000)
    log('Restoring Recursive Channels url= ' + repr(url))
    restorecount = RestoreOldRecursiveChannels(url)
    utils.notificationforced('[COLOR green]Restoring Recursive Channels Finished![/COLOR] %s records restored' % repr(restorecount))
    
def RestoreChannels(url):
    ###try:
        utils.notificationforced('[COLOR green]Restoring Channels[/COLOR]',time=100000)
        log('Restoring Channels url= ' + repr(url))
        restorecount = RestoreOldChannels(url)
        utils.notificationforced('[COLOR green]Restoring Channels Finished![/COLOR] %s records restored' % repr(restorecount))
    ###except Exception as  e:
    ### pass
        
def RestoreEPG(url):
    ###try:
        utils.notificationforced('[COLOR green]Restoring EPG[/COLOR]',time=100000)
        log('Restoring EPG url= ' + repr(url))
        restorecount = RestoreOldEPG(url)
        utils.notificationforced('[COLOR green]Restoring EPG Finished![/COLOR] %s records restored' % repr(restorecount))
    ###except Exception as  e:
    ### pass
    
def delAllChannels():   ### If user have changed - update full afterwards
    log( 'Start to delete all channels')
    conn = getConnection()
    c = conn.cursor()
    ###programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
    ###c.execute("SELECT * FROM programs WHERE channel=?", [channel])
    try:
        c.execute("DELETE FROM channels")
    except Exception as e:
        pass
        log( 'c.execute(DELETE FROM channels) failed! \nERROR= %r' % (e))
    conn.commit()
    c.close()
    return

def delAllPlannedPrograms():   ### If recursive have made too many recordings - Stop all recordings and clear parts of database but not the recursive recordings
    log( 'Start to delete all recordings')
    conn = getConnection()
    c = conn.cursor()
    ###programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
    ###c.execute("SELECT * FROM programs WHERE channel=?", [channel])
    try:
        c.execute("SELECT DISTINCT alarmname FROM recordings_adc WHERE not name LIKE '%Recursive:%'")
        favorites = c.fetchall()
        log( 'len(favorites)= %r' % len(favorites))
        for nameAlarm in favorites:
            try:
                log( 'nameAlarm= %r' % (nameAlarm))
                xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
            except Exception as e:
                pass
                log( 'xbmc.executebuiltin(CancelAlarm(nameAlarm,True)) failed! \nERROR= %r' % (e))
        c.execute("DELETE FROM recordings_adc WHERE not name LIKE '%Recursive:%'")
    except Exception as e:
        pass
        log( 'c.execute(DELETE FROM recordings_adc) failed! \nERROR= %r' % (e))
    conn.commit()
    c.close()
    return

def delAllPlannedProgramsInclusiveRecursive():   ### If recursive have made too many recordings - Stop all recordings and clear parts of database
    log( 'Start to delete all recordings')
    conn = getConnection()
    c = conn.cursor()
    ###programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
    ###c.execute("SELECT * FROM programs WHERE channel=?", [channel])
    try:
        c.execute("SELECT DISTINCT alarmname FROM recordings_adc")
        favorites = c.fetchall()
        for nameAlarm in favorites:
            try:
                xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
            except:
                pass
        c.execute("DELETE FROM recordings_adc")
    except Exception as e:
        pass
        log( 'c.execute(DELETE FROM recordings_adc) failed! \nERROR= %r' % (e))
    conn.commit()
    c.close()
    return

def delAllProgramsForHumans():   ### Programs for Humans not used any more
    log( 'Start to delete all Programs for Humans')
    conn = getConnection()
    c = conn.cursor()
    try:
        c.execute("DELETE FROM programsForHumans")
    except Exception as e:
        pass
        log( 'c.execute(DELETE FROM programsForHumans) failed! \nERROR= %r' % (e))
    conn.commit()
    c.close()
    return
    
def setChannelCatchup(c,cat,catchup):
    
    if cat == '' or cat == None:
        return
    try:
        cat = cat.strip()
    except:
        pass
    ###conn = getConnection()
    ###c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin]) 
    favorites = c.fetchall()
    ###utils.logdevarray(module+'-setChannelCatchup',favorites)
    for chan in favorites:
        c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], catchup, chan[9], chan[10], chan[11], chan[12]])
    ###conn.commit()
    ###c.close()

def getChannelDescription(cat):
    
    if cat == '' or cat == None:
        return ''
    try:
        cat = cat.strip()
    except:
        pass
    conn = getConnection()
    c = conn.cursor()
    c.execute("SELECT DISTINCT description FROM channels WHERE id=? and source=?", [cat,origin]) 
    favorites = c.fetchall()
    des = ''
    for chan in favorites:
        if chan[0] != None:
            des += chan[0]
    c.close()
    return des

def setChannelDescription(cat,description):
    log('setChannelDescription cat= %r, description= %r' % (cat,description))
    if cat == '' or cat == None:
        return
    try:
        cat = cat.strip()
    except:
        pass
    conn = getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin]) 
    favorites = c.fetchall()
    for chan in favorites:
        try:
            log('setChannelDescription id= %r, title= %r' % (cat, chan[1]))
        except Exception as e:
            pass
            log('setChannelDescription id= %r, ERROR: %r' % (cat, e))
        c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9], description, chan[11], chan[12]])
    conn.commit()
    c.close()

def setChannelAdded(c,cat,added):
    if cat == '' or cat == None:
        return
    try:
        cat = cat.strip()
    except:
        pass    
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin]) 
    favorites = c.fetchall()
    for chan in favorites:
        c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9], chan[10], chan[11], added])

def getChannelEpgid(c,cat):
    if cat == '' or cat == None:
        return
    try:
        cat = cat.strip()
    except:
        pass    
    c.execute("SELECT DISTINCT epg_channel FROM channels WHERE id=? and source=?", [cat,origin]) 
    favorites = c.fetchall()
    if len(favorites) > 0:
        try:
            fav = favorites[0][0]
        except Exception as e:
            pass
            log( 'c.execute(SELECT DISTINCT epg_channel FROM channels WHERE id=%r, [cat]) failed! \nERROR= %r' % (cat,e))
            fav = ''
    else:
        fav = ''
    log('getChannelEpgid(c,cat= %r)-->Epgid= %r' % (cat,fav))
    return fav.lower().strip()
    
def setChannelEpgid(c,cat,fav):
    if cat == '' or cat == None or fav == None:
        return
    try:
        cat = cat.strip()
    except:
        pass    
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin]) 
    favorites = c.fetchall()
    fav = fav.lower().strip()
    for chan in favorites:
        if fav != None : 
            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], fav, chan[10], chan[11], chan[12]]) 
    log('setChannelEpgid(c,cat= %r)-->Epgid= %r' % (cat,fav))
    
    c.execute("SELECT * FROM channelsRecursive WHERE id=? and source=?", [cat,origin]) 
    favorites = c.fetchall()
    for chan in favorites:
        if fav != None : 
            c.execute("INSERT OR REPLACE INTO channelsRecursive(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], fav, chan[10], chan[11], chan[12]]) 
        
def getChannelFav(c,cat):
    
    if cat == '' or cat == None:
        return
    try:
        cat = cat.strip()
    except:
        pass    
    c.execute("SELECT DISTINCT favorite FROM channels WHERE id=? and source=?", [cat,origin])  ### 2017-09-28
    favorites = c.fetchall()
    if len(favorites) > 0:
        try:
            fav = favorites[0][0]
            ###if fav == 'false':
            ###    fav = 'False'
        except Exception as e:
            pass
            log( 'c.execute(SELECT DISTINCT favorite FROM channels WHERE id=%r, [cat]) failed! \nERROR= %r' % (cat,e))
            fav = 'False'
    else:
        fav = 'False'
    return fav
    
def setChannelFav(c,cat,fav):
    if cat == '' or cat == None or fav == '' or fav == None:
        return
    try:
        cat = cat.strip()
    except:
        pass    
    ###c.execute("SELECT * FROM channels WHERE id=?", [cat])   ### 2018-12-07
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])  ### 2017-08-26
    favorites = c.fetchall()
    for chan in favorites:
        if fav != '' and fav != None and fav.lower() != 'false': 
            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], fav, chan[8], chan[9], chan[10], chan[11], chan[12]])
        else:
            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], 'False', chan[8], chan[9], chan[10], chan[11], chan[12]])
    
def addChannelFav(cat,fav):
    log(' addChannelFav cat= %r' % (cat))
    if cat == '' or cat == None:
        return
    try:
        cat = cat.strip()
    except:
        pass
    conn = getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])
    ###c.execute("SELECT * FROM channels WHERE id=? ", [cat]) ### 2018-12-07
    favorites = c.fetchall()
    for chan in favorites:
        c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], fav, chan[8], chan[9], chan[10], chan[11], chan[12]])
        utils.notificationforced('Favorite added: %s' % chan[1])
    conn.commit()
    c.close()

def delChannelFav(cat):
    log('-delChannelFav cat= %r' % (cat))
    cat = cat.strip()
    conn = getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])
    ###c.execute("SELECT * FROM channels WHERE id=? ", [cat])   ### 2018-12-07
    favorites = c.fetchall()
    for chan in favorites:
        log('-delChannelFav 1 cat= %r' % (cat))
        c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], 'False', chan[8], chan[9], chan[10], chan[11], chan[12]])
    conn.commit()
    c.close()

def setChannelHide(cat):
    cat = cat.strip()
    conn = getConnection()
    c = conn.cursor()
    ###c.execute("SELECT * FROM channels WHERE id=?", [cat])
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])
    favorites = c.fetchall()
    for chan in favorites:
        c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], 0, chan[6], chan[7], chan[8], chan[9], chan[10], chan[11], chan[12]])
        utils.notificationforced('Channel Hidden: %s' % chan[1])
    conn.commit()
    c.close()
    
def delChannelHide(cat):
    cat = cat.strip()
    log('delChannelHide(cat= %r)' % cat)
    conn = getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])
    favorites = c.fetchall()
    log('delChannelHide len(favorites)= %r' % len(favorites))
    for chan in favorites:
        c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], 1, chan[6], chan[7], chan[8], chan[9], chan[10], chan[11], chan[12]])
    ###log('delChannelHide-1 len(favorites)= %r' % len(favorites))
    conn.commit()
    c.close()

def setChannelRecursive(cat):
    cat = cat.strip()
    conn = getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])
    favorites = c.fetchall()
    for chan in favorites:
        if not chan[9] is None:
            if not ' (R)' in chan[9]:
                recursive = chan[9] + ' (R)'
            else:
                recursive = chan[9]
            ### Only mark as recursive channel if epg_channel assigned
            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], recursive.replace(' (R)',''), chan[10], chan[11], chan[12]])
            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], ADDONid, chan[5], chan[6], 'False', 0, chan[9].replace(' (R)',''), '', '', ''])  ### Play channel Source = ADDONid
            c.execute("INSERT OR REPLACE INTO channelsRecursive(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], 'False', 0, chan[9].replace(' (R)',''), '', '', ''])  ### Play channelRecursive
            utils.notificationforced('Recursive added: %s' % chan[1])

    conn.commit()
    c.close()
    
def delChannelRecursive(cat):
    cat = cat.strip()
    log('delChannelRecursive(cat= %r)' % cat)
    conn = getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])
    favorites = c.fetchall()
    for chan in favorites:
        c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], 1, chan[6], chan[7], chan[8], chan[9].replace(' (R)',''), chan[10], chan[11], chan[12]])
        c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], ADDONid, chan[5], chan[6], 'False', 0, chan[9].replace(' (R)',''), '', '', ''])  ### Play channel Source = ADDONid
        c.execute("INSERT OR REPLACE INTO channelsRecursive(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], 0, chan[6], chan[7], chan[8], chan[9].replace(' (R)',''), chan[10], chan[11], chan[12]])
    ###log('delChannelHide-1 len(favorites)= %r' % len(favorites))
    conn.commit()
    c.close()
    
def isChannelRecursive(cat):
    log('isChannelRecursive(cat= %r)' % cat)
    cat = cat.strip()
    conn = getConnection()
    c = conn.cursor()
    favorites =  []
    try:
        c.execute("SELECT visible FROM channelsRecursive WHERE id=? and source=?", [cat,origin])
        favorites = c.fetchall()
        if repr(favorites[0][0]) == '1':
            result = True
        else:
            result = False
    except Exception as e:
        pass
        log('isChannelRecursive(Error= %r)' % e)
        result = False
    
    c.close()
    log('isChannelRecursive(result= %r)' % result)
    return result
  
def isChannelVisible(cat):
    ###log('isChannelVisible(cat=%r)' % cat)
    cat = cat.strip()
    conn = getConnection()
    c = conn.cursor()
    try:
        c.execute("SELECT DISTINCT visible FROM channels WHERE id=? and source=?", [cat,origin])
        favorites = c.fetchall()
    except:
        pass
        favorites =  []
    result = False
    if len(favorites) > 0:
        result = favorites[0][0]
        ###log('result= %r' % result)
        if result == 1:
            result = True
        ###log('result1= %r' % result)
    c.close()
    return result
    
def getAllChannels():
    log('err getAllChannels()')
    c = getConnection().cursor()
    try:
        ### channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER)
        c.execute("SELECT * FROM channels")
        ###c.execute("SELECT * FROM channels WHERE source=?",[origin])
        channels = c.fetchall()
    except:
        pass
        channels =  []
    ###channels = sorted(channels, key=itemgetter('title'))
    channels = sorted(channels,key=lambda i:i[1].lower())  ### Sort ignore case coloum 1
    
    log('err getAllChannels() - len= %r' % len(channels))
    c.close()
    return channels

def getAllChannelSources():
    log('err getAllChannelSources')
    c = getConnection().cursor()
    try:
        ### channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER)
        c.execute("SELECT DISTINCT source FROM channels")
        channels = c.fetchall()
        log('err 0 getAllChannelSources - len= %r' % len(channels))
    except Exception as e:
        pass
        log('getAllChannelSources ERROR: %r' % e)
        channels =  []
    ###channels = sorted(channels, key=itemgetter('title'))
    log('err 1 getAllChannelSources - len= %r' % len(channels))
    channels = sorted(channels,key=lambda i:i[0].lower())  ### Sort ignore case coloum 1
    ###channels = sorted(channels)
    log('err 2 getAllChannelSources - len= %r' % len(channels))
    log('err channels= %r' % channels)
    c.close()
    return channels 
    
def getAllChannelsList():
    c = getConnection().cursor()
    try:
        ### channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER)
        c.execute("SELECT DISTINCT id, title, stream_url, epg_channel, logo FROM channels")
        channels = c.fetchall()
    except:
        pass
        channels =  []
    ###channels = sorted(channels, key=itemgetter('title'))
    channels = sorted(channels,key=lambda i:i[1].lower())  ### Sort ignore case coloum 1
    log('getAllChannelsList() - len= %r' % len(channels))
    return channels

def getAllChannelsList0(epg_channel):
    c = getConnection().cursor()
    try:
        ### channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER)
        c.execute("SELECT DISTINCT id,title,epg_channel FROM channels WHERE epg_channel LIKE ? and source=? COLLATE NOCASE",['%' + epg_channel + '%',origin])
        channels = c.fetchall()
        c.execute("SELECT DISTINCT id,title,epg_channel FROM channels WHERE id LIKE ? and source=? COLLATE NOCASE",['%' + epg_channel + '%',origin])
        channelsid = c.fetchall()
    except:
        pass
        channels =  []
        channelsid = []
    channelsall = []    
    for chan in channels:
        channelsall.append(chan)
    for chan in channelsid:
        channelsall.append(chan)
    channels = channelsall
    ###channels = sorted(channels, key=itemgetter('title'))
    channels = sorted(channels,key=lambda i:i[1].lower())  ### Sort ignore case coloum 1
    log('getAllChannelsList() - len= %r' % len(channels))
    return channels

def urlFromCat(cat):
    c = getConnection().cursor()
    try:
        c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])
        urls = c.fetchall()
        ###log('urls= %s --> cat= %s' %(repr(urls),cat))
    except:
        pass
        urls = ''
    if len(urls) > 0:
        url = urls[0][3]
    else:
        url = ''
        ###utils.notification( 'NOT FOUND: channel= %s' % (cat))
    c.close()
    ###log('cat= %s --> url= %s' %(cat,url))
    return url

def titleFromCat(cat):
    c = getConnection().cursor()
    try:
        c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])
        urls = c.fetchall()
        ###log('urls= %s --> cat= %s' %(repr(urls),cat))
    except:
        pass
        urls = ''
    if len(urls) > 0:
        url = urls[0][1]  # Return title
    else:
        url = ''
        ###utils.notification( 'NOT FOUND: channel= %s' % (cat))
    c.close()
    ###log('cat= %s --> url= %s' %(cat,url))
    return url
    
def directprograms(cat):
    ###Direct programs always have 'DIR' as first characters of cat
    ### Channel name has (D) in the end to be Direct
    ###channelname = ChannelName(cat)
    ###log('directprograms(cat= %r) channelname= %r, last 4= %r' % (cat, channelname,channelname[-4:]))
    ###if not ' (D' in channelname[-5:]:
    if cat != None and cat[:3] != 'DIR':
        log('Not direct program cat= %r' % cat)
        return ''
    url = urlFromCat(cat)
    log('directprograms(cat= %r) url= %r' % (cat, url))
    return url

def catFromEPGcat(EPGcat):
    c = getConnection().cursor()
    try:
        c.execute("SELECT * FROM channelsRecursive WHERE epg_channel=?", [EPGcat])   ### channels == channelsRecursive
        cats = c.fetchall()
        ###log('cats= %r <-- EPGcat= %r' %(cats,EPGcat))
        if len(cats) > 0:
            cat = cats[0][0]
        else:
            c.execute("SELECT * FROM channelsRecursive WHERE id=?", [EPGcat])   ### channels == channelsRecursive
            cats = c.fetchall()
            if len(cats) > 0:
                cat = cats[0][0]
            else:
                ###cat = EPGcat
                cat = ''   ### 2018-12-07
            log('cat= %r <-- EPGcat= %r' %(cat,EPGcat))
    except:
        pass
        ###cat = EPGcat
        cat = ''   ### 2018-12-07
    c.close()
    return cat

def catFromUrl(url):
    c = getConnection().cursor()
    try:
        c.execute("SELECT * FROM channels WHERE stream_url=?", [url])
        cats = c.fetchall()
        ###log('cats= %r <-- url= %r' %(cats,url))
        if len(cats) > 0:
            cat = cats[0][0]
        else:
            if ':25461' in url:
                url  = url.replace(':25461',':8080')
                c.execute("SELECT * FROM channels WHERE stream_url=?", [url])
                cats = c.fetchall()
                ###log('cats= %r <-- url= %r' %(cats,url))
                if len(cats) > 0:
                    cat = cats[0][0]
                else:
                    cat = ''
            else:
                cat = ''
            ###utils.notification( 'NOT FOUND: channel= %s' % (url))
    except:
        pass
        cat = ''
    c.close()
    ###log('cat= %s <-- url= %s' %(cat,url))
    ###2017-06-12 19:41:13 default.py: catThis = recordings.catFromUrl(StreamURL)= '' 
    ###2017-06-12 19:41:13 default.py: 0 addDir(name= FORMULA 1 (2017) - CANADIAN GRAN PRIX RACE (1080),url= http://roq-tv.net:25461/movie/<username>/<password>/3518.mp4,mode= 200,iconimage= ,cat= ,date= ,description= IMDB_ID: 
    if not cat == '':
        return cat
    else:
        try:
            cat=url.split('live/')[1].split('/')[0]
        except:
            pass
            try:
                cat=url.split('tv2danmark/')[1].split('/')[0]
            except:
                pass
                try:
                    cat=url.split('i/')[1].split('/')[0]
                except:
                    pass
                    try:
                        cat=url.split('.')[-2].split('/')[-1]
                    except:
                        pass
                        cat=''
                        log('catFromUrl(url) FAILED: url= %r' % url)
    return cat
    
def IconFromCat(cat):
    catin = cat
    url = ''
    if cat!= '#':
        c = getConnection().cursor()
        try:
            ### c.execute("INSERT OR REPLACE INTO channelsRecursive(0id, 1title, 2logo, 3stream_url, 4source, 5visible, 6weight, 7favorite, 8catchup, 9epg_channel, 10description, 11updated, 12created)
            c.execute("SELECT * FROM channels WHERE id=? and source=? AND visible=1", [cat.strip(),origin])
            urls = c.fetchall()
            if len(urls) > 0:
                cat = urls[0][9].lower()   ### use epg_channel
            if cat == '':
                url = urls[0][2]           ### use channel icon
            else:
                log('err cat= %r, url= %r' % (cat,url))
                url = ''
                ###if not 'http' in cat and not cat == '#':
                ###    utils.notification( '1. NOT FOUND: channel= %s' % (cat))
            if url == '':
                cat = urls[0][9].lower()   ### use epg_channel
        except:
            pass
            url = ''
        c.close()
    
    if url == '':
        if cat == '#':
            cat= 'vod4'
        log('IconFromCat cat= %r' % cat)
        if cat == '':
            cat = 'tv1'
        if cat == 'tv3max.dk':
            cat = 'tv3max2.dk'
        url = 'https://raw.githubusercontent.com/krogsbell/Logos/master/'+str(cat)+'.png'
    log('IconFromCat catin= %r, url= %r' % (catin,url))
    return url
    

def ChannelName(cat):
    c = getConnection().cursor()
    try:
        #xbmc.log('recordings.py: ChannelName cat= %s' % (repr(cat)))
        ###c = getIconConnection().cursor()
        #c.execute("SELECT * FROM channels WHERE title=? COLLATE NOCASE", [title.strip()])
        ###c.execute("SELECT * FROM channels WHERE title=? and source=? COLLATE NOCASE", [ChannelName.strip(),origin])
        c.execute("SELECT * FROM channels WHERE id=? and source=? COLLATE NOCASE", [cat.strip(),origin])  ### 2017-09-30
        logos = c.fetchall()
        #xbmc.log('recordings.py: ChannelName logos title= %s' % repr(logos))
        if len(logos) > 0:
            logo = logos[0][1]
        else:
            logo = cat
            ###utils.notification( 'NOT FOUND: channel= %s' % (cat))
        #xbmc.log('recordings.py: ChannelName logo= %s' % repr(logo))
    except:
        pass
        logo = cat
    c.close()
    return logo
    
def EPG_ChannelFromCat(cat):
    c = getConnection().cursor()
    try:
        c.execute("SELECT * FROM channels WHERE id=? and source=? COLLATE NOCASE", [cat.strip(),origin]) 
        logos = c.fetchall()
        if len(logos) > 0:
            logo = logos[0][9]
        else:
            logo = ''
            ###utils.notification( 'NOT FOUND: channel= %s' % (cat))
        #xbmc.log('recordings.py: ChannelName logo= %s' % repr(logo))
    except:
        pass
        logo = ''
    logo = logo.lower().strip()
    c.close()
    return logo

def EPG_ChannelFromCname(ChannelName):
    cat = ChannelName
    c = getConnection().cursor()
    try:
        c.execute("SELECT * FROM channels WHERE title=? and source=? COLLATE NOCASE", [cat.strip(),origin]) 
        logos = c.fetchall()
        if len(logos) > 0:
            logo = logos[0][9]
        else:
            logo = ''
            ###utils.notification( 'NOT FOUND: channel= %s' % (cat))
        #xbmc.log('recordings.py: ChannelName logo= %s' % repr(logo))
    except:
        pass
        logo = ''
    logo = logo.lower().strip()
    c.close()
    return logo
    
def catsfromEPGid(epgid):
    c = getConnection().cursor()
    try:
        ###c.execute("SELECT * FROM channels WHERE epg_channel=? favorite=? and visible=? and source=?", [epgid,'True',1,origin])
        c.execute("SELECT * FROM channels WHERE epg_channel=?", [epgid])
        ###c.execute("SELECT * FROM channels WHERE title=? COLLATE NOCASE", [epgid.strip()])
        logos = c.fetchall()
        cat= logos[0][0]
    except:
        pass
        logos= []
    if len(logos) > 0:
        logo = logos[0][0]
    else:
        logo = '0'
        if not 'http' in epgid:
            utils.notification( 'NOT FOUND: epgid= %s' % (epgid))
    utils.logdebug('catsfromEPGid', 'epgid= %r, cat= %r' % (epgid, logo))
    c.close()
    return logo
    
    
def CatFromChannelName(ChannelName):
    c = getConnection().cursor()
    try:
        ###c = getIconConnection().cursor()
        c.execute("SELECT * FROM channels WHERE title=? and source=? COLLATE NOCASE", [ChannelName.strip(),origin])
        logos = c.fetchall()
        if len(logos) > 1:
            log('err More channels with same name: ChannelName= %r --> %r' % (ChannelName,logos[1][0]))
        if len(logos) == 1:
            log('err One channels with name: ChannelName= %r --> %r' % (ChannelName,logos[0][0]))
    except Exception as e:
        pass
        log('CatFromChannelName(ChannelName= %r) ERROR: %r' % (ChannelName,e))
        logos= []
    if len(logos) > 0:
        logo = logos[0][0]
    else:
        logo = '0'
        log('2. NOT FOUND: channel= %s' % ChannelName)
    log('CatFromChannelName ChannelName= %r, cat= %r' % (ChannelName, logo))
    c.close()
    return logo
    
def ChannelNameDb(cat,c,origin):  ###  and source=?", [cat,origin])
    try:
        #xbmc.log('recordings.py: ChannelName cat= %s' % (repr(cat)))
        ###c = getIconConnection().cursor()
        ###c = getConnection().cursor()
        #c.execute("SELECT * FROM channels WHERE title=? and source=? COLLATE NOCASE", [title.strip(),origin])
        c.execute("SELECT * FROM channels WHERE id=? and source=? COLLATE NOCASE", [cat.strip(),origin])  ### 2017-09-30

        logos = c.fetchall()
        #xbmc.log('recordings.py: ChannelName logos title= %s' % repr(logos))
    except:
        pass
        logos= []
    if len(logos) > 0:
        logo = logos[0][1]
    else:
        logo = cat
        ###utils.notification( 'NOT FOUND: channel= %s' % (cat))
    #xbmc.log('recordings.py: ChannelName logo= %s' % repr(logo))
    ###c.close()  # 2017-12-29
    return logo

def CatFromChannelNameDb(ChannelName,c,origin):
    try:
        ###c = getIconConnection().cursor()
        ###c = getConnection().cursor()
        c.execute("SELECT * FROM channels WHERE title=? and source=? COLLATE NOCASE", [ChannelName.strip(),origin])
        #c.execute("SELECT * FROM channels WHERE id=?", [cat.strip()])
        logos = c.fetchall()
        
        cat= int(logos[0][0])
    except:
        pass
        logos= []
    if len(logos) > 0:
        logo = logos[0][0]
    else:
        logo = '0'
        ###utils.notification( 'NOT FOUND: channel= %s' % (ChannelName))
    utils.logdebug('CatFromChannelName', 'ChannelName= %r, cat= %r' % (ChannelName, logo))
    ###c.close()  # 2017-12-29
    return logo

def getRecordings():
    #print "getRecordings"
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    c = getConnection().cursor()
    #print "getRecordings1"
    try:
        c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE start > ?" , [now])
        #print "getRecordings2"
        recordings = c.fetchall()
        recordings = sorted(recordings, key=itemgetter('start'))
        #print "getRecordings3"
        log('getRecordings len(recordings)= ' + str(len(recordings)))
        for index in range(0, len(recordings)):
            cat         = recordings[index][0]
            name        = recordings[index][1]
            startDate   = parseDate(recordings[index][2]) 
            log('getRecordings() Name= %r StartDate=%r' %(recordings[index][1],recordings[index][2]))
    except Exception as e:
        pass
        log('getRecordings() failed! \nERROR= %r' % e)
        recordings = []
    ##for index in range(0, len(recordings)):
    ##  #print "getRecordings4"
    ##  cat         = recordings[index][0]
    ##  #print "getRecordings5"
    ##  name        = recordings[index][1]
    ##  #print "getRecordings6"
    ##  startDate   = parseDate(recordings[index][2])
    ##  #print "getRecordings7"
    ##  endDate     = parseDate(recordings[index][3])
    ##  #print "getRecordings8"
    ##  alarmname   = recordings[index][4]
    ##  #print "getRecordings9"
    ##  description = recordings[index][5]
    ##  #print "getRecordings9a"
    ##  #print "recording# " + str(index) + ": " + str(cat) + " , " + str(name) + " , " + repr(startDate) + " , " + repr(endDate) + " , " + alarmname + " , " + str(description)
    #print "getRecordings10"
    #try:
    #   conn.commit()
    #   #print 'recordings.py conn.commit OK'
    #except:
    #   pass
    #   #print 'recordings.py conn.commit failed!'
    #try:
    #   c.commit()
    #   #print 'recordings.py c.commit OK'
    #except:
    #   pass
    #   #print 'recordings.py c.commit failed!'
    c.close()
    #print "getRecordings"
    return recordings
    
def isRecursiveRecord(cat,recordname):
    log( 'c.execute(SELECT * FROM recordings_adc WHERE cat= %r and name= %r)' % (cat,recordname))
    c = getConnection().cursor()
    try:  ### WHERE
        c.execute("SELECT * FROM recordings_adc WHERE cat=? and name=?",  [cat,recordname])
    except Exception as e:
        pass
        log( 'c.execute(SELECT * FROM recordings_adc WHERE cat=? and name=?) failed! \nERROR= %r' % e)
    recordings = c.fetchall()
    c.close()
    if len(recordings) > 0:
        return True
    else:
        return False
    
def isRecording(cat,name,startD,endD):
    startD = parseDate(startD)
    endD = parseDate(endD)
    c = getConnection().cursor()
    if '[' in name:
        name = name.split('[')[0].strip() + '%'
    ###name = name.replace('[','%').replace(']','%').replace('(','%').replace(')','%').replace('.','%').replace('%%','%').replace('  ','%').replace('%%','%').replace('% %','%')
    log( 'c.execute(SELECT * FROM recordings_adc WHERE cat=%r and name like %r)' % (cat,name))
    try:  ### WHERE
        c.execute("SELECT * FROM recordings_adc WHERE cat=? and name like ? and start <= ? and end >= ? ",  [cat,name,startD,endD])
        
    except Exception as e:
        pass
        log( 'c.execute(SELECT * FROM recordings_adc WHERE cat=? and name like ?) failed! \nERROR= %r' % e)
    recordings = c.fetchall()
    c.close()
    return recordings
    
def getRecordingsActive(startD,endD):
    try:
        startPadding = 60 * int(ADDON.getSetting('TimeBefore')) + 1
        endPadding   = 60 * int(ADDON.getSetting('TimeAfter')) + 1
    except:
        startPadding = 60 * 3
        endPadding   = 60 * 15
    startD = parseDate(startD)
    endD = parseDate(endD)
    startD = startD + timedelta(seconds = startPadding)
    endD = endD - timedelta(seconds = endPadding)
    if endD < startD:
        endD = startD
    c = getConnection().cursor()
    try:
        c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc")
    except Exception as e:
        pass
        log( 'c.execute(SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc) failed! \nERROR= %r' % e)
    recordings = c.fetchall()
    recordingsActive=[]

    for index in range(0, len(recordings)): 
        cat         = recordings[index][0]
        ###noblock     = utils.directprograms(cat)
        noblock     = directprograms(cat)
        name        = recordings[index][1]
        startDate   = parseDate(recordings[index][2]) + timedelta(seconds = startPadding+1)
        endDate     = parseDate(recordings[index][3]) - timedelta(seconds = endPadding+1)
        alarmname   = recordings[index][4]
        description = recordings[index][5]
        if not('Recursive:' in name) and not ('[COLOR blue]' in name) and noblock == '':
            if ((endDate >= startD and startDate <= endD) or (endDate >= endD and startDate <= startD) or (endDate <= endD and startDate >= startD)):
                recordingsActive.append(name)
    c.close()
    return recordingsActive

def getRecordingsActiveAll(startD,endD):
    try:
        startPadding = 60 * int(ADDON.getSetting('TimeBefore')) + 1
        endPadding   = 60 * int(ADDON.getSetting('TimeAfter')) + 1
    except:
        startPadding = 60 * 3
        endPadding   = 60 * 15
    startD = parseDate(startD)
    endD = parseDate(endD)
    startD = startD + timedelta(seconds = startPadding)
    endD = endD - timedelta(seconds = endPadding)
    if endD < startD:
        endD = startD
    c = getConnection().cursor()
    c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc")
    recordings = c.fetchall()
    recordingsActive=[]

    for index in range(0, len(recordings)): 
        cat         = recordings[index][0]
        name        = recordings[index][1]
        startDate   = parseDate(recordings[index][2]) + timedelta(seconds = startPadding+1)
        endDate     = parseDate(recordings[index][3]) - timedelta(seconds = endPadding+1)
        alarmname   = recordings[index][4]
        description = recordings[index][5]
        if not('Recursive:' in name) and not ('[COLOR blue]' in name):
            if ((endDate >= startD and startDate <= endD) or (endDate >= endD and startDate <= startD) or (endDate <= endD and startDate >= startD)):
                recordingsActive.append(name)
    c.close()
    return recordingsActive

def getRecordingsActiveAllCat(startD,endD):
    try:
        startPadding = 60 * int(ADDON.getSetting('TimeBefore')) + 1
        endPadding   = 60 * int(ADDON.getSetting('TimeAfter')) + 1
    except:
        startPadding = 60 * 3
        endPadding   = 60 * 15
    startD = parseDate(startD)
    endD = parseDate(endD)
    startD = startD + timedelta(seconds = startPadding)
    endD = endD - timedelta(seconds = endPadding)
    if endD < startD:
        endD = startD
    try:
        c = getConnection().cursor()
        c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc")
        recordings = c.fetchall()
    except:
        pass
        recordings = []
    recordingsActive=[]

    for index in range(0, len(recordings)): 
        cat         = recordings[index][0]
        name        = recordings[index][1]
        startDate   = parseDate(recordings[index][2]) + timedelta(seconds = startPadding+1)
        endDate     = parseDate(recordings[index][3]) - timedelta(seconds = endPadding+1)
        alarmname   = recordings[index][4]
        description = recordings[index][5]
        if not('Recursive:' in name) and not ('[COLOR blue]' in name):
            if ((endDate >= startD and startDate <= endD) or (endDate >= endD and startDate <= startD) or (endDate <= endD and startDate >= startD)):
                recordingsActive.append(cat)
    c.close()
    return recordingsActive

def getNextVOD():
    ### Only if no recording is started
    now = parseDate(datetime.now())
    try:
        c = getConnection().cursor()
        c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name like '[COLOR yellow]Started%' and end > ? ", [now])
        recordings = c.fetchall()
        if len(recordings) == 0:
            c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name like '[COLOR violet]%' and start >= ? ", [now])
            recordings = c.fetchall()
            recordings = sorted(recordings, key=itemgetter(2)) ### Sort by startdate
        else:
            recordings = []
    except:
        pass
        recordings = []
    recordingsActive=[]

    for index in range(0, len(recordings)): 
        cat         = recordings[index][0]
        name        = recordings[index][1]
        startDate   = recordings[index][2]
        endDate     = recordings[index][3]
        alarmname   = recordings[index][4]
        description = recordings[index][5]
        recordingsActive.append([cat, name, startDate, endDate, alarmname, description])
    c.close()
    return recordingsActive

def getRecordingsActiveNoOrange(startD,endD):
    try:
        startPadding = 60 * int(ADDON.getSetting('TimeBefore')) + 1
        endPadding   = 60 * int(ADDON.getSetting('TimeAfter')) + 1
    except:
        startPadding = 60 * 3
        endPadding   = 60 * 15
    startD = parseDate(startD)
    endD = parseDate(endD)
    startD = startD + timedelta(seconds = startPadding)
    endD = endD - timedelta(seconds = endPadding)
    if endD < startD:
        endD = startD
    try:
        c = getConnection().cursor()
        c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc")
        recordings = c.fetchall()
    except:
        pass
        recordings = []
    recordingsActive=[]

    for index in range(0, len(recordings)): 
        cat         = recordings[index][0]
        name        = recordings[index][1]
        startDate   = parseDate(recordings[index][2]) + timedelta(seconds = startPadding+1)
        endDate     = parseDate(recordings[index][3]) - timedelta(seconds = endPadding+1)
        alarmname   = recordings[index][4]
        description = recordings[index][5]
        if not('Recursive:' in name) and not ('[COLOR blue]' in name) and not ('[COLOR orange]' in name ) and not ('[COLOR violet]' in name ) and not ('[COLOR green]Complete ' in name) and directprograms(cat) == '':  ### 2017-09-21/2018-11-25
            if ((endDate >= startD and startDate <= endD) or (endDate >= endD and startDate <= startD) or (endDate <= endD and startDate >= startD)):
                recordingsActive.append(name)
    c.close()
    return recordingsActive
    
def getRecordingsConcurrent(startD,endD):
    try:
        startPadding = 60 * int(ADDON.getSetting('TimeBefore')) + 1
        endPadding   = 60 * int(ADDON.getSetting('TimeAfter')) + 1
    except:
        pass
        startPadding = 60 * 3
        endPadding   = 60 * 15
    startD = parseDate(startD)
    endD = parseDate(endD)
    startD = startD + timedelta(seconds = startPadding) * 2
    endD = endD - timedelta(seconds = endPadding) * 2
    if endD < startD:
        endD = startD
    try:
        c = getConnection().cursor()
        c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc")
        recordings = c.fetchall()
    except:
        pass
        recordings = []
    recordingsActive=[]

    for index in range(0, len(recordings)): 
        cat         = recordings[index][0]
        name        = recordings[index][1]
        startDate   = parseDate(recordings[index][2]) + timedelta(seconds = startPadding+1)
        endDate     = parseDate(recordings[index][3]) - timedelta(seconds = endPadding+1)
        alarmname   = recordings[index][4]
        description = recordings[index][5]
        if not('Recursive:' in name) and not ('[COLOR blue]' in name) and not ('[COLOR orange]' in name): 
            if ((endDate >= startD and startDate <= endD) or (endDate >= endD and startDate <= startD) or (endDate <= endD and startDate >= startD)):
                recordingsActive.append(name)
    c.close()
    return recordingsActive

def add(cat, startDate, endDate, recordname, description):
    log('add(cat= %r, startDate= %r, endDate= %r, recordname= %r, description= %r)' %(cat, startDate, endDate, recordname, description))
    startDate = parseDate(startDate)
    endDate = parseDate(endDate)
    now = parseDate(datetime.now())
    if startDate < now and not 'Recursive:' in recordname:
        log('Dont accept add of recordings, when late')
        return
    if 'Complete' in recordname:
        log('Dont accept schedule of Completed recordings, when late')
        return   
    if 'Restarted' in recordname:
        log('Dont accept schedule of Restarted recordings, when late')
        return  
    log('add(startDate= %r, endDate= %r)' %(startDate, endDate))
    marker = 'BbBb'  ### Allow change of cat
    if marker in recordname:
        recordname = recordname.replace(marker,'')
        ### Change cat
        oldcat = cat
        epg_channel = EPG_ChannelFromCat(cat)
        if epg_channel == '':
            if cat[0:3] == 'DIR':
                epg_channel = '%'+cat[4:].split(' ')[0]+'%'
            else:
                epg_channel = '%'+cat.split(' ')[0]+'%'
            log('epg_channel like recordingsSelected= %r' % epg_channel)
        if epg_channel != '':
            mychannels = getAllChannelsList0(epg_channel)   ### id, title, EPG
            if len(mychannels) > 1:
                
                recursiveChannels = RecursiveChannels()
    
                mychannellist = []
                for cpair in mychannels:
                    if cpair[0] in recursiveChannels:
                        mychannellist.append(cpair[1] + ' (' + cpair[0] + ') EPG= '+ cpair[2]+ ' Recursive')
                    else:
                        mychannellist.append(cpair[1] + ' (' + cpair[0] + ') EPG= '+ cpair[2])
                originalchannel = titleFromCat(cat) + ' (' + cat + ')'
                originalchannelidx = 0
                for y in range(0, len(mychannellist)):
                    if originalchannel in mychannellist[y]:  ### Find first entry with match
                        originalchannelidx = y
                        break
                log('add originalchannel= %r' % originalchannel)
                log('add mychannellist= %r' % mychannellist)
                SelectedChannel = xbmcgui.Dialog().select('New Channel for ' + originalchannel, mychannellist, preselect = originalchannelidx)
                log( 'SelectedChannelNo= %r' % SelectedChannel)
                if SelectedChannel >= 0:
                    try:
                        log( 'try SelectedChannel= %r' % mychannellist[SelectedChannel])
                        newcat = mychannellist[SelectedChannel].split('(')[-1].split(')')[0].strip()
                        
                        log('Selected: ' + titleFromCat(newcat) + ' (' + newcat + ')')
                        cat = newcat
                        if cat != oldcat:
                            recordname = recordname.replace('AaAa','',1)  ### dont change dates if channel changed
                    except Exception as e:
                        pass
                        log( 'SelectedChannel FAILED Channel= %r \nERROR= %r' % (SelectedChannel,e))
    
    log('add(startDate= %r, endDate= %r)' %(startDate, endDate))
    if 'Recursive:' in recordname or directprograms(cat) != '':
        recordingsActive = []
    else:
        recordingsActive=getRecordingsActiveNoOrange(startDate, endDate)
    try:
        concurrentstreams = int(ADDON.getSetting('concurrentstreams'))
    except:
        pass
        concurrentstreams = 1
    ### if not recordingsActive == []:
    log('%r\nlen(recordingsActive) %r >= %r concurrentstreams' % (recordingsActive, len(recordingsActive),concurrentstreams))
    if len(recordingsActive) >= concurrentstreams and concurrentstreams > 0:
        utils.notificationforced('[COLOR red]OVERLAPPING Recording NOT allowed:[/COLOR] %s' % recordingsActive[0])
    if 'Complete' in recordname:
        log('Dont accept schedule of Completed recordings, when late')
        return
    if 'Restarted' in recordname:
        log('Dont accept schedule of Restarted recordings, when late')
        return  
    if schedule(cat, startDate, endDate, recordname, description):
        utils.notification('Recording [COLOR red]set[/COLOR] for %s' % recordname)
    return

def schedule(cat, startDate, endDate, recordname, description, DB='default'):
    ###recordname = recordname.split('[')[0]### 2018-09-12  limmit size of recordname
    added = False
    log('recordings.schedule DB= %r' % DB)
    log('schedule(cat= %r, startDate= %r, endDate= %r, recordname= %r, description= %r, DB= %r' % (cat, startDate, endDate, recordname, description, DB))
    if description == None:
        description = 'None 1'
    recordPath = xbmcvfs.translatePath(os.path.join(utils.ADDONgetSetting('record_path')))
    if recordPath == '':
        recordPath = xbmcvfs.translatePath(os.path.join(utils.ADDONgetSetting('record_path_old')))
        log('err second read recordPath= %r Writable? %r' % (recordPath,utils.folderwritable(recordPath,module)))
    log('err recordPath= %r Writable? %r' % (recordPath,utils.folderwritable(recordPath,module)))
    if ADDON.getSetting('enable_record')=='true' and not utils.folderwritable(recordPath,module):
        utils.notificationforced('Recording not possible [COLOR red]You must set the recording path writable![/COLOR] \nGoto Settings/Recording/Record Path and set that to a writable path')
        ###log('You must set the recording path writable!')
        ###xbmcaddon.Addon(id=ADDONid).openSettings()   
    recordname = ' '.join(recordname.split())  ## Remove doublespaces etc
    log('startDate= %r > endDate= %r - timedelta(minutes=1)= %r' % (startDate,endDate - timedelta(minutes=1),startDate > endDate - timedelta(minutes=1)))
    if startDate > endDate - timedelta(minutes=1) :
        startDate = datetime.now()
        endDate = datetime.now() + timedelta(hours=2) # missing time in schedule
    log('schedule(cat= %r, startDate= %r, endDate= %r, recordname= %r, description= %r)' % ( cat,startDate,endDate,recordname,description))
    if cat[0:4].lower() == 'http':
        playchannel = 'VOD or from other Addon' ### 2019-01-06
    else:
        playchannel = EPG_ChannelFromCat(cat)  ### 2018-07-09
    originalduration = ''
    startDate = parseDate(startDate)
    endDate   = parseDate(endDate)
    durationstring = str(endDate - startDate).split(':')
    log('startDate= %r, endDate= %r, durationstring= %r' % (startDate,endDate,durationstring))
    if endDate > startDate and not 'day' in durationstring[0]:
        originalduration =  'Duration [' + durationstring[0] + ':' + durationstring[1] + ']. '
        log('originalduration= %r' % originalduration)
    ###if not 'Duration [' in description and not ']. ' in description:
    if not ('Duration [' in description and ']. ' in description):  ### 2019-09-08
        description = originalduration + description
        log('Added to description originalduration= %r' % originalduration)
    AdjustDates = False
    recordModified = False
    recordRescheduled = False
    recordRecursive = False
    recordInactive = False
    t = startDate - datetime.now()
    log('t= %r, t.days= %r' % (t,t.days))
    timeToRecording = (t.days * 86400) + t.seconds
    log('timeToRecording= %r' % timeToRecording)
    log('Dont accept schedule during reschedule, if they are late. Rescheduling= %r' % ADDON.getSetting('rescheduling'))
    if (timeToRecording < 0) and not ('Recursive' in recordname):  ### 2019-01-06
        log('timeToRecording is negative: Dont accept schedule, if they are late')
        AdjustDates = True
        recordModified = True
        if 'Complete' in recordname:
            log('Dont accept schedule of Completed recordings, when late')
            return False
        if 'Restarted' in recordname:
            log('Dont accept schedule of Restarted recordings, when late')
            return  
        if ADDON.getSetting('rescheduling').lower() == 'true' :
            log('Dont accept schedule during reschedule, if they are late')
            return False ## Dont accept schedule during reschedule, if they are late
    if 'Complete' in recordname:
        log('Dont accept schedule of Completed recordings')
        return False  
    if 'Restarted' in recordname:
        log('Dont accept schedule of Restarted recordings')
        return  
    now = parseDate(datetime.now()) ### 2018-09-05
    ###now = datetime.now()
    log('now= %r' % now)
    try:
        startPadding = 60 * int(ADDON.getSetting('TimeBefore'))
        endPadding   = 60 * int(ADDON.getSetting('TimeAfter'))
    except:
        pass
        startPadding = 60 * 3
        endPadding   = 60 * 15
    
    if ('CcCc' in recordname) and (timeToRecording < (startPadding * 2)):
        log('Dont accept schedule from TV Grab if they are late')
        return False ## Dont accept schedule from TV Grab if they are late
    recordname = recordname.replace('CcCc','',1)
    if ('AaAa' in recordname):
        AdjustDates = True
        recordModified = True
        if 'Modified' in recordname:
            recordname = recordname.replace('AaAa','',1)
        else:
            #recordname = recordname.replace('AaAa',' Modified',1)  # 2015-10-11 Don't add Modified to record name
            recordname = recordname.replace('AaAa','',1)
    if ('BbBb' in recordname):
        recordRescheduled = True
        AdjustDates = False
        
        if 'Rescheduled' in recordname:
            recordname = recordname.replace('BbBb','',1)
        else:
            #recordname = recordname.replace('BbBb',' Rescheduled',1)  # 2015-10-11 Don't put Rescheduled in recordname
            recordname = recordname.replace('BbBb','',1)
    if ('Recursive' in recordname):
        recordRecursive = True
        AdjustDates = False
        recordname = recordname.replace('AaAa','',1)
        recordname = recordname.replace('BbBb','',1)
        recordname = recordname.replace('Modified','',1)
        recordname = recordname.replace('Rescheduled','',1)
        recordname = recordname.replace('  ',' ')
    recordname = recordname.replace('[COLOR blue]','') # remove inactive marker
    recordname = recordname.replace('[COLOR green]','') # remove inactive marker
    recordname = recordname.replace('[COLOR orange]','*') # remove inactive marker
    recordname = recordname.replace('[COLOR red]','') # remove inactive marker
    recordname = recordname.replace('[/COLOR]','')
    if recordname == '':
        recordname = 'missing'
    ###log('recordname= ' + repr(recordname))
    if recordname[0][0] == '*':   # DISABLE RECORD
        recordInactive = True
        AdjustDates = False
        recordname = recordname.replace('*','',1)  # 'schedule *-->inactive'
        recordname = recordname.replace('AaAa','',1)
        recordname = recordname.replace('BbBb','',1)
        recordname = recordname.replace('Modified','',1)
        recordname = recordname.replace('Rescheduled','',1)
        recordname = recordname.replace('  ',' ')
    
    showNotification = True
    if timeToRecording < 0:
        showNotification = True
        timeToRecording  = 0
        startDate        = now
    else:
        if (not recordModified) and (not recordRescheduled) and (not recordRecursive) and (not recordInactive): 
            startDate = startDate - timedelta(seconds = startPadding)
        #modify startDate if necessary; it shouldn't be earlier that 'now'
        if startDate < now:
            startDate = now
    
    if (startDate == now or recordModified) and (not recordRescheduled) and (not recordRecursive) and (not recordInactive):
        AdjustDates = True
    if AdjustDates == True:
        startDate=AdjustDateTime(startDate,"Start")
    if (endDate <= startDate) and (not recordRecursive) and (not recordInactive):
        endDate = startDate + timedelta(seconds = endPadding)
        AdjustDates = True
    if AdjustDates == True:
        endDate=AdjustDateTime(endDate,"End")
    if (recordname == 'n a' or AdjustDates == True) and (not recordRescheduled) and (not recordInactive) or recordModified:
        if recordModified and recordRecursive:
            recordname='Recursive:' + NAMErecord(recordname.replace('Recursive:','',1).strip())
        else:
            recordname=NAMErecord(recordname)
    if recordModified:
        try:
            ### description = latin1_to_ascii(DescriptionRecord(description))
            description = DescriptionRecord(description)   ### 2019-09-08
        except Exception as e:
            pass
            log('if recordModified ERROR %r' % e)
    t =  startDate - now
    timeToRecording = (t.days * 86400) + t.seconds     
    showNotification = True
    if timeToRecording < 0:
        timeToRecording  = 0
        startDate        = now
    nameAlarm = ADDONid +'-recording-%s-%s-%s' % (cat, startDate, latin1_to_ascii_force(recordname))
    nameAlarm = nameAlarm.replace(':','.').replace('/','').replace('[','').replace(']','').replace('&','.')
    ###nameAlarm = stringtoargument(nameAlarm)   ### Removed 2019-12-17
    duration = endDate - startDate
    ######log('duration is %s, if less than 3 minutes - no recording of %s with startDate= %s and endDate= %s' % (repr(duration),repr(recordname),repr(startDate),repr(endDate)))
    if (not recordRecursive) and duration < timedelta(0, 180): # Dont record if les than 3 minutes 2016-03-16
        ###log('duration is %s, is less than 3 minutes - no recording of %s with startDate= %s and endDate= %s' % (repr(duration),repr(recordname),repr(startDate),repr(endDate)))
        log('Dont record if les than 3 minutes')
        return False
    duration = (duration.days * 86400) + duration.seconds
    if (not recordModified) and (not recordRescheduled) and (not recordInactive):
        duration = duration + endPadding
    if recordRecursive or recordInactive:
        script         =  ''   #os.path.join(ADDON.getAddonInfo('path'), 'findrecursiveX.py')
    else:
        if ADDON.getSetting('recordusing')  == '0':
            script   = os.path.join(ADDON.getAddonInfo('path'), 'record-rtmpdump.py')
        else:
            if 'Record from VOD/Series or from other AddOn' in description:   
                script   = os.path.join(ADDON.getAddonInfo('path'), 'recorduriffmpeg.py')
                ### Parameters: uri, title, nameAlarm
            else:
                script   = os.path.join(ADDON.getAddonInfo('path'), 'record-ffmpeg.py')
                ### Parameters: cat, startTime, endTime, duration, title, argv6, argv7, nameAlarm
    if (not recordModified) and (not recordRescheduled) and (not recordRecursive) and (not recordInactive):
        endDate = endDate + timedelta(seconds = endPadding)
    recordname = re.sub(',', '', recordname) 
    ###recordname = stringtoargument(recordname) 
    args     = stringtoargument(cat) + ',' + str(startDate) + ',' + str(endDate) + ',' + str(duration) + ',' + recordname + ',' + '60' + ',' + 'True'
    cmd     = ''
    if not(recordRecursive or recordInactive):
        args= args + ',' + nameAlarm + ',' + utils.base64b64encode(description)  ### 2020-02-02
        cmd = 'AlarmClock(%s,RunScript(%s,%s),%d,True)' % (nameAlarm, script, args, timeToRecording/60)
    recordingsActive = []
    if recordRecursive or recordInactive:
        if recordRecursive:
            endDate = startDate
    else:
        recordingsActive=getRecordingsActive(startDate, endDate)
    ###recordname = latin1_to_ascii(recordname) ###
    if recordInactive:
        added = addRecordingPlanned(cat, startDate, endDate, '[COLOR orange]' + recordname + '[/COLOR]', '[COLOR orange]' + nameAlarm + '[/COLOR]', description, playchannel,DB)
        return False
    if recordRecursive:
        # Test if it exists before scheduling
        if isRecursiveRecord(cat,recordname):
            log('Test if it exists before scheduling - isRecursiveRecord(cat= %r,recordname= %r)' % (cat,recordname))
            return False
    unblock = directprograms(cat)
    if not unblock == '':
        # Handle scheduling of Direct Channel - Noblock
        if not cat in getRecordingsActiveAllCat(startDate, endDate):
            added = addRecordingPlanned(cat, startDate, endDate, recordname, nameAlarm, description, playchannel,DB)
            if not recordRescheduled:
                xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
            else:
                if not recordRecursive:
                    utils.notificationforced('[COLOR lightgreen]Direct Channel Recording: [/COLOR] %s' % (playchannel + ': ' + recordname))
            cmd= latin1_to_ascii(cmd)
            xbmc.executebuiltin(cmd)
        log('Handle scheduling of Direct Channel - Noblock')
        return added
    for  RecordingActive in recordingsActive:
        if ('[COLOR orange]' in RecordingActive) and (recordname in RecordingActive):
            # 2016-03-13 utils.notification('[COLOR orange]Disabled Recording: [/COLOR] %s' % (str(RecordingActive)))
            log('[COLOR orange]Disabled Recording: [/COLOR] %r' % RecordingActive)
            return False
        if (not '[COLOR orange]' in RecordingActive) and (not recordRescheduled) and (not recordRecursive) : ### and 1 == 0 :  ### DISABLE 2019-07-22/2020-02-08
            try:
                log('recordname= %r,RecordingActive= %r, cat= %r\ngetRecordingsActiveAllCat= %r'% (recordname, RecordingActive, cat,  getRecordingsActiveAllCat(startDate, endDate)))
                ###if (not recordname in RecordingActive) or (not cat in getRecordingsActiveAllCat(startDate, endDate)) : ### 2017-03-18 mark program with same name in a new channel
                if not (recordname in RecordingActive and cat in getRecordingsActiveAllCat(startDate, endDate)) : ### 2017-03-18 mark program with same name in a new channel
                    log('if not recordname= %s in RecordingActive= %s' % (repr(recordname),repr(RecordingActive)))
                    # 2016-03-13 utils.notification('[COLOR red]OVERLAPPING Recording NOT allowed:[/COLOR] %s' % (str(RecordingActive)))
                    delRecordingPlanned(cat, startDate, endDate, '[COLOR blue]' + recordname + '[/COLOR]')
                    added = addRecordingPlanned(cat, startDate, endDate, '[COLOR blue]' + recordname + '[/COLOR]', '[COLOR blue]' + nameAlarm + '[/COLOR]', description, playchannel,DB)
                else:
                    log('IGNORE if recordname= %r in RecordingActive= %r' % (recordname,RecordingActive))
                    added = False
                    ###delRecordingPlanned(cat, startDate, endDate, '[COLOR lightblue]' + recordname + '[/COLOR]')
                    ###addRecordingPlanned(cat, startDate, endDate, '[COLOR lightblue]' + recordname + '[/COLOR]', '[COLOR lightblue]' + nameAlarm + '[/COLOR]', description, playchannel,DB)
                return added
            except Exception as e:
                pass
                log('schedule: ERROR: %r' % e)  # Put in LOG
                return False
    #cancel alarm first just in case it already exists
    if not recordRescheduled:
        xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
    cmd= latin1_to_ascii(cmd)
    xbmc.executebuiltin(cmd)
    if recordRecursive:
        #cancel alarm first just in case it already exists
        if not recordRescheduled:
            xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
    added = addRecordingPlanned(cat, startDate, endDate, recordname, nameAlarm, description, playchannel,DB)
    if ('Recursive:' not in recordname):
        utils.notificationforced('Recording [COLOR red]set[/COLOR] for %s' % recordname)
    return added

def EPGOnce():
    nameAlarmEPGonce = ADDONname +'updateepgonce' 
    scriptEPG   = os.path.join(ADDON.getAddonInfo('path'), 'updateepg.py')
    ###cmdEPGonce = 'AlarmClock(%s,RunScript(%s,%s),00:00:00,silent)' % (nameAlarmEPGonce.encode('utf-8', 'replace'), scriptEPG.encode('utf-8', 'replace'), 'once')
    cmdEPGonce = 'AlarmClock(%s,RunScript(%s,%s),00:00:00,silent)' % (nameAlarmEPGonce, scriptEPG, 'once')
    xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmEPGonce)
    xbmc.executebuiltin(cmdEPGonce)

def reschedule():
    backupSetupxml()
    ADDON.setSetting('fixsetup','false')
    ADDON.setSetting('rescheduling','true')
    backupDataBase()
    
    if ADDON.getSetting('enable_record')=='true' or ADDON.getSetting('record_display_path') != '' or (ADDON.getSetting('record_display_path') and ADDON.getSetting('record_archive_path_enable') == 'true'):
        args     = str('True')
        #script   = os.path.join(ADDON.getAddonInfo('path'), 'findrecursivetimed.py')
        #scriptOnce   = os.path.join(ADDON.getAddonInfo('path'), 'findrecursivetimedOnce.py')
        #scriptHour   = os.path.join(ADDON.getAddonInfo('path'), 'findrecursivetimedHour.py')
        
        #nameAlarmRepeat = ADDONid+'-recording-recursive-repeat' 
        #cmdrepeat = 'AlarmClock(%s,RunScript(%s,%s),02:00:00,loop,silent)' % (nameAlarmRepeat.encode('utf-8', 'replace'), script.encode('utf-8', 'replace'), args.encode('utf-8', 'replace'))
        #xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmRepeat)
        # xbmc.executebuiltin(cmdrepeat)  # Active
        #nameAlarmRepeat = ADDONid+'-recording-recursive-once' 
        #cmdrepeat = 'AlarmClock(%s,RunScript(%s,%s),00:05:00,silent)' % (nameAlarmRepeat.encode('utf-8', 'replace'), scriptOnce.encode('utf-8', 'replace'), args.encode('utf-8', 'replace'))
        #xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmRepeat)
        #xbmc.executebuiltin(cmdrepeat)  # Active
        TVguide= utils.TVguide()
        
        prog = 'startrepeatprog.py'
        now= datetime.today().strftime('%H:%M:%S')
        now = now.split(':')
        nowhm = int(now[0]) * 60 + int(now[1])
        ###starttime = '07:00:00'.split(':')
        starttime = ADDON.getSetting('epgimportstarttime').split(':')
        ###interval  = '08:00:00'
        interval  = ADDON.getSetting('epgimportinterval')
        intervalh  = interval.split(':')
        starttimehm = int(starttime[0]) * 60 + int(starttime[1])
        intervalhm = int(intervalh[0]) * 60 + int(intervalh[1])
        ###log('interval= %r starttime= %r - now= %r' %(interval, starttime, now))
        i = 0
        while starttimehm < nowhm and i < 50:
            starttimehm += intervalhm
            i += 1
            ###log('interval= %r starttime= %r - now= %r' %(intervalhm, starttimehm, nowhm))
        starttimedelta = starttimehm - nowhm
        starttimedeltahms = str(starttimedelta/60) + ':' + str(starttimedelta%60) + ':00'
        intervalhms = interval.replace(':','h',1).replace(':','m',1)
        log('starttimedeltahms= %r starttime= %r - now= %r' %(starttimedeltahms, starttime, now))
        nameAlarmstartrepeatprog = ADDONname +'startrepeatprog' 
        scriptstartrepeatprog   = os.path.join(ADDON.getAddonInfo('path'), prog)
        cmdstartrepeatprog = 'AlarmClock(%s,RunScript(%s,%s),%s,silent)' % (nameAlarmstartrepeatprog.encode('utf-8', 'replace'), scriptstartrepeatprog.encode('utf-8', 'replace'), intervalhms,starttimedeltahms)
        xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmstartrepeatprog)
        if ADDON.getSetting('notifyduringepgupdate') == 'true':
            utils.notification('Start EPG import in '+starttimedeltahms.replace(':','h',1).replace(':','m',1) + 's')
        xbmc.executebuiltin(cmdstartrepeatprog) 
        
        ###nameAlarmEPG = ADDONname +'updateepg' 
        channels = getAllChannelsList()
        if ADDON.getSetting('epgimportonstart').lower() == 'true' or len(channels) == 0:
            EPGOnce()
        ###cmdEPG = 'AlarmClock(%s,RunScript(%s,%s),08:10:00,loop,silent)' % (nameAlarmEPG.encode('utf-8', 'replace'), scriptEPG.encode('utf-8', 'replace'), 'hourly')
        ###xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmEPG) 
        ###xbmc.executebuiltin(cmdEPG)  # Active
        
        nameAlarmKeep = ADDONname +'http-keep-alive' 
        scriptKeep   = os.path.join(ADDON.getAddonInfo('path'), 'http-keep-alive.py')
        cmdKeep = 'AlarmClock(%s,RunScript(%s,%s),00:05:30,loop,silent)' % (nameAlarmKeep.encode('utf-8', 'replace'), scriptKeep.encode('utf-8', 'replace'), '')
        xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmKeep)
        xbmc.executebuiltin(cmdKeep)  # Active
    if ADDON.getSetting('enable_record')=='true' :    
        nameAlarmRepeat = ADDONname +'-recording-recursive-hours' 
        scriptHour   = os.path.join(ADDON.getAddonInfo('path'), 'findtvguidenotificationstimed.py')
        cmdrepeat = 'AlarmClock(%s,RunScript(%s,%s),00:50:00,loop,silent)' % (nameAlarmRepeat.encode('utf-8', 'replace'), scriptHour.encode('utf-8', 'replace'), args.encode('utf-8', 'replace'))
        xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmRepeat)
        xbmc.executebuiltin(cmdrepeat)  # Active
        if ADDON.getSetting('notifyduringepgupdate') == 'true':
            utils.notification('[COLOR green]Timers set[/COLOR] for TV Guide grab recordings reguarly')
        ##xbmc.executebuiltin("Container.Refresh")
        
        scriptTrig   = os.path.join(ADDON.getAddonInfo('path'), 'TrigTVGuide.py')       
        try:
            TrigInterval = ADDON.getSetting('startstopguideinterval')
        except Exception as e:
            pass
            ###log( 'Trigger TV Guide interval failed! Guide= %s ERROR= %s' % (guide,repr(e)))
            TrigInterval = '01:00:00'
        
        for Guide in range(0, len(TVguide)):
            guide = TVguide[Guide][0]
            # Trigger Guide...
            try:
                cmdTrig = 'AlarmClock(%s,RunScript(%s,%s,%s),%s,loop,silent)' % (ADDONname +'TrigTVGuide'+guide, scriptTrig, guide,'ExtraParameter',TrigInterval)
                if not (TrigInterval == '00:00:00' or TrigInterval == '0'):
                    xbmc.executebuiltin(cmdTrig)  # Active
                    ###xbmc.executebuiltin("StopScript(" + guide + ")")  ### Stop Guide
                    ###xbmc.executebuiltin("RunAddon(" + guide + ")")    ### Start Guide
                    ###log( 'Trigger TV Guide= %s with interval %s' % (guide,TrigInterval))
                ###else:
                    
                    ###log( 'No Trigger TV Guide= %s' % (guide))
            except Exception as e:
                pass
                ###log( 'Trigger TV Guide failed! Guide= %s ERROR= %s' % (guide,repr(e)))
        
        
        now = parseDate(datetime.now())
        recordings = getRecordings()
        if ADDON.getSetting('notifyduringepgupdate') == 'true':
            utils.notification('[COLOR green]Rescheduling Recordings[/COLOR]',time=100000)
        
        for index in range(0, len(recordings)): 
            cat       = recordings[index][0]
            name      = recordings[index][1]
            #startDate = parseDate(recordings[index][2])
            startDate = recordings[index][2]
            #endDate   = parseDate(recordings[index][3])
            endDate   = recordings[index][3]
            alarmname = recordings[index][4]
            description = recordings[index][5]
            
            try:
                if not ('Recursive:' in name) and not('[COLOR blue]' in name):
                    delRecordingPlanned(cat, startDate, endDate, name)
            except:
                pass
                log('delRecordingPlanned: FAILED(index= %r, cat= %r, startDate= %r, endDate= %r, name= %r)' %(index,cat,startDate,endDate,name))  # Put in LOG
            startDate = parseDate(startDate)
            endDate   = parseDate(endDate)
            if not('Recursive:' in name) or (startDate >= now):  ### Don't restart in the middle of a recording
                if '[COLOR orange]' in name:
                    schedule(cat,startDate,endDate,name+'BbBb',description)
                elif '[COLOR blue]' in name:
                    log('Blue recordings are not deleted')
                else:
                    schedule(cat,startDate,endDate,name+'BbBb',description)
    ADDON.setSetting('rescheduling','false')

def Numeric(timeT,funk):
        dialog = xbmcgui.Dialog()
        keyboard=dialog.numeric(2, funk + ' Time To Record?',timeT)
        return keyboard

def NumericStart(timeD,funk):
        dialog = xbmcgui.Dialog()
        keyboard=dialog.numeric(1, funk + ' Date To Record?',timeD)
        return keyboard

def NAMErecord(recordName):
        search_entered = recordName
        keyboard = xbmc.Keyboard(search_entered, 'Please Enter Program Name')
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText()
            if search_entered == None:
                return False          
        return search_entered 
         
def DescriptionRecord(recordName):
        search_entered = recordName
        keyboard = xbmc.Keyboard(search_entered, 'Please Enter Programme Description')
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText()
            if search_entered == None:
                return False          
        return search_entered  

def AdjustDateTime(aDateTime,funk):
    startTime=aDateTime.strftime('%H:%M')
    aDateTime=NumericStart(aDateTime.strftime('%d/%m/%Y'),funk)
    startTime=Numeric(startTime,funk)
    startYear=int(aDateTime.split('/')[2])
    startMonth=int(aDateTime.split('/')[1])
    startDay=int(aDateTime.split('/')[0])
    startHour=int(startTime.split(':')[0])
    startMinute=int(startTime.split(':')[1])
    aDateTime=(startYear,startMonth,startDay,startHour,startMinute,0,0,0,-1)
    aDateTime=datetime(*aDateTime[0:6])
    return aDateTime

def safe_unicode(obj, *args):
    """ return the unicode representation of obj """
    try:
        return unicode(obj, *args)
    except UnicodeDecodeError:
        ascii_text = str(obj).encode('string_escape')
        return unicode(ascii_text)

def safe_str(obj):
    """ return the byte string representation of obj """
    try:
        return str(obj)
    except UnicodeEncodeError:
        return unicode(obj).encode('unicode_escape')

# ------------------------------------------------------------------------
# Sample code below to illustrate their usage

def write_unicode_to_file(filename, unicode_text):
    """
    Write unicode_text to filename in UTF-8 encoding.
    Parameter is expected to be unicode. But it will also tolerate byte string.
    """
    fp = file(filename,'wb')
    # workaround problem if caller gives byte string instead
    unicode_text = safe_unicode(unicode_text)
    utf8_text = unicode_text.encode('utf-8')
    fp.write(utf8_text)
    fp.close()


def _decodeHtmlEntities(string):
        """Decodes the HTML entities found in the string and returns the modified string.

        Both decimal (&#000;) and hexadecimal (&x00;) are supported as well as HTML entities,
        such as &aelig;

        Keyword arguments:
        string -- the string with HTML entities

        """
        if type(string) not in [str, unicode]:
            return string

        def substituteEntity(match):
            ent = match.group(3)
            if match.group(1) == "#":
                # decoding by number
                if match.group(2) == '':
                    # number is in decimal
                    return unichr(int(ent))
            elif match.group(2) == 'x':
                # number is in hex
                return unichr(int('0x' + ent, 16))
            else:
                # they were using a name
                cp = name2codepoint.get(ent)
                if cp:
                    return unichr(cp)
                else:
                    return match.group()

        entity_re = re.compile(r'&(#?)(x?)(\w+);')
        return entity_re.subn(substituteEntity, string)[0]


"""
latin1_to_ascii -- The UNICODE Hammer -- AKA "The Stupid American"

This takes a UNICODE string and replaces Latin-1 characters with
something equivalent in 7-bit ASCII. This returns a plain ASCII string. 
This function makes a best effort to convert Latin-1 characters into 
ASCII equivalents. It does not just strip out the Latin1 characters.
All characters in the standard 7-bit ASCII range are preserved. 
In the 8th bit range all the Latin-1 accented letters are converted to 
unaccented equivalents. Most symbol characters are converted to 
something meaningful. Anything not converted is deleted.

Background:

One of my clients gets address data from Europe, but most of their systems 
cannot handle Latin-1 characters. With all due respect to the umlaut,
scharfes s, cedilla, and all the other fine accented characters of Europe, 
all I needed to do was to prepare addresses for a shipping system.
After getting headaches trying to deal with this problem using Python's 
built-in UNICODE support I gave up and decided to use some brute force.
This function converts all accented letters to their unaccented equivalents. 
I realize this is dirty, but for my purposes the mail gets delivered.


#!/usr/bin/env python
# -*- coding: utf-8 -*-

u = 'idzie wąż wąską dróżką'
uu = u.decode('utf8')
s = uu.encode('cp1250')
print(s)
"""

import re, html.entities

##
# Removes HTML or XML character references and entities from a text string.
#
# @param text The HTML (or XML) source text.
# @return The plain text, as a Unicode string, if necessary.

def unescape(text):
    def fixup(m):
        text = m.group(0)
        if text[:2] == "&#":
            # character reference
            try:
                if text[:3] == "&#x":
                    return unichr(int(text[3:-1], 16))
                else:
                    return unichr(int(text[2:-1]))
            except ValueError:
                pass
        else:
            # named entity
            try:
                text = unichr(html.entities.name2codepoint[text[1:-1]])
            except KeyError:
                pass
        return text # leave as is
    return re.sub("&#?\w+;", fixup, text)

def latin1_to_ascii (unicrap):
    """This takes a UNICODE string and replaces Latin-1 characters with
        something equivalent in 7-bit ASCII. It returns a plain ASCII string. 
        This function makes a best effort to convert Latin-1 characters into 
        ASCII equivalents. It does not just strip out the Latin-1 characters.
        All characters in the standard 7-bit ASCII range are preserved. 
        In the 8th bit range all the Latin-1 accented letters are converted 
        to unaccented equivalents. Most symbol characters are converted to 
        something meaningful. Anything not converted is deleted.
    """
    u = unicrap   ## TEST 2016-04-29 ###############################################################################################
    
    return u
    #return u ######################################
    if isinstance(u, unicode):
        #   uu = u.encode('utf-8')
        #else:
        #   uu = u
    #try:
        uu = u.encode('utf8')
    else:
        uu = u.encode('utf8', 'xmlcharrefreplace')
    #except:
    #   uu = 'a' + u +'b'
    
    #try:
    ##s = uu.encode('ascii', 'xmlcharrefreplace')
    #except:
    #   s = 'x' + u +'y'
    
    return uu ## TEST 2016-04-29 ###############################################################################################

def latin1_to_ascii_force(unitext):
    """
2020-02-02 13:43:56 default.py: l TEST i= 127, str(j)= '\x7f'=, unicrap(j)= '\x7f'
2020-02-02 13:43:56 default.py: l TEST i= 128, str(j)= '\x80'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 129, str(j)= '\x81'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 130, str(j)= '\x82'=, unicrap(j)= 'Euro'
2020-02-02 13:43:56 default.py: l TEST i= 131, str(j)= '\x83'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 132, str(j)= '\x84'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 133, str(j)= '\x85'=, unicrap(j)= 'AA'
2020-02-02 13:43:56 default.py: l TEST i= 134, str(j)= '\x86'=, unicrap(j)= 'AE'
2020-02-02 13:43:56 default.py: l TEST i= 135, str(j)= '\x87'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 136, str(j)= '\x88'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 137, str(j)= '\x89'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 138, str(j)= '\x8a'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 139, str(j)= '\x8b'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 140, str(j)= '\x8c'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 141, str(j)= '\x8d'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 142, str(j)= '\x8e'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 143, str(j)= '\x8f'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 144, str(j)= '\x90'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 145, str(j)= '\x91'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 146, str(j)= '\x92'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 147, str(j)= '\x93'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 148, str(j)= '\x94'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 149, str(j)= '\x95'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 150, str(j)= '\x96'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 151, str(j)= '\x97'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 152, str(j)= '\x98'=, unicrap(j)= 'OE'
2020-02-02 13:43:56 default.py: l TEST i= 153, str(j)= '\x99'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 154, str(j)= '\x9a'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 155, str(j)= '\x9b'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 156, str(j)= '\x9c'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 157, str(j)= '\x9d'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 158, str(j)= '\x9e'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 159, str(j)= '\x9f'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 160, str(j)= '\xa0'= , unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 161, str(j)= '\xa1'=¡, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 162, str(j)= '\xa2'=¢, unicrap(j)= 'c'
2020-02-02 13:43:57 default.py: l TEST i= 163, str(j)= '\xa3'=£, unicrap(j)= 'L'
2020-02-02 13:43:57 default.py: l TEST i= 164, str(j)= '\xa4'=¤, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 165, str(j)= '\xa5'=¥, unicrap(j)= 'Y'
2020-02-02 13:43:57 default.py: l TEST i= 166, str(j)= '\xa6'=¦, unicrap(j)= ':'
2020-02-02 13:43:57 default.py: l TEST i= 167, str(j)= '\xa7'=§, unicrap(j)= 's'
2020-02-02 13:43:57 default.py: l TEST i= 168, str(j)= '\xa8'=¨, unicrap(j)= '..'
2020-02-02 13:43:57 default.py: l TEST i= 169, str(j)= '\xa9'=©, unicrap(j)= 'c'
2020-02-02 13:43:57 default.py: l TEST i= 170, str(j)= '\xaa'=ª, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 171, str(j)= '\xab'=«, unicrap(j)= '<<'
2020-02-02 13:43:57 default.py: l TEST i= 172, str(j)= '\xac'=¬, unicrap(j)= '-'
2020-02-02 13:43:57 default.py: l TEST i= 173, str(j)= '\xad'=­, unicrap(j)= '-'
2020-02-02 13:43:57 default.py: l TEST i= 174, str(j)= '\xae'=®, unicrap(j)= 'R'
2020-02-02 13:43:57 default.py: l TEST i= 175, str(j)= '\xaf'=¯, unicrap(j)= '_'
2020-02-02 13:43:57 default.py: l TEST i= 176, str(j)= '\xb0'=°, unicrap(j)= 'deg'
2020-02-02 13:43:57 default.py: l TEST i= 177, str(j)= '\xb1'=±, unicrap(j)= '+/-'
2020-02-02 13:43:57 default.py: l TEST i= 178, str(j)= '\xb2'=², unicrap(j)= '^2'
2020-02-02 13:43:57 default.py: l TEST i= 179, str(j)= '\xb3'=³, unicrap(j)= '^3'
2020-02-02 13:43:57 default.py: l TEST i= 180, str(j)= '\xb4'=´, unicrap(j)= "'"
2020-02-02 13:43:57 default.py: l TEST i= 181, str(j)= '\xb5'=µ, unicrap(j)= 'm'
2020-02-02 13:43:57 default.py: l TEST i= 182, str(j)= '\xb6'=¶, unicrap(j)= 'pi'
2020-02-02 13:43:57 default.py: l TEST i= 183, str(j)= '\xb7'=·, unicrap(j)= '*'
2020-02-02 13:43:57 default.py: l TEST i= 184, str(j)= '\xb8'=¸, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 185, str(j)= '\xb9'=¹, unicrap(j)= '^1'
2020-02-02 13:43:57 default.py: l TEST i= 186, str(j)= '\xba'=º, unicrap(j)= '^0'
2020-02-02 13:43:57 default.py: l TEST i= 187, str(j)= '\xbb'=», unicrap(j)= '>>'
2020-02-02 13:43:57 default.py: l TEST i= 188, str(j)= '\xbc'=¼, unicrap(j)= '1/4'
2020-02-02 13:43:57 default.py: l TEST i= 189, str(j)= '\xbd'=½, unicrap(j)= '1/2'
2020-02-02 13:43:57 default.py: l TEST i= 190, str(j)= '\xbe'=¾, unicrap(j)= '3/4'
2020-02-02 13:43:57 default.py: l TEST i= 191, str(j)= '\xbf'=¿, unicrap(j)= '?'
2020-02-02 13:43:57 default.py: l TEST i= 192, str(j)= '\xc0'=À, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 193, str(j)= '\xc1'=Á, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 194, str(j)= '\xc2'=Â, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 195, str(j)= '\xc3'=Ã, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 196, str(j)= '\xc4'=Ä, unicrap(j)= 'AA'
2020-02-02 13:43:57 default.py: l TEST i= 197, str(j)= '\xc5'=Å, unicrap(j)= 'AA'
2020-02-02 13:43:57 default.py: l TEST i= 198, str(j)= '\xc6'=Æ, unicrap(j)= 'AE'
2020-02-02 13:43:57 default.py: l TEST i= 199, str(j)= '\xc7'=Ç, unicrap(j)= 'C'
2020-02-02 13:43:57 default.py: l TEST i= 200, str(j)= '\xc8'=È, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 201, str(j)= '\xc9'=É, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 202, str(j)= '\xca'=Ê, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 203, str(j)= '\xcb'=Ë, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 204, str(j)= '\xcc'=Ì, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 205, str(j)= '\xcd'=Í, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 206, str(j)= '\xce'=Î, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 207, str(j)= '\xcf'=Ï, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 208, str(j)= '\xd0'=Ð, unicrap(j)= 'Th'
2020-02-02 13:43:57 default.py: l TEST i= 209, str(j)= '\xd1'=Ñ, unicrap(j)= 'N'
2020-02-02 13:43:57 default.py: l TEST i= 210, str(j)= '\xd2'=Ò, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 211, str(j)= '\xd3'=Ó, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 212, str(j)= '\xd4'=Ô, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 213, str(j)= '\xd5'=Õ, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 214, str(j)= '\xd6'=Ö, unicrap(j)= 'OE'
2020-02-02 13:43:57 default.py: l TEST i= 215, str(j)= '\xd7'=×, unicrap(j)= '*'
2020-02-02 13:43:57 default.py: l TEST i= 216, str(j)= '\xd8'=Ø, unicrap(j)= 'OE'
2020-02-02 13:43:57 default.py: l TEST i= 217, str(j)= '\xd9'=Ù, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 218, str(j)= '\xda'=Ú, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 219, str(j)= '\xdb'=Û, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 220, str(j)= '\xdc'=Ü, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 221, str(j)= '\xdd'=Ý, unicrap(j)= 'Y'
2020-02-02 13:43:57 default.py: l TEST i= 222, str(j)= '\xde'=Þ, unicrap(j)= 'th'
2020-02-02 13:43:57 default.py: l TEST i= 223, str(j)= '\xdf'=ß, unicrap(j)= 'ss'
2020-02-02 13:43:57 default.py: l TEST i= 224, str(j)= '\xe0'=à, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 225, str(j)= '\xe1'=á, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 226, str(j)= '\xe2'=â, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 227, str(j)= '\xe3'=ã, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 228, str(j)= '\xe4'=ä, unicrap(j)= 'ae'
2020-02-02 13:43:57 default.py: l TEST i= 229, str(j)= '\xe5'=å, unicrap(j)= 'aa'
2020-02-02 13:43:57 default.py: l TEST i= 230, str(j)= '\xe6'=æ, unicrap(j)= 'ae'
2020-02-02 13:43:57 default.py: l TEST i= 231, str(j)= '\xe7'=ç, unicrap(j)= 'c'
2020-02-02 13:43:57 default.py: l TEST i= 232, str(j)= '\xe8'=è, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 233, str(j)= '\xe9'=é, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 234, str(j)= '\xea'=ê, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 235, str(j)= '\xeb'=ë, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 236, str(j)= '\xec'=ì, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 237, str(j)= '\xed'=í, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 238, str(j)= '\xee'=î, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 239, str(j)= '\xef'=ï, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 240, str(j)= '\xf0'=ð, unicrap(j)= 'th'
2020-02-02 13:43:57 default.py: l TEST i= 241, str(j)= '\xf1'=ñ, unicrap(j)= 'n'
2020-02-02 13:43:57 default.py: l TEST i= 242, str(j)= '\xf2'=ò, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 243, str(j)= '\xf3'=ó, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 244, str(j)= '\xf4'=ô, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 245, str(j)= '\xf5'=õ, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 246, str(j)= '\xf6'=ö, unicrap(j)= 'oe'
2020-02-02 13:43:57 default.py: l TEST i= 247, str(j)= '\xf7'=÷, unicrap(j)= '/'
2020-02-02 13:43:57 default.py: l TEST i= 248, str(j)= '\xf8'=ø, unicrap(j)= 'oe'
2020-02-02 13:43:57 default.py: l TEST i= 249, str(j)= '\xf9'=ù, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 250, str(j)= '\xfa'=ú, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 251, str(j)= '\xfb'=û, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 252, str(j)= '\xfc'=ü, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 253, str(j)= '\xfd'=ý, unicrap(j)= 'y'
2020-02-02 13:43:57 default.py: l TEST i= 254, str(j)= '\xfe'=þ, unicrap(j)= 'th'
2020-02-02 13:43:57 default.py: l TEST i= 255, str(j)= '\xff'=ÿ, unicrap(j)= 'y'
N\xc3\xa5r st\xc3\xb8vet har lagt sig
N      å r st      ø vet har lagt sig 
S\xc3\xb8ren Ryge pr\xc3\xa6senterer
S      ø ren Ryge pr      æ senterer 
    """
    xc3flag = False
    xlatec3={0x82:'Euro', 0x85:'AA', 0x86:'AE', 0x98:'OE', 
        0xa0:'',
        0xa1:'', 0xa2:'c', 0xa3:'L', 0xa4:'o',
        0xa5:'aa', 0xa6:'ae', 0xa7:'s', 0xa8:'..',
        0xa9:'c', 0xaa:'a', 0xab:'<<', 0xac:'-',
        0xad:'-', 0xae:'R', 0xaf:'_', 
        0xb0:'deg',
        0xb1:'+/-', 0xb2:'^2', 0xb3:'^3', 0xb4:"'",
        0xb5:'m', 0xb6:'oe', 0xb7:'*', 0xb8:'oe',
        0xb9:'^1', 0xba:'^0', 0xbb:'>>', 
        0xbc:'1/4', 0xbd:'1/2', 0xbe:'3/4', 0xbf:'?',
        0xc0:'A', 0xc1:'A', 0xc2:'A', 0xc3:'', 0xc4:'AA', 0xc5:'AA',
        0xc6:'AE', 0xc7:'C',
        0xc8:'E', 0xc9:'E', 0xca:'E', 0xcb:'E',
        0xcc:'I', 0xcd:'I', 0xce:'I', 0xcf:'I',
        0xd0:'Th', 0xd1:'N',
        0xd2:'O', 0xd3:'O', 0xd4:'O', 0xd5:'O', 0xd6:'OE', 
        0xd7:'*', 
        0xd8:'OE',
        0xd9:'U', 0xda:'U', 0xdb:'U', 0xdc:'U',
        0xdd:'Y', 0xde:'th', 0xdf:'ss',
        0xe0:'a', 0xe1:'a', 0xe2:'a', 0xe3:'a', 0xe4:'ae', 0xe5:'aa',
        0xe6:'ae', 0xe7:'c',
        0xe8:'e', 0xe9:'e', 0xea:'e', 0xeb:'e',
        0xec:'i', 0xed:'i', 0xee:'i', 0xef:'i',
        0xf0:'th', 0xf1:'n',
        0xf2:'o', 0xf3:'o', 0xf4:'o', 0xf5:'o', 0xf6:'oe', 0xf7:'/', 0xf8:'oe',
        0xf9:'u', 0xfa:'u', 0xfb:'u', 0xfc:'u',
        0xfd:'y', 0xfe:'th', 0xff:'y',
        }
    xlate={0x82:'Euro', 0x85:'AA', 0x86:'AE', 0x98:'OE', 
        0xa0:'',
        0xa1:'', 0xa2:'c', 0xa3:'L', 0xa4:'o',
        0xa5:'aa', 0xa6:':', 0xa7:'s', 0xa8:'..',
        0xa9:'c', 0xaa:'a', 0xab:'<<', 0xac:'-',
        0xad:'-', 0xae:'R', 0xaf:'_', 
        0xb0:'deg',
        0xb1:'+/-', 0xb2:'^2', 0xb3:'^3', 0xb4:"'",
        0xb5:'m', 0xb6:'pi', 0xb7:'*', 0xb8:'oe',
        0xb9:'^1', 0xba:'^0', 0xbb:'>>', 
        0xbc:'1/4', 0xbd:'1/2', 0xbe:'3/4', 0xbf:'?',
        0xc0:'A', 0xc1:'A', 0xc2:'A', 0xc3:'', 0xc4:'AA', 0xc5:'AA',
        0xc6:'AE', 0xc7:'C',
        0xc8:'E', 0xc9:'E', 0xca:'E', 0xcb:'E',
        0xcc:'I', 0xcd:'I', 0xce:'I', 0xcf:'I',
        0xd0:'Th', 0xd1:'N',
        0xd2:'O', 0xd3:'O', 0xd4:'O', 0xd5:'O', 0xd6:'OE', 
        0xd7:'*', 
        0xd8:'OE',
        0xd9:'U', 0xda:'U', 0xdb:'U', 0xdc:'U',
        0xdd:'Y', 0xde:'th', 0xdf:'ss',
        0xe0:'a', 0xe1:'a', 0xe2:'a', 0xe3:'a', 0xe4:'ae', 0xe5:'aa',
        0xe6:'ae', 0xe7:'c',
        0xe8:'e', 0xe9:'e', 0xea:'e', 0xeb:'e',
        0xec:'i', 0xed:'i', 0xee:'i', 0xef:'i',
        0xf0:'th', 0xf1:'n',
        0xf2:'o', 0xf3:'o', 0xf4:'o', 0xf5:'o', 0xf6:'oe', 0xf7:'/', 0xf8:'oe',
        0xf9:'u', 0xfa:'u', 0xfb:'u', 0xfc:'u',
        0xfd:'y', 0xfe:'th', 0xff:'y', 
        }
    r = ''
    unitext = unitext.replace('\xef\xbb\xbf','')   ### Remove: byte order mark (BOM)
    for i in unitext:
        if ord(i) == 0xc3:
            xc3flag = True
        else:
            if xc3flag == True:
                ###if xlatec3.has_key(ord(i)):
                if ord(i) in xlatec3:
                    r += xlatec3[ord(i)]
                elif ord(i) >= 0x80:
                    pass
                else:
                    r += str(i)
                xc3flag = False
            else:
                ###if xlate.has_key(ord(i)):
                if ord(i) in xlate:
                    r += xlate[ord(i)]
                elif ord(i) >= 0x80:
                    pass
                else:
                    r += str(i)
    return r

def latin1_to_ascii_forceOLD(unicrap):
    """This takes a UNICODE string and replaces Latin-1 characters with
        something equivalent in 7-bit ASCII. It returns a plain ASCII string. 
        This function makes a best effort to convert Latin-1 characters into 
        ASCII equivalents. It does not just strip out the Latin-1 characters.
        All characters in the standard 7-bit ASCII range are preserved. 
        In the 8th bit range all the Latin-1 accented letters are converted 
        to unaccented equivalents. Most symbol characters are converted to 
        something meaningful. Anything not converted is deleted.
    """ 
    
    xlate={0x82:'Euro', 0x85:'Aa', 0x86:'Ae', 0x98:'Oe', 0xc0:'A', 0xc1:'A', 0xc2:'', 0xc3:'', 0xc4:'A', 0xc5:'A',
        0xc6:'Ae', 0xc7:'C',
        0xc8:'E', 0xc9:'E', 0xca:'E', 0xcb:'E',
        0xcc:'I', 0xcd:'I', 0xce:'I', 0xcf:'I',
        0xd0:'Th', 0xd1:'N',
        0xd2:'O', 0xd3:'O', 0xd4:'O', 0xd5:'O', 0xd6:'O', 0xd7:'x', 0xd8:'O',
        0xd9:'U', 0xda:'U', 0xdb:'U', 0xdc:'U',
        0xdd:'Y', 0xde:'th', 0xdf:'ss',
        0xe0:'a', 0xe1:'a', 0xe3:'a', 0xe4:'a', 0xe5:'a',
        0xe6:'ae', 0xe7:'.0xe7.',
        0xe8:'e', 0xe9:'e', 0xea:'e', 0xeb:'e',
        0xec:'i', 0xed:'i', 0xee:'i', 0xef:'i',
        0xf0:'th', 0xf1:'n',
        0xf2:'o', 0xf3:'o', 0xf4:'o', 0xf5:'o', 0xf6:'o', 0xf8:'o',
        0xf9:'u', 0xfa:'u', 0xfb:'u', 0xfc:'u',
        0xfd:'y', 0xfe:'th', 0xff:'y',0xa0:'a',
        0xa1:'a', 0xa2:'.0xa2.', 0xa3:'', 0xa4:'a',
        0xa5:'aa', 0xa6:'ae', 0xa7:'s', 0xa8:'u',
        0xa9:'e', 0xaa:'e', 0xab:'<<', 0xac:'',
        0xad:'-', 0xae:'R', 0xaf:'_', 0xb0:'d',
        0xb1:'+/-', 0xb2:'^2', 0xb3:'^3', 0xb4:"'",
        0xb5:'m', 0xb6:'o', 0xb7:'*', 0xb8:'oe',
        0xb9:'^1', 0xba:'^o', 0xbb:'>>', 
        0xbc:'u', 0xbd:'1/2', 0xbe:'3/4', 0xbf:'?',
        0xd7:'*', 0xf7:'/'
        }
    r = ''
    for i in unicrap:
        if ord(i) in xlate:
            r += xlate[ord(i)]
        elif ord(i) >= 0x80:
            pass
        else:
            r += str(i)
    
    return r

def imageUrlicon(imageUrl,cat,ext):
    #print 'recordings.py imageUrlicon(imageUrl,cat,ext)'
    iurl=icon(cat)
    #print repr(iurl)
    if iurl == '':
        return imageUrl + 'ntvlogo' + ext
    #print iurl.lower()[0] 
    if iurl.lower()[0] =='h':
        return iurl
    else:
        return imageUrl + 'ntvlogo' + ext

def icon(oldicon):
    #print repr(ADDON.getSetting('Use2014Icons').lower())
    #print repr('true')
    if not ADDON.getSetting('Use2014Icons').lower()=='true':
        return oldicon
    #print 'Exchange DR1(183->147) with DR1 HD(508->413) Krogsbell 2014-12-20
    
    """"
    Icons found with this lookup: Krogsbell 2015-02-15
    http://www.ntv.mx/res/content/tv/<no>.png
    2   Itv
    3   Itv 2
    4   BBC ONE
    5   BBC TWO
    7   SKY 1
    8   SKY Movies Action & Adventure
    9   SKY Comedy
    10  SKY Movies Sci Fi & Horror
    11  SKY Movies Sci Fi & Horror
    12  SKY Sports 1
    13  SKY Sports 3
    14  SKY Sports F1
    15  ESPN
    17  SKY News
    26  SKY Movies Drama & Romance
    27  SKY Movies Family
    29  SKY Movies Modern Great
    30  SKY Movies Premiere
    33  SKY Movies Showcase
    39  SKY Sports 2
    40  SKY 2
    43  Animal Planet   310 + 55 *
    44  Discovery Channel   56 + 306 *
    51  SKY Sports 4
    52  SKY Sports News
    54  FOX News
    56  National Geographic Channel
    57  SKY Movies Chrime & Thriller
    59  Itv 4
    60  Five
    61  5USA
    63  Movies4men
    64  Aljazeera
    65  4 (build of sticks)
    79  Gold (in a circle)
    80  Y Yesterday
    81  MTV
    82  VHR 71
    83  VIVA    72
    84  Alibi
    93  SKY Movies Select
    94  SKY Atlantic
    96  Discovery History   78 *
    97  Sc Discovery Science    79 *
    99  Discovery Home & Health 80 *
    100 Eden
    101 Comedy Channel
    102 Fox
    106 4E (E within 4)
    108 4More
    123 TCM Turner Classic Movies
    125 5*
    126 4Film   109 *
    135 NickJR
    137 Nickelodeon
    138 N TV Norge  100 *
    139 2 Bliss
    141 STV 1   91 *
    142 STV 2   104*
    143 4 Guld (in a star)  105 *
    146 2 Filmkanalen
    153 2
    157 4 Sport 119 *
    159 TV2 Lorry
    164 BBC News
    167 NRK 1   127 *
    168 NRK 2   128 *
    169 NRK 3   129 *
    170 3   140 + 141
    171 3 Puls Viasat
    175 3 tv3.se
    177 6 in circle
    179 4 in quadrant   125 *
    183 DR1 147 *
    184 DR2 148 *
    187 TV2 zulu *
    188 TV2 charlie *
    192 Dave
    197 At The Races
    198 Racing UK   Pure Racing Entertainment
    199 BT Sport1
    201 BT Sport2
    202 Box Nation
    204 TLC
    207 SETANTA IRELAND
    208 SETANTA SPORTS
    209 Aljazeera +6
    210 Aljazeera +7
    211 Aljazeera +8
    212 Aljazeera +9
    213 Aljazeera +5
    214 Bein Sports 1
    215 Bein Sports 2
    216 Bein Sports 3
    217 Bein Sports 4
    218 Bein Sports 10
    219 H History UK
    224 Virgin
    241 TNT HD
    252 RT Russia Today
    273 Gulli
    282 DR K    230 *
    283 DR Ultra    231 *
    286 6 on blue background
    290 H2
    291 DBC Drama
    292 Pick TV
    294 Euronews
    295 BBC News
    296 Cartoonito
    297 SKY Arts 2
    298 SKY Movies Disney
    299 Itv 3+1
    303 SKY Arts 1
    304 SKY Living
    305 Good Food
    309 TV2 Fri 261 *
    310 3+ Viasat   262 *
    315 FEM
    316 SKY Sports 1 HD
    317 SKY Sports 2 HD
    318 SKY Sports 4 HD
    319 SKY Sports News HD
    320 SKY Sports 3 HD
    321 SKY Sports F1 HD
    330 OSN Sports 3
    331 OSN Sports 4
    333 Fox Sports 1 HD
    336 TSN 2 HD
    337 Sports Net World HD
    339 Sports Net One HD
    340 Bein Sport HD
    341 CTV HD
    341 HBO HD
    343 NBA  TV High Definition
    344 NBC & N HD
    http://www.ntv.mx/res/content/tv/400.png
    http://www.ntv.mx/res/content/tv/478.png
    115 http://cloud.yousee.tv/static/img/logos/Large_TV2_ny.png
    136 http://cloud.yousee.tv/static/img/logos/Large_TV2_NEWS.png
    259 http://cloud.yousee.tv/static/img/logos/Large_DR_3.png
    249     http://cloud.yousee.tv/static/img/logos/IK_dk4.png
    """
    iconold =['71','72','115','136','259','249','99','303','412','245','267','298','227','141','125','127','128','129','119','105','104','91','100','109','78','79','80','306','56','55','310','115','235','140','240','138','231','131','230','261','137','148','262','147','413']
    iconnew=['82','83','a','b','c','d','139','204','141','56','315','44','44','170','179','167','168','169','157','143','142','141','138','126','96','97','99','44','44','43','43','155','287','170','294','187','283','171','282','309','188','184','310','183','183']
    i = 0
    r = ''
    while i < len(iconold) and r =='':
        if oldicon==iconold[i]:
            r = iconnew[i]
        i += 1
    #print r
    #r = ''
    #for i in oldicon:
    #   if xlate.has_key(str(i)):
    #       r += xlate[str(i)]
    #       print 'recordings.py icon(oldicon) %s--> icon= %s' %(str(repr(oldicon)),str(repr(r)))
    if r=='':
        r = ''
    elif r=='a':
        return 'http://cloud.yousee.tv/static/img/logos/Large_TV2_ny.png'
    elif r=='b':
        return 'http://cloud.yousee.tv/static/img/logos/Large_TV2_NEWS.png'
    elif r=='c':
        return 'http://cloud.yousee.tv/static/img/logos/Large_DR_3.png'
    elif r=='d':
        return 'http://cloud.yousee.tv/static/img/logos/IK_dk4.png'
    #   else:
    #       r += str(i)
    #print 'recordings.py icon(oldicon) %s--> icon= %s' %(str(repr(oldicon)),str(repr(r)))
    return r
    
def stringtoargument(txtstring):
    return txtstring
    txtstring= txtstring.replace('\n','..NewLine..').replace(',','..Comma..').replace(' ','AAabBB').replace('?','aAabBb').replace('=','BBabAA').replace(',','###').replace('&','AaAaA').replace('\n','NlNlNl')
    return txtstring
    
def argumenttostring(txtstring):
    return txtstring
    txtstring= txtstring.replace('..NewLine..','\n').replace('..Comma..',',').replace('AAabBB',' ').replace('aAabBb','?').replace('BBabAA','=').replace('###',',').replace('AaAaA','&').replace('NlNlNl','\n')
    return txtstring

def addRecordingPlanned(cat, startDate, endDate, recordname, alarmname, description, playchannel, DB='default',uri='url'):
    log('err addRecordingPlanned(cat= %r, startDate= %r, endDate= %r, recordname= %r, alarmname= %r, playchannel= %r, DB= %r,uri= %r)' % (cat, startDate, endDate, recordname, alarmname, playchannel, DB, uri))
    added = False
    if type(cat) in [str] and '&' in cat and 1==0:   ###2020-02-25 keep all commands (1==0)
        cat = cat.split('&')[0]    ### Remove trailing commands from url in cat if & in cat 2020-01-29
    startDate = parseDate(startDate).replace(second=0, microsecond=0)  ### 2021-02-18
    endDate   = parseDate(endDate).replace(second=0, microsecond=0)
    ###startDate = parseDate(startDate)
    ###endDate   = parseDate(endDate)
    log('err addRecordingPlanned(cat= %r, startDate= %r, endDate= %r)' % (cat, startDate, endDate))
    if endDate < startDate:
        endDate = startDate  
    log('addRecordingPlanned DB= %r' % DB)
    if playchannel == cat:
        playchannel = EPG_ChannelFromCat(cat)  ### 2018-07-09
    if playchannel == '' and 'http' == cat.lower()[4:]:
        playchannel = 'VOD'
    if DB == 'default':
        log('addRecordingPlanned using default database')
        conn      = getConnection()
        conn.text_factory = str  ### 2016-04-30 TEST
        c         = conn.cursor()
    else:
        c = DB
    log('addRecordingPlanned(cat= %r, startDate= %r, endDate= %r, recordname= %r, alarmname= %r, description= %r, playchannel= %r)' % (cat, startDate, endDate, recordname, alarmname, description, playchannel))
    try:
        c.execute("INSERT OR REPLACE INTO recordings_adc(cat, name, start, end, alarmname, description, playchannel) VALUES(?, ?, ?, ?, ?, ?, ?)", [cat, recordname, str(startDate), str(endDate), alarmname, description, playchannel])
        added = True
    except Exception as e:
            pass
            log('addRecordingPlanned FAILED cat= %r ERROR= %r' % (cat,e))
    if DB == 'default':
        conn.commit()
        c.close()
    return added

def updateRecordingPlanned(alarmname, name, newdescription=''):
    #print 'recordings.py updateRecordingPlanned(alarmname= %s, name= %s)' %(repr(alarmname), repr(name))
    try:
        conn = getConnection()
        c    = conn.cursor()
        c4   = c.execute("SELECT * FROM recordings_adc WHERE alarmname=?",  [alarmname])
        recordingsSelected = c4.fetchall()
        if len(recordingsSelected) > 0:
            for index in range(0, len(recordingsSelected)): 
                cat       = recordingsSelected[index][0]
                nameOLD      = recordingsSelected[index][1]
                startDate = recordingsSelected[index][2].split('.')[0]  ###207-09-30
                endDate   = recordingsSelected[index][3].split('.')[0]  ###207-09-30
                alarmnameOLD = recordingsSelected[index][4]
                description = recordingsSelected[index][5]
                if newdescription != '':  ### 2018-12-26
                    newdescription += '\n\n' + description
                else:
                    newdescription = description
                playchannel = recordingsSelected[index][6]
                if playchannel == cat:
                    playchannel = EPG_ChannelFromCat(cat)  ### 2018-07-09
                c4.execute("DELETE FROM recordings_adc WHERE alarmname=?",  [alarmname])
                c4.execute("INSERT OR REPLACE INTO recordings_adc(cat, name, start, end, alarmname, description, playchannel) VALUES(?, ?, ?, ?, ?, ?, ?)", [cat, name, startDate, endDate, alarmname, newdescription, playchannel])
        conn.commit()
        #print 'recordings.py conn.commit OK'
    except:
        pass
        #print 'recordings.py conn.commit failed!'
    c.close()
    xbmc.executebuiltin("Container.Refresh")

def delRecordingPlanned(cat, startDate, endDate, recordname):
    startDate = startDate.split('.')[0]
    endDate = endDate.split('.')[0]
    log('err delRecordingPlanned(cat= %r, startDate= %r, endDate= %r, recordname= %r)' % (cat, startDate, endDate, recordname))
    ### recordings_adc(cat, name, start, end, alarmname, description, playchannel)
    conn = getConnection()
    c    = conn.cursor()
    c4=c.execute("SELECT * FROM recordings_adc WHERE cat=? AND name=? AND start=? AND end=?", [cat, recordname, startDate, endDate])
    ###c4=c.execute("SELECT * FROM recordings_adc WHERE cat=? AND name=? AND start=?", [cat, recordname, startDate])
    recordingsSelected = c4.fetchall()
    log('err delRecordingPlanned(len(recordingsSelected= %r))' % (len(recordingsSelected)))
    for index in range(0, len(recordingsSelected)): 
        #cat       = recordingsSelected[index][0]
        name       = recordingsSelected[index][1]
        #startDate = recordingsSelected[index][2]
        endDateXX  = recordingsSelected[index][3]
        
        alarmname = recordingsSelected[index][4]
        Recordings = ADDON.getSetting('Recordings').replace(alarmname,'')
        ADDON.setSetting('Recordings',Recordings)
        log('DELETE FROM recordings_adc WHERE alarmname= %r and end= %r' % (alarmname,endDateXX))
        now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        ###xbmcgui.Dialog().ok(ADDONname, 'startDate= %r' % startDate, 'now= %r' % now)
        RECURSIVEMARKER = 'Recursive:'
        LastView = ADDON.getSetting('LastView')  ###, 'RECORDINGSPLANNED')
        if startDate > now or (RECURSIVEMARKER in recordname and LastView=='RECORDINGSPLANNED'):  ### 2019-01-11 
            c4.execute("DELETE FROM recordings_adc WHERE alarmname=? and end=?",  [alarmname,endDateXX]) ### 2018-09-04 delete only future programs
        xbmc.executebuiltin('CancelAlarm(%s,True)' % alarmname)
    conn.commit()   
    c.close()

def modifyRecordingPlanned(cat, startDate, endDate, recordname, description):
    try:
        startDate = startDate.split('.')[0]
        endDate = endDate.split('.')[0]
    except:
        pass
    log('modifyRecordingPlanned (cat= %r, startDate= %r, endDate= %r, recordname= %r, description= %r)' % (cat, startDate, endDate, recordname, description))
    startDate = parseDate(startDate)
    endDate   = parseDate(endDate)
    conn      = getConnection()
    c         = conn.cursor()
    ###recordingsSelected = c.fetchall()   ###2020-04-07 
    ###for rec in recordingsSelected:
    ### utils.logdevarray('modifyRecordingPlanned-recordingsSelected', repr(rec[0]))
    dialog = xbmcgui.Dialog()
    log('cat recordingsSelected= %r' % cat)
    
    c1=c.execute("SELECT * FROM recordings_adc WHERE cat=? AND name=?", [cat,recordname])
    recordingsSelected = c1.fetchall()
    log('c1 recordingsSelected= %r' % recordingsSelected)
    
    ###for rec in recordingsSelected:
    ###    utils.logdevarray('modifyRecordingPlanned-recordingsSelected-3', repr(rec[0]))
    ##c2=c1.execute("SELECT * FROM recordings_adc WHERE name=?",  [unicode(recordname, 'utf-8')])
    ###c2=c1.execute("SELECT * FROM recordings_adc WHERE name=?",  [recordname])
    ###recordingsSelected = c2.fetchall()
    ###for rec in recordingsSelected:
    ### utils.logdevarray('modifyRecordingPlanned-recordingsSelected-2', repr(rec[0]))
    ###c3=c2.execute("SELECT * FROM recordings_adc WHERE start=?", [startDate])
    ###recordingsSelected = c3.fetchall()
    ###for rec in recordingsSelected:
    ### utils.logdevarray('modifyRecordingPlanned-recordingsSelected-3', repr(rec[0]))
    ###c4=c3.execute("SELECT * FROM recordings_adc WHERE end=?", [endDate])
    ###recordingsSelected = c4.fetchall()
    c4 = c1
    ###for rec in recordingsSelected:
    ###    utils.logdevarray('modifyRecordingPlanned-recordingsSelected-4', repr(rec[0]))

    for index in range(0, len(recordingsSelected)): 
        cat         = recordingsSelected[index][0]
        name        = recordingsSelected[index][1]
        ###if TVguideNR == '0':  ##############################################################<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        startDateXX = parseDate(recordingsSelected[index][2])
        endDateXX   = parseDate(recordingsSelected[index][3])
        alarmname   = recordingsSelected[index][4]
        description = recordingsSelected[index][5]
        ### else:
        ###     startDateXX = parseDate(recordingsSelected[index][2])
        ###     endDateXX   = parseDate(recordingsSelected[index][3])
        ###     alarmname   = recordingsSelected[index][4]
        ###     description = recordingsSelected[index][5]
        ###log('cat= %r, name= %r, startDateXX= %r, endDateXX= %r, alarmname= %r, description= %r' % (cat, name, startDateXX, endDateXX, alarmname, description))
        
    if len(recordingsSelected) > 0:
        log('XX  name= %r, recordname= %r' % (name,recordname))
        ###recordname = unicode(name, 'utf-8')
        ###log('XXXXname= %r, recordname= %r' % (name,recordname))
        log('c4.execute(DELETE FROM recordings_adc WHERE alarmname= %r' % alarmname)
        
        try:
            cutoffdate = datetime.today().strftime("%Y-%m-%d %H:%M:%S")
            log('Modifyrecordingsplanned recordings_adc: cutoffdate= %r' % cutoffdate)
            c.execute("DELETE FROM recordings_adc WHERE alarmname=? and start>?", [alarmname,cutoffdate])  ### Only delete future recordings
        except Exception as e:
            pass
            log( 'c.execute(DELETE FROM recordings_adc WHERE alarmname=? and start>?, [alarmname,cutoffdate]= %r) failed! \nERROR= %r' % (cutoffdate,e))
        
        ###c4.execute("DELETE FROM recordings_adc WHERE alarmname=?",  [alarmname])
        xbmc.executebuiltin('CancelAlarm(%s,True)' % alarmname)
        try:
            conn.commit()
            
        except:
            pass
            
        c4.close()
        if '[COLOR orange]' in recordname:
            activatemarker = True
        else:
            activatemarker = False
        recordname = recordname.replace('[COLOR blue]','') # remove inactive marker
        recordname = recordname.replace('[COLOR green]','') # remove inactive marker
        recordname = recordname.replace('[COLOR orange]','') # remove inactive marker
        recordname = recordname.replace('[COLOR red]','') # remove inactive marker
        recordname = recordname.replace('[/COLOR]','')
        if not activatemarker:   # Just activate disabled recordings
            recordname += 'AaAa' # marker to force change of date
        recordname += 'BbBb' # marker to allow change of cat
        
        log('add(cat= %r, startDate= %r, endDate= %r, recordname= %r, description= %r)' % (cat, startDate, endDate, recordname, description))
        add(cat, startDate, endDate, recordname, description)
    else:
        dialog.ok(ADDONid + " Modify Recording planned [COLOR red]FAILED![/COLOR]", "Selected record? " + unicode(recordname, 'utf-8'),'', "How many selected: " + str(len(recordingsSelected)))
    try:
        conn.commit()
        
    except:
        pass
        
    c.close()

def ht(ts):    ### Timestamp to short human time
    if type(ts) != int:
        return ts
    dt = datetime.fromtimestamp(ts)
    ###ht = dt.strftime("%Y-%m-%d %H:%M:%S")
    ht = dt.strftime("%m-%d %H:%M")
    return ht
    
def humantime(ts):   ### Timestamp to human time
    try:
        ts = int(ts)
        dt = datetime.fromtimestamp(ts)
        ht = dt.strftime("%Y-%m-%d %H:%M:%S")
    except Exception as e:
        pass
        log('humantime(ts= %r) Error: %r' % (ts,e))
        ht = ts
    return ht

def humantimestop(dt):   ### datetime to human time with microseconds
    ###dt = datetime.fromtimestamp(ts)
    htms = dt.strftime("%f")[:3]
    ###ht = dt.strftime("%Y-%m-%d %H:%M:%S") + ',' + htms
    ht = dt.strftime("%H:%M:%S") + ',' + htms
    return ht

def dt(ts):   ### DateTime from Timestamp
    if type(ts) != int:
        return ts
    dt = datetime.fromtimestamp(ts)
    return dt
    
def ts(ds):   ### Date string to timestamp
    if type(ds) != str:
        return ds
    ###ds = "2008-11-10 17:53:59"
    time_tuple = time.strptime(ds, "%Y-%m-%d %H:%M:%S")
    ###time_tuple = (2008, 11, 12, 13, 59, 27, 2, 317, 0)
    ts = int(time.mktime(time_tuple))
    return ts
    
def finddoubletes():
    findanddeleteoverlappingepg = ADDON.getSetting('findanddeleteoverlappingepg')
    updateplanedrecordings = ADDON.getSetting('updateplanedrecordings')
    deleteddublets = 0
    dublets = 0
    updatedrecordings = 0
    if findanddeleteoverlappingepg == 'true':
        try:
            ### find dublette programs, find the newest update any programmings and then delete the oldest program
            log('finddoubletes() started')
            now = datetime.now()
            nowTS = int(time.mktime(now.timetuple()))
            ###nowTSplus = nowTS + 86400    ### 24 * 60 * 60  now+timedelta(hours=24)
            nowTSplus = nowTS + 432000   ### 5 days
            ###nowTSplus = nowTS + 7200    ### 24 * 60 * 60  now+timedelta(hours=2)  ---TEST
            conn      = getConnection()
            c         = conn.cursor()
            ###programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
            ### programs(channel TEXT, title TEXT, sub_title TEXT, start_date INTEGER, end_date INTEGER, description TEXT, categories TEXT, image_large TEXT, image_small TEXT, season TEXT, episode TEXT, is_movie TEXT, language TEXT, source TEXT, updates_id INTEGER, UNIQUE (channel, start_date, end_date))")
            ###c.execute("SELECT DISTINCT p.*, c.epg_channel FROM channelsRecursive c, programs p WHERE p.channel = c.epg_channel AND p.title = ? AND p.start_date >= ?",[program, now])
            j = 0
            ###c.execute("SELECT p.* FROM channelsRecursive c, programs p WHERE p.channel = c.epg_channel and p.start_date>? and p.start_date<?", [nowTS,nowTSplus])
            c.execute("SELECT p.* FROM channels c, programs p WHERE p.channel = c.epg_channel and p.start_date>? and p.start_date<?", [nowTS,nowTSplus])
            programs = c.fetchall()
            programs = sorted(programs, key=itemgetter('updates_id'), reverse=True)
            log('Programs in timespan= %r' % len(programs))
            for prog in programs:
                j += 1
                if j < 10:
                    log('#j %03d channel= %r, title= %r, start_date= %r, end_date= %r, updates_id= %r' % (j, prog[0], prog[1], ht(prog[3]), ht(prog[4]), ht(prog[14])))
                c.execute("SELECT * FROM programs WHERE channel=? and title=? and ((start_date<? and end_date>?) or (start_date<? and end_date>?))",  [prog[0],prog[1],prog[3],prog[3],prog[4],prog[4]])
                overlappingprograms0 = c.fetchall()
                c.execute("SELECT * FROM programs WHERE channel=? and title=? and ((start_date<=? and end_date>?) or (start_date<=? and end_date>?) or (start_date<? and end_date>=?) or (start_date<? and end_date>=?))",  [prog[0],prog[1],prog[3],prog[3],prog[4],prog[4],prog[3],prog[3],prog[4],prog[4]])
                ### < and > changed to <= and >= 2019-09-16
                overlappingprograms = c.fetchall()
                overlappingprograms = sorted(overlappingprograms, key=itemgetter('updates_id'), reverse=True)
                log('#j %r Overlappingprograms= %r:%r\nChannel= %r\nProgram= %r' % (j,len(overlappingprograms0),len(overlappingprograms),prog[0], prog[1]))  ### < and > changed to <= and >= 2019-09-16
                if len(overlappingprograms) > 0:
                    finalProg = ['channel', 'title', 'sub_title', 'start_date', 'end_date', 'description', 'categories', 'image_large', 'image_small', 'season', 'episode', 'is_movie', 'language', 'source', 'updates_id']
                    i = 0
                    log('#j %06d channel= %r, title= %r, start_date= %r, end_date= %r, updates_id= %r' % (j, prog[0], prog[1], ht(prog[3]), ht(prog[4]), ht(prog[14])))
                    
                    for overlap in overlappingprograms:
                        i += 1
                        dublets += 1
                        log('#i %06d channel= %r, title= %r, start_date= %r, end_date= %r, updates_id= %r' % (i, overlap[0], overlap[1], ht(overlap[3]), ht(overlap[4]), ht(overlap[14])))
                        try:
                            if prog[14] == None:
                                deleted = delEPGProgram(prog[0], prog[3], prog[4])
                                if deleted: deleteddublets += 1
                                log('#j %06d channel= %r, title= %r, start_date= %r, end_date= %r, updates_id= %r\nDeleted with success 1: %r' % (j, prog[0], prog[1], ht(prog[3]), ht(prog[4]), ht(prog[14]),deleted))
                                finalProg = overlap
                            elif prog[14] > overlap[14]:
                                ### The newest found
                                ### delEPGProgram(channel, start_date, end_date)
                                deleted = delEPGProgram(overlap[0], overlap[3], overlap[4])
                                if deleted: deleteddublets += 1
                                log('#i %06d channel= %r, title= %r, start_date= %r, end_date= %r, updates_id= %r\nDeleted with success 2: %r' % (i, overlap[0], overlap[1], ht(overlap[3]), ht(overlap[4]), ht(overlap[14]),deleted))
                                finalProg = prog
                            elif prog[14] < overlap[14]:
                                deleted = delEPGProgram(prog[0], prog[3], prog[4])
                                if deleted: deleteddublets += 1
                                log('#j %06d channel= %r, title= %r, start_date= %r, end_date= %r, updates_id= %r\nDeleted with success 3: %r' % (j, prog[0], prog[1], ht(prog[3]), ht(prog[4]), ht(prog[14]),deleted)) 
                                finalProg = overlap
                            elif prog[14] == overlap[14]:
                                if prog[3] < overlap[3]:
                                    finalProg = prog
                                elif prog[4] < overlap[4]: 
                                    finalProg = overlap
                        except Exception as e:
                            pass
                            log('#i %06d channel= %r, title= %r\n ERROR: %r ' % (i, overlap[0], overlap[1], e))
                    log('#j %06d channel= %r, title= %r, start_date= %r, end_date= %r, updates_id= %r\nFinal surviving program' % (j, finalProg[0], finalProg[1], ht(finalProg[3]), ht(finalProg[4]), ht(finalProg[14])))
                    if finalProg[0] != 'channel':
                        ### This is the survival EPG program - now find planned recordings for this program and update start and stop dates
                        log('This is the survival EPG program - now find planned recordings for this program and update start and stop dates')
            if updateplanedrecordings == 'true':
                ### recordings_adc(cat 0, name 1, start 2, end 3, alarmname 4, description 5, playchannel 6)
                ### programs(channel 0, title 1, sub_title 2, start_date 3, end_date 4, description 5, categories 6, image_large 7, image_small 8, season 9, episode 10, is_movie 11, language 12, source 13, updates_id 14)
                ### channels(id 0, title 1, logo 2, stream_url 3, source 4, visible 5, weight 6, favorite 7, catchup 8, epg_channel 9, description 10, updated 11, created 12)
                c.execute("SELECT * FROM recordings_adc WHERE start>? AND end<?", [humantime(nowTS),humantime(nowTSplus)])
                programs = c.fetchall()
                programs = sorted(programs, key=itemgetter('start'))
                log('Planned recordings in timespan= %r' % len(programs))
                ###c.execute("SELECT r.*, p.* FROM channels c, programs p, recordings_adc r WHERE p.title=r.name and p.channel=c.epg_channel and r.cat = c.id and p.start_date>? and p.start_date<?", [nowTS,nowTSplus]) 
                c.execute("SELECT r.*, p.* FROM programs p, recordings_adc r WHERE p.title=r.name and p.channel=r.playchannel and p.start_date>? and p.start_date<?", [nowTS,nowTSplus]) 
                programs = c.fetchall()
                programs = sorted(programs)
                log('Planned recordings/programs in timespan= %r' % len(programs))
                try:
                    startPadding = 60 * int(ADDON.getSetting('TimeBefore'))
                    endPadding   = 60 * int(ADDON.getSetting('TimeAfter'))
                    MaxTimeDifference = int(ADDON.getSetting('MaxTimeDifference')) * 60 * 60   ### Max default 2 hours difference 2019-08-30
                except:
                    startPadding = 60 * 3  ###  3 minutes
                    endPadding   = 60 * 15 ### 15 minutes
                    MaxTimeDifference = 2 * 60 * 60  ### 2 hours
                
                for prog in programs:
                    data = []
                    for index in range(0, len(prog)): 
                        data.append(prog[index])
                    log('planned recording= %r' % data)
                    ### cat 0, name 1, start 2, end 3, alarmname 4, description 5, playchannel 6, channel 0/7, title 1/8, sub_title 2/9, start_date 3/10, end_date 4/11, description 5, categories 6, image_large 7, image_small 8, season 9, episode 10, is_movie 11, language 12, source 13, updates_id 14
                    nowDS = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                    cat = data[0]
                    recordname = data[1]
                    alarmname = data[4]
                    playchannel = data[6]
                    e_start = ts(data[2])
                    e_end = ts(data[3])
                    p_start_date = data[10] - startPadding
                    p_end_date = data[11] + endPadding
                    startdate = e_start
                    enddate = e_end
                    if abs(e_start - p_start_date) < MaxTimeDifference : 
                        if e_start < p_start_date and abs(e_start - p_start_date) < MaxTimeDifference : 
                            startdate = e_start
                        else:
                            startdate = p_start_date
                    if abs(e_end - p_end_date) < MaxTimeDifference : 
                        if e_end > p_end_date : 
                            enddate = e_end
                        else:
                            enddate = p_end_date
                    if startdate != e_start or enddate != e_end:
                        description = data[5] + '\n\nStart/Stop Time changed ' + nowDS + '\nStartNEW ' + repr(startdate) + ' - ' + humantime(startdate)+ '\nStartORG ' + repr(e_start) + ' - ' + humantime(e_start)+ '\nEndNEW ' + repr(enddate) + ' - ' + humantime(enddate)+ '\nEndORG ' + repr(e_end) + ' - ' + humantime(e_end)
                        updatedrecordings += 1
                        startDate = humantime(startdate)
                        endDate = humantime(enddate)
                        delRecordingPlanned(cat, data[2], data[3], recordname)
                        addRecordingPlanned(cat, startDate, endDate, recordname, alarmname, description, playchannel)
                    
        except Exception as e:
            pass
            log('finddoubletes FAILED j= %r \nERROR= %r' % (j,e))
        log('finddoubletes ended\n Deleted %r dublet EPG Programs\n Doublets found= %r\n Updated recordings= %r' % (deleteddublets,dublets,updatedrecordings))  
        ADDON.setSetting('lastEPGimportdublets',repr(dublets))
        ADDON.setSetting('lastEPGimportdubletsdeleted',repr(deleteddublets))
        ADDON.setSetting('lastEPGimportplannedupdated',repr(updatedrecordings))
        if ADDON.getSetting('notifyduringepgupdate') == 'true':
            if updateplanedrecordings == 'true' :
                utils.notificationforced('Finddoubletes ended\nDeleted %r Updated %r' % (deleteddublets,updatedrecordings))
            else:
                utils.notificationforced('Finddoubletes ended\nDeleted %r' % (deleteddublets))
        c.close()
    return updatedrecordings
    
def updateOrigin(dbpathnew,originnew):
    conn   = sqlite3.connect(dbpathnew, timeout = 20, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    ###conn.execute('PRAGMA case_sensitive_like = true;')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    try:
        c = conn.cursor()
        c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, favorite BOLEAN, catchup BOLEAN, epg_channel TEXT, description TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (id, title, source))")
        c.execute("CREATE TABLE IF NOT EXISTS channelsRecursive(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, favorite BOLEAN, catchup BOLEAN, epg_channel TEXT, description TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (id, title, source))")
        c.execute("CREATE TABLE IF NOT EXISTS recordings_adc (cat TEXT, name TEXT, start TEXT, end TEXT, alarmname TEXT, description TEXT, playchannel TEXT, PRIMARY KEY (cat,name,start,end))")
        conn.commit()
        
        c.execute("SELECT * FROM channels WHERE source=?", [origin]) 
        channels = c.fetchall()
        if len(channels) > 0:
            for chan in channels:
                c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], originnew, chan[5], chan[6], chan[7], chan[8], chan[9], chan[10], chan[11], chan[12]])                        
        c.execute("DELETE FROM channels WHERE source=?",  [origin])
        conn.commit()
        c.close()
    except Exception as e:
        pass
        log( 'Update with new origin database failed! \nERROR= %r' % (e))
