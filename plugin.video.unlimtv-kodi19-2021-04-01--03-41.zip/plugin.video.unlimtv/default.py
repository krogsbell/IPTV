import sys

from app import App
from logger import Log

app = App()
try:
    ###reload(sys)  
    ###sys.setdefaultencoding('utf8')
    Log.log('defaultencoding= %r' % sys.getdefaultencoding())
    app.run()
except Exception as e:
    pass
    Log.log('app.run failed: %r' % e)


