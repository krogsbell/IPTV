#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
import urllib

class Parameters:

    url = None
    uri = None
    name = None
    mode = None
    icon_image = None
    date = None
    description = None
    cat = None
    start_date = None
    end_date = None
    recordname = None
    prev_mode = None

    def __init__(self):
        params = Parameters.read_parameters()

        try:
            self.url = urllib.unquote_plus(params["url"])
        except:
            pass
        try:
            self.uri = urllib.unquote_plus(params["uri"])
        except:
            pass
        try:
            self.name = urllib.unquote_plus(params["name"])
        except:
            pass
        try:
            self.icon_image = urllib.unquote_plus(params["iconimage"])
        except:
            pass
        try:
            self.mode = int(params["mode"])
        except:
            pass
        try:
            self.prev_mode = int(params["prev_mode"])
        except:
            pass

        try:
            self.cat = urllib.unquote_plus(params["cat"])
        except:
            pass
        try:
            self.date = str(params["date"])
        except:
            pass
        try:
            self.description = urllib.unquote_plus(params["description"])
        except:
            pass
        try:
            self.start_date = str(params["startDate"])
        except:
            pass
        try:
            self.end_date = str(params["endDate"])
        except:
            pass
        try:
            self.recordname = urllib.unquote_plus(params["recordname"])
        except:
            pass

    @staticmethod
    def read_parameters():
        param = []
        paramstring = sys.argv[2]
        if len(paramstring) >= 2:
            params = sys.argv[2]
            cleanedparams = params.replace('?', '').replace('& ','aMp ').replace('&%20','aMp%20') 
            if (params[len(params) - 1] == '/'):
                params = params[0:len(params) - 2]
            pairsofparams = cleanedparams.split('&')
            param = {}
            for i in range(len(pairsofparams)):
                splitparams = {}
                splitparams = pairsofparams[i].split('=',1)
                if (len(splitparams)) == 2:
                    param[splitparams[0]] = splitparams[1].replace('aMp ','& ').replace('aMp%20','&%20') 
        return param
