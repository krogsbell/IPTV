#!/usr/bin/python
# -*- coding: utf-8 -*-
class Platform:

    ###SITE = 'https://www.unlim.tv'
    ###SITE = 'https://www.touchsportstv.com'
    SITE = 'https://www.fhc-boxtv.net' 
    CODE = 'unlimtv'
    BRAND = 'FHC-BoxTV.net'
    CHANNELS_TTL = 120
    PLUGIN = 'plugin.video.' + CODE
    VERSION = '1.0'
    USER_AGENT = PLUGIN + '-XBMC-' + VERSION
    COMPRESSION = True
    COOKIE_PATH = 'cookies'
    COOKIE_FILE = CODE + '.lwp'
    LOGINPASS_FILE = CODE + '.lp'
    STORAGE_PATH = 'storage'
    STORAGE_FILE = 'channels.json'

