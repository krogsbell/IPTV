#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys,xbmcvfs,os
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import recordings
import definition

ADDON      = definition.getADDON()
ADDONname  = utils.ADDONgetAddonInfo('name')
ADDONid    = utils.ADDONgetAddonInfo('id')
ADDONrefer = utils.ADDONgetSetting('my_referral_name')
args = sys.argv  ### args[1] == 'once' or 'hourly'
module = 'categories.py'
origin = ADDONid +' available_channels'
utils.logdev(module,'errX Start')
utils.logdev(module,'errX args: '+ repr(args))
datapath   = xbmcvfs.translatePath(utils.ADDONgetAddonInfo('profile'))
progpath   = utils.ADDONgetAddonInfo('path')
referral = utils.ADDONgetSetting('my_referral_link')

def log(infotext,showlength=500):
    debug = utils.ADDONgetSetting('debug').lower()
    if debug in infotext.lower() and not debug == '':
        utils.logdev('error',module + ': ' + infotext,showlength=showlength)
    else:
        nolog = True

def getAll():   ###allCategories = categories.getAll()
def getAllCats():
    conn = getCategoriesConnection()
    c = conn.cursor()
    c.execute("SELECT categori, categoritype FROM categories  WHERE visible=1 ORDER BY categori, categoritype ASC") 
    log('1935 error getAllCategories')
    channels = c.fetchall()
    AllCats = []
    for chan in channels:
        AllCats.append([chan[0],chan[1]])
    return AllCats

def getActive():   ###activeCategories = categories.getActive()

def limitChannels(name,categoritype,categori):
    if categori != '':
        try:
            if not recordings.isCategoriAvailable(categori, categoritype) :
                recordings.addCategori(categori, categoritype, 'updateepg')
        except Exception as e:
            pass
            log('1979 recordings.addCategori %r\nERROR %r' % (categori,e))    
        try:
            if recordings.isCategoriActive(categori, categoritype) :
                return True 
            else:
                return False
        except Exception as e:
            pass
            log('1979 recordings.addCategori %r\nERROR %r' % (categori,e))   
    return True   
    
def adjustCategoryName(category_name) :
    try:
        category_name = category_name.replace('\u27be','->').replace('âž¾','->')   ### 2023-03-20 change unicode arrow
        if 'English series -' in category_name :
            category_name = category_name.split('English series -')[0]+'English series'  ### ignore text after English series
        category_name = ' '.join(category_name.split())  ## Remove doublespaces etc
        return category_name
    except Exception as e:
        pass
        return 'Category Name Error: %r' % e

"""
    ###namecharset = utils.bomTypeText(name)
    ###log('errorX utils.bomTypeText(name= %r), namecharset= %r' % (name,namecharset))
    name = name.lower()
    category = category.lower()
    channelType = channelType.lower()
    if channelType != 'live':
        log('errorX channelType not live: name= %r,channelType= %r' % (name,channelType))
        acceptcategory = utils.ADDONgetSetting('acceptvodcategory').lower()
        acceptchannelswith = utils.ADDONgetSetting('acceptvodswith').lower()
        acceptchannelswithout = utils.ADDONgetSetting('acceptvodswithout').lower()
    else:
        log('errorX channelType live: name= %r,channelType= %r' % (name,channelType))
        acceptcategory = utils.ADDONgetSetting('acceptcategory').lower()
        acceptchannelswith = utils.ADDONgetSetting('acceptchannelswith').lower()
        acceptchannelswithout = utils.ADDONgetSetting('acceptchannelswithout').lower()
    acceptcategory = acceptcategory.split(',')
    acceptchannelswith = acceptchannelswith.split(',')
    acceptchannelswithout = acceptchannelswithout.split(',')
    log('1967 errorZ limitChannels(name= %r, channelType= %r, category= %r Before test) ' % (name,channelType,category))
    if category != '' and acceptcategory != '':
        for chanc in acceptcategory:
            if chanc == category :
                log('1970 errorZ limitChannels(name= %r, channelType= %r, category= %r  KEPT from category) ' % (name,channelType,category))
                return True
    elif category != '':
        try:
            ###recordings.addCategori(categori, categoritype, source)
            recordings.addCategori(category, channelType, 'updateepg')
        except Exception as e:
            pass
            log('1979 recordings.addCategori %r\nERROR %r' % (category,e))    
            
    log('1972 errorZ limitChannels(name= %r, channelType= %r, category= %r  Ignored from category) ' % (name,channelType,category))
    if acceptchannelswith == '' :
        for chanx in acceptchannelswithout:
            if chanx != '' and chanx in name:
                log('errorZ limitChannels(acceptchannelswith= %r, name= %r, channelType= %r SKIPPED 1)' % (acceptchannelswith,name,channelType))
                return False
        log('errorZ limitChannels(acceptchannelswithout= %r, name= %r, channelType= %r Kept)' % (acceptchannelswithout,name,channelType))
        return True
    for chan in acceptchannelswith:
        if chan != '' and chan in name:
            for chanx in acceptchannelswithout:
                if chanx != '' and chanx in name:
                    log('errorZ limitChannels(acceptchannelswithout= %r, name= %r, channelType= %r SKIPPED 2)' % (acceptchannelswithout,name,channelType))
                    return False
            log('errorZ limitChannels(acceptchannelswith= %r, name= %r, channelType= %r Kept)' % (acceptchannelswith,name,channelType))
            return True
    log('errorZ limitChannels(acceptchannelswith= %r, name= %r, channelType= %r SKIPPED 3)' % (acceptchannelswith,name,channelType))
    return False
    """