#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmcplugin,xbmcgui,xbmc,xbmcaddon
import definition
ADDON = definition.getADDON()
import urllib,urllib2,sys,re,os
import utils
###import net
###from hashlib import md5  
import json
import glob
import recordings
import locking
import definition
###import sqlite3
from sqlite3 import dbapi2 as sqlite3
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
from operator import itemgetter

ADDONname  = ADDON.getAddonInfo('name')
ADDONid    = ADDON.getAddonInfo('id')
module = 'findtvguidenotifications.py'
utils.logdev(module,'Start')
utils.logdev(module,'Start' + repr(sys.argv))
"""  ### No offset on own EPG!!!
try:
    TimeZoneOffset = int(ADDON.getSetting('AdjustTVguideTimeZoneOffset'))
    if TimeZoneOffset > 24 or TimeZoneOffset < -24 :
        TimeZoneOffset = 0
except:
    pass
    TimeZoneOffset = 0
"""
TimeZoneOffset = 0
#EPG_DB = 'source.db'  Depends on actual TV Guide
RECORDS_DB = 'recordings_adc.db'
###CHANNEL_DB = 'channels.db'
CHANNEL_DB = 'recordings_adc.db'
RECURSIVEMARKER = 'Recursive:'
TVguideNR = ADDON.getSetting('tvguidenr')

dbPath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
###dbPathNTV = os.path.join(xbmc.translatePath(ADDON.getAddonInfo('path')),'resources')
dbPathNTV = dbPath
scriptTrig   = os.path.join(ADDON.getAddonInfo('path'), 'TrigTVGuide.py')

"""
def adapt_datetime(ts):
    try:
        ### TypeError is raised unless the comparison is == or !=
        if ts is None:
            return None
        return time.mktime(ts.timetuple())
    except Exception, e:
            pass
            utils.logdev('adapt_datetime(ts) FAILED 1', 'ts= %r ERROR= %r' % (ts,e))
            return None
            
def convert_datetime(ts):
        ###try:
            ### TypeError is raised unless the comparison is == , != or is
            if ts is None:
                utils.logdev('convert_datetime(ts) FAILED 1', 'ts= %r ' % (ts))
                return None
            if ts == None:
                utils.logdev('convert_datetime(ts) FAILED 2', 'ts= %r ' % (ts))
                return None
            if ts is '':
                utils.logdev('convert_datetime(ts) FAILED 3', 'ts= %r ' % (ts))
                return None
            ###utils.logdev('convert_datetime(ts) 4', 'ts= %r ' % (ts))
            Timeshift = ts
            if Timeshift is None:
                utils.logdev('convert_datetime(ts) FAILED 5', 'ts= %r ' % (ts))
                return None
            else:
            tsf = float(Timeshift)
            ###utils.logdev('convert_datetime(ts) 6', 'ts= %r ' % (ts))
            dtftsf = datetime.fromtimestamp(tsf)
            return dtftsf
        ###except Exception, e:
        ### pass
        ### utils.logdev('convert_datetime(ts) FAILED 7', 'ts= %r ERROR= %r' % (ts,e))
        ### return None
               
# http://docs.python.org/2/library/sqlite3.html#registering-an-adapter-callable
sqlite3.register_adapter(datetime, adapt_datetime)
sqlite3.register_converter('timestamp', convert_datetime)
"""
def MyChannels():
    channels = recordings.getAllChannels()
    #channelsLC = []
    #for cha in channels:
    #    channelsLC.append(cha[1].lower(),cha)
    ##channels = sorted(channels, key=itemgetter(1))
    # sorted_list = sorted(unsorted_list, key=lambda s: s.lower())
    #channelsLC = sorted(channelsLC, key=itemgetter(0))
    #channels = sorted(channels, key=lambda s: s.lower())
    channels = sorted(channels,key=lambda i:i[1].lower())  ### Sort ignore case coloum 1
    
    AllMyChannels=[]
    ### Limit search to special sources
    utils.logdev(module,'limitsources')
    limitsourcesSQ = recordings.getAllChannelSources()
    utils.logdev(module,'limitsources= %r' % limitsourcesSQ)
    limitsources = []
    for sourceSQ in limitsourcesSQ:
        if not ADDONid in sourceSQ[0]:
            limitsources.append(sourceSQ[0])
    ##limitsources = ['IPTV','Rytec']
    if len(limitsources) != 1:
        limitsources = sorted(limitsources)    # sort alphabetically
        limitsource = limitsources[xbmcgui.Dialog().select('Select Source for EPG', limitsources)]
    else:
        limitsource = limitsources[0]
    utils.logdev(module,'limitsource= %r' % limitsource)
    for field in channels:
        cat          = field[0]
        name         = field[1]    ###.encode("utf-8")
        iconimage    = field[2]
        url          = field[3]
        source       = field[4]
        if '-' in source:
            sourceID = source.split('-')[0].strip()
        elif '.' in source:
            sourceID = source.split('.')[2].split(' ')[0].strip()
        else:
            sourceID = field[4]
        visible      = field[5]
        weight       = field[6]
        ###if not source == ADDONid:
        ### utils.logdev(module, 'source= %s, module= %s' % (source,module))
        ###if source == ADDONid and not '/movie/' in url:   
        if not '/movie/' in url and not sourceID == ADDONid and not sourceID == ADDONid + ' available_channels':
            displaychannelnumber = (name + ' (' +cat+' - ' + sourceID + ')\n' )
            if source == limitsource: 
                AllMyChannels.append(displaychannelnumber)
        
    return AllMyChannels

def MyPlayChannels():
    channels=recordings.getAllChannels()
    channels = sorted(channels, key=itemgetter(1))
    
    AllMyChannels=[]
    
    for field in channels:
        cat          = field[0]
        name         = field[1]    ###.encode("utf-8")
        iconimage    = field[2]
        url          = field[3]
        source       = field[4]
        if '-' in source:
            source = source.split('-')[0].strip()
        elif '.' in source:
            source = source.split('.')[2].split(' ')[0].strip()
        elif ' ' in source:
            source = source.split(' ')[0].strip()   ### 2017-09-17
        else:
            source = field[4]
        visible      = field[5]
        weight       = field[6]
        ###if not source == ADDONid:
        ### utils.logdev(module, 'source= %s, module= %s' % (source,module))
        ###if source == ADDONid and not '/movie/' in url:   
        if not url == 'url' and not url == '' and not '/movie/' in url and not source == ADDONid:
            displaychannelnumber = (name + ' (' +cat+' - ' + source + ')\n' )
            AllMyChannels.append(displaychannelnumber)
        
    return AllMyChannels


def findtvguidenotifications():
    if locking.isAnyRecordLocked() and ADDON.getSetting('grabduringrecord') == 'false'  :
        locking.scanUnlockAll()
        findtvguidenotificationsend('[COLOR red]Recording - Grab disabled[/COLOR]')
        return
    elif  locking.isAnyScanLocked():
        findtvguidenotificationsend('[COLOR red]Already scanning - New grab disabled[/COLOR]')
        return
    else:
        locking.scanLock('findtvguidenotifications')
    if not locking.isScanLocked('findtvguidenotifications'):
        findtvguidenotificationsend('[COLOR red]Scan lock not working - Grab disabled[/COLOR]')
        return
    TVguide= utils.TVguide()
    Recursive = RecursiveRecordings() ## Get all recursive recordings
    utils.logdev(module, 'Recursive= %r' % (Recursive))
    #guidenotifications= ADDON.getSetting('tvguidenotifications')

    for Guide in range(0, len(TVguide)):
        
        guide = TVguide[Guide][0]
        guideDB = TVguide[Guide][1]
        
        grabGuide(guide,guideDB)
        ###try:
        utils.logdev('findrecursiverecordingsinGuide', 'guide= %r, guideDB= %r, Recursive= %r' % (guide,guideDB,Recursive))
        findrecursiverecordingsinGuide(guide,guideDB,Recursive)
        ###except Exception, e:
        ### pass
        ### utils.logdev('findrecursiverecordingsinGuide EXECUTION FAILED 1', 'guide= %s ERROR= %s' % (guide,repr(e)))
        ### findtvguidenotificationsend('[COLOR red]Grab from TV Guide FAILED![/COLOR] - guide= %s ERROR= %s'% (guide,repr(e)))
        ### return
    findtvguidenotificationsend('[COLOR green]Grab from TV Guide finished! - Use Refresh to update view[/COLOR]')


def findtvguidenotificationsend(EndText):
    # Show menuentry when finished OK - but not when run in the background
    locking.scanUnlockAll()
    utils.notificationsend(EndText)

def RecursiveRecordings():
    conn = recordings.getConnection()
    c = conn.cursor()
    c.execute("PRAGMA journal_mode = WAL")  ### 2018-01-07 Try to speed up on Windows 
    #c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE '%Recursive:%' and NOT LIKE '%COLOR orange%' COLLATE NOCASE")  # Find all active recursive recordings
    try:
        c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE ? COLLATE NOCASE",['%'+RECURSIVEMARKER+'%'])  # Find all active recursive recordings RECURSIVEMARKER
    except Exception, e:
        pass
        utils.logdev(module, 'c.execute(SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE ? COLLATE NOCASE,[RECURSIVEMARKER]) failed! \nERROR= %r' % e)
    recordingsE = c.fetchall()
    # Put recursive recordings changed last - first
    recordingsC = sorted(recordingsE, key=itemgetter(2), reverse=True)
    utils.logdev(module,'Recursive recordings= %r'%recordingsC)
    conn.commit()  ###2017-09-20
    c.close()      ###2017-09-20
    return recordingsC

def findrecursiverecordingsinGuide(guide,EPG_DB,Recursive):         
    #utils.logdev('findrecursiverecordingsinGuideCode', 'guide= %s' % guide)
    ADDONguide = xbmcaddon.Addon(id=guide)

    NTVchannels = MyPlayChannels()
    #SearchRecursiveIn: 0=Only selected channel|1=First 25 Cannels|2=First 50 Channels|3=All My Channels
    SearchRecursiveIn= int(ADDON.getSetting('SearchRecursiveIn'))
    #utils.logdev('findtvguidenotificationsGuide', 'MyNTVchannels= %s' % repr(NTVchannels))
    ###utils.logdev(module,'Start DB Create')
    """
    conv   = sqlite3.connect(os.path.join(dbPath, RECORDS_DB), timeout = 20, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conv.execute('PRAGMA foreign_keys = ON')
    conv.row_factory = sqlite3.Row
    conv.text_factory = str
    """
    conv = recordings.getDatabaseConnection(os.path.join(dbPath, RECORDS_DB))
    b = conv.cursor()
    b.execute("PRAGMA journal_mode = WAL")  ### 2018-01-07 Try to speed up on Windows 
    ###b.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)") ## 2016-05-15
    ###b.execute("CREATE TABLE IF NOT EXISTS channelslookup(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, favorite BOLEAN, catchup BOLEAN, description TEXT, PRIMARY KEY (title, source))")   ### 2017-07-24 channels --> channelslookup - Removed 2017-09-12
    ###utils.logdev(module,'Start DB Create1')
    dbPathEPG = xbmc.translatePath(ADDONguide.getAddonInfo('profile'))
    #utils.logdev('findrecursiverecordingsinGuide', 'dbPath= %s' % dbPathEPG)
    if not os.path.exists(dbPathEPG):
        #utils.logdev('findrecursiverecordingsinGuide', 'os.mkdir(dbPath) where dbPath= %s' % dbPathEPG)
        os.mkdir(dbPathEPG)
    ###utils.logdev(module,'Start DB Create2')
    """
    conn   = sqlite3.connect(os.path.join(dbPathEPG, EPG_DB), timeout = 20, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    """
    conn = recordings.getDatabaseConnection(os.path.join(dbPath, EPG_DB))
    c = conn.cursor()
    c.execute("PRAGMA journal_mode = WAL")  ### 2018-01-07 Try to speed up on Windows 
    ###c = conv.cursor()
    if TVguideNR == '0':
        utils.logdev(module,'Start DB Create WB0')
        """
        c.execute("CREATE TABLE IF NOT EXISTS programs(channel TEXT, title TEXT, sub_title TEXT, start_date TIMESTAMP, end_date TIMESTAMP, description TEXT, categories TEXT, image_large TEXT, image_small TEXT, season TEXT, episode TEXT, is_movie TEXT, language TEXT, source TEXT, updates_id INTEGER, UNIQUE (channel, start_date, end_date), FOREIGN KEY(channel, source) REFERENCES channels(id, source) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED, FOREIGN KEY(updates_id) REFERENCES updates(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
        c.execute("CREATE TABLE IF NOT EXISTS programsForHumans (channel TEXT, title TEXT, start_date TEXT, end_date TEXT, description TEXT, image_large TEXT, image_small TEXT, source TEXT, updates_id INTEGER, PRIMARY KEY (channel, updates_id), FOREIGN KEY(updates_id) REFERENCES updates(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
        c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, lineup TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
        """
        ###utils.logdev(module,'Start DB Create WB1')
        c.execute("CREATE TABLE IF NOT EXISTS programs(channel TEXT, title TEXT, sub_title TEXT, start_date INTEGER, end_date INTEGER, description TEXT, categories TEXT, image_large TEXT, image_small TEXT, season TEXT, episode TEXT, is_movie TEXT, language TEXT, source TEXT, updates_id INTEGER, UNIQUE (channel, start_date, end_date))")
        ###utils.logdev(module,'Start DB Create WB2')
        c.execute("CREATE TABLE IF NOT EXISTS programsForHumans (channel TEXT, title TEXT, sub_title TEXT, start_date TEXT, end_date TEXT, description TEXT, image_large TEXT, image_small TEXT, source TEXT, updates_id INTEGER, PRIMARY KEY (channel, updates_id))")
        ###utils.logdev(module,'Start DB Create WB3')
        ###c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, lineup TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, source))")
        c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, lineup TEXT, visible BOOLEAN, weight INTEGER, epg_channel TEXT, description TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (id, source))")
        ###utils.logdev(module,'Start DB Create WB4')
    else:
        utils.logdev(module,'Start DB Create NoWB')
        c.execute("CREATE TABLE IF NOT EXISTS programs (channel TEXT, title TEXT, start_date TIMESTAMP, end_date TIMESTAMP, description TEXT, image_large TEXT, image_small TEXT, source TEXT, updates_id INTEGER, PRIMARY KEY (channel, updates_id), FOREIGN KEY(updates_id) REFERENCES updates(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
        ###  Stop using programsForHumans
        ###c.execute("CREATE TABLE IF NOT EXISTS programsForHumans (channel TEXT, title TEXT, start_date TEXT, end_date TEXT, description TEXT, image_large TEXT, image_small TEXT, source TEXT, updates_id INTEGER, PRIMARY KEY (channel, updates_id), FOREIGN KEY(updates_id) REFERENCES updates(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
        c.execute("CREATE TABLE IF NOT EXISTS channels (id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY(id,source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
    conn.commit()
    ###conv.commit()
    for index in range(0, len(Recursive)):
        utils.logdev('findrecursiverecordingsinGuide', 'Recursive[%s]= %s X %s X %s' % (repr(index),repr(Recursive[index][0]),repr(Recursive[index][1]),repr(Recursive[index][2])))

    for index in range(0, len(Recursive)):
        utils.logdev('findrecursiverecordingsinGuide', 'index= %s' % index)
        utils.logdev('findrecursiverecordingsinGuide', 'Recursive[index][1]= %s' % repr(Recursive[index][1].replace(RECURSIVEMARKER, '').strip()))
        cat= Recursive[index][0]
        utils.logdev('findrecursiverecordingsinGuide', 'cat= %s' % repr(cat))
        # Find channel name in TV Guide 1. saved conversion 2. name as used i NTV
        try:
            b.execute("SELECT * FROM channels WHERE id=? and source=? and visible=?", [cat,guide,1])
            channelconvert = b.fetchall()
            utils.logdev('findrecursiverecordingsinGuide', 'channelconvert= %s' % repr(channelconvert))
        except:
            pass
            channelconvert = []
        if len(channelconvert) == 1:
            channel= channelconvert[0][1]
            utils.logdev('findrecursiverecordingsinGuide', 'Converted: cat= (%s) channel= %s' % (repr(cat),repr(channel)))
        else:
            channel= recordings.ChannelName(cat)
            utils.logdev('findrecursiverecordingsinGuide', 'LookedUp: cat= (%r) channel= %r, len(channelconvert)= %r' % (cat,channel,len(channelconvert)))
        #utils.logdev('findrecursiverecordingsinGuide', 'cat= (%s) channel= %s' % (repr(channel),repr(channel)))
        # Find id from TV Guide channel name
        #c.execute("SELECT * FROM channels")
        #channelconvert = c.fetchall()
        utils.logdev('findrecursiverecordingsinGuide', 'channelconvert= %s' % repr(channelconvert))
        try:
            c.execute("SELECT * FROM channels WHERE title=? and visible=? COLLATE NOCASE", [channel,1])
            channelconvert = c.fetchall()
            utils.logdev('findrecursiverecordingsinGuide', 'channelconvert= %s' % repr(channelconvert))
            channel= channelconvert[0][0]
        except:
            pass
            channel= 0
        utils.logdev('findrecursiverecordingsinGuide', 'ChannelConvert: cat= (%s) channel= %s #ofchannelconvert= %s' % (repr(cat),repr(channel),repr(len(channelconvert))))
        #utils.logdev('findrecursiverecordingsinGuide', 'channel= %s' % repr(channel))
        #c.execute("SELECT * FROM programs WHERE title LIKE ? AND channel=? COLLATE NOCASE", ['%'+(Recursive[index][1].replace(RECURSIVEMARKER, '').strip())+'%',channel])
        recursivechannel= channel  ### E! ==> E.se
        utils.logdev('findrecursiverecordingsinGuide', 'recursivechannel= %s' % repr(recursivechannel))
        ###SearchText = '%'+(Recursive[index][1].replace(RECURSIVEMARKER, '').strip())+'%'
        SearchText = (Recursive[index][1].replace(RECURSIVEMARKER, '').strip())
        try:
            SearchText = SearchText.split('^')
        except Exception, e:
            pass
            utils.logdev('findrecursiverecordingsinGuide split search text EXECUTION FAILED 3', 'SearchText= %s ERROR= %s' % (repr(SearchText),repr(e)))
            utils.logdev('findrecursiverecordingsinGuide', 'Default SearchText= %s' % repr(SearchText))
            SearchText = [SearchText.strip()]
        utils.logdev('findrecursiverecordingsinGuide', 'SearchText= %s' % repr(SearchText))
        utils.logdev('findrecursiverecordingsinGuide', 'SearchText= %s' % repr(SearchText[0]))
        utils.logdev('findrecursiverecordingsinGuide', 'len(SearchText)= %s' % repr(len(SearchText)))
        if '[COLOR orange]' in SearchText[0]:
            mark = True
            SearchText[0] = SearchText[0].replace('[COLOR orange]','',1).replace('[/COLOR]','',1)
        else:
            mark = False
        if SearchText[0] == '' or len(SearchText[0].strip()) < 3:
            utils.logdev('findrecursiverecordingsinGuide', 'SearchText is empty or less than 3 chars long')
        else:
            ###cy= c.execute("SELECT DISTINCT p.*, c.weight FROM channels c, programs p WHERE c.weight < 25 AND p.channel = c.id AND p.title = ? AND p.start_date >= ?",[program, now])
            ### channelsRecursive(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created)
            
            nowTS = time.mktime(datetime.now().timetuple())
            ###c.execute("SELECT DISTINCT p.title, p.channel, c.id, c.title, c.epg_channel, c.id, p.start_date  FROM programs p, channelsRecursive c WHERE p.title LIKE ? and p.channel = c.epg_channel and p.start_date > ? COLLATE NOCASE", ['%'+SearchText[0].strip()+'%', nowTS])
            c.execute("SELECT DISTINCT p.title, p.channel, c.id, c.title, c.epg_channel, c.id, p.start_date  FROM programs p, channels c WHERE p.channel = c.epg_channel AND p.title LIKE ?  and (c.epg_channel like '% (R)%' or c.favorite=? or c.catchup=?) and c.visible=? and p.start_date > ? COLLATE NOCASE", ['%'+SearchText[0].strip()+'%','True',1,1, nowTS])
            ###[searchText,'True',1,1,origin])...c.title like '% (D)%' or 
            ###c.execute("SELECT DISTINCT p.title, p.channel, c.id, c.title, c.epg_channel, c.id, p.start_date  FROM programs p, channels c WHERE p.title LIKE ? and p.channel = c.epg_channel and p.start_date > ? COLLATE NOCASE", ['%'+SearchText[0].strip()+'%', nowTS])
            notifications = c.fetchall()
            if len(notifications) > 0:
                for indexN in range(0, len(notifications)): 
                    ptitle=       notifications[indexN][0]
                    pchannel=     notifications[indexN][1]
                    cid=          notifications[indexN][2]
                    ctitle=       notifications[indexN][3]
                    cepg_channel= notifications[indexN][4]
                    cid=          notifications[indexN][5]
                    pstart_date=  notifications[indexN][6]
                    utils.logdev('findrecursiverecordingsinGuide TEST', 'Found SearchText= %r' % ('%'+SearchText[0].strip()+'%'))
                    utils.logdev('findrecursiverecordingsinGuide TEST', 'p.title= %r, \np.channel=     %r, c.id= %r, c.title= %r, \nc.epg_channel= %r \nc.id= %r \np.start_date= %r' % (ptitle, pchannel, cid, ctitle, cepg_channel, cid, time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(pstart_date))))
            else:
                utils.logdev('findrecursiverecordingsinGuide TEST', 'Nothing found: %r' % ('%'+SearchText[0].strip()+'%'))
                    
            if len(SearchText) == 1 : ##################################################################
                utils.logdev('findrecursiverecordingsinGuide', 'SearchText= %r' % ('%'+SearchText[0].strip()+'%'))
                c.execute("SELECT * FROM programs p, channelsRecursive c WHERE p.title LIKE ? and p.channel = c.epg_channel and p.start_date > ? COLLATE NOCASE", ['%'+SearchText[0].strip()+'%', nowTS])
            if len(SearchText) == 2 :  
                c.execute("SELECT * FROM programs p, channelsRecursive c WHERE p.title LIKE ? AND p.title NOT LIKE ? AND p.channel = c.epg_channel and p.start_date > ? COLLATE NOCASE", ['%'+SearchText[0].strip()+'%','%'+SearchText[1].strip()+'%', nowTS])
            if len(SearchText) == 3 :  
                c.execute("SELECT * FROM programs p, channelsRecursive c WHERE p.title LIKE ? AND p.title NOT LIKE ? AND p.title NOT LIKE ? AND p.channel = c.epg_channel and p.start_date > ? COLLATE NOCASE", ['%'+SearchText[0].strip()+'%','%'+SearchText[1].strip()+'%','%'+SearchText[2].strip()+'%', nowTS])
            if len(SearchText) > 3 :  
                c.execute("SELECT * FROM programs p, channelsRecursive c WHERE p.title LIKE ? AND p.title NOT LIKE ? AND p.title NOT LIKE ? AND p.title NOT LIKE ? AND p.channel = c.epg_channel and p.start_date > ? COLLATE NOCASE", ['%'+SearchText[0].strip()+'%','%'+SearchText[1].strip()+'%','%'+SearchText[2].strip()+'%','%'+SearchText[3].strip()+'%', nowTS])
            notifications = c.fetchall()
            utils.logdev('findrecursiverecordingsinGuide', 'notifications= %r' % notifications)
            utils.logdev('findrecursiverecordingsinGuide', 'len(notifications)= %r' % len(notifications))
            if len(notifications) > 0:
                for indexN in range(0, len(notifications)): 
                    channel= notifications[indexN][0]
                    program= notifications[indexN][1]
                    utils.logdev('findrecursiverecordingsinGuide', 'indexN= %s' % repr(indexN))
                    utils.logdev('findrecursiverecordingsinGuide', '  cat= %s' % repr(cat))
                    utils.logdev('findrecursiverecordingsinGuide', '  channel= %s' % repr(channel))
                    utils.logdev('findrecursiverecordingsinGuide', '  SearchText= %s' % repr(SearchText))
                    ###utils.logdev('findrecursiverecordingsinGuide', '  SearchNotText= %s' % repr(SearchNotText))
                    utils.logdev('findrecursiverecordingsinGuide XYZ', '  program= %s' % repr(program))
                    c.execute("SELECT DISTINCT id, title, logo, stream_url, source, visible, weight FROM channels WHERE id=? and visible=?",  [channel,1])   ### 2017-09-25 - channelsRecursive XX<== channels
                    channeldata= c.fetchall()
                    utils.logdev('findrecursiverecordingsinGuide', 'channeldata= %r' % (channeldata))
                    if len(channeldata) > 0:
                        now = time.mktime(datetime.now().timetuple())
                        ###cz= c.execute("SELECT * FROM programs WHERE channel=? AND title=? AND start_date >= ?",  [recursivechannel, program, now]) ### Recursive Only on channel in record
                        cz= c.execute("SELECT * FROM programs WHERE channel=? AND title=? AND start_date >= ?",  [channel, program, now]) ### Recursive Only on channel in record
                        utils.logdev('findrecursiverecordingsinGuide cz', '[recursivechannel= %r, channel= %r, program= %r, now= %r]' % (recursivechannel, channel, program, now))
                        programs= cz.fetchall()
                        for prog in programs:
                            progpart = []
                            for indexJ in range(0, len(prog)):
                                progpart.append(prog[indexJ])
                            utils.logdev('findrecursiverecordingsinGuideAA1', 'program= %s' % repr(progpart))
                        ###c.execute("SELECT * FROM channels WHERE epg_channel like '% (R)%'")
                        ###cy= c.execute("SELECT DISTINCT p.*, c.weight FROM channels c, programs p WHERE c.weight < 50 AND p.channel = c.id AND p.title = ? AND p.start_date >= ?",[program, now])
                        cy= c.execute("SELECT DISTINCT p.*, c.epg_channel FROM channelsRecursive c, programs p WHERE p.channel = c.epg_channel AND p.title = ? AND p.start_date >= ?",[program, now])
                        utils.logdev('findrecursiverecordingsinGuide cy', '[program= %r, now= %r]' % (program, now))
                        ### programs += cy.fetchall()   ### TEST just test original channel 2017-08-25
                        for prog in programs:
                            progpart = []
                            for indexJ in range(0, len(prog)):
                                progpart.append(prog[indexJ])
                            utils.logdev('findrecursiverecordingsinGuideAA2', 'program= %s' % repr(progpart))
                        """
                        if  not recursivechannel==channel and ((SearchRecursiveIn==0) or (SearchRecursiveIn==1 and channeldata[0][6] > 25) or (SearchRecursiveIn==2 and channeldata[0][6] > 50)) :  ### channel.weight
                            utils.logdev('findrecursiverecordingsinGuide', 'channel.weight> 25 or 50 and recursivechannel!=channel')
                            nonsense=''
                        else:
                            now = datetime.now()
                            utils.logdev('findrecursiverecordingsinGuide', 'now= %s' % repr(now))
                            utils.logdev('findrecursiverecordingsinGuide', 'SearchRecursiveIn= %s' % repr(SearchRecursiveIn))
                            #if SearchRecursiveIn==0:
                            cz= c.execute("SELECT * FROM programs WHERE channel=? AND title=? AND start_date >= ?",  [recursivechannel, program, now]) ### Recursive Only on channel in record
                            programs= cz.fetchall()
                            utils.logdev('findrecursiverecordingsinGuideA', 'programs= %s' % repr(programs))
                            if SearchRecursiveIn==1:
                                #cx= c.execute("SELECT * FROM channels WHERE weight<?",  ['25']) ### Recursive first 25 visible ###################################
                                #programs= cx.fetchall()
                                #utils.logdev('findrecursiverecordingsinGuide', '25 programs= %s' % repr(programs))
                                #cy= cx.execute("SELECT * FROM programs WHERE title=? AND start_date >= ?",  [program, now]) ### Recursive first 25 ###################################
                                cy= c.execute("SELECT DISTINCT p.*, c.weight FROM channels c, programs p WHERE c.weight < 25 AND p.channel = c.id AND p.title = ? AND p.start_date >= ?",[program, now])
                                ###cy= cx.execute('SELECT p.*, (SELECT 1 FROM notifications n WHERE n.channel=p.channel AND n.program_title=p.title AND n.source=p.source) AS notification_scheduled FROM programs p WHERE p.channel IN (\'' + ('\',\''.join(channelMap.keys())) + '\') AND p.source=? AND p.end_date > ? AND p.start_date < ?', [self.source.KEY, startTime, endTime])
                            elif SearchRecursiveIn==2:
                                cy= c.execute("SELECT DISTINCT p.*, c.weight FROM channels c, programs p WHERE c.weight < 50 AND p.channel = c.id AND p.title = ? AND p.start_date >= ?",[program, now])
                            elif SearchRecursiveIn==3:
                                cy= c.execute("SELECT * FROM programs WHERE title=? AND start_date >= ?",[program, now])  ##### All programs ######
                            else:
                                cy=c.execute("SELECT * FROM programs WHERE channel=? AND title=? AND start_date >= ?",[recursivechannel, program, now]) ### Recursive Only on channel in record
                            #cy= c.execute("SELECT * FROM programs WHERE title=?",[program])  ########### No Date - Test #########
                            programs += cy.fetchall()
                            utils.logdev('findrecursiverecordingsinGuideAA', 'programs= %s' % repr(programs))
                        """
                        NTVchannelSelect= NTVchannels
                        for prog in range(0, len(programs)):
                            try:
                                cweight= programs[prog][9]
                                utils.logdev('findrecursiverecordingsinGuideAAA', 'cweight= %s' % repr(cweight))
                            except:
                                pass
                            pchannel= programs[prog][0]
                            utils.logdev('findrecursiverecordingsinGuide', 'pchannel= %s' % repr(pchannel))
                            ptitle= programs[prog][1]
                            utils.logdev('findrecursiverecordingsinGuide', 'ptitle= %s' % repr(ptitle))
                            if TVguideNR == '0':
                                pstart_date= programs[prog][3]
                                pend_date= programs[prog][4]
                            else:
                                pstart_date= programs[prog][2]
                                pend_date= programs[prog][3]
                            utils.logdev('findrecursiverecordingsinGuide','pstart_date= %r pend_date= %r type(pstart_date)= %r' % (pstart_date,pend_date,type(pstart_date)))
                            
                            if not type(pstart_date) is int:
                                if type(pend_date) is int:
                                    utils.logdev('findrecursiverecordingsinGuide', 'pstart_date is not int and set to pend-2h= %s' % repr(pstart_date))
                                    pstart_date = datetime.fromtimestamp(pend_date) - timedelta(hours = 2)  ### If pstart is missing sub 2 hours from pend
                                    
                                else:
                                    utils.logdev('findrecursiverecordingsinGuide', 'pstart_date is not datetime and set to now= %s -3h= %s' % (repr(datetime.now()),repr(pstart_date)))
                                    pstart_date = datetime.now() - timedelta(hours = 3)  ### If pstart and pend is missing sub 3h from now making it obsolete
                            else:
                                pstart_date = datetime.fromtimestamp(pstart_date)
                            if not type(pend_date) is int:  
                                utils.logdev('findrecursiverecordingsinGuide', 'pend_date (pstart_date + 2)= %s' % repr(pend_date))
                                pend_date = pstart_date + timedelta(hours = 2)  ### If pend is missing add 2 hours
                            else:
                                pend_date = datetime.fromtimestamp(pend_date)
                            ### pstart_date and pend_date are now datetime
                            
                            if TVguideNR == '0':
                                pdescription= programs[prog][5]
                            else:
                                pdescription= programs[prog][4]
                            utils.logdev('findrecursiverecordingsinGuide XXX', 'channeldata[0][1]= %r' % (channeldata[0][1]))
                            cat= recordings.CatFromChannelName(channeldata[0][1])
                            utils.logdev('findrecursiverecordingsinGuide XXX1', 'cat= %r' % (cat))
                            cat= recordings.catFromEPGcat(cat)
                            ###cat= recursivechannel  ### 2017-09-23
                            utils.logdev('findrecursiverecordingsinGuide XXX2', ' \n             cat= %r, \nrecursivechannel= %r' % (cat,recursivechannel))
                            if cat == '0' and cat == '-1':  ## Channel from TVguide not found - ignore ## 2017-09-18
                                b.execute("SELECT * FROM channels WHERE title=? and source=? and visible=?", [channeldata[0][1],guide,1])
                                channelconvert = b.fetchall()
                                if len(channelconvert) == 0:
                                    SelectedChannel = xbmcgui.Dialog().select(guide + ': Select Channel for: ' + channeldata[0][1] + ' - ' + channeldata[0][0] + ' - ' + ptitle, NTVchannelSelect)
                                    utils.logdev('findrecursiverecordingsinGuide', 'SelectedChannel= %s' % (repr(SelectedChannel)))
                                    if SelectedChannel <> -1:
                                        try:
                                            id = NTVchannelSelect[SelectedChannel].replace(' (D)','').replace(' (VPN OR UK ONLY)','').split('(')[1].split(')')[0].split(' -')[0]  ### 2017-08-24
                                            utils.logdev('findrecursiverecordingsinGuide', 'id= %r' % id)
                                            if id != '' and id != '0' and id != 0 :
                                                b.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight) VALUES(?, ?, ?, ?, ?, ?, ?)", [id, channeldata[0][1], '', '', guide, 'True', id])

                                                utils.logdev('findrecursiverecordingsinGuide', 'id= %s' % (repr(id)))
                                                cat = id
                                                utils.logdev('findrecursiverecordingsinGuide', 'Selected cat= %s' % (repr(cat)))
                                                
                                        except Exception, e:
                                            cat = '0'
                                            pass
                                            utils.logdev('findrecursiverecordingsinGuide SelectedChannel FAILED', 'guide= %s ERROR= %s' % (guide,repr(e)))
                                    conv.commit()
                                else:
                                    cat = channelconvert[0][0]
                                    utils.logdev('findrecursiverecordingsinGuide', 'Converted cat= %s' % (repr(cat)))
                            now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                            try:
                                
                                utils.logdev('findrecursiverecordingsinGuide', 'guide= %s Recursive= %s' % (guide,Recursive[index]))
                                if type(pdescription) != str:
                                    pdescription = 'empty1'
                                if type(now) != str:
                                    now = 'empty2'
                                if type(Recursive[index][1]) != str:
                                    Recursive[index][1] = 'empty3'
                                if type(guide) != str:
                                    guide = 'empty4'
                                if type(channeldata[0][1]) != str:
                                    channeldata[0][1] = 'empty5'
                                if type(channeldata[0][0]) != str:
                                    channeldata[0][0] = 'empty6'
                                if type(ptitle) != str:
                                    ptitle = 'empty7'
                                pdescription = pdescription + ' \n\nCreated: ' + now +' \nRecursive [' + Recursive[index][1].replace(RECURSIVEMARKER, '') + '] from ' + guide + ' - ' + channeldata[0][1] + ' - ' + channeldata[0][0] + ' \n\n' + ptitle
                                pdescription = pdescription.replace('(','[').replace(')',']')
                            except Exception, e:
                                pass
                                utils.logdev('findrecursiverecordingsinGuide Description FAILED', 'guide= %s ERROR= %s' % (guide,repr(e)))
                            utils.logdev('findrecursiverecordingsinGuide', 'cat= %s' % repr(cat))
                            utils.logdev('findrecursiverecordingsinGuide', 'pdescription= %s' % repr(pdescription))
                            utils.logdev('findrecursiverecordingsinGuide', 'pend_date= %s' % repr(pend_date))
                            delta = timedelta(hours = TimeZoneOffset)
                            utils.logdev('findrecursiverecordingsinGuide', 'timedelta(hours = TimeZoneOffset)= %s' % repr(delta))
                            ###if not cat == '' :
                            utils.logdev(module,'recordings.schedule(cat= %r, pstart_date + timedelta(hours = TimeZoneOffset)= %r, pend_date + timedelta(hours = TimeZoneOffset)= %r, CcCc + program= %r, pdescription= %r)' % (cat, pstart_date + timedelta(hours = TimeZoneOffset), pend_date + timedelta(hours = TimeZoneOffset), 'CcCc' + program, pdescription))
                            if cat != '' and cat != '0' and cat != 0 :
                                utils.logdev(module,'recordings.schedule DB= %r' % c)
                                if mark:
                                    recordings.schedule(cat, pstart_date + timedelta(hours = TimeZoneOffset), pend_date + timedelta(hours = TimeZoneOffset), '*' + program, pdescription,c)   ### Disable recording
                                else:
                                    recordings.schedule(cat, pstart_date + timedelta(hours = TimeZoneOffset), pend_date + timedelta(hours = TimeZoneOffset), 'CcCc' + program, pdescription,c)
                                # Set notification in TV Guide channeldata[0][0], program, ADDON.getAddonInfo('name')
                                try:
                                    c.execute("SELECT * FROM notifications WHERE channel = ? AND program_title = ? AND source = ?",  [channeldata[0][0], program, channeldata[0][4]])
                                    notify =  c.fetchall()
                                    if len(notify) == 0 and ADDON.getSetting('updateguide')=='true':  ## Only insert if not already there and set up in settings that recursive recordings are transferred
                                        if mark:
                                            c.execute("INSERT OR REPLACE INTO notifications (channel, program_title, source) VALUES(?, ?, ?)", [channeldata[0][0], '[COLOR orange]'+program+'[/COLOR]', channeldata[0][4]])
                                        else:
                                            c.execute("INSERT OR REPLACE INTO notifications (channel, program_title, source) VALUES(?, ?, ?)", [channeldata[0][0], program, channeldata[0][4]])
                                except Exception, e:
                                    pass
                                    utils.logdev('findrecursiverecordingsinGuide not cat ==  FAILED', 'guide= %s ERROR= %s' % (guide,repr(e)))
                    
    utils.logdev('findtvguidenotifications','EMPTY programsForHumans')
    try:
        c.execute("DROP TABLE programsForHumans")
    except:
        pass
    """
    now = datetime.now()
    # Transfer programs to programsForHumans
    #utils.logdev('findtvguidenotifications','channels= %s' % (repr(programs[prog][0])))
    c.execute("SELECT * FROM channels WHERE visible")
    channels= c.fetchall()
    ###utils.logdevarray(module+ '-channels',channels)
    for chan in range(0, len(channels)):
        time.sleep(1/100)
        if channels[chan][1] == channels[chan][0]:
            humanchannel= channels[chan][0]
        else:
            humanchannel= channels[chan][1] + ' (' + channels[chan][0] + ')'
        try:
            c.execute("SELECT * FROM programs WHERE start_date >= ? AND channel=?",  [now,channels[chan][0]]) 
            programs= c.fetchall()
        except Exception, e:
            pass
            utils.logdev('findrecursiverecordingsinGuide FAILED', 'now= %r, channel= %r, ERROR= %r' % (now,channels[chan][0],repr(e)))
            ###utils.logdev('findtvguidenotifications','programs= %s' % (repr(programs)))
        for prog in range(0, len(programs)):
            #utils.logdev('findtvguidenotifications','channels= %s' % (repr(channels)))
            #utils.logdev('findtvguidenotifications','channels[0][0]= %s, channels[0][1]= %s, egual= %s' % (repr(channels[0][1]), repr(channels[0][0]), repr(channels[0][1] == channels[0][0])))
            
            c.execute("SELECT * FROM programsForHumans WHERE channel=? AND title=? AND start_date=? AND end_date=? AND description=? AND source=?", [humanchannel, programs[prog][1],str(programs[prog][2]),str(programs[prog][3]),programs[prog][4],programs[prog][7]])
            programsForHumans =  c.fetchall()
            ###utils.logdev('findtvguidenotifications','len(programsForHumans)= %s' % repr(len(programsForHumans)))
            if len(programsForHumans) == 0:  ## Only insert if not already there
                c.execute("INSERT OR REPLACE INTO programsForHumans (channel, title, start_date, end_date, description, image_large, image_small, source) VALUES(?, ?, ?, ?, ?, ?, ?, ?)", [humanchannel, programs[prog][1],str(programs[prog][2]),str(programs[prog][3]),programs[prog][4],programs[prog][2],programs[prog][3],programs[prog][7]])
    """
    conn.commit()
    conv.commit()
    c.close()
    b.close()
    
    #utils.logdev('findrecursiverecordingsinGuideCode', 'dbPath= %s' % dbPath)
    utils.logdev('findrecursiverecordingsinGuideCode EXECUTION Finished', 'guide= %s' % guide)

def adjusttvguide(conn,c,first):
    try: 
        sqlfilename= ADDON.getSetting('AdjustTVguideSqlFile')
        lineno = 0
        linemarker = '#lineno#'
        utils.logdev('adjusttvguide',repr(sqlfilename))
        sqlfile= open(sqlfilename,'r')
        line0 = sqlfile.readline()
        utils.logdev('adjusttvguide',repr(line0))
        if 'firstchannel=' in line0.lower():
            firstchannel= line0.lower().split('firstchannel=')[1].strip()
            if firstchannel != first.lower():
                line = sqlfile.readline().strip('\n')
                if linemarker in line:
                    line = line.replace(linemarker,str(lineno))   ### Automatic insert weight/linenumber
                    lineno += 1
                while line != '':
                    utils.logdev('adjusttvguide',repr(line))
                    c.execute(line)
                    line = sqlfile.readline()
                    if linemarker in line:
                        line = line.replace(linemarker,str(lineno))   ### Automatic insert weight/linenumber
                        lineno += 1
                utils.logdev('adjusttvguide','DROP TABLE programsForHumans')
                c.execute("DROP TABLE programsForHumans")
            else:
                utils.logdev('adjusttvguide','TV Guide already updated')
        else:
            utils.notificationbox('adjusttvguide: The sql file %s to adjust the TV Guide must start with: Firstchannel=' % repr(sqlfilename))
    except Exception, e:
        pass
        utils.logdev('adjusttvguide','No Adjust TV Guide SQL file or not all lines executed! ERROR= %r' % (e))
    conn.commit()   

def grabGuide(guide,EPG_DB):
    if ADDON.getSetting('DebugRecording') == 'false':
        try:
            grabGuideCode(guide,EPG_DB)
        except Exception, e:
            pass
            utils.logdev('grabGuide EXECUTION FAILED 4', 'guide= %r, ERROR= %r' % (guide,e))
    else:
        grabGuideCode(guide,EPG_DB)     


def grabGuideCode(guide,EPG_DB):        
    ###utils.logdev('grabGuideCode', 'guide= %s' % guide)
    #try:
    ADDONguide = xbmcaddon.Addon(id=guide)

    dbPathEPG = xbmc.translatePath(ADDONguide.getAddonInfo('profile'))
    ###utils.logdev('grabGuideCode', 'dbPath= %s' % dbPathEPG)
    if not os.path.exists(dbPathEPG):
        #utils.logdev('findtvguidenotifications', 'os.mkdir(dbPath) where dbPath= %s' % dbPathEPG)
        os.mkdir(dbPathEPG)
    if not os.path.exists(dbPathNTV):
        os.mkdir(dbPathNTV)
    """
    cNTV   = sqlite3.connect(os.path.join(dbPathNTV, CHANNEL_DB), timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    cNTV.execute('PRAGMA foreign_keys = ON')
    cNTV.row_factory = sqlite3.Row
    cNTV.text_factory = str
    """
    cNTV = recordings.getDatabaseConnection(os.path.join(dbPath, CHANNEL_DB))
    a = cNTV.cursor()
    a.execute("PRAGMA journal_mode = WAL")  ### 2018-01-07 Try to speed up on Windows 
    ###a.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)") ## 2016-05-15
    a.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (title, source))")
    cNTV.commit()
    ###utils.logdev('grabGuideCode', 'cNTV.commit() dbPath= %s' % dbPathEPG)
    """
    conv   = sqlite3.connect(os.path.join(dbPath, RECORDS_DB), timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conv.execute('PRAGMA foreign_keys = ON')
    conv.row_factory = sqlite3.Row
    conv.text_factory = str
    """
    conv = recordings.getDatabaseConnection(os.path.join(dbPath, RECORDS_DB))
    b = conv.cursor()
    b.execute("PRAGMA journal_mode = WAL")  ### 2018-01-07 Try to speed up on Windows 
    ##b.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)") ## 2016-05-15
    b.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (title, source))")
    conv.commit()
    ###utils.logdev('grabGuideCode', 'conv.commit() dbPath= %s' % dbPathEPG)
    """
    conn   = sqlite3.connect(os.path.join(dbPathEPG, EPG_DB), timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    """
    conn = recordings.getDatabaseConnection(os.path.join(dbPath, EPG_DB))
    c = conn.cursor()
    c.execute("PRAGMA journal_mode = WAL")  ### 2018-01-07 Try to speed up on Windows 
    ###utils.logdev('grabGuideCode', 'conXX.commit() dbPath= %s' % dbPathEPG)
    ###c.execute("CREATE TABLE IF NOT EXISTS notifications (channel TEXT, program_title TEXT, source TEXT, FOREIGN KEY(channel, source) REFERENCES channels(id, source) ON DELETE CASCADE)")
    c.execute("CREATE TABLE IF NOT EXISTS notifications (channel TEXT, program_title TEXT, source TEXT)")
    ###c.execute("CREATE TABLE IF NOT EXISTS programs (channel TEXT, title TEXT, start_date TIMESTAMP, end_date TIMESTAMP, description TEXT, image_large TEXT, image_small TEXT, source TEXT, updates_id INTEGER, PRIMARY KEY (id, updates_id), FOREIGN KEY(updates_id) REFERENCES updates(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
    ###utils.logdev('grabGuideCode', 'conXXXX.commit() dbPath= %s' % dbPathEPG)
    c.execute("CREATE TABLE IF NOT EXISTS programs (channel TEXT, title TEXT, start_date TIMESTAMP, end_date TIMESTAMP, description TEXT, image_large TEXT, image_small TEXT, source TEXT, updates_id INTEGER, PRIMARY KEY (id, updates_id))")
    ###c.execute("CREATE TABLE IF NOT EXISTS channels (id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY(id,source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
    ###utils.logdev('grabGuideCode', 'conXXXXXX.commit() dbPath= %s' % dbPathEPG)
    c.execute("CREATE TABLE IF NOT EXISTS channels (id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY(id,source))")
    conn.commit()
    ###utils.logdev('grabGuideCode', 'conn.commit() dbPath= %s' % dbPathEPG)
    ## Adjust TV Guide
    ###utils.logdev('grabGuideCode', 'SELECT * FROM channels WHERE weight=0')
    c.execute("SELECT * FROM channels WHERE weight=0")
    ###c.execute("SELECT * FROM channels")
    channels = c.fetchall()
    ###utils.logdev('grabGuideCode', 'len(channels)= %r' % len(channels))
    if len(channels) == 1:
        adjusttvguide(conn,c,channels[0][1])
    else:
        adjusttvguide(conn,c,'missing channel 0 force update')
        
    c.execute("SELECT * FROM notifications")
    notifications = c.fetchall()
    ###utils.logdev('grabGuideCode', 'notifications= %r' % notifications)
    ###utils.logdevarray('grabGuideCode-notifications', notifications)
    
    NTVchannels = MyPlayChannels() ######################################### 2017-08-25
    ###utils.logdev('grabGuideCode', 'MyNTVchannels= %r' % NTVchannels)

    #if len(NTVchannels) < 2:   ## Only Euronews is not enough (2)
    #   from operator import itemgetter
    #   a.execute("SELECT * FROM channels WHERE id=ltrim(id,'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ') ") #### id must be number!
    #   NTVchannels = a.fetchall()
    #   #utils.logdev('findtvguidenotifications', 'NTVchannels(unsorted)= %s' % repr(NTVchannels))
    #   NTVchannels = sorted(NTVchannels, key=itemgetter(1))
    #   #utils.logdev('findtvguidenotifications', 'NTVchannels= %s' % repr(NTVchannels))

    for index in range(0, len(notifications)): 
        time.sleep(1/100)
        channel= notifications[index][0]
        program= notifications[index][1]
        ###utils.logdev('grabGuideCode', 'channel= %r' % channel)
        ###utils.logdev('grabGuideCode', 'program= %r' % program)
        c.execute("SELECT DISTINCT id, title, logo, stream_url, source, visible, weight FROM channels WHERE id=? and visible=?",  [channel,1])
        channeldata= c.fetchall()
        ###utils.logdevarray('grabGuideCode-channeldata', channeldata)
        
        now = datetime.now()
        ###utils.logdev('grabGuideCode', 'now= %r' % now)
        c.execute("SELECT * FROM programs WHERE channel=? AND title=? AND start_date >= ?",  [channel, program, now])
        ####c.execute("SELECT * FROM programs WHERE title=? ",  [program]) ### TEST
        programs= c.fetchall()
        ###utils.logdevarray('grabGuideCode-programs', programs)
    
        '''
        channel= 'BBC 1 London'
        program= 'The Big Questions'
        channeldata= [(u'BBC 1 London', u'BBC One', u'http://wozboxtv.com/downloads/xmltv/logos/BBC%20One.png', None, u'xmltv', 1, 0)]
        now= datetime(2016, 2, 7, 10, 46, 51, 603477)
        programs= [(u'BBC 1 London', u'The Big Questions', datetime(2016, 2, 7, 11, 0), datetime(2016, 2, 7, 12, 0), u'Nicky Campbell presents moral and religious discussions on topical issues from King Edward VI School, Southampton.(n)', None, u'http://cdn.tvguide.co.uk/HighlightImages/Large/big_questions.jpg', u'xmltv', 1)]
        '''
    
        #NTVchannelSelect = []
        #for x in range (0,len(NTVchannels)):
        #   #try:
        #       #utils.logdev('findtvguidenotifications', 'NTVchannels[x]= %s' % (repr(NTVchannels[x])))
        #       #if isnumeric(str(NTVchannels[x])):
        #       NTVchannelSelect.append(NTVchannels[x])
        #       #utils.logdev('findtvguidenotifications', 'NTVchannelSelect= %s' % (repr(NTVchannelSelect)))
        #   #except:
        #   #   pass
        #utils.logdev('findtvguidenotifications', 'guide= %s and EPG_DB= %s' % (guide,EPG_DB))
        #utils.logdev('findtvguidenotifications', 'NTVchannelSelect= %s' % (repr(NTVchannelSelect)))
    
        NTVchannelSelect= NTVchannels
        for prog in range(0, len(programs)):
            time.sleep(1/100)
            pchannel= programs[prog][0]
            ptitle= programs[prog][1]
            if TVguideNR == '0':
                pstart_date= programs[prog][3]
                pend_date= programs[prog][4]
                pdescription= programs[prog][5]
            else:
                pstart_date= programs[prog][2]
                pend_date= programs[prog][3]
                pdescription= programs[prog][4]
            ###pstart_date= programs[prog][2]
            ###pend_date= programs[prog][3]
            ###pdescription= programs[prog][4]
            #utils.logdev('findtvguidenotifications', 'channeldata[0][1]= %s' % (repr(channeldata[0][1])))
            cat= recordings.CatFromChannelName(channeldata[0][1])
            #utils.logdev('findtvguidenotifications', 'cat= %s' % (repr(cat)))
            if cat == '0':  ## Channel from TVguide not found ##
                utils.logdev('grabGuideCode-channelconvert', '[channeldata[0][1]= %r,guide= %r]'% (channeldata[0][1],guide))
                b.execute("SELECT * FROM channels WHERE title=? and source=? and visible=?", [channeldata[0][1],guide,1])
                channelconvert = b.fetchall()
                ###utils.logdevarray('grabGuideCode-channelconvert', channelconvert)
                if len(channelconvert) == 0:
                    utils.logdev('findtvguidenotifications', 'Waiting for Select Channel for  %s' % (repr(guide + ': Select Channel for: ' + channeldata[0][1] + ' - ' + channeldata[0][0] + ' - ' + ptitle)))
                    SelectedChannel = xbmcgui.Dialog().select(guide + ': Select Channel for: ' + channeldata[0][1] + ' - ' + channeldata[0][0] + ' - ' + ptitle, NTVchannelSelect)
                    utils.logdev('findtvguidenotifications', 'SelectedChannel= %r' % (SelectedChannel))
                    if SelectedChannel <> -1:
                        try:
                            id = NTVchannelSelect[SelectedChannel].split('(')[1].split(')')[0]
                            if not id == '' and not id == '0':
                                b.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight) VALUES(?, ?, ?, ?, ?, ?, ?)", [id, channeldata[0][1], '', '', guide, 'True', id])
                                cat = id  ### 2016-06-13
                        except Exception, e:
                            pass
                            utils.logdev('grabGuide SelectedChannel <> -1 FAILED 4', 'guide= %r, ERROR= %r' % (guide,e))
                    conv.commit()
                else:
                    cat = channelconvert[0][0]
            utils.logdev('grabGuideCode-channelconvert', 'cat= %r,guide= %r]'% (cat,guide))
            now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
            utils.logdev('grabGuideCode-channelconvert', 'now= %r,guide= %r]'% (now,guide))
            pdescription = pdescription + ' \n\nCreated: ' + now + ' \nNotification from ' + guide + ' - ' + channeldata[0][1] + ' - ' + channeldata[0][0] + ' \n\n' + ptitle
            utils.logdev('grabGuideCode-channelconvert', 'pdescription= %r,guide= %r]'% (pdescription,guide))
            pdescription = pdescription.replace('(','[').replace(')',']')
            ###utils.logdev('grabGuideCode', 'cat= %s' % repr(cat))
            if not cat == '' and not cat == '0':
                ###utils.logdev('grabGuideCode', 'pdescription= %s' % repr(pdescription))
                ###utils.logdev('grabGuideCode', 'schedule(cat= %r, pstart_date + timedelta(hours = TimeZoneOffset)= %r, pend_date + timedelta(hours = TimeZoneOffset)= %r, program= %r, pdescription= %r)' % (cat, pstart_date + timedelta(hours = TimeZoneOffset), pend_date + timedelta(hours = TimeZoneOffset), program, pdescription))
                recordings.schedule(cat, pstart_date + timedelta(hours = TimeZoneOffset), pend_date + timedelta(hours = TimeZoneOffset), program, pdescription)
        
    c.close()
    b.close()
    utils.logdev('grabGuide', 'FINISHED!')
    #except:
    #   pass
    #   utils.logdev('grabGuide', 'FAILED!')

######################################################################
"""
def RecursiveRecordingsPlanned(SearchAllFavorites):
    #import recordings
    ###cat = ADDON.getSetting('SearchRecursiveIn')
    if locking.isAnyRecordLocked():
        locking.scanUnlockAll()
        return
    elif  locking.isAnyScanLocked():
        return
    else:
        locking.scanLock(SearchAllFavorites)
    if not locking.isScanLocked(SearchAllFavorites):
        return
    #utils.logdev('findrecursivetvguide.py RUNNING RecursiveRecordingsPlanned','cat= %s, SearchAllFavorites= %s' % (repr(cat), repr(SearchAllFavorites)))
    ###ADDON.setSetting('RecursiveSearch','true')
    
    conn = recordings.getConnection()
    c = conn.cursor()
    c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE '%Recursive:%' COLLATE NOCASE")  # Find all recursive recordings
    recordingsE = c.fetchall()
    # Put recursive recordings changed last - first
    recordingsC = sorted(recordingsE, key=itemgetter(2), reverse=True)
    #utils.logdev('findrecursivetvguide.py: Recursive recordings',repr(recordingsC))
    for index in range(0, len(recordingsC)):
        if isinstance(recordings.parseDate(recordingsC[index][2]), datetime.date) and isinstance(recordings.parseDate(recordingsC[index][3]), datetime.date) and 'Recursive:' in recordingsC[index][1]:
            if int(ADDON.getSetting('SearchRecursiveIn')) > 0 or ((not SearchAllFavorites == 'NotAllFavorites')and(not SearchAllFavorites == 'Once')and(not SearchAllFavorites == 'Hour')):
                if not recordingsC[index][0] in uniques:
                    findrecursiveinplaychannel(recordingsC[index][0],recordingsC[index][1],index) # Allways search channel in record
                    if ADDON.getSetting('NotifyOnSearch')=='true' and not '[COLOR orange]' in recordingsC[index][1]:
                        utils.notification('Find%s [COLOR green]complete in own channel[/COLOR]' % recordingsC[index][1])
                for cat in uniques:
                    findrecursiveinplaychannel(cat,recordingsC[index][1],index)
                if ADDON.getSetting('NotifyOnSearch')=='true' and not '[COLOR orange]' in recordingsC[index][1]:
                    utils.notification('Find%s [COLOR green]complete[/COLOR]' % recordingsC[index][1])
            else:
                findrecursiveinplaychannel(recordingsC[index][0],recordingsC[index][1],index)
                if ADDON.getSetting('NotifyOnSearch')=='true' and not '[COLOR orange]' in recordingsC[index][1]:
                    utils.notification('Find%s [COLOR green]complete[/COLOR] in selected channel: %s' % (recordingsC[index][1], recordingsC[index][0]))
    conn.commit()
    c.close()
    if ADDON.getSetting('NotifyOnSearch')=='true':
        utils.notification('Find all recursives [COLOR green]complete[/COLOR]')
    locking.scanUnlockAll()
    ###ADDON.setSetting('RecursiveSearch','false')
    return

def findrecursiveinplaychannel(cat,title,index):
    if locking.isAnyRecordLocked():
        locking.scanUnlockAll()
        return
    if '[COLOR orange]' in title:
        utils.logdev('findrecursiveinplaychannel','DISABLED: %s' % repr(title))  # Put message in LOG
        return

    name = title
    try:
        name = name.split('Recursive:')[1]
    except Exception, e:
        pass
        utils.logdev('grabGuide name.split(Recursive:)[1] FAILED ', 'guide= %r, ERROR= %r' % (guide,e))
    newname = recordings.latin1_to_ascii(name)
    newname = newname.strip()
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20')
    nowT= recordings.parseDate(datetime.today())
    
    conn = recordings.getConnection() ###################### TV Guide database
    c = conn.cursor()
    c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name CONTAINS 'Recursive:'")  ####################################################################################################
    recordingsE = c.fetchall()
    # Put recursive recordings changed last - first
    recordingsC = sorted(recordingsE, key=itemgetter(2), reverse=True)
    #utils.logdev('findrecursivetvguide.py: Recursive recordings',repr(recordingsC))
    for field in recordingsC:
        time='[COLOR yellow](%s) - [/COLOR]'%(startDate.strftime('%H:%M'))
        recordnameT = recordings.latin1_to_ascii(recordname)
        startDateT = recordings.parseDate(startDate)
        if (newname.upper() in recordnameT.upper()) and (nowT < (startDateT + timedelta(hours = TimeZoneOffset))):
            recordings.schedule(cat, startDate + timedelta(hours = TimeZoneOffset), endDate + timedelta(hours = TimeZoneOffset), recordname, description)
"""

