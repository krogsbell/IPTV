#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs,os
import datetime
import time
import utils, recordings
import net
from hashlib import md5
import json

#ADDON      = xbmcaddon.Addon(id='plugin.video.wozboxntv')
import definition
ADDON      = definition.getADDON()
module = 'recordtimeshift.py'
###timeshiftfilename = 'timeshift'
timeshiftbase = utils.ADDONgetSetting('timeshiftbase')
timeshiftfilename = timeshiftbase + '_' + datetime.datetime.today().strftime('%Y-%m-%d_%H-%M')
#xbmc.log('recordtimeshift.py: sys.argv= %s' %(str(repr(sys.argv))))
try:
    program  = sys.argv[0]
    uri           = sys.argv[1].replace('AAabBB',' ').replace('aAabBb','?').replace('BBabAA','=')
    title         = sys.argv[2]
except:
    pass
    title = 'TimeShift'
try:
    xbmc.log('recordtimeshift.py: os.environ= %s' % os.environ['OS'] ) #put in LOG
except: pass

timeshiftsetting = utils.ADDONgetSetting('timeshift')
#print timeshiftsetting
#utils.notification('TimeShift Setting = ' + repr(timeshiftsetting))
if timeshiftsetting == '0':
    #utils.notification('TimeShift %s [COLOR red]NOT enabled[/COLOR]' % (title))
    utils.notificationbox('TimeShift %s [COLOR red]NOT enabled[/COLOR]' % (title))

else:

    LoopCountMax = int(utils.ADDONgetSetting('LoopCount'))
    RecordingDisabled = False
    
    recordPath = xbmcvfs.translatePath(os.path.join(utils.ADDONgetSetting('record_path')))
    if not utils.folderwritable(recordPath):
        utils.notification('Recording %s [COLOR red]FAILED - You must set the recording path writable![/COLOR]' % title)
    else:
        nowHM=datetime.datetime.today().strftime('%H:%M:%S')
        rtmp  = uri.replace('xXx',' ').replace('###',',')
        ### timeshiftmaxtime
        timeshiftmaxtime = utils.ADDONgetSetting('timeshiftmaxtime')  ### in Minutes
        timeshiftmaxtime = int(timeshiftmaxtime) * 60
        ###cmdoption = ' -t ' +str(1*30*60)  ### TimeShift recording time .5h
        cmdoption = ' -t ' +str(timeshiftmaxtime)  ### TimeShift recording time
        if os.access('/system/vendor/bin/ffmpeg', os.X_OK):
            cmd = '/system/vendor/bin/ffmpeg -y -i '  # Use seperately installed ffmpeg program ###
        else:
            cmd = 'ffmpeg -y -i '  # Use seperately installed ffmpeg program ###
        cmd += '"' + rtmp + '"'
        cmd += ' -c copy ' + cmdoption + ' ' 
        
        recordstarttime = datetime.datetime.today().strftime('%Y-%m-%d %H-%M')
        
        timeshiftfile = recordPath + timeshiftfilename + '.ts'
        utils.ADDONsetSetting('timeshiftfile',timeshiftfile)
        utils.logdev(module,'utils.ADDONsetSetting(timeshiftfile= %r' % timeshiftfile)
        
        utils.logdev(module,'utils.ADDONgetSetting(timeshiftfile= %r' % utils.ADDONgetSetting('timeshiftfile'))
        
        cmd += '"' + timeshiftfile + '"'
    
        utils.logdev(module,'cmd= %r' % cmd)
        nowHM=datetime.datetime.today().strftime('%H:%M')
        if not RecordingDisabled:
            utils.notification('TimeShift Recording %s [COLOR green]started %s[/COLOR]' % (title, nowHM))
        
        if utils.ADDONgetSetting('os')=='11':
            subpr = utils.runCommand(cmd, LoopCount=0, libpath=None).pid
        else:
            libpath = utils.libPath()
            subpr = utils.runCommand(cmd, LoopCount=0, libpath=libpath).pid
            
        utils.logdev(module,'subpr= %r' % subpr)
        ### Popen.terminate()
        ### utils.terminateSubpr(subpr)  ### 2018-02-26  Only stop TimeShift when starting a new
        if not RecordingDisabled:
            nowHM=datetime.datetime.today().strftime('%H:%M')
            utils.logdev('TimeShift', 'Recording %s [COLOR red]complete[/COLOR] %s' % (title, nowHM))
