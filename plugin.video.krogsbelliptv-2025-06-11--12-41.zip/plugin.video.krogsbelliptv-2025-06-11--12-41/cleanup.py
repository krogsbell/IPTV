#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmc, xbmcvfs
# For Python 3.0 and later
from urllib.request import urlopen
import sys
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import definition
import utils
import recordings
import glob
import os
import locking
 
def log(infotext,showlength=500):
    module    = 'cleanup.py'
    debug = definition.ADDONgetSetting('debug').lower()
    if debug in infotext[0:25].lower() and not debug == '':
        utils.logdev('error',module + ': ' + infotext,showlength=showlength)
    else:
        nolog = True
        xbmc.log(definition.ADDONgetAddonInfo('name') + ' ' + module +': <*' + infotext[0:showlength]+'*>')
 
try:
    ADDON     = definition.getADDON()
    ADDONid   = definition.ADDONgetAddonInfo('id')
    ADDONname = definition.ADDONgetAddonInfo('name')
    datapath  = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
    progpath  = definition.ADDONgetAddonInfo('path')
    module    = 'cleanup.py'
    log('error cleanup Started')
    log('error sys.argv= %r' % sys.argv)
    alarmName = 'cleanup'
    marker    = 'once'
    try:
        marker = sys.argv[1]
    except Exception as e:
        pass
        log('30 ERROR: %r' % e)
    alarmName = alarmName + '-' + marker   
    recordings.updateAlarm(alarmName)
    log('error cleanup after updateAlarm')
    BACKUP_PATH = definition.ADDONgetSetting('backup_path')
    log('37 error BACKUP_PATH= %r' % BACKUP_PATH)
    RECORD_PATH = definition.ADDONgetSetting('record_path')
    log('37 error RECORD_PATH= %r' % RECORD_PATH)
    titext = '*.tit'
    try:
        ###path = definition.ADDONgetSetting('record_path')
        ###path = xbmcvfs.translatePath(definition.ADDONgetSetting('record_path'))
        ###log('error record_path path= %r' % path)
        files =  glob.glob(os.path.join(RECORD_PATH, titext))
        log('error  files= %r' % files)
        for f in files:
            log('error file f= %r' % f)
            fl = f.replace('.tit','.log',-1).replace('[','?').replace(']','?')
            log('error logfile fl= %r' % fl)
            ###f = f.replace('.tit','*').replace('[','?').replace(']','?')
            fa = f.replace('.tit','.???').replace('[','?').replace(']','?')  ### 2024-08-17 only files with same as .tit
            fx = f.replace('.tit','*').replace('[','?').replace(']','?') 
            log('error fa.replaced= %r' % fa)
            log('error fx.replaced= %r' % fx)
            allfiles = glob.glob(fx)
            log('error len(allfiles)= %r' % len(allfiles))
            log('error .tit file siblings: %r' % allfiles)
            allbasicfiles = glob.glob(fa)
            log('error len(allbasicfiles)= %r' % len(allbasicfiles))
            log('error .tit basic files: %r' % allbasicfiles)
            logfiles = glob.glob(fl)
            log('error .log files: %r' % logfiles)
            videoext = definition.ADDONgetSetting('extorgcollection').split(',')
            VideoExt = ''
            for vext in videoext:
                vext = '.' + vext
                log('error vext= %r' % vext)
                if VideoExt == '' :
                    for file in allbasicfiles:
                        log('error file= %r' % file)
                        extension = os.path.splitext(file)[1]
                        log('error extension= %r' % extension)
                        if extension == vext :
                            VideoExt = vext
            log('error file has video %r with ext %r' % (f,VideoExt))
            if VideoExt == '' :
                log('error logfiles= %r' % logfiles)
                logdeleted = True
                if len(logfiles) != 0 :
                    for file in logfiles:
                        log('error DELETE FILE= %r' % file)
                        filetime = datetime.fromtimestamp(os.path.getmtime(file))
                        now = (datetime.today() - timedelta(days=1))
                        log('error file time= %r, now - 1 day= %r' % (filetime,now))
                        if now >= filetime:   ### only delete if logfile is more than one day old
                            utils.copyFiles(file,BACKUP_PATH)
                            locking.deleteLockFile(file)
                            if os.path.isfile(file):
                                logdeleted = False
                                log('error log file was not deleted= %r' % (file))
                            if logdeleted:    ### only delete if logfile was deleted
                                log('error log file WAS deleted= %r' % (file))
                                for file in allfiles:
                                    log('error DELETE FILE= %r' % file)
                                    utils.copyFiles(file,BACKUP_PATH)
                                    locking.deleteLockFile(file)
                        else:
                            log('error log file not one day old and was not deleted= %r' % (file))
                else:
                    log('error log file WAS NOT found')
                    for file in allfiles:
                        log('error DELETE FILE= %r' % file)
                        filetime = datetime.fromtimestamp(os.path.getmtime(file))
                        now = (datetime.today() - timedelta(days=1))
                        log('error file time= %r, now - 1 day= %r' % (filetime,now))
                        if now >= filetime:   ### only delete if logfile is more than one day old
                            utils.copyFiles(file,BACKUP_PATH)
                            locking.deleteLockFile(file)
                            if os.path.isfile(file):
                                logdeleted = False
                                log('error log file was not deleted= %r' % file)
                        else:
                            log('error log file not one day old and was not deleted= %r' % (file))
    except Exception as  e:
        pass
        log( 'Error Exception in cleanup= %r' % e)
        
except Exception as  e:
    pass
    log( 'Exception in cleanup= %s ERROR= %s' % (repr(link),repr(e)))
log('Ended')

