firstchannel=DRx
UPDATE channels SET weight = weight + 1000 WHERE weight < 1000
UPDATE channels SET weight = #lineno# WHERE id = 'dr01_0@147054' COLLATE NOCASE
UPDATE channels SET stream_url = 'http://dr01-lh.akamaihd.net/i/dr01_0@147054/master.m3u8?b=600-3000' WHERE id = 'dr01_0@147054' COLLATE NOCASE
UPDATE channels SET epg_channel = 'DR1.dk' WHERE id = 'dr01_0@147054' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'dr02_0@147055' COLLATE NOCASE
UPDATE channels SET stream_url = 'http://dr02-lh.akamaihd.net/i/dr02_0@147055/master.m3u8?b=600-3000' WHERE id = 'dr02_0@147055' COLLATE NOCASE
UPDATE channels SET epg_channel = 'DR2.dk' WHERE id = 'dr02_0@147055' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'dr03_0@147056' COLLATE NOCASE
UPDATE channels SET title = 'DR3' WHERE id = 'dr03_0@147056' COLLATE NOCASE
UPDATE channels SET stream_url = 'http://dr03-lh.akamaihd.net/i/dr03_0@147056/master.m3u8?b=600-3000' WHERE id = 'dr03_0@147056' COLLATE NOCASE
UPDATE channels SET epg_channel = 'DR3.dk' WHERE id = 'dr03_0@147056' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'dr04_0@147057' COLLATE NOCASE
UPDATE channels SET stream_url = 'http://dr04-lh.akamaihd.net/i/dr04_0@147057/master.m3u8?b=600-3000' WHERE id = 'dr04_0@147057' COLLATE NOCASE
UPDATE channels SET epg_channel = 'DRK.dk' WHERE id = 'dr04_0@147057' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'TV2.dk' COLLATE NOCASE
UPDATE channels SET title = 'TV2 dk' WHERE id = 'TV2.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'http://tv2danmark-tv2nord-live.hls.adaptive.level3.net/tv2danmark/tv2nord/master.m3u8' WHERE id = 'TV2.dk' COLLATE NOCASE
UPDATE channels SET epg_channel = 'TV2.dk' WHERE id = 'TV2.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'TV2Charlie.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'TV2Zulu.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'TV2fri.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'TV3.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'TV3Plus.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'SkySportsF1.uk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'TV3Sport1.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'TV3Sport2.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'BBCOneHD.uk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'BBC2.uk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'ITV1London.uk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'ITV2.uk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'Showtime.no' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'SkyAtlantic.uk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'Eurosport.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'Eurosport2.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = '6eren.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'Euronews.nws' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'CMoreAction.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'CMoreFirst.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'CMoreHits.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'CMoreSeries.dk' COLLATE NOCASE
UPDATE channels SET visible = 0 WHERE weight > 0
UPDATE channels SET visible = 1 WHERE weight < #lineno#
