#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmcaddon,xbmc,xbmcvfs,os,sys,datetime,re,glob

import definition,utils
ADDON      = definition.getADDON()

datapath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
module = 'locking.py'

def log(infotext,showlength=500):
    debug = utils.ADDONgetSetting('debug').lower()
    if debug in infotext.lower() and not debug == '':
        utils.logdev('error',module + ': ' + infotext,showlength=showlength)
    else:
        nolog = True
        
"""
def log(infotext):
    if 'err' in infotext.lower():
        utils.logdev('err',module + ': ' + infotext)
    else:
        utils.logdev(module,infotext)  ### log all! 
"""        
try:
    log('err sys.argv= %r' % sys.argv)
    concurrentstreams = int(utils.ADDONgetSetting('concurrentstreams'))
except:
    pass
    concurrentstreams = 1
    log('concurrentstreams set to default value')
    
def adjustFileName(title):
    filetitle = title.replace('?', '')
    filetitle = filetitle.replace(':', '')
    filetitle = filetitle.replace('/', '')
    filetitle = filetitle.replace('+', '')
    filetitle = filetitle.replace('\\', '')
    filetitle = re.sub('[,:\\/*?\<>|"]+', '', filetitle)
    filetitle = " ".join(filetitle.split())  # Remove extra spaces from filename
    filetitle = filetitle[:100]
    log( 'adjustFileName(title)= %r\n             %r' % (title, filetitle))
    return filetitle
    
def recordLock(lockDescription):
    recordingLock = os.path.join(datapath, 'recordingLock') + adjustFileName(lockDescription) + '.txt'
    log( 'recordLock0: recordingLock= %r for %r' % (os.path.isfile(recordingLock), recordingLock))
    if os.path.isfile(recordingLock) == False: 
        # create lock file
        LF = open(recordingLock, 'w')  ### 2018-09-12  a --> w
        log('open(recordingLock, w)= %r' % LF)
        # Write to our text file the information we have provided and then goto next line in our file.
        LF.write(lockDescription + '\n')
        log('write(lockDescription)= %r' % LF)
        # Close our file so no further writing is posible.
        LF.close()
        log('close()= %r' % LF)
        ###utils.ADDONsetSetting('StopRecording','Lock: ' + lockDescription)
        
def deleteLockFile(recordingLock):
    tries    = 0
    maxTries = 10
    maxSleep = 50
    while os.path.exists(recordingLock) and tries < maxTries:
        try:
            os.remove(recordingLock)
            ###utils.ADDONsetSetting('StopRecording','unLock: ' + lockDescription)
            break
        except:
            xbmc.sleep(maxSleep)
            tries = tries + 1
            
def deleteOldLockFile(recordingLock,ageinhours):
    tries    = 0
    maxTries = 10
    maxSleep = 50
    while os.path.exists(recordingLock) and tries < maxTries:
        try:
            createdtime= os.stat(recordingLock).st_ctime
            now= datetime.datetime.today()
            if now > datetime.datetime.fromtimestamp(createdtime) +  datetime.timedelta(hours = ageinhours):
                os.remove(recordingLock)
                log('deleteOldLockFile(recordingLock= %r,ageinhours= %r)' % (recordingLock,ageinhours))
            ###utils.ADDONsetSetting('StopRecording','unLock by age: ' + lockDescription)
            break
        except:
            xbmc.sleep(maxSleep)
            tries = tries + 1
            
def recordUnlock(lockDescription):
    recordingLock = os.path.join(datapath, 'recordingLock') + adjustFileName(lockDescription) + '.txt'
    ###utils.ADDONsetSetting('StopRecording','Recording stopped: ' + lockDescription + ' ' + datetime.datetime.today().strftime('%H:%M'))
    # delete lock file
    deleteLockFile(recordingLock)
    log('recordUnlock(file= %r)' % (recordingLock))
    
def recordUnlockAll():
    lockDescription = '*'
    recordingLock = os.path.join(datapath, 'recordingLock') + lockDescription + '.txt'
    LockFiles = glob.glob(recordingLock)
    # delete lock files
    for file in LockFiles:
        deleteLockFile(file)
        log('recordUnlockAll(file= %r)' % (file))
        
def isRecordLocked(lockDescription):
    isAnyRecordLocked()
    recordingLock = os.path.join(datapath, 'recordingLock') + adjustFileName(lockDescription) + '.txt'
    if os.path.isfile(recordingLock):  # release scanlock if more thae 1 hour old
        createdtime= os.stat(recordingLock).st_ctime
        now= datetime.datetime.today()
        if now > datetime.datetime.fromtimestamp(createdtime) +  datetime.timedelta(hours = 3):
            recordUnlock(lockDescription)
            log('deleteOldLockFile(recordingLock= %r,ageinhours= %r)' % (recordingLock,3))
    return os.path.isfile(recordingLock)
    
def isAnyRecordLocked():   ### All records locked - no extra stream
    recordingLock = os.path.join(datapath, 'recordingLock') + '*.txt'
    LockFiles = glob.glob(recordingLock)
    for file in LockFiles:
        deleteOldLockFile(file,4) #Delete files more than 4 hours old
        log('deleteOldLockFile(recordingLock= %r,ageinhours= %r)' % (file,4))
    ###return (LockFiles and len(LockFiles) > 0)
    LockFiles = glob.glob(recordingLock)
    log('isAnyRecordLocked(LockFiles= %r and len(LockFiles)= %r >= concurrentstreams= %r)' %(LockFiles, len(LockFiles), concurrentstreams))
    if concurrentstreams == 0:
        return False
    else:
        return (len(LockFiles) >= concurrentstreams)
    
def RecordsLocked():
    recordingLock = os.path.join(datapath, 'recordingLock') + '*.txt'
    LockFiles = glob.glob(recordingLock)
    return LockFiles
    
def scanLock(lockDescription):
    recordingLock = os.path.join(datapath, 'scanLock') + adjustFileName(lockDescription) + '.txt'
    if os.path.isfile(recordingLock) == False: 
        # create lock file
        LF = open(recordingLock, 'a')
        # Write to our text file the information we have provided and then goto next line in our file.
        LF.write(lockDescription + '\n')
        # Close our file so no further writing is posible.
        LF.close()
        ###utils.ADDONsetSetting('StopScan','Lock: ' + lockDescription)
    
def isScanLocked(lockDescription):
    isAnyScanLocked()
    recordingLock = os.path.join(datapath, 'scanLock') + adjustFileName(lockDescription) + '.txt'
    return os.path.isfile(recordingLock)
    
def isAnyScanLocked():
    recordingLock = os.path.join(datapath, 'scanLock') + '*.txt'
    LockFiles = glob.glob(recordingLock)
    for file in LockFiles:
        deleteOldLockFile(file,5) #Delete files more than 5 hours old
        log('deleteOldLockFile(scanLock= %r,ageinhours= %r)' % (file,5))
    LockFiles = glob.glob(recordingLock)
    log('isAnyScanLocked(LockFiles= %r and len(LockFiles)= %r >0)' %(LockFiles, len(LockFiles)))
    return (len(LockFiles) > 0)
    
def scanUnlockAll():
    lockDescription = '*'
    recordingLock = os.path.join(datapath, 'scanLock') + lockDescription + '.txt'
    LockFiles = glob.glob(recordingLock)
    # delete lock files
    for file in LockFiles:
        deleteLockFile(file)
        log('scanUnlockAll(file= %r)' % (file))
        
def scanUnlock(lockDescription):
    log('scanUnlock(lockDescription= %r)' % (lockDescription))
    recordingLock = os.path.join(datapath, 'scanLock') + adjustFileName(lockDescription) + '.txt'
    log('scanUnlock(recordingLock= %r)' % (recordingLock))
    #utils.ADDONsetSetting('StopRecording','Recording stopped: ' + lockDescription + ' ' + datetime.datetime.today().strftime('%H:%M'))
    # find lock files
    LockFiles = glob.glob(recordingLock)
    log('scanUnlock(LockFiles= %r)' % (LockFiles))
    # delete lock files
    for file in LockFiles:
        log('scanUnlock(0 file= %r)' % (file))
        deleteLockFile(file)
        log('scanUnlock(1 file= %r)' % (file))
    ###deleteLockFile(recordingLock)
    ###log('scanUnlock(file= %r)' % (recordingLock))

def markLock(lockDescription):
    recordingLock = os.path.join(datapath, 'markLock') + adjustFileName(lockDescription) + '.txt'
    if os.path.isfile(recordingLock) == False: 
        # create lock file
        LF = open(recordingLock, 'a')
        # Write to our text file the information we have provided and then goto next line in our file.
        LF.write(lockDescription + '\n')
        # Close our file so no further writing is posible.
        LF.close()
        ###utils.ADDONsetSetting('Stopmark','Lock: ' + lockDescription)
    
def ismarkLocked(lockDescription):
    isAnymarkLocked()
    recordingLock = os.path.join(datapath, 'markLock') + adjustFileName(lockDescription) + '.txt'
    return os.path.isfile(recordingLock)
    
def isAnymarkLocked():
    recordingLock = os.path.join(datapath, 'markLock') + '*.txt'
    LockFiles = glob.glob(recordingLock)
    for file in LockFiles:
        deleteOldLockFile(file,12) #Delete files more than 12 hours old
        log('deleteOldLockFile(markLock= %r,ageinhours= %r)' % (file,5))
    LockFiles = glob.glob(recordingLock)
    log('isAnymarkLocked(LockFiles= %r and len(LockFiles)= %r >0)' %(LockFiles, len(LockFiles)))
    return (len(LockFiles) > 0)
    
def markLockedList():
    recordingLock = os.path.join(datapath, 'markLock') + '*.txt'
    LockFiles = glob.glob(recordingLock)
    for file in LockFiles:
        deleteOldLockFile(file,12) #Delete files more than 12 hours old
        log('deleteOldLockFile(markLock= %r,ageinhours= %r)' % (file,5))
    LockFiles = glob.glob(recordingLock)
    log('markLockedList= %r and len(LockFiles)= %r >0)' %(LockFiles, len(LockFiles)))
    return (repr(LockFiles))
    
def markUnlockAll():
    lockDescription = '*'
    recordingLock = os.path.join(datapath, 'markLock') + lockDescription + '.txt'
    LockFiles = glob.glob(recordingLock)
    # delete lock files
    for file in LockFiles:
        deleteLockFile(file)
        log('markUnlockAll(file= %r)' % (file))
        
def markUnlock(lockDescription):
    recordingLock = os.path.join(datapath, 'markLock') + adjustFileName(lockDescription) + '.txt'
    #utils.ADDONsetSetting('StopRecording','Recording stopped: ' + lockDescription + ' ' + datetime.datetime.today().strftime('%H:%M'))
    # delete lock file
    deleteLockFile(recordingLock)
    log('markUnlock(file= %r)' % (recordingLock))

def isAnyThingLocked(destinationdatapath):
    recordingLock = os.path.join(destinationdatapath, '*Lock') + '*.txt'
    LockFiles = glob.glob(recordingLock)
    for file in LockFiles:
        deleteOldLockFile(file,5) #Delete files more than 5 hours old
        log('deleteOldLockFile(scanLock= %r,ageinhours= %r)' % (file,5))
    LockFiles = glob.glob(recordingLock)
    log('isAnyThingLocked((LockFiles= %r and len(LockFiles)= %r >0)' %(LockFiles, len(LockFiles)))
    return (len(LockFiles) > 0)