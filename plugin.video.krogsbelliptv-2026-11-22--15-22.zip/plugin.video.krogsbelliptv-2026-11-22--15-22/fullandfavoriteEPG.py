#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmc, xbmcvfs
# For Python 3.0 and later
from urllib.request import urlopen
import sys
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import definition
import utils
import recordings
import glob
import os
import locking
import updateepg
module    = 'fullandfavoriteEPG.py'

def log(infotext,showlength=1024):
    definition.log(infotext,showlength,module)

try:
    ADDON     = definition.getADDON()
    ADDONid   = definition.ADDONgetAddonInfo('id')
    ADDONname = definition.ADDONgetAddonInfo('name')
    datapath  = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
    progpath  = definition.ADDONgetAddonInfo('path')
    
    log('fullandfavoriteEPG Started')
    log('fullandfavoriteEPG sys.argv= %r' % sys.argv)
    alarmName = 'fullandfavoriteEPG'
    marker    = 'once'
    try:
        marker = sys.argv[1]
    except Exception as e:
        pass
        log('fullandfavoriteEPG Except: %r' % e)
    alarmName = alarmName + '-' + marker   
    recordings.updateAlarm(alarmName)
    log('fullandfavoriteEPG after updateAlarm')
    BACKUP_PATH = definition.ADDONgetSetting('backup_path')
    log('fullandfavoriteEPG BACKUP_PATH= %r' % BACKUP_PATH)
    RECORD_PATH = definition.ADDONgetSetting('record_path')
    log('fullandfavoriteEPG RECORD_PATH= %r' % RECORD_PATH)
    dns_servers = utils.showdns()
    now=datetime.today().strftime('%H:%M:%S')
    definition.ADDONsetSetting('EPGimportaccept', 'fullandfavoriteEPG started %r %r' % (now, dns_servers))  ### 2026-03-09
        
    enabled = definition.ADDONgetSetting('fullandfavoriteEPGenable')
    log('fullandfavoriteEPG enabled= %r' % enabled)
    ROQuser = definition.ADDONgetSetting('user')
    if not enabled or ROQuser.lower() == 'none' :
        definition.ADDONsetSetting('EPGimportaccept', 'fullandfavoriteEPG not enabled')
    else:    
        
        try:
            """
            EPGurl = 'http://line.dndnscloud.ru/xmltv.php?username=8dnebn9ii5&password=7jbq9bx6nt'  ###&next_days=10'   ### 2026-04-16  Test new link
            log('  EPGurl= %r' % EPGurl)
            ChannelFileTest = os.path.join(datapath,'EPGfullTest.xml')  
            log('  ChannelFileTest= %r' % ChannelFileTest)                
            data = utils.readlink(EPGurl,ChannelFileTest,module)
            log('  data= %r' % data)
            """
            ChannelFile2 = os.path.join(datapath,'EPGfull.xml')        
            log('fullandfavoriteEPG ChannelFile2= %r' % ChannelFile2)
            ChannelFile4 = 'EPGfavorites.xml'
            log('fullandfavoriteEPG ChannelFile4= %r' % ChannelFile4)
            ROQuser = definition.ADDONgetSetting('user')
            ROQpass = definition.ADDONgetSetting('pass')
            httplinkEPG = definition.getBASEURL() + '/xmltv.php?username=' +ROQuser+ '&password=' +ROQpass +'&next_days=10'
            log('fullandfavoriteEPG httplinkEPG= %r' % httplinkEPG)
            data = utils.readlink(httplinkEPG,ChannelFile2,module)
            log('fullandfavoriteEPG data= %r' % data)
            ### copy EPG to master.xml in Recordingsfolder
            if os.path.exists(ChannelFile2):
                log('fullandfavoriteEPG Except ChannelFile2 exists= %r' % ChannelFile2)
                Recordings = xbmcvfs.translatePath(definition.FileManagerPath('Recordings'))
                destf = os.path.join(Recordings,'EPGfull_'+definition.ADDONgetSetting('my_referral_init')+'_'+str(xbmc.getInfoLabel('System.FriendlyName'))+'.xml')   ### 2026-03-12
                log('fullandfavoriteEPG Except 1 destf= %r' % destf)
                copyOK = xbmcvfs.copy(ChannelFile2, destf)
                if not copyOK:
                    log('fullandfavoriteEPG Except Copy of %r failed - ERR: %r' %  (destf,copyOK))
                wanted = recordings.getFavoriteChannelsEPG()
                log('fullandfavoriteEPG wanted= %r' % wanted)
                utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] Select XMLTV channels Wanted: %r' % wanted)
                ###wanted = ['dr1.dk','493972']
                destf = os.path.join(datapath,ChannelFile4)   ### 2026-03-12 save in datapath
                log('Except 2 destf= %r' % destf)
                result = updateepg.SelectXMLTVchannels(wanted,ChannelFile2,destf)
                log('fullandfavoriteEPG SelectXMLTVchannels result= %r' % result)
                destfR = os.path.join(Recordings,ChannelFile4)   ### 2026-03-09
                log('  3 destfR= %r' % destfR)
                copyOK = xbmcvfs.copy(destf, destfR)
                if not copyOK:
                    ERROR = 'Exception in copy of EGfavorites failed'
                    log('fullandfavoriteEPG ' + ERROR)
                    updateepg.EPGimportERRORS(ERROR)
                log('fullandfavoriteEPG Except SelectXMLTVchannels result= %r' % copyOK)
            utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] Select XMLTV channels Finished with result %r' % result)
            
        except Exception as e:
            pass
            ERROR = 'fullandfavoriteEPG Select XMLTV channels Exception: %r' %e
            log(ERROR)
            updateepg.EPGimportERRORS(ERROR)
            utils.notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] Select XMLTV channels failed: %r' % e)
        
except Exception as  e:
    pass
    log('fullandfavoriteEPG Exception in fullandfavoriteEPG: %r' % e)
    updateepg.EPGimportERRORS(ERROR)
recordings.EPGOnce()
log('fullandfavoriteEPG Ended')

