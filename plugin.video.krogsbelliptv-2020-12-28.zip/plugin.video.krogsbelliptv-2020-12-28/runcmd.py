#!/usr/bin/python
# -*- coding: utf-8 -*-
import utils
import definition

ADDON      = definition.getADDON()
ADDONname  = ADDON.getAddonInfo('name')
ADDONid    = ADDON.getAddonInfo('id')
module = 'runcmd.py'
utils.logdev(module,'sys.argv= %s' %(str(repr(sys.argv))))
program  = sys.argv[0]
cmd      = sys.argv[1]

utils.logdev(module,'cmd= %r' % cmd)  #put in LOG
try: 
    #print os.environ
    utils.logdev(module,'os.environ= ' + os.environ['OS'])  #put in LOG
except: pass

try: 
    LoopCount = 0
    LibPath = utils.libPath()
    utils.runCommand(cmd, LoopCount, LibPath)
except Exception,e:
    pass
    utils.logdev(module,'cmd=  %r\nFAILED: %r' % (cmd,e))

