#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#      Copyright (C) 2014 Tommy Winther
#      http://tommy.winther.nu
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
"""
        <news>[B]Version 2023-02-26[B]
        To add recording to DRNU addon, install Krogsbell IPTV Addon from: https://github.com/krogsbell/IPTV and try the menuoption Switch Krogsbell Addon.
        To add the recording function to a new version of DRNU addon:
        Add the file krogsbell.py together with addon.py in the root
        At resources\lib\addon.py add 'import krogsbell'
        At def playVideo(self, id, kids_channel, path):
        add two lines
        if krogsbell.krogsbellRecord(self, id, kids_channel, path) :  ### Krogsbell addon
            return                                                    ### Krogsbell addon
        At resources\lib\tvapi.py
        add 'import krogsbell' in the start
        and in  many def get_xxx(self, xxx):
        after
        if u.status_code == 200:
            krogsbell.krogsbellGetProgramcard(u.json(), path or id)               ### Krogsbell addon
            return u.json()
        add the line
        krogsbell.krogsbellGetProgramcard(u.json())
        Remember some programs do not record outside Denmark unless you use special network settings
        </news>
"""
#
import pickle
import os
import sys
import urllib.parse as urlparse
import re
import datetime
import time
import _strptime
from operator import itemgetter

import xbmc, xbmcvfs
import xbmcgui
import xbmcaddon
import xbmcplugin

from resources.lib import tvapi
from resources.lib import tvgui

import shutil
import base64

xbmc.log('DRNU: Start')
ADDON      = xbmcaddon.Addon()
ADDONname  = ADDON.getAddonInfo('name')
ADDONid    = ADDON.getAddonInfo('id')
if ADDON.getSetting('enable.debug') == 'true' :
    DEBUGGING  = True
else:
    DEBUGGING  = True  ### Just debug
get_setting = ADDON.getSetting

def bool_setting(name):
    return get_setting(name) == 'true'

def RecordFlagSet(sourceApp,flag):   ### 2018-11-08
    if sourceApp == '':
        ADDONsource = xbmcaddon.Addon()
    else:
        ADDONsource = xbmcaddon.Addon(sourceApp)
    datapath = xbmcvfs.translatePath(ADDONsource.getAddonInfo('profile'))
    recordflag = os.path.join(datapath, 'RecordFlag.txt')
    FlagFile = open(recordflag, 'w')
    # Write to our text file the information we have provided and then goto next line in our file.
    # LogDev.write(repr(module) + ': ' + repr(message) + '\n')
    FlagFile.write(flag)
    FlagFile.close()

def RecordFlagGet(sourceApp):   ### 2018-11-08
    if sourceApp == '':
        ADDONsource = xbmcaddon.Addon()
    else:
        ADDONsource = xbmcaddon.Addon(sourceApp)
    datapath = xbmcvfs.translatePath(ADDONsource.getAddonInfo('profile'))
    recordflag = os.path.join(datapath, 'RecordFlag.txt')
    if os.path.isfile(recordflag):
        FlagFile = open(recordflag, 'r')
        # Write to our text file the information we have provided and then goto next line in our file.
        # LogDev.write(repr(module) + ': ' + repr(message) + '\n')
        flag = FlagFile.read()
    else:
        flag = ''
    return flag

def logdev(module,message):
    if DEBUGGING :
        nowHMS=datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        datapath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        addonlog = os.path.join(datapath, 'addon.log')
        ###xbmc.log('DRNU: logdev before reset')
        logdevreset(addonlog)
        # create lock file
        LogDev = open(addonlog, 'a')
        # Write to our text file the information we have provided and then goto next line in our file.
        # LogDev.write(repr(module) + ': ' + repr(message) + '\n')
        LogDev.write('%s %s: %s\n\n' % (nowHMS, module, message))

def logdevreset(addonlog): 
    xbmc.log('DRNU: logdevreset')
    addonOLDlog = addonlog.replace('.log','OLD.log')
    try:
        size = os.path.getsize(addonlog)
        xbmc.log('DRNU: addon.log size= %r' % size)
        maxsize = 1 * 1024 * 1024 # 1 MB 
        xbmc.log('DRNU: log size= %r' % size)
        if os.path.exists(addonlog) and size > maxsize:
            shutil.copyfile(addonlog, addonOLDlog)
            tries    = 0
            maxTries = 10
            maxSleep = 50
            while os.path.exists(addonlog) and tries < maxTries:
                try:
                    os.remove(addonlog)
                    break
                except:
                    xbmc.sleep(maxSleep)
                    tries = tries + 1
    except Exception as e:
        pass
        xbmc.log('DRNU: Reset addon.log failed: %r' % e)
        
def _DrDkTvAddon__log(text):
    if DEBUGGING :
        logdev('krogsbell.py',text.encode("utf-8"))
        
def __log(text):
    if DEBUGGING :
        logdev('krogsbell.py',text.encode("utf-8"))
    
def printL(message, module = 'krogsbell.py', size=250):
    if DEBUGGING :
        if len(message) > size:
            logdev(module,message[0:size]+'...\n...\n...'+message[-250:]+'\n')
        else:
            logdev(module,message)

def cmp_to_key(mycmp):
    'Convert a cmp= function into a key= function'
    class K:
        def __init__(self, obj, *args):
            self.obj = obj
        def __lt__(self, other):
            return mycmp(self.obj, other.obj) < 0
        def __gt__(self, other):
            return mycmp(self.obj, other.obj) > 0
        def __eq__(self, other):
            return mycmp(self.obj, other.obj) == 0
        def __le__(self, other):
            return mycmp(self.obj, other.obj) <= 0
        def __ge__(self, other):
            return mycmp(self.obj, other.obj) >= 0
        def __ne__(self, other):
            return mycmp(self.obj, other.obj) != 0
    return K

def krogsbellAddons():
    ### Krogsbell IPTV addons have the file 'definition.py'
    addons = []
    try:
        SwFileFolder = os.path.join(xbmcvfs.translatePath('special://masterprofile/'), 'addon_data','krogsbell.switchaddons')
        SwFile = os.path.join(SwFileFolder,'switchaddons.txt')
        if not os.path.exists(SwFileFolder):
            os.mkdir(SwFileFolder)
            open(SwFile, 'a').close()
        printL('SwFile= %r' % SwFile)
        switchfile = open(SwFile, 'r')
        addonsO = switchfile.read()
        switchfile.close() 
        if not ADDONid in addonsO:
            addonsO += '\n' + ADDONrefer + ':' + ADDONid
            addonsO = addonsO.replace('\n\n\n\n','\n').replace('\n\n\n','\n').replace('\n\n','\n')
            LF = open(SwFile, 'w')
            LF.write(addonsO)
            LF.close()
        ADDON.setSetting('switchaddons',addonsO)
        if addonsO != '' :
            addonsO = addonsO.split('\n')
            for addon in addonsO:
                if addon != '':
                    newaddon = addon.split(':')
                    if newaddon[1] != ADDONid:
                        try:
                            testAddon = xbmcaddon.Addon(id=newaddon[1])
                            pathTOaddon = os.path.join(xbmcvfs.translatePath('special://home/addons'), newaddon[1])
                            if os.path.exists(pathTOaddon):
                                addons.append(newaddon)
                        except Exception as e:
                            pass
                            printL('testAddon FAILED= %r' % e)
    except Exception as e:
        pass
        addons.append(['ERROR',repr(e)])
    ###[['GlowIPTV','plugin.video.glowiptv.rec'],['DR NU','plugin.video.drnu'],['BBC iPlayer','plugin.video.iplayerwww'],['ITV Player','plugin.video.itv']]
    addons = sorted(addons)
    choises = []
    for choise in addons:
       choises.append(choise[0] + ': ' + choise[1])
    return choises

def krogsbellAddonsSelect():
    printL('krogsbellAddonsSelect: Start')
    choisesall = krogsbellAddons()
    choises    = []
    progpath   = ADDON.getAddonInfo('path')
    datapath   = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    for choise in choisesall:
        try:
            newADDONid = choise.replace(': ',':').split(':')[1]
            progpathnew= os.path.join(progpath.replace(ADDONid,newADDONid),'definition.py')
            printL('progpathnew= %r' % progpathnew)
            if os.path.exists(progpathnew):
                ### ...\addon_data\...\storage\channels.json
                datapathnew= os.path.join(datapath.replace(ADDONid,newADDONid),'storage','channels.json')
                printL('datapathnew= %r' % datapathnew)
                if not os.path.exists(datapathnew):
                    targetADDON = xbmcaddon.Addon(id=newADDONid)
                    enable_record = targetADDON.getSetting('enable_record')
                    printL('targetADDON= %r, enable_record= %r'% (targetADDON, enable_record))            
                    if enable_record == 'true':
                        printL('choises.append(choise)= %r' % choise)
                        choises.append(choise)
        except Exception as e:
            pass
            choises.append('Error: %r' % e)
    selected = -1
    if len(choises) > 0:
        dialog = xbmcgui.Dialog()
        printL('select(choises)= %r' % choises)
        selected = dialog.select('[B]'+ADDON.getAddonInfo('name') +'[/B][I]'+ ADDON.getLocalizedString(30031)+'[/I]', choises) ####################
        printL('selected choise#= %r' % selected)
    if selected != -1:
        printL('selected Addon = %r ' % choises[selected])
        return choises[selected].replace(': ',':').split(':')[1]
    return ''

def krogsbellGetProgramcard(self, programCard, path):
    if bool_setting('krogsbell.enabled') :
        try:
            desc = path.split('_')[-1].split('/')[-1]
            __log('krogsbellGetProgramcard desc= %r'% desc)
            __log('krogsbellGetProgramcard programCard= %r'% programCard)
            __log('krogsbellGetProgramcard programCard_type= %r'% type(programCard))
            filename = 'programCard' + desc + '.txt'
            __log('krogsbellGetProgramcard filename= %r' % filename)
            datapath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
            flag = os.path.join(datapath, filename)
            File = open(flag, 'w')
            File.write(str(programCard))
            File.close()
            filename = 'programCardPickle' + desc + '.pickle'
            __log('krogsbellGetProgramcard filename= %r' % filename)
            pickleFile = os.path.join(datapath, filename)
            with open(pickleFile, 'wb') as handle:
                pickle.dump(programCard, handle, protocol=pickle.HIGHEST_PROTOCOL)
        except Exception as e:
            pass
            try: 
                __log('krogsbellGetProgramcard programCard ERROR= %r'% e)
            except:
                pass
    
def krogsbellRecord(self, id, kids_channel, path):
    if not bool_setting('krogsbell.enabled') :
        return False
    try:
        __log('krogsbellRecord path= %r' % path)
        if path.startswith('/kanal'):
            # live stream
            video = self.api.get_livestream(path, with_subtitles=bool_setting('enable.subtitles'))
        elif path.startswith('/film'):
            video = self.api.unfold_list(path)
        else:
            self.updateRecentlyWatched(path)
            video = self.api.get_stream(id)
        subs = {}
        for i, sub in enumerate(video['subtitles']):
            subs[sub['language']] = i
        kids_channel = kids_channel == 'True'

        if not video['url']:
            self.displayError(tr(30904))
            return False

        item = xbmcgui.ListItem(path=video['url'], offscreen=True)

        if get_setting('inputstream') == 'adaptive':
            is_helper = Helper('hls')
            if is_helper.check_inputstream():
                item.setProperty('inputstream', is_helper.inputstream_addon)
                item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        
        ###krogsbell.krogsbellRecord(video, path)   ### Krogsbell addon previous call
        ###krogsbell(name,url,there_are_subtitles,subtitles_file)
        try:
            subtitlesAvailable = video['subtitles'][1]['isEmbedded']
            subtitles = video['subtitles'][1]['link']
        except Exception as e:
            pass
            try:
                subtitlesAvailable = video['subtitles'][0]['isEmbedded']
                subtitles = video['subtitles'][0]['link']
            except Exception as e:
                pass
                subtitlesAvailable = False
                subtitles = ''
        __log('krogsbellRecord path= %r' % path)
        __log('krogsbellRecord video[subtitles][isEmbedded]= %r' % subtitlesAvailable)
        __log('krogsbellRecord video[subtitles][link]= %r' % subtitles)      
        if krogsbell(self,'Fra DR TV '+path,video['url'],subtitlesAvailable,subtitles) :
            return True
        ###krogsbell(name,url,there_are_subtitles,subtitles_file)
    except Exception as e:
        pass
        __log('krogsbellRecord ERROR %r' % e)
        return False
  
def get_info(self, data):
    try:
        __log('descriptionFromProgramcard data= %r' % data)
        __log('descriptionFromProgramcard data type= %r'% type(data))
        title = data['title']
        __log('descriptionFromProgramcard api.get_info 0 title= %r' % title)
        typeD = data['type']
        __log('descriptionFromProgramcard api.get_info 0 type= %r' % typeD)
        title, infoLabels = self.api.get_info(data)   ### 2023-02-25
        __log('descriptionFromProgramcard api.get_info 1 title= %r' % title)
        __log('descriptionFromProgramcard infoLabels= %r' % infoLabels)
    except Exception as e:
        pass
        __log('descriptionFromProgramcard api.get_info ERROR %r' % e)
    
def descriptionFromProgramcard(self, id):
    __log('descriptionFromProgramcard id= %r' % id)
    desc = id.split('_')[-1]
    __log('descriptionFromProgramcard desc= %r' % desc)
    filename = 'programCard' + desc + '.txt'
    __log('descriptionFromProgramcard filename= %r' % filename)
    datapath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    flag = os.path.join(datapath, filename)
    File = open(flag, 'r')
    programCard = File.read()
    File.close()
    filename = 'programCardPickle' + desc + '.pickle'
    __log('descriptionFromProgramcard filename= %r' % filename)
    pickleFile = os.path.join(datapath, filename)
    with open(pickleFile, 'rb') as handle:
        data = pickle.load(handle)
    get_info(self, data)
    datakeys = None
    items = None
    param = ['id','title','duration','releaseYear','shortDescription','description','IsGeoRestricted','PlayButtonExtraDetails']
    values= [desc,'','','','','','','']
    while items == None :
        try:
            datakeys = data.keys()
        except Exception as e:
            pass
            __log('descriptionFromProgramcard data.keys() ERROR= %r' % e)
        __log('descriptionFromProgramcard data.keys()= %r' % datakeys)
        try: 
            values[7] = data['customFields']['PlayButtonExtraDetails']
        except Exception as e:
            pass
            __log('descriptionFromProgramcard customFields ERROR %r' % e)
        if 'entries' in datakeys and len(data['entries']) > 0 :
            try:
                entriesType = type(data['entries'])
                __log('descriptionFromProgramcard entriesType= %r' % entriesType)
                if entriesType == 'dict':
                    __log('descriptionFromProgramcard entriesType == dict')
                    data = data['entries']
                    get_info(self, data)
                else:
                    try:
                        __log('descriptionFromProgramcard entriesType != dict\n%r' % data)
                        data = data['entries'][0]
                        get_info(self, data)
                    except Exception as e:
                        pass    
                        __log('descriptionFromProgramcard entries not dict ERROR %r' % e)
                        if 'type' in datakeys and data['type'] == 'channel':
                            items = data
            except Exception as e:
                pass
                __log('descriptionFromProgramcard entries ERROR %r' % e)
        ###'canonical': '/liste/ta-mest-sete-film_365856'}
        ###elif 'canonical' in datakeys:
        ###    canonicalid = data['canonical']
        ###    descriptionFromProgramcard(self,canonicalid)
        ###    break
        elif 'episodes' in datakeys:
            data = data['episodes']
        elif 'list' in datakeys:
            data = data['list']
        elif 'item' in datakeys:
            data = data['item']
        elif 'items' in datakeys:
            data = data['items']
            items = data
        elif 'type' in datakeys and data['type'] == 'channel':
            items = data
        else:
            items = data
    
        ###items = data['entries'][0]['list']['items']
        __log('descriptionFromProgramcard dict items= %r' % items)
        try:
            itemkeys = items[0].keys()
        except:
            pass
            try:
                itemkeys = items.keys()
            except:
                pass
                itemkeys = ''
        __log('descriptionFromProgramcard itemkeys= %r' % itemkeys)
        __log('descriptionFromProgramcard items= %r' % items)
        try:
            try:
                lenItems = len(items)
                __log('descriptionFromProgramcard lenItems= %r' % lenItems)
            except Exception as e:
                pass
                lenItems = 0
                __log('descriptionFromProgramcard lenItems ERROR %r'% e)
            if 'items' not in itemkeys:
                i = 1
                while i <= len(param)-1 :
                    __log('descriptionFromProgramcard 0 i= %r' % i)
                    __log('descriptionFromProgramcard 0 XXX[%r] param= %r itemkeysT= %r' % (i,param[i],itemkeys))
                    if param[i] in itemkeys :
                        __log('descriptionFromProgramcard 0 [%r] %r= %r' % (i,param[i],values[i]))
                        __log('descriptionFromProgramcard 0 [%r] items= %r' % (i,items))
                        
                        if "%r" % type(items) == "<class 'list'>" :
                            __log('descriptionFromProgramcard items [ type= %r ]' % type(items))
                            __log('descriptionFromProgramcard 0 [%r] items[param[i]]= %r' % (i,items[0][param[i]]))
                            values[i] = str(items[0][param[i]])
                        else:
                            __log('descriptionFromProgramcard items ( type= %r )' % type(items))
                            __log('descriptionFromProgramcard 0 [%r] items[param[i]]= %r' % (i,items[param[i]]))
                            values[i] = str(items[param[i]])
                        __log('descriptionFromProgramcard 1 [%r] %r= %r' % (i,param[i],values[i]))
                    i += 1
            else:
                for o in range(lenItems):
                    idkey = data[o]['id']
                    __log('descriptionFromProgramcard dict items key id %r= %r' % (desc, idkey))
                    i = 1
                    if desc == idkey :
                        while i <= len(param)-1 :
                            __log('descriptionFromProgramcard 1 i= %r' % i)
                            __log('descriptionFromProgramcard 1 XXX[%r] param= %r itemkeysT= %r' % (i,param[i],itemkeys))
                            if param[i] in itemkeys :
                                values[i] = str(items[o][param[i]])
                                __log('descriptionFromProgramcard [%r] %r= %r' % (i,param[i],values[i]))
                            i += 1
        except Exception as e:
            pass
            __log('descriptionFromProgramcard ERROR %r'% e)
        __log('descriptionFromProgramcard values= %r\nparam= %r' % (values, param))
    title = values[1]
    __log('descriptionFromProgramcard title= %r' % title)
    duration = values[2]
    __log('descriptionFromProgramcard duration= %r' % duration)
    releaseYear = values[3]
    __log('descriptionFromProgramcard releaseYear= %r' % releaseYear)
    shortdescription = values[4]
    __log('descriptionFromProgramcard shortdescription= %r' % shortdescription)
    description = values[5]
    __log('descriptionFromProgramcard description= %r' % description)
    IsGeoRestricted = values[6]
    __log('descriptionFromProgramcard IsGeoRestricted= %r' % IsGeoRestricted)
    PlayButtonExtraDetails = values[7]
    __log('descriptionFromProgramcard PlayButtonExtraDetails= %r' % PlayButtonExtraDetails)
    
    if releaseYear != '':
        title = title + ' (' + releaseYear + ')'
    if PlayButtonExtraDetails != '':
        title = title + ' ' + PlayButtonExtraDetails
    if IsGeoRestricted != '':
        title = title + ' [' + IsGeoRestricted + ']'
    __log('descriptionFromProgramcard final title= %r' % title)
    if len(shortdescription) >= len(description) :
        description = shortdescription
    return (title, duration, description.replace('/n','NewLine'))
    
def krogsbell(self,name,url,there_are_subtitles,subtitles_file):
    ###def PLAY_STREAM_HLS_LIVE(name,url,iconimage):
    printL('krogsbell(name=%r\n,url=%r\n,there_are_subtitles=%r\n,subtitles_file=%r\n)'% (name,url,there_are_subtitles,subtitles_file))
    cmd  = 'XBMC.Notification(%s, %s, %r, %s)' % (name, url, 10000, '') 
    xbmc.executebuiltin(cmd) 
    title, duration, description = descriptionFromProgramcard(self, name)
    __log('Programcard title= %r' % title)
    __log('Programcard duration= %r' % duration)
    __log('Programcard description= %r' % description)
    if there_are_subtitles == 1:
        subtitles_url = subtitles_file
    else:
        subtitles_url = ''
    if title != '':
        name = title
    ### else keep name from call
        
    if duration != '':
        durtxt = '&duration=' + str(int(duration)//60 +1)
    else:
        durtxt = '&duration=240'
    __log('descriptionFromProgramcard durtxt= %r' % durtxt)
    printL('replace , in name with (nothing) name= %r' % name)
    iconimage = 'DefaultVideo.png'
    krogsbellAddonID = krogsbellAddonsSelect()
    recording = False
    if krogsbellAddonID != '' :
        if not '&description=' in url:
            URI='plugin://'+krogsbellAddonID+'/?url=url&mode=2011&name='+base64b64encode(name+' [DR NU]')+'&uri='+base64b64encode(url+durtxt+'&description=' + description+'&subtitlesurl='+subtitles_url+'&subtitlesoffset=0')
        else:
            URI='plugin://'+krogsbellAddonID+'/?url=url&mode=2011&name='+base64b64encode(name+' [DR NU]')+'&uri='+base64b64encode(url+durtxt+'&subtitlesurl='+subtitles_url+'&subtitlesoffset=0')
        printL('URI= %r' % URI)
        try:
            xbmc.executebuiltin('RunPlugin(%s)' % URI)
            recording = True
        except:
            pass
            printL('No valid Addon to record stream!')
            printL('Play Video')
    return recording


def recordingaddons():
    try:
        addons = []
        SwFileFolder = os.path.join(xbmcvfs.translatePath('special://masterprofile/'), 'addon_data','krogsbell.switchaddons')
        SwFile = os.path.join(SwFileFolder,'switchaddons.txt')
        if not os.path.exists(SwFileFolder):
            os.mkdir(SwFileFolder)
            open(SwFile, 'a').close()
        __log('SwFile= %r' % SwFile)
        switchfile = open(SwFile, 'r')
        addonsO = switchfile.read()
        switchfile.close() 
        if addonsO != '' :
            addonsO = addonsO.split('\n')
            for addon in addonsO:
                if addon != '':
                    __log('addon= %r' % addon)
                    newaddon = addon.split(':')
                    if newaddon[1] != ADDONid:
                        if 'video.' in newaddon[1]:
                            pathTOaddon = os.path.join(xbmcvfs.translatePath('special://home/addons'), newaddon[1])
                            if os.path.exists(pathTOaddon):
                                addons.append(newaddon)
    except Exception as e:
        pass
        addons.append(['ERROR',repr(e)])
    addons = sorted(addons)
    return addons

def TS(timestr):
    ### time format 2019-05-21T22:05:00Z
    time_tuple = time.strptime(timestr, "%Y-%m-%dT%H:%M:%SZ")
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def now():   ### Local time
    dt_obj= datetime.datetime.now()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
   
def nowTS():   ### UTC time
    dt_obj= datetime.datetime.utcnow()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def nowS(format):   ### Now date string UTC time
    time_tuple = time.localtime(nowTS())
    date_str = time.strftime(format, time_tuple)
    return(date_str)
    
def datestr(timestamp,format):   ### Date string UTC time %Y-%m-%dT%H:%M:%SZ
    time_tuple = time.localtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)

def datestrdelta(timestamp,format):   ### Now date string UTC time %Y-%m-%dT%H:%M:%SZ
    time_tuple = time.gmtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)

def base64b64encode(texttoencode):
    ###printL('0 texttoencode= %r' % texttoencode)
    try:
        result = base64.b64encode(texttoencode.encode())
        ###printL('1 result= %r' % result)
    except Exception as e:
        pass
        printL('base64b64encode() ERROR: %r' % e)
        result = base64.b64encode(texttoencode)
        ###printL('2 result= %r' % result)
        
    ###printL('3 result= %r' % result)
    texttoencode = 'b64' + result.decode()
    ###printL('1 texttoencode= %r' % texttoencode)
    return texttoencode
    
    
def switch(x):
    findP = ADDON.getSetting('LastSwitch')  ### datestr(nowTS(),'h%Hm%Ms%S'))
    if findP == '':
        delta = 10
    else:
        delta = nowTS() - TS(findP)
    __log('delta= %r' % delta)
    if delta > 9:
        ADDON.setSetting('LastSwitch',datestr(nowTS(),'%Y-%m-%dT%H:%M:%SZ'))
        dialog = xbmcgui.Dialog()
        addons = []
        try:
            SwFileFolder = os.path.join(xbmcvfs.translatePath('special://masterprofile/'), 'addon_data','krogsbell.switchaddons')
            SwFile = os.path.join(SwFileFolder,'switchaddons.txt')
            if not os.path.exists(SwFileFolder):
                os.mkdir(SwFileFolder)
                open(SwFile, 'a').close()
            __log('SwFile= %r' % SwFile)
            switchfile = open(SwFile, 'r')
            addonsO = switchfile.read()
            switchfile.close() 
            if not ADDONid in addonsO:
                addonsO += '\n' + ADDONname + ':' + ADDONid
                addonsO = addonsO.replace('\n\n\n\n','\n').replace('\n\n\n','\n').replace('\n\n','\n')
                LF = open(SwFile, 'w')
                LF.write(addonsO)
                LF.close()
            ADDON.setSetting('switchaddons',addonsO)
            if addonsO != '' :
                addonsO = addonsO.split('\n')
                for addon in addonsO:
                    if addon != '':
                        __log('addon= %r' % addon)
                        newaddon = addon.split(':')
                        if newaddon[1] != ADDONid:
                            try:
                                testAddon = xbmcaddon.Addon(id=newaddon[1])
                                pathTOaddon = os.path.join(xbmcvfs.translatePath('special://home/addons'), newaddon[1])
                                if os.path.exists(pathTOaddon):
                                    addons.append(newaddon)
                            except Exception as e:
                                pass
                                __log('testAddon FAILED= %r' % e)
        except Exception as e:
            pass
            addons.append(['ERROR',repr(e)])
        addons = sorted(addons)
        choises = []
        for choise in addons:
           choises.append(choise[0] + ': ' + choise[1])
        if len(choises) > 0:
            selected = dialog.select(ADDON.getAddonInfo('name') + ' - Select an Addon to switch to:', choises)
            if selected != -1:
                __log('selected Addon= %r - %r' % (addons[selected][0],addons[selected][1]))
                IDdoADDON = addons[selected][1]
                __log('Start Addon= %r' % IDdoADDON)
                xbmc.executebuiltin('Dialog.Close(busydialog)')   ### 2019-09-03 needed to allow switch addon
                xbmc.executebuiltin('RunAddon(%s)' % IDdoADDON)
     
def latin1_to_ascii_force(unitext):
    """
2020-02-02 13:43:56 default.py: l TEST i= 127, str(j)= '\x7f'=, unicrap(j)= '\x7f'
2020-02-02 13:43:56 default.py: l TEST i= 128, str(j)= '\x80'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 129, str(j)= '\x81'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 130, str(j)= '\x82'=, unicrap(j)= 'Euro'
2020-02-02 13:43:56 default.py: l TEST i= 131, str(j)= '\x83'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 132, str(j)= '\x84'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 133, str(j)= '\x85'=, unicrap(j)= 'AA'
2020-02-02 13:43:56 default.py: l TEST i= 134, str(j)= '\x86'=, unicrap(j)= 'AE'
2020-02-02 13:43:56 default.py: l TEST i= 135, str(j)= '\x87'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 136, str(j)= '\x88'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 137, str(j)= '\x89'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 138, str(j)= '\x8a'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 139, str(j)= '\x8b'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 140, str(j)= '\x8c'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 141, str(j)= '\x8d'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 142, str(j)= '\x8e'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 143, str(j)= '\x8f'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 144, str(j)= '\x90'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 145, str(j)= '\x91'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 146, str(j)= '\x92'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 147, str(j)= '\x93'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 148, str(j)= '\x94'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 149, str(j)= '\x95'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 150, str(j)= '\x96'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 151, str(j)= '\x97'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 152, str(j)= '\x98'=, unicrap(j)= 'OE'
2020-02-02 13:43:56 default.py: l TEST i= 153, str(j)= '\x99'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 154, str(j)= '\x9a'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 155, str(j)= '\x9b'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 156, str(j)= '\x9c'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 157, str(j)= '\x9d'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 158, str(j)= '\x9e'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 159, str(j)= '\x9f'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 160, str(j)= '\xa0'= , unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 161, str(j)= '\xa1'=¡, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 162, str(j)= '\xa2'=¢, unicrap(j)= 'c'
2020-02-02 13:43:57 default.py: l TEST i= 163, str(j)= '\xa3'=£, unicrap(j)= 'L'
2020-02-02 13:43:57 default.py: l TEST i= 164, str(j)= '\xa4'=¤, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 165, str(j)= '\xa5'=¥, unicrap(j)= 'Y'
2020-02-02 13:43:57 default.py: l TEST i= 166, str(j)= '\xa6'=¦, unicrap(j)= ':'
2020-02-02 13:43:57 default.py: l TEST i= 167, str(j)= '\xa7'=§, unicrap(j)= 's'
2020-02-02 13:43:57 default.py: l TEST i= 168, str(j)= '\xa8'=¨, unicrap(j)= '..'
2020-02-02 13:43:57 default.py: l TEST i= 169, str(j)= '\xa9'=©, unicrap(j)= 'c'
2020-02-02 13:43:57 default.py: l TEST i= 170, str(j)= '\xaa'=ª, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 171, str(j)= '\xab'=«, unicrap(j)= '<<'
2020-02-02 13:43:57 default.py: l TEST i= 172, str(j)= '\xac'=¬, unicrap(j)= '-'
2020-02-02 13:43:57 default.py: l TEST i= 173, str(j)= '\xad'=­, unicrap(j)= '-'
2020-02-02 13:43:57 default.py: l TEST i= 174, str(j)= '\xae'=®, unicrap(j)= 'R'
2020-02-02 13:43:57 default.py: l TEST i= 175, str(j)= '\xaf'=¯, unicrap(j)= '_'
2020-02-02 13:43:57 default.py: l TEST i= 176, str(j)= '\xb0'=°, unicrap(j)= 'deg'
2020-02-02 13:43:57 default.py: l TEST i= 177, str(j)= '\xb1'=±, unicrap(j)= '+/-'
2020-02-02 13:43:57 default.py: l TEST i= 178, str(j)= '\xb2'=², unicrap(j)= '^2'
2020-02-02 13:43:57 default.py: l TEST i= 179, str(j)= '\xb3'=³, unicrap(j)= '^3'
2020-02-02 13:43:57 default.py: l TEST i= 180, str(j)= '\xb4'=´, unicrap(j)= "'"
2020-02-02 13:43:57 default.py: l TEST i= 181, str(j)= '\xb5'=µ, unicrap(j)= 'm'
2020-02-02 13:43:57 default.py: l TEST i= 182, str(j)= '\xb6'=¶, unicrap(j)= 'pi'
2020-02-02 13:43:57 default.py: l TEST i= 183, str(j)= '\xb7'=·, unicrap(j)= '*'
2020-02-02 13:43:57 default.py: l TEST i= 184, str(j)= '\xb8'=¸, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 185, str(j)= '\xb9'=¹, unicrap(j)= '^1'
2020-02-02 13:43:57 default.py: l TEST i= 186, str(j)= '\xba'=º, unicrap(j)= '^0'
2020-02-02 13:43:57 default.py: l TEST i= 187, str(j)= '\xbb'=», unicrap(j)= '>>'
2020-02-02 13:43:57 default.py: l TEST i= 188, str(j)= '\xbc'=¼, unicrap(j)= '1/4'
2020-02-02 13:43:57 default.py: l TEST i= 189, str(j)= '\xbd'=½, unicrap(j)= '1/2'
2020-02-02 13:43:57 default.py: l TEST i= 190, str(j)= '\xbe'=¾, unicrap(j)= '3/4'
2020-02-02 13:43:57 default.py: l TEST i= 191, str(j)= '\xbf'=¿, unicrap(j)= '?'
2020-02-02 13:43:57 default.py: l TEST i= 192, str(j)= '\xc0'=À, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 193, str(j)= '\xc1'=Á, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 194, str(j)= '\xc2'=Â, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 195, str(j)= '\xc3'=Ã, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 196, str(j)= '\xc4'=Ä, unicrap(j)= 'AA'
2020-02-02 13:43:57 default.py: l TEST i= 197, str(j)= '\xc5'=Å, unicrap(j)= 'AA'
2020-02-02 13:43:57 default.py: l TEST i= 198, str(j)= '\xc6'=Æ, unicrap(j)= 'AE'
2020-02-02 13:43:57 default.py: l TEST i= 199, str(j)= '\xc7'=Ç, unicrap(j)= 'C'
2020-02-02 13:43:57 default.py: l TEST i= 200, str(j)= '\xc8'=È, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 201, str(j)= '\xc9'=É, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 202, str(j)= '\xca'=Ê, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 203, str(j)= '\xcb'=Ë, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 204, str(j)= '\xcc'=Ì, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 205, str(j)= '\xcd'=Í, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 206, str(j)= '\xce'=Î, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 207, str(j)= '\xcf'=Ï, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 208, str(j)= '\xd0'=Ð, unicrap(j)= 'Th'
2020-02-02 13:43:57 default.py: l TEST i= 209, str(j)= '\xd1'=Ñ, unicrap(j)= 'N'
2020-02-02 13:43:57 default.py: l TEST i= 210, str(j)= '\xd2'=Ò, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 211, str(j)= '\xd3'=Ó, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 212, str(j)= '\xd4'=Ô, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 213, str(j)= '\xd5'=Õ, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 214, str(j)= '\xd6'=Ö, unicrap(j)= 'OE'
2020-02-02 13:43:57 default.py: l TEST i= 215, str(j)= '\xd7'=×, unicrap(j)= '*'
2020-02-02 13:43:57 default.py: l TEST i= 216, str(j)= '\xd8'=Ø, unicrap(j)= 'OE'
2020-02-02 13:43:57 default.py: l TEST i= 217, str(j)= '\xd9'=Ù, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 218, str(j)= '\xda'=Ú, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 219, str(j)= '\xdb'=Û, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 220, str(j)= '\xdc'=Ü, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 221, str(j)= '\xdd'=Ý, unicrap(j)= 'Y'
2020-02-02 13:43:57 default.py: l TEST i= 222, str(j)= '\xde'=Þ, unicrap(j)= 'th'
2020-02-02 13:43:57 default.py: l TEST i= 223, str(j)= '\xdf'=ß, unicrap(j)= 'ss'
2020-02-02 13:43:57 default.py: l TEST i= 224, str(j)= '\xe0'=à, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 225, str(j)= '\xe1'=á, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 226, str(j)= '\xe2'=â, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 227, str(j)= '\xe3'=ã, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 228, str(j)= '\xe4'=ä, unicrap(j)= 'ae'
2020-02-02 13:43:57 default.py: l TEST i= 229, str(j)= '\xe5'=å, unicrap(j)= 'aa'
2020-02-02 13:43:57 default.py: l TEST i= 230, str(j)= '\xe6'=æ, unicrap(j)= 'ae'
2020-02-02 13:43:57 default.py: l TEST i= 231, str(j)= '\xe7'=ç, unicrap(j)= 'c'
2020-02-02 13:43:57 default.py: l TEST i= 232, str(j)= '\xe8'=è, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 233, str(j)= '\xe9'=é, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 234, str(j)= '\xea'=ê, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 235, str(j)= '\xeb'=ë, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 236, str(j)= '\xec'=ì, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 237, str(j)= '\xed'=í, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 238, str(j)= '\xee'=î, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 239, str(j)= '\xef'=ï, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 240, str(j)= '\xf0'=ð, unicrap(j)= 'th'
2020-02-02 13:43:57 default.py: l TEST i= 241, str(j)= '\xf1'=ñ, unicrap(j)= 'n'
2020-02-02 13:43:57 default.py: l TEST i= 242, str(j)= '\xf2'=ò, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 243, str(j)= '\xf3'=ó, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 244, str(j)= '\xf4'=ô, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 245, str(j)= '\xf5'=õ, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 246, str(j)= '\xf6'=ö, unicrap(j)= 'oe'
2020-02-02 13:43:57 default.py: l TEST i= 247, str(j)= '\xf7'=÷, unicrap(j)= '/'
2020-02-02 13:43:57 default.py: l TEST i= 248, str(j)= '\xf8'=ø, unicrap(j)= 'oe'
2020-02-02 13:43:57 default.py: l TEST i= 249, str(j)= '\xf9'=ù, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 250, str(j)= '\xfa'=ú, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 251, str(j)= '\xfb'=û, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 252, str(j)= '\xfc'=ü, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 253, str(j)= '\xfd'=ý, unicrap(j)= 'y'
2020-02-02 13:43:57 default.py: l TEST i= 254, str(j)= '\xfe'=þ, unicrap(j)= 'th'
2020-02-02 13:43:57 default.py: l TEST i= 255, str(j)= '\xff'=ÿ, unicrap(j)= 'y'
N\xc3\xa5r st\xc3\xb8vet har lagt sig
N      å r st      ø vet har lagt sig 
S\xc3\xb8ren Ryge pr\xc3\xa6senterer
S      ø ren Ryge pr      æ senterer 
    """
    printL('latin1_to_ascii_force(unitext= %r)' % unitext)
    xc3flag = False
    xlatec3={0x82:'Euro', 0x85:'AA', 0x86:'AE', 0x98:'OE', 
        0xa0:'',
        0xa1:'', 0xa2:'c', 0xa3:'L', 0xa4:'ae',
        0xa5:'aa', 0xa6:'ae', 0xa7:'s', 0xa8:'..',
        0xa9:'e', 0xaa:'a', 0xab:'<<', 0xac:'-',
        0xad:'-', 0xae:'R', 0xaf:'_', 
        0xb0:'deg',
        0xb1:'+/-', 0xb2:'^2', 0xb3:'o', 0xb4:"'",
        0xb5:'m', 0xb6:'oe', 0xb7:'*', 0xb8:'oe',
        0xb9:'^1', 0xba:'^0', 0xbb:'>>', 
        0xbc:'1/4', 0xbd:'1/2', 0xbe:'3/4', 0xbf:'?',
        0xc0:'A', 0xc1:'A', 0xc2:'A', 0xc3:'', 0xc4:'AA', 0xc5:'AA',
        0xc6:'AE', 0xc7:'C',
        0xc8:'E', 0xc9:'E', 0xca:'E', 0xcb:'E',
        0xcc:'I', 0xcd:'I', 0xce:'I', 0xcf:'I',
        0xd0:'Th', 0xd1:'N',
        0xd2:'O', 0xd3:'O', 0xd4:'O', 0xd5:'O', 0xd6:'OE', 
        0xd7:'*', 
        0xd8:'OE',
        0xd9:'U', 0xda:'U', 0xdb:'U', 0xdc:'U',
        0xdd:'Y', 0xde:'th', 0xdf:'ss',
        0xe0:'a', 0xe1:'a', 0xe2:'a', 0xe3:'a', 0xe4:'ae', 0xe5:'aa',
        0xe6:'ae', 0xe7:'c',
        0xe8:'e', 0xe9:'e', 0xea:'e', 0xeb:'e',
        0xec:'i', 0xed:'i', 0xee:'i', 0xef:'i',
        0xf0:'th', 0xf1:'n',
        0xf2:'o', 0xf3:'o', 0xf4:'o', 0xf5:'o', 0xf6:'oe', 0xf7:'/', 0xf8:'oe',
        0xf9:'u', 0xfa:'u', 0xfb:'u', 0xfc:'u',
        0xfd:'y', 0xfe:'th', 0xff:'y',
        }
    xlate={0x82:'Euro', 0x85:'AA', 0x86:'AE', 0x98:'OE', 
        0xa0:'',
        0xa1:'', 0xa2:'c', 0xa3:'L', 0xa4:'o',
        0xa5:'aa', 0xa6:':', 0xa7:'s', 0xa8:'..',
        0xa9:'c', 0xaa:'a', 0xab:'<<', 0xac:'-',
        0xad:'-', 0xae:'R', 0xaf:'_', 
        0xb0:'deg',
        0xb1:'+/-', 0xb2:'^2', 0xb3:'o', 0xb4:"'",
        0xb5:'m', 0xb6:'pi', 0xb7:'*', 0xb8:'oe',
        0xb9:'^1', 0xba:'^0', 0xbb:'>>', 
        0xbc:'1/4', 0xbd:'1/2', 0xbe:'3/4', 0xbf:'?',
        0xc0:'A', 0xc1:'A', 0xc2:'A', 0xc3:'', 0xc4:'AA', 0xc5:'AA',
        0xc6:'AE', 0xc7:'C',
        0xc8:'E', 0xc9:'E', 0xca:'E', 0xcb:'E',
        0xcc:'I', 0xcd:'I', 0xce:'I', 0xcf:'I',
        0xd0:'Th', 0xd1:'N',
        0xd2:'O', 0xd3:'O', 0xd4:'O', 0xd5:'O', 0xd6:'OE', 
        0xd7:'*', 
        0xd8:'OE',
        0xd9:'U', 0xda:'U', 0xdb:'U', 0xdc:'U',
        0xdd:'Y', 0xde:'th', 0xdf:'ss',
        0xe0:'a', 0xe1:'a', 0xe2:'a', 0xe3:'a', 0xe4:'ae', 0xe5:'aa',
        0xe6:'ae', 0xe7:'c',
        0xe8:'e', 0xe9:'e', 0xea:'e', 0xeb:'e',
        0xec:'i', 0xed:'i', 0xee:'i', 0xef:'i',
        0xf0:'th', 0xf1:'n',
        0xf2:'o', 0xf3:'o', 0xf4:'o', 0xf5:'o', 0xf6:'oe', 0xf7:'/', 0xf8:'oe',
        0xf9:'u', 0xfa:'u', 0xfb:'u', 0xfc:'u',
        0xfd:'y', 0xfe:'th', 0xff:'y', 
        }
    r = ''
    printL('unitext= %r' % unitext)
    ###unitext = unitext.encode("utf-8")
    ###printL('unitext-utf-8= %r' % unitext)
    unitext = unitext.replace('\xef\xbb\xbf','')   ### Remove: byte order mark (BOM)
    printL('unitext-noBOM= %r' % unitext)
    for i in unitext:
        printL('i= %r, ord(i)= %r' %  (i,ord(i)))
        try:
            if ord(i) == 0xc3:
                xc3flag = True
            else:
                if xc3flag == True:
                    ###if xlatec3.has_key(ord(i)):
                    if ord(i) in xlatec3:
                        r += xlatec3[ord(i)]
                    elif ord(i) >= 0x80:
                        pass
                    else:
                        r += str(i)
                    xc3flag = False
                else:
                    ###if xlate.has_key(ord(i)):
                    if ord(i) in xlate:
                        r += xlate[ord(i)]
                    elif ord(i) >= 0x80:
                        pass
                    else:
                        r += str(i)
        except Exception as e:
            pass
            printL('latin1_to_ascii_force(unitext) ERROR= %r)' % e)
    printL('latin1_to_ascii_force(unitext-->r= %r)' % r)
    return r
    
def shareLogs(change): ### Only change = True in this file only
    sharepath = ADDON.getSetting('sharepath')
    __log('603 shareLogs sharepath= %r' % sharepath)
    ###if not os.path.exists(sharepath):
    ###    os.mkdir(sharepath)
    ###    __log('606 folder created: %r' % sharepath)
    ###    open(sharepath, 'a').close()
    
    dest = 'DestinationNotSetYet'
    try:
        if sharepath != '':
            destname = (str(xbmc.getInfoLabel('System.FriendlyName'))+'-'+ADDONname).replace(' ','')
            dest = os.path.join(sharepath,destname)
            __log('613 logs to= %r' % dest)
            
            ADDON.setSetting('Excution 1', 'Before Copy Files')
            datapath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
            
            try:
                file = 'DRTV-favorites.txt'
                destf = os.path.join(sharepath,file)
                sourf = xbmcvfs.translatePath(os.path.join(datapath, 'favorites.txt'))
                copyOK = xbmcvfs.copy(destf, sourf)
                if not copyOK:
                    __log('Copy of favorites.txt failed')
                __log('619 favorites.txt to= %r' % sourf)
                __log('620 favorites.txt from= %r' % destf)
            except Exception as e:
                pass
                ADDON.setSetting('Exception favorites.txt', repr(e))
            
            if not change :
                file = destname+'-kodi.log'
                destf = os.path.join(sharepath,file)
                sourf = xbmcvfs.translatePath(os.path.join('special://logpath', 'kodi.log'))
                ###xbmcvfs.copy(sourf, destf)
                if os.path.exists(sourf):
                    copyOK = xbmcvfs.copy(sourf, destf)
                    if not copyOK:
                        __log('Copy of kodi.log failed')
                __log('619 kodi.log from= %r' % sourf)
                __log('620 kodi.log to= %r' % destf)
                
                file = destname+'-addon.log'
                destf = os.path.join(sharepath,file)
                sourf = xbmcvfs.translatePath(os.path.join(datapath, 'addon.log'))
                if os.path.exists(sourf):
                    copyOK = xbmcvfs.copy(sourf, destf)
                    if not copyOK:
                        __log('Copy of addon.log failed')
                __log('627 addon.log from= %r' % sourf)
                __log('628 addon.log to= %r' % destf)
            ###settingUpdated = False    
            if change :
                file = destname+'-settings.cng'
                cngf = os.path.join(sharepath,file)
                localcngf = xbmcvfs.translatePath(os.path.join(datapath, 'settings.cng'))
                ADDON.setSetting('Excution 2', 'cngf = %r' % cngf)
                try:
                    copyOK = xbmcvfs.copy(cngf, localcngf)
                    if not copyOK:
                        __log('Copy of settings.cng failed')
                        ADDON.setSetting('Exception 1', 'Copy of settings.cng failed')
                    if os.path.isfile(localcngf) :
                        ADDON.setSetting('Excution 3', 'localcngf = %r' % localcngf)
                        file = open(localcngf,'r',encoding='utf-8')
                        desc = file.read()
                        ADDON.setSetting('Excution 4', 'desc = %r' % desc)
                        file.close()
                        params = desc.split('<setting id="')[1]
                        ADDON.setSetting('Excution 5', 'params = %r' % params)
                        param = params.split('"')[0]
                        ADDON.setSetting('Excution 6', 'param = %r' % param)
                        values = params.split('>')[1].split('<')[0]
                        ADDON.setSetting('Excution 7', 'values = %r' % values)
                        ADDON.setSetting(param, values)
                        xbmcvfs.delete(cngf)
                        xbmcvfs.delete(localcngf)
                        ###settingUpdated = True
                except Exception as e:
                    pass
                    ADDON.setSetting('Exception', repr(e))
            
            ADDON.setSetting('Excution 9', 'Before Copy settings.xml')
            if not change :
                file = destname+'-settings.xml'
                destf = os.path.join(sharepath,file)
                sourf = xbmcvfs.translatePath(os.path.join(datapath, 'settings.xml'))
                if os.path.exists(sourf):
                    copyOK = xbmcvfs.copy(sourf, destf)
                    ###if settingUpdated :
                    ###    copyOKreturn = xbmcvfs.copy(destf, sourf)
                    if not copyOK:
                        __log('Copy of settings.xml failed')
                    ###if not copyOKreturn:
                    ###    __log('Copy back of settings.xml failed')
                __log('653 settings.xml from= %r' % sourf)
                __log('654 settings.xml to= %r' % destf)
            
    except Exception as  e:
        pass 
        __log('Change setting or Copy shareLogs to sharepath= %r FAILED: %r' % (dest, e))
 
