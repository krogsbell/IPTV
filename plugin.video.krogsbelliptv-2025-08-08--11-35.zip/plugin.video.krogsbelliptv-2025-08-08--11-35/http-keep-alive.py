#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmc, xbmcvfs
# For Python 3.0 and later
from urllib.request import urlopen
import sys
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import definition
import utils
import recordings
    
try:
    ADDON     = definition.getADDON()
    ADDONid   = definition.ADDONgetAddonInfo('id')
    ADDONname = definition.ADDONgetAddonInfo('name')
    datapath  = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
    progpath  = definition.ADDONgetAddonInfo('path')
    module    = 'http-keep-alive.py'
    SHOWLENGTH = 1024
    definition.log('Http Keep Alive Started',SHOWLENGTH,module)
    definition.log('sys.argv= %r' % sys.argv,SHOWLENGTH,module)
    alarmName = 'http-keep-alive'
    marker    = 'once'
    try:
        marker = sys.argv[1]
    except Exception as e:
        pass
        definition.log('30 Except: %r' % e,SHOWLENGTH,module)
    alarmName = alarmName + '-' + marker   
    recordings.updateAlarm(alarmName)
    definition.log('Http Keep Alive after updateAlarm',SHOWLENGTH,module)
    ###utils.notification('Http Keep Alive Started')
    ### SmartDNS Proxy servers: 46.166.189.68, 54.93.173.153, 81.17.17.188
    ### SmartDNS Proxy activation command: https://www.smartdnsproxy.com/api/IP/update/XXXXXXXXXXXXXXX (XXX.. Your direct link)
    
    link = definition.ADDONgetSetting('http-keep-alive')
    data = 'Request not executed! - Less then 5 characters'

    utils.shareLogs()    ### this is responsible for copying shared logs!
    ###utils.logdevreset()   ### Responsible for keepning addon.log below max size
    utils.logdevreset('definitionOLD.log')   ### Responsible for keepning definition.log below max size

    try:
        if len(link) > 5:
            file = urlopen(link)
            deflink = 'https://www.smartdnsproxy.com/api/IP/update/'
            if deflink in link:
                link = deflink + '...'  ### Don't log full link
            data = file.read(500)
            file.close()
            definition.ADDONsetSetting('http-keep-alive-result',repr(data))
            definition.ADDONsetSetting('http-keep-alive-time',repr(datetime.today().strftime('%Y-%m-%d %H:%M:%S')))
            definition.log('error Request: %s,\n Result: %s' % (repr(link),repr(data)),SHOWLENGTH,module)
    except Exception as  e:
        pass
        definition.log('Error in http-keep-alive= %s Except= %s' % (repr(link),repr(e)),SHOWLENGTH,module)
        
except Exception as  e:
    pass
    definition.log('Error in http-keep-alive= %s ERROR= %s' % (repr(link),repr(e)),SHOWLENGTH,module)
definition.log('Ended',SHOWLENGTH,module)

