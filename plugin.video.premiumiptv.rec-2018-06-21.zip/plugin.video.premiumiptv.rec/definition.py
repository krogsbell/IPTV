#!/usr/bin/python
# -*- coding: utf-8 -*-

# 0= NTV.mx, 1= WOZBOX www.wozboxtv.com, 2=www.myindian.tv, 3=www.wliptv.com, 4=roq-tv.com, 5=www.ace-tv.co.uk
# Copy the addon folder to the name of the id to copy addon to, update addon.xml and add the jpg and png icons to be used with the addon then make a zip file and install from zip!

referral= 7   ### 8 ###<===  GlowIPTV         ##########################<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
###values="NTV|WOZBOX (www.wozboxtv.com)|My Indian TV|White Label Spain (http://www.wliptv.com)|ROQ TV Rec|ACE TV Rec|ACE TV Rec Experimental|Premium IPTV (Premiumiptv.co)
import xbmcaddon,xbmc

BASEURL = 'http://www.roq-tv.net:80'
COMMAND = ''
COMMANDEND = ''
REGISTRATION = 'http://roq-tv.com'
REFERRALNAME = 'ROQ TV Rec Dummy'

if referral==0:
    ADDON = xbmcaddon.Addon(id='plugin.video.ntv')
    BASEURL = 'http://www.ntv.mx'
    REGISTRATION = 'http://ntv.mx/?r=Kodi&c=2&a=0&p=9'
    REFERRALNAME = 'NTV'
    
elif referral==1:
    ADDON = xbmcaddon.Addon(id='plugin.video.wozboxntv')
    BASEURL = 'http://www.ntv.mx'
    REGISTRATION = 'wozboxtv.com/registration'
    REFERRALNAME = 'WOZBOX (www.wozboxtv.com)'
    
elif referral==2:
    ADDON = xbmcaddon.Addon(id='plugin.video.myindian')
    BASEURL = 'http://www.myindian.tv'
    REGISTRATION = 'http://www.myindian.tv'
    REFERRALNAME = 'My Indian TV'
    
elif referral==3:
    ADDON = xbmcaddon.Addon(id='plugin.video.wliptv')
    BASEURL = 'http://www.wliptv.com'
    REGISTRATION = 'http://www.wliptv.com'
    REFERRALNAME = 'White Label Spain (http://www.wliptv.com)'
    
elif referral==4:
    ADDON = xbmcaddon.Addon(id='plugin.video.roqtv.rec')
    ###BASEURL = 'http://roq-tv.net:25461'
    BASEURL = 'http://www.roq-tv.net:80'
    COMMAND = '/panel_api.php?'
    COMMANDEND = ''
    REGISTRATION = 'http://roq-tv.com'
    REFERRALNAME = 'ROQ TV Rec'

elif referral==5:
    ADDON = xbmcaddon.Addon(id='plugin.video.acetvrec')
    BASEURL = 'http://ace-tv.xyz:25461'
    REGISTRATION = 'http://www.ace-tv.co.uk'
    REFERRALNAME = 'ACE TV Rec'

elif referral==6:
    ###ADDON = xbmcaddon.Addon(id='plugin.video.acetvrec')
    ADDON = xbmcaddon.Addon(id='plugin.video.roqtvrec')
    ###BASEURL = 'http://ace-tv.xyz:25461'
    BASEURL = 'http://ace-tv.xyz:8080'
    ###BASEURL = 'http://ace.nothingtosee.xyz:8080'   ### TEST 2017-11-23
    REGISTRATION = 'http://www.ace-tv.co.uk'
    REFERRALNAME = 'ACE TV Rec Experimental'
    
elif referral==7:
    ###http://tv.premium.iptv.uno:8080/get.php?username=xxxx&password=xxxx&type=m3u_plus&output=m3u8
    ADDON = xbmcaddon.Addon(id='plugin.video.premiumiptv.rec')
    BASEURL = 'http://tv.premium.iptv.uno:8080'
    COMMAND = 'get.php?'
    COMMANDEND = '&type=m3u_plus&output=m3u8'
    REGISTRATION = 'http://www.premiumiptv.co'
    REFERRALNAME = 'Premium IPTV (Premiumiptvco.com)'

elif referral==8:
    ###http://tv.glowiptv.iptv.uno:8080/get.php?username=xxx&password=xxxx&type=m3u_plus&output=m3u8
    ADDON = xbmcaddon.Addon(id='plugin.video.glowiptv.rec')
    BASEURL = 'http://tv.glowiptv.iptv.uno:80'
    COMMAND = 'get.php?'
    COMMANDEND = '&type=m3u_plus&output=m3u8'
    REGISTRATION = 'http://glowiptv.com'
    REFERRALNAME = 'GlowIPTV (glowiptv.com)'

else:
    ADDON = xbmcaddon.Addon(id='plugin.video.wozboxntv')
    BASEURL = 'http://www.ntv.mx'
    COMMAND = ''
    COMMANDEND = ''
    REGISTRATION = 'wozboxtv.com/registration'
    REFERRALNAME = 'Dummy set to WOZBOX (www.wozboxtv.com)'

ADDON.setSetting('my_referral_link',str(referral))
ADDON.setSetting('my_referral_name',REFERRALNAME)
ADDON.setSetting('my_referral_registration',REGISTRATION)
###xbmc.log('definition.py in %s with referral= %s' % (ADDON.getAddonInfo('id'), repr(referral)))

def getADDON():
    return ADDON

def getBASEURL():
    return BASEURL  
    
def getCOMMAND():
    return COMMAND 
    
def getCOMMANDEND():
    return COMMANDEND  
    
def getREGISTRATION():
    return REGISTRATION 
    
def getKrogsbellAddOns():
    return ['plugin.video.glowiptv.rec','plugin.video.premiumiptv.rec','plugin.video.roqtv.rec']
