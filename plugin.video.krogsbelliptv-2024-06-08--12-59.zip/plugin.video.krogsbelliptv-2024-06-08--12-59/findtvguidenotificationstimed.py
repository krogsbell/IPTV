#!/usr/bin/python
# -*- coding: utf-8 -*-
from findtvguidenotifications import findtvguidenotifications
from recordings import addAlarm
from definition import getADDON
from utils import logdev
ADDON      = getADDON()
module     = 'findtvguidenotificationstimed.py'
logdev(module,'error findtvguidenotifications.py - Started')
addAlarm(module, 'start', '', '00:00:00', 'options')
findtvguidenotifications()
logdev(module,'error findtvguidenotifications.py - Ended')
