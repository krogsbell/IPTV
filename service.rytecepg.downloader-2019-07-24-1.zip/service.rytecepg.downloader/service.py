#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
import xbmc, xbmcgui, xbmcaddon, os
from resources.lib import common
from resources.lib import rytec
import datetime
import shutil

#id = 'service.rytecepg.downloader'
#addon = xbmcaddon.Addon(id=id)
addon = xbmcaddon.Addon()
IMAGE = os.path.join(addon.getAddonInfo('path'), 'icon.png')
datapath    = xbmc.translatePath(addon.getAddonInfo('profile'))
if os.path.isdir(datapath) == False:
    os.makedirs(datapath)

def logX(message):
    xbmc.log('[Rytec EPG Downloader service.py]: '  + message)

def log(message):
    if addon.getSetting('addonlog') == '1':
        logX(message)
    else:
        module = 'service.py'
        nowHMS=datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        addonlog = os.path.join(datapath, 'addon.log')
        LogDev = open(addonlog, 'a')
        # Write to our text file the information we have provided and then goto next line in our file.
        LogDev.write(nowHMS + ' ' + module + ': ' + message + '\n')

def makeOldFile(file):
    if os.path.isfile(file):
        ext = '.' + file.split('.')[-1]
        new = 'OLD' + ext
        oldfile = file.replace(ext,new)
        log('oldfile= %r' % oldfile)
        shutil.copyfile(file, oldfile)

def deleteFile(file):
    tries    = 0
    maxTries = 10
    while os.path.exists(file) and tries < maxTries:
        try:
            print 'removeFile: %s' % file  # Put in LOG
            os.remove(file)
            break
        except:
            print 'Failed #= %d' % tries  # Put in LOG
            xbmc.sleep(500)
            tries = tries + 1

def logreset():
    ### If size of addon.log > 3 MB - save as addonOLD.log
    try:
        datapath = xbmc.translatePath(addon.getAddonInfo('profile'))
        addonlog = os.path.join(datapath, 'addon.log')
        logsize = os.stat(addonlog).st_size
        log('logsize= %r' % logsize)
        if logsize > 3000000:
            log('reset logfile')
            makeOldFile(addonlog)
            deleteFile(addonlog)
    except Exception, e:
        pass
        log('Error in logreset: ' + repr(e))
    
def logbox(message):
    ###cmd  = 'XBMC.Notification(%s, %s, %d, %s)' % ('[Rytec EPG Downloader]: ', message, 9999, IMAGE)
    log(message)
    common.logbox(message)
    #status[1] = status[0]
    #status[0] = message
    #addon.setSetting('status',status[0])
    #addon.setSetting('status1',status[1])
    #addon.setSetting('status2',status[2])
    #if addon.getSetting('notification') == 'Yes':
    #    xbmc.executebuiltin(cmd)
    
def notify(message):
    log('Notify: [Rytec EPG Downloader]: ', repr(message))
    cmd  = 'XBMC.Notification(%s, %s, %d, %s)' % ('[Rytec EPG Downloader]: ', repr(message), 9999, IMAGE)
    if addon.getSetting('notification') == 'Yes' and xbmc.getCondVisibility('Player.HasMedia') != True :
            xbmc.executebuiltin(cmd)

"""    
try:
    import setupbackports
    setupbackports.setup()
    log('setupbackports startet')
except Exception, e:
    pass
    logbox('[COLOR red]Could not setupbackports [/COLOR] Error: ' + repr(e))
"""
    
    
def start_rytec_service(manual=False):
    logreset()
    log('rytec service started (manual= %r)' % (manual))
    descriptions = common.get_descriptions()
    log('descriptions= ' + repr(descriptions))
    sources_list = None
    merge = False
    for description in descriptions:
        log('description= ' + repr(description))
        ret = False
        if description.startswith('http'):
            epg_url = description
        else:
            epg_url = common.get_description_url(description)
        log('epg_url= ' + repr(epg_url))
        if epg_url:
            ret = common.load_local_xml(epg_url)
            log('ret= ' + repr(ret))
            if ret:
                log('no epg update needed ' + description)
            else:
                if description.startswith('http'):
                    if manual:
                        ret = rytec.download_epg(epg_url,description)
                if not manual:
                    ret = rytec.download_epg(epg_url,description)
                    if ret: merge = True
        if not ret and not description.startswith('http'):
            log('sources_list= ' + repr(sources_list))
            if not sources_list: sources_list = rytec.get_sources_list()
            ###log('sources_list= ' + repr(sources_list))
            if sources_list:
                ret = rytec.get_epg(sources_list, description)
                log('ret= ' + repr(ret))
                if ret:
                    merge = True
                else:
                    logbox('[COLOR red]Could not download epg data: %s [/COLOR]' % description)
                    ###xbmc.executebuiltin('Notification(could not download epg data: %s)' % description)
                    ###log('could not download epg data ' + description)
            else:
                logbox('[COLOR red]Could not download sources list: %s [/COLOR]' % description)
                ###xbmc.executebuiltin('Notification(could not download sources list: %s)' % description)
                ###log('could not download sources list '+ description)
    #if merge and len(descriptions) > 1:
    if merge and len(descriptions) > 0:  
        try:
            common.merge_epg()
        except Exception, e:
            pass
            logbox('[COLOR red]could not merge epg ' + description + '[/COLOR] Error: ' + repr(e))

def service():
    a = False
    i = 0
    while (not xbmc.abortRequested):
        if common.download_allowed(a):
            if not common.blocked(a):
                start_rytec_service()
        a = True
        i += 1
        log('Service loop# %r' % i)
        ###xbmc.sleep(100000) 
        xbmc.sleep(10000000) 
        
log('common.get_xml_path()= %r' % common.get_xml_path())
log('common.get_activation_code()= %r' % common.get_activation_code())
if common.get_xml_path() and common.get_activation_code():
    try:
        log('sys.argv= %r, length= %r' % (sys.argv,len(sys.argv)))
        addon.setSetting('manual','False')
        dialog = xbmcgui.Dialog()
        if len(sys.argv) > 1:
            if sys.argv[1:][0] == 'manual_download':
                notify('Manual Download Startet')
                manual = True
                addon.setSetting('manual','True')
                logbox('Manual Download Startet')
                common.removeGzXz()   ### Remove old EPG compressed files
                start_rytec_service(manual)
                #dialog = xbmcgui.Dialog()
                addon.setSetting('manual','False')
                ok = dialog.ok('Rytec EPG Downloader', 'Manual Download Finished')
            if sys.argv[1:][0] == 'setchannels':
                notify('Set Channels Started')
                log('Set Channels Started')
                dialog = xbmcgui.Dialog()
                sources_list= rytec.get_sources_list()
                if sources_list != []:
                    log('rytec.get_sources_list()= %r' % sources_list)
                    channellist = rytec.get_epg_list(sources_list)
                    log('rytec.get_epg_list()= %r' % channellist)
                    ret = common.setchannels(channellist)
                    log('Return from Set Channels: %r' % ret)
                    ok = dialog.ok('Rytec EPG Downloader', 'Set Channels Finished\nClose the setup with OK to save the new setup!')
                else:
                    notify('[COLOR red]Error getting Channels![/COLOR]')
            if sys.argv[1:][0] == 'merge':
                notify('Merge Started')
                log('Merge Started')
                ret = common.merge_epg()
                log('Return from Merge: %r' % ret)
                #dialog = xbmcgui.Dialog()
                ok = dialog.ok('Rytec EPG Downloader', 'Merge Finished')
                
    except Exception, e:
        pass
        ###notify('Error in manual or setchannel: ' + repr(e))
        log('Error in manual or setchannel: ' + repr(e))
        
    service()
