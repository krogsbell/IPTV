#!/usr/bin/python
# -*- coding: utf-8 -*-

import urllib
try:
    # For Python 3.0 and later
    from urllib.request import urlopen
except ImportError:
    # Fall back to Python 2's urllib2
    from urllib2 import urlopen
    
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import _strptime
import os
import xbmcgui, xbmcplugin, xbmcaddon
import utils
import json as simplejson
import xbmcvfs
import channels

CHANNELS_URL = 'https://www.dr.dk/mu-online/api/1.0/channel/all-active-dr-radio-channels'
PATH = sys.argv[1]
###idtext = PATH.replace('plugin:','').replace('/','').replace('special:homeaddons','')
###ADDON = xbmcaddon.Addon(id=idtext)
ADDON = xbmcaddon.Addon('plugin.audio.dr.dk.netradio')
ADDONname = ADDON.getAddonInfo('name')
ADDONid   = ADDON.getAddonInfo('id')
ADDONpath = xbmcvfs.translatePath('special://home/addons/%s/' % ADDONid)
LOGO_PATH = os.path.join(ADDONpath, 'resources', 'logos')
ICON = os.path.join(ADDONpath, 'icon.png')
FANART = os.path.join(ADDONpath, 'fanart.jpg')
module = 'startstation.py'

def __log(text):
    utils.logdev(sys.argv[0]+' '+sys.argv[2],text)
    
def now():   ### Local time
    dt_obj= datetime.now()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
    
def todayDate():
    dt_obj= datetime.today().date()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
    
def AdjustDateTime(dateTS,Hours,Minutes):
    dt_obj = datetime.fromtimestamp(dateTS) + timedelta(hours= int(Hours), minutes= int(Minutes))
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
    
def humantime(ts):   ### Timestamp to human time
    if isinstance(ts, int):
        dt = datetime.fromtimestamp(ts)
    elif isinstance(ts, datetime.datetime):
        dt = ts
    else:
        return ts
    ###dt = datetime.datetime.fromtimestamp(ts)
    ht = dt.strftime("%Y-%m-%d %H:%M:%S")
    ###ht = dt.strftime("%m-%d %H:%M")
    return ht

def showError(message):
    heading = 'Error in Startstation!'
    line1 = ADDON.getLocalizedString(30900)
    line2 = ADDON.getLocalizedString(30901)
    ###xbmcgui.Dialog().ok(heading, line1, line2, message)
    __log(heading+'\n'+line1+'\n'+line2+'\n'+message)    
    
def testHTTP(url):  
    try:
        return True
        import socket
        if url[:4].lower() != 'http':
            __log('testHTTP(%r)=\n%r' % (url,'Play non http or https!'))
            return True
        # timeout in seconds
        timeout = 10
        socket.setdefaulttimeout(timeout)

        # this call to urlopen now uses the default timeout
        # we have set in the socket module
        req = urllib.parse.Request(url)
        response = urlopen(req)
        __log('testHTTP(%r)=\n%r' % (url,response))
        return response
    except Exception as e:
        pass
        __log('testHTTP(%r)\nERROR: %r' % (url,e))
        return False

def playEPG(idx):
    __log('99 playEPG(idx= %r)'% idx)
    try:
        __log('101 playEPG(idx= %r)'% idx)
        u = urlopen(CHANNELS_URL)
        __log('103 playEPG(idx) u= %r'% u)
        channelList = simplejson.loads(u.read())
        ###__log('105 playEPG(idx) channelList= %r'% channelList)
        u.close()
    except Exception as  ex:
        __log('108 Exception ex= %r'% ex)
        showError(str(ex))
        return
    try:
        for channel in channelList:
            title = channel['Title']
            slug  = channel['Slug']
            if title[0:3] == 'DR ':
                title = title[3:]
            __log('playEPG(title= %r slug= %r)'% (title,slug))
            idxlower = idx.lower()
            if ('p4' in idxlower and idxlower == slug) or idxlower[:2] == slug[:2] and not 'p4' in idxlower: 
            ###if idx.lower() == slug:
                sourceUrl = channel['SourceUrl']
                logoImage = os.path.join(LOGO_PATH, sourceUrl[sourceUrl.rindex('/') + 1:] + '.png')
                if xbmcvfs.exists(logoImage):  
                    iconImage=logoImage
                else:
                    iconImage=ICON
                item = xbmcgui.ListItem(title)
                item.setArt({ 'icon': iconImage, 'thumb' : iconImage })
                item.setProperty('IsPlayable', 'true')
                item.setProperty('Fanart_Image', FANART)
                item.setInfo(type='music', infoLabels={
                    'title': title
                })

                url = None

                if 'StreamingServers' in channel:
                    for server in channel['StreamingServers']:
                        if 'LinkType' in server and server['LinkType'] == 'ICY' and 'Qualities' in server:
                            try:
                                url = server['Server'] + '/' + server['Qualities'][0]['Streams'][0]['Stream']
                                break
                            except:
                                pass
                __log('playEPG(url= %r)'% url)
                if url:
                    __log('play-ing-EPG(url= %r)'% url)
                    ###url = url.replace('https://live-icy.dr.dk/A/A02H.mp3','http://live-icy.gss.dr.dk/A/A25L.mp3')
                    url = url.replace('https://live-icy.dr.dk/A/A02H.mp3','http://live-icy.gss.dr.dk/A/A28L.mp3')  ### P4 København
                    __log('url= %r' % url)
                    if title[0:3] == 'DR ':
                        title = title[3:]
                    if title[0:2] != 'P4':
                        title = title[:2]
                    logoImage = os.path.join(LOGO_PATH, title + '.png')
                    item = xbmcgui.ListItem(path=url)
                    item.setArt({ 'icon': logoImage, 'thumb' : logoImage })
                    item.setInfo(type='music', infoLabels={
                        'title': title
                    })
                    ADDON.setSetting('programplaying',idx)
                    if not xbmc.Player().isPlaying():
                        __log('0 Player is NOT Playing #0')
                    else:
                        __log('0 Player is Playing #0')
                    xbmc.Player().play(url, item, True)
                    __log('167 play-ing-EPG-started(url= %r)'% url)
                    xbmc.sleep(1000)
                    if not xbmc.Player().isPlaying():
                        __log('1 Player is NOT Playing #1')
                    else:
                        __log('1 Player is Playing #1')
                    x = 0
                    xbmc.sleep(10000)    ### 2023-08-16
                    while not xbmc.Player().isPlaying() and x <= 100:
                        xbmc.sleep(10000)   ### 2023-08-16
                        x += 1
                        try:
                            __log('Player is NOT playing - try again #%r' % x)
                            xbmc.Player().play(url, item, True)
                        except Exception as e:
                            pass
                            __log('PlayEPG Player ERROR: %r' % e)
                        __log('PlayEPG Player break!')
                        break   ### Stop at first match
    except Exception as e:
        pass
        __log('PlayEPG ERROR: %r' % e)
    ### playOther(idx)   ### 2023-08-16

def playOther(idx):
    __log('playEPG(idx= %r)'% idx)
    url = None
    try:
        ### other channel
        __log('Other Channels')
        if url == None:
            try:
                channel = None
                for c in channels.CHANNELS:
                    __log('Other Channel= %r: %r' % (c.id,c.name))
                    if c.name == idx:
                        channel = c
                        break

                if channel is None:
                    __log('Other Channel= None')
                    return

                logoImage = xbmcvfs.translatePath(os.path.join(LOGO_PATH, str(channel.id) + '.png'))
                item = xbmcgui.ListItem(path=channel.url)
                item.setArt({ 'icon': logoImage, 'thumb' : logoImage })
                item.setInfo(type='music', infoLabels={
                    'title': channel.name
                })
                __log('play-ing-EPG(url= %r)'% channel.url)
                if testHTTP(channel.url):
                    ###__log('xbmc.Player().isPlaying(565): %r' % xbmc.Player().isPlaying())
                    ###ADDON.setSetting('programplaying',idx)
                    url = channel.url
                    ###xbmcplugin.setResolvedUrl(HANDLE, True, listitem = item)
                    ###__log('xbmc.Player().isPlaying(569): %r' % xbmc.Player().isPlaying())
                else:
                    __log('NOT play-ing-EPG(url= %r)'% channel.url)
            except Exception as e:
                pass
                __log('playOther idx: %r\nERROR: %r' % (idx,e))
        __log('playEPG(url= %r)'% url)
        if url != None:
            __log('play-ing-EPG(url= %r)'% url)
            """
            ###url = url.replace('https://live-icy.dr.dk/A/A02H.mp3','http://live-icy.gss.dr.dk/A/A25L.mp3')
            url = url.replace('https://live-icy.dr.dk/A/A02H.mp3','http://live-icy.gss.dr.dk/A/A28L.mp3')  ### P4 København
            __log('url= %r' % url)
            if title[0:3] == 'DR ':
                title = title[3:]
            if title[0:2] != 'P4':
                title = title[:2]
            logoImage = os.path.join(LOGO_PATH, title + '.png')
            item = xbmcgui.ListItem(path=url)
            item.setArt({ 'icon': logoImage, 'thumb' : logoImage })
            item.setInfo(type='music', infoLabels={
                'title': title
            })
            """
            ADDON.setSetting('programplaying',idx)
            if not xbmc.Player().isPlaying():
                __log('Player is NOT Playing #0')
            else:
                __log('Player is Playing #0')
            xbmc.Player().play(url, item, True)
            __log('250 play-ing-EPG-started(url= %r)'% url)
            xbmc.sleep(1000)
            if not xbmc.Player().isPlaying():
                __log('Player is NOT Playing #1')
            else:
                __log('Player is Playing #1')
            x = 0
            while not xbmc.Player().isPlaying() and x <= 100:
                xbmc.sleep(1000)
                x += 1
                try:
                    __log('Player is NOT playing - try again #%r' % x)
                    xbmc.Player().play(url, item, True)
                except Exception as e:
                    pass
                    __log('PlayEPG Player ERROR: %r' % e)
                break   ### Stop at first match
    except Exception as e:
        pass
        __log('PlayEPG ERROR: %r' % e)
    
try:
    program    = sys.argv[0]
    PATH       = sys.argv[1]
    station_id = sys.argv[2]
    
except Exception as e:
    pass
    title = 'StartStation'
    PATH = repr(e)
    station_id = 'P4KBH'
    
try:
    __log('sys.argv= %r' % sys.argv)
    __log('os.environ= %s' % os.environ['OS'] ) #put in LOG
    __log('PATH= %r' % PATH)
    __log('ADDONpath= %r' % ADDONpath)
    __log('LOGO_PATH= %r' % LOGO_PATH)
    __log('ICON= %r' % ICON)
    __log('FANART= %r' % FANART)

except Exception as e:
    pass
    __log('ERROR data: %r' % e)
try:
    player = xbmc.Player()
    try:
        timebetweenupdates = ADDON.getSetting('timebetweenupdates').split(':')
        __log('293 timebetweenupdates= %r' % timebetweenupdates)
        timebetweenupdatesH = int(timebetweenupdates[0])
        timebetweenupdatesM = int(timebetweenupdates[1])
        timebetweenupdatesS = int(timebetweenupdates[2])
        
        timeaftervideodummy = int(ADDON.getSetting('timeaftervideo'))//(timebetweenupdatesH*3600 + timebetweenupdatesM*60 + timebetweenupdatesS)
        __log('timeaftervideodummy= %r' % timeaftervideodummy)
    except Exception as e:
        pass
        timeaftervideodummy = 5
        __log('timeaftervideodummy ERROR: %r' % e)
    
    if player.isPlayingVideo():
        PlayingVideo = True
        timeaftervideo = timeaftervideodummy
        try:
            ADDON.setSetting('timeaftervideo',str(timeaftervideo*(timebetweenupdatesH*3600 + timebetweenupdatesM*60 + timebetweenupdatesS)))  ### Adjust to actual time based on timeupdateinterval
            ADDON.setSetting('timeaftervideocounter',str(timeaftervideo))
        except Exception as e:
            pass
            __log('timeaftervideo ERROR: %r' % e)
        __log('PlayingVideo = True')
    else:
        PlayingVideo = False
        timeaftervideoI = ADDON.getSetting('timeaftervideocounter')
        if timeaftervideoI == '':
            timeaftervideoI = timeaftervideodummy
        timeaftervideo = int(timeaftervideoI)
        timeaftervideo -= 1
        if timeaftervideo <= 0:
            timeaftervideo = 0
        ADDON.setSetting('timeaftervideocounter',str(timeaftervideo))
        __log('PlayingVideo = False')
except Exception as e:
    pass
    PlayingVideo = False
    timeaftervideo = timeaftervideodummy
    try:
        ADDON.setSetting('timeaftervideo',str(timeaftervideo*(timebetweenupdatesH*3600 + timebetweenupdatesM*60 + timebetweenupdatesS)))  ### Adjust to actual time based on timeupdateinterval
    except Exception as e:
        pass
        __log('timeaftervideo ERROR: %r' % e)
    ADDON.setSetting('timeaftervideocounter',str(timeaftervideo))
    __log('Is Palying Video Test ERROR: %r' % e)
__log('Test part:Play Video= %r, timeaftervideo= %r' % (PlayingVideo,timeaftervideo))

try:
    __log('code part')
    if not PlayingVideo and timeaftervideo <= 0 :
        __log('Video is not playing')
        utils.setChannelVolumen(station_id)
        __log('after utils.setChannelVolumen(station_id= %r)' % station_id )
        """
        try:
            if ADDON.getSetting('autovolumen') == 'true' and not PlayingVideo:
                __log('Set Volume')
                ### volumens = 100@6:30, 80@23:30
                testnow = now()
                today   = todayDate()
                ChannelVolumen = utils.getChannelVolumen(station_id)
                __log('station_id= %r' % station_id)
                __log('ChannelVolumen= %r' % ChannelVolumen)
                __log('Set testnow= %r, today= %r' % (humantime(testnow), humantime(today)))
                newvol = '100'
                volumens = ADDON.getSetting('volumens').split(',')
                __log('Set Volumens= %r' % volumens)
                newvol = '0'
                for volumen in volumens:
                    __log('Set Volumen= %r' % volumen)
                    vol = volumen.split('@')
                    volu = vol[0]
                    if int(newvol) < int(volu):
                        newvol = volu
                        __log('newvol adjusted to: %r' % newvol)
                for volumen in volumens:
                    __log('Set Volumen= %r' % volumen)
                    vol = volumen.split('@')
                    volu = vol[0]
                    vtim = vol[1].split(':')
                    __log('Set vtim= %r' % vtim)
                    vtimadjusted = AdjustDateTime(today,vtim[0],vtim[1])
                    __log('Set vtimadjusted= %r' % humantime(vtimadjusted))
                    if vtimadjusted <= testnow:
                        newvol = str(int(volu) * int(ChannelVolumen) // 100)
                xbmc.executebuiltin( "SetVolume(%s,showvolumebar)" % ( newvol ) )
                __log('Set Volumen now to %r' % newvol)
                ADDON.setSetting('setvolumen',newvol)
            
        except Exception as e:
            pass
            __log('Set Volumen ERROR: %r' % e)
            ADDON.setSetting('setvolumen','ERROR: %r' % e)
        """
        playEPG(station_id)
        utils.logdev('window','StartStation module= %r, CurrentWindowIdWindowId= %r' % (module, xbmcgui.getCurrentWindowId()))
        xbmc.executebuiltin("Container.Refresh")
    
except Exception as e:
    pass
    __log('ERROR: %r' % e)