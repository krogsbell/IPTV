import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
import sys
import urllib
import time
import datetime
from logger import Log
from platform import Platform
from settings import Settings
import utils

ADDON   = xbmcaddon.Addon()
ADDONid = ADDON.getAddonInfo('id')

def log(message):
    module = 'gui.py'
    utils.logdev(module,message)
    
class Gui:
    dialog = None
    addon = None
    settings = None
    app = None

    def __init__(self, _app, _addon, _settings):
        self.dialog = xbmcgui.Dialog()
        self.app = _app
        self.addon = _addon
        self.settings = _settings
    
    @staticmethod
    def log(message):
        module = 'Gui.gui.py'
        utils.logdev(module,message)
    
    @staticmethod
    def search(name):
        search_entered = None
        keyboard = xbmc.Keyboard(search_entered, 'Please Enter ' + str(name))
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText()
        return search_entered

    def numeric(self, name):
        keyboard = self.dialog.numeric(0, 'Please Enter ' + str(name))
        return keyboard

    @staticmethod
    def signin():
        email = Gui.search('Email')
        password = Gui.search('Password')
        return email, password

    @staticmethod
    def register():
        firstname = Gui.search('First Name')
        lastname = Gui.search('Last name')
        email = Gui.search('Email')
        password = Gui.search('Password')
        return firstname, lastname, email, password

    def signin_or_register(self):
        return self.dialog.yesno(Platform.BRAND, 'Do you Wish To Register', '', "Or Sign In", 'Register', 'Sign In')

    def register_success(self):
        self.dialog.ok(Platform.BRAND, 'Thank You For Registering', 'Please Open Your Email Client',
                       'And Verify Your Email Address')

    def show_message(self, line1 = '', line2 = '', line3 = ''):
        self.dialog.ok(Platform.BRAND, line1, line2, line3)

    def exit_and_restart(self, message):
        return self.dialog.yesno(Platform.BRAND, message, '', 'Exit And Restart Again')

    def please_try_again(self, message):
        return self.dialog.yesno(Platform.BRAND, message, '', 'Please Try Again')

    def categories(self, categories):
        imageUrl = ''
        # if ADDON.getSetting('enable_record') == 'true':
        #    addDir('My Recordings', 'url', 6, '', '', '', '')
        # addDir('My Account', 'url', 8, '', '', '', '')
        self.add_folder('Favorites', self.app.MODE_FAVORITES, '')
        self.add_folder('All channels', self.app.MODE_CHANNELS, '')
        self.add_folder('Search by name', self.app.MODE_SEARCH, '')
        log('categoriesXyX= %r' % categories)
        categories = sorted(categories.items(), key = lambda kv: kv[1])
        log('categoriesXyZ= %r' % categories)
        for tuple in categories:
            self.add_folder(tuple[1], self.app.MODE_CHANNELS, str(tuple[0]))
            #self.addDir(categories[k], 'url', self.app.MODE_CHANNELS, imageUrl + '/tvicon.jpg', str(k), '', '')
        self.setView('movies', 'main-view')

    def channels(self, channels):
        ###log('channels= %r' % channels)
        try:
            Channels = []
            log('len(channels)= %r' % len(channels))
            for k in channels:
                #log('channelK= %r' % channels[k])
                #log('channelKname= %r' % channels[k]['name'])
                Channels.append([channels[k]['name'],channels[k]])
            Channels = sorted(Channels)
            #log('ChannelsXyX= %r' % Channels)
            for i in range(0, len(Channels)):
                self.add_channel(Channels[i][1])
        except Exception,e:
            pass
            log('channels= ERROR %r' % e)
        self.setView('movies', 'channels-view')

    def play_stream(self, name, url, logo):
        Log.log('play_stream(self, name= %r, url= %r, logo)' % (name,url))
        remote_icon = Platform.SITE + '/assets/img/channels/' + logo + '|auth=TLS&verifypeer=false'
        item = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = remote_icon)
        item.setInfo(type="Video", infoLabels={"Title": name})
        item.setProperty("IsPlayable", "true")
        item.setPath(url)
        Log.log('play_stream(self, name= %r, url= %r\nsys.argv= %r)' % (name,url,sys.argv))
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

    def record_stream(self, name, url, logo, description, source):
        Log.log('record_stream(self, name= %r, url= %r, logo, description= %r)' % (name,url,description))
        Log.log('record_stream(self, source= %r)' % (source))
        remote_icon = Platform.SITE + '/assets/img/channels/' + logo + '|auth=TLS&verifypeer=false'

        ###URI='plugin://plugin.video.dreamiptv/?url=url&mode=2012&source='+ADDONid+'&name=' + name.encode("utf-8") + ' [unlim.tv]&uri='+ url.replace(' ','AAabBB').replace('?','aAabBb').replace('=','BBabAA').replace(',','###').replace('&','AaAaA') + '&description='+description
        URI= source + '?url=url&mode=2012&source=' + ADDONid + '&name=' + name.encode("utf-8") + ' [unlim.tv]&uri='+ url.replace(' ','AAabBB').replace('?','aAabBb').replace('=','BBabAA').replace(',','###').replace('&','AaAaA') + '&description=' + description
            
        Log.log('unlim.tv-->recorduri.py: URI= %s' % repr(URI))
        tries    = 0
        maxTries = 10
        maxSleep = 500
        try:
            Log.log(repr(URI))
            xbmc.executebuiltin('XBMC.RunPlugin(%s)' % URI) 
            xbmc.sleep(maxSleep)
        except Exception,e:
            pass 
            Log.log('record_stream ERROR: %r' % e)
            
    def record_stream_archive(self, name, url, logo, description, source):
        Log.log('record_stream_archive(self, name= %r, url= %r, logo, description= %r)' % (name,url,description))
        Log.log('record_stream_archive(self, source= %r)' % (source))
        remote_icon = Platform.SITE + '/assets/img/channels/' + logo + '|auth=TLS&verifypeer=false'

        URI= source + '?url=url&mode=2012&source=' + ADDONid + '&name=' + name.encode("utf-8") + ' [unlim.tv]&uri='+ url.replace(' ','AAabBB').replace('?','aAabBb').replace('=','BBabAA').replace(',','###').replace('&','AaAaA') + '&description=' + description
            
        Log.log('unlim.tv-->recorduri.py: URI= %s' % repr(URI))
        tries    = 0
        maxTries = 10
        maxSleep = 500
        try:
            Log.log(repr(URI))
            xbmc.executebuiltin('XBMC.RunPlugin(%s)' % URI) 
            xbmc.sleep(maxSleep)
        except Exception,e:
            pass 
            Log.log('record_stream_archive ERROR: %r' % e)
           
    def sync_stream(self, name, url, logo):
        Log.log('sync_stream(self, name= %r, url= %r, logo)' % (name,url))
        remote_icon = Platform.SITE + '/assets/img/channels/' + logo + '|auth=TLS&verifypeer=false'
        ###URI='plugin://plugin.video.unlimtv/?url=url&mode=211&source='+ADDONid+'&cat=' + cat[3:] +'&startdate=' + str(startDateTS) +'&duration='+ duration
        Log.log('url 1= %r' % url)
        url += '&'
        cat = Log.param(url,'stream')
        duration = Log.param(url,'duration')
        startDate = Log.param(url,'start')
        ### 2017-05-21:16-00
        time_tuple = time.strptime(startDate, "%Y-%m-%d:%H-%M")
        startDateTS = int(time.mktime(time_tuple))
        ### Get url: '/channels/get-record/' + chId + '/' + evtStart + '/' + evtDuration
        ### https://www.unlim.tv:443/channels/get-record/949/1557407400/6000
        ###url = 'https://www.unlim.tv:443/channels/get-record/'+cat+'/'+str(startDateTS)+'/'+duration
        ###Log.log('url 2= %r' % url)
        url = Api.get_archive_link(self, channel_id, evtStart, evtDuration)
        
        ###URI='plugin://plugin.video.unlimtv/?url=url&mode=211&source='+ADDONid+'&cat=' + cat[3:] +'&startdate=' + str(startDateTS) +'&duration='+ duration
        
        URI='plugin://plugin.video.krogsbelliptv.rec/?url=url&mode=2012&source='+ADDONid+'&name=' + name.encode("utf-8") + ' [unlim.tv]&uri='+ url.replace(' ','AAabBB').replace('?','aAabBb').replace('=','BBabAA').replace(',','###').replace('&','AaAaA')
            
        Log.log('unlim.tv-->recorduri.py: URI= %s' % repr(URI))
        tries    = 0
        maxTries = 10
        maxSleep = 500
        try:
            Log.log(repr(URI))
            xbmc.executebuiltin('XBMC.RunPlugin(%s)' % URI) 
            xbmc.sleep(maxSleep)
        except Exception,e:
            pass 
            Log.log('sync_stream ERROR: %r' % e)

    def add_folder(self, name, mode, cat):
        item = xbmcgui.ListItem(name.encode('utf-8'), iconImage = 'DefaultFolder.png')
        item.addContextMenuItems([])
        url = sys.argv[0] + '?mode=' + str(mode) + '&cat=' + cat
        xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = url, listitem = item, isFolder = True)

    def add_channel(self, channel):
        log('Channel= %r' % channel)
        name = channel['name'].encode('utf-8')
        log('name= %r' % name)
        epgnow = channel['epg_now']
        plot = ''
        event = ''
        try:
            event = epgnow['event_name'].encode('utf-8')
            desc = epgnow['description'].encode("utf-8")
            if len(desc) > 0:
                plot = desc
        except Exception,e:
            pass 
            Log.log('record_stream ERROR: %r' % e)

        if channel['health'] == 1:
            if len(event) > 0:
                name = name + ' [COLOR yellow]' + event + '[/COLOR]'
        else:
            name = '[COLOR grey][I]' + name + '[/I][/COLOR] [COLOR blue]broken[/COLOR]'

        remote_icon = Platform.SITE + '/assets/img/channels/' + channel['logo'] + '|auth=TLS&verifypeer=false'
        item = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = remote_icon)
        item.setInfo(type = "Video", infoLabels = {'title': name, 'plot': plot, 'playcount': 0})

        if channel['health'] == 1:
            item.setProperty('IsPlayable', 'true')

        menu = []
        url = 'XBMC.RunPlugin(' + sys.argv[0] + '?mode=';
        text = 'Toggle favorites'
        if channel['favorite'] == 0:
            url = url + str(self.app.MODE_FAV_ADD)
        else:
            url = url + str(self.app.MODE_FAV_REMOVE)
        url = url + '&cat=' + str(channel['id']) + ')'
        text = '[COLOR orange][B]' + text + '[/B][/COLOR]'
        menu.append((text, url))
        item.addContextMenuItems(items = menu, replaceItems = True)

        url = sys.argv[0] + '?mode=' + str(self.app.MODE_PLAY) + '&cat=' + str(channel['id'])
        xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = url, listitem = item, isFolder = False)


    def setView(self, content, viewType):
        # set content type so library shows more views and info
        if content:
            xbmcplugin.setContent(int(sys.argv[1]), content)
        if self.addon.getSetting('auto-view') == 'true':  # <<<----see here if auto-view is enabled(true)
            xbmc.executebuiltin(
                "Container.SetViewMode(%s)" % self.addon.getSetting(viewType))  # <<<-----then get the view type
