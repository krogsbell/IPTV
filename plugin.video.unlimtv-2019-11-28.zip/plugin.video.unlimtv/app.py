from platform import Platform
from settings import Settings
from api import Api
from parameters import Parameters
from logger import Log
from gui import Gui
from middleware import Middleware
import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui
import sys

import base64


class App:

    MODE_CATEGORIES = None
    MODE_CHANNELS = 2
    MODE_FAVORITES = 3
    MODE_SEARCH = 4
    MODE_FAV_ADD = 5
    MODE_FAV_REMOVE = 6
    MODE_PLAY = 200
    MODE_RECORD = 210
    MODE_RECORD_ARCHIVE = 2100
    MODE_SYNC = 211
    MODE_EXIT = 666

    addon = None
    settings = None
    api = None
    parameters = None
    gui = None
    middleware = None

    data_path = None

    def __init__(self):
        self.addon = xbmcaddon.Addon(id = Platform.PLUGIN)
        self.data_path = xbmc.translatePath(self.addon.getAddonInfo('profile'))
        self.settings = Settings(self.addon)
        self.parameters = Parameters()
        self.gui = Gui(self, self.addon, self.settings)
        self.api = Api(self, self.settings)
        self.middleware = Middleware(self, self.api)
        return

    def run(self):

        auth = False

        # if we have cookies, lets just use it
        if self.api.have_cookies_in_file():
            Log.log('---- have cookies ----')
            self.api.load_cookies()
            auth = True

        # first we try to auth with saved creds
        if not auth:
            Log.log('---- no cookies ----')
            email = self.settings.get(Settings.EMAIL)
            password = self.settings.get(Settings.PASSWORD)
            if len(email) > 0 and len(password) > 0:
                Log.log('---- have settings ----')
                data = self.api.login(email, password)
                if data['status'] == 1:
                    auth = True
                    self.api.save_cookies()
                else:
                    self.api.erase_cookies()

        # saved creds did not work, ask for sign in or register
        if not auth:
            Log.log('---- could not auto auth ----')
            auth = self.signin()
            '''
            if self.gui.signin_or_register():
                auth = self.signin()
            else:
                if self.register():
                    # succesful reg, lets try to auth again
                    email = self.settings.get(Settings.EMAIL)
                    password = self.settings.get(Settings.PASSWORD)
                    if len(email) > 0 and len(password) > 0:
                        data = self.api.login(email, password)
                        if(data['status'] == 1):
                            auth = True
                            self.api.save_cookies()
                        else:
                            self.api.erase_cookies()
            '''

        if auth:
            mode = self.parameters.mode
#            if mode is None:
#                mode = self.App.MODE_EXIT
        else:
            mode = App.MODE_EXIT
        
        if mode == App.MODE_CATEGORIES:
            self.mode_categories()

        elif mode == App.MODE_CHANNELS:
            self.mode_channels(self.parameters.cat)

        elif mode == App.MODE_FAVORITES:
            self.mode_favorites()

        elif mode == App.MODE_PLAY:
            Log.log('MODE_PLAY cat= %r' % self.parameters.cat)
            Log.log('MODE_PLAY url= %r' % self.parameters.url)
            Log.log('MODE_PLAY uri= %r' % self.parameters.uri)
            self.mode_play(self.parameters.cat)

        elif mode == App.MODE_RECORD:
            Log.log('MODE_RECORD cat= %r' % self.parameters.cat)
            Log.log('MODE_RECORD url= %r' % self.parameters.url)
            Log.log('MODE_RECORD uri= %r' % self.parameters.uri)
            self.mode_record(self.parameters.cat,self.parameters.uri,self.parameters.url)
            
        elif mode == App.MODE_RECORD_ARCHIVE:
            Log.log('MODE_RECORD_ARCHIVE cat= %r' % self.parameters.cat)
            Log.log('MODE_RECORD_ARCHIVE url= %r' % self.parameters.url)
            Log.log('MODE_RECORD_ARCHIVE uri= %r' % self.parameters.uri)
            self.mode_record_archive(self.parameters.cat,self.parameters.uri,self.parameters.url)
            
        elif mode == App.MODE_SYNC:
            Log.log('MODE_SYNC cat= %r' % self.parameters.cat)
            Log.log('MODE_SYNC url= %r' % self.parameters.url)
            Log.log('MODE_SYNC uri= %r' % self.parameters.uri)
            self.mode_sync(self.parameters.cat,self.parameters.url)

        elif mode == App.MODE_SEARCH:
            self.mode_search()

        elif mode == App.MODE_FAV_ADD:
            self.mode_fav_add(self.parameters.cat)

        elif mode == App.MODE_FAV_REMOVE:
            self.mode_fav_remove(self.parameters.cat)

        elif mode == App.MODE_EXIT:
            App.exit()

        xbmcplugin.endOfDirectory(int(sys.argv[1]))




    def signin(self):
        Log.log('---- app.signin ----')
        email, password = self.gui.signin()
        data = self.api.login(email, password)
        if data['status'] == 0:
            if self.gui.please_try_again(data['message']):
                return self.signin()
            else:
                return False
        else:
            Log.log('---- app signin success, saving settings ----')
            self.settings.set(Settings.EMAIL, email)
            self.settings.set(Settings.PASSWORD, password)
            self.api.save_cookies()
            return True

    def register(self):
        firstname, lastname, email, password = self.gui.register()
        data = self.api.register(firstname, lastname, email, password)
        if data['status'] == 0:
            if self.gui.exit_and_restart(data['message']):
                return self.register()
            else:
                return False
        else:
            self.gui.register_success()
            self.settings.set(Settings.EMAIL, email)
            self.settings.set(Settings.PASSWORD, password)
            return True


    def mode_categories(self):
        Log.log('---- mode categories ----')
        categories = self.middleware.get_categories()
        self.gui.categories(categories)

    def mode_channels(self, category):
        channels = self.middleware.get_channels(category)
        self.gui.channels(channels)

    def mode_search(self, name = ''):
        if len(name) == 0:
            name = self.gui.search('channel name')
        channels = self.middleware.search_channel(name)
        self.gui.channels(channels)

    def mode_favorites(self):
        channels = self.middleware.get_favs()
        self.gui.channels(channels)

    def mode_play(self, channel_id):
        Log.log('mode_play channel_id= %r' % channel_id)
        channel = self.middleware.get_channel(channel_id)
        if channel['health'] == 1:
            data = self.middleware.get_channel_link(channel_id)
            if data['status'] == 1:
                self.gui.play_stream(channel['name'], data['body'], channel['logo'])
            else:
                self.gui.show_message(data['message'])
        else:
            self.gui.show_message('Channel is temporarily unavailable', 'We are working to have it fixed')

    def mode_record(self, channel_id,description,source):
        Log.log('mode_record channel_id= %r' % channel_id)
        Log.log('mode_record description= %r' % description)
        Log.log('base64.b64decode(description=\n%r' % base64.b64decode(description.replace('oG','&').replace('pLus','=')))
        Log.log('mode_record source= %r' % source)
        channel = self.middleware.get_channel(channel_id)
        if channel['health'] == 1:
            data = self.middleware.get_channel_link(channel_id)
            if data['status'] == 1:
                self.gui.record_stream(channel['name'], data['body'], channel['logo'], description, source)
            else:
                self.gui.show_message(data['message'])
        else:
            self.gui.show_message('Channel is temporarily unavailable', 'We are working to have it fixed')
            
    def mode_record_archive(self, channel_id,description,source):
        Log.log('mode_record_archive channel_id= %r' % channel_id)
        Log.log('mode_record_archive description= %r' % description)
        FullDescription = base64.b64decode(description.replace('oG','&').replace('pLus','='))
        Log.log('base64.b64decode(description=\n%r' % FullDescription)
        Log.log('mode_record_archive source= %r' % source)
        """
        <div class="js-evt-play event-pop-up__button" data-dvr-link="" data-channel-id="967" data-dvr-event-start="1574883600" data-dvr-event-duration="7800" data-dvr-event="Hvidsten Gruppen">PLAY</div>
        """
        evtStart = '1574883600'
        evtDuration = '7800'
        channel = self.middleware.get_channel(channel_id)
        if channel['health'] == 1:
            ### data = self.middleware.get_channel_link(channel_id)
            data = self.middleware.get_archive_link(channel_id, evtStart, evtDuration)
            Log.log('get_archive_link data= %r' % data)
            if data['status'] == 1:
                self.gui.record_stream_archive(channel['name'], data['body'], channel['logo'], description, source)
            else:
                self.gui.show_message(data['message'])
        else:
            self.gui.show_message('Channel is temporarily unavailable', 'We are working to have it fixed')
            
    def mode_sync(self, channel_id, url):
        Log.log('mode_sync channel_id= %r\n%r' % (channel_id,url))
        evtStart = 1111111111
        evtDuration = 120
        channel = self.middleware.get_archive_link(channel_id, evtStart, evtDuration)
        if channel['health'] == 1:
            data = self.middleware.get_archive_link(channel_id, evtStart, evtDuration)
            if data['status'] == 1:
                self.gui.sync_stream(channel['name'], data['body'], channel['logo'])
            else:
                self.gui.show_message(data['message'])
        else:
            self.gui.show_message('Channel is temporarily unavailable', 'We are working to have it fixed')

    def exit_with_message(self, message):
        self.gui.show_message(message)
        App.exit()

    def mode_fav_add(self, channel_id):
        self.middleware.fav_add(channel_id)

    def mode_fav_remove(self, channel_id):
        self.middleware.fav_remove(channel_id)

    def remove_auth(self):
        self.api.erase_cookies()
        #self.settings.set(Settings.EMAIL, "")
        #self.settings.set(Settings.PASSWORD, "")

    @staticmethod
    def exit():
        xbmc.executebuiltin("XBMC.Container.Update(path,replace)")
        xbmc.executebuiltin("XBMC.ActivateWindow(Home)")

