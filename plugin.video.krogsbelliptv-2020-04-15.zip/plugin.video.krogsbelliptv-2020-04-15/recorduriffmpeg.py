#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os
import datetime
import time
import utils, recordings
import net
import base64
from hashlib import md5
import json
import HTMLParser
import requests
from requests.packages import urllib3
#Below is required to get around an ssl issue
urllib3.disable_warnings()
import urllib
import locking

###import urllib.request   ### 2017-11-04
###urllib.request.urlretrieve('http://www.example.com/songs/mp3.mp3', 'mp3.mp3')
import wget
###def testwget():
###    image_name = 'test4.jpg'
###    wget.download(url, image_name)

#ADDON      = xbmcaddon.Addon(id='plugin.video.wozboxntv')
import definition
ADDON      = definition.getADDON()
ADDONname  = ADDON.getAddonInfo('name')
ADDONid    = ADDON.getAddonInfo('id')
module = 'recorduriffmpeg.py'
try:
    baseurl = definition.getBASEURL().split('://')[1].split(':')[0]
except:
    pass
    baseurl = ''
searchhighlightcolor = ADDON.getSetting('searchhighlightcolor')

def log(infotext):
    if 'err' in infotext.lower():
        utils.logdev('err',module + ': ' + infotext)
    else:
        utils.logdev(module,infotext)

def logd(infotext):
    log(infotext)
    
def logd1(infotext):
    log('err: ' + infotext)

def logdev(module,infotext):
    log(infotext)
    
log('Start')

try:
    logdev(module,'Arguments: ' + repr(sys.argv))
except Exception,e:
    pass
    logdev(module,'ERROR Arguments: sys.argv %r' % e)

def param(u,match):
    try:
        ###u = urllib.unquote_plus(u)
        x = u.split('&'+match+'=')[1].split('&')[0]
    except:
        pass
        try:
            x = u.split('?'+match+'=')[1].split('&')[0]
        except:
            pass
            x = ''
    return x

def httpget(url, out=None):
    logdev(module,'httpget:url= %r' % url)
    #resp = ''
    #data = ''
    #http = get_httplib()
    #resp, data = http.request(url, "GET")
    data = wget.download(url, out)
    logdev(module,'httpget:data= %r' % data)
    return data

def OpenURL(url):
    ### BBC Subtitels download
    """
    import HTMLParser
    import requests
    from requests.packages import urllib3
    #Below is required to get around an ssl issue
    urllib3.disable_warnings()
    """
    cookie_jar = None
    user_agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:48.0) Gecko/20100101 Firefox/48.0'
    headers = {'User-Agent': user_agent}
    logdev(module,'OpenURL:url= %r' % url)
    try:
        r = requests.get(url, headers=headers, cookies=cookie_jar)
    except requests.exceptions.RequestException as e:
        return repr(e)
    try:
        for cookie in r.cookies:
            cookie_jar.set_cookie(cookie)
        #Set ignore_discard to overcome issue of not having session
        #as cookie_jar is reinitialised for each action.
        cookie_jar.save(ignore_discard=True)
    except:
        pass
    return HTMLParser.HTMLParser().unescape(r.content.decode('utf-8'))

def download_subtitles_BBC(url, offset, outfile):
    import codecs
    re_subtitles = re.compile('^\s*<p.*?begin=\"(.*?)(\.([0-9]+))?\"\s+.*?end=\"(.*?)(\.([0-9]+))?\"\s*>(.*?)</p>')
    # BBC
    # Download and Convert the TTAF format to srt
    # SRT:
    # 1
    # 00:01:22,490 --> 00:01:26,494
    # Next round!
    #
    # 2
    # 00:01:33,710 --> 00:01:37,714
    # Now that we've moved to paradise, there's nothing to eat.
    #

    # TT:
    # <p begin="0:01:12.400" end="0:01:13.880">Thinking.</p>
    ###outfile = os.path.join(DIR_USERDATA, 'iplayer.en.srt or .da.srt')
    # print "Downloading subtitles from %s to %s"%(url, outfile)
    fw = codecs.open(outfile, 'w', encoding='utf-8')

    if not url:
        fw.write("1\n0:00:00,001 --> 0:01:00,001\nNo subtitles available\n\n")
        fw.close()
        return
    logdev(module,'download_subtitles_BBC:url= %r' % url)
    txt = OpenURL(url)

    # print txt

    i = 0
    prev = None

    # some of the subtitles are a bit rubbish in particular for live tv
    # with lots of needless repeats. The follow code will collapse sequences
    # of repeated subtitles into a single subtitles that covers the total time
    # period. The downside of this is that it would mess up in the rare case
    # where a subtitle actually needs to be repeated
    for line in txt.split('\n'):
        entry = None
        m = re_subtitles.match(line)
        # print line
        # print m
        if m:
            if(m.group(3)):
                start_mil = "%s000" % m.group(3) # pad out to ensure 3 digits
            else:
                start_mil = "000"
            if(m.group(6)):
                end_mil = "%s000" % m.group(6)
            else:
                end_mil = "000"

            ma = {'start': m.group(1),
                'start_mil': start_mil[:3],
                'end': m.group(4),
                'end_mil': end_mil[:3],
                'text': m.group(7)}

            # ma['text'] = ma['text'].replace('&amp;', '&')
            # ma['text'] = ma['text'].replace('&gt;', '>')
            # ma['text'] = ma['text'].replace('&lt;', '<')
            ma['text'] = ma['text'].replace('<br />', '\n')
            ma['text'] = ma['text'].replace('<br/>', '\n')
            ma['text'] = re.sub('<.*?>', '', ma['text'])
            ma['text'] = re.sub('&#[0-9]+;', '', ma['text'])
            # ma['text'] = ma['text'].replace('<.*?>', '')
            # print ma
            if not prev:
                # first match - do nothing wait till next line
                prev = ma
                continue

            if prev['text'] == ma['text']:
                # current line = previous line then start a sequence to be collapsed
                prev['end'] = ma['end']
                prev['end_mil'] = ma['end_mil']
            else:
                i += 1
                entry = "%d\n%s,%s --> %s,%s\n%s\n\n" % (
                    i, prev['start'], prev['start_mil'], prev['end'], prev['end_mil'], prev['text'])
                prev = ma
        elif prev:
            i += 1
            entry = "%d\n%s,%s --> %s,%s\n%s\n\n" % (
                i, prev['start'], prev['start_mil'], prev['end'], prev['end_mil'], prev['text'])

        if entry:
            fw.write(entry)

    fw.close()
    return outfile


def download_subtitles(url, offset, outfile):

    ###logdev(module,'Subtitles at %s' % url)
    ###outfile = os.path.join(SUBTITLES_DIR, 'itv.srt')
    fw = open(outfile, 'w')
    logdev(module,'download_subtitles:url= %r' % url)
    if not url:
        fw.write("1\n0:00:00,001 --> 0:01:00,001\nNo subtitles available\n\n")
        fw.close() 
        return outfile
    txt = httpget(url, outfile)
    ###logdev(module,'txt= %r' % txt)
    try:
        logdev(module,'Subtitles start: ' + repr(txt[0:50]))
    except Exception,e:
        logdev(module,'Subtitles start Error: %r' % e)
    logdev(module,'Subtitles start: '+repr(txt[0:6])+' or ' + repr(txt[3:9]))
    if repr(txt[3:9]) == "'WEBVTT'":
        ### ITV
        try:
            logdev(module,'ITV Subtitles start: ' + repr(txt[0:50]))
            fw.write(txt)
            fw.close()    
            return outfile
        except Exception,e:
            pass
            logdev(module,'Failed to decode (ITV UTF-16) Subtitles: \nError: ' + repr(e)+ '\n' +repr(txt[0:50]))
        
    if repr(txt[0:6]) == '\'WEBVTT\'':  ### 2017-01-30
        ### DRnu
        fw.write(txt)
        fw.close()    
        return outfile
            
    else: 
        ### ITV <?xml version="1.0" encoding="UTF-16"?>  ### BBC <?xml version="1.0" encoding="utf-8"?>
        if ('encoding="utf-8"?' in txt) or ('encoding="UTF-8"?' in txt):
            encoding="utf-8"
            try:
                download_subtitles_BBC(url, offset, outfile)
            except Exception, e:
                pass
                txt = 'Failed to encode BBC Subtitles: ' + repr(txt[0:50]) + ' Error: ' + repr(e)
                logdev(module,'Failed to encode utf-8 Subtitles: ' + repr(txt[0:50]) + ' Error: ' + repr(e))
            return outfile
        else:
            encoding="utf-16"
            try:
                txt = txt.decode("utf-16")
            except UnicodeDecodeError:
                txt = txt[:-1].decode("utf-16")
            try:
                txt = txt.encode('latin-1')
            except Exception, e:
                pass
                txt = 'Failed to encode Subtitles: ' + repr(txt[0:50]) + ' Error: ' + repr(e)
                logdev(module,'Failed to encode Subtitles: ' + repr(txt[0:50]) + ' Error: ' + repr(e))
    logdev(module,'Start of Subtitles ('+encoding+' encoding): ' + repr(txt[0:99]))
    txt = re.sub("<br/>"," ",txt)
    #print "SUBS %s" % txt
    p= re.compile('^\s*<p.*?begin=\"(.*?)\.([0-9]+)\"\s+.*?end=\"(.*?)\.([0-9]+)\"\s*>(.*?)</p>')
    i=0
    prev = None

    entry = None
    for line in txt.splitlines():
        subtitles1 = re.findall('<p.*?begin="(...........)" end="(...........)".*?">(.*?)</p>',line)
        logdev(module,str(i) + ' Subtitles ('+encoding+' encoding) subtitles1= '+repr(subtitles1) + ' in line: ' + repr(line))
        if subtitles1:
            for start_time, end_time, text in subtitles1:
                r = re.compile('<[^>]*>')
                text = r.sub('',text)
                start_hours = re.findall('(..):..:..:..',start_time)
                start_mins = re.findall('..:(..):..:..', start_time)
                start_secs = re.findall('..:..:(..):..', start_time)
                start_msecs = re.findall('..:..:..:(..)',start_time)
#               start_mil = start_msecs +'0'
                end_hours = re.findall('(..):..:..:..',end_time)
                end_mins = re.findall('..:(..):..:..', end_time)
                end_secs = re.findall('..:..:(..):..', end_time)
                end_msecs = re.findall('..:..:..:(..)',end_time)
#               end_mil = end_msecs +'0'
                entry = "%d\n%s:%s:%s,%s --> %s:%s:%s,%s\n%s\n\n" % (i, start_hours[0], start_mins[0], start_secs[0], start_msecs[0], end_hours[0], end_mins[0], end_secs[0], end_msecs[0], text)
                i=i+1
                #print "ENTRY" + entry
        if entry: 
            fw.write(entry)
    
    fw.close()    
    return outfile

def download_subtitles_files(url, outfile):
    return 0 ### 2018-06-18/2019-01-27 ???
    ### Fetch files ending with .srt and similar filename  2018-06-15
    ### add subtitle extension to outfile
    logdev(module,'download_subtitles_files(url= %r, outfile= %r)' % (url, outfile))
    subtitles_fetched = 0
    urlnoext = url.rsplit('.',1)[0]
    subtitles = ['.en.srt','.da.srt']
    for sub in subtitles:
        try:    
            r = requests.get(urlnoext + sub)
            if r.status_code == 200:
                with open(outfile + sub, 'wb') as f:  
                    # Retrieve HTTP meta-data
                    logdev(module,'r.status_code= %r' % r.status_code)  
                    logdev(module,'r.headers[content-type]= %r' % r.headers['content-type'])  
                    logdev(module,'r.encoding= %r' % r.encoding)  
                    f.write(r.content)
                    subtitles_fetched +=1
        except Exception,e: 
            pass
            logdev(module,'download_subtitles_files Error= %r' % e)
    return subtitles_fetched

uri = ''
try:
    nameAlarm = 'Not Set'
    logdev(module,'sys.argv= ' + repr(sys.argv))
    program       = sys.argv[0]
    logdev(module,'program: ' + repr(program))
    uri           = sys.argv[1]
    try:
        if uri[:3] == 'b64':
            decoded = base64.b64decode(uri[3:])
        else:
            decoded = uri
    except Exception,e:
        pass
        logdev(module,'base64.b64decode Error %r' % e)
        decoded = uri
    uri = decoded
    uri           = recordings.argumenttostring(uri)
    logdev(module,'2 uri: ' + repr(uri)) 
    ###searchhighlightcolor = searchhighlightcolor
    title         = recordings.argumenttostring(sys.argv[2]).replace('[COLOR '+searchhighlightcolor+']','').replace('[/COLOR]','')
    logdev(module,'title: ' + repr(title))
    nameAlarm     = sys.argv[3]
    try:
        if nameAlarm[:3] == 'b64':
            decoded = base64.b64decode(nameAlarm[3:])
        else:
            decoded = nameAlarm
    except Exception,e:
        pass
        logdev(module,'base64.b64decode Error %r' % e)
        decoded = nameAlarm
    nameAlarm = decoded
    
    logdev(module,'nameAlarm-3: ' + repr(nameAlarm))
except:
    pass
    title = 'Arkiv Video'
    
try:
    argv5 = recordings.argumenttostring(sys.argv[5])
    argv8 = sys.argv[8]
    try:
        if argv8[:3] == 'b64':
            decoded = base64.b64decode(argv8[3:])
        else:
            decoded = argv8
    except Exception,e:
        pass
        logdev(module,'base64.b64decode Error %r' % e)
        decoded = argv8
    argv8 = decoded
    
    if argv5 != '' and argv8 != '':  ### 2018-12-26 If recording has been modified
        title         = argv5.replace('[COLOR violet]','')
        logdev(module,'title argv5: %r' % title)
        nameAlarm     = argv8
        logdev(module,'nameAlarm-8: %r' % nameAlarm)
except Exception,e:
    pass
    logdev(module,'argv5-8 ERROR: %r' % e)
logdev(module,'title: ' + repr(title))
if nameAlarm == 'Not Set':
    nameAlarm = ADDONname + ' ' + title
    nameAlarm = recordings.latin1_to_ascii_force(nameAlarm)  ### 2019-01-02
    nameAlarm = re.sub('[(,:\\/*?\<>|")]+', '', nameAlarm).replace('[','').replace(']','')
###Recordings = ADDON.getSetting('Recordings') + nameAlarm
locking.markLock(nameAlarm)
###ADDON.setSetting('Recordings',Recordings)
if baseurl in uri:
    logdev(module,'recordLock(nameAlarm= %r )' % nameAlarm)
    locking.recordLock(nameAlarm)

allstreams      = param(uri,'allstreams')
description     = param(uri,'description')
try:
    if description[:3] == 'b64':
        decoded = base64.b64decode(description[3:])
    else:
        decoded = description
except Exception,e:
    pass
    logdev(module,'base64.b64decode Error %r' % e)
    decoded = description
description = decoded

try:
    duration        = int(param(uri,'duration')) 
    logdev(module,'duration: ' + repr(duration))
except:
    pass
    duration        = 0
durationH = 0
durationM = 0
if 'uration [' in description and '].' in description:
    logdev(module,'Duration: ' + repr(uri))
    orgduration = (description.split('uration [')[1].split('].')[0] + 'm').replace(':','h')
    logdev(module,'orgduration from uri: ' + orgduration)
else:
    durationH = int(int(duration)/60)
    durationM = (int(duration) - durationH*60)
    orgduration =  str(durationH) + 'h' + str(durationM).zfill(2) + 'm'
    logdev(module,'orgduration from duration: ' + orgduration)
    
subtitlesurl    = param(uri,'subtitlesurl')
try:
    subtitlesoffset = int(param(uri,'subtitlesoffset'))
except:
    pass
    subtitlesoffset = 0
try:
    logdev(module,'XXXXXXX uri: ' + repr(uri))
    ###uri = uri.split('&')[0]
    uri = uri.split('&description=')[0]
    try:
        uri = uri.split('&name=')[0]
    except:
        pass
    logdev(module,'XXXXXXX uri: ' + repr(uri))
except Exception,e:
    pass
    logdev(module,'Get uri FAILED: %r' % e)
    uri = ''
"""
try:
    description   = uri.split('&description=')[1]
    try:
        subtitlesurl    = description.split('&subtitlesurl=')[1]
        subtitlesoffset = subtitlesurl.split('&subtitlesoffset=')[1]
        duration        = int(subtitlesoffset.split('&duration=')[1])
        subtitlesoffset = int(subtitlesoffset.split('&duration=')[0])
        subtitlesurl    = subtitlesurl.split('&subtitlesoffset=')[0]
        description     = description.split('&subtitlesurl=')[0]
        logdev(module,'Subtitles at: ' + repr(subtitlesurl))
    except Exception,e:
        pass
        logdev(module,'NO Subtitles - Error: %r' % e)
        subtitlesurl = ''
        subtitleoffset = 0
    uri = uri.split('&description=')[0]
    try:
        uri = uri.split('&name=')[0]
    except:
        pass
except:
    pass
    try:
        description = uri.split('&description=')[1]
    except:
        logdev(module,'Description not found in: ' + repr(uri))       
        description = 'No description'

        ### 2019-01-03
            durationH = 0
            durationM = 0
            if 'Duration [' in description and '].' in description:
                orgduration = (description.split('uration [')[1].split('].')[0] + 'm').replace(':','h')
            else:
                durationH = int(int(duration)/3600)
                durationM = (int(duration) - durationH*3600)/60
                orgduration =  str(durationH) + 'h' + str(durationM) + 'm'
            if duration == '0':
                cmd += '"' + recordPath + filetitle + ' ['+recordstarttime+ PreTitle + playchannel  + ']'
            else:
                durationH = int(int(duration)/60)
                durationM = int(duration) - durationH*60
                cmd += '"' + recordPath + filetitle + ' ['+recordstarttime+ PreTitle + playchannel + ' ' + orgduration + ']'
        
        """
logdev(module,'description: ' + repr(description))
logdev(module,'uri: ' + repr(uri))
try:
    #print os.environ
    logdev(module,os.environ['OS']) #put in LOG
except: pass

###if not ADDON.getSetting('RecordFromTVguide') == 'true':
###    utils.notification('Recording %s [COLOR red]NOT enabled[/COLOR]' % (title))
###else:
recordPath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_path')))
logdev(module, 'recordPath= %s' %recordPath)
if not utils.folderwritable(recordPath):
    utils.notification('Recording %s [COLOR red]FAILED - You must set the recording path writable![/COLOR]' % title)
else:
    datapath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
    nowHM=datetime.datetime.today().strftime('%H:%M:%S')
    #print 'recorduri.py5: title= %s, LoopCount= %s at %s' % (repr(title),repr(0),nowHM)
    if duration == 0:  ### Duration is NOT in URI or Description
        duration = ADDON.getSetting('RecordFromTVguideDurationMinutes')
        try:     ### Ask option no longer possible!
            if int(duration) < 0: 
                duration = '0'
        except:
            pass
            duration = '0'
    else:
        duration = str(duration)
    cmdoption=''
    
    qrecord = xbmcgui.Dialog()
    arecord = True
    ###arecord = qrecord.yesno(ADDON.getAddonInfo('name'),'Do you want to record?', '' ,title)
    logdev(module,'answer= %s' % repr(arecord))
    if arecord:
        if duration == 'ask':
            dialog = xbmcgui.Dialog()
            duration = dialog.numeric(0, ADDON.getAddonInfo('name') + ': Time to record in minutes, empty or 0=until end','0')
        try:
            #cmd += ' -V --stop ' + ADDON.getSetting('RecordFromTVguideDurationMinutes')
            cmdoption += ' -t ' + str(int(duration)*60)
        except:
            pass
            cmdoption += ' -t ' + str(120*60)
        if duration == 'ignore' or duration == '' or duration == '0' or duration == 'ask':
            #cmdoption =  ' -t ' +str(120*60)
            cmdoption = ''
            duration = '0'
        ffmpegfreeoption = ADDON.getSetting('ffmpegfreeoption')    
        if 'multisub' in title.lower().replace('-','') or allstreams == 'y':
            ###if not '-map' in ffmpegfreeoption:
            cmdoption += ' -map 0 '  ### 2018-07-20 - use -map 0 to record all subtitles and save in originalfile format
        
        logdev(module,'uri= %r' % uri) #put in LOG
        rtmp  = uri
        
        #xbmc.log('recorduriffmpeg.py: uri= %s' % repr(uri))
        ###cmd  =  os.path.join(ADDON.getAddonInfo('path'),'rtmpdump', utils.rtmpdumpFilename())
        lowspeeddownload = ADDON.getSetting('lowspeeddownload')
        if lowspeeddownload == 'true':
            ffmpegcmd = 'ffmpeg -y -re -listen_timeout 2000 -reconnect 1 -reconnect_at_eof 1 -reconnect_streamed 1 -reconnect_delay_max 2 -i '
        else:
            if 'itvpnpdotcom' in rtmp or 'live.akamaized.net' in rtmp:  ### Simple for ITV and BBC
                ffmpegcmd = 'ffmpeg -y -i '
            elif 'bbc iplayer' in title.lower() or 'itv player' in title.lower():  ### BBC or ITV
                ffmpegcmd = 'ffmpeg -y -i '
            else:
                ffmpegcmd = 'ffmpeg -y -listen_timeout 2000 -reconnect 1 -reconnect_at_eof 1 -reconnect_streamed 1 -reconnect_delay_max 2 -i '
        if os.access('/system/vendor/bin/ffmpeg', os.X_OK):
            cmd = '/system/vendor/bin/' + ffmpegcmd  # Use seperately installed ffmpeg program ###
        else:   ###  -rtmp_live live don't work for ITV Hub
            cmd = ffmpegcmd
        #cmd += ' -V --stop 10000'
        #cmd += ' --live '
        #cmd += ' --flv "' + recordPath + '['+datetime.datetime.today().strftime('%Y-%m-%d %H-%M')+'] - ' + re.sub('[,:\\/*?\<>|"]+', '', title) + '.flv"'
        cmd += '"' + rtmp + '"'
        if 'itvpnpdotcom' in rtmp:
            ffmpegoptions= '4'   ### Use this option with ITV (TESTING) 2019-01-15
        else:
            ffmpegoptions= ADDON.getSetting('ffmpegoptions')
        logdev(module,'ffmpegoptions: ' + repr(ffmpegoptions))
        if ffmpegoptions == '1':
            cmd += ' -f flv -c:v libx264 -b:v 2000k -c:a aac -strict experimental -b:a 128k -ar 44100 ' + cmdoption + ' ' ### For use with ffmpeg
        elif ffmpegoptions == '2':
            cmd += ' -c copy ' + cmdoption + ' ' ### For use with ffmpeg and ac3 sound
        elif ffmpegoptions == '0':
            cmd += ' -c copy -bsf:a aac_adtstoasc ' + cmdoption + ' ' ### For use with ffmpeg
        elif ffmpegoptions == '4':
            cmd += ' -c copy ' + cmdoption + ' '
        else:
            ffmpegfreeoption = ADDON.getSetting('ffmpegfreeoption')
            cmd += ' ' + ffmpegfreeoption + ' ' + cmdoption + ' ' ### For use with ffmpeg free option
        #cmd += ' -c copy -bsf:a aac_adtstoasc ' + cmdoption + ' ' ### For use with ffmpeg
        #cmd += ' -o '
        ### string.count(substring)
        cmdcount = cmd.count(' -map ')
        if cmdcount > 1:
            cmd = cmd.replace(' -map 0 ',' ',1) ### Remove -map 0 once
        filetitle = recordings.latin1_to_ascii_force(title) ### 2019-01-02
        filetitle = filetitle.replace('?', '')
        filetitle = filetitle.replace(',', '')
        filetitle = filetitle.replace(':', ' -')
        filetitle = filetitle.replace('/', '-')
        filetitle = filetitle.replace('+','Plus')
        filetitle = filetitle.replace('\\', '_')
        filetitle = filetitle.replace('] [', '][') ### 2019-01-28
        filetitle = re.sub('[,:\\/*?\<>|"]+', '', filetitle)
        filetitle = " ".join(filetitle.split())  # Remove extra spaces from filename
        ###source = ''
        ###if ' - ' in filetitle:
        ###    filename = filetitle.replace(' - ','####',1).split('####')
        ###    filetitle = filename[1]
        ###    source = filename[0]
        ###    logdev(module,'source= %r, filetitle=%r' % (source,filetitle))
        ###if source == '':
        recordings.updateRecordingPlanned(nameAlarm, '[COLOR orange]Start recording of [/COLOR] ' + title)
        nowHM=datetime.datetime.today().strftime('%H:%M')
        utils.notification('Recording %s [COLOR yellow]started %s[/COLOR]' % (title, nowHM))
        recordings.updateRecordingPlanned(nameAlarm, '[COLOR yellow]Started ' + nowHM + '[/COLOR] ' + title)
        source = ADDONname
        try:
            ###ADDON.getSetting('basicuserinfo')  ### 3 letter Addon get it from file name with user info
            ###source1 = ' ' + ADDONid.split('.')[2][:3].upper() + ' ' 
            ###source1 = ' ' + ADDON.getSetting('basicuserinfo').split(os.sep)[-1][:3].upper() + ' '
            source1 = ' ' + ADDON.getSetting('my_referral_init')         
        except Exception,e:
            pass
            logdev(module,'ADDONid.split(.)[2][:3].upper() ERROR: %r' % e)
            source1 = ''
        if duration == '0':
            filename1 = recordPath + filetitle + '['+datetime.datetime.today().strftime('%Y-%m-%d %H-%M') + source1 + ']'
        else:
            orgduration = '[' + orgduration +']'
            
            if '[' in filetitle:   ### Put duration first on second line, if not in line
                if orgduration in filetitle:
                    filename1 = recordPath + filetitle + '['+datetime.datetime.today().strftime('%Y-%m-%d %H-%M') + source1 + ']'
                else:
                    filetitle1 = filetitle.replace('[',orgduration +'[',1)
                    filename1 = recordPath + filetitle1 + '['+datetime.datetime.today().strftime('%Y-%m-%d %H-%M') + source1 + ']'
            else:
                filename1 = recordPath + filetitle + orgduration+ '['+datetime.datetime.today().strftime('%Y-%m-%d %H-%M') + source1 + ']'
        subtitlescount = download_subtitles_files(rtmp, filename1)
        ext = ADDON.getSetting('ffmpegoutputtype')
        extorgcollectionraw = ADDON.getSetting('extorgcollection')
        extorgcollection = extorgcollectionraw.split(',')
        if '.' in rtmp:
            extorg = rtmp.rsplit('.',1)[1].lower()  ### extension 2018-06-16
        else:
            extorg = ''
        if extorg == 'm3u' or extorg == 'm3u8' :   ### Don't use m3u or m3u8 as filenames
            extorg = ''
        logdev(module,'0:ext= %r\nextorgcollectionraw= %r\nextorgcollection= %r\nextorg= %r\nlen(extorg)= %r'% (ext, extorgcollectionraw, extorgcollection, extorg,len(extorg)))
        if not ext in extorgcollection:
            logdev(module,'NOT ext in extorgcollection')
            if len(ext) > 1 and len(ext) < 6:
                if len(extorgcollectionraw) > 0:
                    logdev(module,'len(extorgcollectionraw) > 0')
                    ADDON.setSetting('extorgcollection',ext +',' + extorgcollectionraw)
                    xbmc.sleep(500)
                    extorgcollectionrawNEW = ADDON.getSetting('extorgcollection')
                    if extorgcollectionrawNEW  == extorgcollectionraw:
                        ADDON.setSetting('extorgcollection',ext +',' + extorgcollectionraw)
                        logdev(module,'NOT ext in extorgcollection - TRY AGAIN')
                else:
                    logdev(module,'len(extorgcollectionraw) == 0')
                    ADDON.setSetting('extorgcollection',ext)
        if not extorg in extorgcollection:
            logdev(module,'NOT extorg in extorgcollection')
            if len(extorg) > 1 and len(extorg) < 6:
                if len(extorgcollectionraw) > 0:
                    logdev(module,'len(extorgcollectionraw) > 0')
                    ADDON.setSetting('extorgcollection',extorg +',' + extorgcollectionraw)
                    xbmc.sleep(500)
                    extorgcollectionrawNEW = ADDON.getSetting('extorgcollection')
                    if extorgcollectionrawNEW  == extorgcollectionraw:
                        ADDON.setSetting('extorgcollection',extorg +',' + extorgcollectionraw)
                        logdev(module,'NOT extorg in extorgcollection - TRY AGAIN')
                else:
                    logdev(module,'len(extorgcollectionraw) == 0')
                    ADDON.setSetting('extorgcollection',extorg)
        else:
            logdev(module,'extorg in extorgcollection')
            """
            if len(extorg) > 1 and len(extorg) < 6:
                if len(extorgcollectionraw) > 0:
                    ADDON.setSetting('extorgcollection',extorg +',' + extorgcollectionraw)
                else:
                    ADDON.setSetting('extorgcollection',extorg)
            """
        ###if (extorg == 'mkv' or extorg == 'mp4' or extorg == 'ts') and ADDON.getSetting('useknownextensions') == 'true' :
        if (len(extorg) > 1 and len(extorg) < 6 and ADDON.getSetting('useknownextensions') == 'true') or 'multisub' in title.lower().replace('-',''):   ### 2018-07-21  if multi-subs save original filename
            if extorg != 'm3u' and extorg != 'm3u8' :
                ext = extorg
        logdev(module,'1:ext= %r\nextorgcollectionraw= %r\nextorgcollection= %r\nextorg= %r'% (ext, extorgcollectionraw, extorgcollection, extorg))
        cmd += '"' + filename1 + '.' + ext +'"'
        infofilename = filename1 + '.txt'
        if 'DR NU' in title:
            subtitlesfilename = filename1 + '.da.srt'   ### .en.srt or .da.srt
            subtitlesincluded = 'Denne optagelse indeholder undertekster'
        else:
            subtitlesfilename = filename1 + '.en.srt'   ### .en.srt or .da.srt
            subtitlesincluded = 'This recording includes subtitles'
        #cmd += ' --rtmp "' + rtmp
        #cmd += '"'
        cmd += ' 2> "' + filename1 + '.log"'   ### Save FFMPEG log 2018-10-22
        ###xbmc.log('recordffmpeguri.py: cmd= %s' % repr(cmd))
        logdev(module,'cmd= %r' % cmd)
        nowHM=datetime.datetime.today().strftime('%H:%M')
        utils.notification('Recording %s [COLOR green]started %s[/COLOR]' % (title, nowHM))
        try:
            # Create file with info on recording 'infofilename'
            ### LF = open(infofilename, 'a')
            LF = open(infofilename, 'w')  ### 2017-08-09
            crlf = '\r\n'
            # Write to our text file the information we have provided and then goto next line in our file.
            LF.write('Recorded using: ' + ADDON.getAddonInfo('name')+ crlf)
            LF.write('Version= ' + ADDON.getAddonInfo('version')+ crlf)
            LF.write('Version Info= ' + utils.version()+ crlf)
            ### LF.write('Version Date= ' + utils.versiondate()+ crlf)
            program  = sys.argv[0]
            LF.write('Program Name= ' + program+ crlf)
            LF.write('Platform= ' + ADDON.getSetting('platform')+ crlf)
            LF.write('Running on= ' + ADDON.getSetting('runningon')+ crlf)
            LF.write('OS= ' + ADDON.getSetting('os')+ crlf)
            LF.write('Record Path= ' + ADDON.getSetting('record_path')+ crlf + crlf)
            LF.write('Record Command:' + crlf + cmd+ crlf + crlf)
            LF.write('Title= ' + title + crlf)
            #LF.write('PlayChannel= ' + playchannel + crlf)
            #LF.write('cat= ' + cat + crlf)
            #LF.write('StartTime= ' + startTime + crlf)
            #LF.write('EndTime= ' + endTime + crlf)
            if not str(int(round(int(duration)))) == '0':   ### 2019-01-04 /60 removed - minutes not seconds
                LF.write('Duration= ' + str(int(round(int(duration)))) + ' minutes' + crlf)
            #LF.write('Argv6= ' + argv6 + crlf)
            #LF.write('Argv7= ' + argv7 + crlf)
            LF.write('NameAlarm= ' + nameAlarm + crlf)
            if not len(description) == 3 and not description == 'n a':
                LF.write('Description:' + crlf + recordings.argumenttostring(description) + crlf)
            else:
                LF.write('No description!' + crlf)
            if not subtitlesurl == '':
                LF.write(crlf + subtitlesincluded + crlf)
            # Close our file so no further writing is posible.
            LF.close()
            try:
                os.chmod(infofilename, 0776)
                logdev(module,'Infofilename permission set to 0776')
            except Exception, e:
                pass
                logdev(module,'Failed to set info filename permission to 0776: ' + repr(e))
            
            infofilename = infofilename.replace('.txt','.nfo')
            LF = open(infofilename.replace('.txt','.nfo'), 'w')   ### 2017-08-09
            # Write to our text file the information we have provided and then goto next line in our file.
            LF.write('<?xml version="1.0" encoding="utf-8"?>' + crlf)
            LF.write('<episodedetails>'+ crlf)
            LF.write('    <title>' + title + '</title>' + crlf)
            if not len(description) == 3 and not description == 'n a':
                LF.write('    <plot>' + recordings.argumenttostring(description) + crlf)
                if not subtitlesurl == '':
                    LF.write(crlf + subtitlesincluded + crlf)
                LF.write('</plot>' + crlf)
            LF.write('</episodedetails>'+ crlf)
            # Close our file so no further writing is posible.
            LF.close()
            try:
                os.chmod(infofilename, 0776)
                logdev(module,'Infofilename permission set to 0776')
            except Exception, e:
                pass
                logdev(module,'Failed to set infofilename permission to 0776: ' + repr(e))
            
            logdev(module,'infofilename= %s written and closed' % (repr(infofilename))) # Add to log
        except Exception, e:
            pass
            logdev(module,'error writing infofile: ' + repr(e))
        
        if not subtitlesurl == '':
            try:
                logdev(module,download_subtitles(subtitlesurl, subtitlesoffset,subtitlesfilename))
            except Exception, e: 
                logdev(module,'error getting subtitles: ' + repr(e))
                pass
                logdev(module,'No subtitles')
        
        if ADDON.getSetting('os')=='11':
            #print 'libpath= None os=11'
            utils.runCommand(cmd, LoopCount=0, libpath=None, nameAlarm=nameAlarm)
        else:
            libpath = utils.libPath()
            #print 'libpath= %s' % libpath
            utils.runCommand(cmd, LoopCount=0, libpath=libpath, nameAlarm=nameAlarm)

        nowHM=datetime.datetime.today().strftime('%H:%M')
        ###utils.notificationbox('Recording %s [COLOR red]complete[/COLOR] %s' % (title, nowHM))
        if baseurl in uri:
            logdev(module,'recordUnLock(nameAlarm= %r )' % nameAlarm)
            locking.recordUnlock(nameAlarm)
        recordings.updateRecordingPlanned(nameAlarm, '[COLOR green]Complete ' + nowHM + '[/COLOR] ' + title)
        utils.notification('Recording finished: ' + title)
        logdev(module,'Recording finished: ' + title+ ' at '+ nowHM)
        ###Recordings = ADDON.getSetting('Recordings').replace(nameAlarm,'')
        locking.markUnlock(nameAlarm)
        ###ADDON.setSetting('Recordings',Recordings)
        """
        try:
            Recordings = ADDON.getSetting('Recordings')
            if nameAlarm in Recordings:
                Recordings = Recordings.split(nameAlarm)[1]
                ADDON.setSetting('Recordings',Recordings)    ### only save later recordings
        except Exception,e:
            pass
            logdev(module,'Error in removing in recordings: %r' % e)
            ADDON.setSetting('Recordings','')  ### Clear recordings if possible
        """
        ### Recording finished - find next VOD and start it even before time
        nextvod = recordings.getNextVOD()
        log('nextvod=  %r'% nextvod)
        ### [cat, name, startDate, endDate, alarmname, description, playchannel, DB]
        if len(nextvod) == 0: 
            ### If no more waiting VODs - adjust time to record
            now= datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S')
            ADDON.setSetting('RecordingFromOtherAddon',now)
        else:
            cat = nextvod[0][0]
            name = nextvod[0][1].replace('[COLOR violet]','').replace('[/COLOR]','')
            startDate = nextvod[0][2]
            endDate = nextvod[0][3]
            alarmname = nextvod[0][4]
            description = nextvod[0][5]
            playchannel = 'VOD'   
            duration = 60
            logdev(module,'len(nextvod)=  %r'% len(nextvod))
            ### Stop original Alarmname
            logdev(module,'xbmc.executebuiltin(CancelAlarm(%r,True)' % alarmname)
            xbmc.executebuiltin('CancelAlarm(%s,True)' % alarmname)
            ### Start new recording now
            now= datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S')
            ###nowTS = int(time.mktime(datetime.datetime.now().timetuple()))
            if endDate < now:
                endDate = now
            logdev(module,'recordings.addRecordingPlanned(cat= %r, now= %r, endDate= %r, recordname= %r, nameAlarm= %r, description= %r, playchannel= %r)' % (cat, now, now, name, alarmname, description, playchannel))
            recordings.addRecordingPlanned(cat, now, endDate, name, alarmname, description, playchannel)
            script = os.path.join(ADDON.getAddonInfo('path'), 'recorduriffmpeg.py')
            args     = 'b64' + base64.b64encode(cat) + ',' + str(now) + ',' + str(endDate) + ',' + str(duration) + ',' + name + ',' + '60' + ',' + 'True'
            args= args + ',' + alarmname + ',b64' + base64.b64encode(description)
            cmd = 'AlarmClock(%s,RunScript(%s,%s),%d,True)' % (alarmname, script, args, 0)
            logdev(module,'xbmc.executebuiltin(cmd= %r)' % cmd)
            xbmc.executebuiltin(cmd)
            