#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmc, xbmcvfs
# For Python 3.0 and later
from urllib.request import urlopen
import sys
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import definition
import utils
import recordings
import glob
import os
import locking
import updateepg
module    = 'fullandfavoriteEPG.py'

def log(infotext,showlength=1024):
    definition.log(infotext,showlength,module)

try:
    ADDON     = definition.getADDON()
    ADDONid   = definition.ADDONgetAddonInfo('id')
    ADDONname = definition.ADDONgetAddonInfo('name')
    datapath  = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
    progpath  = definition.ADDONgetAddonInfo('path')
    
    log('Started')
    log('sys.argv= %r' % sys.argv)
    alarmName = 'fullandfavoriteEPG'
    marker    = 'once'
    try:
        marker = sys.argv[1]
    except Exception as e:
        pass
        definition.log('fullandfavoriteEPG: ERROR: %r' % e)
    alarmName = alarmName + '-' + marker   
    recordings.updateAlarm(alarmName)
    log('after updateAlarm')
    BACKUP_PATH = definition.ADDONgetSetting('backup_path')
    log('BACKUP_PATH= %r' % BACKUP_PATH)
    RECORD_PATH = definition.ADDONgetSetting('record_path')
    log('RECORD_PATH= %r' % RECORD_PATH)
    enabled = definition.ADDONgetSetting('fullandfavoriteEPGenable')
    log('enabled= %r' % enabled)
    
    try:
        ChannelFile2 = os.path.join(datapath,ADDONname) + 'fullEPG.xml'         
        log('ChannelFile2= %r' % ChannelFile2)
        ChannelFile4 = 'favoritesEPG.xml'
        log('ChannelFile4= %r' % ChannelFile4)
        ROQuser = definition.ADDONgetSetting('user')
        ROQpass = definition.ADDONgetSetting('pass')
        httplinkEPG = definition.getBASEURL() + '/xmltv.php?username=' +ROQuser+ '&password=' +ROQpass +'&next_days=7'
        log('httplinkEPG= %r' % httplinkEPG)
        data = utils.readlink(httplinkEPG,ChannelFile2,module)
        log('data= %r' % data)
        ### copy EPG to master.xml in Recordingsfolder
        if os.path.exists(ChannelFile2):
            log('ChannelFile2 exists= %r' % ChannelFile2)
            Recordings = xbmcvfs.translatePath(definition.FileManagerPath('Recordings'))
            destf = os.path.join(Recordings,str(xbmc.getInfoLabel('System.FriendlyName'))+'fullEPG.xml')   ### 2025-07-23
            log('1 destf= %r' % destf)
            copyOK = xbmcvfs.copy(ChannelFile2, destf)
            if not copyOK:
                log('Copy of %r failed - ERR: %r' %  (destf,copyOK))
            wanted = recordings.getFavoriteChannelsEPG()
            log('wanted= %r' % wanted)
            utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] Select XMLTV channels Wanted: %r' % wanted)
            ###wanted = ['dr1.dk','493972']
            destf = os.path.join(Recordings,'epg',ChannelFile4)
            log('2 destf= %r' % destf)
            result = updateepg.SelectXMLTVchannels(wanted,ChannelFile2,destf)
            log('SelectXMLTVchannels result= %r' % result)
        utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] Select XMLTV channels Finished with result %r' % result)
        
    except Exception as e:
        pass
        log('Select XMLTV channels Exception: %r' %e)
        utils.notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] Select XMLTV channels failed: %r' % e)
        
except Exception as  e:
    pass
    log('Exception in fullandfavoriteEPG: %r' % e)
log('Ended')

