#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import os
import sys
import time
import shutil
import datetime
import time
import signal
import base64
#import locking     #Use locking to write test messages as filenames
###import recordings
from subprocess import Popen, PIPE, STDOUT

#ADDON      = xbmcaddon.Addon(id='plugin.video.wozboxntv')
import definition
ADDON      = definition.getADDON()
ADDONid    = ADDON.getAddonInfo('id')
ADDONname  = ADDON.getAddonInfo('name')
xbmc.log('utils.py in %s' % ADDONname) ###, level=xbmc.LOGNOTICE)
referral = ADDON.getSetting('my_referral_link')
datapath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
progpath = ADDON.getAddonInfo('path')   
###IMAGE = os.path.join(ADDON.getAddonInfo('path'), 'icon' + referral + '.jpg')
IMAGE = os.path.join(ADDON.getAddonInfo('path'), 'icon.png')
directrecording = ADDON.getSetting('enable_record_drdk_directly')
module = 'utils.py'
showlength = 1024
notify = ADDON.getSetting('notifyduringepgupdate')
if notify == 'true':
    notifyduringepgupdate = True
else:
    notifyduringepgupdate = False

"""
    Outputs message to log file
    :param msg: message to output
    :param level: debug levelxbmc. Values:
    xbmc.LOGDEBUG = 0
    xbmc.LOGERROR = 4
    xbmc.LOGFATAL = 6
    xbmc.LOGINFO = 1
    xbmc.LOGNONE = 7
    xbmc.LOGNOTICE = 2
    xbmc.LOGSEVERE = 5
    xbmc.LOGWARNING = 3
"""
   
def logdevreset():
    datapath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
    addonlog = os.path.join(datapath, 'addon.log')
    addonOLDlog = os.path.join(datapath, 'addonOLD.log')
    
    try:
        size = os.path.getsize(addonlog)
        maxsize = 10 * 1024 * 1024 # 10 MB 
        if os.path.exists(addonlog) and size > maxsize:
 
            shutil.copyfile(addonlog, addonOLDlog)
        
            tries    = 0
            maxTries = 10
            maxSleep = 50
            while os.path.exists(addonlog) and tries < maxTries:
                try:
                    os.remove(addonlog)
                    break
                except:
                    xbmc.sleep(maxSleep)
                    tries = tries + 1
    except Exception, e:
        pass
        ### xbmc.log('%r: Reset addon.log failed: %r' % (ADDONname,e), level=xbmc.LOGERROR)
        xbmc.log('%r: Reset addon.log failed: %r' % (ADDONname,e))
 
def logm(module,message):  ### Log to KODI Log
    ### xbmc.log(ADDON.getAddonInfo('name') + ' ' + module +': ' + message, level=xbmc.LOGERROR)
    xbmc.log(ADDON.getAddonInfo('name') + ' ' + module +': <*' + message[0:showlength]+'*>')
    
def log(infotext):
    if 'err' in infotext.lower():
        logdev('err',module + ': ' + infotext)
    else:
        logdev(module,infotext)

def logd1(infotext):
    log('err: ' + infotext)

def logarray(Name,Array,nelements=1):
    i = 0
    for rec in Array:
        try:
            if nelements==1:
                log('logarray in %s= %r %r' % (Name,i,rec))
                i += 1
            else:
                records = []
                for index in range(0, nelements):
                    records.append(rec[index])
                log('logarray in %s= %r %r' % (Name,i,records))
                i += 1
        except Exception,e:
            pass
            log('ERROR: logarray in %s= %r' % (Name,e))

def logdev(module,message):
    if ADDON.getSetting('addonlog') == '1' and not module in ADDON.getSetting('modulestoaddonlog'):
        logm(module,message)
    else:
        try:
            nowHMS=datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S')
            datapath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
            addonlog = os.path.join(datapath, 'addon.log')
            logdevreset()
            LogDev = open(addonlog, 'a')
            # Write to our text file the information we have provided and then goto next line in our file.
            # LogDev.write(repr(module) + ': ' + repr(message) + '\n')
            if len(message) > showlength:
                LogDev.write(nowHMS + ' ' + module + ': <*\n' + message[0:showlength]+'...\n*>\n')
            else:
                LogDev.write(nowHMS + ' ' + module + ': <*\n' + message+'\n*>\n')
        except Exception, e:
            pass
            log('error in logdev: ' + repr(e))

def loglist(module,programs,label):
    for prog in programs:
        progpart = []
        for indexJ in range(0, len(prog)):
            progpart.append(prog[indexJ])
        log('%s= %r' % (label,progpart))
        
def logdevarray(module,array):
    log('\n')
    try:
        if type(array) in (list, tuple, dict):
            log('len(array)= %r' % len(array))
            for note in array:
                if type(note) in (list, tuple, dict):
                    i = 0
                    for n in note:
                        log('array[%d]= %r' % (i,note))
                        i += 1
                else:
                    log('array[x]= %r - %r' % (note, array[note]))
            log('\n')
        else:
            log('array= %r' % array)
    except Exception, e:
        pass
        log('error in logdevarray: ' + repr(e))

def get_free_space_gb(dirname,archive=''):
    try:
        log('err test sdiskusage folderPath= %r' % dirname)
        import ctypes
        import os
        import platform
        import sys
        """Return folder/drive free space (in gigabytes)."""
        if platform.system() == 'Windows':
            free_bytes = ctypes.c_ulonglong(0)
            ctypes.windll.kernel32.GetDiskFreeSpaceExW(ctypes.c_wchar_p(dirname), None, None, ctypes.pointer(free_bytes))
            freeGB = free_bytes.value / 1024 / 1024 / 1024
        else:
            st = os.statvfs(dirname)
            freeGB = st.f_bavail * st.f_frsize / 1024 / 1024 /1024
        
        if archive == 'A':
            ADDON.setSetting('record_archive_size',str(freeGB))
        elif archive == 'L':
            ADDON.setSetting('record_path_size',str(freeGB))
        log('err test sdiskusage freeGB= %r, folderPath= %r' % (freeGB,dirname))
        return freeGB
    except Exception,e:
        pass
        log('error sdiskusage %r' % e)
        try:
            if archive == 'A':
                ADDON.setSetting('record_archive_size',repr(e))
            elif archive == 'L':
                ADDON.setSetting('record_path_size',repr(e))
            log('err test sdiskusage freeGB Error= %r, folderPath= %r' % (e,dirname))
        except Exception,e:
            pass
            log('error sdiskusage 2 %r' % e)
        return -1
        

def HT(TS):
    try:
        TStype = type(TS)
        log('TStype= %r' % TStype)
        if isinstance(TS, float):
            return humantime(int(TS))
            ###recordings.humantime(time.mktime(TS.timetuple()))
        elif isinstance(TS, int):
            return humantime(TS)
        elif isinstance(TS, datetime.datetime):
            return humantime(TS)
        else:
            return humantime(TS)
    except Exception,e:
        pass
        log('ERROR HT(TS= %r)\nERROR: %r' % (TS,e))

def ht(ts):    ### Timestamp to short human time
    if not isinstance(ts, int):
        return ts
    dt = datetime.datetime.fromtimestamp(ts)
    ###ht = dt.strftime("%Y-%m-%d %H:%M:%S")
    ht = dt.strftime("%m-%d %H:%M")
    return ht
    
def humantime(ts):   ### Timestamp to human time
    if isinstance(ts, int):
        dt = datetime.datetime.fromtimestamp(ts)
    elif isinstance(ts, datetime.datetime):
        dt = ts
    else:
        return ts
    ###dt = datetime.datetime.fromtimestamp(ts)
    ht = dt.strftime("%Y-%m-%d %H:%M:%S")
    ###ht = dt.strftime("%m-%d %H:%M")
    return ht

def humantimestop(dt):   ### datetime to human time with microseconds
    ###dt = datetime.fromtimestamp(ts)
    htms = dt.strftime("%f")[:3]
    ###ht = dt.strftime("%Y-%m-%d %H:%M:%S") + ',' + htms
    ht = dt.strftime("%H:%M:%S") + ',' + htms
    return ht

def dt(ts):   ### DateTime from Timestamp
    if not isinstance(ts, int):
        return ts
    dt = datetime.datetime.fromtimestamp(ts)
    return dt
    
def ts(ds):   ### Date string to timestamp
    if not isinstance(ts, str):
        return ds
    ###ds = "2008-11-10 17:53:59"
    time_tuple = time.strptime(ds, "%Y-%m-%d %H:%M:%S")
    ###time_tuple = (2008, 11, 12, 13, 59, 27, 2, 317, 0)
    ts = int(time.mktime(time_tuple))
    return ts
            
"""
time_tuple = dt_obj.timetuple()
time_tuple = (2008, 11, 12, 13, 59, 27, 2, 317, 0)
timestamp = time.mktime(time_tuple)
"""

def decode64(text):
    try:
        if text[:3] == 'b64':
            decoded = base64.b64decode(text[3:])
        else:
            decoded = text
    except Exception,e:
        pass
        log('base64.b64decode Error %r' % e)
        decoded = text
    return decoded
    
def encode64(text):
    try:
        if text:
            encoded = 'b64' + base64.b64decode(text)
        else:
            encoded = text
    except Exception,e:
        pass
        log('base64.b64encode Error %r' % e)
        encoded = text
    return encoded

def TwoLines(name):  ### Use in menus to allow autoscroll and see all text on both lines
    ###log('TwoLines(name)= %r' % name)
    name = name.replace('  ',' ').split('\n')
    line1 = name[0]
    lenline1 = len(line1)
    line2 = ''
    for i in range(1, len(name)):
        line2 += name[i] + ' '
    lenline2 = len(line2)
    if lenline1 < lenline2:
        line1 = line1 + '  ' * (lenline2 - lenline1)
    if line2 != '':
        name = line1 +'\n' + line2
    else:
        name = line1
    return name 

def notnone(cat):
    if cat == None:
        return ''
    else:
        return cat
        
def makeOldFile(file):
    if os.path.isfile(file):
        ext = '.' + file.split('.')[-1]
        new = 'OLD' + ext
        oldfile = file.replace(ext,new)
        log('oldfile= %r' % oldfile)
        shutil.copyfile(file, oldfile)

def notificationsend(name):
    # Show menuentry when finished OK - but not when run in the background
    contextMenu = []
    try:
        log(name)
        liz=xbmcgui.ListItem(name)
        liz.setProperty('IsPlayable','false')
        contextMenu.append(('[COLOR orange][B]Back to view[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=666&url=None&iconimage=None&cat=0)'% (sys.argv[0])))
        contextMenu.append(('[COLOR red][B]Back to Kodi[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=29&url=None&iconimage=None&cat=0)'% (sys.argv[0])))
        liz.addContextMenuItems(contextMenu,replaceItems=True)
        xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url='url',listitem = liz, isFolder = False) 
        log('notificationsend - Finished in foreground with menu item')
    except Exception, e:
        pass
        log('error in notificationsend: ' + repr(e))
        log('notificationsend - Finished in background - no menu item')

def testPrograms():
    notificationUPD('Test recording programs')
    try:  ### Get system timezone
        timezone = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Settings.GetSettingValue", "params": {"setting": "locale.timezone"}, "id": 1}')
        log('Kodi timezone= %r' % timezone)
    except Exception, e:
            pass
            log('Get timezone error= %r' % e)
    try:   ### Test if ffmpeg is installed
        if runCommandTest('ffmpeg'):
            notificationUPD('FFMPEG has been installed!')
            log('FFMPEG installed!')
        else:
            log('FFMPEG NOT installed!')
    except Exception, e:
            pass
            log('Get ffmpeg error= %r' % e)
    try:   ### Test if rtmpdump is installed
        if runCommandTest('rtmpdump'):
            log('RTMPDUMP installed!')
        else:
            log('RTMPDUMP NOT installed!')
    except Exception, e:
            pass
            log('Get rtmpdump error= %r' % e)
    try:   ### Test if 7zip is installed
        if runCommandTest('7z'):
            log('7z installed!')
        else:
            log('7z NOT installed!')
    except Exception, e:
            pass
            log('Get 7z error= %r' % e)
    try:   ### Test if xarchiver -v is installed
        if runCommandTest('xarchiver -v'):
            log('xarchiver -v installed!')
        else:
            log('xarchiver -v NOT installed!')
    except Exception, e:
            pass
            log('Get xarchiver -v error= %r' % e)

def FindDirectPrograms():
    directprograms= []
    ###log('FindDirectPrograms directrecording= ' + repr(directrecording))
    if directrecording == '2':   ### HD
        directfile = os.path.join(progpath,'resources','directchannelshd.csv')
        log('FindDirectPrograms: directfile HD= ' + repr(directfile))
    if directrecording == '1':   ### SD
        directfile = os.path.join(progpath,'resources','directchannelssd.csv')
        #log('FindDirectPrograms','directfile SD= ' + repr(directfile))
    if not directrecording == '1' and not directrecording == '2':
        log('FindDirectPrograms: No directfile!')
        return directprograms
        
    try: 
        csvfile = open(directfile,'r')
    except Exception, e:
        log('FindDirectPrograms: error in open file ' + repr(directfile) +': ' + repr(e))
        pass
        return directprograms
    line0 = csvfile.readline()
    #log('FindDirectPrograms First line: ' + repr(line0))
    nextline=csvfile.readline().strip().split(',')
    #log('FindDirectPrograms Next line: ' + repr(nextline))
    while not nextline == [''] :
        directprograms.append(nextline)
        #log('FindDirectPrograms directprograms: ' + repr(directprograms))
        nextline=csvfile.readline().strip().split(',')
        #log('FindDirectPrograms Next line: ' + repr(nextline))
        #log('FindDirectPrograms len(nextline): ' + repr(len(nextline)))
        if not len(nextline) == 3:
            break 
        if len(nextline) == 0:
            break 
    csvfile.close()
    return directprograms

def directprogramsNTV(cat):
    drprograms=FindDirectPrograms()
    recorddrdirectly=''
    if directrecording > '0':   ### SD, HD
        for index in range(0, len(drprograms)): 
            if cat ==  drprograms[index][0]:
                recorddrdirectly = drprograms[index][2]
                return recorddrdirectly
    return recorddrdirectly

def getGuiSetting(guisetting,defaultsetting):
    ### guisettings.xml <webserverport>8081</webserverport>
    ### utils.getGuiSetting(guisetting,defaultsetting)
    ### utils.getGuiSetting('webserverport','8080')
    
    try:
        guisettings = xbmc.translatePath(os.path.join('special://masterprofile' , 'guisettings.xml'))
        settingsfile = open(guisettings,'r')
        settings = settingsfile.read()
        webport = settings.split('<' + str(guisetting) + '>')
        webport = webport[1].split('</' + str(guisetting) + '>')[0]
    except Exception, e:
        log('getGuiSetting error in get ' + str(getGuiSetting) +': ' + repr(e))
        pass
        webport = str(defaultsetting)  ### Default
    log('getGuiSetting Configured ' + str(getGuiSetting) +': ' + repr(webport))
    return webport

def TVguide():
    try:
        TVguideNr= int(ADDON.getSetting('tvguidenr'))
    except:
        pass
        TVguideNr = 0
        ADDON.setSetting('tvguidenr',str(TVguideNr))
    # 0= wozboxtvguide/roq tv rec|1= tvguide|2= ftvguide|3= ivueguide|4= custom (if empty search all known)|5= no tv guide search
    #log('TVguideNr',repr(TVguideNr))
    if TVguideNr == 0:
        ###TVguide= [['script.wozboxtvguide2.0','source.db']]
        TVguide= [[ADDONid,'recordings_adc.db']]
    elif TVguideNr == 1:
        TVguide= [['script.tvguide','source.db']]
    elif TVguideNr == 2:
        TVguide= [['script.ftvguide','source.db']]
    elif TVguideNr == 3:
        TVguide= [['script.ivueguide','master.db']]
    elif TVguideNr == 4:
        #TVguide= [ ['script.tvguide','source.db']]
        ExtraGuide= ''
        ExtraGuideDB= ''
        ExtraGuidePathDB= ADDON.getSetting('tvguidenotificationsDB')
        ExtraGuideList= ExtraGuidePathDB.split(os.sep)
        ExtraGuide= ExtraGuideList[-2]
        ExtraGuideDB= ExtraGuideList[-1]
        if ExtraGuide != '' and ExtraGuideDB != '':
            TVguide= [[ExtraGuide,ExtraGuideDB]]
        else:
            # If Extra TV Guide not complete - try all
            TVguide= [['script.wozboxtvguide2.0','source.db'], ['script.tvguide','source.db'],['script.ftvguide','source.db'],['script.ivueguide','master.db']]
    else:
        # No search in TV Guide
        TVguide= []
    #log('findtvguidenotifications TVguide',repr(TVguide))
    if len(TVguide) != 0:
        ADDON.setSetting('activetvguide',repr(TVguide[0][0]))
    else:
        ADDON.setSetting('activetvguide','none')
    return TVguide
    
def ChannelNameLookuponWeb(cat):
    
    net.set_cookies(cookie_jar)
    imageUrl=definition.getBASEURL() + '/res/content/tv/'
    now= datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20')
    url='&mwAction=category&xbmc=1&mwData={"id":"%s","time":"%s","type":"tv"}'%('-2',now)
    
    link = net.http_GET(site+url, headers={'User-Agent' : UA}).content
    
    data = json.loads(link)
    channels=data['contents']
    
    for field in channels:
        channel      =  field['id']
        if channel == cat:
            name         =  field['name'].encode("utf-8")
            
            return name
    notification( 'NOT FOUND: channel= %s' % (cat))
    return 'no name'

def logdebug(module,message):
    if ADDON.getSetting('DebugRecording')=='true':
        log(message)

def notificationUPD(message, time = 0):
    if notifyduringepgupdate:
        notificationforced(message, time)
      
def notificationforced(message, time = 0):
    if (not ADDON.getSetting('RecursiveSearch')=='true' or ADDON.getSetting('NotifyOnSearch')=='true'):
        message = message.replace(',',  '')     ### No commas in text allowed
        if time == 0:
            try:
                time = int(ADDON.getSetting('NotificationTime'))
            except:
                pass
            if time == 0:
                time = 30
        
        header = definition.getTITLE()
        cmd  = 'XBMC.Notification(%s, %s, %r, %s)' % (header, message, time*1000, IMAGE)  ### 2017-07-27    
        
        try:
            window_id = xbmcgui.getCurrentWindowId()
            logd1('notificationforced window_id= %r' % window_id)
            win = xbmcgui.Window(window_id)
            window_f = win.getFocus()   ### Only continue if current window is in focus!
            logd1('notificationforced window_f= %r' % window_f)
            if xbmc.getCondVisibility('Player.HasMedia') != True:
                logd1('notificationforced cmd= %r' % cmd)
                xbmc.executebuiltin(cmd) 
        except Exception,e:
            pass
            logd1('Windows Focus Error - No Notifications: %r' % e)
        
      
def notification(message, time = 0):
    
    if (not ADDON.getSetting('RecursiveSearch')=='true' or ADDON.getSetting('NotifyOnSearch')=='true'):
        
        message = message.replace(',',  '')     ### No commas in text allowed
        
        log('notification: ' + message)
        if ADDON.getSetting('ShowNotifications') == 'true' and xbmc.getCondVisibility('Player.HasMedia') != True :
            notificationforced(message, time)
    
def notificationboxadd(message):
    oldmessage= ADDON.getSetting('allmessages')
    if oldmessage == '':
        allmessages= message
    else:
        allmessages= message + '/' + oldmessage
    ADDON.setSetting('allmessages',allmessages)
    
def notificationbox(message):
    oldmessage= ADDON.getSetting('allmessages')
    if oldmessage == '':
        allmessages= message
    else:
        allmessages= message + '[CR]' + oldmessage
    ADDON.setSetting('allmessages',allmessages)
    log('notificationbox' + allmessages)
    if ADDON.getSetting('ShowNotifications') == 'true' and xbmc.getCondVisibility('Player.HasMedia') != True :
        xbmcgui.Dialog().ok( ADDON.getAddonInfo('name'), allmessages)
    ADDON.setSetting('allmessages','')
        
def folderwritable(path):
    log('err folderwritable(path= %r)' % path)
    if os.access(path, os.W_OK):
        log('err OK-1 folderwritable(path= %r)' % path)
        return True
    else:
        if '://' in path:
            log('err OK-2 folderwritable(path= %r)' % path)
            return True
        else:
            if path=='':
                path = xbmc.translatePath(os.path.join(ADDON.getSetting('record_path')))
                log('err empty folderwritable(path= %r)' % path)
                if path=='':
                    xbmcgui.Dialog().ok( ADDON.getAddonInfo('name'), '[COLOR red]utils.py folderwritable: ERROR[/COLOR]', '[Empty path]', 'The folder is not writable! \nGoto Settings/Recording/Set Record Path \nand set that to a writable path \nor disable recording')
            else:
                log('err folderwritable(path= %r)' % path)
                xbmcgui.Dialog().ok( ADDON.getAddonInfo('name'), '[COLOR red]utils.py folderwritable: ERROR[/COLOR]', path, 'The folder is not writable! \nGoto Settings/Recording/Set Record Path \nand set that to a writable path \nor disable recording')
            return False

def filterfalse(predicate, iterable):
    # filterfalse(lambda x: x%2, range(10)) --> 0 2 4 6 8
    if predicate is None:
        predicate = bool
    for x in iterable:
        if not predicate(x):
            yield x

def unique_everseen(iterable, key=None):
    "List unique elements, preserving order. Remember all elements ever seen."
    # unique_everseen('AAAABBBCCDAABBB') --> A B C D
    # unique_everseen('ABBCcAD', str.lower) --> A B C D
    seen = set()
    seen_add = seen.add
    if key is None:
        for element in filterfalse(seen.__contains__, iterable):
            seen_add(element)
            yield element
    else:
        for element in iterable:
            k = key(element)
            if k not in seen:
                seen_add(k)
                yield element

def uniquecolon(items):
    # print 'utils.py uniquecolon(items)= %s' % repr(items) 
    listitems=items.split(':')
    result=':'.join(unique_everseen(listitems))
    # print 'utils.py uniquecolon(items) result= %s' % repr(result) 
    return result
    
def FindPlatform():
    # Find the actual platform
    Platform = ''
    try:
        kodilog = xbmc.translatePath(os.path.join('special://logpath' , 'kodi.log'))
        try: csvfile = open(kodilog,'r')
        except:
            pass
            kodilog = xbmc.translatePath(os.path.join('special://logpath' , 'xbmc.log'))
            try: csvfile = open(kodilog,'r')
            except:
                pass
                kodilog = xbmc.translatePath(os.path.join('special://logpath' , 'tvmc.log'))
                try: csvfile = open(kodilog,'r')
                except:
                    pass
                    kodilog = xbmc.translatePath(os.path.join('special://logpath' , 'spmc.log'))
                    try: csvfile = open(kodilog,'r')
                    except:
                        pass
                        log('ERROR FindPlatform csvfile not found')
                    """
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: -----------------------------------------------------------------------
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: Starting Kodi (18.2 Git:20190422-f264356). Platform: Linux x86 64-bit
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: Using Release Kodi x64 build
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: Kodi compiled 2019-04-22 by GCC 7.3.0 for Linux x86 64-bit version 4.15.18 (266002)
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: Running on Ubuntu 18.04.2 LTS, kernel: Linux x86 64-bit version 4.18.0-17-generic
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: FFmpeg version/source: 4.0.3-Kodi
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: Host CPU: Intel(R) Core(TM) i7-3517U CPU @ 1.90GHz, 4 cores available
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: special://xbmc/ is mapped to: /usr/share/kodi
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: special://xbmcbin/ is mapped to: /usr/lib/x86_64-linux-gnu/kodi
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: special://xbmcbinaddons/ is mapped to: /usr/lib/x86_64-linux-gnu/kodi/addons
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: special://masterprofile/ is mapped to: /home/hans/.kodi/userdata
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: special://envhome/ is mapped to: /home/hans
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: special://home/ is mapped to: /home/hans/.kodi
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: special://temp/ is mapped to: /home/hans/.kodi/temp
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: special://logpath/ is mapped to: /home/hans/.kodi/temp
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: The executable running is: /usr/lib/x86_64-linux-gnu/kodi/kodi-x11
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: Local hostname: fabses-UX31A
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: Log File is located: /home/hans/.kodi/temp/kodi.log
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: -----------------------------------------------------------------------
                    """


        line = csvfile.readline()   ### Read first 8 lines
        line += csvfile.readline()
        line += csvfile.readline()
        line += csvfile.readline()
        line += csvfile.readline()
        line += csvfile.readline()
        line += csvfile.readline()
        line += csvfile.readline()
        Platform = line.split('Platform: ')[1].split('-bit')[0].strip()+'-bit'
        ADDON.setSetting('platform',Platform)
        RunningOn = line.split('Running on ')[1].split(' ')[0].strip()
        ADDON.setSetting('runningon',RunningOn)
        log('Platform'+ repr(ADDON.getSetting('platform')))   # Put in LOG
        log('RunningOn'+ repr(ADDON.getSetting('runningon')))   # Put in LOG
        log('OS'+ os.environ['OS'])  # Put in LOG
    except Exception,e: 
        pass
        log('FindPlatform ERROR FAILED: ' + repr(e))   # Put in LOG
    finally:
        csvfile.close()
    return Platform

def rtmpdumpFilename():
    if ADDON.getSetting('DebugRecording')=='false': #dont update Paltform if debugging recordings
        try:
            Platform = FindPlatform()
            ADDON.setSetting('osplatform','')
            if Platform == 'Windows NT x86 32-bit':
                ADDON.setSetting('os','11')
            elif Platform == 'Windows NT x86 64-bit':
                ADDON.setSetting('os','11')
            elif Platform == 'Android ARM 32-bit':
                ADDON.setSetting('os','13')
            elif Platform == 'Android x86 32-bit':
                ADDON.setSetting('os','13')
            elif Platform == 'Linux x86 64-bit':
                ADDON.setSetting('os','7')
            elif Platform == 'Linux x86 32-bit':
                ADDON.setSetting('os','6')
            else:
                log ('rtmpdumpFilename:  Your platform= %s has not been set automatically!' % repr(Platform))  # Put in LOG
        except:
            pass
            log ('rtmpdumpFilename:  ERROR Failed to automatically update platform!')  # Put in LOG
        ADDON.setSetting('osplatform',ADDON.getSetting('os'))
        log('rtmpdumpFilename Running on %s' % repr( ADDON.getSetting('runningon')))
        if 'OpenELEC' in ADDON.getSetting('runningon'):
            ADDON.setSetting('os','12')
        if 'samsung' in ADDON.getSetting('runningon'):
            ADDON.setSetting('os','13')
        if 'WOZTEC' in ADDON.getSetting('runningon'):
            ADDON.setSetting('os','13')
        if 'MBX' in ADDON.getSetting('runningon'): 
            ADDON.setSetting('os','13')
        if 'Genymotion' in ADDON.getSetting('runningon'): 
            ADDON.setSetting('os','13')
        # Enable the following two lines to test running on Ubuntu!
        #if 'Ubuntu' in ADDON.getSetting('runningon'):  # ONLY TEST
        #   ADDON.setSetting('os','13')
    quality = ADDON.getSetting('os')
    log ('rtmpdumpFilename quality= %s' %quality)
    #if quality == '0':
    #   return 'androidarm/rtmpdump'
    #elif quality == '1':
    #   return 'android86/rtmpdump'
    #el
    if quality == '2':
        return 'atv1linux/rtmpdump'
    elif quality == '3':
        return 'atv1stock/rtmpdump'
    elif quality == '4':
        return 'atv2/rtmpdump'
    elif quality == '5':
        return 'ios/rtmpdump'
    elif quality == '6':
        return 'linux32/rtmpdump'
    elif quality == '7':
        return 'linux64/rtmpdump'
    elif quality == '8':
        return 'osx106/rtmpdump'
    elif quality == '9':
        return 'osx107/rtmpdump'
    elif quality == '10':
        return 'pi/rtmpdump'
    elif quality == '11':
        return 'win/rtmpdump.exe'
    elif quality == '12':
        return '/usr/bin/rtmpdump'
    elif quality == '13' or quality == '0' or quality == '1':
        return  '/system/vendor/bin/rtmpdump' # HOTFIX Android - rtmpdump moved to /system/bin (using build in librtmp.so from kodi)
    else:
        log('rtmpdumpFilename: Your platform= %s has not been set automatically!' % repr(Platform))  # Put in LOG
        return

def libPath():
    quality = ADDON.getSetting('os')
    log ('libPath quality= %s' %quality)
    #if quality == '0':
    #   return os.path.join(ADDON.getAddonInfo('path'),'rtmpdump', 'androidarm')
    #elif quality == '1':
    #   return os.path.join(ADDON.getAddonInfo('path'),'rtmpdump', 'android86')
    #el
    if quality == '2':
        return os.path.join(ADDON.getAddonInfo('path'),'rtmpdump', 'atv1linux')
    elif quality == '3':
        return os.path.join(ADDON.getAddonInfo('path'),'rtmpdump', 'atv1stock')
    elif quality == '4':
        return os.path.join(ADDON.getAddonInfo('path'),'rtmpdump', 'atv2')
    elif quality == '5':
        return os.path.join(ADDON.getAddonInfo('path'),'rtmpdump', 'ios')
    elif quality == '6':
        return os.path.join(ADDON.getAddonInfo('path'),'rtmpdump', 'linux32')
    elif quality == '7':
        return os.path.join(ADDON.getAddonInfo('path'),'rtmpdump', 'linux64')
    elif quality == '8':
        return os.path.join(ADDON.getAddonInfo('path'),'rtmpdump', 'osx106')
    elif quality == '9':
        return os.path.join(ADDON.getAddonInfo('path'),'rtmpdump', 'osx107')
    elif quality == '10':
        return os.path.join(ADDON.getAddonInfo('path'),'rtmpdump', 'pi')
    elif quality == '11':
        return 'None'   
    elif quality == '12':
        return '/usr/bin/'
    elif quality == '13' or quality == '0' or quality == '1':
        LIBpath = '/data/data/org.xbmc.kodi/lib/'
        log( 'libPath: os.path.exists(%s)= %s' % (repr(LIBpath),repr(os.path.exists(LIBpath))))  # Put in LOG
        log( 'libPath: os.path.exists(%s)= %s' % (repr(LIBpath + 'librtmp.so'),repr(os.path.exists(LIBpath + 'librtmp.so'))))  # Put in LOG
        return LIBpath
"""
def runCommandTest(cmd):
    log('runCommandTest cmd= %s' % repr(cmd)) # Put in LOG
    
    # subpr = Popen(cmd, shell=True, env=env, stdin=PIPE, stdout=PIPE, stderr=STDOUT) # original
    quality = ADDON.getSetting('os')
    if quality=='13' or  quality=='0' or quality=='1':
        subpr = Popen(cmd, executable='/system/bin/sh', shell=True, close_fds=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT)
    else:
        subpr = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT) 

    x = subpr.stdout.read()
    log('runCommandTest x= %r' % x) # Put in LOG
    expectedresult = 'copyright'   ### 2017-12-16
    if expectedresult.lower() in x.lower():
        return True
    expectedresult = '(c)'   ### 2017-12-16
    if expectedresult.lower() in x.lower():
        return True
    else:
        return False  
"""
        
def runCommandTest(cmd):
    log('runCommandTest: 1.cmd= %r' % cmd) # Put in LOG
    # subpr = Popen(cmd, shell=True, env=env, stdin=PIPE, stdout=PIPE, stderr=STDOUT) # original
    quality = ADDON.getSetting('os')
    log('runCommandTest: 2.quality= %r' % quality) # Put in LOG
    try:
        if quality != 'X':  ###Always use this path
            try:
                subpr = Popen(cmd, executable='/system/bin/sh', shell=True, close_fds=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT)
                log('runCommandTest: 3.subpr= %r' % subpr) # Put in LOG
            except Exception,e:
                pass
                log('runCommandTest: 4.Error= %r' % e) # Put in LOG
                try:
                    subpr = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT)
                    log('runCommandTest: 5.subpr= %r' % subpr) # Put in LOG
                except Exception,e:
                    pass
                    log('runCommandTest: 6.Error= %r' % e) # Put in LOG
                    return False
        elif quality=='13' or  quality=='0' or quality=='1':
            subpr = Popen(cmd, executable='/system/bin/sh', shell=True, close_fds=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT)
        else:
            subpr = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT) 

        x = subpr.stdout.read(1024)   ### Only read first part of output
        log('runCommandTest: 7.x= %r' % x) # Put in LOG
        expectedresult = 'copyright'   ### 2017-12-16
        if expectedresult.lower() in x.lower():
            return True
        expectedresult = '(c)'   ### 2017-12-16
        if expectedresult.lower() in x.lower():
            return True
        expectedresult = 'BusyBox'   ### 2018-05-26 xz on LibreELEC
        if expectedresult.lower() in x.lower():
            return True
        expectedresult = 'usage: mkchromecast'   ### 2018-05-26 mkchromecast on Ubuntu
        if expectedresult.lower() in x.lower():
            return True
        expectedresult = 'usage: vlc-cache-gen'
        if expectedresult.lower() in x.lower():
            return True
        else:
            return False 
    except Exception,e:
        pass
        log('runCommandTest: 8.Error= %r' % e) # Put in LOG
        return False
        
def runCommand(cmd, LoopCount, libpath = None, module_path = './', nameAlarm=''):
    log('runCommand: cmd= %s' % repr(cmd)) # Put in LOG
    log('runCommand: LoopCount= %s' % repr(LoopCount)) # Put in LOG
    log('runCommand: libpath= %s' % repr(libpath)) # Put in LOG
    log('runCommand: module_path= %s' % repr(module_path)) # Put in LOG
    log('runCommand: nameAlarm= %s' % repr(nameAlarm)) # Put in LOG
    from subprocess import Popen, PIPE, STDOUT
    # get the list of already defined env settings
    env = os.environ
    log('runCommand: env= %s' % env)
    if LoopCount == 0:
        if (libpath):
            log('runCommand: libpath1= %s' %repr(libpath))
            # add the additional env setting
            envname = "LD_LIBRARY_PATH"
            if (env.has_key(envname)):
                env[envname] = env[envname] + ":" + libpath
                env[envname]=uniquecolon(env[envname])
            else:
                env[envname] = libpath
            envname = "DYLD_LIBRARY_PATH"
            if (env.has_key(envname)):
                env[envname] = uniquecolon(env[envname] + ":" + libpath)
            else:
                env[envname] = libpath
        envname = 'PYTHONPATH'
        if (env.has_key(envname)):
            env[envname] = uniquecolon(env[envname] + ":" + module_path)
        else:
            env[envname] = module_path
    try:
        log('runCommand: env[PYTHONPATH] = ' + env['PYTHONPATH'])  # Put in LOG
        log('runCommand: env[LD_LIBRARY_PATH] = ' + env['LD_LIBRARY_PATH']) # Put in LOG
        log('runCommand: env[DYLD_LIBRARY_PATH] = ' + env['DYLD_LIBRARY_PATH'])  # Put in LOG
    except:
        pass

    # subpr = Popen(cmd, shell=True, env=env, stdin=PIPE, stdout=PIPE, stderr=STDOUT) # original
    try:
        quality = ADDON.getSetting('os')
        if quality=='13' or  quality=='0' or quality=='1':
            subpr = Popen(cmd, executable='/system/bin/sh', shell=True, close_fds=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT)
        else:
            subpr = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT) 
    except Exception,e:
        pass
        subpr = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT)
        log('runCommand: Error Popen \ncmd= %r\npid= %r' % (cmd,e))
        nowHM=datetime.datetime.today().strftime('%H:%M')
        ##recordings.updateRecordingPlanned(nameAlarm, '[COLOR red]Error ' + nowHM + '[/COLOR] ' + title + ' - ' + e)
    try:
        subprpid = subpr.pid
        if subprpid != 0 and ADDON.getSetting('timeshiftbase') in cmd:  ### Only save TimeShift processes
            xbmcgui.Window(10000).setProperty(ADDONname + 'subprpid', repr(subprpid))
            xbmcgui.Window(10000).setProperty(ADDONname + 'subprcmd', cmd)
            log('runCommand: TimeShift set pid= %r, cmd= %r' % (subprpid, cmd))
        else:
            log('runCommand: NOT TimeShift pid= %r, cmd= %r' % (subprpid, cmd))
        if subprpid != 0 and 'mkchromecast' in cmd:
            ADDON.setSetting('castsubpr',repr(subprpid))
            ADDON.setSetting('castsubprcmd',cmd)
    except Exception,e:
        pass
        log('runCommand: Error save \ncmd= %r\nError: %r' % (cmd,e))
        nowHM=datetime.datetime.today().strftime('%H:%M')
        ##recordings.updateRecordingPlanned(nameAlarm, '[COLOR red]Error ' + nowHM + '[/COLOR] ' + title + ' - ' + e)
    x = subpr.stdout.read()   ### 2019-05-02  Read last characters?
    #xbmcgui.Dialog().ok( ADDON.getAddonInfo('name'), 'Test runCommand: 1', '', repr(x[-100:]))
    #xbmcgui.Dialog().input('Test runCommand: 1 \n' + repr(x[-100:]), defaultt='', type=xbmcgui.INPUT_ALPHANUM, autoclose=5000)
    if ADDON.getSetting('DebugRecording')=='true':
        log('runCommand: subpr.stdout.read()= %s' % repr(x))
        if 'ERROR' in x:
            xError=x.replace('\n','[cr]')
            notification('[COLOR red]ERROR utils.py runCommand: Basic recording function failed![/COLOR]')
            xbmcgui.Dialog().ok( ADDON.getAddonInfo('name'), 'utils.py runCommand: ERROR', '', repr(xError))
    xbmc.sleep(2000)
    ###time.sleep(2)
    while subpr.poll() == None:
        xbmc.sleep(2000)
        ###time.sleep(2)
        x = subpr.stdout.read()   ### 2019-05-02  Read last characters?
        #xbmcgui.Dialog().ok( ADDON.getAddonInfo('name'), 'Test runCommand: 1', '', repr(x[-100:]))
        #xbmcgui.Dialog().input('Test runCommand: 2 \n' + repr(x[-100:]), defaultt='', type=xbmcgui.INPUT_ALPHANUM, autoclose=5000)
        if ADDON.getSetting('DebugRecording')=='true':
            if 'ERROR' in x:
                xError=x.replace('\n','[cr]')
                notification('[COLOR red]ERROR utils.py runCommand: Basic recording function failed![/COLOR]')
                xbmcgui.Dialog().ok( ADDON.getAddonInfo('name'), 'utils.py runCommand: ERROR in Loop', '', repr(xError))
    return subpr    ### 2018-02-25

def terminateSubpr(subpr):  
    ### Popen.terminate()
    """
    There's a very good explanation of how to create a new process group with python subprocess. Adding option preexec_fn=os.setsid to Popen:

process_Festival = subprocess.Popen(["festival", "--tts", "/var/log/dmesg"],preexec_fn=os.setsid)
You can then get the process group from the process id and signal it:

pgrp = os.getpgid(process_Festival.pid)
os.killpg(pgrp, signal.SIGINT)

Popen("TASKKILL /F /PID {pid} /T".format(pid=process.pid))

    """
    record_path = ADDON.getSetting('record_path')
    platform    = ADDON.getSetting('platform')
    runningon   = ADDON.getSetting('runningon')
    osplat      = ADDON.getSetting('os')
    log('record_path= %r, platform= %r, runningon= %r, os= %r' % (record_path, platform, runningon, osplat)) 
    
    try:
        if osplat == '11':
            Popen("TASKKILL /F /PID {pid} /T".format(pid=int(subpr)))
            log('subpr.terminate on Windows (%r)' % (subpr)) 
    except Exception,e:
        pass
        log('Popen(TASKKILL /F /PID {pid} /T (%r) Error= %r' % (subpr,e)) 
    try:
        if osplat == '7':
            os.kill(int(subpr), signal.SIGINT)
            log('subpr.terminate 7(%r)' % (subpr)) 
    except Exception,e:
        pass
        log('subpr.terminate 7(%r) Error= %r' % (subpr,e)) 
          
    try:
        if osplat != '11' and osplat != '7':
            pgrp = os.getpgid(int(subpr))
            os.killpg(pgrp, signal.SIGINT)
            #os.killpg(pgrp, signal.SIGHUP)
            #os.killpg(pgrp, signal.SIGTERM)
            #os.killpg(pgrp, signal.SIGKILL)
            log('subpr.terminate tree(%r)' % (subpr)) 
    except Exception,e:
        pass
        log('subpr.terminate tree(%r) Error= %r' % (subpr,e)) 
        try:
            ### If you kill festival with a signal like SIGHUP rather than SIGKILL it will clean up any subprocesses properly.
            #os.kill(int(subpr), signal.SIGINT) # signal.SIGKILL or signal.SIGTERM
            #os.kill(int(subpr), signal.SIGHUP) # signal.SIGKILL or signal.SIGTERM
            os.kill(int(subpr), signal.SIGTERM) 
            #os.kill(int(subpr), signal.SIGKILL) 
            log('subpr.terminate %r)' % (subpr)) 
        except Exception,e:
            pass
            log('subpr.terminate(%r) Error= %r' % (subpr,e)) 
    log('subpr.terminate() ACTIVATED!')    ### 2018-02-25
"""    
def terminateSubprOLD(subpr):  
    ### Popen.terminate()
    try:
        import os
        import signal

        os.kill(int(subpr), signal.SIGTERM) #or signal.SIGKILL 
        ### subpr.terminate()     ### 2018-02-25
        log('subpr.terminate(%r)' % (subpr)) 
    except Exception,e:
        pass
        log('subpr.terminate(%r) Error= %r' % (subpr,e)) 
    log('subpr.terminate() ACTIVATED!')    ### 2018-02-25
"""    
def datetimeconversions():
    # Test date time conversions on this system
    #-------------------------------------------------
    # conversions to strings
    #-------------------------------------------------
    # datetime object to string
    dt_obj = datetime.datetime(2008, 11, 10, 17, 53, 59)
    date_str = dt_obj.strftime("%Y-%m-%d %H:%M:%S")
    print date_str

    # time tuple to string
    time_tuple = (2008, 11, 12, 13, 51, 18, 2, 317, 0)
    date_str = time.strftime("%Y-%m-%d %H:%M:%S", time_tuple)
    print date_str

    #-------------------------------------------------
    # conversions to datetime objects
    #-------------------------------------------------
    # time tuple to datetime object
    time_tuple = (2008, 11, 12, 13, 51, 18, 2, 317, 0)
    dt_obj = datetime.datetime(*time_tuple[0:6])
    print 'datetime.datetime(*time_tuple[0:6])'
    print repr(dt_obj)
    print str(dt_obj)
    
    # date string to datetime object
    date_str = "2008-11-10 17:53:59"
    ##fejler## dt_obj = datetime.datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")
    date_str = "2008-11-10 17:53:59"
    time_tuple = time.strptime(date_str, "%Y-%m-%d %H:%M:%S")
    dt_obj = datetime.datetime(*time_tuple[0:6])
    print repr(dt_obj)
    print str(dt_obj)

    # timestamp to datetime object in local time
    timestamp = 1226527167.595983
    dt_obj = datetime.datetime.fromtimestamp(timestamp)
    print repr(dt_obj)
    print str(dt_obj)

    # timestamp to datetime object in UTC
    timestamp = 1226527167.595983
    dt_obj = datetime.datetime.utcfromtimestamp(timestamp)
    print repr(dt_obj)
    print str(dt_obj)

    #-------------------------------------------------
    # conversions to time tuples
    #-------------------------------------------------
    # datetime object to time tuple
    dt_obj = datetime.datetime(2008, 11, 10, 17, 53, 59)
    time_tuple = dt_obj.timetuple()
    print repr(time_tuple)
    print str(time_tuple)

    # string to time tuple
    date_str = "2008-11-10 17:53:59"
    time_tuple = time.strptime(date_str, "%Y-%m-%d %H:%M:%S")
    print repr(time_tuple)
    print str(time_tuple)

    # timestamp to time tuple in UTC
    timestamp = 1226527167.595983
    time_tuple = time.gmtime(timestamp)
    print repr(time_tuple)
    print str(time_tuple)

    # timestamp to time tuple in local time
    timestamp = 1226527167.595983
    time_tuple = time.localtime(timestamp)
    print repr(time_tuple)
    print str(time_tuple)

    #-------------------------------------------------
    # conversions to timestamps
    #-------------------------------------------------
    # time tuple in local time to timestamp
    time_tuple = (2008, 11, 12, 13, 59, 27, 2, 317, 0)
    timestamp = time.mktime(time_tuple)
    print repr(timestamp)
    print str(timestamp)

    # time tuple in utc time to timestamp
    time_tuple_utc = (2008, 11, 12, 13, 59, 27, 2, 317, 0)
    timestamp_utc = calendar.timegm(time_tuple_utc)
    print repr(timestamp_utc)
    # time tuple in utc time to timestamp
    time_tuple_utc = (2008, 11, 12, 13, 59, 27, 2, 317, 0)
    #timestamp_utc = calendar.timegm(time_tuple_utc)
    timestamp_utc = calendar.timegm(time_tuple_utc)
    print repr(timestamp_utc)
    print str(timestamp_utc)

    #-------------------------------------------------
    # results
    #-------------------------------------------------
    # 2008-11-10 17:53:59
    # 2008-11-12 13:51:18
    # datetime.datetime(2008, 11, 12, 13, 51, 18)
    # datetime.datetime(2008, 11, 10, 17, 53, 59)
    # datetime.datetime(2008, 11, 12, 13, 59, 27, 595983)
    # datetime.datetime(2008, 11, 12, 21, 59, 27, 595983)
    # (2008, 11, 10, 17, 53, 59, 0, 315, -1)
    # (2008, 11, 10, 17, 53, 59, 0, 315, -1)
    # (2008, 11, 12, 21, 59, 27, 2, 317, 0)
    # (2008, 11, 12, 13, 59, 27, 2, 317, 0)
    # 1226527167.0
    # 1226498367
    
def username(infile):
    #Open settings file and find username/mailaddress
    # <setting id="user">xxxxxxxx</setting> ### Kodi 18!
    LF = open(infile, 'r')
    input = LF.read()
    marker = '<setting id="user">'
    markerend = '</setting>'
    user=''
    if marker in input and user == '':
        user = input.split(marker)[1].split(markerend)[0]
    # Close our file
    LF.close()
    return user

def folder(infile):
    #Open settings file and find recording folder
    LF = open(infile, 'r')
    input = LF.read()
    marker = '<setting id="record_display_path" value="'  ### NOT Kodi 18!
    markerend = '" />'
    user=''
    if marker in input and user == '':
        user = input.split(marker)[1].split(markerend)[0]
    # Close our file
    LF.close()
    return user
    
def versiondate():
    #Open addon.xml file and find version and date
    infile = os.path.join(ADDON.getAddonInfo('path'), 'addon.xml')
    LF = open(infile, 'r')
    input = LF.read()
    marker = 'Version Date'
    markerend = '</description>'
    user=''
    if marker in input and user == '':
        user = input.split(marker)[1].split(markerend)[0]
    # Close our file
    LF.close()
    return user
    
def version():
    #Open addon.xml file and find version info
    infile = os.path.join(ADDON.getAddonInfo('path'), 'addon.xml')  
    log('Path to addon.xml' + infile)     
    LF = open(infile, 'r')
    input = LF.read()
    marker = '<addon id='
    markerend = '>'
    user=''
    if marker in input and user == '':
        user = input.split(marker)[1].split(markerend)[0]
    # Close our file
    LF.close()
    return user
    


