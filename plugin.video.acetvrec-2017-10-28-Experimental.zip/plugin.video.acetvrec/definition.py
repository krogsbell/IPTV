#!/usr/bin/python
# -*- coding: utf-8 -*-

# 0= NTV.mx, 1= WOZBOX www.wozboxtv.com, 2=www.myindian.tv, 3=www.wliptv.com, 4=roq-tv.com, 5=www.ace-tv.co.uk
# Copy the addon folder to the name of the id to copy addon to, update addon.xml and add the jpg and png icons to be used with the addon then make a zip file and install from zip!

referral= 6           ##########################<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

import xbmcaddon,xbmc

if referral==0:
	ADDON = xbmcaddon.Addon(id='plugin.video.ntv')
	BASEURL = 'http://www.ntv.mx'
	REGISTRATION = 'http://ntv.mx/?r=Kodi&c=2&a=0&p=9'
	
elif referral==1:
	ADDON = xbmcaddon.Addon(id='plugin.video.wozboxntv')
	BASEURL = 'http://www.ntv.mx'
	REGISTRATION = 'wozboxtv.com/registration'
	
elif referral==2:
	ADDON = xbmcaddon.Addon(id='plugin.video.myindian')
	BASEURL = 'http://www.myindian.tv'
	REGISTRATION = 'http://www.myindian.tv'
	
elif referral==3:
	ADDON = xbmcaddon.Addon(id='plugin.video.wliptv')
	BASEURL = 'http://www.wliptv.com'
	REGISTRATION = 'http://www.wliptv.com'
	
elif referral==4:
	ADDON = xbmcaddon.Addon(id='plugin.video.roqtvrec')
	BASEURL = 'http://roq-tv.net:25461'
	REGISTRATION = 'http://roq-tv.com'

elif referral==5:
	ADDON = xbmcaddon.Addon(id='plugin.video.acetvrec')
	BASEURL = 'http://ace-tv.xyz:25461'
	REGISTRATION = 'http://www.ace-tv.co.uk'

elif referral==6:
	ADDON = xbmcaddon.Addon(id='plugin.video.acetvrec')
	###BASEURL = 'http://ace-tv.xyz:25461'
	BASEURL = 'http://ace.nothingtosee.xyz:8080'   ### TEST 2017-11-23
	REGISTRATION = 'http://www.ace-tv.co.uk'

else:
	ADDON = xbmcaddon.Addon(id='plugin.video.wozboxntv')
	BASEURL = 'http://www.ntv.mx'
	REGISTRATION = 'wozboxtv.com/registration'

ADDON.setSetting('my_referral_link',str(referral))
###xbmc.log('definition.py in %s with referral= %s' % (ADDON.getAddonInfo('id'), repr(referral)))

def getADDON():
	return ADDON

def getBASEURL():
	return BASEURL	
	
def getREGISTRATION():
	return REGISTRATION	
