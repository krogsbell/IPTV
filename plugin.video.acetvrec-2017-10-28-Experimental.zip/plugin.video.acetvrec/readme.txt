An enhanced version of the original NTV.mx addon including version 3.4.9 and comes in flavors: NTV, White Label, My Indian TV and WozboxNTV.
It shows icons of most channels
Recording is controlled via a database and there are views to control recording
Every time the addon is started it creates the ftvntv-krogsbell.ini file with your channels to use in integration with TV Guides.
You can select different TV Guides and any program you mark in the TV Guide will be set for recording by the addon - no strange settinge - just select your TV Guide (compatible with the original Tommy Winther TV Guide) and keep it updated.
You can make recursive recordings from the addon - then on an hourly basis your TV Guide is searched for programs with the text in the program title. Recursive programs found will be marked as notified.
You can controll the TV Guide with an SQL file - example is supplied.
Recording with RTMPDUMP or FFMPEG on all platforms including Android. If FFMPEG folder is missing in your installation, you can find it at the Google Drive link below.
This version generates a m3u file to use with PVR IPTV Simple Client.
Take a look in the changelog.txt to see how things are working.
Regards Hans 

Google Drive link:
https://drive.google.com/folderview?id=0B-3Zxd-YAuoofmYyVHQ0cE9xeTJyTnd0NEZNSVJqZkpibGhZTzF2M1gzOUZxeDdMM2dUbDQ&usp=sharing

Dropbox links (previous versions):
https://www.dropbox.com/s/495vv3ugoi6k3jl/plugin.video.ntv-5.0.20-2016-03-21-1.zip?dl=0
https://www.dropbox.com/s/3hf2su9joz8o5kd/plugin.video.myindian-1.0.20-2016-03-21-1.zip?dl=0
https://www.dropbox.com/s/w4halhwvwzt0950/plugin.video.wliptv-1.0.20-2016-03-21-1.zip?dl=0

Addon to use Raytec EPG (Kode 3025)
https://www.dropbox.com/s/bofr1e8usmfig8m/service.rytecepgdownloader-0.7.0-2016-04-15-14.zip?dl=0
Or JinJins original/updated (service.rytecepgdownloader-16.5.9.zip 2016-05-10)
https://www.dropbox.com/sh/d98stl4i7gtu94q/AADwfdNtpEHbLNsbjozswotca
