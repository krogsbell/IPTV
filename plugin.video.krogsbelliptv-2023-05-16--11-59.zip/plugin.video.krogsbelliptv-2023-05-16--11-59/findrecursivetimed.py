#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import definition
ADDON      = definition.getADDON()
module     = 'findrecursivetimed.py'
import urllib,sys,re,os
import datetime
import time
import utils
import net
from hashlib import md5  
import json
import recordings, glob
import findrecursive
import locking

utils.logdev(module,'Start')

def deleteFile(file):
    tries    = 0
    maxTries = 10
    while os.path.exists(file) and tries < maxTries:
        try:
            os.remove(file)
            break
        except:
            xbmc.sleep(50)
            tries = tries + 1

if not locking.isAnyRecordLocked(): 
	findrecursive.RecursiveRecordingsPlanned('Timed')
	#xbmc.executebuiltin("Container.Refresh")

	lockDescription = '*Stop Recording*.flv'
	recordingLock = os.path.join(utils.ADDONgetSetting('record_path'),lockDescription)
	LockFiles = glob.glob(recordingLock)
	# delete lock files
	for file in LockFiles:
		deleteFile(file)
