#!/usr/bin/python
# -*- coding: utf-8 -*-
import recordings, utils, locking
import xbmcaddon, xbmc, datetime, os

import definition
ADDON      = definition.getADDON()
ADDONname  = utils.ADDONgetAddonInfo('name')
xbmc.log('service.py in %s' % utils.ADDONgetAddonInfo('name'))
module= 'service.py'

def log(infotext,showlength=500):
    debug = utils.ADDONgetSetting('debug').lower()
    if debug in infotext.lower() and not debug == '':
        utils.logdev('error',module + ': ' + infotext,showlength=showlength)
    else:
        nolog = True
        
utils.logdevreset()
log('err Start')
log('err Version= %r' % utils.version())    
log('err VersionDate= %r' % utils.versiondate())

try:
    utils.deleteset()
    ###reload(sys)  
    ###sys.setdefaultencoding('utf8')
    log('err defaultencoding= %r' % sys.getdefaultencoding())
    Platform = utils.rtmpdumpFilename()
    if not Platform == '':
        utils.notification('[COLOR green]Platform found and set[/COLOR]')
except:
    pass
    log('err FindPlatform FAILED')  # Put in LOG
    
log('err 34')
locking.recordUnlockAll()
log('err 36')
locking.scanUnlockAll()
log('err 38')
locking.markUnlockAll()
log('err 40')
recordings.backupSetupxml()
log('err 42')
recordings.restoreLastSetupXml()
log('err 44')
###utils.logdevreset()
recordings.cleanTempFiles()
recordings.ftvntvlist()  ### also made after EPG Update
log('err 48')
recordings.setAlarm('http-keep-alive-once','http-keep-alive.py','once','00:00:00','silent')
recordings.setAlarm('http-keep-alive-loop','http-keep-alive.py','loop','00:05:30','loop,silent')
###nameAlarmKeep = ADDONname +'http-keep-alive-once' 
###scriptKeep   = os.path.join(utils.ADDONgetAddonInfo('path'), 'http-keep-alive.py')
###cmdKeep = 'AlarmClock(%s,RunScript(%s,%s),00:00:00,silent)' % (nameAlarmKeep, scriptKeep, 'once')
###xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmKeep)
###xbmc.executebuiltin(cmdKeep)  # Active
log('err 41')
###recordings.downloadicons()
utils.ADDONsetSetting('allmessages','')
utils.ADDONsetSetting('RecursiveSearch','false')
utils.ADDONsetSetting('RecordingFromOtherAddon','0')
utils.ADDONsetSetting('Recordings','')   ### Reset setting with recording names
utils.ADDONsetSetting('castsubpr','')    ### Reset cast info
utils.ADDONsetSetting('castsubprcmd','')
log('err 49')
if utils.ADDONgetSetting('enable_record')=='true':
    now = recordings.parseDate(datetime.datetime.now()) 
    startDate=now - datetime.timedelta(days = 10)
    endDate=now + datetime.timedelta(days = 100)
    recordingsActive=recordings.getRecordingsActive(startDate, endDate)
    log('err recordingsActive ' + repr(recordingsActive))
    log('err 56')
    try:
        recordings.backupDataBase()
        recordings.reschedule()
        utils.notification('[COLOR green]Reschedule Complete[/COLOR]')
        utils.ADDONsetSetting('DebugRecording','false')
        log('err 62')
    except:
        pass
        utils.notification('[COLOR red]Reschedule failed:[/COLOR] Check your planned recordings! - Recording Debug has been set')
        utils.ADDONsetSetting('DebugRecording','true')
        log('err 67')
        xbmc.sleep(5000)

