#!/usr/bin/env python
# -*- coding: utf-8 -*-
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import time
import os
try:
    from os import statvfs
except:
    pass
import xbmc
import xbmcgui
import xbmcaddon
import utils
import shutil
import re
import net
import locking
import json
import urllib
import glob
import urllib2

from sqlite3 import dbapi2 as sqlite3
from operator import itemgetter

"""
To run plugin use : xbmc.executebuiltin('RunPlugin("plugin.video.something")')
To run script use : xbmc.executebuiltin('RunAddon("script.something")')
cmd = 'AlarmClock(%s,RunScript(%s,%s),%d,True)' % (nameAlarm, script, args, timeToRecording/60)

RunAddon(id)	Runs the specified plugin/script	
RunAppleScript(script[,args]*)	Run the specified AppleScript command	
RunPlugin(plugin)	Runs the plugin. Full path must be specified. Does not work for folder plugins	
RunScript(script[,args]*)	Runs the python script. You must specify the full path to the script. One way to specify the full path is through the special protocol. If the script is an add-on, you can also execute it using its add-on id. As of 2007/02/24, all extra parameters are passed to the script as arguments and can be accessed by python using sys.argv

playlist = playlist.create_playlist( ( self.settings[ "music_path" ], ), self.settings[ "shuffle" ] )
        xbmc.Player().play( playlist )
        xbmc.executebuiltin( "RunScript(%s)" % os.path.join( os.getcwd(), "default.py" ) )

start_exec='XBMC.RunPlugin(%s)' % ('%s?action=%s&url=%s&ind=%s&storage=%s') % (
                     sys.argv[0], 'downloadLibtorrent', urllib.quote_plus(torrent.encode('utf-8')), str(ind), storage)
            xbmc.executebuiltin(start_exec)
            xbmc.executebuiltin('Container.Refresh')        

xbmc.executebuiltin("RunScript(script.extendedinfo,info=youtubebrowser)")


"""

RECORDS_DB  = 'recordings_adc.db'
CHANNEL_DB  = 'channels.db'
EPG_DB      = 'master.db'
SETTINGSXML = 'settings.xml'
#ADDON      = xbmcaddon.Addon(id='plugin.video.wozboxntv')
import definition
ADDON       = definition.getADDON()
ADDONid     = ADDON.getAddonInfo('id')
ADDONname   = ADDON.getAddonInfo('name')
xbmc.log('recordings.py in %s' % ADDONname)
datapath    = xbmc.translatePath(ADDON.getAddonInfo('profile'))
progpath    = ADDON.getAddonInfo('path')
module      = 'recordings.py'
origin = ADDONid +' available_channels'
RECURSIVEMARKER = 'Recursive:'

"""
def adapt_datetime(ts):
    try:
        ### TypeError is raised unless the comparison is == or !=
        if ts is None:
            return None
        return time.mktime(ts.timetuple())
    except Exception, e:
            pass
            utils.logdev('adapt_datetime(ts) FAILED 1', 'ts= %r ERROR= %r' % (ts,e))
            return None
def convert_datetime(ts):
        try:
            ### TypeError is raised unless the comparison is == or !=
            if ts is None:
                return None
            return datetime.fromtimestamp(float(ts))
        except Exception, e:
            pass
            utils.logdev('convert_datetime(ts) FAILED 1', 'ts= %r ERROR= %r' % (ts,e))
            return None

def convert_datetimeORIGINAL(ts):
        try:
            return datetime.fromtimestamp(float(ts))
        except ValueError:

            return None
               
# http://docs.python.org/2/library/sqlite3.html#registering-an-adapter-callable
###sqlite3.register_adapter(datetime, adapt_datetime)
sqlite3.register_adapter(datetime, adapt_datetime)
sqlite3.register_converter('timestamp', convert_datetime)
"""
def SelectSetupxmlFiles():
    path = xbmc.translatePath(ADDON.getAddonInfo('profile'))
    files =  glob.glob(os.path.join(path, '*'))
    defaultfile = os.path.join(path, SETTINGSXML)
    files1 = sorted(files, reverse=True)
    activeDB = SETTINGSXML.split('.')[0]+ ' - ' + utils.username(defaultfile) 
    index = 0
    contextMenu = []
    contextFile = []
    
    for infile in files1:
        if index < 50:
            index += 1
            try:
                if infile[-4:].lower()=='.xml':
                    mail = utils.username(infile)
                    folder = utils.folder(defaultfile)
                    name = infile.replace(path,'').replace('.xml','') + ' - ' + mail + ': ' + folder
                
                    ###if '@' in mail: 
                    contextMenu.append(name)
                    contextFile.append(infile)
            except:
                pass
    if len(contextMenu) == 0:
        xbmcaddon.Addon(id=ADDONid).openSettings()
    else:
        SelectedChannel = xbmcgui.Dialog().select('Select a setupxml file', contextMenu)
        if SelectedChannel <> -1:
            ADDON.setSetting('fixsetup','true')
            try:
                id = contextFile[SelectedChannel]
                utils.notification('Seletced setupxml: ' + repr(id))
                ### copy file
                shutil.copyfile(id, defaultfile)
                xbmc.executebuiltin("XBMC.Container.Update(path,replace)")  ### Exit AddOn after setup.xml update
                xbmc.executebuiltin("XBMC.ActivateWindow(Home)")
            except:
                pass
                ADDON.setSetting('fixsetup','false')
            
def TestHDD(path):
    try:
        st = os.statvfs(path)

        if st.f_frsize:
            freespace = st.f_frsize * st.f_bavail/1024/1024/1024
        else:
            freespace = st.f_bsize * st.f_bavail/1024/1024/1024

        utils.logdev(module,"Free Space: %dGB"%(freespace))
        if(freespace < 3):
            text = "You have less than 3GB of free space on your Record Path"
            text1 = path
            text2 = "Free up some space!"
            utils.notification('[COLOR red]Less than 3GB of free space on[/COLOR] \n'+path)
            ###xbmcgui.Dialog().ok(ADDONname, text, text1, text2)
    except Exception, e:
            pass
            utils.logdev(module,'Error in get TestHDD path= %r \nError: %r' %(path,e))
    """
    if Platform.system == 'android': 
-            # http://stackoverflow.com/questions/1749928/replacement-for-python-statvfs#comment42443537_1749950
-            # https://github.com/Diblo/KODI-Popcorn-Time/issues/68
-            return 16106127360 # 15 GB
+            if hasattr(os, 'statvfs'):
+                st = os.statvfs(download_path)
+                return st.f_bavail * st.f_frsize
+            else:
+                import commands, b2h
+                return b2h.human2bytes(commands.getoutput('df %s' % download_path).split('\n')[1].split()[3])
         if Platform.system == 'windows':
             free_bytes = ctypes.c_ulonglong(0)
             ctypes.windll.kernel32.GetDiskFreeSpaceExW(ctypes.c_wchar_p(self.mediaSettings.download_path), None, None, ctypes.pointer(free_bytes))
© 2017 GitH
    """
    ###while not xbmc.abortRequested:    
    ###    xbmc.sleep(500)          

recordPath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_path')))
utils.logdev(module,'recordPath= %s' %recordPath)
TestHDD(recordPath)
if ADDON.getSetting('enable_record')=='true' and not utils.folderwritable(recordPath):
    ###utils.notification('Recording not possible [COLOR red]You must set the recording path writable![/COLOR] \nGoto Settings/Recording/Record Path and set that to a writable path')
    utils.logdev(module,'You must set the recording path writable!')
    if not ADDON.getSetting('fixsetup') == 'true':  ### Only run setup once
        if ADDON.getSetting('user') == '':
            SelectSetupxmlFiles()
            if ADDON.getSetting('user') == '':
                xbmcaddon.Addon(id=ADDONid).openSettings()
        else:
            xbmcaddon.Addon(id=ADDONid).openSettings() 
"""
recordPath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_path')))
utils.logdev(module,'recordPath= %s' %recordPath)
if ADDON.getSetting('enable_record')=='true' and not utils.folderwritable(recordPath):
    ###utils.notification('Recording not possible [COLOR red]You must set the recording path writable![/COLOR] \nGoto Settings/Recording/Record Path and set that to a writable path')
    utils.logdev(module,'You must set the recording path writable! ')
    xbmcaddon.Addon(id=ADDONid).openSettings()
"""
def downloadicons():
    utils.logdevreset()
    return    #### REMOVE TO DOWNLOAD ALL ICONS AGAIN TO DATA FOLDER ####

    iconsfolder = os.path.join(datapath,'icons')
    if os.path.exists(iconsfolder) == False:
        os.makedirs(iconsfolder)    
    c = getIconConnection().cursor()
    ### c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (title, source))") ###
    c.execute("SELECT * FROM channels")
    logos = c.fetchall()
    ###utils.logdev('downloadicons','size= ' + repr(len(logos)))
    for logo in logos:
        logoid= logo[0]
        title= logo[1]
        logolink= logo[2]
        ###utils.logdev('downloadicons','id= ' + repr(logoid) + ' title= ' + repr(title) + ' logolink= ' + repr(logolink))
        logofilename= os.path.join(datapath,'icons',logoid) + '.png'
        ###utils.logdev('downloadicons','logofilename= ' + repr(logofilename))
        try:
            iconfile = urllib2.urlopen(logolink)
            with open(logofilename,'wb') as output:
                output.write(iconfile.read())
        except:
            pass
            ###utils.logdev('downloadicons','FAILED id= ' + repr(logoid) + ' title= ' + repr(title) + ' logolink= ' + repr(logolink))
    c.close()

def getIcon(title,cat):
    return IconFromCat(cat)
    """
    if ADDON.getSetting('geticonfromweb') == 'true':
        return getIconFromWeb(title,cat)
    else:
        logofilename= os.path.join(progpath,'resources','logo',cat) + '.png'
        if os.path.isfile(logofilename) == True:
            ### ###utils.logdev('getIcon','logofilename= ' + repr(logofilename))
            return logofilename
        else:
            ###utils.logdev('getIcon FAILED','logofilename= ' + repr(logofilename))
            return logofilename
"""

"""
ROQ TV - M3U Playlist URL
'http://roq-tv.net:25461/get.php?username=xxxx&password=xxxx&type=m3u_plus&output=ts'
definition.getBASEURL() + '/get.php?username=xxxx&password=xxxx&type=m3u_plus&output=ts'

ROQ TV - EPG url
http://roq-tv.net:25461/xmltv.php?username=xxxx&password=xxxx

You can access the online viewing platform here: 
http://roq-tv.net:25461/client_area/index.php?username=xxxx&password=xxxx
with or without username and password

"""




def ftvntvlist():
# Create a FTVNTV.INI file with all channels from ROQ TV
## This file contains the "built-in" channels
## It is parsed by Pythons ConfigParser
#
#[plugin.video.ntv]
#* * * * * *  NEW NTV CHANNELS 2015-05-01 * * * * * * *=
#24 Techno=plugin://plugin.video.ntv/?url=url&mode=200&name=24+Techno+-+%5BCOLOR+yellow%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fwww.ntv.mx%2Fres%2Fcontent%2Ftv%2F179.png&cat=179
#2x2=plugin://plugin.video.ntv/?url=url&mode=200&name=2x2+-+%5BCOLOR+yellow%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fwww.ntv.mx%2Fres%2Fcontent%2Ftv%2F177.png&cat=177
#5 Star=plugin://plugin.video.ntv/?url=url&mode=200&name=5+Star+-+%5BCOLOR+yellow%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fwww.ntv.mx%2Fres%2Fcontent%2Ftv%2F86.png&cat=86
#5 USA=plugin://plugin.video.ntv/?url=url&mode=200&name=5+USA+-+%5BCOLOR+yellow%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fwww.ntv.mx%2Fres%2Fcontent%2Ftv%2F64.png&cat=64
    channellist = os.path.join(datapath,'channels') + '.csv'
    ftvntvini = os.path.join(datapath,'ftv'+ADDONname) + '.ini'
    ntvchannelsm3u = os.path.join(datapath,'roqtvchannels') + '.m3u'
    ###utils.logdev('ftvntvlist','ftvroqtv= %s for %s' % (repr(os.path.isfile(ftvntvini)), repr(ftvntvini)))
    if os.path.isfile(channellist) == True: 
        ###utils.logdev('ftvntvlist','channellist exists - deleting')
        locking.deleteLockFile(channellist)
    if os.path.isfile(ftvntvini) == True: 
        ftvntviniOLD = os.path.join(datapath,'ftv'+ADDONname+'OLD') + '.ini'
        shutil.copyfile(ftvntvini, ftvntviniOLD)
        locking.deleteLockFile(ftvntvini)
    if os.path.isfile(ntvchannelsm3u) == True: 
        ###utils.logdev('ntvchannelsm3u','ntvchannelsm3u exists - deleting')
        locking.deleteLockFile(ntvchannelsm3u)
    if os.path.isfile(ftvntvini) == False:
        now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        # create file
        ###utils.logdev('ftvntvlist','ftvroqtv.ini beeing created ' + now)
        LF = open(ftvntvini, 'a')
        # Write to our text file the information we have provided and then goto next line in our file.
        LF.write('# This file contains the TV channels for your Package\n')
        LF.write('# Created by ' + ADDON.getAddonInfo('name') +' at ' + now + '\n')
        LF.write('[' + ADDON.getAddonInfo('id') + ']\n')
        LF.write('\n')
        ftvntvinifile = ftvntvini.replace(datapath,'')
        try:
            CHANNELlist(LF)
            utils.notification('[COLOR green]'+ftvntvinifile+' created[/COLOR]')
        except Exception, e:
            pass
            utils.logdev('ftvntvlist','Error in get CHANNELlist: ' + repr(e))
            utils.notification('[COLOR red]Access to %s channel list is not available[CR]%s NOT generated![/COLOR]' % (ADDONname,ftvntvinifile) )
            ###utils.notificationbox('[COLOR red]Check your internet connection![/COLOR][CR][CR][COLOR green]Access to %s channel list is not available[CR]ftvroqtv.ini NOT generated![/COLOR]' % ADDON.getAddonInfo('name') )
        LF.write('\n')
        now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        LF.write('# End of ' + ADDONname + ' channels - ended at ' + now + '\n')
        # Close our file so no further writing is posible.
        LF.close()
        
        ftvntvini = os.path.join(datapath,'Channels '+ADDONname) + '.txt'
        LF = open(ftvntvini, 'w')
        # Write to our text file the information we have provided and then goto next line in our file.
        LF.write('# This file contains the TV channels for your Package\n')
        LF.write('# Created by ' + ADDON.getAddonInfo('name') +' at ' + now + '\n')
        LF.write('[' + ADDON.getAddonInfo('id') + ']\n')
        LF.write('\n')
        ftvntvinifile = ftvntvini.replace(datapath,'')
        try:
            CHANNELDisplaylist(LF)
            utils.notification('[COLOR green]'+ftvntvinifile+' created[/COLOR]')
        except Exception, e:
            pass
            utils.logdev('ftvntvlist','Error in get CHANNELlist: ' + repr(e))
            utils.notification('[COLOR red]Access to %s channel list is not available[CR]%s NOT generated![/COLOR]' % (ADDONname,ftvntvinifile) )
            ###utils.notificationbox('[COLOR red]Check your internet connection![/COLOR][CR][CR][COLOR green]Access to %s channel list is not available[CR]ftvroqtv.ini NOT generated![/COLOR]' % ADDON.getAddonInfo('name') )
        LF.write('\n')
        now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        LF.write('# End of ' + ADDONname + ' channels - ended at ' + now + '\n')
        # Close our file so no further writing is posible.
        LF.close()
        
        

def CHANNELlist(LF):   ### ROQ TV
    nowDate= datetime.today().strftime('%Y-%m-%d')
    ###utils.logdev('CHANNELlist','LF= ' + repr(LF))
    LF.write('# My ' + ADDON.getAddonInfo('name') + ' Channels\n')
    LF.write(' \n \n \n*** My ' + ADDON.getAddonInfo('name') + ' Live Channels at ' + nowDate + ' ***********************=\n')
    ### channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER)
    ### channels = []
    channels = getAllChannelsList()
    channels = sorted(channels, key=itemgetter(1))
    for field in channels:
        cat          = field[0]
        name         = field[1]
        url          = field[2]
        if url != 'url' and 'live' in url.lower():
            line=name + '=' + url
            LF.write(line + '\n')
    
    LF.write(' \n \n \n*** My ' + ADDON.getAddonInfo('name') + ' Videos at ' + nowDate + ' ***********************=\n')
    for field in channels:

        cat          = field[0]
        name         = field[1]
        url          = field[2]
        
        if url != 'url' and not 'live' in url.lower():
            line=name + '=' + url
            LF.write(line + '\n')
    
def CHANNELDisplaylist(LF):   ### ROQ TV
    nowDate= datetime.today().strftime('%Y-%m-%d')
    ###utils.logdev('CHANNELlist','LF= ' + repr(LF))
    LF.write('# My ' + ADDON.getAddonInfo('name') + ' Channels\n')
    LF.write(' \n \n \n*** My ' + ADDON.getAddonInfo('name') + ' Live Channels at ' + nowDate + ' ***********************=\n')
    ### channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER)
    ### channels = []
    channels = getAllChannelsList()
    channels = sorted(channels, key=itemgetter(1))
    i = 0
    for field in channels:
        cat          = field[0]
        name         = field[1]
        url          = field[2]
        if url != 'url' and 'live' in url.lower() and not ' (D)' in name:
            i += 1
            line=format(i, '04d') + ' ' + name
            LF.write(line + '\n')
    
    LF.write(' \n \n \n*** My ' + ADDON.getAddonInfo('name') + ' Videos at ' + nowDate + ' ***********************=\n')
    i = 0
    for field in channels:

        cat          = field[0]
        name         = field[1]
        url          = field[2]
        
        if url != 'url' and not 'live' in url.lower() and not ' (D)' in name:
            i += 1
            line=format(i, '04d') + ' ' + name
            LF.write(line + '\n')
    

def CHANNELlistNTV(LF):
    #cat = '16' # NTV Ultimate
    #cat = '-2' # My Channels
    #cat = '-1' # My Favorites
    #cat = '10' # Indian Tv
    #cat = '15' # Scandinavian
    #cat = '12' # DK + UK ?
    #cats = ['-2','-1','0','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30']
    nowDate= datetime.today().strftime('%Y-%m-%d')
    if referralLink() == '1':
        cats = ['-2','-1','16']
    if referralLink() == '2':
        cats = ['10']
    if referralLink() == '3':
        cats = ['-2','10','20','25']
    if not referralLink() == '1' and not referralLink() == '2' and not referralLink() == '3'  :
        cats = ['-2','-1','16']
    for cat in cats:
        if cat == '-2':
            LF.write('# cat= ' + cat + ' My ' + ADDON.getAddonInfo('name') + ' Channels\n')
            LF.write('*** My ' + ADDON.getAddonInfo('name') + ' Channels at ' + nowDate + ' ***********************=\n')
        elif cat == '-1':
            LF.write('# cat= ' + cat + ' My Favorites ' + ADDON.getAddonInfo('name') + ' Channels\n')
            LF.write('*** My Favorites ' + ADDON.getAddonInfo('name') + ' Channels at ' + nowDate + ' ***********************=\n')
        elif cat == '16':
            LF.write('# cat= ' + cat + ' ' + ADDON.getAddonInfo('name') + ' Ultimate Channels\n')
            LF.write('*** ' + ADDON.getAddonInfo('name') + ' Ultimate Channels at ' + nowDate + ' ***********************=\n')
        else:
            LF.write('# cat= ' + cat + '\n')
            LF.write('*** ' + ADDON.getAddonInfo('name') + ' Channels #' + cat + ' at ' + nowDate + ' ***********************=\n')
        """
        from hashlib import md5
        streamtype = ADDON.getSetting('streamtype')
        if streamtype == '0':
            STREAMTYPE = 'NTV-XBMC-HLS-'
        elif streamtype == '1':
            STREAMTYPE = 'NTV-XBMC-'
        site=definition.getBASEURL() + '/index.php?' + referral()+ 'c=6&a=0'
        datapath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
        cookie_path = os.path.join(datapath, 'cookies')
        cookie_jar = os.path.join(cookie_path, "ntv.lwp")
        UA=STREAMTYPE + ADDON.getAddonInfo('version') 
        #print  "UA=STREAMTYPE + ADDON.getAddonInfo('version')= " + str(repr(UA))
        netX=net.Net()
        loginurl = definition.getBASEURL() + '/index.php?' + referral() + 'c=3&a=4'
        username    =ADDON.getSetting('user')
        password =md5(ADDON.getSetting('pass')).hexdigest()

        data     = {'email': username,
                                                'psw2': password,
                                                'rmbme': 'on'}
        headers  = {'Host':definition.getBASEURL().replace('http://',''),
                                                'Origin':definition.getBASEURL() + '',
                                                'Referer':definition.getBASEURL() + '/index.php?' + referral() + 'c=3&a=0','User-Agent' : UA}

        html = netX.http_POST(loginurl, data, headers).content
        if 'success' in html:
            if os.path.exists(cookie_path) == False:
                os.makedirs(cookie_path)
            netX.save_cookies(cookie_jar)


        #print 'default.py CHANNELS(name= %s, cat= %s)' % (repr(name),repr(cat))
        netX.set_cookies(cookie_jar)
        imageUrl=definition.getBASEURL() + '/res/content/tv/'
        now= datetime.today().strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20')
        url='&mwAction=category&xbmc=1&mwData={"id":"%s","time":"%s","type":"tv"}'%(cat,now)
        #print 'default.py YYYY site+url= %s%s'  % (site,url)
        link = netX.http_GET(site+url, headers={'User-Agent' : UA}).content
        """
        ### ROQ TV TEST
        ###link = net.http_GET('http://roq-tv.net:25461/get.php?username=XXX&password=XXXX&type=m3u_plus&output=ts').contents
        
        ###utils.logdev(module, 'ROQ TV TEST link= %s ERROR= %s' % (link))
        
        
        #print 'default.py YYYY Channels link= %s' % str(repr(link))
        data = json.loads(link)
        channels=data['contents']
        #print 'default.py cat= %s, CHANNELS= %s' % (cat,str(repr(channels)))
        offset= int(data['offset'])
        channels = sorted(channels, key=itemgetter('name'))
        BASE=data['base_url']
        utils.logdev('CHANNELlist','cat= %s with BASE= %s' % (cat, repr(BASE)))
        utils.logdev('CHANNELlist','imageUrl= %s' % repr(imageUrl))
        for field in channels:
            #iconimage=BASE+field['icon']
            endTime      =  field['time_to']
            name         =  field['name'].encode("utf-8")
            channel      =  field['id']
            whatsup      =  field['whatsup'].encode("utf-8")
            description  =  field['descr'].encode("utf-8")
            iconimage = getIcon(name,channel)   ##############################################################################################
            if referralLink() == '-1':   ### 2016-05-04 don't show (record)/(view) for wozbox any more
                line=name + ' (record)=plugin://' + ADDON.getAddonInfo('id') + '/?url=url&mode=2009&name=' + urllib.quote_plus(name) + '+-+%5BCOLOR+red%5Dn+a%5B%2FCOLOR%5D&iconimage=' + urllib.quote_plus(iconimage) + '&cat=' + channel 
                LF.write(line + '\n')
                line=name + ' (view)=plugin://' + ADDON.getAddonInfo('id') + '/?url=url&mode=200&name=' + urllib.quote_plus(name) + '+-+%5BCOLOR+green%5Dn+a%5B%2FCOLOR%5D&iconimage=' + urllib.quote_plus(iconimage) + '&cat=' + channel 
            if not referralLink() == '-1':
                line=name + ' =plugin://' + ADDON.getAddonInfo('id') + '/?url=url&mode=200&name=' + urllib.quote_plus(name) + '+-+' + urllib.quote_plus(name) + '&iconimage=' + urllib.quote_plus(iconimage) + '&cat=' + channel 
            LF.write(line + '\n')

def referralLink():
    # 0= NTV, 1= WOZBOX www.wozboxtv.com
    referralLink=ADDON.getSetting('my_referral_link')
    return referralLink

def referral():
    #site=definition.getBASEURL() + '/index.php?c=6&a=0'
    #referralLink=ADDON.getSetting('my_referral_link')
    #if referralLink == '1':
    #   referral = 'r=wb&'
    #else:
    referral = ''
    #referralsite='http://www.ntv.mx/index.php?' + referral+ 'c=6&a=0'
    return referral

def parseDate(dateString):
    x = 'start'
    ###utils.logdev(module,'parseDate(dateString= %r) = %r' %(dateString,x))
    try:
        dateString = int(dateString)
        x = datetime.fromtimestamp(time.mktime(dateString))
        return x
    except:
        pass
    try:
        dateString = dateString.split('.')[0]  ### 2017-09-20 02:37:26.143149 ==> 2017-09-20 02:37:26
    except:
        pass
    if type(dateString) == datetime:

        ###utils.logdev(module,'Already dateString= %r' %(dateString))
        return dateString
    try:
        #dateString = '2050-01-01 00:00:00'
        time_tuple = datetime.strptime(dateString, "%Y-%m-%d %H:%M:%S")
        #time_tuple = time.strptime(dateString, "%Y-%m-%d %H:%M:%S")
        x = datetime(*time_tuple[0:6])
        ###utils.logdev(module,'parseDate(dateString= %r) = %r' %(dateString,x))
        return x
    except:
        pass
    try:
        if isinstance(dateString, datetime.date):
            time_tuple = dateString.timetuple()
            x = datetime(*time_tuple[0:6])
            ###utils.logdev(module,'parseDate(dateString= %r) = %r' %(dateString,x))
            return x
    except:
        pass
    try:
        x = dateString.replace('%20', ' ')
        dateString = x
        ###utils.logdev(module,'parseDate(dateString= %r) = %r' %(dateString,x))
    except:
        pass
    try:
        x = datetime.fromtimestamp(time.mktime(time.strptime(dateString.encode('utf-8', 'replace'), "%Y-%m-%d")))
        ###utils.logdev(module,'parseDate(dateString= %r) = %r' %(dateString,x))
        return x
    except:
        pass
        #print 'parseDate default date failed'
    try:
        x = datetime.fromtimestamp(time.mktime(time.strptime(dateString.encode('utf-8', 'replace'), "%Y-%m-%d %H:%M:%S")))
        ###utils.logdev(module,'parseDate(dateString= %r) = %r' %(dateString,x))
        return x
    except:
        pass
        
    try:
        time_tuple = time.strptime(dateString, "%Y-%m-%d %H:%M:%S")
        dt_obj = datetime(*time_tuple[0:6])
        ###utils.logdev(module,'parseDate(dateString= %r) = %r' %(dateString,dt_obj))
        return dt_obj
    except:
        pass
    try:
        x = datetime.fromtimestamp(time.mktime(time.strptime(dateString.encode('utf-8', 'replace'), "%Y-%m-%d %H:%M:%S")))
        ###utils.logdev(module,'parseDate(dateString= %r) = %r' %(dateString,x))
        return x
    except:
        pass
    try:
        date_str = safe_str(dateString)
        time_tuple = time.strptime(date_str, "%Y-%m-%d %H:%M:%S")
        x = datetime(*time_tuple[0:6])
        ###utils.logdev(module,'parseDate(dateString= %r) = %r' %(dateString,x))
        return x
    except:
        pass
    try:
        xint = float(dateString)
        x = datetime.fromtimestamp(xint)
        ###utils.logdev(module,'parseDate(dateString= %r) = %r' %(dateString,x))
        return x
    except:
        pass
    x = datetime.today()  + timedelta(days = 100) # ERROR RETURN
    utils.logdev(module,'parseDate FAILED returning some time in the future + 100 days: parseDate(dateString= %r) ==> %r' %(dateString,x))
    return x 

def backupSetupxml():
    try:
        dbPath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
        if not os.path.exists(dbPath):
            os.mkdir(dbPath)        
        timestampnow = datetime.now()
        timestampnowS = str(datetime.now()).split('.')[0].replace('-','').replace(' ','').replace(':','') + '-'
        backupSrc = os.path.join(dbPath, SETTINGSXML)
        backupDst = os.path.join(dbPath, timestampnowS + SETTINGSXML)
        shutil.copyfile(backupSrc, backupDst)
    except:
        pass
        utils.logdev('backupSetupxml','recordings.py backup SETTINGSXML Failed!')  # Put in LOG
    
def restoreSetupXml(backupSrc):
    try:
        utils.notification('[COLOR green]Restoring %s[/COLOR]' % SETTINGSXML,time=1000)
        backupSetupxml()
        dbPath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
        if not os.path.exists(dbPath):
            os.mkdir(dbPath)
        backupDst = os.path.join(dbPath, SETTINGSXML)
        #print 'restoreBackupDataBase from backupSrc= %s to backupDst= %s' % (backupSrc,backupDst)
        #os.remove(backupDst)
        deleteFile(backupDst)
        shutil.copyfile(backupSrc, backupDst)
        #reschedule()
        utils.notification('[COLOR green]Restoring %s Finished![/COLOR]' % SETTINGSXML)
    except:
        pass
        utils.notification('[COLOR red]Restoring %s FAILED![/COLOR]' % SETTINGSXML)

def restoreLastSetupXml():
    #utils.notification('[COLOR green]Restoring %s[/COLOR]' % SETTINGSXML,time=1000)
    path = xbmc.translatePath(ADDON.getAddonInfo('profile'))
    files =  glob.glob(os.path.join(path, '*.xml'))
    defaultfile = os.path.join(path, SETTINGSXML)
    files1 = sorted(files, reverse=True)
    storedusers = []
    index = 0
    restored = False
    for infile in files1:
        mail = utils.username(infile)
        firstmailoccurance = True
        for xmail in storedusers:   ######
            if xmail == mail:
                firstmailoccurance = False
        if firstmailoccurance:
            storedusers.append(mail)
            utils.logdev('Storedusers',repr(storedusers))
            
        if index < 20:
            try:
                index += 1
                mail = utils.username(infile)
                if restored == False and not infile == defaultfile and not mail == '': 
                    deleteFile(defaultfile)
                    shutil.copyfile(infile, defaultfile)
                    #utils.notification('[COLOR green]Restoring %s Finished![/COLOR]' % SETTINGSXML)
                    restored = True
            except:
                pass
                utils.notification('[COLOR red]Restoring %s FAILED![/COLOR]' % SETTINGSXML)
        else:
            try:
                if restored == True:
                    index += 1
                    if not infile == defaultfile and not firstmailoccurance: 
                        deleteFile(infile)
            except:
                pass
                utils.notification('[COLOR red]Restoring %s cleanup FAILED![/COLOR]' % SETTINGSXML)
    return restored
        
def backupDataBase():
    try:
        dbPath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
        if not os.path.exists(dbPath):
            os.mkdir(dbPath)
        backupSrc = os.path.join(dbPath, RECORDS_DB)
        timestampnow = datetime.now()
        timestampnowS = str(datetime.now()).split('.')[0].replace('-','').replace(' ','').replace(':','') + '-'
        usernamed = ADDON.getSetting('user') + '-'
        backupDst = os.path.join(dbPath, timestampnowS + usernamed + RECORDS_DB)
        utils.logdev(module,'backupDst= %r' % backupDst)
        shutil.copyfile(backupSrc, backupDst)
    except:
        pass
        utils.logdev(module,'recordings.py backupDataBase Failed!')  # Put in LOG
    
    path = xbmc.translatePath(ADDON.getAddonInfo('profile'))
    files =  glob.glob(os.path.join(path, '*.db'))
    defaultfile = os.path.join(path, RECORDS_DB)
    files1 = sorted(files, reverse=True)
    index = 0
    for infile in files1:
        if index < 20:
            try:
                index += 1
            except:
                pass
                utils.notification('[COLOR red]Restoring %s cleanup FAILED![/COLOR]' % RECORDS_DB)
        else:
            try:
                index += 1
                if not infile == defaultfile: 
                    deleteFile(infile)
            except:
                pass
                utils.notification('[COLOR red]Restoring %s cleanup FAILED![/COLOR]' % RECORDS_DB)

def deleteDataBase():
    try:
        utils.notification('[COLOR green]Delete Database[/COLOR]',time=100000)
        backupDataBase()
        delAllPlannedPrograms()
        dbPath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
        if not os.path.exists(dbPath):
            os.mkdir(dbPath)
        backupDst = os.path.join(dbPath, RECORDS_DB)
        deleteFile(backupDst)
        utils.notification('[COLOR green]Delete Database Finished![/COLOR]')
    except Exception, e:
        pass
        utils.logdev(module,'Error in deleteDataBase: ' + repr(e))
        utils.notification('[COLOR red]Delete Database FAILED![/COLOR]')

def restoreBackupDataBase(backupSrc):
    try:
        utils.notification('[COLOR green]Restoring Database[/COLOR]',time=100000)
        backupDataBase()
        delAllPlannedPrograms()
        dbPath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
        if not os.path.exists(dbPath):
            os.mkdir(dbPath)
        backupDst = os.path.join(dbPath, RECORDS_DB)
        #print 'restoreBackupDataBase from backupSrc= %s to backupDst= %s' % (backupSrc,backupDst)
        #os.remove(backupDst)
        deleteFile(backupDst)
        shutil.copyfile(backupSrc, backupDst)
        reschedule()
        utils.notification('[COLOR green]Restoring Database Finished![/COLOR]')
    except:
        pass
        utils.notification('[COLOR red]Restoring Database FAILED![/COLOR]')
        utils.logdev('restoreBackupDataBase','recordings.py backupDataBase Failed!')

def restoreRecursiveRecordings(url):
    try:
        utils.notification('[COLOR green]Restoring Recursive Records[/COLOR]',time=100000)
        utils.logdev('restoreRecursiveRecordings','Restoring Recursive Records url= ' + repr(url))
        restorecount = RecursiveRecordings(url)
        utils.notification('[COLOR green]Restoring Recursive Records Finished![/COLOR] %s records restored' % repr(restorecount))
    except Exception, e:
        pass
        utils.logdev('restoreRecursiveRecordings','error in Restoring Recursive Records: ' + repr(e))
        utils.notification('[COLOR red]Restoring Recursive Records FAILED![/COLOR] ' + repr(restorecount) + ' records restored: ' + repr(e))

def RecursiveRecordings(dbPath):
    RECURSIVEMARKER = 'Recursive:'
    restorecount = 0
    recur = getDatabaseConnection(dbPath)
    conn = getConnection()
    d = conn.cursor()
    c = recur.cursor()
    c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE '%Recursive:%' COLLATE NOCASE")  # Find all recursive recordings
    recordingsE = c.fetchall()
    # Put recursive recordings changed last - first
    reC = sorted(recordingsE, key=itemgetter(2), reverse=True)
    
    for i in range(0, len(reC)):
        utils.logdev('RecursiveRecordings','Recursive Records: ' + repr(i) + '= ' + repr(reC[i][1].replace(RECURSIVEMARKER,'')))
        d.execute("SELECT DISTINCT cat, name FROM recordings_adc WHERE cat=? and name=? COLLATE NOCASE", [reC[i][0],reC[i][1]])
        recExists = d.fetchall()
        if len(recExists) < 1:
            ### Log which records that restore to find out why they don't stay on reschedule
            ###utils.logdev('RecursiveRecordingsRestore','Add Recursive Record: ' + repr(i) + '= ' + repr(reC[i][0]) + ', '+repr(reC[i][1]) + ', '+repr(reC[i][2]) + ', '+repr(reC[i][3]) + ', '+repr(reC[i][4]) + ', '+repr(reC[i][5]))
            d.execute("INSERT OR REPLACE INTO recordings_adc(cat, name, start, end, alarmname, description, playchannel) VALUES(?, ?, ?, ?, ?, ?, ?)", reC[i]) ## insert recursive
            restorecount += 1
            utils.logdev('RecursiveRecordings','Add Recursive Record: ' + repr(i) + '= ' + repr(reC[i][1].replace(RECURSIVEMARKER,'')))
    recur.commit()
    conn.commit()
    c.close()
    d.close()
    return restorecount
"""
def setEPGChannel(cat,channel):  ### Code Copy... 2017-09-04
    try:
        utils.logdev(module,'setEPGChannel(cat)')
        conn = recordings.getConnection()
        c = conn.cursor()
        c.execute("SELECT * FROM channels WHERE id=?", [cat])
        favorites = c.fetchall()
        result = []

        for index in range(0, len(favorites)):
            ch = []
            for i in range(0, len(favorites[index])):
                if favorites[index][i] == None:
                    ch.append('')
                else:
                    ch.append(favorites[index][i])
            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [ch[0], ch[1], ch[2], ch[3], ch[4], ch[5], ch[6], ch[7], ch[8], channel,ch[10],ch[11],ch[12]])
        if result == []:
            utils.logdev(module,'EPG not found for cat= %r' % cat)

        conn.commit()
        c.close() 
    except Exception, e:
        pass
        utils.notification('Error in setEPGChannel(cat) '+ cat + ' \n' + repr(e))
"""     
def RestoreOldChannels(dbPath):
    restorecount = 0
    recur = getDatabaseConnection(dbPath)
    conn = getConnection()
    d = conn.cursor()
    c = recur.cursor()
    c.execute("SELECT * FROM channels")  # Find all channels
    favorites = c.fetchall()
    for index in range(0, len(favorites)):
        ch = []
        ###for i in range(0, len(favorites[index])):
        for i in range(0, 12):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        d.execute("SELECT DISTINCT id, source FROM channels WHERE id=? and source=? COLLATE NOCASE", [ch[0],ch[4]])
        recExists = d.fetchall()
        if len(recExists) < 1:
            d.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [ch[0], ch[1], ch[2], ch[3], ch[4], ch[5], ch[6], ch[7], ch[8], ch[9],ch[10],ch[11],ch[12]])
            restorecount += 1
    recur.commit()
    conn.commit()
    c.close()
    d.close()
    return restorecount

def RestoreOldEPG(dbPath):
    restorecount = 0
    recur = getDatabaseConnection(dbPath)
    conn = getConnection()
    d = conn.cursor()
    c = recur.cursor()
    c.execute("SELECT * FROM programs")  # Find all old programs
    favorites = c.fetchall()
    for index in range(0, len(favorites)):
        ch = []
        ###for i in range(0, len(favorites[index])):
        for i in range(0, 15):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        ###utils.logdev('RestoreOldEPG',str(len(ch)))
        d.execute("SELECT DISTINCT channel, start_date, end_date FROM programs WHERE channel=? and start_date=? and end_date=? COLLATE NOCASE", [ch[0],ch[3],ch[4]])
        recExists = d.fetchall()
        if len(recExists) < 1:
            ###utils.logdev('RestoreOldEPG',repr(ch))
            d.execute("INSERT OR REPLACE INTO programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source, updates_id) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [ch[0], ch[1], ch[2], ch[3], ch[4], ch[5], ch[6], ch[7], ch[8], ch[9],ch[10],ch[11],ch[12],ch[13],ch[14]])
            restorecount += 1
    recur.commit()
    conn.commit()
    c.close()
    d.close()
    return restorecount

def RecursiveRecordingsCount(dbPath):
    try:
        RECURSIVEMARKER = 'Recursive:'
        recur = getDatabaseConnection(dbPath)
        c = recur.cursor()
        c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE '%Recursive:%' COLLATE NOCASE")  # Find all recursive recordings
        recrecordings = c.fetchall()
        c.execute("SELECT * FROM recordings_adc")
        recordings = c.fetchall()
        recur.commit()
        c.close()
        plrecordings = len(recordings) - len(recrecordings)
        return ' (P' + str(plrecordings) +'/R' + str(len(recrecordings)) + ')'
    except Exception, e:
        pass
        utils.logdev('RecursiveRecordingsCount','error in RecursiveRecordingsCount: ' + repr(e))
        utils.notification('[COLOR red]RecursiveRecordingsCount FAILED![/COLOR]: ' + repr(e))
        return '-'

def stopAllRecordings():
    recordings = getRecordings()
    #print len(recordings)
    #print recordings
    for index in range(0, len(recordings)): 
        cat       = recordings[index][0]
        name      = recordings[index][1]
        startDate = recordings[index][2]
        endDate   = recordings[index][3]
        try:
            delRecordingPlanned(cat, startDate, endDate, name)
            #print 'delRecordingPlanned(index= %s, cat= %s, startDate= %s, endDate= %s, name= %s)' %(str(repr(index)),str(repr(cat)), str(repr(startDate)), str(repr(endDate)), str(repr(name)))
        except:
            pass
            utils.logdev('stopAllRecordings','delRecordingPlanned FAILED(index= %s, cat= %s, startDate= %s, endDate= %s, name= %s)' %(str(repr(index)),str(repr(cat)), str(repr(startDate)), str(repr(endDate)), str(repr(name))))  # Put in LOG

def deleteFile(file):
    tries    = 0
    maxTries = 10
    while os.path.exists(file) and tries < maxTries:
        try:
            os.remove(file)
            break
        except:
            xbmc.sleep(500)
            tries = tries + 1

def FindPlatformMoved():
    # Find the actual platform
    Platform = ''
    try:
        kodilog = xbmc.translatePath(os.path.join('special://logpath' , 'kodi.log'))
        #print kodilog
        try: logfile = open(kodilog,'r')
        except:
            pass
            kodilog = xbmc.translatePath(os.path.join('special://logpath' , 'xbmc.log'))
            #print kodilog
            try: logfile = open(kodilog,'r')
            except:
                pass
                kodilog = xbmc.translatePath(os.path.join('special://logpath' , 'tvmc.log'))
                #print kodilog
                logfile = open(kodilog,'r')
        #print kodilog
        #print repr(logfile)
        line0 = logfile.readline()
        #print line0
        line1 = logfile.readline()
        #print line1
        line2 = logfile.readline()
        #print line2
        line3 = logfile.readline()
        #print line3
        line4 = logfile.readline()
        #print line4
        line5 = logfile.readline()
        #print line5
        line6 = logfile.readline()
        #print line6
        line7 = logfile.readline()
        #print line7
        Platform = line2.split('Platform:')[1].strip()
        #print Platform
        ADDON.setSetting('platform',Platform)
        RunningOn = line5.split('Running on ')[1].split(' ')[0].strip()
        #print 'RunningOn: %s' % repr(RunningOn) 
        ADDON.setSetting('runningon',RunningOn)
        utils.logdev('FindPlatformMoved','RunningOn: %s' % repr(ADDON.getSetting('runningon')))   # Put in LOG
        #print os.environ
        utils.logdev('FindPlatformMoved',os.environ['OS'])  # Put in LOG
    except: 
        pass
        utils.logdev('FindPlatformMoved','recordings.py FindPlatform FAILED')   # Put in LOG
    finally:
        logfile.close()
    return Platform

def getConnection():    
    dbPath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
    if not os.path.exists(dbPath):
        os.mkdir(dbPath)

    conn   = sqlite3.connect(os.path.join(dbPath, RECORDS_DB), timeout = 20, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    createTable(conn)
    return conn

def getEPGConnection():    
    dbPath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
    if not os.path.exists(dbPath):
        os.mkdir(dbPath)
    conn   = sqlite3.connect(os.path.join(dbPath, EPG_DB), timeout = 20, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    createTable(conn)
    return conn

def createEPGchannelsTable(conn):
    c = conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, favorite BOLEAN, catchup BOLEAN, epg_channel TEXT, description TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (title, source))")  ### 201-09-17
    c.execute("CREATE TABLE IF NOT EXISTS channelsRecursive(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, favorite BOLEAN, catchup BOLEAN, epg_channel TEXT, description TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (title, source))")
    conn.commit()
    c.close()

def createEPGNotificationTable(conn):
    c = conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS CREATE TABLE notifications(channel TEXT, program_title TEXT, source TEXT, start_date INTEGER, type TEXT)")
    conn.commit()
    c.close()

def createEPGProgramsTable(conn):
    c = conn.cursor()
    ###c.execute("CREATE TABLE IF NOT EXISTS programs(channel TEXT, title TEXT, sub_title TEXT, start_date TIMESTAMP, end_date TIMESTAMP, description TEXT, categories TEXT, image_large TEXT, image_small TEXT, season TEXT, episode TEXT, is_movie TEXT, language TEXT, source TEXT, updates_id INTEGER, UNIQUE (channel, start_date, end_date))")
    c.execute("CREATE TABLE IF NOT EXISTS programs(channel TEXT, title TEXT, sub_title TEXT, start_date INTEGER, end_date INTEGER, description TEXT, categories TEXT, image_large TEXT, image_small TEXT, season TEXT, episode TEXT, is_movie TEXT, language TEXT, source TEXT, updates_id INTEGER, UNIQUE (channel, start_date, end_date))")
    conn.commit()
    c.close()

def getDatabaseConnection(dbPath):    
    conn   = sqlite3.connect(dbPath, timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    createTable(conn)
    return conn

def getIconConnection():    
    dbPath = os.path.join(xbmc.translatePath(ADDON.getAddonInfo('path')),'resources')
    #xbmc.log('recordings.py: getIconConnection dbPath= %s' % repr(dbPath))
    if not os.path.exists(dbPath):
        os.mkdir(dbPath)
    conn   = sqlite3.connect(os.path.join(dbPath, CHANNEL_DB), timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    createIconTable(conn)
    return conn

""" WOZBOX TVGUIDE 2.0
CREATE TABLE channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, lineup TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)

CREATE TABLE notifications(channel TEXT, program_title TEXT, source TEXT, start_date TIMESTAMP, type TEXT, FOREIGN KEY(channel, source) REFERENCES channels(id, source) ON DELETE CASCADE)

CREATE TABLE programs(channel TEXT, title TEXT, sub_title TEXT, start_date INTEGER, end_date INTEGER, description TEXT, categories TEXT, image_large TEXT, image_small TEXT, season TEXT, episode TEXT, is_movie TEXT, language TEXT, source TEXT, updates_id INTEGER, UNIQUE (channel, start_date, end_date), FOREIGN KEY(channel, source) REFERENCES channels(id, source) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED, FOREIGN KEY(updates_id) REFERENCES updates(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)
"""
def createWozboxTVguidechannelsTable(conn):
    c = conn.cursor()
    ###c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, lineup TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
    c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, lineup TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, source))")
    conn.commit()
    c.close()

def createWozboxTVguideNotificationTable(conn):
    c = conn.cursor()
    ###c.execute("CREATE TABLE IF NOT EXISTS CREATE TABLE notifications(channel TEXT, program_title TEXT, source TEXT, start_date INTEGER, type TEXT, FOREIGN KEY(channel, source) REFERENCES channels(id, source) ON DELETE CASCADE)") ### 2017-08-14
    c.execute("CREATE TABLE IF NOT EXISTS CREATE TABLE notifications(channel TEXT, program_title TEXT, source TEXT, start_date INTEGER, type TEXT)")
    conn.commit()
    c.close()

def createWozboxTVguideProgramsTable(conn):
    c = conn.cursor()
    ###c.execute("CREATE TABLE IF NOT EXISTS programs(channel TEXT, title TEXT, sub_title TEXT, start_date TIMESTAMP, end_date TIMESTAMP, description TEXT, categories TEXT, image_large TEXT, image_small TEXT, season TEXT, episode TEXT, is_movie TEXT, language TEXT, source TEXT, updates_id INTEGER, UNIQUE (channel, start_date, end_date), FOREIGN KEY(channel, source) REFERENCES channels(id, source) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED, FOREIGN KEY(updates_id) REFERENCES updates(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
    c.execute("CREATE TABLE IF NOT EXISTS programs(channel TEXT, title TEXT, sub_title TEXT, start_date INTEGER, end_date INTEGER, description TEXT, categories TEXT, image_large TEXT, image_small TEXT, season TEXT, episode TEXT, is_movie TEXT, language TEXT, source TEXT, updates_id INTEGER, UNIQUE (channel, start_date, end_date))")
    conn.commit()
    c.close()

def createTableORG(conn):
    c = conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS recordings_adc (cat TEXT, name TEXT, start TEXT, end TEXT, alarmname TEXT, description TEXT, playchannel TEXT, PRIMARY KEY (cat,name,start,end))")
    conn.commit()
    c.close()

def createTable(conn):   ###WozboxTVguidechannels
    try:
        c = conn.cursor()
        c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, favorite BOLEAN, catchup BOLEAN, epg_channel TEXT, description TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (title, source))")
        c.execute("CREATE TABLE IF NOT EXISTS channelsRecursive(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, favorite BOLEAN, catchup BOLEAN, epg_channel TEXT, description TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (title, source))")
        c.execute("CREATE TABLE IF NOT EXISTS recordings_adc (cat TEXT, name TEXT, start TEXT, end TEXT, alarmname TEXT, description TEXT, playchannel TEXT, PRIMARY KEY (cat,name,start,end))")
        conn.commit()
        c.close()
    except Exception, e:
        pass
        utils.logdev(module, 'createTable(conn) failed! \nERROR= %r' % (e))

def createIconTable(conn):
    try:
        c = conn.cursor()
        ##c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT NOT NULL, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (title), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)") ### 2016-05-15
        c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, favorite BOLEAN, catchup BOLEAN, epg_channel TEXT, description TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (title, source))")
        conn.commit()
        c.close()
    except Exception, e:
        pass
        utils.logdev(module, 'createIconTable(conn) failed! \nERROR= %r' % (e))

def addChannel(name,url,iconimage,cat,origin,visible=1,weight=1000,epg_channel='',description=''):
    ###utils.logdev(module+'-addChannel','name= %s,url= %s,iconimage= %s,cat= %s,origin= %s' % (name,url,iconimage,cat,origin))
    ### add to channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER)
    now = datetime.now()
    nowTS = int(time.mktime(now.timetuple()))
    nowTSold =    nowTS - 31536000    ### 365 * 24 * 60 * 60  now-timedelta(days=365)
    now = parseDate(datetime.now())  ### 2017-09-30
    cat = cat.strip()
    name = name.strip()
    if name != '':
        try:
            conn = getConnection()
            c = conn.cursor()
            c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])  ### 2017-08-26
            ###c.execute("SELECT * FROM channels WHERE id=?", [cat])
            channels = c.fetchall()
            ###utils.logdevarray(module+'-addChannel',channels)
            if len(channels) > 0:
                for chan in channels:
                    ###utils.logdevarray(module+'-addChannel',chan)
                    c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, name, iconimage, url, origin, chan[5], chan[6], chan[7], chan[8], chan[9], chan[10], nowTS, chan[12]])
            else:
                c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, name, iconimage, url, origin, visible, weight, '', '',epg_channel, description,nowTS,nowTSold])    
            ###c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite) VALUES(?, ?, ?, ?, ?, ?, ?)", [cat, name, iconimage, url, origin, 'True', '0'])
        
            conn.commit()
        except:
            pass
        c.close()
### recordings.addEPGChannel(c,stream_id,name,url,stream_icon,epg_channel_id,EPGgenerator)  
def addEPGChannel(c,cid,name,url,iconimage,cat,origin,visible=1,weight=0,epg_channel='',description=''):
    ###utils.logdev(module+'-addChannel','name= %s,url= %s,iconimage= %s,cat= %s,origin= %s' % (name,url,iconimage,cat,origin))
    ### add to channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER)
    now = datetime.now()
    nowTS = int(time.mktime(now.timetuple()))
    nowTSold =    nowTS - 31536000    ### 365 * 24 * 60 * 60  now-timedelta(days=365)
    if cid == '' or cid == None:
        return
    try:
        cid = cid.strip()
    except:
        pass
    try:
        name = name.strip()
    except:
        pass
    ###conn = getConnection()
    ###c = conn.cursor()
    try:
        ###c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, description) VALUES(?, ?, ?, ?, ?, ?)", [cid, name, iconimage, url, origin, cat])
        c.execute("SELECT * FROM channels WHERE id=?", [cid])
        channels = c.fetchall()
        ###utils.logdevarray(module+'-addChannel',channels)
        if len(channels) > 0:
            for chan in channels:
                ###utils.logdevarray(module+'-addChannel',chan)
                if chan[9] != '':
                    epg_channel = chan[9]
                c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cid, name, iconimage, url, origin, chan[5], chan[6], chan[7], chan[8], epg_channel, description, nowTS, chan[12]])  ### 2018-02-13 description <== chan[10]
        else:
            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cid, name, iconimage, url, origin, visible, weight, '', '', epg_channel, description, nowTS, nowTSold])
    except Exception, e:
        pass
        ###ADDON.setSetting('KeyErrorStop',repr(e))
        utils.logdev(module,'ChannelId= %r' % cid)
        utils.logdev(module, 'c.execute("INSERT OR REPLACE INTO channels(id= %r, title= %r, logo= %r, stream_url= %r, source= %r, description= %r, now= %r) failed! \nERROR= %r' % (cid, name, iconimage, url, origin, description, now, e))
    ###conn.commit()
    ###c.close()

###c.execute("CREATE TABLE IF NOT EXISTS programs(channel TEXT, title TEXT, sub_title TEXT, start_date TIMESTAMP, end_date TIMESTAMP, description TEXT, categories TEXT, image_large TEXT, image_small TEXT, season TEXT, episode TEXT, is_movie TEXT, language TEXT, source TEXT, updates_id INTEGER, UNIQUE (channel, start_date, end_date))")    

def addEPGProgram(c, prog, channel, title, sub_title, start_date, end_date, description='', categories='', image_large='', image_small='', season= '', episode='', is_movie='', language='', source=''):
    ###utils.logdev(module+'-addChannel','name= %s,url= %s,iconimage= %s,cat= %s,origin= %s' % (name,url,iconimage,cat,origin))
    ### add to channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER)
    ###channel = channel.strip()
    ###title = title.strip()
    ###conn = getConnection()
    ###c = conn.cursor()
    try:
        c.execute("INSERT OR REPLACE INTO programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source])
    except Exception, e:
        pass
        ###ADDON.setSetting('KeyErrorStop',repr(e))
        utils.logdev(module,'Programdict= %r' % prog)
        utils.logdev(module, 'c.execute("INSERT OR REPLACE INTO programs(channel= %r, title= %r, sub_title= %r, start_date= %r, end_date= %r, description= %r, categories= %r, image_large= %r, image_small= %r, season= %r, episode= %r, is_movie= %r, language= %r, source= %r) failed! \nERROR= %r' % (channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source, e))
    
    ###conn.commit()
    ###c.close()
    
def getEPGPrograms(channel):
    ###utils.logdev(module,'getEPGPrograms: channel= %r' % channel)
    conn = getConnection()
    c = conn.cursor()
    ###programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
    try:
        ###c.execute("SELECT * FROM programs WHERE channel=?", [channel])
        c.execute("SELECT DISTINCT title, description, source, start_date, end_date  FROM programs WHERE channel=? COLLATE NOCASE", [channel])
        programs = c.fetchall()
        programs = sorted(programs, key=itemgetter('start_date')) ### Sort by startdate
    except Exception, e:
        pass
        utils.logdev(module, 'c.execute(SELECT DISTINCT title, description, start_date, end_date, source FROM programs WHERE channel=?, [channel]) failed! \nERROR= %r' % e)
        programs = []
    c.close()
    ###utils.logdevarray(module+' TEST',programs)
    return programs

def getEPGProgramsNow(channel):
    ###now= datetime.today()
    ###nowplus = now + timedelta(hours = 2)
    now = datetime.now()
    nowTS = int(time.mktime(now.timetuple()))
    nowTSplus =    nowTS + 7200    ### 2 * 60 * 60  now-timedelta(hours=2)
    ###utils.logdev(module,'now= datetime.today(%r) nowplus = %r' % (nowTS,nowTSplus))
    conn = getConnection()
    c = conn.cursor()
    ###programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
    ###c.execute("SELECT * FROM programs WHERE channel=?", [channel])
    try:
        channel = channel.replace(' (R)','')   ### 2017-07-27
        c.execute("SELECT DISTINCT title, description, source, start_date, end_date  FROM programs WHERE channel=? and start_date < ? and end_date > ? COLLATE NOCASE", [channel,nowTSplus,nowTS])
        ###c.execute("SELECT DISTINCT title, description, source, start_date, end_date  FROM programs WHERE channel=? and start_date < ? and end_date > ? COLLATE NOCASE", [channel,nowplus,now])
        programs = c.fetchall()
        programs = sorted(programs, key=itemgetter('start_date')) ### Sort by startdate
    except Exception, e:
        pass
        utils.logdev(module, 'c.execute(SELECT DISTINCT title, description, start_date, end_date, source FROM programs WHERE channel=?and start_date < ? and end_date > ? , [channel]) failed! \nERROR= %r' % e)
        programs = []
    c.close()
    return programs

def delEPGProgram(channel, start_date, end_date):
    utils.logdev(module, 'delEPGProgram(channel= %r, start_date= %r, end_date= %r)'% (channel, start_date, end_date))
    success = False
    conn = getConnection()
    c = conn.cursor()
    ###programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
    c.execute("SELECT * FROM programs WHERE channel=? AND start_date=? AND end_date=?", [channel, start_date, end_date])
    favorites = c.fetchall()
    utils.logdev(module, 'delEPGProgram favorites= %r, len(favorites)= %r' % (favorites, len(favorites)))
    if len(favorites) == 1:
        c.execute("DELETE FROM programs WHERE channel=? AND start_date=? AND end_date=?", [channel, start_date, end_date])
        conn.commit()
        utils.logdev(module, 'delEPGProgram Succeded')
        success = True
    c.close()
    return success

    
def delOldEPGPrograms():
    utils.logdev(module, 'Start to delete old programs and channels - cutoffdate')
    conn = getConnection()
    c = conn.cursor()
    ###programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
    ###c.execute("SELECT * FROM programs WHERE channel=?", [channel])
    try:
        ###time_tuple = dt_obj.timetuple()
        ###timestamp = time.mktime(time_tuple)
        ###datetime.fromtimestamp(timestamp)
        cutoffdate = (datetime.today() - timedelta(days = 7)).timetuple()
        utils.logdev(module,'Programs: cutoffdate(tuple)= %r' % cutoffdate)
        cutoffdate = time.mktime(cutoffdate)
        utils.logdev(module,'Programs: cutoffdate(timestamp)= %r' % cutoffdate)
        ###c4.execute("DELETE FROM recordings_adc WHERE alarmname=? and end=?",  [alarmname,endDate])
        c.execute("DELETE FROM programs WHERE end_date<? ", [cutoffdate])
        c.execute("DELETE FROM programsForHumans WHERE end_date<? ", [cutoffdate])   ### 2017-09-18
        cutoffdate = (datetime.today() - timedelta(days = 2)).timetuple()
        utils.logdev(module,'Channels: cutoffdate(tuple)= %r' % cutoffdate)
        cutoffdate = time.mktime(cutoffdate)
        utils.logdev(module,'Channels: cutoffdate(timestamp)= %r' % cutoffdate)
        ###c4.execute("DELETE FROM recordings_adc WHERE alarmname=? and end=?",  [alarmname,endDate])
        c.execute("DELETE FROM channels WHERE updated<? ", [cutoffdate])
    except Exception, e:
        pass
        utils.logdev(module, 'c.execute(DELETE FROM programs, programsForHumans or channels WHERE end_date or updated<? , [cutoffdate]= %r) failed! \nERROR= %r' % (cutoffdate,e))
    conn.commit()
    c.close()
    return

def delNewEPGPrograms():   ### If to many programs have changed - update full afterwards
    utils.logdev(module, 'Start to delete new programs - cutoffdate')
    conn = getConnection()
    c = conn.cursor()
    ###programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
    ###c.execute("SELECT * FROM programs WHERE channel=?", [channel])
    try:
        ###time_tuple = dt_obj.timetuple()
        ###timestamp = time.mktime(time_tuple)
        ###datetime.fromtimestamp(timestamp)
        cutoffdate = datetime.today().timetuple()   ### now
        utils.logdev(module,'Programs: cutoffdate(tuple)= %r' % cutoffdate)
        cutoffdate = time.mktime(cutoffdate)
        utils.logdev(module,'Programs: cutoffdate(timestamp)= %r' % cutoffdate)
        ###c4.execute("DELETE FROM recordings_adc WHERE alarmname=? and end=?",  [alarmname,endDate])
        c.execute("DELETE FROM programs WHERE end_date>? ", [cutoffdate])
    except Exception, e:
        pass
        utils.logdev(module, 'c.execute(DELETE FROM programs WHERE start_date or updated<? , [cutoffdate]= %r) failed! \nERROR= %r' % (cutoffdate,e))
    conn.commit()
    c.close()
    return

def RestoreChannels(url):
    ###try:
        utils.notification('[COLOR green]Restoring Channels[/COLOR]',time=100000)
        utils.logdev('restoreRecursiveRecordings','Restoring Channels url= ' + repr(url))
        restorecount = RestoreOldChannels(url)
        utils.notification('[COLOR green]Restoring Channels Finished![/COLOR] %s records restored' % repr(restorecount))
    ###except Exception, e:
    ### pass
    ### utils.logdev('RestoreChannels','error in Restoring Channels: ' + repr(e))
    ### utils.notification('[COLOR red]Restoring Channels FAILED![/COLOR] ' + repr(restorecount) + ' records restored: ' + repr(e))
        
def RestoreEPG(url):
    ###try:
        utils.notification('[COLOR green]Restoring EPG[/COLOR]',time=100000)
        utils.logdev('restoreRecursiveRecordings','Restoring EPG url= ' + repr(url))
        restorecount = RestoreOldEPG(url)
        utils.notification('[COLOR green]Restoring EPG Finished![/COLOR] %s records restored' % repr(restorecount))
    ###except Exception, e:
    ### pass
    ### utils.logdev('RestoreEPG','error in Restoring EPG: ' + repr(e))
    ### utils.notification('[COLOR red]Restoring EPG FAILED![/COLOR] ' + repr(restorecount) + ' records restored: ' + repr(e))
         
def delAllChannels():   ### If user have changed - update full afterwards
    utils.logdev(module, 'Start to delete all channels')
    conn = getConnection()
    c = conn.cursor()
    ###programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
    ###c.execute("SELECT * FROM programs WHERE channel=?", [channel])
    try:
        c.execute("DELETE FROM channels")
    except Exception, e:
        pass
        utils.logdev(module, 'c.execute(DELETE FROM channels) failed! \nERROR= %r' % (e))
    conn.commit()
    c.close()
    return

def delAllPlannedPrograms():   ### If recursive have made too many recordings - Stop all recordings and clear parts of database
    utils.logdev(module, 'Start to delete all recordings')
    conn = getConnection()
    c = conn.cursor()
    ###programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
    ###c.execute("SELECT * FROM programs WHERE channel=?", [channel])
    try:
        c.execute("SELECT DISTINCT alarmname FROM recordings_adc")
        favorites = c.fetchall()
        for nameAlarm in favorites:
            try:
                xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
            except:
                pass
        c.execute("DELETE FROM recordings_adc")
    except Exception, e:
        pass
        utils.logdev(module, 'c.execute(DELETE FROM recordings_adc) failed! \nERROR= %r' % (e))
    conn.commit()
    c.close()
    return

def delAllProgramsForHumans():   ### Programs for Humans not used any more
    utils.logdev(module, 'Start to delete all Programs for Humans')
    conn = getConnection()
    c = conn.cursor()
    try:
        c.execute("DELETE FROM programsForHumans")
    except Exception, e:
        pass
        utils.logdev(module, 'c.execute(DELETE FROM programsForHumans) failed! \nERROR= %r' % (e))
    conn.commit()
    c.close()
    return
    
def setChannelCatchup(c,cat,catchup):
    ###utils.logdev(module+'-setChannelCatchup','cat= %r' % (cat))
    if cat == '' or cat == None:
        return
    try:
        cat = cat.strip()
    except:
        pass
    ###conn = getConnection()
    ###c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE id=?", [cat])
    favorites = c.fetchall()
    ###utils.logdevarray(module+'-setChannelCatchup',favorites)
    for chan in favorites:
        c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], catchup, chan[9], chan[10], chan[11], chan[12]])
    ###conn.commit()
    ###c.close()

def getChannelDescription(cat):
    ###utils.logdev(module+'-getChannelDescription','cat= %r' % (cat))
    if cat == '' or cat == None:
        return ''
    try:
        cat = cat.strip()
    except:
        pass
    conn = getConnection()
    c = conn.cursor()
    c.execute("SELECT DISTINCT description FROM channels WHERE id=?", [cat])
    favorites = c.fetchall()
    des = ''
    for chan in favorites:
        if chan[0] != None:
            des += chan[0]
    c.close()
    return des

def setChannelDescription(cat,description):
    ###utils.logdev(module+'-setChannelDescription','cat= %r' % (cat))
    if cat == '' or cat == None:
        return
    try:
        cat = cat.strip()
    except:
        pass
    conn = getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE id=?", [cat])
    favorites = c.fetchall()
    ###utils.logdevarray(module+'-setChannelDescription',favorites)
    for chan in favorites:
        c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9], description, chan[11], chan[12]])
    conn.commit()
    c.close()

def getChannelFav(c,cat):
    ###utils.logdev(module+'-getChannelFav','cat= %r' % (cat))
    if cat == '' or cat == None:
        return
    try:
        cat = cat.strip()
    except:
        pass    
    c.execute("SELECT DISTINCT favorite FROM channels WHERE id=? and source=?", [cat,origin])  ### 2017-09-28
    favorites = c.fetchall()
    if len(favorites) > 0:
        try:
            fav = favorites[0][0]
        except Exception, e:
            pass
            utils.logdev(module, 'c.execute(SELECT DISTINCT favorite FROM channels WHERE id=%r, [cat]) failed! \nERROR= %r' % (cat,e))
            fav = 'False'
    else:
        fav = 'False'
    return fav

def setChannelAdded(c,cat,added):
    if cat == '' or cat == None:
        return
    try:
        cat = cat.strip()
    except:
        pass    
    c.execute("SELECT * FROM channels WHERE id=?", [cat])
    favorites = c.fetchall()
    for chan in favorites:
        c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9], chan[10], chan[11], added])
    
def setChannelFav(c,cat,fav):
    ###utils.logdev(module+'-setChannelFav','cat= %r, fav= %r' % (cat,fav))
    if cat == '' or cat == None or fav == '' or fav == None:
        return
    try:
        cat = cat.strip()
    except:
        pass    
    ###c.execute("SELECT * FROM channels WHERE id=?", [cat])
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])  ### 2017-08-26
    favorites = c.fetchall()
    for chan in favorites:
        ###utils.logdev(module,"INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite= %r ==> %r, catchup, description) " % ( chan[7],fav))
        if fav != '' and fav != None and fav.lower() == 'true':  ###2017-09-14
        ###if fav.lower() == 'true':
            ###utils.logdev(module+'-setChannelFav','cat= %r, fav= %r from oldfav= %r' % (cat,fav,chan[7]))
            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], 'True', chan[8], chan[9], chan[10], chan[11], chan[12]])
            ###utils.logdev(module,'3. ChannelFav= %r, stream_id= %r' % (fav, cat))
        else:
            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], 'False', chan[8], chan[9], chan[10], chan[11], chan[12]])
            ###utils.logdev(module,'4. ChannelFav= %r, stream_id= %r' % (fav, cat))
    
def addChannelFav(cat):
    utils.logdev(module+'-addChannelFav','cat= %r' % (cat))
    if cat == '' or cat == None:
        return
    try:
        cat = cat.strip()
    except:
        pass
    conn = getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])
    ###c.execute("SELECT DISTINCT title, favorite FROM channels WHERE id=?", [cat])
    favorites = c.fetchall()
    ###utils.logdevarray(module+'-addChannelFav',favorites)
    for chan in favorites:
        ###utils.logdev(module,'INSERT OR REPLACE INTO channels(id= %r, title= %r, favorite= %r)' % (cat, chan[0], chan[1]))
        ### c.execute("INSERT OR REPLACE INTO channels(id, title, favorite) VALUES(?, ?, ?)", [cat, chan[0], 'True'])
        ### utils.logdev(module,'INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) [cat= %r, chan[1]= %r, chan[2]= %r, chan[3]= %r, chan[4]= %r, chan[5]= %r, chan[6]= %r, True= %r, chan[8]= %r, chan[9]= %r, chan[10]= %r, chan[11]= %r, chan[12]= %r])' % (cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9], chan[10], chan[11], chan[12]))
        c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], 'True', chan[8], chan[9], chan[10], chan[11], chan[12]])
        utils.notification('Favorite added: %s' % chan[1])
    conn.commit()
    c.close()

def delChannelFav(cat):
    utils.logdev(module+'-delChannelFav','cat= %r' % (cat))
    cat = cat.strip()
    conn = getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])
    favorites = c.fetchall()
    for chan in favorites:
        utils.logdev(module+'-delChannelFav 1','cat= %r' % (cat))
        c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], 'False', chan[8], chan[9], chan[10], chan[11], chan[12]])
    conn.commit()
    c.close()

def setChannelHide(cat):
    cat = cat.strip()
    conn = getConnection()
    c = conn.cursor()
    ###c.execute("SELECT * FROM channels WHERE id=?", [cat])
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])
    favorites = c.fetchall()
    for chan in favorites:
        c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], 0, chan[6], chan[7], chan[8], chan[9], chan[10], chan[11], chan[12]])
        utils.notification('Channel Hidden: %s' % chan[1])
    conn.commit()
    c.close()
    
def delChannelHide(cat):
    cat = cat.strip()
    utils.logdev(module,'delChannelHide(cat= %r)' % cat)
    conn = getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])
    favorites = c.fetchall()
    utils.logdev(module,'delChannelHide len(favorites)= %r' % len(favorites))
    for chan in favorites:
        c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], 1, chan[6], chan[7], chan[8], chan[9], chan[10], chan[11], chan[12]])
    ###utils.logdev(module,'delChannelHide-1 len(favorites)= %r' % len(favorites))
    conn.commit()
    c.close()

def setChannelRecursive(cat):
    cat = cat.strip()
    conn = getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])
    favorites = c.fetchall()
    for chan in favorites:
        if not chan[9] is None:
            if not ' (R)' in chan[9]:
                recursive = chan[9] + ' (R)'
            else:
                recursive = chan[9]
            ### Only mark as recursive channel if epg_channel assigned
            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], recursive.replace(' (R)',''), chan[10], chan[11], chan[12]])
            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], ADDONid, chan[5], chan[6], 'False', 0, chan[9].replace(' (R)',''), '', '', ''])  ### Play channel Source = ADDONid
            c.execute("INSERT OR REPLACE INTO channelsRecursive(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], 'False', 0, chan[9].replace(' (R)',''), '', '', ''])  ### Play channelRecursive
            utils.notification('Recursive added: %s' % chan[1])

    conn.commit()
    c.close()
    
def delChannelRecursive(cat):
    cat = cat.strip()
    utils.logdev(module,'delChannelRecursive(cat= %r)' % cat)
    conn = getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])
    favorites = c.fetchall()
    for chan in favorites:
        c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], 1, chan[6], chan[7], chan[8], chan[9].replace(' (R)',''), chan[10], chan[11], chan[12]])
        c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], ADDONid, chan[5], chan[6], 'False', 0, chan[9].replace(' (R)',''), '', '', ''])  ### Play channel Source = ADDONid
        c.execute("INSERT OR REPLACE INTO channelsRecursive(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], 0, chan[6], chan[7], chan[8], chan[9].replace(' (R)',''), chan[10], chan[11], chan[12]])
    ###utils.logdev(module,'delChannelHide-1 len(favorites)= %r' % len(favorites))
    conn.commit()
    c.close()

def isChannelVisible(cat):
    ###utils.logdev(module,'isChannelVisible(cat=%r)' % cat)
    cat = cat.strip()
    conn = getConnection()
    c = conn.cursor()
    try:
        c.execute("SELECT DISTINCT visible FROM channels WHERE id=? and source=?", [cat,origin])
        favorites = c.fetchall()
    except:
        pass
        favorites =  []
    result = False
    if len(favorites) > 0:
        result = favorites[0][0]
        ###utils.logdev(module,'result= %r' % result)
        if result == 1:
            result = True
        ###utils.logdev(module,'result1= %r' % result)
    c.close()
    return result
    
def getAllChannels():
    c = getConnection().cursor()
    try:
        ### channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER)
        c.execute("SELECT * FROM channels")
        channels = c.fetchall()
    except:
        pass
        channels =  []
    channels = sorted(channels, key=itemgetter('title'))
    utils.logdev(module,'getAllChannels() - len= %r' % len(channels))
    return channels

def getAllChannelsList():
    c = getConnection().cursor()
    try:
        ### channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER)
        c.execute("SELECT DISTINCT id, title, stream_url FROM channels")
        channels = c.fetchall()
    except:
        pass
        channels =  []
    channels = sorted(channels, key=itemgetter('title'))
    utils.logdev(module,'getAllChannelsList() - len= %r' % len(channels))
    return channels


def urlFromCat(cat):
    c = getConnection().cursor()
    try:
        c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])
        urls = c.fetchall()
        ###utils.logdev(module,'urls= %s --> cat= %s' %(repr(urls),cat))
    except:
        pass
        urls = ''
    if len(urls) > 0:
        url = urls[0][3]
    else:
        url = ''
        ###utils.notification( 'NOT FOUND: channel= %s' % (cat))
    c.close()
    ###utils.logdev(module,'cat= %s --> url= %s' %(cat,url))
    return url
    
def directprograms(cat):
    ### Channel name has (D) in the end to be Direct or not roqtv.com in url
    url = urlFromCat(cat)
    ###utils.logdev(module,'directprograms(cat= %r) url= %r' % (cat, url))
    if not 'roq-tv.net' in url:
        return url
    else:
        return ''

def catFromEPGcat(EPGcat):
    c = getConnection().cursor()
    try:
        c.execute("SELECT * FROM channelsRecursive WHERE epg_channel=?", [EPGcat])   ### channels == channelsRecursive
        cats = c.fetchall()
        ###utils.logdev(module,'cats= %r <-- EPGcat= %r' %(cats,EPGcat))
        if len(cats) > 0:
            cat = cats[0][0]
        else:
            cat = ''
            utils.logdev(module,'cat= %r <-- EPGcat= %r' %(cat,EPGcat))
    except:
        pass
        cat = ''
    c.close()
    return cat

def catFromUrl(url):
    c = getConnection().cursor()
    try:
        c.execute("SELECT * FROM channels WHERE stream_url=?", [url])
        cats = c.fetchall()
        ###utils.logdev(module,'cats= %r <-- url= %r' %(cats,url))
        if len(cats) > 0:
            cat = cats[0][0]
        else:
            if ':25461' in url:
                url  = url.replace(':25461',':8080')
                c.execute("SELECT * FROM channels WHERE stream_url=?", [url])
                cats = c.fetchall()
                ###utils.logdev(module,'cats= %r <-- url= %r' %(cats,url))
                if len(cats) > 0:
                    cat = cats[0][0]
                else:
                    cat = ''
            else:
                cat = ''
            ###utils.notification( 'NOT FOUND: channel= %s' % (url))
    except:
        pass
        cat = ''
    c.close()
    ###utils.logdev(module,'cat= %s <-- url= %s' %(cat,url))
    ###2017-06-12 19:41:13 default.py: catThis = recordings.catFromUrl(StreamURL)= '' 
    ###2017-06-12 19:41:13 default.py: 0 addDir(name= FORMULA 1 (2017) - CANADIAN GRAN PRIX RACE (1080),url= http://roq-tv.net:25461/movie/<username>/<password>/3518.mp4,mode= 200,iconimage= ,cat= ,date= ,description= IMDB_ID: 
    if not cat == '':
        return cat
    else:
        try:
            cat=url.split('live/')[1].split('/')[0]
        except:
            pass
            try:
                cat=url.split('tv2danmark/')[1].split('/')[0]
            except:
                pass
                try:
                    cat=url.split('i/')[1].split('/')[0]
                except:
                    pass
                    try:
                        cat=url.split('.')[-2].split('/')[-1]
                    except:
                        pass
                        cat=''
                        utils.logdev(module,'catFromUrl(url) FAILED: url= %r' % url)
    return cat
    
def IconFromCat(cat):
    c = getConnection().cursor()
    try:
        c.execute("SELECT * FROM channels WHERE id=?", [cat.strip()])
        urls = c.fetchall()
        if len(urls) > 0:
            url = urls[0][2]
        else:
            url = ''
            utils.notification( 'NOT FOUND: channel= %s' % (cat))
    except:
        pass
        url = ''
    c.close()
    return url

def ChannelName(cat):
    c = getConnection().cursor()
    try:
        #xbmc.log('recordings.py: ChannelName cat= %s' % (repr(cat)))
        ###c = getIconConnection().cursor()
        #c.execute("SELECT * FROM channels WHERE title=? COLLATE NOCASE", [title.strip()])
        ###c.execute("SELECT * FROM channels WHERE title=? and source=? COLLATE NOCASE", [ChannelName.strip(),origin])
        c.execute("SELECT * FROM channels WHERE id=? and source=? COLLATE NOCASE", [cat.strip(),origin])  ### 2017-09-30
        logos = c.fetchall()
        #xbmc.log('recordings.py: ChannelName logos title= %s' % repr(logos))
        if len(logos) > 0:
            logo = logos[0][1]
        else:
            logo = cat
            ###utils.notification( 'NOT FOUND: channel= %s' % (cat))
        #xbmc.log('recordings.py: ChannelName logo= %s' % repr(logo))
    except:
        pass
        logo = cat
    c.close()
    return logo
    
def EPG_ChannelFromCat(cat):
    c = getConnection().cursor()
    try:
        c.execute("SELECT * FROM channels WHERE id=? and source=? COLLATE NOCASE", [cat.strip(),origin]) 
        logos = c.fetchall()
        if len(logos) > 0:
            logo = logos[0][9]
        else:
            logo = ''
            ###utils.notification( 'NOT FOUND: channel= %s' % (cat))
        #xbmc.log('recordings.py: ChannelName logo= %s' % repr(logo))
    except:
        pass
        logo = ''
    c.close()
    return logo
    
def catsfromEPGid(epgid):
    c = getConnection().cursor()
    utils.logdev('XYZxyz','catsfromEPGid(epgid= %r)' % epgid)
    try:
        ###c.execute("SELECT * FROM channels WHERE epg_channel=? favorite=? and visible=? and source=?", [epgid,'True',1,origin])
        c.execute("SELECT * FROM channels WHERE epg_channel=?", [epgid])
        ###c.execute("SELECT * FROM channels WHERE title=? COLLATE NOCASE", [epgid.strip()])
        logos = c.fetchall()
        utils.logdev('XYZxyz','logos= %r' % logos)
        cat= logos[0][0]
    except:
        pass
        logos= []
    if len(logos) > 0:
        logo = logos[0][0]
    else:
        logo = '0'
        utils.notification( 'NOT FOUND: epgid= %s' % (epgid))
    utils.logdebug('catsfromEPGid', 'epgid= %r, cat= %r' % (epgid, logo))
    c.close()
    return logo
    
    
def CatFromChannelName(ChannelName):
    c = getConnection().cursor()
    try:
        ###c = getIconConnection().cursor()
        ###c.execute("SELECT * FROM channels WHERE title=? and source=? COLLATE NOCASE", [ChannelName.strip(),origin])
        c.execute("SELECT * FROM channels WHERE title=? COLLATE NOCASE", [ChannelName.strip()])
        #c.execute("SELECT * FROM channels WHERE id=?", [cat.strip()])
        logos = c.fetchall()
        ###utils.logdev('CatFromChannelName', 'ChannelName= %s, CatFromChannelName= %s' % (repr(ChannelName), repr(logos)))
        cat= logos[0][0]
    except:
        pass
        logos= []
    if len(logos) > 0:
        logo = logos[0][0]
    else:
        logo = '0'
        ###utils.notification( 'NOT FOUND: channel= %s' % (ChannelName))
    utils.logdebug('CatFromChannelName', 'ChannelName= %r, cat= %r' % (ChannelName, logo))
    c.close()
    return logo
    
def ChannelNameDb(cat,c,origin):  ###  and source=?", [cat,origin])
    try:
        #xbmc.log('recordings.py: ChannelName cat= %s' % (repr(cat)))
        ###c = getIconConnection().cursor()
        ###c = getConnection().cursor()
        #c.execute("SELECT * FROM channels WHERE title=? and source=? COLLATE NOCASE", [title.strip(),origin])
        c.execute("SELECT * FROM channels WHERE id=? and source=? COLLATE NOCASE", [cat.strip(),origin])  ### 2017-09-30

        logos = c.fetchall()
        #xbmc.log('recordings.py: ChannelName logos title= %s' % repr(logos))
    except:
        pass
        logos= []
    if len(logos) > 0:
        logo = logos[0][1]
    else:
        logo = cat
        ###utils.notification( 'NOT FOUND: channel= %s' % (cat))
    #xbmc.log('recordings.py: ChannelName logo= %s' % repr(logo))
    ###c.close()  # 2017-12-29
    return logo

def CatFromChannelNameDb(ChannelName,c,origin):
    try:
        ###c = getIconConnection().cursor()
        ###c = getConnection().cursor()
        c.execute("SELECT * FROM channels WHERE title=? and source=? COLLATE NOCASE", [ChannelName.strip(),origin])
        #c.execute("SELECT * FROM channels WHERE id=?", [cat.strip()])
        logos = c.fetchall()
        ###utils.logdev('CatFromChannelName', 'ChannelName= %s, CatFromChannelName= %s' % (repr(ChannelName), repr(logos)))
        cat= int(logos[0][0])
    except:
        pass
        logos= []
    if len(logos) > 0:
        logo = logos[0][0]
    else:
        logo = '0'
        ###utils.notification( 'NOT FOUND: channel= %s' % (ChannelName))
    utils.logdebug('CatFromChannelName', 'ChannelName= %r, cat= %r' % (ChannelName, logo))
    ###c.close()  # 2017-12-29
    return logo

def getRecordings():
    #print "getRecordings"
    c = getConnection().cursor()
    #print "getRecordings1"
    try:
        c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc")
        #print "getRecordings2"
        recordings = c.fetchall()
        recordings = sorted(recordings, key=itemgetter('start'))
        #print "getRecordings3"
        utils.logdev('getRecordings',"len(recordings)= " + str(len(recordings)))
        for index in range(0, len(recordings)):
            cat         = recordings[index][0]
            name        = recordings[index][1]
            startDate   = parseDate(recordings[index][2]) 
            utils.logdev('getRecordings','getRecordings() Name= %r StartDate=%r' %(recordings[index][1],recordings[index][2]))
    except Exception, e:
        pass
        utils.logdev(module,'getRecordings() failed! \nERROR= %r' % e)
        recordings = []
    ##for index in range(0, len(recordings)):
    ##  #print "getRecordings4"
    ##  cat         = recordings[index][0]
    ##  #print "getRecordings5"
    ##  name        = recordings[index][1]
    ##  #print "getRecordings6"
    ##  startDate   = parseDate(recordings[index][2])
    ##  #print "getRecordings7"
    ##  endDate     = parseDate(recordings[index][3])
    ##  #print "getRecordings8"
    ##  alarmname   = recordings[index][4]
    ##  #print "getRecordings9"
    ##  description = recordings[index][5]
    ##  #print "getRecordings9a"
    ##  #print "recording# " + str(index) + ": " + str(cat) + " , " + str(name) + " , " + repr(startDate) + " , " + repr(endDate) + " , " + alarmname + " , " + str(description)
    #print "getRecordings10"
    #try:
    #   conn.commit()
    #   #print 'recordings.py conn.commit OK'
    #except:
    #   pass
    #   #print 'recordings.py conn.commit failed!'
    #try:
    #   c.commit()
    #   #print 'recordings.py c.commit OK'
    #except:
    #   pass
    #   #print 'recordings.py c.commit failed!'
    c.close()
    #print "getRecordings"
    return recordings

def isRecording(cat,name,startD,endD):
    startD = parseDate(startD)
    endD = parseDate(endD)
    c = getConnection().cursor()
    if '[' in name:
        name = name.split('[')[0].strip() + '%'
    ###name = name.replace('[','%').replace(']','%').replace('(','%').replace(')','%').replace('.','%').replace('%%','%').replace('  ','%').replace('%%','%').replace('% %','%')
    utils.logdev(module, 'c.execute(SELECT * FROM recordings_adc WHERE cat=%r and name like %r)' % (cat,name))
    try:  ### WHERE
        c.execute("SELECT * FROM recordings_adc WHERE cat=? and name like ? and start <= ? and end >= ? ",  [cat,name,startD,endD])
        
    except Exception, e:
        pass
        utils.logdev(module, 'c.execute(SELECT * FROM recordings_adc WHERE cat=? and name like ?) failed! \nERROR= %r' % e)
    recordings = c.fetchall()
    c.close()
    return recordings
    
def getRecordingsActive(startD,endD):
    try:
        startPadding = 60 * int(ADDON.getSetting('TimeBefore')) + 1
        endPadding   = 60 * int(ADDON.getSetting('TimeAfter')) + 1
    except:
        startPadding = 60 * 3
        endPadding   = 60 * 15
    startD = parseDate(startD)
    endD = parseDate(endD)
    startD = startD + timedelta(seconds = startPadding)
    endD = endD - timedelta(seconds = endPadding)
    if endD < startD:
        endD = startD
    c = getConnection().cursor()
    try:
        c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc")
    except Exception, e:
        pass
        utils.logdev(module, 'c.execute(SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc) failed! \nERROR= %r' % e)
    recordings = c.fetchall()
    recordingsActive=[]

    for index in range(0, len(recordings)): 
        cat         = recordings[index][0]
        ###noblock     = utils.directprograms(cat)
        noblock     = directprograms(cat)
        name        = recordings[index][1]
        startDate   = parseDate(recordings[index][2]) + timedelta(seconds = startPadding+1)
        endDate     = parseDate(recordings[index][3]) - timedelta(seconds = endPadding+1)
        alarmname   = recordings[index][4]
        description = recordings[index][5]
        if not('Recursive:' in name) and not ('[COLOR blue]' in name) and noblock == '':
            if ((endDate >= startD and startDate <= endD) or (endDate >= endD and startDate <= startD) or (endDate <= endD and startDate >= startD)):
                recordingsActive.append(name)
    c.close()
    return recordingsActive

def getRecordingsActiveAll(startD,endD):
    try:
        startPadding = 60 * int(ADDON.getSetting('TimeBefore')) + 1
        endPadding   = 60 * int(ADDON.getSetting('TimeAfter')) + 1
    except:
        startPadding = 60 * 3
        endPadding   = 60 * 15
    startD = parseDate(startD)
    endD = parseDate(endD)
    startD = startD + timedelta(seconds = startPadding)
    endD = endD - timedelta(seconds = endPadding)
    if endD < startD:
        endD = startD
    c = getConnection().cursor()
    c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc")
    recordings = c.fetchall()
    recordingsActive=[]

    for index in range(0, len(recordings)): 
        cat         = recordings[index][0]
        name        = recordings[index][1]
        startDate   = parseDate(recordings[index][2]) + timedelta(seconds = startPadding+1)
        endDate     = parseDate(recordings[index][3]) - timedelta(seconds = endPadding+1)
        alarmname   = recordings[index][4]
        description = recordings[index][5]
        if not('Recursive:' in name) and not ('[COLOR blue]' in name):
            if ((endDate >= startD and startDate <= endD) or (endDate >= endD and startDate <= startD) or (endDate <= endD and startDate >= startD)):
                recordingsActive.append(name)
    c.close()
    return recordingsActive

def getRecordingsActiveAllCat(startD,endD):
    try:
        startPadding = 60 * int(ADDON.getSetting('TimeBefore')) + 1
        endPadding   = 60 * int(ADDON.getSetting('TimeAfter')) + 1
    except:
        startPadding = 60 * 3
        endPadding   = 60 * 15
    startD = parseDate(startD)
    endD = parseDate(endD)
    startD = startD + timedelta(seconds = startPadding)
    endD = endD - timedelta(seconds = endPadding)
    if endD < startD:
        endD = startD
    try:
        c = getConnection().cursor()
        c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc")
        recordings = c.fetchall()
    except:
        pass
        recordings = []
    recordingsActive=[]

    for index in range(0, len(recordings)): 
        cat         = recordings[index][0]
        name        = recordings[index][1]
        startDate   = parseDate(recordings[index][2]) + timedelta(seconds = startPadding+1)
        endDate     = parseDate(recordings[index][3]) - timedelta(seconds = endPadding+1)
        alarmname   = recordings[index][4]
        description = recordings[index][5]
        if not('Recursive:' in name) and not ('[COLOR blue]' in name):
            if ((endDate >= startD and startDate <= endD) or (endDate >= endD and startDate <= startD) or (endDate <= endD and startDate >= startD)):
                recordingsActive.append(cat)
    c.close()
    return recordingsActive

def getRecordingsActiveNoOrange(startD,endD):
    try:
        startPadding = 60 * int(ADDON.getSetting('TimeBefore')) + 1
        endPadding   = 60 * int(ADDON.getSetting('TimeAfter')) + 1
    except:
        startPadding = 60 * 3
        endPadding   = 60 * 15
    startD = parseDate(startD)
    endD = parseDate(endD)
    startD = startD + timedelta(seconds = startPadding)
    endD = endD - timedelta(seconds = endPadding)
    if endD < startD:
        endD = startD
    try:
        c = getConnection().cursor()
        c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc")
        recordings = c.fetchall()
    except:
        pass
        recordings = []
    recordingsActive=[]

    for index in range(0, len(recordings)): 
        cat         = recordings[index][0]
        name        = recordings[index][1]
        startDate   = parseDate(recordings[index][2]) + timedelta(seconds = startPadding+1)
        endDate     = parseDate(recordings[index][3]) - timedelta(seconds = endPadding+1)
        alarmname   = recordings[index][4]
        description = recordings[index][5]
        if not('Recursive:' in name) and not ('[COLOR blue]' in name) and not ('[COLOR orange]' in name ) and directprograms(cat) == '':  ### 2017-09-21
            if ((endDate >= startD and startDate <= endD) or (endDate >= endD and startDate <= startD) or (endDate <= endD and startDate >= startD)):
                recordingsActive.append(name)
    c.close()
    return recordingsActive
    
def getRecordingsConcurrent(startD,endD):
    try:
        startPadding = 60 * int(ADDON.getSetting('TimeBefore')) + 1
        endPadding   = 60 * int(ADDON.getSetting('TimeAfter')) + 1
    except:
        pass
        startPadding = 60 * 3
        endPadding   = 60 * 15
    startD = parseDate(startD)
    endD = parseDate(endD)
    startD = startD + timedelta(seconds = startPadding) * 2
    endD = endD - timedelta(seconds = endPadding) * 2
    if endD < startD:
        endD = startD
    try:
        c = getConnection().cursor()
        c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc")
        recordings = c.fetchall()
    except:
        pass
        recordings = []
    recordingsActive=[]

    for index in range(0, len(recordings)): 
        cat         = recordings[index][0]
        name        = recordings[index][1]
        startDate   = parseDate(recordings[index][2]) + timedelta(seconds = startPadding+1)
        endDate     = parseDate(recordings[index][3]) - timedelta(seconds = endPadding+1)
        alarmname   = recordings[index][4]
        description = recordings[index][5]
        if not('Recursive:' in name) and not ('[COLOR blue]' in name) and not ('[COLOR orange]' in name): 
            if ((endDate >= startD and startDate <= endD) or (endDate >= endD and startDate <= startD) or (endDate <= endD and startDate >= startD)):
                recordingsActive.append(name)
    c.close()
    return recordingsActive

def add(cat, startDate, endDate, recordname, description):
    utils.logdev(module,'add(cat= %r, startDate= %r, endDate= %r, recordname= %r, description= %r)' %(cat, startDate, endDate, recordname, description))
    utils.logdev(module,'add(startDate= %r, endDate= %r)' %(startDate, endDate))
    startDate = parseDate(startDate)
    endDate = parseDate(endDate)
    utils.logdev(module,'add(startDate= %r, endDate= %r)' %(startDate, endDate))
    if  ('Recursive:' in recordname):
        recordingsActive = []
    else:
        recordingsActive=getRecordingsActiveNoOrange(startDate, endDate)
    if not recordingsActive == []:
        utils.notification('[COLOR red]OVERLAPPING Recording NOT allowed:[/COLOR] %s' % str(recordingsActive))
    if schedule(cat, startDate, endDate, recordname, description):
        utils.notification('Recording [COLOR red]set[/COLOR] for %s' % recordname)
    return

def schedule(cat, startDate, endDate, recordname, description, DB='default'):
    utils.logdev(module,'recordings.schedule DB= %r' % DB)
    utils.logdev(module,'schedule(cat= %r, startDate= %r, endDate= %r, recordname= %r, description= %r, DB= %r' % (cat, startDate, endDate, recordname, description, DB))
    if description == None:
        description = 'None 1'
    recordPath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_path')))
    if ADDON.getSetting('enable_record')=='true' and not utils.folderwritable(recordPath):
        utils.notification('Recording not possible [COLOR red]You must set the recording path writable![/COLOR] \nGoto Settings/Recording/Record Path and set that to a writable path')
        ###utils.logdev(module,'You must set the recording path writable!')
        ###xbmcaddon.Addon(id=ADDONid).openSettings()   
    recordname = ' '.join(recordname.split())  ## Remove doublespaces etc
    utils.logdev(module,'startDate= %r > endDate= %r - timedelta(minutes=1)= %r' % (startDate,endDate - timedelta(minutes=1),startDate > endDate - timedelta(minutes=1)))
    if startDate > endDate - timedelta(minutes=1) :
        startDate = datetime.now()
        endDate = datetime.now() + timedelta(hours=2) # missing time in schedule
    utils.logdev(module,'schedule(cat= %r, startDate= %r, endDate= %r, recordname= %r, description= %r)' % ( cat,startDate,endDate,recordname,description))
    
    playchannel = cat
    originalduration = ''
    startDate = parseDate(startDate)
    endDate   = parseDate(endDate)
    durationstring = str(endDate - startDate).split(':')
    utils.logdev(module,'startDate= %r, endDate= %r, durationstring= %r' % (startDate,endDate,durationstring))
    originalduration = ''
    if endDate > startDate and not 'day' in durationstring[0]:
        originalduration =  'Duration [' + durationstring[0] + ':' + durationstring[1] + ']. '
    if not 'Duration [' in description and not ']. ' in description:
        description = originalduration + description
    AdjustDates = False
    recordModified = False
    recordRescheduled = False
    recordRecursive = False
    recordInactive = False
    t = startDate - datetime.now()
    utils.logdev(module,'t= %r, t.days= %r' % (t,t.days))
    timeToRecording = (t.days * 86400) + t.seconds
    utils.logdev(module,'timeToRecording= %r' % timeToRecording)
    now = parseDate(datetime.now()) ### 2017-09-30
    ###now = datetime.now()
    utils.logdev(module,'now= %r' % now)
    try:
        startPadding = 60 * int(ADDON.getSetting('TimeBefore'))
        endPadding   = 60 * int(ADDON.getSetting('TimeAfter'))
    except:
        startPadding = 60 * 3
        endPadding   = 60 * 15
    
    #if cat == '147':
    #utils.logdev('schedule147','cat= %s, name= %s' % (repr(cat),repr(recordname))) ## debug
    
    if ('CcCc' in recordname) and (timeToRecording < (startPadding * 2)):
        return ## Dont accept schedule from TV Grab if they are late
    recordname = recordname.replace('CcCc','',1)
    if ('AaAa' in recordname):
        AdjustDates = True
        recordModified = True
        if 'Modified' in recordname:
            recordname = recordname.replace('AaAa','',1)
        else:
            #recordname = recordname.replace('AaAa',' Modified',1)  # 2015-10-11 Don't add Modified to record name
            recordname = recordname.replace('AaAa','',1)
    if ('BbBb' in recordname):
        recordRescheduled = True
        AdjustDates = False
        #if cat == '147':
        #utils.logdev('schedule147R','cat= %s, name= %s' % (repr(cat),repr(recordname))) ## debug
        if 'Rescheduled' in recordname:
            recordname = recordname.replace('BbBb','',1)
        else:
            #recordname = recordname.replace('BbBb',' Rescheduled',1)  # 2015-10-11 Don't put Rescheduled in recordname
            recordname = recordname.replace('BbBb','',1)
    if ('Recursive' in recordname):
        #print 'Recursive: - %s' % (recordname)
        
        #if cat == '147':
        #utils.logdev('schedule147R','cat= %s, name= %s' % (repr(cat),repr(recordname))) ## debug
    
        
        recordRecursive = True
        AdjustDates = False
        recordname = recordname.replace('AaAa','',1)
        recordname = recordname.replace('BbBb','',1)
        recordname = recordname.replace('Modified','',1)
        recordname = recordname.replace('Rescheduled','',1)
        recordname = recordname.replace('  ',' ')
    recordname = recordname.replace('[COLOR blue]','') # remove inactive marker
    recordname = recordname.replace('[COLOR green]','') # remove inactive marker
    recordname = recordname.replace('[COLOR orange]','*') # remove inactive marker
    recordname = recordname.replace('[COLOR red]','') # remove inactive marker
    recordname = recordname.replace('[/COLOR]','')
    if recordname == '':
        recordname = 'missing'
    ###utils.logdev(module,'recordname= ' + repr(recordname))
    if recordname[0][0] == '*':   # DISABLE RECORD
        #if cat == '147':
        #utils.logdev('schedule147*','cat= %s, name= %s' % (repr(cat),repr(recordname))) ## debug
    
        recordInactive = True
        AdjustDates = False
        recordname = recordname.replace('*','',1)  # 'schedule *-->inactive'
        recordname = recordname.replace('AaAa','',1)
        recordname = recordname.replace('BbBb','',1)
        recordname = recordname.replace('Modified','',1)
        recordname = recordname.replace('Rescheduled','',1)
        recordname = recordname.replace('  ',' ')
    
    showNotification = True
    if timeToRecording < 0:
        showNotification = True
        timeToRecording  = 0
        startDate        = now
    else:
        if (not recordModified) and (not recordRescheduled) and (not recordRecursive) and (not recordInactive): 
            startDate = startDate - timedelta(seconds = startPadding)
        #modify startDate if necessary; it shouldn't be earlier that 'now'
        if startDate < now:
            startDate = now
    
    #if cat == '147':
    ###utils.logdev(module,'cat= %s, name= %s' % (repr(cat),repr(recordname))) ## debug
    
    
    if (startDate == now or recordModified) and (not recordRescheduled) and (not recordRecursive) and (not recordInactive):
        AdjustDates = True
    if AdjustDates == True:
        startDate=AdjustDateTime(startDate,"Start")
    if (endDate <= startDate) and (not recordRecursive) and (not recordInactive):
        endDate = startDate + timedelta(seconds = endPadding)
        AdjustDates = True
    if AdjustDates == True:
        endDate=AdjustDateTime(endDate,"End")
    if (recordname == 'n a' or AdjustDates == True) and (not recordRescheduled) and (not recordInactive) or recordModified:
        if recordModified and recordRecursive:
            recordname='Recursive:' + NAMErecord(recordname.replace('Recursive:','',1).strip())
        else:
            recordname=NAMErecord(recordname)
    if recordModified:
        try:
            description = latin1_to_ascii(DescriptionRecord(description))
        except:
            pass
    recordname= latin1_to_ascii(recordname)
    t =  startDate - now
    timeToRecording = (t.days * 86400) + t.seconds     
    showNotification = True
    if timeToRecording < 0:
        timeToRecording  = 0
        startDate        = now
    nameAlarm = ADDONid +'-recording-%s-%s-%s' % (cat, startDate, latin1_to_ascii_force(recordname))
    duration = endDate - startDate
    ######utils.logdev(module,'duration is %s, if less than 3 minutes - no recording of %s with startDate= %s and endDate= %s' % (repr(duration),repr(recordname),repr(startDate),repr(endDate)))
    if (not recordRecursive) and duration < timedelta(0, 180): # Dont record if les than 3 minutes 2016-03-16
        ###utils.logdev(module,'duration is %s, is less than 3 minutes - no recording of %s with startDate= %s and endDate= %s' % (repr(duration),repr(recordname),repr(startDate),repr(endDate)))
        return
    #xbmc.log('recordings.py: durationDeltaTime= %s' % repr(duration))
    duration = (duration.days * 86400) + duration.seconds
    #xbmc.log('recordings.py: durationNumber= %s' % repr(duration))
    #xbmc.log('recordings.py: endPadding= %s' % repr(endPadding))
    if (not recordModified) and (not recordRescheduled) and (not recordInactive):
        duration = duration + endPadding
        #xbmc.log('recordings.py: duration+endPadding= %s' % repr(duration))
    if recordRecursive or recordInactive:
        #if cat == '147':
        #utils.logdev('scheduleScript','cat= %s, name= %s' % (repr(cat),repr(recordname))) ## debug
        script         =  ''   #os.path.join(ADDON.getAddonInfo('path'), 'findrecursiveX.py')
    else:
        if ADDON.getSetting('recordusing')  == '0':
            script   = os.path.join(ADDON.getAddonInfo('path'), 'record-rtmpdump.py')
        else:
            script   = os.path.join(ADDON.getAddonInfo('path'), 'record-ffmpeg.py')
    if (not recordModified) and (not recordRescheduled) and (not recordRecursive) and (not recordInactive):
        endDate = endDate + timedelta(seconds = endPadding)
    recordname = re.sub(',', '', recordname) 
    #if (int(cat) == 147) and (not recordRecursive) and (not recordInactive):  # change DR1 to DR1 HD - Krogsbell 2015-02-27 DR1 HD now have TV Guide so no switch of channel
    #   #print 'Exchange DR1(183->147) with DR1 HD(508->413) Krogsbell 2014-12-20'
    #   cat = '413'
    ##args     = str(cat) + ',' + str(startDate) + ',' + str(endDate) + ',' + str(duration) + ',' + str(recordname) + ',' + str('60') + ',' + str('True')
    #if cat == '147':
    #utils.logdev('scheduleRecordname','cat= %s, name= %s' % (repr(cat),repr(recordname))) ## debug
    ######utils.logdev('TEST','recordname= %s' % repr(recordname))
    args     = cat + ',' + str(startDate) + ',' + str(endDate) + ',' + str(duration) + ',' + recordname + ',' + '60' + ',' + 'True'
    ######utils.logdev('TEST','args= %s' % repr(args))
    cmd     = ''
    if not(recordRecursive or recordInactive):
        #args= args + ',' + str(nameAlarm) + ',' + urllib.quote_plus(stringtoargument(description))  ####
        args= args + ',' + nameAlarm + ',' + stringtoargument(description)  ### 2016-06-13
        #cmd = 'AlarmClock(%s,RunScript(%s,%s),%d,True)' % (nameAlarm.encode('utf-8', 'replace'), script.encode('utf-8', 'replace'), args.encode('utf-8', 'replace'), timeToRecording/60)
        cmd = 'AlarmClock(%s,RunScript(%s,%s),%d,True)' % (nameAlarm, script, args, timeToRecording/60)
        #cmd = 'AlarmClock(%s,RunScript(%s,%s),%d,True)' % (nameAlarm, script, args, timeToRecording/60)
    recordingsActive = []
    if recordRecursive or recordInactive:
        if recordRecursive:
            endDate = startDate
    else:
        recordingsActive=getRecordingsActive(startDate, endDate)
    recordname = latin1_to_ascii(recordname) ##############################
    if recordInactive:
        addRecordingPlanned(cat, startDate, endDate, '[COLOR orange]' + recordname + '[/COLOR]', '[COLOR orange]' + nameAlarm + '[/COLOR]', description, playchannel,DB)
        return
    unblock = directprograms(cat)
    if not unblock == '':
        # Handle scheduling of Direct Channel - Noblock
        if not cat in getRecordingsActiveAllCat(startDate, endDate):
            addRecordingPlanned(cat, startDate, endDate, recordname, nameAlarm, description, playchannel,DB)
            if not recordRescheduled:
                xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
            else:
                if not recordRecursive:
                    utils.notification('[COLOR lightgreen]Direct Channel Recording: [/COLOR] %s' % (playchannel + ': ' + recordname))
            ###utils.logdev('TEST','cmd= %s' %repr(cmd))
            cmd= latin1_to_ascii(cmd)
            ###utils.logdev('TEST1','cmd= %s' %repr(cmd))
            xbmc.executebuiltin(cmd)
        return
    for  RecordingActive in recordingsActive:
        if ('[COLOR orange]' in RecordingActive) and (recordname in RecordingActive):
            # 2016-03-13 utils.notification('[COLOR orange]Disabled Recording: [/COLOR] %s' % (str(RecordingActive)))
            return
        if (not '[COLOR orange]' in RecordingActive) and (not recordRescheduled) and (not recordRecursive):
            try:
                if (not recordname in RecordingActive) or (not cat in getRecordingsActiveAllCat(startDate, endDate)) : ### 2017-03-18 mark program with same name in a new channel
                    utils.logdev('Schedule','if not recordname= %s in RecordingActive= %s' % (repr(recordname),repr(RecordingActive)))
                    # 2016-03-13 utils.notification('[COLOR red]OVERLAPPING Recording NOT allowed:[/COLOR] %s' % (str(RecordingActive)))
                    delRecordingPlanned(cat, startDate, endDate, '[COLOR blue]' + recordname + '[/COLOR]')
                    addRecordingPlanned(cat, startDate, endDate, '[COLOR blue]' + recordname + '[/COLOR]', '[COLOR blue]' + nameAlarm + '[/COLOR]', description, playchannel,DB)
                else:
                    # 2016-03-13 utils.notification('[COLOR red]Ignore scheduling of same RecordName:[/COLOR] %s' % (str(RecordingActive)))
                    xbmc.sleep(1)
                return
            except:
                pass
                utils.logdev('schedule', 'scheduling ERROR!')  # Put in LOG
                return
    #cancel alarm first just in case it already exists
    if not recordRescheduled:
        xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
    ###utils.logdev('TEST','cmd= %s' %repr(cmd))
    cmd= latin1_to_ascii(cmd)
    ###utils.logdev('TEST1','cmd= %s' %repr(cmd))
    xbmc.executebuiltin(cmd)
    if recordRecursive:
        
        
        #cancel alarm first just in case it already exists
        if not recordRescheduled:
            xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
    #print 'addRecordingPlanned(cat= %s, startDate= %s, endDate= %s, recordname= %s, nameAlarm= %s, description= %s, playchannel= %s)' %(cat, repr(startDate), repr(endDate), repr(recordname), repr(nameAlarm), repr(description), repr(playchannel))
    ###utils.logdev('schedule','cat= %s, name= %s, startDate= %s ,endDate= %s' % (repr(cat),repr(recordname), repr(startDate),repr(endDate))) ## debug
    addRecordingPlanned(cat, startDate, endDate, recordname, nameAlarm, description, playchannel,DB)
    if ('Recursive:' not in recordname):
        utils.notification('Recording [COLOR red]set[/COLOR] for %s' % recordname)
    return

def EPGOnce():
    nameAlarmEPGonce = ADDONname +'updateepgonce' 
    scriptEPG   = os.path.join(ADDON.getAddonInfo('path'), 'updateepg.py')
    cmdEPGonce = 'AlarmClock(%s,RunScript(%s,%s),00:00:00,silent)' % (nameAlarmEPGonce.encode('utf-8', 'replace'), scriptEPG.encode('utf-8', 'replace'), 'once')
    xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmEPGonce)
    xbmc.executebuiltin(cmdEPGonce)

def reschedule():
    backupSetupxml()
    ADDON.setSetting('fixsetup','false')
    backupDataBase()
    if ADDON.getSetting('enable_record')=='true':
        args     = str('True')
        #script   = os.path.join(ADDON.getAddonInfo('path'), 'findrecursivetimed.py')
        #scriptOnce   = os.path.join(ADDON.getAddonInfo('path'), 'findrecursivetimedOnce.py')
        #scriptHour   = os.path.join(ADDON.getAddonInfo('path'), 'findrecursivetimedHour.py')
        
        #nameAlarmRepeat = ADDONid+'-recording-recursive-repeat' 
        #cmdrepeat = 'AlarmClock(%s,RunScript(%s,%s),02:00:00,loop,silent)' % (nameAlarmRepeat.encode('utf-8', 'replace'), script.encode('utf-8', 'replace'), args.encode('utf-8', 'replace'))
        #xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmRepeat)
        # xbmc.executebuiltin(cmdrepeat)  # Active
        #nameAlarmRepeat = ADDONid+'-recording-recursive-once' 
        #cmdrepeat = 'AlarmClock(%s,RunScript(%s,%s),00:05:00,silent)' % (nameAlarmRepeat.encode('utf-8', 'replace'), scriptOnce.encode('utf-8', 'replace'), args.encode('utf-8', 'replace'))
        #xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmRepeat)
        #xbmc.executebuiltin(cmdrepeat)  # Active
        TVguide= utils.TVguide()
        
        prog = 'startrepeatprog.py'
        now= datetime.today().strftime('%H:%M:%S')
        now = now.split(':')
        nowhm = int(now[0]) * 60 + int(now[1])
        ###starttime = '07:00:00'.split(':')
        starttime = ADDON.getSetting('epgimportstarttime').split(':')
        ###interval  = '08:00:00'
        interval  = ADDON.getSetting('epgimportinterval')
        intervalh  = interval.split(':')
        starttimehm = int(starttime[0]) * 60 + int(starttime[1])
        intervalhm = int(intervalh[0]) * 60 + int(intervalh[1])
        ###utils.logdev(module,'interval= %r starttime= %r - now= %r' %(interval, starttime, now))
        i = 0
        while starttimehm < nowhm and i < 50:
            starttimehm += intervalhm
            i += 1
            ###utils.logdev(module,'interval= %r starttime= %r - now= %r' %(intervalhm, starttimehm, nowhm))
        starttimedelta = starttimehm - nowhm
        starttimedeltahms = str(starttimedelta/60) + ':' + str(starttimedelta%60) + ':00'
        intervalhms = interval.replace(':','h',1).replace(':','m',1)
        utils.logdev(module,'starttimedeltahms= %r starttime= %r - now= %r' %(starttimedeltahms, starttime, now))
        nameAlarmstartrepeatprog = ADDONname +'startrepeatprog' 
        scriptstartrepeatprog   = os.path.join(ADDON.getAddonInfo('path'), prog)
        cmdstartrepeatprog = 'AlarmClock(%s,RunScript(%s,%s),%s,silent)' % (nameAlarmstartrepeatprog.encode('utf-8', 'replace'), scriptstartrepeatprog.encode('utf-8', 'replace'), intervalhms,starttimedeltahms)
        xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmstartrepeatprog)
        utils.notification('Start EPG import in '+starttimedeltahms.replace(':','h',1).replace(':','m',1) + 's')
        xbmc.executebuiltin(cmdstartrepeatprog) 
        
        ###nameAlarmEPG = ADDONname +'updateepg' 
        channels = getAllChannelsList()
        if ADDON.getSetting('epgimportonstart').lower() == 'true' or len(channels) == 0:
            EPGOnce()
        ###cmdEPG = 'AlarmClock(%s,RunScript(%s,%s),08:10:00,loop,silent)' % (nameAlarmEPG.encode('utf-8', 'replace'), scriptEPG.encode('utf-8', 'replace'), 'hourly')
        ###xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmEPG) 
        ###xbmc.executebuiltin(cmdEPG)  # Active
        
        nameAlarmKeep = ADDONname +'http-keep-alive' 
        scriptKeep   = os.path.join(ADDON.getAddonInfo('path'), 'http-keep-alive.py')
        cmdKeep = 'AlarmClock(%s,RunScript(%s,%s),00:05:30,loop,silent)' % (nameAlarmKeep.encode('utf-8', 'replace'), scriptKeep.encode('utf-8', 'replace'), '')
        xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmKeep)
        xbmc.executebuiltin(cmdKeep)  # Active
        
        nameAlarmRepeat = ADDONname +'-recording-recursive-hours' 
        scriptHour   = os.path.join(ADDON.getAddonInfo('path'), 'findtvguidenotificationstimed.py')
        cmdrepeat = 'AlarmClock(%s,RunScript(%s,%s),00:50:00,loop,silent)' % (nameAlarmRepeat.encode('utf-8', 'replace'), scriptHour.encode('utf-8', 'replace'), args.encode('utf-8', 'replace'))
        xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmRepeat)
        xbmc.executebuiltin(cmdrepeat)  # Active
        utils.notification('[COLOR green]Timers set[/COLOR] for TV Guide grab recordings reguarly')
        ##xbmc.executebuiltin("Container.Refresh")
        
        scriptTrig   = os.path.join(ADDON.getAddonInfo('path'), 'TrigTVGuide.py')       
        try:
            TrigInterval = ADDON.getSetting('startstopguideinterval')
        except Exception, e:
            pass
            ###utils.logdev(module, 'Trigger TV Guide interval failed! Guide= %s ERROR= %s' % (guide,repr(e)))
            TrigInterval = '01:00:00'
        
        for Guide in range(0, len(TVguide)):
            guide = TVguide[Guide][0]
            # Trigger Guide...
            try:
                cmdTrig = 'AlarmClock(%s,RunScript(%s,%s,%s),%s,loop,silent)' % (ADDONname +'TrigTVGuide'+guide, scriptTrig, guide,'ExtraParameter',TrigInterval)
                if not (TrigInterval == '00:00:00' or TrigInterval == '0'):
                    xbmc.executebuiltin(cmdTrig)  # Active
                    ###xbmc.executebuiltin("StopScript(" + guide + ")")  ### Stop Guide
                    ###xbmc.executebuiltin("RunAddon(" + guide + ")")    ### Start Guide
                    ###utils.logdev(module, 'Trigger TV Guide= %s with interval %s' % (guide,TrigInterval))
                ###else:
                    
                    ###utils.logdev(module, 'No Trigger TV Guide= %s' % (guide))
            except Exception, e:
                pass
                ###utils.logdev(module, 'Trigger TV Guide failed! Guide= %s ERROR= %s' % (guide,repr(e)))
        
        
        now = parseDate(datetime.now())
        recordings = getRecordings()
        utils.notification('[COLOR green]Rescheduling Recordings[/COLOR]',time=100000)
        #print len(recordings)
        #print recordings
        
        ###utils.logdev('reschedule','size= %s' % (repr(len(recordings)))) ## debug
        for index in range(0, len(recordings)): 
            cat       = recordings[index][0]
            name      = recordings[index][1]
            #startDate = parseDate(recordings[index][2])
            startDate = recordings[index][2]
            #endDate   = parseDate(recordings[index][3])
            endDate   = recordings[index][3]
            alarmname = recordings[index][4]
            description = recordings[index][5]
            
            ###utils.logdev('reschedule','cat= %s, name= %s' % (repr(cat),repr(name))) ## debug
            try:
                delRecordingPlanned(cat, startDate, endDate, name)
            except:
                pass
                ###utils.logdev('delRecordingPlanned','FAILED(index= %s, cat= %s, startDate= %s, endDate= %s, name= %s)' %(str(repr(index)),str(repr(cat)), str(repr(startDate)), str(repr(endDate)), str(repr(name))))  # Put in LOG
            if ('Recursive' in name):
                startDate = now
                endDate   = now
            else:
                startDate = parseDate(startDate)
                endDate   = parseDate(endDate)
            if ('Recursive' in name) or (('[COLOR blue]' not in name) and (endDate > now)):
                ###utils.logdev('schedule','cat= %s, name= %s, startDate= %s ,endDate= %s' % (repr(cat),repr(name), repr(startDate),repr(endDate))) ## debug
                schedule(cat,startDate,endDate,name+'BbBb',description)

def Numeric(timeT,funk):
        dialog = xbmcgui.Dialog()
        keyboard=dialog.numeric(2, funk + ' Time To Record?',timeT)
        return keyboard

def NumericStart(timeD,funk):
        dialog = xbmcgui.Dialog()
        keyboard=dialog.numeric(1, funk + ' Date To Record?',timeD)
        return keyboard

def NAMErecord(recordName):
        search_entered = recordName
        keyboard = xbmc.Keyboard(search_entered, 'Please Enter Program Name')
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText()
            if search_entered == None:
                return False          
        return search_entered 
         
def DescriptionRecord(recordName):
        search_entered = recordName
        keyboard = xbmc.Keyboard(search_entered, 'Please Enter Programme Description')
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText()
            if search_entered == None:
                return False          
        return search_entered  

def AdjustDateTime(aDateTime,funk):
    startTime=aDateTime.strftime('%H:%M')
    aDateTime=NumericStart(aDateTime.strftime('%d/%m/%Y'),funk)
    startTime=Numeric(startTime,funk)
    startYear=int(aDateTime.split('/')[2])
    startMonth=int(aDateTime.split('/')[1])
    startDay=int(aDateTime.split('/')[0])
    startHour=int(startTime.split(':')[0])
    startMinute=int(startTime.split(':')[1])
    aDateTime=(startYear,startMonth,startDay,startHour,startMinute,0,0,0,-1)
    aDateTime=datetime(*aDateTime[0:6])
    return aDateTime

def safe_unicode(obj, *args):
    """ return the unicode representation of obj """
    try:
        return unicode(obj, *args)
    except UnicodeDecodeError:
        ascii_text = str(obj).encode('string_escape')
        return unicode(ascii_text)

def safe_str(obj):
    """ return the byte string representation of obj """
    try:
        return str(obj)
    except UnicodeEncodeError:
        return unicode(obj).encode('unicode_escape')

# ------------------------------------------------------------------------
# Sample code below to illustrate their usage

def write_unicode_to_file(filename, unicode_text):
    """
    Write unicode_text to filename in UTF-8 encoding.
    Parameter is expected to be unicode. But it will also tolerate byte string.
    """
    fp = file(filename,'wb')
    # workaround problem if caller gives byte string instead
    unicode_text = safe_unicode(unicode_text)
    utf8_text = unicode_text.encode('utf-8')
    fp.write(utf8_text)
    fp.close()


def _decodeHtmlEntities(string):
        """Decodes the HTML entities found in the string and returns the modified string.

        Both decimal (&#000;) and hexadecimal (&x00;) are supported as well as HTML entities,
        such as &aelig;

        Keyword arguments:
        string -- the string with HTML entities

        """
        if type(string) not in [str, unicode]:
            return string

        def substituteEntity(match):
            ent = match.group(3)
            if match.group(1) == "#":
                # decoding by number
                if match.group(2) == '':
                    # number is in decimal
                    return unichr(int(ent))
            elif match.group(2) == 'x':
                # number is in hex
                return unichr(int('0x' + ent, 16))
            else:
                # they were using a name
                cp = name2codepoint.get(ent)
                if cp:
                    return unichr(cp)
                else:
                    return match.group()

        entity_re = re.compile(r'&(#?)(x?)(\w+);')
        return entity_re.subn(substituteEntity, string)[0]


"""
latin1_to_ascii -- The UNICODE Hammer -- AKA "The Stupid American"

This takes a UNICODE string and replaces Latin-1 characters with
something equivalent in 7-bit ASCII. This returns a plain ASCII string. 
This function makes a best effort to convert Latin-1 characters into 
ASCII equivalents. It does not just strip out the Latin1 characters.
All characters in the standard 7-bit ASCII range are preserved. 
In the 8th bit range all the Latin-1 accented letters are converted to 
unaccented equivalents. Most symbol characters are converted to 
something meaningful. Anything not converted is deleted.

Background:

One of my clients gets address data from Europe, but most of their systems 
cannot handle Latin-1 characters. With all due respect to the umlaut,
scharfes s, cedilla, and all the other fine accented characters of Europe, 
all I needed to do was to prepare addresses for a shipping system.
After getting headaches trying to deal with this problem using Python's 
built-in UNICODE support I gave up and decided to use some brute force.
This function converts all accented letters to their unaccented equivalents. 
I realize this is dirty, but for my purposes the mail gets delivered.


#!/usr/bin/env python
# -*- coding: utf-8 -*-

u = 'idzie wąż wąską dróżką'
uu = u.decode('utf8')
s = uu.encode('cp1250')
print(s)
"""

import re, htmlentitydefs

##
# Removes HTML or XML character references and entities from a text string.
#
# @param text The HTML (or XML) source text.
# @return The plain text, as a Unicode string, if necessary.

def unescape(text):
    def fixup(m):
        text = m.group(0)
        if text[:2] == "&#":
            # character reference
            try:
                if text[:3] == "&#x":
                    return unichr(int(text[3:-1], 16))
                else:
                    return unichr(int(text[2:-1]))
            except ValueError:
                pass
        else:
            # named entity
            try:
                text = unichr(htmlentitydefs.name2codepoint[text[1:-1]])
            except KeyError:
                pass
        return text # leave as is
    return re.sub("&#?\w+;", fixup, text)

def latin1_to_ascii (unicrap):
    """This takes a UNICODE string and replaces Latin-1 characters with
        something equivalent in 7-bit ASCII. It returns a plain ASCII string. 
        This function makes a best effort to convert Latin-1 characters into 
        ASCII equivalents. It does not just strip out the Latin-1 characters.
        All characters in the standard 7-bit ASCII range are preserved. 
        In the 8th bit range all the Latin-1 accented letters are converted 
        to unaccented equivalents. Most symbol characters are converted to 
        something meaningful. Anything not converted is deleted.
    """
    u = unicrap   ## TEST 2016-04-29 ###############################################################################################
    ###utils.logdev('TEST-unicrap',repr(u))
    return u
    #return u ######################################
    if isinstance(u, unicode):
        #   uu = u.encode('utf-8')
        #else:
        #   uu = u
    #try:
        uu = u.encode('utf8')
    else:
        uu = u.encode('utf8', 'xmlcharrefreplace')
    #except:
    #   uu = 'a' + u +'b'
    ###utils.logdev('TEST-utf8',repr(uu))
    #try:
    ##s = uu.encode('ascii', 'xmlcharrefreplace')
    #except:
    #   s = 'x' + u +'y'
    #####utils.logdev('TEST-ascii',repr(s))
    return uu ## TEST 2016-04-29 ###############################################################################################

def latin1_to_ascii_force (unicrap):
    """This takes a UNICODE string and replaces Latin-1 characters with
        something equivalent in 7-bit ASCII. It returns a plain ASCII string. 
        This function makes a best effort to convert Latin-1 characters into 
        ASCII equivalents. It does not just strip out the Latin-1 characters.
        All characters in the standard 7-bit ASCII range are preserved. 
        In the 8th bit range all the Latin-1 accented letters are converted 
        to unaccented equivalents. Most symbol characters are converted to 
        something meaningful. Anything not converted is deleted.
    """ 
    #return unicrap
    ###utils.logdev('TEST-unicrap',repr(unicrap))
    xlate={0x82:'Euro', 0x85:'Aa', 0x86:'Ae', 0x98:'Oe', 0xc0:'A', 0xc1:'A', 0xc2:'', 0xc3:'', 0xc4:'A', 0xc5:'A',
        0xc6:'Ae', 0xc7:'C',
        0xc8:'E', 0xc9:'E', 0xca:'E', 0xcb:'E',
        0xcc:'I', 0xcd:'I', 0xce:'I', 0xcf:'I',
        0xd0:'Th', 0xd1:'N',
        0xd2:'O', 0xd3:'O', 0xd4:'O', 0xd5:'O', 0xd6:'O', 0xd7:'x', 0xd8:'O',
        0xd9:'U', 0xda:'U', 0xdb:'U', 0xdc:'U',
        0xdd:'Y', 0xde:'th', 0xdf:'ss',
        0xe0:'a', 0xe1:'a', 0xe3:'a', 0xe4:'a', 0xe5:'a',
        0xe6:'ae', 0xe7:'.0xe7.',
        0xe8:'e', 0xe9:'e', 0xea:'e', 0xeb:'e',
        0xec:'i', 0xed:'i', 0xee:'i', 0xef:'i',
        0xf0:'th', 0xf1:'n',
        0xf2:'o', 0xf3:'o', 0xf4:'o', 0xf5:'o', 0xf6:'o', 0xf8:'o',
        0xf9:'u', 0xfa:'u', 0xfb:'u', 0xfc:'u',
        0xfd:'y', 0xfe:'th', 0xff:'y',0xa0:'a',
        0xa1:'a', 0xa2:'.0xa2.', 0xa3:'', 0xa4:'a',
        0xa5:'aa', 0xa6:'ae', 0xa7:'s', 0xa8:'u',
        0xa9:'e', 0xaa:'e', 0xab:'<<', 0xac:'',
        0xad:'-', 0xae:'R', 0xaf:'_', 0xb0:'d',
        0xb1:'+/-', 0xb2:'^2', 0xb3:'^3', 0xb4:"'",
        0xb5:'m', 0xb6:'o', 0xb7:'*', 0xb8:'oe',
        0xb9:'^1', 0xba:'^o', 0xbb:'>>', 
        0xbc:'u', 0xbd:'1/2', 0xbe:'3/4', 0xbf:'?',
        0xd7:'*', 0xf7:'/'
        }
    r = ''
    for i in unicrap:
        if xlate.has_key(ord(i)):
            r += xlate[ord(i)]
        elif ord(i) >= 0x80:
            pass
        else:
            r += str(i)
    ###utils.logdev('TEST-unicrap',repr(r))
    return r

def imageUrlicon(imageUrl,cat,ext):
    #print 'recordings.py imageUrlicon(imageUrl,cat,ext)'
    iurl=icon(cat)
    #print repr(iurl)
    if iurl == '':
        return imageUrl + 'ntvlogo' + ext
    #print iurl.lower()[0] 
    if iurl.lower()[0] =='h':
        return iurl
    else:
        return imageUrl + 'ntvlogo' + ext

def icon(oldicon):
    #print repr(ADDON.getSetting('Use2014Icons').lower())
    #print repr('true')
    if not ADDON.getSetting('Use2014Icons').lower()=='true':
        return oldicon
    #print 'Exchange DR1(183->147) with DR1 HD(508->413) Krogsbell 2014-12-20
    
    """"
    Icons found with this lookup: Krogsbell 2015-02-15
    http://www.ntv.mx/res/content/tv/<no>.png
    2   Itv
    3   Itv 2
    4   BBC ONE
    5   BBC TWO
    7   SKY 1
    8   SKY Movies Action & Adventure
    9   SKY Comedy
    10  SKY Movies Sci Fi & Horror
    11  SKY Movies Sci Fi & Horror
    12  SKY Sports 1
    13  SKY Sports 3
    14  SKY Sports F1
    15  ESPN
    17  SKY News
    26  SKY Movies Drama & Romance
    27  SKY Movies Family
    29  SKY Movies Modern Great
    30  SKY Movies Premiere
    33  SKY Movies Showcase
    39  SKY Sports 2
    40  SKY 2
    43  Animal Planet   310 + 55 *
    44  Discovery Channel   56 + 306 *
    51  SKY Sports 4
    52  SKY Sports News
    54  FOX News
    56  National Geographic Channel
    57  SKY Movies Chrime & Thriller
    59  Itv 4
    60  Five
    61  5USA
    63  Movies4men
    64  Aljazeera
    65  4 (build of sticks)
    79  Gold (in a circle)
    80  Y Yesterday
    81  MTV
    82  VHR 71
    83  VIVA    72
    84  Alibi
    93  SKY Movies Select
    94  SKY Atlantic
    96  Discovery History   78 *
    97  Sc Discovery Science    79 *
    99  Discovery Home & Health 80 *
    100 Eden
    101 Comedy Channel
    102 Fox
    106 4E (E within 4)
    108 4More
    123 TCM Turner Classic Movies
    125 5*
    126 4Film   109 *
    135 NickJR
    137 Nickelodeon
    138 N TV Norge  100 *
    139 2 Bliss
    141 STV 1   91 *
    142 STV 2   104*
    143 4 Guld (in a star)  105 *
    146 2 Filmkanalen
    153 2
    157 4 Sport 119 *
    159 TV2 Lorry
    164 BBC News
    167 NRK 1   127 *
    168 NRK 2   128 *
    169 NRK 3   129 *
    170 3   140 + 141
    171 3 Puls Viasat
    175 3 tv3.se
    177 6 in circle
    179 4 in quadrant   125 *
    183 DR1 147 *
    184 DR2 148 *
    187 TV2 zulu *
    188 TV2 charlie *
    192 Dave
    197 At The Races
    198 Racing UK   Pure Racing Entertainment
    199 BT Sport1
    201 BT Sport2
    202 Box Nation
    204 TLC
    207 SETANTA IRELAND
    208 SETANTA SPORTS
    209 Aljazeera +6
    210 Aljazeera +7
    211 Aljazeera +8
    212 Aljazeera +9
    213 Aljazeera +5
    214 Bein Sports 1
    215 Bein Sports 2
    216 Bein Sports 3
    217 Bein Sports 4
    218 Bein Sports 10
    219 H History UK
    224 Virgin
    241 TNT HD
    252 RT Russia Today
    273 Gulli
    282 DR K    230 *
    283 DR Ultra    231 *
    286 6 on blue background
    290 H2
    291 DBC Drama
    292 Pick TV
    294 Euronews
    295 BBC News
    296 Cartoonito
    297 SKY Arts 2
    298 SKY Movies Disney
    299 Itv 3+1
    303 SKY Arts 1
    304 SKY Living
    305 Good Food
    309 TV2 Fri 261 *
    310 3+ Viasat   262 *
    315 FEM
    316 SKY Sports 1 HD
    317 SKY Sports 2 HD
    318 SKY Sports 4 HD
    319 SKY Sports News HD
    320 SKY Sports 3 HD
    321 SKY Sports F1 HD
    330 OSN Sports 3
    331 OSN Sports 4
    333 Fox Sports 1 HD
    336 TSN 2 HD
    337 Sports Net World HD
    339 Sports Net One HD
    340 Bein Sport HD
    341 CTV HD
    341 HBO HD
    343 NBA  TV High Definition
    344 NBC & N HD
    http://www.ntv.mx/res/content/tv/400.png
    http://www.ntv.mx/res/content/tv/478.png
    115 http://cloud.yousee.tv/static/img/logos/Large_TV2_ny.png
    136 http://cloud.yousee.tv/static/img/logos/Large_TV2_NEWS.png
    259 http://cloud.yousee.tv/static/img/logos/Large_DR_3.png
    249     http://cloud.yousee.tv/static/img/logos/IK_dk4.png
    """
    iconold =['71','72','115','136','259','249','99','303','412','245','267','298','227','141','125','127','128','129','119','105','104','91','100','109','78','79','80','306','56','55','310','115','235','140','240','138','231','131','230','261','137','148','262','147','413']
    iconnew=['82','83','a','b','c','d','139','204','141','56','315','44','44','170','179','167','168','169','157','143','142','141','138','126','96','97','99','44','44','43','43','155','287','170','294','187','283','171','282','309','188','184','310','183','183']
    i = 0
    r = ''
    while i < len(iconold) and r =='':
        if oldicon==iconold[i]:
            r = iconnew[i]
        i += 1
    #print r
    #r = ''
    #for i in oldicon:
    #   if xlate.has_key(str(i)):
    #       r += xlate[str(i)]
    #       print 'recordings.py icon(oldicon) %s--> icon= %s' %(str(repr(oldicon)),str(repr(r)))
    if r=='':
        r = ''
    elif r=='a':
        return 'http://cloud.yousee.tv/static/img/logos/Large_TV2_ny.png'
    elif r=='b':
        return 'http://cloud.yousee.tv/static/img/logos/Large_TV2_NEWS.png'
    elif r=='c':
        return 'http://cloud.yousee.tv/static/img/logos/Large_DR_3.png'
    elif r=='d':
        return 'http://cloud.yousee.tv/static/img/logos/IK_dk4.png'
    #   else:
    #       r += str(i)
    #print 'recordings.py icon(oldicon) %s--> icon= %s' %(str(repr(oldicon)),str(repr(r)))
    return r
    
def stringtoargument(txtstring):
    txtstring= txtstring.replace('\n','..NewLine..')   ### 2018-04-27
    txtstring= txtstring.replace(',','..Comma..')
    return txtstring
def argumenttostring(txtstring):
    txtstring= txtstring.replace('..NewLine..','\n')  ### 2018-04-27
    txtstring= txtstring.replace('..Comma..',',')
    return txtstring


def addRecordingPlanned(cat, startDate, endDate, recordname, alarmname, description, playchannel, DB='default'):
    startDate = parseDate(startDate).replace(second=0, microsecond=0)
    endDate   = parseDate(endDate).replace(second=0, microsecond=0)
    utils.logdev(module,'addRecordingPlanned DB= %r' % DB)
    if DB == 'default':
        utils.logdev(module,'addRecordingPlanned using default database')
        conn      = getConnection()
        conn.text_factory = str  ### 2016-04-30 TEST
        c         = conn.cursor()
    else:
        c = DB
    utils.logdev(module,'addRecordingPlanned(cat= %r, startDate= %r, endDate= %r, recordname= %r, alarmname= %r, description= %r, playchannel= %r)' % (cat, startDate, endDate, recordname, alarmname, description, playchannel))
    try:
        c.execute("INSERT OR REPLACE INTO recordings_adc(cat, name, start, end, alarmname, description, playchannel) VALUES(?, ?, ?, ?, ?, ?, ?)", [cat, recordname, str(startDate), str(endDate), alarmname, description, playchannel])
    except Exception, e:
            pass
            utils.logdev('addRecordingPlanned FAILED', 'cat= %r ERROR= %r' % (cat,e))
    if DB == 'default':
        conn.commit()
        c.close()

def updateRecordingPlanned(alarmname, name):
    #print 'recordings.py updateRecordingPlanned(alarmname= %s, name= %s)' %(repr(alarmname), repr(name))
    try:
        conn = getConnection()
        c    = conn.cursor()
        c4   = c.execute("SELECT * FROM recordings_adc WHERE alarmname=?",  [alarmname])
        recordingsSelected = c4.fetchall()
        if len(recordingsSelected) > 0:
            for index in range(0, len(recordingsSelected)): 
                cat       = recordingsSelected[index][0]
                nameOLD      = recordingsSelected[index][1]
                startDate = recordingsSelected[index][2].split('.')[0]  ###207-09-30
                endDate   = recordingsSelected[index][3].split('.')[0]  ###207-09-30
                alarmnameOLD = recordingsSelected[index][4]
                description = recordingsSelected[index][5]
                playchannel = recordingsSelected[index][6]
                c4.execute("DELETE FROM recordings_adc WHERE alarmname=?",  [alarmname])
                c4.execute("INSERT OR REPLACE INTO recordings_adc(cat, name, start, end, alarmname, description, playchannel) VALUES(?, ?, ?, ?, ?, ?, ?)", [cat, name, startDate, endDate, alarmname, description, playchannel])
        conn.commit()
        #print 'recordings.py conn.commit OK'
    except:
        pass
        #print 'recordings.py conn.commit failed!'
    c.close()
    xbmc.executebuiltin("Container.Refresh")

def delRecordingPlanned(cat, startDate, endDate, recordname):
    """
    try:
        xint = float(startDate)
        startDateX = datetime.fromtimestamp(xint)
        xint = float(endDate)
        endDateX = datetime.fromtimestamp(xint)
        #print 'delRecordingPlanned from timestamp'
    except:
        pass
    """
    ### recordings_adc(cat, name, start, end, alarmname, description, playchannel)
    conn = getConnection()
    c    = conn.cursor()
    utils.logdev(module,'delRecordingPlanned(cat= %r, startDate= %r, endDate= %r, recordname= %r)' % (cat, startDate, endDate, recordname))
    ###c4=c.execute("SELECT * FROM recordings_adc WHERE name=? and end=?", [recordname,endDate])
    ### RECURSIVEMARKER = 'Recursive:'
    ###if RECURSIVEMARKER in recordname:
    ### c4=c.execute("SELECT * FROM recordings_adc WHERE cat=? AND name=?", [cat, recordname])
    ###else:
    c4=c.execute("SELECT * FROM recordings_adc WHERE cat=? AND name=? AND start=? AND end=?", [cat, recordname, startDate, endDate])
    recordingsSelected = c4.fetchall()
    utils.logdev(module,'delRecordingPlanned(len(recordingsSelected= %r))' % (len(recordingsSelected)))
    for index in range(0, len(recordingsSelected)): 
        #cat       = recordingsSelected[index][0]
        name       = recordingsSelected[index][1]
        #startDate = recordingsSelected[index][2]
        endDateXX  = recordingsSelected[index][3]
        #print 'recordings.py endDate= %s, endDateXX = %s' % (str(repr(endDate)),str(repr(endDateXX)))
        alarmname = recordingsSelected[index][4]
        utils.logdev(module,'DELETE FROM recordings_adc WHERE alarmname= %r and end= %r' % (alarmname,endDateXX))
        c4.execute("DELETE FROM recordings_adc WHERE alarmname=? and end=?",  [alarmname,endDateXX])
        xbmc.executebuiltin('CancelAlarm(%s,True)' % alarmname)
    conn.commit()   
    c.close()

def modifyRecordingPlanned(cat, startDate, endDate, recordname, description):
    utils.logdev('modifyRecordingPlanned', '(cat= %r, startDate= %r, endDate= %r, recordname= %r, description= %r)' % (cat, startDate, endDate, recordname, description))
    startDate = parseDate(startDate)
    endDate   = parseDate(endDate)
    conn      = getConnection()
    c         = conn.cursor()
    recordingsSelected = c.fetchall()
    ###for rec in recordingsSelected:
    ### utils.logdevarray('modifyRecordingPlanned-recordingsSelected', repr(rec[0]))
    dialog = xbmcgui.Dialog()
    c1=c.execute("SELECT * FROM recordings_adc WHERE cat=? AND name=?", [cat,unicode(recordname, 'utf-8')])
    recordingsSelected = c1.fetchall()
    for rec in recordingsSelected:
        utils.logdevarray('modifyRecordingPlanned-recordingsSelected-1', repr(rec[0]))
    ##c2=c1.execute("SELECT * FROM recordings_adc WHERE name=?",  [unicode(recordname, 'utf-8')])
    ###c2=c1.execute("SELECT * FROM recordings_adc WHERE name=?",  [recordname])
    ###recordingsSelected = c2.fetchall()
    ###for rec in recordingsSelected:
    ### utils.logdevarray('modifyRecordingPlanned-recordingsSelected-2', repr(rec[0]))
    ###c3=c2.execute("SELECT * FROM recordings_adc WHERE start=?", [startDate])
    ###recordingsSelected = c3.fetchall()
    ###for rec in recordingsSelected:
    ### utils.logdevarray('modifyRecordingPlanned-recordingsSelected-3', repr(rec[0]))
    ###c4=c3.execute("SELECT * FROM recordings_adc WHERE end=?", [endDate])
    ###recordingsSelected = c4.fetchall()
    c4 = c1
    for rec in recordingsSelected:
        utils.logdevarray('modifyRecordingPlanned-recordingsSelected-4', repr(rec[0]))
    for index in range(0, len(recordingsSelected)): 
        cat         = recordingsSelected[index][0]
        name        = recordingsSelected[index][1]
        ###if TVguideNR == '0':  ##############################################################<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        startDateXX = parseDate(recordingsSelected[index][2])
        endDateXX   = parseDate(recordingsSelected[index][3])
        alarmname   = recordingsSelected[index][4]
        description = recordingsSelected[index][5]
        ### else:
        ###     startDateXX = parseDate(recordingsSelected[index][2])
        ###     endDateXX   = parseDate(recordingsSelected[index][3])
        ###     alarmname   = recordingsSelected[index][4]
        ###     description = recordingsSelected[index][5]
        ###utils.logdev(module,'cat= %r, name= %r, startDateXX= %r, endDateXX= %r, alarmname= %r, description= %r' % (cat, name, startDateXX, endDateXX, alarmname, description))
    if len(recordingsSelected) > 0:
        utils.logdev(module,'XX  name= %r, recordname= %r' % (name,recordname))
        recordname = unicode(name, 'utf-8')
        utils.logdev(module,'XXXXname= %r, recordname= %r' % (name,recordname))
        utils.logdev(module,'c4.execute(DELETE FROM recordings_adc WHERE alarmname= %r' % alarmname)
        c4.execute("DELETE FROM recordings_adc WHERE alarmname=?",  [alarmname])
        xbmc.executebuiltin('CancelAlarm(%s,True)' % alarmname)
        try:
            conn.commit()
            #print 'recordings.py conn.commit OK'
        except:
            pass
            #print 'recordings.py c4.commit failed!'
        c4.close()
        recordname = recordname.replace('[COLOR blue]','') # remove inactive marker
        recordname = recordname.replace('[COLOR green]','') # remove inactive marker
        recordname = recordname.replace('[COLOR orange]','') # remove inactive marker
        recordname = recordname.replace('[COLOR red]','') # remove inactive marker
        recordname = recordname.replace('[/COLOR]','')
        
        recordname = recordname +'AaAa' # marker to force change of date
        utils.logdev(module,'add(cat= %r, startDate= %r, endDate= %r, recordname= %r, description= %r)' % (cat, startDate, endDate, recordname, description))
        add(cat, startDate, endDate, recordname, description)
    else:
        dialog.ok(ADDONid + " Modify Recording planned [COLOR red]FAILED![/COLOR]", "Selected record? " + unicode(recordname, 'utf-8'),'', "How many selected: " + str(len(recordingsSelected)))
    try:
        conn.commit()
        #print 'recordings.py conn.commit OK'
    except:
        pass
        #print 'recordings.py conn.commit failed!'
    c.close()

