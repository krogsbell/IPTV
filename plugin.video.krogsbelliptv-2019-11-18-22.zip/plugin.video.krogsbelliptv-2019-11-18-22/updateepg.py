#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import calendar
import net
import json
import locking,utils
import recordings
import glob
import fnmatch
import definition
import shutil
import urllib2
import xmltodict
import base64
from operator import itemgetter

ADDON      = definition.getADDON()
ADDONname  = ADDON.getAddonInfo('name')
ADDONid    = ADDON.getAddonInfo('id')
args = sys.argv  ### args[1] == 'once' or 'hourly'
module = 'updateepg.py'
utils.logdev(module,'Start')
utils.logdev(module,'args: '+ repr(args))
datapath   = xbmc.translatePath(ADDON.getAddonInfo('profile'))
progpath   = ADDON.getAddonInfo('path')
referral = ADDON.getSetting('my_referral_link')
dateStringDummy = '20200625070000 +0100'

notify = ADDON.getSetting('notifyduringepgupdate')
if notify == 'true':
    notifyduringepgupdate = True
else:
    notifyduringepgupdate = False

def sleep(sleeptime):
    utils.logdev('sleep','sleep %r (sleeptime= %r)' % (module,sleeptime))
    xbmc.sleep(sleeptime)
       
def notnone(cat):
    if cat == None:
        return ''
    else:
        return cat

def logdev(module,infotext):
    utils.logdev(module,infotext) 

def notification(infotext):  
    if notifyduringepgupdate:
        utils.notification(infotext)
        
def testPrograms():
    try:  ### Get system timezone
        timezone = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Settings.GetSettingValue", "params": {"setting": "locale.timezone"}, "id": 1}')
        logdev(module,'Kodi timezone= %r' % timezone)
    except Exception, e:
            pass
            logdev(module,'Get timezone error= %r' % e)
    try:   ### Test if ffmpeg is installed
        if utils.runCommandTest('ffmpeg'):
            logdev(module,'FFMPEG installed!')
    except Exception, e:
            pass
            logdev(module,'Get ffmpeg error= %r' % e)
    try:   ### Test if rtmpdump is installed
        if utils.runCommandTest('rtmpdump'):
            logdev(module,'RTMPDUMP installed!')
    except Exception, e:
            pass
            logdev(module,'Get rtmpdump error= %r' % e)
    try:   ### Test if 7zip is installed
        if utils.runCommandTest('7z'):
            logdev(module,'7z installed!')
        else:
            logdev(module,'7z NOT installed!')
    except Exception, e:
            pass
            logdev(module,'Get 7z error= %r' % e)
    ### xarchiver -v
    try:   ### Test if xarchiver -v is installed
        if utils.runCommandTest('xarchiver -v'):
            logdev(module,'xarchiver -v installed!')
        else:
            logdev(module,'xarchiver -v NOT installed!')
    except Exception, e:
            pass
            logdev(module,'Get xarchiver -v error= %r' % e)

            
def GetFromDict(link,number=0):           
    try:  ### Get original descriptions from enigma2 link
        logdev(module,'Read enigma2 link number= %r'% number)
        """
        ###link = 'http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')
        enigma2 i, (key= u'items', value= OrderedDict([(u'playlist_name', u'My_Bouquet_Name'), (u'category', OrderedDict([(u'category_id', u'1'), (u'category_title', u'My_Bouquet_Name')])), (u'channel', [OrderedDict([(u'title', u'Live Streams'), (u'description', u'Live Streams Category'), (u'category_id', u'0'), (u'playlist_url', u'http://www.e900x.com:8000/enigma2.php?username=xxx&password=yyy&type=get_live_categories')]), OrderedDict([(u'title', u'Vod'), (u'description', u'Video On Demand Category'), (u'category_id', u'1'), (u'playlist_url', u'http://www.e900x.com:8000/enigma2.php?username=xxx&password=yyy&type=get_vod_categories')]), OrderedDict([(u'title', u'TV Series'), (u'description', u'TV Series Category'), (u'category_id', u'2'), (u'playlist_url', u'http://www.e900x.com:8000/enigma2.php?username=xxx&password=yyy&type=get_series_categories')])])])): 
        """
        ROQTVusername = ADDON.getSetting('user')
        if link != '' :
            
            logdev(module,'GetFromDict(link)= %r' % link)
            
            file = urllib2.urlopen(link)
            data = file.read()
            file.close()
            data = data.replace('\n','').replace('<description/>','<description></description>')
            
            for titem in ['title','description']:
                
                data = data.split('<'+titem+'>')
                
                i=0
                newdata= ''
                for part in data:
                    
                    if i==0:
                        newdata+=part
                        
                        i+=1
                        
                    else:
                        part=part.split('</'+titem+'>',1)
                        
                        if not part[0] == None:
                            
                            if titem == 'title':
                                
                                decodedtext = recordings.latin1_to_ascii_force(base64.b64decode(part[0], '-_').replace('&','&amp;')).replace('<<','XX')
                            else:
                                decodedtext = recordings.latin1_to_ascii_force(base64.b64decode(part[0], '-_').replace('&','&amp;')).replace('<<','XX')
                                
                        else:
                            utils.notification('Missing channel: ' + repr(part))
                            decodedtext=''
                            
                        newdata+='<'+titem+'>' + decodedtext +'</'+titem+'>' + part[1]
                        
                data = newdata
            
            channelsxml = os.path.join(datapath, 'channelsxml')+ str(number)  + '.xml'
            LF = open(channelsxml, 'w')
            LF.write(newdata)
            LF.close()
            
            try:
                newdata = newdata.replace('*#*>','*#*').replace('<*#*','*#*')  ### SPORT BEIN ARABIA fix
                data = xmltodict.parse(newdata)
            except Exception, e:
                pass
                logdev(module,'Error in enigma2 xmltodict.parse(newdata)1: #%r\n%r'% (number,e))
                data = ''
            
            channelsdict = os.path.join(datapath, 'channelsdict')  + str(number)+ '.dict'
            LF = open(channelsdict, 'w')
            LF.write(repr(data))
            LF.close()
    except Exception, e:
        pass
        logdev(module,'Error in enigma2 xmltodict.parse(newdata)2: #%r\n%r'% (number,e))
        data = ''    
    logdev(module,'channelsdict.dict transformed: %r' % data)
    return data
            
def GetOriginalDescriptionsFromDict(): 
    """
    ###link = 'http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')
    enigma2 i, (key= u'items', value= OrderedDict([(u'playlist_name', u'My_Bouquet_Name'), (u'category', OrderedDict([(u'category_id', u'1'), (u'category_title', u'My_Bouquet_Name')])), (u'channel', [OrderedDict([(u'title', u'Live Streams'), (u'description', u'Live Streams Category'), (u'category_id', u'0'), (u'playlist_url', u'http://www.e900x.com:8000/enigma2.php?username=xxx&password=yyy&type=get_live_categories')]), OrderedDict([(u'title', u'Vod'), (u'description', u'Video On Demand Category'), (u'category_id', u'1'), (u'playlist_url', u'http://www.e900x.com:8000/enigma2.php?username=xxx&password=yyy&type=get_vod_categories')]), OrderedDict([(u'title', u'TV Series'), (u'description', u'TV Series Category'), (u'category_id', u'2'), (u'playlist_url', u'http://www.e900x.com:8000/enigma2.php?username=xxx&password=yyy&type=get_series_categories')])])]))

    OrderedDict([(u'items', OrderedDict([(u'playlist_name', u'SubCategory [ My_Bouquet_Name ]'), (u'category', OrderedDict([(u'category_id', u'1'), (u'category_title', u'SubCategory [ My_Bouquet_Name ]')])), (u'channel', [OrderedDict([(u'title', u'All'), (u'description', u'TV Series Category [ ALL ]'), (u'category_id', u'0'), (u'playlist_url', u'http://www.e900x.com:8000/enigma2.php?username=xxx&password=yyy&type=get_series&cat_id=0')]), OrderedDict([(u'title', u'English Series'), (u'description', u'TV Series Category'), (u'category_id', u'45'), (u'playlist_url', u'http://www.e900x.com:8000/enigma2.php?username=xxx&password=yyy&type=get_series&cat_id=45')])])]))])
    """          
    try:  ### Get original descriptions from enigma2 link
        logdev(module,'Read enigma2 link')
        number=0
        ###link = 'http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')
        ROQTVusername = ADDON.getSetting('user')
        if ROQTVusername.lower() != 'none':
            link = definition.getBASEURL() + '/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')
            utils.logdev(module,'enigma2 link= %r' % link)
            data = GetFromDict(link,number=number)
            number += 1
            
            channelsdict = os.path.join(datapath, 'channelsdict')  + '.dict'
            LF = open(channelsdict, 'w')
            LF.write(repr(data))
            LF.close()
        
            logdev(module,'channelsdict.dict transformed: %r' % data)
            for i, (key, value) in enumerate(data.iteritems()):
                utils.logdev(module,'enigma2 i, (key= %r, value= %r): ' % (key, value))
                for i1, (key1, value1) in enumerate(value.iteritems()):
                    utils.logdev(module,'enigma2 i1, (key1= %r, value1= %r): ' % (key1, value1))
                    if key1 == 'channel':
                        for d in value1:
                            if 'playlist_url' in d and not d['playlist_url'] == None:
                                playlist_url=d['playlist_url']
                                data4 = GetFromDict(playlist_url,number=number)
                                number += 1
                                for k, (key4, value4) in enumerate(data4.iteritems()):
                                    logdev(module,'enigma2 k, (key4= %r, value4= %r): ' % (key4, value4))
                                    for k1, (key5, value5) in enumerate(value4.iteritems()):
                                        utils.logdev(module,'enigma2 k1, (key5= %r, value5= %r): ' % (key5, value5))
                                        logdev(module,'key5?channel %r' % key5)
                                        if key5 == 'channel':
                                            logdev(module,'key5==channel %r'% key5)
                                            for d5 in value5:
                                                logdev(module,'d5= %r'% d5)
                                                if d5['title'] == 'All':
                                                    playlist_url5=d5['playlist_url']
                                                    logdev(module,'enigma2 k1, (key5= %r, value5= %r, number= %r)' % (key5, playlist_url5, number))
                                                    data1 = GetFromDict(playlist_url5,number=number)
                                                    number += 1
                                                    for j, (key2, value2) in enumerate(data1.iteritems()):
                                                        ###utils.logdev(module,'enigma2 j, (key2= %r, value2= %r)' % (key2, value2))
                                                        for j1, (key3, value3) in enumerate(value2.iteritems()):
                                                            ###logdev(module,'enigma2 j1, (key3= %r, value3= %r)' % (key3, value3))
                                                            if key3 == 'channel':
                                                                for d3 in value3:
                                                                    if 'stream_url' in d3 and not d3['stream_url'] == None:
                                                                        StreamURL=d3['stream_url'].replace('![CDATA[','',1).replace(']]','',1)
                                                                        utils.logdev(module,'enigma2 d3, (StreamURL= %r)' % (StreamURL))
                                                                        if not d3['desc_image'] == None:
                                                                            DescURL=d3['desc_image'].replace('![CDATA[','',1).replace(']]','',1)
                                                                        else:
                                                                            DescURL = ''
                                                                        try:
                                                                            Description=d3['description']
                                                                            if isinstance(Description, dict):
                                                                                try:
                                                                                    Description = Description['em']+'\n'+Description['#text']
                                                                                except Exception,e:
                                                                                    pass
                                                                                    Description = repr(Description) + repr(e)  ### 2019-03-31
                                                                            elif not isinstance(Description, unicode):
                                                                                if not (Description == None or Description == ''):
                                                                                    Description='Unknown description type: ' + repr(type(Description))
                                                                                else: 
                                                                                    Description = repr(Description)
                                                                            
                                                                        except Exception, e:
                                                                            pass
                                                                            logdev(module,'Error in get enigma2 Description: ' + repr(e))
                                                                            EPGimportERRORS('Error in get enigma2 Description: ' + repr(e))
                                                                            Description= 'Error in get enigma2 Description: ' + repr(e)
                                                                            
                                                                        utils.logdev(module,'Test enigma2 Title= %s, Stream= %s, DescURL= %s, Category_ID= %s, Description= %s' % (d3['title'],StreamURL,DescURL,d3['category_id'],Description))
                                                                        catThis = recordings.catFromUrl(StreamURL)
                                                                        if ADDON.getSetting('user') in catThis :
                                                                            catThis = '#'
                                                                        utils.logdev(module,'catThis= %r' % catThis)
                                                                        if recordings.isChannelVisible(catThis) or catThis == '#':
                                                                            utils.logdev(module,'Visible catThis= %r' % catThis)
                                                                            
                                                                            try:
                                                                                
                                                                                if catThis != '#' :
                                                                                    recordings.setChannelDescription(catThis,Description)   ### 2019-02-11 Save descriptions in onlinE DATABASE
                                                                            except Exception, e:
                                                                                pass
                                                                                utils.logdev(module,'Error in get enigma2: ' + repr(e))
                                                                                EPGimportERRORS('Error in get enigma2: ' + repr(e))
                                                        
    except Exception, e:
        pass
        utils.logdev(module,'Error in getting enigma2 Channels: ' + repr(e))
        EPGimportERRORS('Error in getting enigma2 Channels: ' + repr(e))
    utils.logdev(module,'Test enigma2  22')
    ### END INSERT setView('movies', 'main-view')             
            
tz = ADDON.getSetting('AdjustTVguideTimeZoneOffset')
if tz == '':
    TimeZone = 0
else:
    TimeZone = int(tz)  
tzx = ADDON.getSetting('AdjustTVguideTimeZoneOffsetExtraXML')

if tzx == '':
    TimeZoneXML = 0
else:
    TimeZoneXML = int(tzx)  
logdev(module,'TimeZone= %r, TimeZoneXML= %r' % (TimeZone,TimeZoneXML))   
datapanel = []
dataepg = []
data= []
EPGgenerator = ''
ChannelFile = ''
channels = 0
programs = 0

def EPGimportERRORS(ERROR):
    utils.logdev(module,'EPGimportERRORS= %r' % ERROR)
    NoERROR = '[COLOR green]No Errors[/COLOR]'
    ERRORS  = '[COLOR red]Error(s)[/COLOR]'
    if ERROR == '':
        ERROR = NoERROR
        utils.logdev(module,'EPGimportERRORS= %r' % ERROR)
    else:
        ERROR = repr(ERROR)
        ERROR = (ERROR + ', ' + ADDON.getSetting('lastEPGimportERRORS')).replace(NoERROR,ERRORS)
        utils.logdev(module,'EPGimportERRORS= %r' % ERROR)
    ADDON.setSetting('lastEPGimportERRORS',ERROR)

def parse_date(dateString):
    return datetime.fromtimestamp(time.mktime(time.strptime(dateString.encode('utf-8', 'replace'), "%Y-%m-%d %H:%M:%S")))
    
def parse_date_string(dateString):
    try:
        ###ValueError: time data '20170625070000 +0100' does not match format '%Y%m%d%H%M%S z'
        ###return time.mktime(time.strptime(dateString.encode('utf-8', 'replace'), '%Y%m%d%H%M%S Z'))  ### UTC time
        ###logdev('resulttime0',repr(dateString))
        dt = dateString.split(' ')
        if int(dt[0]) < 0:
            dateStringOLD = dateString
            logdev('resulttime0',repr(dateString))
            logdev('parse_date_string0','dt[0]= %r' % dt[0])
            dateString = dateStringDummy
            dt = dateString.split(' ')
            resulttime = time.mktime(time.strptime(dt[0], '%Y%m%d%H%M%S'))
            logdev('parse_date_string1a','dt= %r' % dt)
            EPGimportERRORS('ERROR in date HTML: %r using dummy time: %r' % (dateStringOLD,dateString))
        resulttime = time.mktime(time.strptime(dt[0], '%Y%m%d%H%M%S'))
        ###logdev('resulttime1',repr(resulttime))
        resulttime =  int(resulttime) - (int(dt[1])/100 - TimeZone)*3600
        ###logdev('resulttime2',repr(resulttime))
        ###logdev('resulttime3',repr(datetime.fromtimestamp(resulttime)))
        return str(resulttime)
    except Exception,e:
        pass
        return '%r ERROR: %r' % (dateString,e)
    
def parse_date_stringXML(dateString):
    dt = dateString.split(' ')
    if int(dt[0]) < 0:
        dateStringOLD = dateString
        logdev('resulttime0',repr(dateString))
        logdev('parse_date_string0','dt[0]= %r' % dt[0])
        dateString = dateStringDummy
        dt = dateString.split(' ')
        resulttime = time.mktime(time.strptime(dt[0], '%Y%m%d%H%M%S'))
        logdev('parse_date_string1a','dt= %r' % dt)
        EPGimportERRORS('ERROR in date XML: %r using dummy time: %r' % (dateStringOLD,dateString))
    resulttime = time.mktime(time.strptime(dt[0], '%Y%m%d%H%M%S'))
    resulttime =  int(resulttime) - (int(dt[1])/100 - TimeZoneXML)*3600
    return str(resulttime)

def getDict(dictA,name,ntype='',dtype=''):
    ###if ADDON.getSetting('KeyErrorStop') != '':
    ### return ''
    element = ''
    en = "KeyError('" + name + "',)"
    ex = "KeyError('" + ntype + "',)"
    ey = "KeyError('" + dtype + "',)"
    if name == 'sub_title':
        return repr(dictA) + ' \n' + en  ### Debug option
    try:
        if dtype != '' and ntype != '':
            elementd = dictA[name][dtype]
            element = dictA[name][ntype]
            ###if type(element) in (list, tuple, dict):
            ### for elem in element:
            ###     return elem
            ###else:
            ###return repr(element)
            return element
    except Exception, e:
        pass
        err = repr(e)
        if err==en:
            return ''
        if err==ey:
            return 'ey1'
        if err==ex:
            return 'ex1'
    try:
        if ntype != '':
            element = dictA[name][ntype]
            ###if type(element) in (list, tuple, dict):
            ### for elem in element:
            ###     return elem
            ###else:
            ###return repr(element)
            return element
    except Exception, e:
        pass
        err = repr(e)
        if err==en:
            return ''
        if err==ex:
            return 'ex2'
    try:
        element = dictA[name]
        ###if type(element) in (list, tuple, dict):
        ### for elem in element:
        ###     return elem
        ###else:
        ###return repr(element)
        return element
    except Exception, e:
        pass
        err = repr(e)
        if err==en:
            return 'en3'
    return 'nothing'

def getEPGChannel(cat):
    try:
        logdev(module,'getEPGChannel(cat)')
        conn = recordings.getConnection()
        c = conn.cursor()
        c.execute("SELECT DISTINCT title, epg_channel, source FROM channels WHERE id=?", [cat])
        favorites = c.fetchall()
        if len(favorites) > 0:
            result = [favorites[0][0],favorites[0][1],favorites[0][2]]  ### Title, EPG Channel
        else:
            result = ''
        c.close() 
        return result
    except Exception, e:
        pass
        notification('Error in getEPGChannel(cat) '+ cat + ' \n' + repr(e))
    
def setEPGChannel(cat,channel):
    try:
        logdev(module,'setEPGChannel(cat)')
        conn = recordings.getConnection()
        c = conn.cursor()
        c.execute("SELECT * FROM channels WHERE id=?", [cat])
        favorites = c.fetchall()
        result = []

        for index in range(0, len(favorites)):
            ch = []
            for i in range(0, len(favorites[index])):
                if favorites[index][i] == None:
                    ch.append('')
                else:
                    ch.append(favorites[index][i])
            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [ch[0], ch[1], ch[2], ch[3], ch[4], ch[5], ch[6], ch[7], ch[8], channel,ch[10],ch[11],ch[12]])
        if result == []:
            logdev(module,'EPG not found for cat= %r' % cat)
        conn.commit()
        
        c.execute("SELECT * FROM channelsRecursive WHERE id=?", [cat])
        favorites = c.fetchall()
        result = []

        for index in range(0, len(favorites)):
            ch = []
            for i in range(0, len(favorites[index])):
                if favorites[index][i] == None:
                    ch.append('')
                else:
                    ch.append(favorites[index][i])
            c.execute("INSERT OR REPLACE INTO channelsRecursive(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [ch[0], ch[1], ch[2], ch[3], ch[4], ch[5], ch[6], ch[7], ch[8], channel,ch[10],ch[11],ch[12]])
        if result == []:
            logdev(module,'EPG not found for cat= %r' % cat)
        conn.commit()
        
        c.close() 
    except Exception, e:
        pass
        notification('Error in setEPGChannel(cat) '+ cat + ' \n' + repr(e))

def getEPGnow(cat):
    ###now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###now= datetime.today()
    ###logdev(module,'getEPGnow(cat)')
    conn = recordings.getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE id=?", [cat])
    favorites = c.fetchall()
    result = []
    for index in range(0, len(favorites)):
        if result == []:
            ch = []
            for i in range(0, len(favorites[index])):
                if favorites[index][i] == None:
                    ch.append('')
                else:
                    ch.append(favorites[index][i])
            ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
            name = ch[1]
            tv_archive = ch[8]  ### Holds duration in days - 0 means no archive
            try:
                if type(tv_archive) != int:
                    tv_archive = 0
                default_tv_archive_duration = int(ADDON.getSetting('tv_archive_duration'))
                if type(default_tv_archive_duration) != int:
                    default_tv_archive_duration = 2
                tv_archive_duration = tv_archive
            except:
                pass
                tv_archive = 0
                default_tv_archive_duration = 2
                tv_archive_duration = default_tv_archive_duration
            if tv_archive_duration > default_tv_archive_duration:
                ADDON.setSetting('tv_archive_duration',str(tv_archive_duration))
            if tv_archive > 0:
                tv_archive = 1
            epg_channel_id = ch[9].replace(' (R)','')  ### Ignore Recursive marker
            result = [recordings.getEPGProgramsNow(epg_channel_id), name, tv_archive, tv_archive_duration, epg_channel_id]
    if result == []:
        logdev(module,'EPG not found for cat= %r' % cat)
    c.close() 
    return result
    
def getEPG(cat):
    try:
        ###now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        ###now= datetime.today()
        ###logdev(module,'getEPG(cat)')
        conn = recordings.getConnection()
        c = conn.cursor()
        c.execute("SELECT * FROM channels WHERE id=? AND visible=1", [cat])
        favorites = c.fetchall()
        result = []
        for index in range(0, len(favorites)):
            if result == []:
                ch = []
                for i in range(0, len(favorites[index])):
                    if favorites[index][i] == None:
                        ch.append('')
                    else:
                        ch.append(favorites[index][i])
                ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
                name = ch[1]
                tv_archive = ch[8]  ### Holds duration in days - 0 means no archive
                if type(tv_archive) != int:
                    tv_archive = 0
                try:
                    default_tv_archive_duration = int(ADDON.getSetting('tv_archive_duration'))
                    if type(default_tv_archive_duration) != int:
                        default_tv_archive_duration = 2
                except:
                    pass
                    default_tv_archive_duration = 2
                tv_archive_duration = tv_archive
                if tv_archive_duration > default_tv_archive_duration:
                    ADDON.setSetting('tv_archive_duration',str(tv_archive_duration))
                if tv_archive > 0:
                    tv_archive = 1
                epg_channel_id = ch[9].replace(' (R)','')  ### Ignore Recursive marker
                result = [recordings.getEPGPrograms(epg_channel_id), name, tv_archive, tv_archive_duration, epg_channel_id]
        if result == []:
            logdev(module,'EPG not found for cat= %r' % cat)
        c.close() 
        return result
    except Exception, e:
        pass
        logdev(module,'Error in getEPG!\n' + repr(e))
    return []
    """
    ### Find name, tv_archive, tv_archive_duration, epg_channel_id in database... 2017-07-14
    linkpanel = 'http://roq-tv.net:25461/panel_api.php?username=' +ROQuser+ '&password=' +ROQpass
    file = urllib2.urlopen(linkpanel)
    datapanel = file.read()
    file.close()
    try:
        datapanel = json.loads(datapanel)
        name = datapanel['available_channels'][cat]['name']
        tv_archive = datapanel['available_channels'][cat]['tv_archive']
        tv_archive_duration = datapanel['available_channels'][cat]['tv_archive_duration']
        epg_channel_id = datapanel['available_channels'][cat]['epg_channel_id']
    except Exception, e:
        pass
        ### or Find epg_channel_id based on cat....
        notification('Error in getting '+ ADDONid + ' info or your channel is from XML file!\n' + repr(e))
        return ''
    
    return [recordings.getEPGPrograms(epg_channel_id), name, tv_archive, tv_archive_duration, epg_channel_id]
    """
    """
    httplinkEPG = 'http://roq-tv.net:25461/xmltv.php?username=' +ROQuser+ '&password=' +ROQpass
    file = urllib2.urlopen(httplinkEPG)
    dataepg = file.read()
    file.close()
    try:
        dataepg = xmltodict.parse(dataepg)
    except Exception, e:
        pass
        notification('Error in EPG file '+ httplinkEPG + ' \n' + repr(e))
        return ''
    try:
        epg = dataepg['tv']['programme']
        logdev(module,repr(dataepg['tv']['programme']))
    except Exception, e:
        pass
        notification('Error in EPG programme '+ httplinkEPG + ' \n' + repr(e))
        return ''
    return
    """
    
def isExtKnown(infile):
    ffmpegoutputtype = ADDON.getSetting('ffmpegoutputtype').lower()
    infileext = infile.lower().rsplit('.',1)[-1]
    ###utils.logdev(module,'infileext= %r, ffmpegoutputtype= %r' % (infileext, ffmpegoutputtype))
    if infileext == ffmpegoutputtype:
        return True
    extorgcollection = ADDON.getSetting('extorgcollection').lower().split(',')
    if infileext in extorgcollection:
    ###if infile[-3:].lower()=='.ts' or infile[-4:].lower()=='.mp4' or infile[-4:].lower()=='.mkv' or infile[-4:].lower()== '.avi' or infile[-4:].lower() == '.m4v' or infile[-4:].lower()=='.flv' or infile[-ffmpegoutputtypelen:].lower()==ffmpegoutputtype:
        return True
    else:
        return False
    
def find_files(directory, pattern):
    for root, dirs, files in os.walk(directory):
        for basename in files:
            if fnmatch.fnmatch(basename, pattern):
                filename = os.path.join(root, basename)
                yield filename
                
def FindCommands(c,folderpath,archive):
    commands = ['rename','move','movetofolder','delete']
    try:
        ### RENAME command
        c.execute("SELECT * FROM files WHERE archive=? AND command=?" , [archive,'rename'])
        channels = c.fetchall()
        utils.logdev(module,'FindCommands rename archive= %r, count= %r' % (archive,len(channels)))
        x = len(channels)
        if x > 0:
            utils.notificationforced('Rename ' + str(x) + ' records in '+archive.lower()+': ', time = 1)
            for chan in channels:
                ###c.execute("INSERT OR REPLACE INTO files(filename, ext, path, video, description, size, archive, updated, created, updatedHuman, command, options) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [filename, chan[1], chan[2], chan[3], chan[4], chan[5], archive, nowTS, chan[8], humantime(nowTS), command, options])
                try:    ### Rename information and subtitles if they are available
                    urlbase = chan[0] 
                    if chan[1] != '':
                        fileext = '.' + chan[1]
                    else:
                        fileext = ''
                    if archive == 'L':
                        urldirectorypath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_path')))
                    else:
                        if ADDON.getSetting('record_archive_path_enable') == 'true':
                            urldirectorypath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_archive_path')))
                        else:
                            urldirectorypath = ''
                    path = chan[2]
                    if path != '':
                        urldirectorypath = os.path.join(urldirectorypath,path)   
                    if not os.path.exists(urldirectorypath):
                        os.makedirs(urldirectorypath)    
                    utils.logdev(module,'FindCommands rename archive= %r, urldirectorypath= %r' % (archive, urldirectorypath))
                    urlnewi = chan[11]
                    if urlnewi != '':
                        urlnewi = recordings.latin1_to_ascii_force(urlnewi)   ### use only acceptable characters
                        urlnewi = ' '.join(urlnewi.split())  ## Remove doublespaces etc
                        urlnew = os.path.join(urldirectorypath,urlnewi)
                        pathofdestination = os.path.dirname(urlnew)
                        utils.logdev(module,'pathofdestination= %r' % pathofdestination)
                        if not os.path.exists(pathofdestination):
                            os.makedirs(pathofdestination)  
                        utils.logdev(module,'urlnew= %r' % urlnew)
                        urlbase = os.path.join(urldirectorypath,urlbase)
                        utils.logdev(module,'urlbase= %r' % urlbase)
                        utils.logdev(module,'rename urlbase+fileext= %s, urlnew+fileext= %s' % (urlbase+fileext, urlnew+fileext))
                        urlbase = urlbase.replace('aMp ','& ').replace('xXx','+')   ### 2019-03-17
                        ###os.rename(urlbase+fileext,urlnew+fileext)
                        shutil.move(urlbase+fileext,urlnew+fileext)
                        try:
                            shutil.move(urlbase+'.txt',urlnew+'.txt')
                        except Exception,e:
                            pass
                            utils.logdev(module,'Rename error %r' % e)
                        try:
                            shutil.move(urlbase+'.srt',urlnew+'.srt')
                        except Exception,e:
                            pass
                            utils.logdev(module,'Rename error %r' % e)
                        try:
                            shutil.move(urlbase+'.en.srt',urlnew+'.en.srt')
                        except Exception,e:
                            pass
                            utils.logdev(module,'Rename error %r' % e)
                        try:
                            shutil.move(urlbase+'.da.srt',urlnew+'.da.srt')
                        except Exception,e:
                            pass
                            utils.logdev(module,'Rename error %r' % e)
                        try:
                            shutil.move(urlbase+'.nfo',urlnew+'.nfo')
                        except Exception,e:
                            pass
                            utils.logdev(module,'Rename error %r' % e)
                        try:
                            shutil.move(urlbase+'.log',urlnew+'.log')
                        except Exception,e:
                            pass
                            utils.logdev(module,'Rename error %r' % e)
                except Exception,e:
                    pass
                    utils.logdev(module,'Rename error %r' % e)
        else:
            utils.logdev(module,'FindCommands rename - no records found!')
        
        ### MOVE command
        c.execute("SELECT * FROM files WHERE archive=? AND command=?" , [archive,'move'])
        channels = c.fetchall()
        utils.logdev(module,'FindCommands move to/from archive= %r, count= %r' % (archive,len(channels)))
        x = len(channels)
        if x > 0:
            utils.notificationforced('Move ' + str(x) + ' records in '+archive.lower()+': ', time = 1)
            for chan in channels:
                ###c.execute("INSERT OR REPLACE INTO files(filename, ext, path, video, description, size, archive, updated, created, updatedHuman, command, options) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [filename, chan[1], chan[2], chan[3], chan[4], chan[5], archive, nowTS, chan[8], humantime(nowTS), command, options])
                try:    ### Rename information and subtitles if they are available
                    urlbase = chan[0] 
                    if chan[1] != '':
                        fileext = '.' + chan[1]
                    else:
                        fileext = ''
                    if archive == 'L':
                        urldirectorypath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_path')))
                        if ADDON.getSetting('record_archive_path_enable') == 'true':
                            urldirectorydestinationpath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_archive_path')))
                        else:
                            urldirectorydestinationpath = ''
                    else:
                        if ADDON.getSetting('record_archive_path_enable') == 'true':
                            urldirectorypath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_archive_path')))
                        else:
                            urldirectorypath = ''
                        urldirectorydestinationpath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_path')))
                    path = chan[2]
                    if path != '':
                        urldirectorypath = os.path.join(urldirectorypath,path)   
                        urldirectorydestinationpath = os.path.join(urldirectorydestinationpath,path)   
                    if not os.path.exists(urldirectorypath):
                        os.makedirs(urldirectorypath)   
                    if not os.path.exists(urldirectorydestinationpath):
                        os.makedirs(urldirectorydestinationpath)   
                    utils.logdev(module,'FindCommands move to/from archive= %r, urldirectorypath= %r' % (archive, urldirectorypath))
                    utils.logdev(module,'FindCommands move to/from archive= %r, urldirectorydestinationpath= %r' % (archive, urldirectorydestinationpath))
                    urlnewi = chan[11]
                    if urlnewi != '':
                        urlnewi = recordings.latin1_to_ascii_force(urlnewi)   ### use only acceptable characters
                        urlnewi = ' '.join(urlnewi.split())  ## Remove doublespaces etc
                        urlnew = os.path.join(urldirectorydestinationpath,urlnewi)
                        utils.logdev(module,'urlnew= %r' % urlnew)
                        urlbase = os.path.join(urldirectorypath,urlbase)
                        utils.logdev(module,'urlbase= %r' % urlbase)
                        utils.logdev(module,'move urlbase+fileext= %s, urlnew+fileext= %s' % (urlbase+fileext, urlnew+fileext))
                        shutil.move(urlbase+fileext,urlnew+fileext)
                        try:
                            shutil.move(urlbase+'.txt',urlnew+'.txt')
                        except Exception,e:
                            pass
                            utils.logdev(module,'move error %r' % e)
                        try:
                            shutil.move(urlbase+'.srt',urlnew+'.srt')
                        except Exception,e:
                            pass
                            utils.logdev(module,'move error %r' % e)
                        try:
                            shutil.move(urlbase+'.en.srt',urlnew+'.en.srt')
                        except Exception,e:
                            pass
                            utils.logdev(module,'move error %r' % e)
                        try:
                            shutil.move(urlbase+'.da.srt',urlnew+'.da.srt')
                        except Exception,e:
                            pass
                            utils.logdev(module,'move error %r' % e)
                        try:
                            shutil.move(urlbase+'.nfo',urlnew+'.nfo')
                        except Exception,e:
                            pass
                            utils.logdev(module,'move error %r' % e)
                        try:
                            shutil.move(urlbase+'.log',urlnew+'.log')
                        except Exception,e:
                            pass
                            utils.logdev(module,'move error %r' % e)
                except Exception,e:
                    pass
                    utils.logdev(module,'move error %r' % e)
                
        else:
            utils.logdev(module,'FindCommands move - no records found!')
        
        ### MOVE to FOLDER command
        c.execute("SELECT * FROM files WHERE archive=? AND command=?" , [archive,'movetofolder'])
        channels = c.fetchall()
        utils.logdev(module,'FindCommands movetofolder= %r, count= %r' % (archive,len(channels)))
        x = len(channels)
        if x > 0:
            utils.notificationforced('Move to folder: ' + str(x) + ' records in '+archive.lower()+': ', time = 1)
            for chan in channels:
                ###c.execute("INSERT OR REPLACE INTO files(filename, ext, path, video, description, size, archive, updated, created, updatedHuman, command, options) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [filename, chan[1], chan[2], chan[3], chan[4], chan[5], archive, nowTS, chan[8], humantime(nowTS), command, options])
                try:    
                    urlbase = chan[0] 
                    if chan[1] != '':
                        fileext = '.' + chan[1]
                    else:
                        fileext = ''
                    if archive == 'L':
                        urldirectorypath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_path')))
                        if ADDON.getSetting('record_archive_path_enable') == 'true':
                            urldirectorydestinationpath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_archive_path')))
                        else:
                            urldirectorydestinationpath = ''
                    else:
                        if ADDON.getSetting('record_archive_path_enable') == 'true':
                            urldirectorypath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_archive_path')))
                            urldirectorydestinationpath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_path')))
                        else:
                            urldirectorypath = ''
                            urldirectorydestinationpath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_path')))
                    path = chan[2]
                    if path != '':
                        urldirectorypath = os.path.join(urldirectorypath,path)   
                        urldirectorydestinationpath = os.path.join(urldirectorydestinationpath,path)   
                    if not os.path.exists(urldirectorypath):
                        os.makedirs(urldirectorypath)   
                    if not os.path.exists(urldirectorydestinationpath):
                        os.makedirs(urldirectorydestinationpath)   
                    utils.logdev(module,'FindCommands move to folder= %r, urldirectorypath= %r' % (archive, urldirectorypath))
                    utils.logdev(module,'FindCommands move to folder= %r, urldirectorydestinationpath= %r' % (archive, urldirectorydestinationpath))
                    options = chan[11]
                    urlnewi = options
                    utils.logdev(module,'FindCommands move to folder urlnewi= %r, urlnewi[:2]= %r, urlnewi[2:]= %r' % (urlnewi, urlnewi[:2], urlnewi[2:]))
                    if urlnewi[:2] == 'l:':
                        urldirectorydestinationpath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_path')))
                    elif urlnewi[:2] == 'a:':
                        if ADDON.getSetting('record_archive_path_enable') == 'true':
                            urldirectorydestinationpath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_archive_path')))
                        else:
                            urldirectorydestinationpath = ''
                    else:
                        utils.logdev(module,'movetofolder error in options: %r' % options)
                        urldirectorydestinationpath = ''
                        urlnewi = ''
                    pathnew = urlnewi[2:]
                    if '\\' in urldirectorydestinationpath:
                        pathnew = pathnew.replace('/','\\')
                    urldirectorydestinationpath = os.path.join(urldirectorydestinationpath,pathnew)
                    if not os.path.exists(urldirectorydestinationpath):
                        os.makedirs(urldirectorydestinationpath)      ### 2019-09-11 Greate new folder if necessary
                    if urlnewi != '':
                        urlnew = os.path.join(urldirectorydestinationpath,urlbase)
                        utils.logdev(module,'urlnew= %r' % urlnew)
                        urlbase = os.path.join(urldirectorypath,urlbase)
                        utils.logdev(module,'movetofolder urlbase+fileext= %s, urlnew+fileext= %s' % (urlbase+fileext, urlnew+fileext))
                        shutil.move(urlbase+fileext,urlnew+fileext)
                        try:
                            shutil.move(urlbase+'.txt',urlnew+'.txt')
                        except Exception,e:
                            pass
                            utils.logdev(module,'move to folder error %r' % e)
                        try:
                            shutil.move(urlbase+'.srt',urlnew+'.srt')
                        except Exception,e:
                            pass
                            utils.logdev(module,'move to folder error %r' % e)
                        try:
                            shutil.move(urlbase+'.en.srt',urlnew+'.en.srt')
                        except Exception,e:
                            pass
                            utils.logdev(module,'move to folder error %r' % e)
                        try:
                            shutil.move(urlbase+'.da.srt',urlnew+'.da.srt')
                        except Exception,e:
                            pass
                            utils.logdev(module,'move to folder error %r' % e)
                        try:
                            shutil.move(urlbase+'.nfo',urlnew+'.nfo')
                        except Exception,e:
                            pass
                            utils.logdev(module,'move to folder error %r' % e)
                        try:
                            shutil.move(urlbase+'.log',urlnew+'.log')
                        except Exception,e:
                            pass
                            utils.logdev(module,'move to folder error %r' % e)
                except Exception,e:
                    pass
                    utils.logdev(module,'move to folder error %r' % e)
                
        else:
            utils.logdev(module,'FindCommands move to folder - no records found!')
        
        ### DELETE command
        c.execute("SELECT * FROM files WHERE archive=? AND command=?" , [archive,'delete'])
        channels = c.fetchall()
        utils.logdev(module,'FindCommands rename archive= %r, count= %r' % (archive,len(channels)))
        x = len(channels)
        if x > 0:
            utils.notificationforced('DELETE ' + str(x) + ' records in '+archive.lower()+': ', time = 1)
            for chan in channels:
                ###c.execute("INSERT OR REPLACE INTO files(filename, ext, path, video, description, size, archive, updated, created, updatedHuman, command, options) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [filename, chan[1], chan[2], chan[3], chan[4], chan[5], archive, nowTS, chan[8], humantime(nowTS), command, options])
                try:    ### Rename information and subtitles if they are available
                    urlbase = chan[0] 
                    if chan[1] != '':
                        fileext = '.' + chan[1]
                    else:
                        fileext = ''
                    if archive == 'L' or ADDON.getSetting('record_archive_path_enable') != 'true':
                        urldirectorypath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_path')))
                    else:
                        urldirectorypath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_archive_path')))
                    path = chan[2]
                    if path != '':
                        urldirectorypath = os.path.join(urldirectorypath,path)   
                    ###if not os.path.exists(urldirectorypath):
                    ###    os.makedirs(urldirectorypath)    
                    utils.logdev(module,'FindCommands delete archive= %r, urldirectorypath= %r' % (archive, urldirectorypath))
                    urlnewi = chan[11]
                    if urlbase != '':
                        ###urlnewi = recordings.latin1_to_ascii_force(urlnewi)   ### use only acceptable characters
                        ###urlnewi = ' '.join(urlnewi.split())  ## Remove doublespaces etc
                        ###urlnew = os.path.join(urldirectorypath,urlnewi)
                        ###utils.logdev(module,'urlnew= %r' % urlnew)
                        urlbase = os.path.join(urldirectorypath,urlbase)
                        utils.logdev(module,'urlbase= %r' % urlbase)
                        utils.logdev(module,'delete urlbase+fileext= %s' % (urlbase+fileext))
                        os.remove(urlbase+fileext)
                        try:
                            os.remove(urlbase+'.txt')
                        except Exception,e:
                            pass
                            utils.logdev(module,'Delete error %r' % e)
                        try:
                            os.remove(urlbase+'.srt')
                        except Exception,e:
                            pass
                            utils.logdev(module,'Delete error %r' % e)
                        try:
                            os.remove(urlbase+'.en.srt')
                        except Exception,e:
                            pass
                            utils.logdev(module,'Delete error %r' % e)
                        try:
                            os.remove(urlbase+'.da.srt')
                        except Exception,e:
                            pass
                            utils.logdev(module,'Delete error %r' % e)
                        try:
                            os.remove(urlbase+'.nfo')
                        except Exception,e:
                            pass
                            utils.logdev(module,'Delete error %r' % e)
                        try:
                            os.remove(urlbase+'.log')
                        except Exception,e:
                            pass
                            utils.logdev(module,'Delete error %r' % e)
                except Exception,e:
                    pass
                    utils.logdev(module,'Delete error %r' % e)
        else:
            utils.logdev(module,'FindCommands Delete - no records found!')
    except Exception,e:
        pass
        utils.logdev(module,'FindCommands ERROR: %r' % e)
                 
def ScanFiles(c,folderPath,archive):
    utils.logdev(module,'ScanFiles(folderPath= %r, archive= %r)'% (folderPath,archive))
    if locking.isScanLocked('ScanFiles'+folderPath):
        utils.notificationforced('No File Scanning as it is still running!')
    else:
        utils.notificationforced('File Scanning Started!')
        locking.scanLock('ScanFiles'+folderPath)
        now = datetime.now()
        i = 0
        cutoffnowTS = int(time.mktime(now.timetuple()))
        ###nowTSold =    nowTS - 31536000    ### 365 * 24 * 60 * 60  now-timedelta(days=365)
        FindCommands(c,folderPath,archive)
        for infile in find_files(folderPath, '*'):
            if i%500 == 0 and i > 0:
                utils.notificationforced('Scanning files in '+archive.lower()+': '+str(i), time = 1)
            i +=1
            try:
                fileext = ''
                fileextt = ''
                if '.' in infile:
                    fileext = infile.split('.')[-1]
                    fileextt = '.' + fileext
            except Exception,e:
                pass
                fileext = repr(e)
                fileextt = fileext
            infilebasename = os.path.basename(infile).replace(fileextt,'',-1) # the file name only
            if len(folderPath)>0:
                pathoffile = os.path.dirname(infile).replace(folderPath[:-1],'',1)
                if len(pathoffile) >0:
                    pathoffile = pathoffile[1:]
            else:
                pathoffile = ''
            video = repr(isExtKnown(infile))
            descriptionfilename = infile.replace(fileextt,'.txt',-1)
            if video == 'True' and os.path.isfile(descriptionfilename):
                try:               ### Description:
                    descf = open(descriptionfilename,'r')
                    desc = descf.read()
                    descf.close()
                    description = 'Description:\n' + desc.split('Description:')[1]
                    ###utils.logdev(module,'desc= ' + repr(desc))
                except Exception,e: 
                    pass
                    description = ''
                    utils.logdev(module,'description ERROR= ' + repr(e))
            else:
                description = ''
            ###utils.logdev(module,'infile= %r, infilebasename= %r' % (infile, infilebasename))
            ###utils.logdev(module,'pathoffile= %r, folderPath= %r,  os.path.dirname(infile)= %r' % (pathoffile, folderPath, os.path.dirname(infile)))
            try:
                FileSize = repr(float(int(long(os.stat(infile).st_size)/long(1024*1024)))/1000)
                FileData = 'Size: '+ FileSize + ' GB\nDate: ' + recordings.humantime(int(os.path.getmtime(infile)))
                if video == 'True':
                    if infile[:1] == '[':   ### 2019-03-11
                        nameparts = infile.split(']',1)
                        name = nameparts[1] + ' ' + nameparts[0] + ']'
                        name = name.strip()
                    else:
                        name = infile
                    try:
                        Duration = name.split('[',1)[1].split(']',1)[0]
                        if not 'h' in Duration or not 'm' in Duration:
                            Duration = name.split(']')[-2].split('[')[-1].split(' ')[-1]
                            if not 'h' in Duration or not 'm' in Duration:
                                Duration = ''
                    except Exception,e:
                        pass
                        utils.logdev(module,'Duration ERROR: %r' % e)
                        Duration = ''
                    Length = 0
                    try:
                        if Duration != '':
                            Length = int(Duration.split('h')[0])*60 + int(Duration.split('h')[1].split('m')[0])
                            FileData += '\nDuration: '+Duration+' '+str(Length)+'m'
                    except Exception,e:
                        pass
                        utils.logdev(module,'Duration2 ERROR: %r' % e)
                        ###FileData += repr(e)
                        
                    Length = -1
                    try:
                        SE = re.findall(r'(\d+)-(\d+)', infile)
                        if int(SE[0][0]) <= int(SE[0][1]):
                            Length = int(SE[0][0])
                    except Exception,e:
                        pass
                        utils.logdev(module,'SeriesEpisode 0 Error: %r' % e)
                    try:
                        SE = re.findall(r'(\d+)x(\d+)', infile)
                        Length = int(SE[0][0])
                    except Exception,e:
                        pass
                        utils.logdev(module,'SeriesEpisode 1 Error: %r' % e)
                    try:
                        SE = re.findall(r'Season (\d+) Episode (\d+)', infile)
                        Length = int(SE[0][0])*1000 + int(SE[0][1])
                    except Exception,e:
                        pass
                        utils.logdev(module,'SeriesEpisode 2 Error: %r' % e)
                    try:
                        SE = re.findall(r'E(\d+)', infile)
                        Length = int(SE[0])
                    except Exception,e:
                        pass
                        utils.logdev(module,'SeriesEpisode 3 Error: %r' % e)
                    try:
                        SE1 = re.findall(r'S(\d+)', infile)
                        Length += int(SE1[0])*1000
                        ### chan[0]= 'Kriminalkommissaer-Barnaby S0E113[DR NU] [2018-01-20 23-02 ROQ TV Rec]'
                        ### SE= [('0', '113')]
                        ###Length = int(SE[0][0])*1000 + int(SE[0][1])
                    except Exception,e:
                        pass
                        utils.logdev(module,'SeriesEpisode 4 Error: %r' % e)
                        
                    try:
                        if Length != -1:
                            SeriesEpisode = '\nSeries/Episode: S' + str(Length/1000) + 'E' + str(Length%1000)
                            ###utils.logdev(module,'Length= %r' % Length)
                            FileData += SeriesEpisode
                    except Exception,e:
                        pass
                        ###utils.logdev(module,'SeriesEpisode Error: %r' % e)
                        ###FileData += repr(e)
                
            except Exception,e:
                pass
                FileData = repr(e)
            recordings.addFile(c, infilebasename, fileext, pathoffile, video, description, FileData, archive)  ### Archive/Local
        utils.notificationforced('Scanning files ended in '+archive.lower()+': '+str(i), time = 1)
        ### Find outdated records
        recordings.addFileCleanup(c,folderPath,archive,cutoffnowTS)
        locking.scanUnlock('ScanFiles'+folderPath)
      
def ScanRecordings():
    try:
        conf = recordings.getFilesConnection()
        recordings.createFileTable(conf)
        c = conf.cursor()
        recordPath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_path')))
        ScanFiles(c,recordPath,'L')
        conf.commit()
        if ADDON.getSetting('record_archive_path_enable') == 'true':
            recordArchivePath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_archive_path')))
            ScanFiles(c,recordArchivePath,'A')
            conf.commit()
            ScanFiles(c,recordPath,'L')  ###Scan local again
            conf.commit()
        c.close() 
    except Exception,e:
        pass
        utils.logdev(module,'ScanRecordings ERROR: %r' % e )
        
def TimeUsed(ended,now):
    try:
        utils.logdev(module,'TimeUsed(ended= %r, now= %r)' % (ended,now))
        utils.logdev(module,'TimeUsed(ended-now)= %r)' % (ended-now))
        timeused = int(repr(ended-now).replace('datetime.timedelta(0, ','').split(',')[0])
        utils.logdev(module,'timeused= %r' % timeused)
        timeusedM = int(timeused/60)
        timeusedS = (timeused - timeusedM*60)
        timeusedMS = str(timeusedM) + 'm' + str(timeusedS).zfill(2) + 's'
        utils.logdev(module,'timeusedMS= %r' % timeusedMS)
    except Exception,e:
        pass
        timeusedMS = 'timeused ERROR %r' % e
        utils.logdev(module,'timeusedMS ERROR %r' % e)
    return timeusedMS
    
def limitChannels(name,channelType):
    if channelType.lower() != 'live':
        return True
    acceptchannelswith = ADDON.getSetting('acceptchannelswith')
    acceptchannelswithout = ADDON.getSetting('acceptchannelswithout')
    if acceptchannelswith == '':
        return True
    acceptchannelswith = acceptchannelswith.split(',')
    acceptchannelswithout = acceptchannelswithout.split(',')
    for chan in acceptchannelswith:
        if chan in name.lower():
            for chanx in acceptchannelswithout:
                if chanx in name:
                    utils.logdev(module,'limitChannels(acceptchannelswith= %r, name= %r, channelType= %r SKIPPED)' % (acceptchannelswith,name,channelType))
                    return False
            utils.logdev(module,'limitChannels(acceptchannelswith= %r, name= %r, channelType= %r Kept)' % (acceptchannelswith,name,channelType))
            return True
    utils.logdev(module,'limitChannels(acceptchannelswith= %r, name= %r, channelType= %r SKIPPED)' % (acceptchannelswith,name,channelType))
    return False
    

if args[1] == 'once' or args[1] == 'hourly':    
    utils.logdev(module,'ScanRecordings started')
    nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ADDON.setSetting('lastEPGimportInfo','Scan Recordings Started ' + nowS)
    ScanRecordings()
    EPGimportERRORS('')
    ### Reset Errors
    logdev(module,'Version: '+utils.version()) 
    logdev(module,'VersionDate: '+utils.versiondate())
    ROQuser = ADDON.getSetting('user')
    ROQpass = ADDON.getSetting('pass')
    ###logdev(module,'GetOriginalDescriptionsFromDict(first time)')
    ###GetOriginalDescriptionsFromDict()
    ###logdev(module,'GetOriginalDescriptionsFromDict(first time finished)')
    utils.testPrograms()   ### Test recordingprograms
    now= datetime.today()
    if locking.isScanLocked('EPG_update'):
        ### and not ADDON.getSetting('blockduringepgimport') == 'true':
        logdev(module,'No EPG update as it is still running!')
        notification('No EPG update as it is still running!')
    else:
        notification('EPG Import Started!')
        logdev('datetime.today()',repr(datetime.today()))
        nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        ADDON.setSetting('lastEPGimportInfo','New EPG Import Started ' + nowS)
        ###if not locking.isAnyScanLocked():
        ### logdev(module,'No scanning try EPG Update!')
        ###if ADDON.getSetting('blockduringepgimport') == 'true':
        locking.scanLock('EPG_update')
        ###notification('%s in %s started' % (module,ADDONid))
        if ADDON.getSetting('enable_record')=='true':
            RecordActive = True
        else:
            RecordActive = False

        
        lastEPGimport = ADDON.getSetting('lastEPGimport')
        if lastEPGimport == '':
            lastEPGimport = now - timedelta(hours = 24)  ### dummy lastEPGimport
            ADDON.setSetting('lastEPGimport',lastEPGimport.strftime('%Y-%m-%d %H:%M:%S using'))
        logdev('ADDON.getSetting(lastEPGimport)',repr(lastEPGimport))
        
        try:
            lastEPGimport = parse_date(ADDON.getSetting('lastEPGimport').split(' using',1)[0])
        except:
            pass
            lastEPGimport = parse_date(ADDON.getSetting('lastEPGimport'))
        logdev('datetime.datetime(ADDON.getSetting(lastEPGimport))',repr(lastEPGimport))   
        
        cEPG = recordings.getConnection()
        recordings.createEPGchannelsTable(cEPG)
        recordings.createEPGProgramsTable(cEPG)
        c = cEPG.cursor()
        try:
            c.execute("PRAGMA journal_mode = WAL")  ### 2018-01-07 Try to speed up on Windows (1700 sec down to 700 sec)
        except Exception, e:
            pass
            logdev(module,'PRAGMA journal_mode = WAL ERROR %r' % e)
        
        ###ADDON = xbmcaddon.Addon(id='plugin.video.wozboxntv')
        ###open(channelsxml, 'w')
        KrogsbellAddOns = definition.getKrogsbellAddOns()
        logdev(module,'KrogsbellAddOns= %r' % KrogsbellAddOns)
        for kaddon in KrogsbellAddOns:
            logdev(module,'kaddon= %r' % kaddon)
            try:
                kaddonID = kaddon.split('.')[2][:3].upper()
                taddonID = ADDONid.split('.')[2][:3].upper()
            except Exception, e:
                pass
                EpgError = 'Error in getting AddOn ID\n' + repr(e) 
                kaddonID = ''
                taddonID = ''
            logdev(module,'kaddonID= %r' % kaddonID)
            logdev(module,'taddonID= %r' % taddonID)
            if kaddonID != '' and kaddonID != taddonID:
                try:
                    NTVchannels = xbmc.translatePath( xbmcaddon.Addon(id=kaddon).getAddonInfo('profile') + 'channels.csv')
                    logdev(module,'NTVchannels= %r' % NTVchannels)
                except Exception, e:
                    pass
                    EpgError = 'Error in getting ' + kaddonID + ' Channels\n' + repr(e)
                    #EPGimportERRORS(EpgError)
                    #notification(EpgError)
                    logdev(module,EpgError)
                    NTVchannels = ''
                try:  ### Get the set webport
                    webport = utils.getGuiSetting('webserverport','8080')
                except:
                    pass
                    webport = '8080'
                if os.path.isfile(NTVchannels):
                    logdev(module,'Use ChannelFile in: ' + repr(NTVchannels))
                    nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                    ADDON.setSetting('lastEPGimportInfo','Import ' + kaddonID + ' Channels Started ' + nowS)
                    ended = datetime.today()
                    notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= ' + kaddonID) 
                    ADDON.setSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Channels= ' + repr(channels) + ' Programs= ' + repr(programs) +' Src= ' + kaddonID)
                    for line in open(NTVchannels):  # opened in text-mode; all EOLs are converted to '\n'
                        ###logdev(module,'Line: ' + repr(i) + ' - ' + line)
                        line = line.rstrip('\n').rstrip('\r')
                        if not line == '' and not line[:2] == '# ' :   # Ignore empty lines and comment lines
                            channels += 1
                            line=line.split(',')
                            stream_id = kaddonID + line[0]
                            name = line[1] + ' (' + kaddonID + ')'
                            url = 'http://127.0.0.1:' + webport + '/jsonrpc?request={"jsonrpc":"2.0","method":"Addons.ExecuteAddon","params":{"wait":false,"addonid":"' +kaddon + '","params":["url=url","cat=' + line[0] + '","mode=210","name=' + line[1] + '","recordname='+ADDONid+'"]},"id":200}'
                            epg_channel_id = line[2]
                            stream_icon = line[3]
                            ###EPGgenerator = 'NTV Available Channels'
                            EPGgenerator = ADDONid +' available_channels'
                            displaydescription = ''
                            recordings.addEPGChannel(c, stream_id, name, url, stream_icon, epg_channel_id, EPGgenerator, epg_channel=epg_channel_id, description=displaydescription)
        """
{"status": 1, "timestamp": 1557165592.926198, "message": null, "body": [

{"category": 1, "category_name": "Entertainment", "show_domestic": 1, "name": "BBC One", "country": "GB", "favorite": 0, "health": 1, "epg_now": {"event_name": "London News", "start_time": "2019-05-06 20:50:00", "end_time": "2019-05-06 21:00:00", "description": 
"The latest news, sport and weather from London. [S."}, "logo": "BBC_One.png", "xmltv_id": "bbc1.uk", "id": 1, "dvr": 7}, 

{"category": 3, "category_name": "Music",
        """
        KrogsbellAddOns = definition.getNTVAddOns()    ###  NTV addons like unlim.tv
        logdev(module,'NTVAddOns= %r' % KrogsbellAddOns)
        streamtype = ADDON.getSetting('streamtype').replace('0','m3u8').replace('1','ts').replace('2','rtmp')
        EPGgenerator = ADDONid +' available_channels'
        for kaddon in KrogsbellAddOns:
            logdev(module,'kaddon= %r' % kaddon)
            try:
                kaddonID = kaddon.split('.')[2][:3].upper()
                taddonID = ADDONid.split('.')[2][:3].upper()
            except Exception, e:
                pass
                EpgError = 'Error in getting AddOn ID\n' + repr(e) 
                kaddonID = ''
                taddonID = ''
            logdev(module,'kaddonID= %r' % kaddonID)
            logdev(module,'taddonID= %r' % taddonID)
            if kaddonID != '' and kaddonID != taddonID:
                try:
                    NTVchannels = xbmc.translatePath( xbmcaddon.Addon(id=kaddon).getAddonInfo('profile') + 'storage/channels.json')
                    logdev(module,'NTVchannels= %r' % NTVchannels)
                    NTVwww = 'https://www.touchsportstv.com' ### To be fetched from addon... 2019-10-09
                    logdev(module,'NTVwww= %r' % NTVwww)
                except Exception, e:
                    pass
                    EpgError = 'Error in getting ' + kaddonID + ' Channels\n' + repr(e)
                    logdev(module,EpgError)
                    NTVchannels = ''
                    NTVwww = ''
                
                if os.path.isfile(NTVchannels):
                    logdev(module,'Use ChannelFile in: ' + repr(NTVchannels))
                    nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                    ADDON.setSetting('lastEPGimportInfo','Import ' + kaddonID + ' Channels Started ' + nowS)
                    ended = datetime.today()
                    notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= ' + kaddonID) 
                    ADDON.setSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Channels= ' + repr(channels) + ' Programs= ' + repr(programs) +' Src= ' + kaddonID)
                    try:
                        file = open(NTVchannels,'r')
                        datapanel = file.read()
                        ###logdev(module,datapanel)
                        file.close()
                    except Exception, e:
                        pass
                        EpgError = 'Error in getting '+ NTVchannels + ' \n' + repr(e)
                        EPGimportERRORS(EpgError)
                        logdev(module,EpgError)
                        datapanel = ''
                    try:
                        datapanel = json.loads(datapanel)
                        descrpanel = 'message= %r \nStatus= %r \nExpire= %r' %(datapanel['message'],datapanel['status'],recordings.parseDate(datapanel['timestamp']).strftime('%Y-%m-%d %H:%M'))
                        logdev(module+' Start datapanel',descrpanel)
                        added = datapanel['timestamp']
                        for chan in datapanel['body']:
                            logdev(module,'name= %r, country= %r, xmltv_id= %r, id= %r dvr= %r' % (chan['name'],chan['country'],chan['xmltv_id'],chan['id'],chan['dvr']))
                            """
{"category": 1, "category_name": "Entertainment", "show_domestic": 1, "name": "BBC One", "country": "GB", "favorite": 0, "health": 1, "epg_now": {"event_name": "London News", "start_time": "2019-05-06 20:50:00", "end_time": "2019-05-06 21:00:00", "description": 
"The latest news, sport and weather from London. [S."}, "logo": "BBC_One.png", "xmltv_id": "bbc1.uk", "id": 1, "dvr": 7}, 
                            """
                            stream_id = kaddonID + str(notnone(chan['id']))
                            logdev(module,'stream_id= %r' % stream_id)
                            name = (notnone(chan['name']) + ' ' + kaddonID +'-'+ notnone(chan['country'])).strip()
                            logdev(module,'name= %r' % name)
                            category_name = notnone(chan['category_name'])
                            logdev(module,'category_name= %r' % category_name)
                            ###stream_icon = NTVwww + '/assets/img/channels/' + notnone(chan['logo']) + '?auth=TLS&verifypeer=false'   ### Original from unlim  2019-10-09
                            stream_icon = NTVwww + '/assets/img/channels/' + notnone(chan['logo']) 
                            logdev(module,'stream_icon= %r' % stream_icon)
                            epg_channel_id = notnone(chan['xmltv_id'])
                            logdev(module,'epg_channel_id= %r' % epg_channel_id)
                            tv_archive_duration = notnone(chan['dvr'])
                            logdev(module,'tv_archive_duration= %r' % tv_archive_duration)
                            #if tv_archive_duration >= 1:
                            #    tv_archive = 1 
                            #else:
                            #    tv_archive = 0
                            if chan['health'] != 1:   ### broken = '[COLOR blue] Broken[/COLOR]'
                                tv_archive_duration = -1
                            ###stream_type = notnone(chan['xmltv_id'])
                            ###container_extension = notnone(chan['xmltv_id'])
                            url = kaddon
                            logdev(module,'url= %r' % url)
                            ChannelFav = recordings.getChannelFav(c,stream_id)
                            displaydescription = 'Category: ' + category_name
                            logdev(module,'recordings.addEPGChannel(c, stream_id= %r, name= %r, url= %r, stream_icon= %r, epg_channel_id= %r, EPGgenerator= %r,  description= %r)'% (stream_id, name, url, stream_icon, epg_channel_id, EPGgenerator, displaydescription))
                            recordings.addEPGChannel(c, stream_id, name, url, stream_icon, epg_channel_id, EPGgenerator, epg_channel=epg_channel_id, description=displaydescription)
                            recordings.setChannelCatchup(c,stream_id,tv_archive_duration)
                            recordings.setChannelFav(c,stream_id,ChannelFav)
                            recordings.setChannelAdded(c,stream_id,added)
                            channels += 1
 
                    except Exception, e:
                        pass
                        EpgError = 'Error in getting datapanel for '+ NTVchannels + ' \n' + repr(e)
                        EPGimportERRORS(EpgError)
                        logdev(module,EpgError)
                        datapanel = ''
                    """
                    for line in open(NTVchannels):  # opened in text-mode; all EOLs are converted to '\n'
                        ###logdev(module,'Line: ' + repr(i) + ' - ' + line)
                        line = line.rstrip('\n').rstrip('\r')
                        if not line == '' and not line[:2] == '# ' :   # Ignore empty lines and comment lines
                            channels += 1
                            line=line.split(',')
                            stream_id = kaddonID + line[0]
                            name = line[1] + ' (' + kaddonID + ')'
                            url = 'http://127.0.0.1:' + webport + '/jsonrpc?request={"jsonrpc":"2.0","method":"Addons.ExecuteAddon","params":{"wait":false,"addonid":"' +kaddon + '","params":["url=url","cat=' + line[0] + '","mode=210","name=' + line[1] + '","recordname='+ADDONid+'"]},"id":200}'
                            epg_channel_id = line[2]
                            stream_icon = line[3]
                            ###EPGgenerator = 'NTV Available Channels'
                            EPGgenerator = ADDONid +' available_channels'
                            displaydescription = ''
                            recordings.addEPGChannel(c, stream_id, name, url, stream_icon, epg_channel_id, EPGgenerator, epg_channel=epg_channel_id, description=displaydescription)
                    """ 


        """
        ###ADDON = xbmcaddon.Addon(id='plugin.video.tvawayrec')
        ###open(channelsxml, 'w')
        try:
            NTVchannels = xbmc.translatePath( xbmcaddon.Addon(id='plugin.video.tvawayrec').getAddonInfo('profile') + 'channels.csv')
        except Exception, e:
            pass
            EpgError = 'Error in getting TVawayrec Channels\n' + repr(e)
            #EPGimportERRORS(EpgError)
            #notification(EpgError)
            logdev(module,EpgError)
            NTVchannels = ''
        try:  ### Get the set webport
            webport = utils.getGuiSetting('webserverport','8080')
        except:
            pass
            webport = '8080'
        if os.path.isfile(NTVchannels):
            logdev(module,'Use ChannelFile in: ' + repr(NTVchannels))
            nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
            ADDON.setSetting('lastEPGimportInfo','Import TVawayrec Channels Started ' + nowS)
            for line in open(NTVchannels):  # opened in text-mode; all EOLs are converted to '\n'
                ###logdev(module,'Line: ' + repr(i) + ' - ' + line)
                line = line.rstrip('\n').rstrip('\r')
                if not line == '' and not line[:2] == '# ' :   # Ignore empty lines and comment lines
                    channels += 1
                    line=line.split(',')
                    stream_id = 'TVA' + line[0]
                    name = line[1] + ' (TVA)'
                    url = 'http://127.0.0.1:' + webport + '/jsonrpc?request={"jsonrpc":"2.0","method":"Addons.ExecuteAddon","params":{"wait":false,"addonid":"plugin.video.tvawayrec","params":["url=url","cat=' + line[0] + '","mode=210","name=' + line[1] + '","recordname='+ADDONid+'"]},"id":200}'
                    stream_icon = ''
                    epg_channel_id = ''
                    ###EPGgenerator = 'TVA Available Channels'
                    EPGgenerator = ADDONid +' available_channels'
                    displaydescription = ''
                    recordings.addEPGChannel(c, stream_id, name, url, stream_icon, epg_channel_id, EPGgenerator, epg_channel=epg_channel_id, description=displaydescription)
        """
        ###if (lastEPGimport-now).total_seconds()/3600 < -12:
        ### >>>>>> ROQ TV PANEL
        ROQTVusername = ADDON.getSetting('user')
        if ROQTVusername.lower() == 'none':
            ADDON.setSetting('expiredate',ROQTVusername)
            ADDON.setSetting('concurrentstreams',ROQTVusername)
            EPGgeneratorName = 'No User'
        else:
            ###linkpanel = definition.getBASEURL() + definition.getCOMMAND() + 'username=' +ROQuser+ '&password=' +ROQpass + definition.getCOMMANDEND()
            linkpanel = definition.getBASEURL() + '/panel_api.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')
            EPGgeneratorName = 'panel_api'
            ended = datetime.today()
            notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= ' + EPGgeneratorName) 
            ADDON.setSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Channels= ' + repr(channels) + ' Programs= ' + repr(programs) +' Src= ' + EPGgeneratorName)
            ###if referral == 7:
            ###    ###http://tv.premium.iptv.uno:8080/get.php?username=xxxx&password=xxxx&type=m3u_plus&output=m3u8
            ###    linkpanel = definition.getBASEURL() + '/get.php?username=' +ROQuser+ '&password=' +ROQpass+ '&type=m3u_plus&output=m3u8'
            try:
                file = urllib2.urlopen(linkpanel)
                datapanel = file.read()
                file.close()
            except Exception, e:
                pass
                EpgError = 'Error in getting '+ linkpanel + ' \n' + repr(e)
                EPGimportERRORS(EpgError)
                notification(EpgError)
                datapanel = ''
                
            ChannelFile = os.path.join(datapath,ADDONid) + '.info'
            utils.makeOldFile(ChannelFile)
            with open(ChannelFile,'wb') as output:
                output.write(datapanel)
            
            ### ADDON.setSetting('lastEPGimportInfo','Pannel data fetched ' + nowS)
            ##ended = datetime.today()
            ##notification('EPG Import at ' + repr(ended-now).replace('datetime.timedelta(0, ','').split(',')[0] +' sec Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= Import of m3u direct channels') 

            ###name= Status,url= url,mode= 11,iconimage= ,cat= ,date= ,description= {u'username': u'XXX', u'status': u'Active', u'is_trial': u'0', u'created_at': u'1493734688', u'auth': 1, u'allowed_output_formats': [u'm3u8', u'ts', u'rtmp'], u'exp_date': u'1499005088', u'active_cons': u'0', u'password': u'XXXX', u'max_connections': u'1'},startDate= ,endDate= ,recordname= )
            try:
                ### {"user_info":{"username":"xxx","password":"yyy","auth":1,"status":"Active","exp_date":"1575555840","is_trial":"0","active_cons":"0","created_at":"1544016135","max_connections":"1","allowed_output_formats":["m3u8","ts","rtmp"]}
                datapanel = json.loads(datapanel)
                datapanel1 = datapanel['user_info']
                descrpanel = 'Username= %s \nStatus= %s \nExpire= %s \nMax connections= %s' %(datapanel1['username'],datapanel1['status'],recordings.parseDate(datapanel1['exp_date']).strftime('%Y-%m-%d %H:%M'),datapanel1['max_connections'])
                logdev(module+' Start datapanel',descrpanel)
                ### expiredate/concurrentstreams
                ADDON.setSetting('expiredate',str(recordings.parseDate(datapanel1['exp_date']).strftime('%Y-%m-%d %H:%M')))
                ADDON.setSetting('concurrentstreams',str(datapanel1['max_connections']))
                ### "server_info":{"url":"e900x.com","port":"8000","https_port":"25463","server_protocol":"http"}
                datapanelS = datapanel['server_info']
                ADDON.setSetting('server_info_url',str(datapanelS['url']))
                ADDON.setSetting('server_info_port',str(datapanelS['port']))
                ADDON.setSetting('server_info_https_port',str(datapanelS['https_port']))
                ADDON.setSetting('server_info_protocol',str(datapanelS['server_protocol']))
            except Exception, e:
                pass
                EpgError = 'Error in getting '+ ADDONid + ' info! Check your User ID\n' + repr(e)
                EPGimportERRORS(EpgError)
                notification(EpgError)
                datapanel = []

            """
            "available_channels":{
            "281":{
            "num":1,
            "name":"UK: BBC ONE HD",
            "stream_type":"live",
            "type_name":"Live Streams",
            "stream_id":"281",
            "stream_icon":"https:\/\/upload.wikimedia.org\/wikipedia\/commons\/1\/1a\/BBC_One_2002.png",
            "epg_channel_id":"BBC One London",
            "added":"1487332455",
            "category_name":"UK: ENTERTAINMENT",
            "category_id":"14",
            "series_no":null,
            "live":"1",
            "container_extension":null,
            "custom_sid":":0:19:22e3:80d:2:11a0000:0:0:0:",
            "tv_archive":1,
            "direct_source":"",
            "tv_archive_duration":"7"},
            """
            streamtype = ADDON.getSetting('streamtype').replace('0','m3u8').replace('1','ts').replace('2','rtmp')
            EPGgenerator = ADDONid +' available_channels'
            try:
            ###if 1==1:
                for chan in datapanel['available_channels']:
                    if (channels % 1000 == 0 and channels != 0) or (programs % 10000 == 0 and programs != 0):
                        ended = datetime.today()
                        notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= ' + EPGgeneratorName)
                        ADDON.setSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Channels= ' + repr(channels) + ' Programs= ' + repr(programs))
                    
                    """
                    logdev(module,repr(chan))
                    try:
                        logdev(module,repr(datapanel['available_channels'][chan]))
                    except Exception, e:
                        pass
                        notification('Info Error ' + repr(e)) 
                    """
                    description = ''
                    stream_id = notnone(datapanel['available_channels'][chan]['stream_id'])
                    name = notnone(datapanel['available_channels'][chan]['name'])
                    """
                    if ': ' in name:  ### Move category to end of name
                        chnameColon = name.split(': ') 
                        name = chnameColon[1] + ' (ROQ TV: ' + chnameColon[0]+ ')'
                    if '(RADIO' in name:   ### Move RADIO categoty to end of name
                        if ') ' in name:
                            chnameColon = name.split(') ')
                            name = chnameColon[1] + ' ' + chnameColon[0]+ ')'
                    """
                    category_name = notnone(datapanel['available_channels'][chan]['category_name'])
                    stream_icon = notnone(datapanel['available_channels'][chan]['stream_icon'])
                    epg_channel_id = notnone(datapanel['available_channels'][chan]['epg_channel_id'])
                    tv_archive = notnone(datapanel['available_channels'][chan]['tv_archive'])
                    tv_archive_duration = notnone(datapanel['available_channels'][chan]['tv_archive_duration'])
                    stream_type = notnone(datapanel['available_channels'][chan]['stream_type'])
                    container_extension = notnone(datapanel['available_channels'][chan]['container_extension'])
                    ###if container_extension == '':
                    ###    container_extensionfiller = ''
                    ###else:
                    ###    container_extensionfiller = '.' + container_extension
                    ###if stream_type == '' or stream_type == 'live':  #### Only Nordic Channels 
                    if stream_type == '' or stream_type == definition.getDefaultStreamType():
                        stream_typefiller = ''
                        container_extensionfiller = ''
                    else:
                        stream_typefiller = stream_type + '/'
                        if container_extension == '':
                            container_extensionfiller = ''
                        else:
                            container_extensionfiller = '.' + container_extension
                    ###logdev(module,'name= %r' % name)
                    ###logdev(module,'stream_id= %r' % stream_id)
                    ###logdev(module,'stream_type= %r' % stream_type)
                    ###logdev(module,'stream_typefiller= %r' % stream_typefiller)
                    ###logdev(module,'container_extension= %r' % container_extension)
                    ###logdev(module,'container_extensionfiller= %r' % container_extensionfiller)
                    added = notnone(datapanel['available_channels'][chan]['added'])
                    
                    if limitChannels(name,stream_type):
                        try:  
                            url = definition.getBASEURL() + '/'+stream_typefiller+ROQuser+'/'+ROQpass+'/'+stream_id+container_extensionfiller
                        except Exception, e:
                            pass
                            EpgError = 'Error in live streamtype '+ ChannelFile + ' \n' + repr(e)
                            logdev(module,'stream_type == live?? url= %r' % url)
                            ### EPGimportERRORS(EpgError)
                            logdev(module,EpgError)
                            url = 'url'  ### Dummy
                        logdev(module,'url= %r' % url)
                        
                        ChannelFav = recordings.getChannelFav(c,stream_id)
                        ###logdev(module,'1. ChannelFav= %r, stream_id= %r' % (ChannelFav, stream_id))
                        ###recordings.addEPGChannel(c,stream_id,name,url,stream_icon,epg_channel_id,EPGgenerator,epg_channel=epg_channel_id)
                        ###addEPGChannel(c,cid,name,url,iconimage,cat,origin,visible=1,weight=0,epg_channel='',description='')
                        ###logdev('XYZxyz','name= %r, category= %r' % (name,category_name))
                        displaydescription = description
                        if category_name != '' and description != '':
                            displaydescription = 'Category: ' + category_name + '\n\nDescription:\n' + description
                        else:
                            displaydescription = category_name + displaydescription
                        ###logdev('XYZxyz','name= %r, category= %r' % (name,displaydescription))
                        if stream_type.lower() == 'live' or ADDON.getSetting('notonlylive').lower() == 'true' :
                            recordings.addEPGChannel(c, stream_id, name, url, stream_icon, epg_channel_id, EPGgenerator, epg_channel=epg_channel_id, description=displaydescription)  ### 2018-02-13
                            recordings.setChannelCatchup(c,stream_id,tv_archive_duration)  ### 2018-06-08 catchup flag is number of days catchup
                            ###logdev(module,'2. ChannelFav= %r, stream_id= %r' % (ChannelFav, stream_id))
                            recordings.setChannelFav(c,stream_id,ChannelFav)
                            recordings.setChannelAdded(c,stream_id,added)
                            channels += 1
                            ###logdev(module,'channels= %r, name= %r' % (channels,name))
                
            except Exception, e:
                pass
                EpgError = 'Error in datapanel[available_channels] '+ ChannelFile + ' \n' + repr(e)
                EPGimportERRORS(EpgError)
                logdev(module,EpgError)
            
        cEPG.commit()
        ended = datetime.today()
        notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= ' + EPGgeneratorName) 
        ADDON.setSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Channels= ' + repr(channels) + ' Programs= ' + repr(programs) +' Src= ' + EPGgeneratorName)
        
        ###logdev(module,'EPG Import at ' + str(int((ended-now).total_seconds())) +' sec Channels= ' + repr(channels))    
        logdev(module,'EPG Import at ' + TimeUsed(ended,now) + ' Channels= ' + repr(channels))  
        ################################
        logdev(module,'useDirectChannels# %r' % 1)
        i = 0
        channelsM3U= []
        ###categories= []
        useDirectChannels = ADDON.getSetting('useDirectChannels')
        logdev(module,'useDirectChannels= %r' % useDirectChannels)
        logdev(module,'useDirectChannels# %r' % 2)
        if useDirectChannels == 'true':
            channelsM3U= []
            logdev(module,'useDirectChannels# %r' % 3)
            ChannelFile = ADDON.getSetting('directchannelsfromextraXMLTVfile') 
            if not os.path.isfile(ChannelFile):
                ChannelFile = os.path.join(datapath,'directchannels.m3u')
                ADDON.setSetting('directchannelsfromextraXMLTVfile','')  ###Remove old value
            if not os.path.isfile(ChannelFile):    ### If ChannelFile exist in Data directory use it
                ChannelFile = os.path.join(progpath,'directchannels.m3u.txt')  ### Otherwise try program directory
            logdev(module,'ChannelFile: %r' % ChannelFile)
            if os.path.isfile(ChannelFile): 
                logdev(module,'useDirectChannels# %r' % 4)
                logdev(module,'Use extra ChannelFile in: ' + repr(ChannelFile))
                ADDON.setSetting('directchannelsfromextraXMLTVfile',ChannelFile)
                nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                ADDON.setSetting('lastEPGimportInfo','Start import of m3u direct channels '+ChannelFile + ' ' + nowS)
                ended = datetime.today()
                notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= Import of m3u direct channels') 
                ADDON.setSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Channels= ' + repr(channels) + ' Programs= ' + repr(programs) +' Src= Import of m3u direct channels')
                for line in open(ChannelFile):  # opened in text-mode; all EOLs are converted to '\n'
                    logdev(module,'Line: ' + repr(i) + ' - ' + line) 
                    line = line.rstrip('\n').rstrip('\r').strip()
                    if not line == '' and not line[:2] == '# ' :   # Ignore empty lines and comment lines
                        logdev(module,'Line: %r' % 1) 
                        if '#EXTM3U' in line :
                            i += 1
                            ######logdev(module,'Skip EXTM3U in line: ' + repr(i))
                        elif '#EXTINF' in line :
                            i += 1
                            logdev(module,'Line:i %r' % i)
                            ######logdev(module,'Use EXTINF in line: ' + repr(i) + ' - ' + line)
                            ###if ',' in line:
                            ### logdev(module,'Comma(,) in line: ' + repr(i) + ' - ' + line)
                            tvgid=''
                            tvgname=''
                            tvgnamecat = ''
                            tvglogo=''
                            grouptitle=''
                            name=''
                            try:
                                tvgid=line.split('tvg-id="',1)[1].split('"',1)[0]
                                ######logdev(module,'Use tvg-id in line: ' + repr(tvgid) + ' - ' + line)
                            except:
                                pass
                            try:
                                tvgname=line.split('tvg-name="',1)[1].split('"',1)[0]
                                ######logdev(module,'Use tvg-name in line: ' + repr(tvgname) + ' - ' + line)
                            except:
                                pass
                            try:
                                tvglogo=line.split('tvg-logo="',1)[1].split('"',1)[0]
                                ######logdev(module,'Use tvg-logo in line: ' + repr(tvglogo) + ' - ' + line)
                            except:
                                pass
                            try:
                                grouptitle=line.split('group-title="',1)[1].split('"',1)[0]
                                ######logdev(module,'Use group-title in line: ' + repr(grouptitle) + ' - ' + line)
                            except:
                                pass
                            try:
                                name=line.split(',')[-1]
                                ######logdev(module,'Use name in line: ' + repr(name) + ' - ' + line)
                                grouptitle=grouptitle.split('SEASON')[0].strip()
                            except:
                                pass
                            try:
                                if ':' in tvgname:
                                    tvgnamecat=tvgname.split(':')[0].strip()
                            except:
                                pass
                        else:
                            i += 1
                            logdev(module,'Line: else i %r' % i)
                            line = line.lower()   ### 2018-06-29
                            try:
                                cats=line.split('live/')[1].split('/')[0]
                            except:
                                pass
                                try:
                                    cats=line.split('tv2danmark/')[1].split('/')[0]
                                except:
                                    pass
                                    try:
                                        cats=line.split('i/')[1].split('/')[0]
                                    except:
                                        pass
                                        try:
                                            if '/' in line.split('.')[-1]:   ### 2018-12-01 Selected stream type if none
                                                line1 = line + '.' + streamtype 
                                            else:
                                                line1 = line ### 2018-12-01 Selected stream type if none
                                            cats=line1.split('.')[-2].split('/')[-1]
                                        except Exception, e:
                                            pass
                                            EpgError = 'Error in m3u file: '+ repr(ChannelFile) + ' @ line= '+line+'\n' + repr(e)
                                            EPGimportERRORS(EpgError)
                                            notification(EpgError)
                                            cats=''
                            if not 'movie' in line and not 'series' in line:
                                catsinlink='! live'
                            else:
                                catsinlink=''
                            ###logdev(module,'Use cname= ' + repr(cname) + ' - grouptitle= ' + repr(grouptitle))
                            ###if cname == grouptitle or cname == tvgnamecat or cname == catsinlink or cname == 'Channels':
                            if '_' in cats:
                                if not 'bbc_' in cats:   ### 2017-08-28
                                    if not 'cbeebies_' in cats:
                                        if not cats[:1] == '_':  ### 2018-07-07
                                            logdev(module,'cats no_= %r' % cats)
                                            cats = cats.split('_')[0]
                                            logdev(module,'cats no_= %r' % cats)
                            ###grouptitle
                            logdev(module,'channelsM3U.append: %r' % name.strip()+' (D)')
                            channelsM3U.append([name.strip()+' (D)',line,grouptitle,tvglogo,tvgname,tvgid,'DIR'+cats,catsinlink])
                            ###elif  cname == 'Categories':
                            ### if not grouptitle in categories and grouptitle != None :
                            ###     categories.append(grouptitle)
                            ### if not tvgnamecat == '' and not tvgnamecat in categories and tvgnamecat != None:
                            ###     categories.append(tvgnamecat)
                            ### if not catsinlink == '' and not catsinlink in categories and catsinlink != None :
                            ###     categories.append(catsinlink)
                            ##logdev(module,'Use URL in line: ' + repr(repr(i)) + ' - ' + line)
                            ###addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
                            ###addDir(name,line,200,tvglogo,cat,'','cat= ' + cat + '\n\rtvg-id= ' + tvgid + '\n\rtvg-name= '+tvgname + '\n\rgroup-title= ' + grouptitle,'','',tvgname)
        ChannelFile = os.path.join(datapath,ADDONid) + '.m3u'
        if os.path.isfile(ChannelFile):
            logdev(module,'Use ChannelFile in: ' + repr(ChannelFile))
            for line in open(ChannelFile):  # opened in text-mode; all EOLs are converted to '\n'
                ###logdev(module,'Line: ' + repr(i) + ' - ' + line)
                line = line.rstrip('\n').rstrip('\r')
                if not line == '' and not line[:2] == '# ' :   # Ignore empty lines and comment lines
                    if '#EXTM3U' in line :
                        i += 1
                        ####logdev(module,'Skip EXTM3U in line: ' + repr(i))
                    elif '#EXTINF' in line :
                        i += 1
                        ###if ',' in line:
                        ### logdev(module,'Comma(,) in line: ' + repr(i) + ' - ' + line)
                        tvgid=''
                        tvgname=''
                        tvgnamecat = ''
                        tvglogo=''
                        grouptitl=''
                        name=''
                        ####logdev(module,'Use EXTINF in line: ' + repr(i) + ' - ' + line)
                        try:
                            tvgid=line.split('tvg-id="',1)[1].split('"',1)[0]
                        except:
                            pass
                            tvgid=''
                        ####logdev(module,'Use tvg-id in line: ' + repr(tvgid) + ' - ' + line)
                        try:
                            tvgname=line.split('tvg-name="',1)[1].split('"',1)[0]
                        except:
                            pass
                            tvgname=''
                        ####logdev(module,'Use tvg-name in line: ' + repr(tvgname) + ' - ' + line)
                        try:
                            tvglogo=line.split('tvg-logo="',1)[1].split('"',1)[0]
                        except:
                            pass
                            tvglogo=''
                        ####logdev(module,'Use tvg-logo in line: ' + repr(tvglogo) + ' - ' + line)
                        try:
                            grouptitle=line.split('group-title="',1)[1].split('"',1)[0]
                        ####logdev(module,'Use group-title in line: ' + repr(grouptitle) + ' - ' + line)
                        except:
                            pass
                            grouptitle=''
                        try:
                            name=line.split(',')[-1]
                        except:
                            pass
                            name=''
                        ####logdev(module,'Use name in line: ' + repr(name) + ' - ' + line)
                        try:
                            grouptitle=grouptitle.split('SEASON')[0].strip()
                        except:
                            pass
                            grouptitle=''
                        tvgnamecat = ''
                        if ':' in tvgname:
                            try:
                                tvgnamecat=tvgname.split(':')[0].strip()
                            except:
                                pass
                                tvgnamecat=''
                    else:
                        i += 1
                        try:
                            if '/' in line.split('.')[-1]:
                                line1 = line + '.' + streamtype   ### 2018-12-02 Selected stream type if none
                            else:
                                line1 = line
                            cats=line1.split('.')[-2].split('/')[-1]
                            catsinlink='! ' + line.split('/')[3]
                        except Exception,e: 
                            utils.logdev(module,'ERROR: %r' % e)
                            cats = ''
                            catslink = ''
                        if  catsinlink == '! rt':
                            catsinlink = ''
                        ######logdev(module,'Use cname= ' + repr(cname) + ' - grouptitle= ' + repr(grouptitle))
                        ###if cname == grouptitle or cname == tvgnamecat or cname == catsinlink or cname == 'Channels':
                        channelsM3U.append([name.strip(),line,grouptitle,tvglogo,tvgname,tvgid,cats,catsinlink])
                        ###elif  cname == 'Categories':
                        ### if not grouptitle in categories:
                        ###     categories.append(grouptitle)
                        ### if not tvgnamecat == '' and not tvgnamecat in categories:
                        ###     categories.append(tvgnamecat)
                        ### if not catsinlink == '' and not catsinlink in categories:
                        ###     categories.append(catsinlink)
                        ######logdev(module,'Use URL in line: ' + repr(repr(i)) + ' - ' + line)
                        ###addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
                        ###addDir(name,line,200,tvglogo,cat,'','cat= ' + cat + '\n\rtvg-id= ' + tvgid + '\n\rtvg-name= '+tvgname + '\n\rgroup-title= ' + grouptitle,'','',tvgname)
        ###channels = sorted(channels)
        ######logdev(module,'Use channels: ' + repr(channels))
        ###categories = sorted(categories)
        ######logdev(module,'Use categories: ' + repr(categories))
        ###for cat in categories:
            ######logdev(module,'Use categories: ' + repr(cat))
        ### if cat != '':
        ###     addDir(cat,'url',2,'','','',channeldescription)
        ###cEPG = recordings.getConnection()
        ###recordings.createEPGchannelsTable(cEPG)
        ###c = cEPG.cursor()
        j = 1
        for cat in channelsM3U:
            ######logdev(module,'Use channels: ' + repr(cat))
            if cat[0] != '':
                ###if RecordActive :  ###
                ### addChannel(name,url,iconimage,cat,source)
                ###recordings.addChannel(cat[0],cat[1],cat[3],cat[6], ADDONid)
                description = ''
                if cat[6] != '':
                    description += ' \n\rcat= ' + cat[6]
                if cat[5] != '':
                    description += ' \n\rtvg-id= ' + cat[5]
                if cat[4] != '':
                    description += ' \n\rtvg-name= '+cat[4]
                if cat[2] != '':
                    description += ' \n\rgroup-title= ' + cat[2]
                if cat[7] != '':
                    description += ' \n\rcatsinlink= '+cat[7]
                if cat[1] != '' and ADDON.getSetting('ShowLink') == 'true':
                    description += ' \n\rlink= '+cat[1].replace('/','/ ')
                ### addChannel(name,url,iconimage,cat,origin,visible=1,weight=1000,epg_channel='',description='')
                if ' (D)' in cat[0] or '/live/' in cat[1].lower() or ADDON.getSetting('notonlylive').lower() == 'true' :
                    if limitChannels(cat[0],'notonlylive'):   ### 2019-08-31
                        recordings.addChannel(cat[0],cat[1],cat[3],cat[6], ADDONid+ ' available_channels',weight= j,epg_channel= cat[5],description=description)  ### 2018-07-19 
                j += 1
                ###addDir(cat[0],cat[1],200,cat[3],cat[6],'',description,'','',cat[4])
        
                ###ChannelFav = recordings.getChannelFav(c,cat[0])
                ###recordings.addEPGChannel(c,cat[0],name,url,stream_icon,epg_channel_id,EPGgenerator)
                ###recordings.setChannelCatchup(c,cat[0],'False')
                ###recordings.setChannelFav(c,cat[0],ChannelFav)
        
                ###addDir(cat[0],cat[1],200,cat[3],cat[6],'','cat= ' + cat[6] + '\n\rtvg-id= ' + cat[5] + '\n\rtvg-name= '+cat[4] + '\n\rgroup-title= ' + cat[2] + ' \n\rcatsinlink= '+cat[7]+ ' \n\rlink= '+cat[1].replace('/','/ '),'','',cat[4])
                ###addDir(cat[0]+'*',cat[1].replace('.ts','.txt').replace('.mp4','.txt'),200,cat[3],cat[6],'',cat[1].replace('.ts','.txt').replace('.mp4','.txt'),'','',cat[4])
    
        
        
        ################################
        ###c.close() #### test
        ###if 1 == 0:
        
        ### >>>>>> ROQ TV ENIGMA
        ###link = 'http://roq-tv.net:25461/enigma2.php?username=XXX&password=XXXX'
        if ROQTVusername.lower() == 'none':
            ADDON.setSetting('expiredate',ROQTVusername)
            ADDON.setSetting('concurrentstreams',ROQTVusername)
            EPGgeneratorName = 'No User'
        else:
            try:
                linkenigma = definition.getBASEURL() + '/enigma2.php?username=' +ROQuser+ '&password=' +ROQpass
                EPGgeneratorName = 'enigma2'
                ended = datetime.today()
                notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= ' + EPGgeneratorName) 
                ADDON.setSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Channels= ' + repr(channels) + ' Programs= ' + repr(programs) +' Src= ' + EPGgeneratorName)
                file = urllib2.urlopen(linkenigma)
                dataenigma = file.read()
                file.close()
                ChannelFile = os.path.join(datapath,ADDONid) + '.enigma'
                utils.makeOldFile(ChannelFile)
                with open(ChannelFile,'wb') as output:
                    output.write(dataenigma)
            
            except Exception, e:
                pass
                EpgError = 'Error in getting '+ linkenigma + ' \n' + repr(e)
                EPGimportERRORS(EpgError)
                notification(EpgError)
                dataenigma = ''
            ### Nothing done with enigma data!!! 2018-07-06    <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
            
        ###nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        ###ADDON.setSetting('lastEPGimportInfo','Import HTTP guide ' + nowS)
        httplinkEPG = ''
        httplinkEPGenable = ADDON.getSetting('tvguideimporthttpenable')  ### 2018-06-12
        if httplinkEPGenable.lower() == 'true':
            ended = datetime.today()
            notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= Import HTTP guide') 
            ADDON.setSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Channels= ' + repr(channels) + ' Programs= ' + repr(programs) + ' Src= Import HTTP guide')
            httplinkEPG = ADDON.getSetting('tvguideimporthttp')
            ROQTVusername = ADDON.getSetting('user')
            if ROQTVusername.lower() != 'none':
                if httplinkEPG == '':
                    httplinkEPG = definition.getBASEURL() + '/xmltv.php?username=' +ROQuser+ '&password=' +ROQpass
            logdev(module,ADDONname + ' EPG link: ' + repr(httplinkEPG))
        if ADDON.getSetting('tvguidefromfile') == 'true':
            ChannelFile1 = ADDON.getSetting('tvguideimport')
            if 'special://' in ChannelFile1:
                ChannelFile1 = xbmc.translatePath(ChannelFile1)
                ADDON.setSetting('tvguideimport',ChannelFile1)
        else:
            ChannelFile1 = ''
        ###if ChannelFile == '':
        ChannelFile2 = ''
        if httplinkEPG != '':
            try:
                m3ufile = urllib2.urlopen(httplinkEPG)
                ChannelFile2 = os.path.join(datapath,ADDONid) + 'EPG.xml'
                utils.makeOldFile(ChannelFile2)
                with open(ChannelFile2,'wb') as output:
                    output.write(m3ufile.read())
            except Exception, e:
                pass
                EpgError = 'Error in httplinkEPG '+ httplinkEPG + ' \n' + repr(e)
                EPGimportERRORS(EpgError)
                notification(EpgError)
        ###logdev(module,'roq-tv EPG file downloaded: ' + repr(ChannelFile))
        #########logdev('Decoded XML file',repr(newdata))
        ###########2017-06-14
        ###else:
            ###ChannelFile = '/home/hans/.kodi/userdata/addon_data/script.ivueguide/merged_epg.xml'  ### Rytec EPG <<<<<<<
        EPGgeneratorDis = ''
        ChannelFiles = []
        if ChannelFile2 != '':
            ChannelFiles.append(ChannelFile2)
        if ChannelFile1 != '':
            ChannelFiles.append(ChannelFile1)   
        for ChannelFile in ChannelFiles:
            try:
                ChannelFileMod = datetime.fromtimestamp(os.path.getmtime(ChannelFile))
            except Exception, e:
                pass
                EpgError = 'Error in EPG file '+ ChannelFile + ' \n' + repr(e)
                EPGimportERRORS(EpgError)
                notification(EpgError)
                ChannelFileMod = now
    
            logdev(module,'ChannelFile= %r' % (ChannelFile))
            if ChannelFile == ChannelFile1:
                logdev(module,'time offset: %r' % (TimeZoneXML))
            else:
                logdev(module,'Time Offset: %r' % (TimeZone))
            logdev(module,'os.path.getmtime(ChannelFile)= %r' % (ChannelFileMod))
            try:
                logdev(module,'lastEPGimport - os.path.getmtime(ChannelFile) in hours= %r' %((lastEPGimport - ChannelFileMod).replace('datetime.timedelta(0, ','').split(')')[0].split(',')[0]) )           ###if (lastEPGimport - ChannelFileMod).total_seconds()/3600 < 12:
            except:
                pass
            try:
                epgfile = open(ChannelFile, 'r')
                dataepg = epgfile.read()
                logdev(module,'len(dataepg)= %r' % len(dataepg))
                epgfile.close() 
            except Exception, e:
                pass
                EpgError = 'Error in EPG file '+ ChannelFile + ' \n' + repr(e)
                logdev(module,'EPGimportERRORS(EpgError)= %r' % EpgError)
                EPGimportERRORS(EpgError)
                ###notification(EpgError)
                ###dataepg = ''    ### Test removed 2019-05-30
            try:
                dataepg = xmltodict.parse(dataepg)
                logdev(module,'len(xmltodict.parse(dataepg))= %r' % len(dataepg))
            except Exception, e:
                pass
                EpgError = 'Error in EPG file '+ ChannelFile + ' \n' + repr(e)
                logdev(module,'EPGimportERRORS(EpgError)*= %r' % EpgError)
                EPGimportERRORS(EpgError)
                ###notification(EpgError)
                ###dataepg = ''   ### Test removed 2019-05-30

            #########logdev('Decoded Dict',repr(data))
            ###channelsxml = os.path.join(datapath, 'channelsdictEPG')  + '.dict'
            ###LF = open(channelsxml, 'w')
            ###LF.write(repr(dataepg))
            ###LF.close()
            ###nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
            ###ADDON.setSetting('lastEPGimportInfo','Extract from datapannel ' + nowS)
            try:
                logdev(module,'len(dataepg)*= %r' % len(dataepg))
                datapanelEPG1 = dataepg['tv']
                datapanelEPG2 = dataepg['tv']['@generator-info-name']
                logdev(module,'datapanelEPG2 = dataepg[tv][@generator-info-name]= %r'%(datapanelEPG2))
                datapanelEPG3 = dataepg['tv']['@generator-info-url']
                logdev(module,'datapanelEPG3 = dataepg[tv][@generator-info-url]= %r'%(datapanelEPG3))
            except Exception, e:
                pass
                EpgError = 'Error in datapanelEPG '+ ChannelFile + ' \n' + repr(e)
                EPGimportERRORS(EpgError)
                notification(EpgError)
                
            EPGgeneratorName = getDict(dataepg,'tv','@generator-info-name')
            EPGgeneratorURL  = getDict(dataepg,'tv','@generator-info-url')
            if EPGgeneratorName == '' or EPGgeneratorURL == '':
                EPGgenerator = EPGgeneratorName + EPGgeneratorURL
            else:
                EPGgenerator = EPGgeneratorName + ' - ' + EPGgeneratorURL
            
            if EPGgeneratorName != '':
                if EPGgeneratorDis != '':
                    EPGgeneratorDis = EPGgeneratorDis + ' - ' + EPGgeneratorName
                else:
                    EPGgeneratorDis = EPGgeneratorName
            ADDON.setSetting('lastEPGimportInfo',EPGgeneratorDis)
            
            ended = datetime.today()
            notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= ' + EPGgeneratorDis) 
            ADDON.setSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Channels= ' + repr(channels) + ' Programs= ' + repr(programs))
            
            try:
                datapanelEPG3 = dataepg['tv']['channel']
            except Exception, e:
                pass
                EpgError = 'Error in datapanelEPG3 '+ ChannelFile + ' \n' + repr(e)
                EPGimportERRORS(EpgError)
                notification(EpgError)
                datapanelEPG3 = []
            i = 0
            for cid in datapanelEPG3:
                ###sleep(1)  ### 2019-09-04
                ###time.sleep(1/100)
                i += 1
                ###if i % 10000 == 0:
                if (channels % 1000 == 0 and channels != 0) or (programs % 10000 == 0 and programs != 0):
                    ended = datetime.today()
                    ###notification('EPG Import at ' + str(int((ended-now).total_seconds())) +' sec Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= ' + EPGgeneratorName)
                    notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= ' + EPGgeneratorName)
                    ADDON.setSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Channels= ' + repr(channels) + ' Programs= ' + repr(programs))
                ###if ADDON.getSetting('KeyErrorStop') == '':
                ###logdev('datapanelEPG3: for cid in datapanelEPG3',repr(cid))
                ###logdev('datapanelEPG3: for cid in datapanelEPG3[@id]',repr(cid['@id']))
                ###OrderedDict([(u'@lang', u'en'), ('#text', u'Deutsche Welle (English)')])
                name = getDict(cid,'display-name','#text','@lang')
                iconimage = getDict(cid,'icon','@src')
                ###def addChannel(name,url,iconimage,cat,origin,visible=True,weight=0,description='')
                ### def addEPGChannel(c,cid,name,url,iconimage,cat,origin,visible=1,weight=0,epg_channel='',description=''):
                if ADDON.getSetting('notonlylive').lower() == 'true' :
                    recordings.addEPGChannel(c,cid['@id'],name,'url',iconimage,repr(cid),EPGgenerator)
                    channels += 1
                    ###logdev(module,'channels= %r, name= %r, cid= %r' % (channels,name,cid['@id']))
            cEPG.commit()
            ended = datetime.today()
            ###logdev(module,'EPG Import at ' + str(int((ended-now).total_seconds())) +' sec Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= ' + EPGgenerator)
            logdev(module,'EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= ' + EPGgenerator)

            ### (u'programme', [OrderedDict([(u'@start', u'20170613130000 +0100'), (u'@stop', u'20170613133000 +0100'), (u'@channel', u'I46817.labs.zap2it.com'), (u'title', u'ESPNEWS'), (u'desc', u'Sports news round-the-clock: highlights, scores, updates.')]),
            ### OrderedDict([(u'@start', u'20170618060000 +0000'), (u'@stop', u'20170618070000 +0000'), (u'@channel', u'BET:BlackEntTv.uk'), (u'title', OrderedDict([(u'@lang', u'en'), ('#text', u'Soul Sessions')])), (u'desc', OrderedDict([(u'@lang', u'en'), ('#text', u"The best of Neo-Soul, R&B and classic hits, and features music videos from today's hottest artist and music legends")]))]),
            try:
                datapanelEPG4 = dataepg['tv']['programme']
            except Exception, e:
                pass
                EpgError = 'Error in dataepg[tv][programme] '+ ChannelFile + ' \n' + repr(e)
                EPGimportERRORS(EpgError)
                notification(EpgError)
                datapanelEPG4 = ''
            ###nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
            ###ADDON.setSetting('lastEPGimportInfo','Pannel EPG4 extracting ' + nowS)
            for prog in datapanelEPG4:
                ###sleep(1)  ### 2019-09-04
                ###time.sleep(1/100)
                i += 1
                ###if i % 10000 == 0:
                if (channels % 1000 == 0 and channels != 0) or (programs % 10000 == 0 and programs != 0):
                    ended = datetime.today()
                    ###notification('EPG Import at ' + str(int((ended-now).total_seconds())) +' sec Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= ' + EPGgeneratorName)
                    notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= ' + EPGgeneratorName)
                    ADDON.setSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Channels= ' + repr(channels) + ' Programs= ' + repr(programs))
                    
                ###if ADDON.getSetting('KeyErrorStop') == '':
                ###logdev('datapanelEPG4: for prog in datapanelEPG4[@start]',repr(prog['@start']))
                ###logdev('datapanelEPG4: for prog in datapanelEPG4[@channel]',repr(prog['@channel']))
                channel = getDict(prog,'@channel')
                title = getDict(prog,'title','#text','@lang')
                sub_title = getDict(prog,'sub_title','#text','@lang')
                nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                try:
                    description = getDict(prog,'desc','#text','@lang').replace('?n','?\n').replace('!n','!\n').replace('.nn','.\n').replace('. nn','.\n').replace('.n','.\n').replace('. n','.\n') + ' \n\nEPG Created ' + nowS  ### 2018-04-27
                except:
                    pass
                    description = ' \n\nEPG Created ' + nowS
                """
                channel = ''
                try:
                    channel = prog['@channel']['#text']
                    ###logdev('datapanelEPG4: for prog in datapanelEPG4[title][@lang]',repr(prog['title']['#text']) + '[' + repr(prog['title']['@lang'])+']')
                except:
                    pass
                    try:
                        channel = prog['@channel']
                    except: pass
                title = ''
                try:
                    title = prog['title']['#text']
                    ###logdev('datapanelEPG4: for prog in datapanelEPG4[title][@lang]',repr(prog['title']['#text']) + '[' + repr(prog['title']['@lang'])+']')
                except:
                    pass
                    try:
                        title = prog['title']
                    except: pass
                sub_title = ''
                try:
                    sub_title = prog['sub_title']['#text']
                    ###logdev('datapanelEPG4: for prog in datapanelEPG4[title][@lang]',repr(prog['title']['#text']) + '[' + repr(prog['title']['@lang'])+']')
                except:
                    pass
                    try:
                        sub_title = prog['sub_title']
                    except: pass
                description = ''
                try:
                    description = prog['desc']['#text']
                    ###logdev('datapanelEPG4: for prog in datapanelEPG4[title][@lang]',repr(prog['title']['#text']) + '[' + repr(prog['title']['@lang'])+']')
                except:
                    pass
                    try:
                        description = prog['desc']
                    except: pass
                    ###logdev('datapanelEPG4: for prog in datapanelEPG4[title]',repr(prog['title']))
                """
                ###descrpanelEPG = 'channel\n@id= %r \ndisplay-name= %r \nicon[src]= %r' %(dataepg['tv']['channel']['@id'],dataepg['tv']['channel']['display-name'],dataepg['tv']['channel']['icon']['@src'])
                ###logdev(module+' Start EPG',descrpanelEPG)
                ###def addEPGProgram(channel, title, sub_title, start_date, end_date, description='', categories='', image_large='', image_small='', season= '', episode='', is_movie='', language='', source='')
                ###.datetime.strptime(thetime, "%Y-%m-%dT%H:%M:%S%z")
                if ChannelFile == ChannelFile1:
                    recordings.addEPGProgram(c,prog,channel, title, sub_title, parse_date_stringXML(prog['@start']), parse_date_stringXML(prog['@stop']), description, source=EPGgenerator)
                else:
                    recordings.addEPGProgram(c,prog,channel, title, sub_title, parse_date_string(prog['@start']), parse_date_string(prog['@stop']), description, source=EPGgenerator)
                programs += 1
            cEPG.commit()
        cEPG.commit()
        c.close()
        ended = datetime.today()
        ADDON.setSetting('lastEPGimport',ended.strftime('%Y-%m-%d %H:%M:%S') + ' using ' + TimeUsed(ended,now))
        """
        if EPGgeneratorName != '':
            if EPGgeneratorDis != '':
                EPGgeneratorDis = EPGgeneratorDis + ', ' + EPGgeneratorName
            else:
                EPGgeneratorDis = EPGgeneratorName
        ADDON.setSetting('lastEPGimportInfo',EPGgeneratorDis)
        """
        ###ADDON.setSetting('lastEPGimportInfoData','Ended in ' + str(int((ended-now).total_seconds())) +' sec Channels= ' + repr(channels) + ' Programs= ' + repr(programs))
        ###notification('EPG Import Ended in ' + str(int((ended-now).total_seconds())) +' sec Cha= ' + repr(channels) + ' Pro= ' + repr(programs))
        ###logdev(module,'EPG Import Ended at ' + str(int((ended-now).total_seconds())) +' sec Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= ' + EPGgenerator)
        ###ADDON.setSetting('lastEPGimportInfoData','Ended in ' + TimeUsed(ended,now) + ' Channels= ' + repr(channels) + ' Programs= ' + repr(programs))
        notification('EPG Import Ended in ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))
        logdev(module,'EPG Import Ended at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+ ' Src= ' + EPGgenerator)
        locking.scanUnlock('EPG_update')
    
    ended = datetime.today()
    lastEPGimportInfoData = 'Ended in ' + TimeUsed(ended,now) + ' Channels= ' + repr(channels) + ' Programs= ' + repr(programs)
    ADDON.setSetting('lastEPGimportInfoData',lastEPGimportInfoData)
    ADDON.setSetting('prevEPGimportInfoData',lastEPGimportInfoData)
    logdev(module,'GetOriginalDescriptionsFromDict(second time)')
    GetOriginalDescriptionsFromDict()
    logdev(module,'GetOriginalDescriptionsFromDict(second time finished)')
    recordings.ftvntvlist() ### Force INI file
    recordings.delOldEPGPrograms()  ### 7 days old programs and 2 days old channels        
    updatedrecordings = recordings.finddoubletes()  ### Find double programs
    if updatedrecordings >= 1:
        recordings.reschedule() ### Set EPG program start

    ended = datetime.today()
    notification('EPG Import Ended in ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+ ' Find doublette programs ended')
    logdev(module,'EPG Import Ended at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= ' + EPGgenerator+ ' Find doublette programs ended')
