#!/usr/bin/env python
# -*- coding: utf-8 -*-
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import time
import os

import xbmc,xbmcvfs
import xbmcgui
import xbmcaddon
import utils
import shutil
import re
import net
import locking
import json
import urllib
import glob
import urllib
import base64

from sqlite3 import dbapi2 as sqlite3
from operator import itemgetter

e = 'Kodi 19 Exception missing'
RECORDS_DB    = 'recordings_adc.db'
CHANNEL_DB    = 'channels.db'
EPG_DB        = 'master.db'
FILES_DB      = 'files.db' ### 2019-02-24
ALARMS_DB     = 'alarms1.db' ### 2022-05-31
CATEGORIES_DB = 'categories.db' ### 2023-05-08
SETTINGSXML = 'settings.xml'
#ADDON      = xbmcaddon.Addon(id='plugin.video.wozboxntv')
import definition
ADDON       = definition.getADDON()
ADDONid     = definition.ADDONgetAddonInfo('id')
ADDONname   = definition.ADDONgetAddonInfo('name')

xbmc.log('recordings.py in %s' % ADDONname)
datapath    = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
progpath    = definition.ADDONgetAddonInfo('path')
module      = 'recordings.py'
origin = ADDONid +' available_channels'
RECURSIVEMARKER = 'Recursive:'

def log(infotext,showlength=1024):
    definition.log(infotext,showlength,module)

"""
try:
    if hasattr(os, "stat"):
        from os import stat as statvfs
    else:
        from os import statvfs
except Exception as e:
    pass
    log('err 76 Exception: %r' % e)
"""
        
def sleep(sleeptime):
    log('sleep %r (sleeptime= %r)' % (module,sleeptime))
    xbmc.sleep(sleeptime)

def resetAlarmDatabase():
    dbPath = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
    if not os.path.exists(dbPath):
        os.mkdir(dbPath)
    file = os.path.join(dbPath, ALARMS_DB)
    utils.makeOldFile(file)
    locking.deleteLockFile(file)
        
def cancelAlarm(nameAlarm):
    AlarmCount = utils.intADDONgetNextSetting('AlarmCount',maxvalue=1000)
    nameAlarm = nameAlarm.replace(',','').replace('.','').replace(' ','').strip()
    log('error cancelAlarm(nameAlarm= %r)' % nameAlarm)
    ###sleep(2000)   ### 2023-06-19
    addAlarm(nameAlarm, 'cancelAlarm', 'no args', '00:00:00', '%r' % AlarmCount)   ### 2023-08-19
    nameAlarmAddon = ADDONname + nameAlarm
    xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmAddon)
    ###sleep(2000)   ### 2023-08-19

def setAlarm(nameAlarm, prog, args, starttimedeltahms,options=utils.intADDONgetNextSetting('AlarmCount',maxvalue=1000)):
    nameAlarm = nameAlarm.replace(',','').replace('.','').replace(' ','').strip()
    starttimedeltahms = utils.fixdelta(starttimedeltahms)
    log('error setAlarm(nameAlarm= %r, prog= %r, args= %r, starttimedeltahms= %r,options= %r) ' % (nameAlarm, prog, args,starttimedeltahms,options))
    nameAlarmAddon = ADDONname + nameAlarm 
    scriptstartrepeatprog   = os.path.join(definition.ADDONgetAddonInfo('path'), prog)
    cmdstartrepeatprog = 'AlarmClock(%s,RunScript(%s,%s),%s,%s)' % (nameAlarmAddon, scriptstartrepeatprog, args, starttimedeltahms, options)
    log('errYYY cmdstartrepeatprog= %r' % cmdstartrepeatprog)
    cancelAlarm(nameAlarm)
    addAlarm(nameAlarm, scriptstartrepeatprog, args, starttimedeltahms, options)
    
    
    try:
        if type(starttimedeltahms) != int:
            utils.notificationforced('Start ' + nameAlarm + ' in '+starttimedeltahms.replace(':','h',1).replace(':','m',1) + 's')
        else: 
            utils.notificationforced('Start ' + nameAlarm + ' in '+str(starttimedeltahms) + 's')
    except Exception as e :
        pass
        log('err 126 setAlarm ERROR: %r' % e)
    xbmc.executebuiltin(cmdstartrepeatprog) 

def cleanTempFiles():
    channelsxml = os.path.join(datapath, 'channelsxml*.xml')
    channelsdict = os.path.join(datapath, 'channelsdict*.dict')
    LockFiles = glob.glob(channelsxml)
    # delete lock files
    for file in LockFiles:
        locking.deleteLockFile(file)
        log('recordUnlockAll(file= %r)' % (file))
        
    LockFiles = glob.glob(channelsdict)
    # delete lock files
    for file in LockFiles:
        locking.deleteLockFile(file)
        log('recordUnlockAll(file= %r)' % (file))

def SelectSetupxmlFiles():
    path = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
    files =  glob.glob(os.path.join(path, '*'))
    defaultfile = os.path.join(path, SETTINGSXML)
    files1 = sorted(files, reverse=True)
    activeDB = SETTINGSXML.split('.')[0]+ ' - ' + utils.username(defaultfile) 
    index = 0
    contextMenu = []
    contextFile = []
    try:
        BackupCount = int(definition.ADDONgetSetting('BackupCount'))  
    except Exception as e:
        log('error 166 Exception: %r' % e)
        pass
        BackupCount = 25
    for infile in files1:
        if index < BackupCount:
            index += 1
            try:
                if infile[-4:].lower()=='.xml':
                    mail = utils.username(infile)
                    folder = utils.folder(defaultfile)
                    name = infile.replace(path,'').replace('.xml','') + ' - ' + mail + ': ' + folder
                
                    ###if '@' in mail: 
                    contextMenu.append(name)
                    contextFile.append(infile)
            except Exception as e:
                log('err 182 Exception: %r' % e)
                pass
    if len(contextMenu) == 0 or len(contextMenu) == 1:   ### Dont ask if only one entry
        log('err 185 xbmcaddon.Addon(id=ADDONid).openSettings()')
        xbmcaddon.Addon(id=ADDONid).openSettings()
    else:
        SelectedChannel = xbmcgui.Dialog().select('Select a setupxml file', contextMenu)
        if SelectedChannel >= 0:
            definition.ADDONsetSetting('fixsetup','true')
            try:
                id = contextFile[SelectedChannel]
                utils.notification('Seletced setupxml: ' + repr(id))
                ### copy file
                shutil.copyfile(id, defaultfile)
                ###xbmc.executebuiltin("XBMC.Container.Update(path,replace)")  ### Exit AddOn after setup.xml update
                xbmc.executebuiltin("Container.Update(path,replace)")  ### Exit AddOn after setup.xml update
                ###xbmc.executebuiltin("XBMC.ActivateWindow(Home)")
                ###xbmc.executebuiltin("ActivateWindow(Home)")
                xbmc.executebuiltin("ActivateWindow('1000')")
            except Exception as e:
                log('err 198 Exception: %r' % e)
                pass
                definition.ADDONsetSetting('fixsetup','false')
            
def TestHDD(path):
    log('err TestHDD(path)= %r' % path)
    try:
        ###st = os.statvfs(path)

        ###if st.f_frsize:
        ###    freespace = st.f_frsize * st.f_bavail/1024/1024/1024
        ###else:
        ###    freespace = st.f_bsize * st.f_bavail/1024/1024/1024
        freespace = utils.get_free_space_gb(path,'L')
        log("err Free Space: %r GB"%(freespace))
        if type(freespace) == type(1):
            if (freespace < 3) and definition.ADDONgetSetting('enable_record') == 'true':
                text = "You have less than 3GB of free space on your Record Path"
                text1 = path
                text2 = "Free up some space!"
                utils.notificationforced('[COLOR red]Less than 3GB of free space on[/COLOR] \n'+path)
                ###xbmcgui.Dialog().ok(ADDONname, text, text1, text2)
    except Exception as e:
        log('err 219 Exception: %r' % e)
        pass
        log('Error in get TestHDD path= %r \nError: %r' %(path,e))
    """
    if Platform.system == 'android': 
-            # http://stackoverflow.com/questions/1749928/replacement-for-python-statvfs#comment42443537_1749950
-            # https://github.com/Diblo/KODI-Popcorn-Time/issues/68
-            return 16106127360 # 15 GB
+            if hasattr(os, 'statvfs'):
+                st = os.statvfs(download_path)
+                return st.f_bavail * st.f_frsize
+            else:
+                import commands, b2h
+                return b2h.human2bytes(commands.getoutput('df %s' % download_path).split('\n')[1].split()[3])
         if Platform.system == 'windows':
             free_bytes = ctypes.c_ulonglong(0)
             ctypes.windll.kernel32.GetDiskFreeSpaceExW(ctypes.c_wchar_p(self.mediaSettings.download_path), None, None, ctypes.pointer(free_bytes))
© 2017 GitH
    """
    ###while not xbmc.abortRequested:    
    ###    sleep(502)          

def writeFromDatabase(channels,filename):
    ###filename = os.path.join(datapath, filename)
    return   ### Don't write
    log('222 errorX writeFromDatabase(channels= %r,filename=%r)' % (channels,filename))
    data = ''
    for channel in channels:
        line = ''
        for ch in channel:
            line += '%r, ' % ch
        log('228 errorX writeFromDatabase(line= %r,filename=%r)' % (line,filename))
        data += ('\n,'+line)
    log('230 errorX writeFromDatabase(line= %r,filename=%r)' % (data,filename))
    with open(filename,'w') as output:
        output.write('%r' % data)

def deleteDoubletChannels():
    return   'Not tested' ### Don't use
    nowDate= datetime.today().strftime('%Y-%m-%d')
    c = getConnection().cursor()
    log('errorX #223 deleteDoubletChannels Started')
    try:
        ### channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER)
        c.execute("SELECT DISTINCT id, title, created FROM channels")
        channels = c.fetchall()
        log('errorX #223 deleteDoubletChannels Fetched')
    except Exception as e:
        log('errorX #228 deleteDoubletChannels Exception: %r' % e)
        pass
        channels =  []
    ###channels = sorted(channels, key=itemgetter('title'))
    ###channels = sorted(channels, key=itemgetter(1))
    ###channels = sorted(channels,key=lambda i:i[0].lower())  ### Sort ignore case coloum 0
    channels = sorted(channels, key=itemgetter(2), reverse=False) ### Sort by created
    filename = os.path.join(datapath, 'Channels.txt')
    ###writeFromDatabase(channels,filename)
    usedchannels = []
    j = 0
    for channel in channels:
        log('238 errorX deleteDoubletChannels channel= %r' % channel )
        if not channel[0] in usedchannels :
            usedchannels.append(channel)
        else:
            log('242 errorX deleteDoubletChannels Delete channel= %r' % channel )
            j += 1
    filename = os.path.join(datapath, 'UsedChannels.txt')
    writeFromDatabase(channels,filename)
    return str(j)
        
recordPathBasic = definition.ADDONgetSetting('record_path')
if recordPathBasic == '':
    recordPathBasic = definition.ADDONgetSetting('record_path')
recordPath = xbmcvfs.translatePath(os.path.join(recordPathBasic))
###log('recordPath= %r Writable? %r' % (recordPath,utils.folderwritable(recordPath,module)))

TestHDD(recordPath)

### Is FFMPEG installed? 2018-05-26
try:
    ffmpeginstalled = utils.runCommandTest('ffmpeg')
except Exception as e:
    log('err 249 Exception: %r' % e)
    pass
    ffmpeginstalled = False
    
### Is yt-dlp installed? 2024-04-01
try:
    ytdlpinstalled = utils.runCommandTest('yt-dlp')
except Exception as e:
    log('err 249 Exception: %r' % e)
    pass
    ytdlpinstalled = False

if definition.ADDONgetSetting('enable_record')=='true' and not (ffmpeginstalled or ytdlpinstalled) and (definition.ADDONgetSetting('enable_ffmpegtest')=='true' or definition.ADDONgetSetting('enable_ytdlptest')=='true'):
    definition.ADDONsetSetting('enable_record','false')
    ###Dialog().ok(heading=heading, message=message)
    xbmcgui.Dialog().ok(ADDONname, 'FFMPEG or yt-dlp is not installed!\n\nRecording is disabled in the settings')
    
if (ffmpeginstalled or ytdlpinstalled) and definition.ADDONgetSetting('enable_record')=='true' and not utils.folderwritable(recordPath,module):
    ###utils.notification('Recording not possible [COLOR red]You must set the recording path writable![/COLOR] \nGoto Settings/Recording/Record Path and set that to a writable path')
    log('ERROR: You must set the recording path writable!')
    if not definition.ADDONgetSetting('fixsetup') == 'true':  ### Only run setup once
        if definition.ADDONgetSetting('user') == '':
            SelectSetupxmlFiles()
            log('err 263 xbmcaddon.Addon(id=ADDONid).openSettings()')
            if definition.ADDONgetSetting('user') == '':
                log('err 265 xbmcaddon.Addon(id=ADDONid).openSettings()')
                xbmcaddon.Addon(id=ADDONid).openSettings()
        else:
            log('err 268 xbmcaddon.Addon(id=ADDONid).openSettings()')
            xbmcaddon.Addon(id=ADDONid).openSettings() 
"""
recordPath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_path')))
log('recordPath= %s' %recordPath)
if definition.ADDONgetSetting('enable_record')=='true' and not utils.folderwritable(recordPath):
    ###utils.notification('Recording not possible [COLOR red]You must set the recording path writable![/COLOR] \nGoto Settings/Recording/Record Path and set that to a writable path')
    log('You must set the recording path writable! ')
    log('err 275 xbmcaddon.Addon(id=ADDONid).openSettings()')
    xbmcaddon.Addon(id=ADDONid).openSettings()
"""
def downloadicons():
    utils.logdevreset()
    return    #### REMOVE TO DOWNLOAD ALL ICONS AGAIN TO DATA FOLDER ####

    iconsfolder = os.path.join(datapath,'icons')
    if os.path.exists(iconsfolder) == False:
        os.makedirs(iconsfolder)    
    c = getIconConnection().cursor()
    ### c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (title, source))") ###
    c.execute("SELECT * FROM channels")
    logos = c.fetchall()
    ###utils.logdev('downloadicons','size= ' + repr(len(logos)))
    for logo in logos:
        logoid= logo[0]
        title= logo[1]
        logolink= logo[2]
        ###utils.logdev('downloadicons','id= ' + repr(logoid) + ' title= ' + repr(title) + ' logolink= ' + repr(logolink))
        logofilename= os.path.join(datapath,'icons',logoid) + '.png'
        ###utils.logdev('downloadicons','logofilename= ' + repr(logofilename))
        try:
            ###iconfile = urllib.urlopen(logolink)
            ###with open(logofilename,'wb') as output:
            ###    output.write(iconfile.read())
            data = utils.readlink(logolink,logofilename,module)
        except Exception as e:
            log('err 299 Exception: %r' % e)
            pass
            ###utils.logdev('downloadicons','FAILED id= ' + repr(logoid) + ' title= ' + repr(title) + ' logolink= ' + repr(logolink))
    c.close()

def getIconfromEPG(epg):
    try:
        url = ''
        cat = epg.lower()   ### use epg_channel lower case
        url = 'https://raw.githubusercontent.com/krogsbell/Logos/master/'+str(cat)+'.png'
        log('errXXX getIconfromEPG= %r, url= %r' % (cat,url))
        return url
    except Exception as e:
        pass
        log('errXXX getIconfromEPG= %r, ERROR: %r' % (epg,e))
        return ''
    

def getIcon(title,cat):
    ###https://raw.githubusercontent.com/krogsbell/Logos/master/99.png
    return IconFromCat(cat)
    """
    if definition.ADDONgetSetting('geticonfromweb') == 'true':
        return getIconFromWeb(title,cat)
    else:
        logofilename= os.path.join(progpath,'resources','logo',cat) + '.png'
        if os.path.isfile(logofilename) == True:
            ### ###utils.logdev('getIcon','logofilename= ' + repr(logofilename))
            return logofilename
        else:
            ###utils.logdev('getIcon FAILED','logofilename= ' + repr(logofilename))
            return logofilename
"""

"""
ROQ TV - M3U Playlist URL
'http://roq-tv.net:25461/get.php?username=xxxx&password=xxxx&type=m3u_plus&output=ts'
definition.getBASEURL() + '/get.php?username=xxxx&password=xxxx&type=m3u_plus&output=ts'

ROQ TV - EPG url
http://roq-tv.net:25461/xmltv.php?username=xxxx&password=xxxx

You can access the online viewing platform here: 
http://roq-tv.net:25461/client_area/index.php?username=xxxx&password=xxxx
with or without username and password

"""

def ftvntvlist():
# Create a FTVNTV.INI file with all channels from ROQ TV
## This file contains the "built-in" channels
## It is parsed by Pythons ConfigParser
#
#[plugin.video.ntv]
#* * * * * *  NEW NTV CHANNELS 2015-05-01 * * * * * * *=
#24 Techno=plugin://plugin.video.ntv/?url=url&mode=200&name=24+Techno+-+%5BCOLOR+yellow%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fwww.ntv.mx%2Fres%2Fcontent%2Ftv%2F179.png&cat=179
#2x2=plugin://plugin.video.ntv/?url=url&mode=200&name=2x2+-+%5BCOLOR+yellow%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fwww.ntv.mx%2Fres%2Fcontent%2Ftv%2F177.png&cat=177
#5 Star=plugin://plugin.video.ntv/?url=url&mode=200&name=5+Star+-+%5BCOLOR+yellow%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fwww.ntv.mx%2Fres%2Fcontent%2Ftv%2F86.png&cat=86
#5 USA=plugin://plugin.video.ntv/?url=url&mode=200&name=5+USA+-+%5BCOLOR+yellow%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fwww.ntv.mx%2Fres%2Fcontent%2Ftv%2F64.png&cat=64
    channellist = os.path.join(datapath,'channels') + '.csv'
    ftvntvini = os.path.join(datapath,'ftv'+ADDONname) + '.ini'
    ntvchannelsm3u = os.path.join(datapath,ADDONname + 'channels') + '.m3u'
    favoritesm3u = (os.path.join(datapath,ADDONname + ' Favorites') + '.m3u').replace('\n','').replace('\n\n','').replace('\n\n\n','')
    netfavoritesm3u = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_path'),'favorites' + '.m3u'))
    netfavoritesaddonm3u = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_path'),(str(xbmc.getInfoLabel('System.FriendlyName'))+'-'+ADDONname + ' Favorites' + '.m3u')))
    ###utils.logdev('ftvntvlist','ftvroqtv= %s for %s' % (repr(os.path.isfile(ftvntvini)), repr(ftvntvini)))
    if os.path.isfile(channellist) == True: 
        ###utils.logdev('ftvntvlist','channellist exists - deleting')
        locking.deleteLockFile(channellist)
    if os.path.isfile(ftvntvini) == True: 
        ftvntviniOLD = os.path.join(datapath,'ftv'+ADDONname+'OLD') + '.ini'
        shutil.copyfile(ftvntvini, ftvntviniOLD)
        locking.deleteLockFile(ftvntvini)
    if os.path.isfile(ntvchannelsm3u) == True: 
        locking.deleteLockFile(ntvchannelsm3u)
    if os.path.isfile(favoritesm3u) == True: 
        locking.deleteLockFile(favoritesm3u)
    if os.path.isfile(favoritesm3u) == False: 
        now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        definition.ADDONsetSetting('lastEPGimportInfo','Start creating %r' % os.path.basename(favoritesm3u))
        LF = open(favoritesm3u, 'a')
        LF.write('#EXTM3U \n')
        ### #EXTINF:-1 tvg-id="epg_channel 9" tvg-name="id 0" tvg-logo="logo 2" group-title="",title 1
        ### stream_url 3  like http://<url>/live/xxxxx/yyyyy/16537.ts
        
        conn = getConnection()
        c = conn.cursor()
        try:
            c.execute("SELECT * FROM channels WHERE favorite<>? and favorite<>? and visible=? and source=?  COLLATE NOCASE", ['False','false',1,origin]) 
            favorites = c.fetchall()
        except Exception as e:
            log('err 374 Exception: %r' % e)
            pass
            log('c.execute("SELECT * FROM channels ERROR: %r' % e)
            favorites = []
        favorites = sorted(favorites, key=itemgetter(1)) ### Sort by name
        favorites = sorted(favorites, key=itemgetter(9)) ### Sort by EPG name
        ADDID1 = definition.ADDONgetSetting('my_referral_init')
        ADDID  = ADDID1[:3].upper()
        if len(ADDID) < 3 or ADDID1 == 'Not Set':
            ADDID = definition.ADDONgetSetting('basicuserinfofile').split(os.sep)[-1][:3].upper()
            definition.ADDONresetSetting('my_referral_init',ADDID)
        if ADDID != ADDID1:
            definition.ADDONresetSetting('my_referral_init',ADDID)
        for index in range(0, len(favorites)):
            try:
                ch = []
                for i in range(0, len(favorites[index])):
                    if favorites[index][i] == None:
                        ch.append('')
                    else:
                        ch.append(favorites[index][i])
                if ' (D' in ch[1]:
                    ADDIDhere = ''
                else:
                    ADDIDhere = ADDID + ' '
                if ch[7] != 'True':
                    favo = ' ' + ch[7]
                else:
                    favo = ''
                logo = ch[2]
                if logo == '' and ch[9] != '':  ### no logo, use channel ID to get logo
                    logo = getIconfromEPG(ch[9])
                if ch[9] + favo != '':
                    ###LF.write('#EXTINF:-1 tvg-id="' + ch[9] + '" tvg-name="' + ch[0] + '" tvg-logo="'+ logo + '" group-title="'+ADDONname +'",' + ch[9] + favo + ': ' + ADDIDhere + ch[1] + '\n')
                    LF.write('#EXTINF:-1 tvg-id="' + ch[9] + '" tvg-name="' + ch[0] + '" tvg-logo="'+ logo + '" group-title="'+ADDONname +'",' + ch[1] + '\n')
                else:
                    ###LF.write('#EXTINF:-1 tvg-id="' + ch[9] + '" tvg-name="' + ch[0] + '" tvg-logo="'+ logo + '" group-title="'+ADDONname +'",' + ADDIDhere + ch[1] + '\n')
                    LF.write('#EXTINF:-1 tvg-id="' + ch[9] + '" tvg-name="' + ch[0] + '" tvg-logo="'+ logo + '" group-title="'+ADDONname +'",' + ch[1] + '\n')
                LF.write(ch[3] + '\n')
            except Exception as e:
                log('error 409 LF.write(#EXTINF:-1 tvg-id Exception: %r' % e)
                pass
        c.close()  
        LF.close()
        definition.ADDONsetSetting('lastEPGimportInfo','Ended creating %r' % os.path.basename(favoritesm3u))
        try:
            if xbmcvfs.exists(favoritesm3u) and filesize(favoritesm3u) > 125 :  ### 2023-07-19 Don't copy favorites is it is empty
                log('error 466 favoritesm3u exists= %r' % favoritesm3u)
                copyOK = xbmcvfs.copy(favoritesm3u, netfavoritesm3u)
                if not copyOK:
                    log('error 469 Copy of %r failed - ERR: %r' %  (netfavoritesm3u,copyOK))
                copyOK = xbmcvfs.copy(favoritesm3u, netfavoritesaddonm3u)
                if not copyOK:
                    log('error 469 Copy of %r failed - ERR: %r' %  (netfavoritesaddonm3u,copyOK))
        except Exception as e:
            log('error 475 copy favoritesm3u Exception: %r' % e)
            pass
    if os.path.isfile(ftvntvini) == False:
        now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        # create file
        ###utils.logdev('ftvntvlist','ftvroqtv.ini beeing created ' + now)
        definition.ADDONsetSetting('lastEPGimportInfo','Start creating %r' % os.path.basename(ftvntvini))
        LF = open(ftvntvini, 'a')
        # Write to our text file the information we have provided and then goto next line in our file.
        LF.write('# This file contains the TV channels for your Package\n')
        LF.write('# Created by ' + definition.ADDONgetAddonInfo('name') +' at ' + now + '\n')
        LF.write('[' + definition.ADDONgetAddonInfo('id') + ']\n')
        LF.write('\n')
        ftvntvinifile = ftvntvini.replace(datapath,'')
        try:
            CHANNELlist(LF)
            if definition.ADDONgetSetting('notifyduringepgupdate') == 'true':    
                utils.notification('[COLOR green]'+ftvntvinifile+' created[/COLOR]')
        except Exception as e:
            log('errorX 422 Exception: %r' % e)
            pass
            thiserror = 'ftvntvlist Error in get CHANNELlist: %r' % e
            log(thiserror)
            LF.write(thiserror)
            LF.write('\n')
            utils.notificationforced('[COLOR red]%r - Access to %s channel list is not available[CR]%s NOT generated![/COLOR]' % (e,ADDONname,ftvntvinifile) )
            ###utils.notificationbox('[COLOR red]Check your internet connection![/COLOR][CR][CR][COLOR green]Access to %s channel list is not available[CR]ftvroqtv.ini NOT generated![/COLOR]' % definition.ADDONgetAddonInfo('name') )
        LF.write('\n')
        now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        LF.write('# End of ' + ADDONname + ' channels - ended at ' + now + '\n')
        # Close our file so no further writing is posible.
        LF.close()
        definition.ADDONsetSetting('lastEPGimportInfo','Ended creating %r' % os.path.basename(ftvntvini))
        
        ftvntvini = os.path.join(datapath,'Channels '+ADDONname) + '.txt'
        definition.ADDONsetSetting('lastEPGimportInfo','Start creating %r' % os.path.basename(ftvntvini))
        LF = open(ftvntvini, 'w')
        # Write to our text file the information we have provided and then goto next line in our file.
        LF.write('# This file contains the TV channels for your Package\n')
        LF.write('# Created by ' + definition.ADDONgetAddonInfo('name') +' at ' + now + '\n')
        LF.write('[' + definition.ADDONgetAddonInfo('id') + ']\n')
        LF.write('\n')
        ftvntvinifile = ftvntvini.replace(datapath,'')
        try:
            CHANNELDisplaylist(LF)
            if definition.ADDONgetSetting('notifyduringepgupdate') == 'true':
                utils.notificationforced('[COLOR green]'+ftvntvinifile+' created[/COLOR]')
        except Exception as e:
            log('errorX 446 Exception: %r' % e)
            pass
            thiserror = 'ftvntvlist Error in get CHANNELDisplaylist: %r' % e
            log(thiserror)
            LF.write(thiserror)
            LF.write('\n')
            utils.notificationforced('[COLOR red]Access to %s channel list is not available[CR]%s NOT generated![/COLOR]' % (ADDONname,ftvntvinifile) )
            ###utils.notificationbox('[COLOR red]Check your internet connection![/COLOR][CR][CR][COLOR green]Access to %s channel list is not available[CR]ftvroqtv.ini NOT generated![/COLOR]' % definition.ADDONgetAddonInfo('name') )
        LF.write('\n')
        now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        LF.write('# End of ' + ADDONname + ' channels - ended at ' + now + '\n')
        # Close our file so no further writing is posible.
        LF.close()
        definition.ADDONsetSetting('lastEPGimportInfo','Ended creating %r' % os.path.basename(ftvntvini))
        
    if os.path.isfile(channellist) == False:
        now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        # create file
        log('528 errorX CHANNELcsvlist channellist beeing created ' + now)
        definition.ADDONsetSetting('lastEPGimportInfo','Start creating %r' % os.path.basename(channellist))
        LF = open(channellist, 'a')
        # Write to our text file the information we have provided and then goto next line in our file.
        try:
            CHANNELcsvlist(LF)
            if definition.ADDONgetSetting('notifyduringepgupdate') == 'true':
                utils.notificationforced('[COLOR green]channels.csv created[/COLOR]')
        except Exception as e:
            log('errorX 468 Exception: %r' % e)
            utils.notificationforced('[COLOR red]channels.csv not created[/COLOR][CR]Error= %r' % e)
        LF.write('\n')
        # Close our file so no further writing is posible.
        LF.close()
        definition.ADDONsetSetting('lastEPGimportInfo','Ended creating %r' % os.path.basename(channellist))
        
def CHANNELcsvlist(LF):   
    nowDate= datetime.today().strftime('%Y-%m-%d')
    channels = getAllChannelsList()
    ###channels = sorted(channels, key=itemgetter(1))
    ###channels = sorted(channels,key=lambda i:i[1].lower())  ### Sort ignore case coloum 1
    krogsbelladdons = []
    KrogsbellAddOns = definition.getKrogsbellAddOns()
    log('KrogsbellAddOns= %r' % KrogsbellAddOns)
    for kaddon in KrogsbellAddOns:
        log('kaddon= %r' % kaddon)
        try:
            kaddonID = kaddon.split('.')[2][:3].upper()
            taddonID = ADDONid.split('.')[2][:3].upper()
        except Exception as e:
            log('err 488 Exception: %r' % e)
            pass
            EpgError = 'Error in getting AddOn ID\n' + repr(e) 
            kaddonID = ''
            taddonID = ''
        log('kaddonID= %r' % kaddonID)
        log('taddonID= %r' % taddonID)
        if kaddonID != '' and kaddonID != taddonID:
            krogsbelladdons.append(kaddonID)
    log('krogsbelladdons= %r' % krogsbelladdons)
    for field in channels:
        cat          = field[0]
        """
        try:
            name = utils.untilD8(field[1])
            log('570 error CHANNELcsvlist name= %r' % name)
        except Exception as e:
            log('error 572 CHANNELcsvlist Exception: %r' % e)
            pass
            name = field[1][0:24]
        """
        name = field[1]
        url          = field[2]
        epg_channel  = field[3]
        logo         = field[4]
        otheraddon = False
        log('585 error CHANNELcsvlist name= %r' % name)
        for id in krogsbelladdons:
            if ' (' + id + ')' in name:
                otheraddon = True
        ###log('url != %r and /live/ in url.lower() %r and not (D) in name %r and not otheraddon %r and name[:2] != ▬  %r ' % (url != 'url',not '/live/' in url.lower(),' (D)' in name, not otheraddon, name[:2]))
        ###if url != 'url' and '/live/' in url.lower() and not ' (D)' in name and not otheraddon and name[:2] != '▬ ':
        log('591 error CHANNELcsvlist name= %r' % name)
        if url != 'url' and '/live/' in url.lower() and not ' (D' in name and not otheraddon and name[:2] != '▬ ' and name[:4] != '\xe2\x96\xac ':
            try:
                log('594 error CHANNELcsvlist name= %r' % name)
                line=cat + ',' + name + ',' + epg_channel + ',' + logo + ',,,,'
                LF.write(line + '\n')   
            except Exception as e:
                log('error 1653 CHANNELlist Exception: %r' % e)
                pass
                line=cat + ',' + latin1_to_ascii_force(name) + ',' + epg_channel + ',' + logo + ',,,,'
                LF.write(line + '\n')

def CHANNELlist(LF):   ### ROQ TV
    nowDate= datetime.today().strftime('%Y-%m-%d')
    log('584 error CHANNELlist LF= %r' % LF)
    krogsbelladdons = []
    KrogsbellAddOns = definition.getKrogsbellAddOns()
    log('587 error KrogsbellAddOns= %r' % KrogsbellAddOns)
    for kaddon in KrogsbellAddOns:
        log('589 error kaddon= %r' % kaddon)
        try:
            kaddonID = kaddon.split('.')[2][:3].upper()
            taddonID = ADDONid.split('.')[2][:3].upper()
        except Exception as e:
            log('error 594 Exception: %r' % e)
            pass
            EpgError = 'Error in getting AddOn ID\n' + repr(e) 
            kaddonID = ''
            taddonID = ''
        log('kaddonID= %r' % kaddonID)
        log('taddonID= %r' % taddonID)
        if kaddonID != '' and kaddonID != taddonID:
            krogsbelladdons.append(kaddonID)
    LF.write('# My ' + definition.ADDONgetAddonInfo('name') + ' Channels\n')
    LF.write(' \n \n \n*** My ' + definition.ADDONgetAddonInfo('name') + ' Live Channels at ' + nowDate + ' ***********************=\n')
    ### channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER)
    ### channels = []
    log('607 error CHANNELlist')
    channels = getAllChannelsList()
    log('609 error CHANNELlist')
    ###channels = sorted(channels, key=itemgetter(1))
    ###channels = sorted(channels,key=lambda i:i[1].lower())  ### Sort ignore case coloum 1
    LIVE  = '/live/'
    MOVIE = '/movie/'
    SERIES= '/series/'
    log('615 error CHANNELlist')
    for field in channels:
        log('617 error CHANNELlist')
        cat          = field[0]
        """
        try:
            name = utils.untilD8(field[1])
            log('627 error CHANNELlist name= %r' % name)
        except Exception as e:
            log('error 629 CHANNELlist Exception: %r' % e)
            pass
            name = field[1][0:24]
        """
        name = field[1]
        url          = field[2]
        otheraddon = False
        log('622 error CHANNELlist')
        for id in krogsbelladdons:
            if ' (' + id + ')' in name:
                otheraddon = True
        ###if url != 'url' and '/live/' in url.lower():
        ###if url != 'url' and '/live/' in url.lower() and not ' (D)' in name and not otheraddon and name[:2] != '▬ ':
        urll = url.lower()
        log('629 CHANNELlist name= %r' % name)
        if url != 'url' and (LIVE in urll or not MOVIE in urll and not SERIES in urll) and not ' (D' in name and not otheraddon and name[:2] != '▬ ' and name[:4] != '\xe2\x96\xac ':
            try:
                line=name + '=' + url
                LF.write(line + '\n')
            except Exception as e:
                log('error 2653 CHANNELlist Except: %r' % e)
                pass
                line=latin1_to_ascii_force(name) + '=' + latin1_to_ascii_force(url)
                log('error 12653 CHANNELlist Except: line= %r' % line)
                LF.write(line + '\n')
    
    LF.write(' \n \n \n*** My ' + definition.ADDONgetAddonInfo('name') + ' Videos at ' + nowDate + ' ***********************=\n')
    for field in channels:

        cat          = field[0]
        """
        try:
            name = utils.untilD8(field[1])
            log('652 error CHANNELlist name= %r' % name)
        except Exception as e:
            log('error 654 CHANNELlist Exception: %r' % e)
            pass
            name = field[1][0:24]
        """
        name = field[1]
        url          = field[2]
        
        ###if url != 'url' and not '/live/' in url.lower() and not ' (D)' in name and not otheraddon and name[:2] != '▬ ':
        urll = url.lower()
        if url != 'url' and MOVIE in urll and not ' (D' in name and not otheraddon and name[:2] != '▬ ' and name[:4] != '\xe2\x96\xac ':
            try:
                line=name + '=' + url
                LF.write(line + '\n')
            except Exception as e:
                log('error 3653 CHANNELlist Exception: %r' % e)
                pass
                line=latin1_to_ascii_force(name) + '=' + latin1_to_ascii_force(url)
                LF.write(line + '\n')
    LF.write(' \n \n \n*** My ' + definition.ADDONgetAddonInfo('name') + ' Series at ' + nowDate + ' ***********************=\n')
    for field in channels:

        cat          = field[0]
        """
        try:
            name = utils.untilD8(field[1])
            log('671 error CHANNELlist name= %r' % name)
        except Exception as e:
            log('error 673 CHANNELlist Exception: %r' % e)
            pass
            name = field[1][0:24]
        """
        name         = field[1]
        url          = field[2]
        
        ###if url != 'url' and not '/live/' in url.lower() and not ' (D)' in name and not otheraddon and name[:2] != '▬ ':
        urll = url.lower()
        log('730 error urll= %r' % urll)
        if url != 'url' and SERIES in urll and not ' (D' in name and not otheraddon and name[:2] != '▬ ' and name[:4] != '\xe2\x96\xac ':
            try:
                line=name + '=' + url
                LF.write(line + '\n')
            except Exception as e:
                log('error 4653 CHANNELlist Exception: %r' % e)
                pass
                line=latin1_to_ascii_force(name) + '=' + latin1_to_ascii_force(url)
                LF.write(line + '\n')
    
def CHANNELDisplaylist(LF):   ### ROQ TV
    nowDate= datetime.today().strftime('%Y-%m-%d')
    krogsbelladdons = []
    KrogsbellAddOns = definition.getKrogsbellAddOns()
    log('660 error CHANNELDisplaylist KrogsbellAddOns= %r' % KrogsbellAddOns)
    for kaddon in KrogsbellAddOns:
        log('662 error CHANNELDisplaylist kaddon= %r' % kaddon)
        try:
            kaddonID = kaddon.split('.')[2][:3].upper()
            taddonID = ADDONid.split('.')[2][:3].upper()
        except Exception as e:
            log('error 597 CHANNELDisplaylist Exception: %r' % e)
            pass
            EpgError = 'Error in getting AddOn ID\n' + repr(e) 
            kaddonID = ''
            taddonID = ''
        log('kaddonID= %r' % kaddonID)
        log('taddonID= %r' % taddonID)
        if kaddonID != '' and kaddonID != taddonID:
            krogsbelladdons.append(kaddonID)
    log('676 error CHANNELDisplaylist LF= %r' % LF)
    LF.write('# My ' + definition.ADDONgetAddonInfo('name') + ' Channels\n')
    LF.write(' \n \n \n*** My ' + definition.ADDONgetAddonInfo('name') + ' Live Channels at ' + nowDate + ' ***********************=\n')
    ### channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER)
    ### channels = []
    channels = getAllChannelsList()
    log('682 error CHANNELDisplaylist')
    ###channels = sorted(channels, key=itemgetter(1))
    i = 0
    LIVE  = '/live/'
    MOVIE = '/movie/'
    SERIES= '/series/'
    for field in channels:
        cat          = field[0]
        """
        try:
            name = utils.untilD8(field[1])
            log('702 error CHANNELDisplaylist name= %r' % name)
        except Exception as e:
            log('error 705 CHANNELDisplaylist Exception: %r' % e)
            pass
            name = field[1][0:24]
        """
        name = field[1]
        url          = field[2]
        otheraddon = False
        for id in krogsbelladdons:
            if ' (' + id + ')' in name:
                otheraddon = True
        ###if url != 'url' and 'live' in url.lower() and not ' (D)' in name:
        urll = url.lower()
        if url != 'url' and (LIVE in urll or not MOVIE in urll and not SERIES in urll) and not ' (D' in name and not otheraddon and name[:2] != '▬ ' and name[:4] != '\xe2\x96\xac ':
            i += 1
            try:
                line=format(i, '04d') + ' ' + name
                LF.write(line + '\n')
            except Exception as e:
                log('error 761 CHANNELDisplaylist Except: %r' % e)
                pass
                line=format(i, '04d') + ' ' + latin1_to_ascii_force(name)
                LF.write(line + '\n')
    
    LF.write(' \n \n \n*** My ' + definition.ADDONgetAddonInfo('name') + ' Videos at ' + nowDate + ' ***********************=\n')
    i = 0
    for field in channels:

        cat          = field[0]
        """
        try:
            name = utils.untilD8(field[1])
            log('724 error CHANNELDisplaylist name= %r' % name)
        except Exception as e:
            log('error 725 CHANNELDisplaylist Exception: %r' % e)
            pass
            name = field[1][0:24]
        """
        name = field[1]
        url          = field[2]
        otheraddon = False
        for id in krogsbelladdons:
            if ' (' + id + ')' in name:
                otheraddon = True
        ###if url != 'url' and not 'live' in url.lower() and not ' (D)' in name:
        urll = url.lower()
        if url != 'url' and MOVIE in urll and not ' (D' in name and not otheraddon and name[:2] != '▬ ' and name[:4] != '\xe2\x96\xac ':
        ###if url != 'url' and not '/live/' in url.lower() and not ' (D)' in name and not otheraddon and name[:2] != '▬ ':
            i += 1
            try:
                line=format(i, '04d') + ' ' + name
                LF.write(line + '\n')
            except Exception as e:
                log('error 792 CHANNELDisplaylist Except: %r' % e)
                pass
                line=format(i, '04d') + ' ' + latin1_to_ascii_force(name)
                LF.write(line + '\n')
    LF.write(' \n \n \n*** My ' + definition.ADDONgetAddonInfo('name') + ' Series at ' + nowDate + ' ***********************=\n')
    i = 0
    for field in channels:

        cat          = field[0]
        """
        try:
            name = utils.untilD8(field[1])
            log('749 error CHANNELDisplaylist name= %r' % name)
        except Exception as e:
            log('error 751 CHANNELDisplaylist Except: %r' % e)
            pass
            name = field[1][0:24]
        """
        name = field[1]
        url          = field[2]
        otheraddon = False
        for id in krogsbelladdons:
            if ' (' + id + ')' in name:
                otheraddon = True
        ###if url != 'url' and not 'live' in url.lower() and not ' (D)' in name:
        urll = url.lower()
        if url != 'url' and SERIES in urll and not ' (D' in name and not otheraddon and name[:2] != '▬ ' and name[:4] != '\xe2\x96\xac ':
        ###if url != 'url' and not '/live/' in url.lower() and not ' (D)' in name and not otheraddon and name[:2] != '▬ ':
            i += 1
            try:
                line=format(i, '04d') + ' ' + name
                LF.write(line + '\n')
            except Exception as e:
                log('error 653 CHANNELDisplaylist Exception: %r' % e)
                pass
                line=format(i, '04d') + ' ' + latin1_to_ascii_force(name) 
                LF.write(line + '\n')

def CHANNELlistNTV(LF):
    #cat = '16' # NTV Ultimate
    #cat = '-2' # My Channels
    #cat = '-1' # My Favorites
    #cat = '10' # Indian Tv
    #cat = '15' # Scandinavian
    #cat = '12' # DK + UK ?
    #cats = ['-2','-1','0','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30']
    nowDate= datetime.today().strftime('%Y-%m-%d')
    if referralLink() == '1':
        cats = ['-2','-1','16']
    if referralLink() == '2':
        cats = ['10']
    if referralLink() == '3':
        cats = ['-2','10','20','25']
    if not referralLink() == '1' and not referralLink() == '2' and not referralLink() == '3'  :
        cats = ['-2','-1','16']
    for cat in cats:
        if cat == '-2':
            LF.write('# cat= ' + cat + ' My ' + definition.ADDONgetAddonInfo('name') + ' Channels\n')
            LF.write('*** My ' + definition.ADDONgetAddonInfo('name') + ' Channels at ' + nowDate + ' ***********************=\n')
        elif cat == '-1':
            LF.write('# cat= ' + cat + ' My Favorites ' + definition.ADDONgetAddonInfo('name') + ' Channels\n')
            LF.write('*** My Favorites ' + definition.ADDONgetAddonInfo('name') + ' Channels at ' + nowDate + ' ***********************=\n')
        elif cat == '16':
            LF.write('# cat= ' + cat + ' ' + definition.ADDONgetAddonInfo('name') + ' Ultimate Channels\n')
            LF.write('*** ' + definition.ADDONgetAddonInfo('name') + ' Ultimate Channels at ' + nowDate + ' ***********************=\n')
        else:
            LF.write('# cat= ' + cat + '\n')
            LF.write('*** ' + definition.ADDONgetAddonInfo('name') + ' Channels #' + cat + ' at ' + nowDate + ' ***********************=\n')
        """
        from hashlib import md5
        streamtype = definition.ADDONgetSetting('streamtype')
        if streamtype == '0':
            STREAMTYPE = 'NTV-XBMC-HLS-'
        elif streamtype == '1':
            STREAMTYPE = 'NTV-XBMC-'
        site=definition.getBASEURL() + '/index.php?' + referral()+ 'c=6&a=0'
        datapath = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
        cookie_path = os.path.join(datapath, 'cookies')
        cookie_jar = os.path.join(cookie_path, "ntv.lwp")
        UA=STREAMTYPE + definition.ADDONgetAddonInfo('version') 
        #print  "UA=STREAMTYPE + definition.ADDONgetAddonInfo('version')= " + str(repr(UA))
        netX=net.Net()
        loginurl = definition.getBASEURL() + '/index.php?' + referral() + 'c=3&a=4'
        username    =definition.ADDONgetSetting('user')
        password =md5(definition.ADDONgetSetting('pass')).hexdigest()

        data     = {'email': username,
                                                'psw2': password,
                                                'rmbme': 'on'}
        headers  = {'Host':definition.getBASEURL().replace('http://',''),
                                                'Origin':definition.getBASEURL() + '',
                                                'Referer':definition.getBASEURL() + '/index.php?' + referral() + 'c=3&a=0','User-Agent' : UA}

        html = netX.http_POST(loginurl, data, headers).content
        if 'success' in html:
            if os.path.exists(cookie_path) == False:
                os.makedirs(cookie_path)
            netX.save_cookies(cookie_jar)


        #print 'default.py CHANNELS(name= %s, cat= %s)' % (repr(name),repr(cat))
        netX.set_cookies(cookie_jar)
        imageUrl=definition.getBASEURL() + '/res/content/tv/'
        now= datetime.today().strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20')
        url='&mwAction=category&xbmc=1&mwData={"id":"%s","time":"%s","type":"tv"}'%(cat,now)
        #print 'default.py YYYY site+url= %s%s'  % (site,url)
        link = netX.http_GET(site+url, headers={'User-Agent' : UA}).content
        """
        
        data = json.loads(link)
        channels=data['contents']
        
        channels = sorted(channels, key=itemgetter('name'))
        BASE=data['base_url']
        log('CHANNELlist cat= %r with BASE= %r' % (cat, BASE))
        log('CHANNELlist imageUrl= %r' % imageUrl)
        for field in channels:
            #iconimage=BASE+field['icon']
            endTime      =  field['time_to']
            name         =  field['name']      ###.encode("utf-8")
            channel      =  field['id']
            whatsup      =  field['whatsup']   ###.encode("utf-8")
            description  =  field['descr']     ###.encode("utf-8")
            iconimage = getIcon(name,channel)   ##############################################################################################
            if referralLink() == '-1':   ### 2016-05-04 don't show (record)/(view) for wozbox any more
                line=name + ' (record)=plugin://' + definition.ADDONgetAddonInfo('id') + '/?url=url&mode=2009&name=' + urllib.quote_plus(name) + '+-+%5BCOLOR+red%5Dn+a%5B%2FCOLOR%5D&iconimage=' + urllib.quote_plus(iconimage) + '&cat=' + channel 
                LF.write(line + '\n')
                line=name + ' (view)=plugin://' + definition.ADDONgetAddonInfo('id') + '/?url=url&mode=200&name=' + urllib.quote_plus(name) + '+-+%5BCOLOR+green%5Dn+a%5B%2FCOLOR%5D&iconimage=' + urllib.quote_plus(iconimage) + '&cat=' + channel 
            if not referralLink() == '-1':
                line=name + ' =plugin://' + definition.ADDONgetAddonInfo('id') + '/?url=url&mode=200&name=' + urllib.quote_plus(name) + '+-+' + urllib.quote_plus(name) + '&iconimage=' + urllib.quote_plus(iconimage) + '&cat=' + channel 
            LF.write(line + '\n')

def referralLink():
    # 0= NTV, 1= WOZBOX www.wozboxtv.com
    referralLink=definition.ADDONgetSetting('my_referral_link')
    return referralLink

def referral():
    #site=definition.getBASEURL() + '/index.php?c=6&a=0'
    #referralLink=definition.ADDONgetSetting('my_referral_link')
    #if referralLink == '1':
    #   referral = 'r=wb&'
    #else:
    referral = ''
    #referralsite='http://www.ntv.mx/index.php?' + referral+ 'c=6&a=0'
    return referral

def parseDate(dateString):
    ### dateString ==> dt_obj
    x = 'start'
    try:   ### Keep dt_obj
        if type(dateString) == datetime:
            log('parseDate(return 1 dateString= %r)' % dateString)
            return dateString
    except Exception as e:
        log('788 Except: %r' % e)
        pass
        log('parseDate(pass 2 dateString= %r, ERROR: %r)' % (dateString,e))
    try:   ### truncate to seconds
        dateString = dateString.split('.')[0]  ### 2017-09-20 02:37:26.143149 ==> 2017-09-20 02:37:26
    except Exception as e:
        log('794 Except: %r' % e)
        pass
    try:   ### replace 'web space'
        x = dateString.replace('%20', ' ')
        dateString = x
    except Exception as e:
        log('800 Except: %r' % e)
        pass
    try:   ### normal datestring as input
        #dateString = '2050-01-01 00:00:00'
        time_tuple = datetime.strptime(dateString, "%Y-%m-%d %H:%M:%S")
        x = datetime(*time_tuple[0:6])
        return x
    except Exception as e:
        log('808 Except: %r' % e)
        pass
    try:   ### is dateString timestamp
        dateString = int(dateString)
        x = datetime.fromtimestamp(time.mktime(dateString))
        return x
    except Exception as e:
        log('815 Except: %r' % e)
        pass
    try:
        if isinstance(dateString, datetime.date):
            time_tuple = dateString.timetuple()
            x = datetime(*time_tuple[0:6])
            return x
    except Exception as e:
        log('823 Except: %r' % e)
        pass
    try:
        x = datetime.fromtimestamp(time.mktime(time.strptime(dateString, "%Y-%m-%d")))
        return x
    except Exception as e:
        log('829 Except: %r' % e)
        pass
    try:
        x = datetime.fromtimestamp(time.mktime(time.strptime(dateString, "%Y-%m-%d %H:%M:%S")))
        return x
    except Exception as e:
        log('835 Except: %r' % e)
        pass 
    try:
        time_tuple = time.strptime(dateString, "%Y-%m-%d %H:%M:%S")
        dt_obj = datetime(*time_tuple[0:6])
        return dt_obj
    except Exception as e:
        log('842 Except: %r' % e)
        pass
    try:
        x = datetime.fromtimestamp(time.mktime(time.strptime(dateString, "%Y-%m-%d %H:%M:%S")))
        return x
    except Exception as e:
        log('848 Except: %r' % e)
        pass
    try:
        date_str = safe_str(dateString)
        time_tuple = time.strptime(date_str, "%Y-%m-%d %H:%M:%S")
        x = datetime(*time_tuple[0:6])
        return x
    except Exception as e:
        log('856 Except: %r' % e)
        pass
    try:
        xint = float(dateString)
        x = datetime.fromtimestamp(xint)
        return x
    except Exception as e:
        log('863 Except: %r' % e)
        pass
    x = datetime.today() ### + timedelta(days = 100) # ERROR RETURN
    ###log('parseDate FAILED returning some time in the future + 100 days: parseDate(dateString= %r) ==> %r' %(dateString,x))
    log('err parseDate FAILED returning now: parseDate(dateString= %r) ==> %r' %(dateString,x))
    return x 

def parseDateNEW(dateString):
    ### dateString ==> dt_obj
    modulex = 'parseDate'
    log('parseDate(dateString= %r)' % dateString)
    x = datetime.now()
    log('parseDate(now x= %r)' % x)
    
    try:
        if dateString == None:
            log('parseDate(return 1 x= %r)' % x)
            return x
    except Exception as e:
        log('err 882 Except: %r' % e)
        pass
        log('parseDate(pass 1 dateString= %r, ERROR: %r)' % (dateString,e))
    try:
        x = dateString.replace('%20', ' ')
        log('parseDate(replace 1,5 x= %r, dateString= %r)' % (x,dateString))
        dateString = x
    except Exception as e:
        log('err 890 Except: %r' % e)
        pass
        log('parseDate(pass 2 dateString= %r, ERROR: %r)' % (dateString,e))
    try:
        dateString = int(dateString)
        x = datetime.fromtimestamp(time.mktime(dateString))
        log('parseDate(return 2 x= %r)' % x)
        return x
    except Exception as e:
        log('err 899 Except: %r' % e)
        pass
        log('parseDate(pass 3 dateString= %r, ERROR: %r)' % (dateString,e))
    try:
        dateString = dateString.split('.')[0]  ### 2017-09-20 02:37:26.143149 ==> 2017-09-20 02:37:26
    except Exception as e:
        log('err 905 Except: %r' % e)
        pass
        log('parseDate(pass 4 dateString= %r, ERROR: %r)' % (dateString,e))
    log('parseDate(pass 3 dateString= %r)' % dateString)
    try:
        if type(dateString) == datetime:
            log('parseDate(return 4 dateString= %r)' % dateString)
            return dateString
    except Exception as e:
        log('err 914 Except: %r' % e)
        pass
        log('parseDate(pass 5 dateString= %r, ERROR: %r)' % (dateString,e))
    try:
        #dateString = '2050-01-01 00:00:00'
        time_tuple = datetime.strptime(dateString, "%Y-%m-%d %H:%M:%S")
        #time_tuple = time.strptime(dateString, "%Y-%m-%d %H:%M:%S")
        x = datetime(*time_tuple[0:6])
        log('parseDate(return 5 x= %r)' % x)
        return x
    except Exception as e:
        log('err 925 Except: %r' % e)
        pass
        log('parseDate(pass 6 dateString= %r, ERROR: %r)' % (dateString,e))
    try:
        if isinstance(dateString, datetime.date):
            time_tuple = dateString.timetuple()
            x = datetime(*time_tuple[0:6])
            log('parseDate(return 6 x= %r, dateString= %r)' % (x,dateString))
            return x
    except Exception as e:
        log('err 935 Except: %r' % e)
        pass
        log('parseDate(pass 7 dateString= %r, ERROR: %r)' % (dateString,e))
    try:
        x = datetime.fromtimestamp(time.mktime(time.strptime(dateString, "%Y-%m-%d")))
        log('parseDate(return 8 x= %r, dateString= %r)' % (x,dateString))
        return x
    except Exception as e:
        log('err 943 Except: %r' % e)
        pass
        log('parseDate(pass 8 dateString= %r, ERROR: %r)' % (dateString,e))
    try:
        x = datetime.fromtimestamp(time.mktime(time.strptime(dateString, "%Y-%m-%d %H:%M:%S")))
        log('parseDate(return 9 x= %r, dateString= %r)' % (x,dateString))
        return x
    except Exception as e:
        log('err 951 Except: %r' % e)
        pass
        log('parseDate(pass 9 dateString= %r, ERROR: %r)' % (dateString,e))
    try:
        time_tuple = time.strptime(dateString, "%Y-%m-%d %H:%M:%S")
        dt_obj = datetime(*time_tuple[0:6])
        log('parseDate(return 10 dt_obj= %r, dateString= %r)' % (dt_obj,dateString))
        return dt_obj
    except Exception as e:
        log('err 960 Except: %r' % e)
        pass
        log('parseDate(pass 10 dateString= %r, ERROR: %r)' % (dateString,e))
    try:
        x = datetime.fromtimestamp(time.mktime(time.strptime(dateString, "%Y-%m-%d %H:%M:%S")))
        log('parseDate(return 11 x= %r, dateString= %r)' % (x,dateString))
        return x
    except Exception as e:
        log('err 968 Except: %r' % e)
        pass
        log('parseDate(pass 11 dateString= %r, ERROR: %r)' % (dateString,e))
    try:
        date_str = safe_str(dateString)
        time_tuple = time.strptime(date_str, "%Y-%m-%d %H:%M:%S")
        x = datetime(*time_tuple[0:6])
        log('parseDate(return 12 x= %r, dateString= %r)' % (x,dateString))
        return x
    except Exception as e:
        log('err 978 Except: %r' % e)
        pass
        log('parseDate(pass 12 dateString= %r, ERROR: %r)' % (dateString,e))
    try:
        xint = float(dateString)
        x = datetime.fromtimestamp(xint)
        log('parseDate(return 13 x= %r, dateString= %r)' % (x,dateString))
        return x
    except Exception as e:
        log('err 987 Except: %r' % e)
        pass
        log('parseDate(pass 13 dateString= %r, ERROR: %r)' % (dateString,e))
    x = datetime.today()  + timedelta(days = 100) # ERROR RETURN
    log('parseDate FAILED returning some time in the future + 100 days: parseDate(dateString= %r) ==> %r' %(dateString,x))
    return x 
    
def filesize(infile):
    try:
        file = open(infile,'r')
        contents = file.read()
        return len(contents)
    except Exception as e:
        log('err 1000 Except: %r' % e)
        pass
        log('filesize(infile= %r) ERROR: %r' % (infile,e))
        return 0
       
def backupSetupxml():
    try:
        dbPath = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
        if not os.path.exists(dbPath):
            os.mkdir(dbPath)        
        timestampnow = datetime.now()
        timestampnowS = str(datetime.now()).split('.')[0].replace('-','').replace(' ','').replace(':','') + '-'
        backupSrc = os.path.join(dbPath, SETTINGSXML)
        if filesize(backupSrc) > 0:
            backupDst = os.path.join(dbPath, timestampnowS + SETTINGSXML)
            shutil.copyfile(backupSrc, backupDst)
    except Exception as e:
        log('err 1017 Except: %r' % e)
        pass
        log('backupSetupxml recordings.py backup SETTINGSXML Failed!\nERROR: %r' % e)  # Put in LOG
        
    path = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
    files =  glob.glob(os.path.join(path, '*-' + SETTINGSXML))
    files1 = sorted(files, reverse=True)
    index = 0   
    try:
        BackupCount = int(definition.ADDONgetSetting('BackupCount'))  
    except Exception as e:
        log('err 1028 Except: %r' % e)
        pass
        BackupCount = 25
    for infile in files1:
        ###log('index= %r, Filename start= %r' % (index,infile))
        infileBasic = os.path.basename(infile)
        if infileBasic != SETTINGSXML : ### SETTINGSXML skipped
            size = filesize(infile)
            if index < BackupCount and size > 0:
                try:
                    index += 1
                except Exception as e:
                    log('err 1040 Except: %r' % e)
                    pass
                    utils.notificationforced('[COLOR red]Restoring %s cleanup FAILED![/COLOR]' % SETTINGSXML)
            else:
                try:
                    if size > 0:
                        index += 1
                    deleteFile(infile)
                except Exception as e:
                    log('err 1049 Except: %r' % e)
                    pass
                    utils.notificationforced('[COLOR red]Restoring %s cleanup FAILED![/COLOR]' % SETTINGSXML)
    
def restoreSetupXml(backupSrc):
    try:
        utils.notificationforced('[COLOR green]Restoring %s[/COLOR]' % SETTINGSXML,time=1000)
        backupSetupxml()
        dbPath = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
        if not os.path.exists(dbPath):
            os.mkdir(dbPath)
        backupDst = os.path.join(dbPath, SETTINGSXML)
        if filesize(backupDst) > 0:
            deleteFile(backupDst)
            shutil.copyfile(backupSrc, backupDst)
            #reschedule()
            utils.notificationforced('[COLOR green]Restoring %s Finished![/COLOR]' % SETTINGSXML)
        else:
            utils.notificationforced('[COLOR red]Restoring %s NOT done - file size is zero![/COLOR]' % SETTINGSXML)
    except Exception as e:
        log('err 1069 Except: %r' % e)
        pass
        utils.notificationforced('[COLOR red]Restoring %s FAILED![/COLOR]' % SETTINGSXML)

def restoreLastSetupXml():
    log('err 1119 restoreLastSetupXml START')
    path = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
    files =  glob.glob(os.path.join(path, '*.xml'))
    defaultfile = os.path.join(path, SETTINGSXML)
    log('err 1123 restoreLastSetupXml defaultfile= %r' % defaultfile)
    files1 = sorted(files, reverse=True)
    log('err 1125 restoreLastSetupXml')
    storedusers = []
    index = 0
    try:
        BackupCount = int(definition.ADDONgetSetting('BackupCount'))  
    except Exception as e:
        log('err 1131 Except: %r' % e)
        pass
        BackupCount = 25
    restored = False
    log('err 1135 restoreLastSetupXml')
    for infile in files1:
        log('err 1137 restoreLastSetupXml')
        mail = utils.username(infile)
        firstmailoccurance = True
        for xmail in storedusers:   ######
            if xmail == mail:
                firstmailoccurance = False
        if firstmailoccurance:
            storedusers.append(mail)
            log('Storedusers: ' +repr(storedusers))  
        if index < BackupCount:
            try:
                log('err 1148 restoreLastSetupXml')
                index += 1
                mail = utils.username(infile)
                if restored == False and not infile == defaultfile and not mail == '': 
                    if filesize(infile) > 0:
                        deleteFile(defaultfile)
                        shutil.copyfile(infile, defaultfile)
                        #utils.notification('[COLOR green]Restoring %s Finished![/COLOR]' % SETTINGSXML)
                        restored = True
            except Exception as e:
                log('err 1158 Except: %r' % e)
                pass
                utils.notificationforced('[COLOR red]Restoring %s FAILED![/COLOR]' % SETTINGSXML)
        else:
            try:
                if restored == True:
                    index += 1
                    log('err 1165 restoreLastSetupXml')
                    if not infile == defaultfile and not firstmailoccurance: 
                        deleteFile(infile)
            except Exception as e:
                log('err 1169 Except: %r' % e)
                pass
                utils.notificationforced('[COLOR red]Restoring %s cleanup FAILED![/COLOR]' % SETTINGSXML)
    log('err 1172 restoreLastSetupXml')
    return restored
        
def backupDataBase():
    try:
        dbPath = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
        if not os.path.exists(dbPath):
            os.mkdir(dbPath)
        backupSrc = os.path.join(dbPath, RECORDS_DB)
        timestampnow = datetime.now()
        timestampnowS = str(datetime.now()).split('.')[0].replace('-','').replace(' ','').replace(':','') + '-'
        usernamed = definition.ADDONgetSetting('user') + '-'
        backupDst = os.path.join(dbPath, timestampnowS + usernamed + RECORDS_DB)
        log('errorZ backupDst= %r' % backupDst)
        if usernamed != '-':
            shutil.copyfile(backupSrc, backupDst)
    except Exception as e:
        log('err 1136 Except: %r' % e)
        pass
        log('BackupDataBase Failed!')  # Put in LOG
    
    path = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
    files =  glob.glob(os.path.join(path, '*.db'))
    defaultfile = os.path.join(path, RECORDS_DB)
    files1 = sorted(files, reverse=True)
    index = 0   
    try:
        BackupCount = int(definition.ADDONgetSetting('BackupCount'))  
    except Exception as e:
        log('error 1148 Except: %r' % e)
        pass
        BackupCount = 25
    for infile in files1:
        ###log('index= %r, Filename start= %r' % (index,infile))
        infileBasic = os.path.basename(infile)
        databases = [ALARMS_DB, CATEGORIES_DB, FILES_DB, RECORDS_DB]
        if not infileBasic in databases : ### alarms, categories, files.db and active recordings_adb.db skipped
            if index < BackupCount:
                try:
                    index += 1
                except Exception as e:
                    log('err 1159 Except: %r' % e)
                    pass
                    utils.notificationforced('[COLOR red]Restoring %s cleanup FAILED![/COLOR]' % RECORDS_DB)
            else:
                try:
                    if not infile == defaultfile: 
                        index += 1
                        deleteFile(infile)
                except Exception as e:
                    log('err 1168 Except: %r' % e)
                    pass
                    utils.notificationforced('[COLOR red]Restoring %s cleanup FAILED![/COLOR]' % RECORDS_DB)

def deleteDataBase():
    try:
        utils.notificationforced('[COLOR green]Delete Database[/COLOR]',time=100000)
        backupDataBase()
        delAllPlannedPrograms()
        dbPath = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
        if not os.path.exists(dbPath):
            os.mkdir(dbPath)
        backupDst = os.path.join(dbPath, RECORDS_DB)
        deleteFile(backupDst)
        utils.notificationforced('[COLOR green]Delete Database Finished![/COLOR]')
    except Exception as e:
        log('err 1184 Except: %r' % e)
        pass
        log('Error in deleteDataBase: ' + repr(e))
        utils.notificationforced('[COLOR red]Delete Database FAILED![/COLOR]')

def restoreBackupDataBase(backupSrc):
    try:
        utils.notificationforced('[COLOR green]Restoring Database[/COLOR]',time=100000)
        backupDataBase()
        delAllPlannedPrograms()
        dbPath = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
        if not os.path.exists(dbPath):
            os.mkdir(dbPath)
        backupDst = os.path.join(dbPath, RECORDS_DB)
        
        deleteFile(backupDst)
        shutil.copyfile(backupSrc, backupDst)
        reschedule()
        utils.notificationforced('[COLOR green]Restoring Database Finished![/COLOR]')
    except Exception as e:
        log('err 1204 Except: %r' % e)
        pass
        utils.notificationforced('[COLOR red]Restoring Database FAILED![/COLOR]')
        log('restoreBackupDataBase recordings.py backupDataBase Failed/ERROR: %r' % e)

def restoreRecursiveRecordings(url):
    try:
        utils.notificationforced('[COLOR green]Restoring Recursive Records[/COLOR]',time=100000)
        log('restoreRecursiveRecordings Restoring Recursive Records url= ' + repr(url))
        restorecount = RecursiveRecordings(url)
        utils.notificationforced('[COLOR green]Restoring Recursive Records Finished![/COLOR] %s records restored' % repr(restorecount))
    except Exception as e:
        log('err 1216 Except: %r' % e)
        pass
        log('restoreRecursiveRecordings error in Restoring Recursive Records: ' + repr(e))
        utils.notificationforced('[COLOR red]Restoring Recursive Records FAILED![/COLOR] ' + repr(restorecount) + ' records restored: ' + repr(e))

def RecursiveRecordings(dbPath):
    RECURSIVEMARKER = 'Recursive:'
    restorecount = 0
    recur = getDatabaseConnection(dbPath)
    conn = getConnection()
    d = conn.cursor()
    c = recur.cursor()
    c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE '%Recursive:%' COLLATE NOCASE")  # Find all recursive recordings
    recordingsE = c.fetchall()
    # Put recursive recordings changed last - first
    reC = sorted(recordingsE, key=itemgetter(2), reverse=True)
    
    for i in range(0, len(reC)):
        log('RecursiveRecordings Recursive Records: ' + repr(i) + '= ' + repr(reC[i][1].replace(RECURSIVEMARKER,'')))
        d.execute("SELECT DISTINCT cat, name FROM recordings_adc WHERE cat=? and name=? COLLATE NOCASE", [reC[i][0],reC[i][1]])
        recExists = d.fetchall()
        if len(recExists) < 1:
            ### Log which records that restore to find out why they don't stay on reschedule
            
            d.execute("INSERT OR REPLACE INTO recordings_adc(cat, name, start, end, alarmname, description, playchannel) VALUES(?, ?, ?, ?, ?, ?, ?)", reC[i]) ## insert recursive
            restorecount += 1
            log('RecursiveRecordings Add Recursive Record: ' + repr(i) + '= ' + repr(reC[i][1].replace(RECURSIVEMARKER,'')))
    recur.commit()
    conn.commit()
    c.close()
    d.close()
    return restorecount
"""
def setEPGChannel(cat,channel):  ### Code Copy... 2017-09-04
    try:
        log('setEPGChannel(cat)')
        conn = recordings.getConnection()
        c = conn.cursor()
        c.execute("SELECT * FROM channels WHERE id=?", [cat])
        favorites = c.fetchall()
        result = []

        for index in range(0, len(favorites)):
            ch = []
            for i in range(0, len(favorites[index])):
                if favorites[index][i] == None:
                    ch.append('')
                else:
                    ch.append(favorites[index][i])
            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [ch[0], ch[1], ch[2], ch[3], ch[4], ch[5], ch[6], ch[7], ch[8], channel,ch[10],ch[11],ch[12]])
        if result == []:
            log('EPG not found for cat= %r' % cat)

        conn.commit()
        c.close() 
    except Exception as  e:
        log('err 1272 Except: %r' % e)
        pass
        utils.notification('Error in setEPGChannel(cat) '+ cat + ' \n' + repr(e))
"""    
 
def RestoreOldFavorites(dbPath):
    restorecount = 0
    recur = getDatabaseConnection(dbPath)
    conn = getConnection()
    d = conn.cursor()
    c = recur.cursor()
    c.execute("SELECT * FROM channels WHERE favorite!=?",['False'])  # Find all favorite channels
    favorites = c.fetchall()
    errorcount = 0
    for index in range(0, len(favorites)):
        ch = []
       
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None or favorites[index][i] == '':
                """
                if i == 7:
                    ch.append('True')
                elif i == 8:
                    ch.append(0)
                elif i != 7 and i != 8:
                """
                ch.append('')
            else:
                ch.append(favorites[index][i])
        ###d.execute("SELECT DISTINCT id, source FROM channels WHERE id=? and source=? COLLATE NOCASE", [ch[0],ch[4]])
        ###recExists = d.fetchall()
        ###if len(recExists) < 1:
        log( 'len(favorites[index])= %r' % len(favorites[index]))
        if len(favorites[index]) == 13:
            d.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [ch[0],ch[1],ch[2],ch[3],ch[4],ch[5],ch[6],ch[7],ch[8],ch[9],ch[10],ch[11],ch[12]])
            restorecount += 1
        else:
            if errorcount < 10:
                xbmcgui.Dialog().ok(ADDONname, 'Not 13 items in channel definition!\n' + repr(ch)+'Channel not updated')
                log( 'Not 13 items in channel definition!\n'+ repr(ch)+'\nChannel not updated')
            errorcount += 1
    recur.commit()
    conn.commit()
    c.close()
    d.close()
    return restorecount

def RestoreOldRecursiveChannels(dbPath):
    restorecount = 0
    recur = getDatabaseConnection(dbPath)
    conn = getConnection()
    d = conn.cursor()
    c = recur.cursor()
    c.execute("SELECT * FROM channelsRecursive")  # Find all Recursive channels
    favorites = c.fetchall()
    errorcount = 0
    for index in range(0, len(favorites)):
        ch = []
       
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None or favorites[index][i] == '':
                if i == 7:
                    ch.append('False')
                elif i == 8:
                    ch.append(0)
                elif i != 7 and i != 8:
                    ch.append('')
            else:
                ch.append(favorites[index][i])
        ###d.execute("SELECT DISTINCT id, source FROM channels WHERE id=? and source=? COLLATE NOCASE", [ch[0],ch[4]])
        ###recExists = d.fetchall()
        ###if len(recExists) < 1:
        log( 'len(favorites[index])= %r' % len(favorites[index]))
        if len(favorites[index]) == 13:
            d.execute("INSERT OR REPLACE INTO channelsRecursive(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [ch[0],ch[1],ch[2],ch[3],ch[4],ch[5],ch[6],ch[7],ch[8],ch[9],ch[10],ch[11],ch[12]])
            restorecount += 1
        else:
            if errorcount < 10:
                xbmcgui.Dialog().ok(ADDONname, 'Not 13 items in channel definition!\n\n'+ repr(ch)+'Channel not updated')
                log( 'Not 13 items in channel definition!\n'+ repr(ch)+'\nChannel not updated')
            errorcount += 1
    recur.commit()
    conn.commit()
    c.close()
    d.close()
    return restorecount
    
def RestoreOldChannels(dbPath):
    restorecount = 0
    recur = getDatabaseConnection(dbPath)
    conn = getConnection()
    d = conn.cursor()
    c = recur.cursor()
    c.execute("SELECT * FROM channels")  # Find all channels
    favorites = c.fetchall()
    errorcount = 0
    for index in range(0, len(favorites)):
        ch = []
       
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None or favorites[index][i] == '':
                if i == 7:
                    ch.append('False')
                elif i == 8:
                    ch.append(0)
                elif i != 7 and i != 8:
                    ch.append('')
            else:
                ch.append(favorites[index][i])
        ###d.execute("SELECT DISTINCT id, source FROM channels WHERE id=? and source=? COLLATE NOCASE", [ch[0],ch[4]])
        ###recExists = d.fetchall()
        ###if len(recExists) < 1:
        log( 'len(favorites[index])= %r' % len(favorites[index]))
        if len(favorites[index]) == 13:
            d.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [ch[0],ch[1],ch[2],ch[3],ch[4],ch[5],ch[6],ch[7],ch[8],ch[9],ch[10],ch[11],ch[12]])
            restorecount += 1
        else:
            if errorcount < 10:
                xbmcgui.Dialog().ok(ADDONname, 'Not 13 items in channel definition!\n\n'+ repr(ch)+'Channel not updated')
                log( 'Not 13 items in channel definition!\n'+ repr(ch)+'\nChannel not updated')
            errorcount += 1
    recur.commit()
    conn.commit()
    c.close()
    d.close()
    return restorecount

def RestoreOldEPG(dbPath):
    restorecount = 0
    recur = getDatabaseConnection(dbPath)
    conn = getConnection()
    d = conn.cursor()
    c = recur.cursor()
    c.execute("SELECT * FROM programs")  # Find all old programs
    favorites = c.fetchall()
    for index in range(0, len(favorites)):
        ch = []
        ###for i in range(0, len(favorites[index])):
        for i in range(0, 15):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        
        d.execute("SELECT DISTINCT channel, start_date, end_date FROM programs WHERE channel=? and start_date=? and end_date=? COLLATE NOCASE", [ch[0],ch[3],ch[4]])
        recExists = d.fetchall()
        if len(recExists) < 1:
            
            d.execute("INSERT OR REPLACE INTO programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source, updates_id) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [ch[0], ch[1], ch[2], ch[3], ch[4], ch[5], ch[6], ch[7], ch[8], ch[9],ch[10],ch[11],ch[12],ch[13],ch[14]])
            restorecount += 1
    recur.commit()
    conn.commit()
    c.close()
    d.close()
    return restorecount

def epg_channels():   ###Get all unique epg_channels ###for favorites
    try:
        recur = getDatabaseConnection(os.path.join(datapath, RECORDS_DB))
        c = recur.cursor()
        c.execute("SELECT DISTINCT epg_channel FROM channels where not favorite = False COLLATE NOCASE")
        ###c.execute("SELECT DISTINCT epg_channel FROM channels COLLATE NOCASE")  ### 2024-06-03
        recordings = c.fetchall()
        c.close()
        epg_channels = []
        for chan in recordings:
            if chan[0] != '' :
                log('error epg_channels chan[0]= %r' % chan[0])
                epg_channels.append(chan[0])
        log('error epg_channels= %r' % epg_channels)
        return epg_channels
    except Exception as e:
        log('error 1658 Except: %r' % e)
        pass
        return []

def getCount(variation):   ###Get count all unique epg_channels ###for favorites favorite
    try:
        definition.log('recordings getCount variation=%r' % variation)
        recur = getDatabaseConnection(os.path.join(datapath, RECORDS_DB))
        
        c = recur.cursor()
        if variation == 'all' :
            c.execute("SELECT DISTINCT id FROM channels")    # Find all channels
        elif variation == 'favorites' :
            c.execute("SELECT DISTINCT id FROM channels WHERE favorite=?",['True'])  # Find all favorite channels
        elif variation == 'catchup' :
            c.execute("SELECT DISTINCT id FROM channels WHERE catchup!=?",[0])  # Find all favorite channels
        definition.log('recordings4 getCount variation=%r' % variation)
        ###c.execute("SELECT DISTINCT epg_channel FROM channels COLLATE NOCASE")  ### 2024-06-03
        recordings = c.fetchall()
        c.close()
        definition.log('recordings getCount variation=%r, len(recordings)= %r' % (variation,len(recordings)))
        return str(len(recordings))
    except Exception as e:
        definition.log('recordings getCount Exception: %r' % e)
        pass
        return '0'

def RecursiveChannels():
    try:
        recur = getDatabaseConnection(os.path.join(datapath, RECORDS_DB))
        c = recur.cursor()
        recrecordings = c.fetchall()
        ###CREATE TABLE channelsRecursive(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, favorite BOLEAN, catchup BOLEAN, epg_channel TEXT, description TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (id, title, source))
        c.execute("SELECT DISTINCT id FROM channelsRecursive")
        recordings = c.fetchall()
        ###recur.commit()
        c.close()
        recursiveChannels = []
        for chan in recordings:
            recursiveChannels.append(chan[0])
        log('err recursiveChannels= %r' % recursiveChannels)
        return recursiveChannels
    except Exception as e:
        log('err 1444 Except: %r' % e)
        pass
        log('RecursiveChannels error: ' + repr(e))
        utils.notificationforced('[COLOR red]RecursiveChannels FAILED![/COLOR]: ' + repr(e))
        return []

def RecursiveRecordingsCount(dbPath):
    try:
        RECURSIVEMARKER = 'Recursive:'
        recur = getDatabaseConnection(dbPath)
        c = recur.cursor()
        ###c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE '%Recursive:%' COLLATE NOCASE")  # Find all recursive recordings
        c.execute("SELECT DISTINCT cat FROM recordings_adc WHERE name LIKE ? COLLATE NOCASE",['%' + RECURSIVEMARKER + '%'])# Find all recursive recordings
        recrecordings = c.fetchall()
        c.execute("SELECT DISTINCT cat FROM recordings_adc")
        recordings = c.fetchall()
        recur.commit()
        c.close()
        plrecordings = len(recordings) - len(recrecordings)
        return ' (P' + str(plrecordings) +'/R' + str(len(recrecordings)) + ')' + utils.isVPN()
    except Exception as e:
        log('err 1465 Except: %r' % e)
        pass
        log('RecursiveRecordingsCount error in RecursiveRecordingsCount: ' + repr(e))
        utils.notificationforced('[COLOR red]RecursiveRecordingsCount FAILED![/COLOR]: ' + repr(e))
        return '-'

def stopAllRecordings():
    recordings = getRecordings()
    
    for index in range(0, len(recordings)): 
        cat       = recordings[index][0]
        name      = recordings[index][1]
        startDate = recordings[index][2]
        endDate   = recordings[index][3]
        try:
            log('err delRecordingPlanned(cat, startDate, endDate, name)' % (cat, startDate, endDate, name))
            delRecordingPlanned(cat, startDate, endDate, name)
        except Exception as e:
            log('err 1483 Except: %r' % e)
            pass
            log('stopAllRecordings delRecordingPlanned FAILED(index= %r, cat= %r, startDate= %r, endDate= %r, name= %r)' %(index, cat, startDate, endDate, name))  # Put in LOG

def deleteFile(file):
    tries    = 0
    maxTries = 10
    while os.path.exists(file) and tries < maxTries:
        try:
            os.remove(file)
            break
        except Exception as e:
            log('err 1495 Except: %r' % e)
            sleep(501)
            tries = tries + 1

def FindPlatformMoved():
    # Find the actual platform
    Platform = ''
    try:
        kodilog = xbmcvfs.translatePath(os.path.join('special://logpath' , 'kodi.log'))
        
        try: logfile = open(kodilog,'r')
        except Exception as e:
            log('err 1507 Except: %r' % e)
            pass
            kodilog = xbmcvfs.translatePath(os.path.join('special://logpath' , 'xbmc.log'))
            
            try: logfile = open(kodilog,'r')
            except Exception as e:
                log('err 1513 Except: %r' % e)
                pass
                kodilog = xbmcvfs.translatePath(os.path.join('special://logpath' , 'tvmc.log'))
                
                logfile = open(kodilog,'r')
        
        line0 = logfile.readline()
        
        line1 = logfile.readline()
        
        line2 = logfile.readline()
        
        line3 = logfile.readline()
        
        line4 = logfile.readline()
        
        line5 = logfile.readline()
        
        line6 = logfile.readline()
        
        line7 = logfile.readline()
        
        Platform = line2.split('Platform:')[1].strip()
        
        definition.ADDONresetSetting('platform',Platform)
        RunningOn = line5.split('Running on ')[1].split(' ')[0].strip()
        
        definition.ADDONresetSetting('runningon',RunningOn)
        log('FindPlatformMoved RunningOn: %s' % repr(definition.ADDONgetSetting('runningon')))   # Put in LOG
        
        log('FindPlatformMoved ' + os.environ['OS'])  # Put in LOG
    except Exception as e: 
        log('err 1545 Except: %r' % e)
        pass
        log('FindPlatformMoved recordings.py FindPlatform FAILED/Error')   # Put in LOG
    finally:
        logfile.close()
    return Platform

def getConnection():    
    dbPath = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
    if not os.path.exists(dbPath):
        os.mkdir(dbPath)

    conn   = sqlite3.connect(os.path.join(dbPath, RECORDS_DB), timeout = 20, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    ###conn.execute('PRAGMA case_sensitive_like = true;')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    createTable(conn)
    return conn

def getEPGConnection():    
    dbPath = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
    if not os.path.exists(dbPath):
        os.mkdir(dbPath)
    conn   = sqlite3.connect(os.path.join(dbPath, EPG_DB), timeout = 20, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    createTable(conn)
    return conn

def createEPGchannelsTable(conn):
    c = conn.cursor()
    try:
        c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, favorite BOLEAN, catchup BOLEAN, epg_channel TEXT, description TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (id, title, source))")  ### 2017-09-17
        c.execute("CREATE TABLE IF NOT EXISTS channelsRecursive(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, favorite BOLEAN, catchup BOLEAN, epg_channel TEXT, description TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (id, title, source))")
        conn.commit()
    except Exception as e:
        log('err 1583 Except: %r' % e)
        pass
        log('createEPGchannelsTable ERROR: %r' % e)
    c.close()

def createEPGNotificationTable(conn):
    c = conn.cursor()
    try:
        c.execute("CREATE TABLE IF NOT EXISTS CREATE TABLE notifications(channel TEXT, program_title TEXT, source TEXT, start_date INTEGER, type TEXT)")
        conn.commit()
    except Exception as e:
        log('err 1594 Except: %r' % e)
        pass
        log('createEPGNotificationTable ERROR: %r' % e)
    c.close()

def createEPGProgramsTable(conn):
    c = conn.cursor()
    ###c.execute("CREATE TABLE IF NOT EXISTS programs(channel TEXT, title TEXT, sub_title TEXT, start_date TIMESTAMP, end_date TIMESTAMP, description TEXT, categories TEXT, image_large TEXT, image_small TEXT, season TEXT, episode TEXT, is_movie TEXT, language TEXT, source TEXT, updates_id INTEGER, UNIQUE (channel, start_date, end_date))")
    try:   ### 2020-03-30 channel TEXT <<COLLATE NOCASE>>,
        c.execute("CREATE TABLE IF NOT EXISTS programs(channel TEXT COLLATE NOCASE, title TEXT, sub_title TEXT, start_date INTEGER, end_date INTEGER, description TEXT, categories TEXT, image_large TEXT, image_small TEXT, season TEXT, episode TEXT, is_movie TEXT, language TEXT, source TEXT, updates_id INTEGER, UNIQUE (channel, start_date, end_date), PRIMARY KEY (channel, start_date, end_date))")
        conn.commit()
    except Exception as e:
        log('err 1606 Except: %r' % e)
        pass
        log('createEPGProgramsTable ERROR: %r' % e)
    c.close()

def getDatabaseConnection(dbPath):    
    conn   = sqlite3.connect(dbPath, timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    ###conn.execute('PRAGMA case_sensitive_like = true;')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    createTable(conn)
    return conn

def getIconConnection():    
    dbPath = os.path.join(xbmcvfs.translatePath(definition.ADDONgetAddonInfo('path')),'resources')
    #xbmc.log('recordings.py: getIconConnection dbPath= %s' % repr(dbPath))
    if not os.path.exists(dbPath):
        os.mkdir(dbPath)
    conn   = sqlite3.connect(os.path.join(dbPath, CHANNEL_DB), timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    createIconTable(conn)
    return conn

""" WOZBOX TVGUIDE 2.0
CREATE TABLE channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, lineup TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)

CREATE TABLE notifications(channel TEXT, program_title TEXT, source TEXT, start_date TIMESTAMP, type TEXT, FOREIGN KEY(channel, source) REFERENCES channels(id, source) ON DELETE CASCADE)

CREATE TABLE programs(channel TEXT, title TEXT, sub_title TEXT, start_date INTEGER, end_date INTEGER, description TEXT, categories TEXT, image_large TEXT, image_small TEXT, season TEXT, episode TEXT, is_movie TEXT, language TEXT, source TEXT, updates_id INTEGER, UNIQUE (channel, start_date, end_date), FOREIGN KEY(channel, source) REFERENCES channels(id, source) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED, FOREIGN KEY(updates_id) REFERENCES updates(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)
"""
def createWozboxTVguidechannelsTable(conn):
    c = conn.cursor()
    ###c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, lineup TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
    c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, lineup TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, source))")
    conn.commit()
    c.close()

def createWozboxTVguideNotificationTable(conn):
    c = conn.cursor()
    ###c.execute("CREATE TABLE IF NOT EXISTS CREATE TABLE notifications(channel TEXT, program_title TEXT, source TEXT, start_date INTEGER, type TEXT, FOREIGN KEY(channel, source) REFERENCES channels(id, source) ON DELETE CASCADE)") ### 2017-08-14
    c.execute("CREATE TABLE IF NOT EXISTS CREATE TABLE notifications(channel TEXT, program_title TEXT, source TEXT, start_date INTEGER, type TEXT)")
    conn.commit()
    c.close()

def createWozboxTVguideProgramsTable(conn):
    c = conn.cursor()
    ###c.execute("CREATE TABLE IF NOT EXISTS programs(channel TEXT, title TEXT, sub_title TEXT, start_date TIMESTAMP, end_date TIMESTAMP, description TEXT, categories TEXT, image_large TEXT, image_small TEXT, season TEXT, episode TEXT, is_movie TEXT, language TEXT, source TEXT, updates_id INTEGER, UNIQUE (channel, start_date, end_date), FOREIGN KEY(channel, source) REFERENCES channels(id, source) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED, FOREIGN KEY(updates_id) REFERENCES updates(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
    c.execute("CREATE TABLE IF NOT EXISTS programs(channel TEXT, title TEXT, sub_title TEXT, start_date INTEGER, end_date INTEGER, description TEXT, categories TEXT, image_large TEXT, image_small TEXT, season TEXT, episode TEXT, is_movie TEXT, language TEXT, source TEXT, updates_id INTEGER, UNIQUE (channel, start_date, end_date), PRIMARY KEY (channel, start_date, end_date))")
    conn.commit()
    c.close()

def createTableORG(conn):
    c = conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS recordings_adc (cat TEXT, name TEXT, start TEXT, end TEXT, alarmname TEXT, description TEXT, playchannel TEXT, PRIMARY KEY (cat,name,start,end))")
    conn.commit()
    c.close()

def createTable(conn):   ###WozboxTVguidechannels
    try:
        log('1853 error conn.commit()')
        conn.commit()
        c = conn.cursor()
        log('1856 error conn= %r' % conn)
        ###log('1857 error c.execute(CREATE TABLE IF NOT EXISTS channels(id %r, title %r, logo %r, stream_url %r, source %r, visible %r, weight %r, favorite %r, catchup %r, epg_channel%r, description %r, updated %r, created %r)' )
        c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, favorite BOLEAN, catchup BOLEAN, epg_channel TEXT, description TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (id, title, source))")
        log('1859 error c.execute(CREATE TABLE IF NOT EXISTS channelsRecursive)')
        c.execute("CREATE TABLE IF NOT EXISTS channelsRecursive(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, favorite BOLEAN, catchup BOLEAN, epg_channel TEXT, description TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (id, title, source))")
        log('1861 error c.execute(CREATE TABLE IF NOT EXISTS recordings_adc)')
        c.execute("CREATE TABLE IF NOT EXISTS recordings_adc (cat TEXT, name TEXT, start TEXT, end TEXT, alarmname TEXT, description TEXT, playchannel TEXT, PRIMARY KEY (cat,name,start,end))")
        log('1863 error c.execute(CREATE TABLE IF NOT EXISTS tvseries)')
        c.execute("CREATE TABLE IF NOT EXISTS tvseries (name TEXT, episodes TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (name))")
        log('1867 error c.execute(CREATE TABLE IF NOT EXISTS categories)')
        c.execute("CREATE TABLE IF NOT EXISTS categories(categori TEXT, categoritype TEXT, source TEXT, visible BOOLEAN, include BOLEAN, updated INTEGER, created INTEGER, PRIMARY KEY (categori))")  ### 2023-05-08
        log('1867 error conn.commit()')
        conn.commit()
        c.close()
    except Exception as e:
        pass
        log( '1873 createTable(conn) failed! \nERROR= %r' % (e))

def createCategoriesTable(conn):  
    try:
        log('1853 error conn.commit()')
        conn.commit()
        c = conn.cursor()
        log('1879 error c.execute(CREATE TABLE IF NOT EXISTS categories(categori TEXT, categoritype TEXT, source TEXT, visible BOOLEAN, include BOLEAN, updated INTEGER, created INTEGER, PRIMARY KEY (categori)))')
        c.execute("CREATE TABLE IF NOT EXISTS categories(categori TEXT, categoritype TEXT, source TEXT, visible BOOLEAN, include BOLEAN, updated INTEGER, created INTEGER, updatedHuman TEXT, PRIMARY KEY (categori))")  ### 2023-05-08
        log('1881 error conn.commit()')
        conn.commit()
        c.close()
    except Exception as e:
        pass
        log( '1886 createTable(conn) failed! \nERROR= %r' % (e))
        
def getCategoriesConnection():     
    log('1902 error getCategoriesConnection START')
    dbPath = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
    if not os.path.exists(dbPath):
        os.mkdir(dbPath)
    conn   = sqlite3.connect(os.path.join(dbPath, CATEGORIES_DB), timeout = 20, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    ###conn.execute('PRAGMA case_sensitive_like = true;')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    createCategoriesTable(conn)
    return conn    
    
def addCategori(categori, categoritype, source):
    log('1915 error addCategori(categori= %r, categoritype= %r, source= %r)' % (categori, categoritype, source))
    ### categories(categori 0, categoritype 1, source 2, visible 3, include 4, updated 5, created 6,  updatedHuman 7
    now = datetime.now()
    nowTS = int(datetime.timestamp(now))
    conn = getCategoriesConnection()
    c = conn.cursor()
    log('1921 error getCategoriesConnection got')
    categori = categori.strip()
    if categori != '' and categoritype != 'series':
        try:
            c.execute("SELECT * FROM categories WHERE categori=? ", [categori]) 
            log('1926 error addCategori(categori= %r' % categori)
            channels = c.fetchall()
            log('1928 error addCategori(len(channels)= %r' % len(channels))
            if len(channels) > 0:
                for chan in channels:
                    c.execute("INSERT OR REPLACE INTO categories(categori, categoritype, source, visible, include, updated, created,  updatedHuman) VALUES(?, ?, ?, ?, ?, ?, ?, ?)", [categori, categoritype, source, chan[3], chan[4], nowTS, chan[6],  humantime(nowTS)])
            else:
                c.execute("INSERT OR REPLACE INTO categories(categori, categoritype, source, visible, include, updated, created,  updatedHuman) VALUES(?, ?, ?, ?, ?, ?, ?, ?)", [categori, categoritype, source, True, False, nowTS, nowTS, humantime(nowTS)])
            log('error addCategori(conn.commit())')
            conn.commit()
            c.close()
            return True
        except Exception as e:
            log('1938 addCategori ERROR %r' % e)
            pass
            return False

def addCategories(categories,source):
    log('1947 errorZZ addCategories(categories= %r,source= %r)' % (categories,source))
    conn = getCategoriesConnection()
    c = conn.cursor()
    log('1950 errorZZ addCategories(categories= %r,source= %r)' % (categories,source))
    ### categories(categori 0, categoritype 1, source 2, visible 3, include 4, updated 5, created 6,  updatedHuman 7
    now = datetime.now()
    nowTS = int(datetime.timestamp(now))
    log('1968 error addCategories(categories= %r,source= %r)' % (categories,source))
    for cat in categories:
        log('1956 errorZZ addCategories(cat= %r,source= %r)' % (cat,source))
        ###categoriandtype = categories[cat].split('¤')
        categoriandtype = cat.split('¤')
        log('1958 errorZZ addCategories(categoriandtype= %r,source= %r)' % (categoriandtype,source))
        categori = categoriandtype[0].strip()
        categoritype = categoriandtype[1].strip()
        if categori != '' and categoritype != 'series' and categoritype != 'radio_streams' :   ### 2025-02-15 radio_streams not added
            try:
                c.execute("SELECT * FROM categories WHERE categori=? ", [categori]) 
                log('1975 error addCategories(categori= %r' % categori)
                channels = c.fetchall()
                log('1977 error addCategories(len(channels)= %r' % len(channels))
                if len(channels) > 0:
                    for chan in channels:
                        if source == 'now':
                            sourceX = chan[2]
                        else:
                            sourceX = source
                        c.execute("INSERT OR REPLACE INTO categories(categori, categoritype, source, visible, include, updated, created,  updatedHuman) VALUES(?, ?, ?, ?, ?, ?, ?, ?)", [categori, categoritype, sourceX, chan[3], chan[4], nowTS, chan[6],  humantime(nowTS)])
                else:
                    c.execute("INSERT OR REPLACE INTO categories(categori, categoritype, source, visible, include, updated, created,  updatedHuman) VALUES(?, ?, ?, ?, ?, ?, ?, ?)", [categori, categoritype, source, True, False, nowTS, nowTS, humantime(nowTS)])
            except Exception as e:
                log('1984 addCategoris ERROR %r' % e)
                pass
    log('1973 errorZZ addCategories(categories= %r,source= %r)' % (categories,source))
    conn.commit()
    c.close()
    log('1976 errorZZ addCategories(categories= %r,source= %r)' % (categories,source))          

def getAllNewCats():
    conn = getCategoriesConnection()
    c = conn.cursor()
    c.execute("SELECT categori, categoritype FROM categories  WHERE visible=1 and source='new' ORDER BY categori COLLATE NOCASE, categoritype ASC") 
    log('1989 error getAllNewCats')
    channels = c.fetchall()
    AllCats = []
    for chan in channels:
        AllCats.append(chan[0]+'¤'+chan[1])
    log('1995 error getAllNewCats %r' % AllCats)
    return AllCats

def getNewCategories():
    conn = getCategoriesConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM categories  WHERE visible=1 and source='new' ORDER BY categori COLLATE NOCASE, categoritype ASC") 
    log('2001 error getNewCategories')
    channels = c.fetchall()
    return channels

def getAllCats():
    conn = getCategoriesConnection()
    c = conn.cursor()
    c.execute("SELECT categori, categoritype FROM categories  WHERE visible=1 ORDER BY categori COLLATE NOCASE, categoritype ASC") 
    log('1935 error getAllCats')
    channels = c.fetchall()
    AllCats = []
    for chan in channels:
        AllCats.append(chan[0]+'¤'+chan[1])
    return AllCats

def getAllCategories():
    conn = getCategoriesConnection()
    c = conn.cursor()
    c.execute("SELECT categori, categoritype FROM categories  WHERE visible=1 ORDER BY categori COLLATE NOCASE, categoritype ASC") 
    log('1935 error getAllCategories')
    channels = c.fetchall()
    return channels

def getActiveCats():
    conn = getCategoriesConnection()
    c = conn.cursor()
    c.execute("SELECT categori, categoritype FROM categories WHERE include=1 AND visible=1 ORDER BY categori COLLATE NOCASE, categoritype ASC") 
    log('1943 error getActiveCats')
    channels = c.fetchall()
    AllCats = []
    for chan in channels:
        AllCats.append(chan[0]+'¤'+chan[1])
    return AllCats
   
def getActiveCategories():
    conn = getCategoriesConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM categories WHERE include=1 AND visible=1 ORDER BY categori COLLATE NOCASE, categoritype  ASC") 
    log('1943 error getAllCategories')
    channels = c.fetchall()
    ###channels = sorted(channels)
    ###channels = sorted(channels,key=lambda i:i[1].lower())  ### Sort ignore case coloum 1
    return channels
    
def getInActiveCategories():
    conn = getCategoriesConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM categories WHERE include=0 AND visible=1 ORDER BY categori COLLATE NOCASE, categoritype ASC") 
    log('1943 error getAllCategories')
    channels = c.fetchall()
    ###channels = sorted(channels)
    ###channels = sorted(channels,key=lambda i:i[1].lower())  ### Sort ignore case coloum 1
    return channels
   
def isCategoriAvailable(categori,categoritype):
    conn = getCategoriesConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM categories WHERE categori=? AND categoritype = ? ", [categori,categoritype])
    log('1951 error getAllCategories')
    channels = c.fetchall()
    ###channels = sorted(channels)
    if len(channels) >= 1:
        return True
    else:
        return False
        
def isCategoriActive(categori,categoritype):
    conn = getCategoriesConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM categories WHERE categori=? AND categoritype = ? AND include = 1 ", [categori,categoritype])
    log('1951 error getAllCategories')
    channels = c.fetchall()
    ###channels = sorted(channels)
    if len(channels) >= 1:
        return True
    else:
        return False

def setCategoriesInactive(categori,categoritype):
    log('1986 error setCategoriesInactive(categori= %r,categoritype= %r)' % (categori,categoritype))
    now = datetime.now()
    nowTS = int(datetime.timestamp(now))
    conn = getCategoriesConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM categories WHERE categori=? AND categoritype = ? ", [categori,categoritype])
    log('1951 error getAllCategories')
    channels = c.fetchall()
    source = 'setCategoriesInactive'
    log('1995 error setCategoriesInactive(len(channels)= %r)' % len(channels))
    ###channels = sorted(channels)
    if len(channels) > 0:
        for chan in channels:
            c.execute("INSERT OR REPLACE INTO categories(categori, categoritype, source, visible, include, updated, created,  updatedHuman) VALUES(?, ?, ?, ?, ?, ?, ?, ?)", [categori, categoritype, source, chan[3], False, nowTS, chan[6],  humantime(nowTS)])
        return True
    else:
        return False

def setCategoriesActive(categori,categoritype):
    log('1986 error setCategoriesActive(categori= %r,categoritype= %r)' % (categori,categoritype))
    now = datetime.now()
    nowTS = int(datetime.timestamp(now))
    conn = getCategoriesConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM categories WHERE categori=? AND categoritype = ? ", [categori,categoritype])
    log('1951 error getAllCategories')
    channels = c.fetchall()
    source = 'setCategoriesActive'
    log('1995 error setCategoriesActive(len(channels)= %r)' % len(channels))
    ###channels = sorted(channels)
    if len(channels) > 0:
        for chan in channels:
            c.execute("INSERT OR REPLACE INTO categories(categori, categoritype, source, visible, include, updated, created,  updatedHuman) VALUES(?, ?, ?, ?, ?, ?, ?, ?)", [categori, categoritype, source, chan[3], True, nowTS, chan[6],  humantime(nowTS)])
        return True
    else:
        return False


def createIconTable(conn):
    try:
        c = conn.cursor()
        ##c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT NOT NULL, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (title), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)") ### 2016-05-15
        c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, favorite BOLEAN, catchup BOLEAN, epg_channel TEXT, description TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (id, title, source))")
        conn.commit()
        c.close()
    except Exception as e:
        log('err 1688 Except: %r' % e)
        pass
        log( 'createIconTable(conn) failed! \nERROR= %r' % (e))

def createAlarmTable(conn):
    try:
        log('errYYY createAlarmTable START')
        c = conn.cursor()
        ### setAlarm(nameAlarm, prog, intervalhms,starttimedeltahms,options)
        c.execute("CREATE TABLE IF NOT EXISTS alarms(alarmname TEXT, prog TEXT, parameters TEXT, starttimedeltahms TEXT, updated INTEGER, created INTEGER, updatedHuman TEXT, options TEXT, PRIMARY KEY (alarmname, prog))")
        conn.commit()
        c.close()
    except Exception as e:
        log('err 1761 Except: %r' % e)
        pass
        log( 'createAlarmTable(conn) failed! \nERROR= %r' % (e))
   
def getAlarmsConnection():     
    log('errYYY getAlarmsConnection START')
    dbPath = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
    if not os.path.exists(dbPath):
        os.mkdir(dbPath)
    conn   = sqlite3.connect(os.path.join(dbPath, ALARMS_DB), timeout = 20, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    ###conn.execute('PRAGMA case_sensitive_like = true;')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    createAlarmTable(conn)
    return conn    

def addAlarm(nameAlarm, prog, parameters, starttimedeltahms, options):
    nameAlarm = nameAlarm.replace(',','').replace('.','').replace(' ','').strip()
    log('error addAlarm START nameAlarm= %r' % nameAlarm)
    now = datetime.now()
    ###nowTS = int(datetime.timestamp(now))
    nowTS = datetime.timestamp(now)
    log('error getAlarmsConnection get')
    conn = getAlarmsConnection()
    c = conn.cursor()
    log('errYYY getAlarmsConnection got')
    ###nameAlarm = nameAlarm.strip()
    if nameAlarm != '':
        try:
            c.execute("SELECT * FROM alarms WHERE alarmname=? ", [nameAlarm]) 
            log('err addAlarm(nameAlarm= %r' % nameAlarm)
            channels = c.fetchall()
            log('err addAlarm(len(channels)= %r' % len(channels))
            if len(channels) > 0:
                for chan in channels:
                    c.execute("INSERT OR REPLACE INTO alarms(alarmname, prog, parameters, starttimedeltahms, updated, created, updatedHuman, options) VALUES(?, ?, ?, ?, ?, ?, ?, ?)", [nameAlarm, prog, parameters,starttimedeltahms,nowTS, chan[5], humantimefraction(nowTS), options])
            else:
                c.execute("INSERT OR REPLACE INTO alarms(alarmname, prog, parameters, starttimedeltahms, updated, created, updatedHuman, options) VALUES(?, ?, ?, ?, ?, ?, ?, ?)", [nameAlarm, prog, parameters, starttimedeltahms, nowTS, nowTS, humantimefraction(nowTS), options])  
            log('err addAlarm(conn.commit())')
            conn.commit()
            c.close()
        except Exception as e:
            log('err 1785 Except: %r' % e)
            log('addAlarm ERROR %r' % e)
            pass

def updateAlarm(nameAlarm):
    nameAlarm = nameAlarm.replace(',','').replace('.','').replace(' ','').strip()
    log('error updateAlarm START nameAlarm= %r' % nameAlarm)
    now = datetime.now()
    nowTS = datetime.timestamp(now)
    conn = getAlarmsConnection()
    c = conn.cursor()
    ###nameAlarm = nameAlarm.strip()
    if nameAlarm != '':
        try:
            c.execute("SELECT * FROM alarms WHERE alarmname=? ", [nameAlarm]) 
            log('addAlarm(nameAlarm= %r' % nameAlarm)
            channels = c.fetchall()
            log('errYYY updateAlarm(len(channels)= %r' % len(channels))
            if len(channels) > 0:
                for chan in channels:
                    c.execute("INSERT OR REPLACE INTO alarms(alarmname, prog, parameters, starttimedeltahms, updated, created, updatedHuman, options) VALUES(?, ?, ?, ?, ?, ?, ?, ?)", [nameAlarm, chan[1], chan[2],chan[3],nowTS, chan[5], humantimefraction(nowTS), chan[7]])
            else:
                log('errYYY updateAlarm: update ignored')
            log('errYYY updateAlarm(conn.commit())')
            conn.commit()
            c.close()
        except Exception as e:
            log('err 1830 Except: %r' % e)
            log('updateAlarm ERROR %r' % e)
            pass    

def getFilesConnection():     
    log( 'err getFilesConnection START')
    dbPath = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
    if not os.path.exists(dbPath):
        os.mkdir(dbPath)
    conn   = sqlite3.connect(os.path.join(dbPath, FILES_DB), timeout = 20, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    ###conn.execute('PRAGMA case_sensitive_like = true;')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    createFileTable(conn)
    log( 'err getFilesConnection END')
    return conn
    
def deleteFileBase():
    try:
        utils.notificationforced('[COLOR green]Delete File Database[/COLOR]',time=100000)
        dbPath = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
        if not xbmcvfs.path.exists(dbPath):
            xbmcvfs.mkdir(dbPath)
        backupDst = os.path.join(dbPath, FILES_DB)
        deleteFile(backupDst)
        sleep(1001)
        if os.path.isfile(backupDst) != True:
            utils.notificationforced('[COLOR green]Delete File Database Finished![/COLOR]')
        else:
            utils.notificationforced('[COLOR red]Delete File Database FAILED![/COLOR]')
    except Exception as e:
        log('err 1718 Except: %r' % e)
        pass
        log('Error in deleteFileDataBase: ' + repr(e))
        utils.notificationforced('[COLOR red]Delete File Database FAILED![/COLOR]')
        
def copyFileBase():
    try:
        log('1858 Exception Copy File Database')
        dbPath = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
        if not xbmcvfs.exists(dbPath):
            xbmcvfs.mkdir(dbPath)
        sourf = os.path.join(dbPath, FILES_DB)
        log('err Exception sourf= %r' % sourf)
        if definition.ADDONgetSetting('copyfiledatabasetorecordings') == 'true':
            destf = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_path'), FILES_DB))
            log('err Exception destf= %r' % destf)
            copyOK = xbmcvfs.copy(sourf, destf)
            if not copyOK:
                log('err Exception of FILES_DB failed')

            if xbmcvfs.exists(destf) == True and copyOK :
                log('1881 Exception Copy File Database Finished!')
            elif xbmcvfs.exists(destf) == True :
                log('1835 Exception Copy File Database NOT UPDATED!')
            else:
                log('1837 Exception Copy File Database FAILED!')
        destf = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_path'), str(xbmc.getInfoLabel('System.FriendlyName'))+'-'+ADDONname + '-' + FILES_DB))
        copyOK = xbmcvfs.copy(sourf, destf)
        if not copyOK:
            log('Exception Copy of FILES_DB failed')
    except Exception as e:
        pass
        log('err 1839 copy File Database Exception: %r' % e)
    
def getFileBase():
    try:
        copyfiledatabasefrom = definition.ADDONgetSetting('copyfiledatabasefrom')
        definition.log('getFileBase Started')
        dbPath = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
        if not xbmcvfs.exists(dbPath):
            xbmcvfs.mkdir(dbPath)
        sourf = os.path.join(dbPath, FILES_DB)
        deleteresult = xbmcvfs.delete(sourf)
        definition.log('getFileBase xbmcvfs.delete(sourf) delete result= %r\n sourf= %r' % (deleteresult,sourf))
        if copyfiledatabasefrom == '' :
            destf = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_path'), FILES_DB))
        else:
            destf = xbmcvfs.translatePath(copyfiledatabasefrom)
        
        definition.log('getFileBase destf= %r' % destf)        
        
        copyOK = xbmcvfs.copy(destf, sourf)  ### Source and destination changed
        definition.log('getFileBase xbmcvfs.copy(destf, sourf) copy result= %r\n sourf= %r\n destf= %r' % (deleteresult,sourf,destf))
        if not copyOK:
            definition.log('getFileBase Get FILES_DB failed from %r' % sourf)
            dialog = xbmcgui.Dialog()
            dialog.ok('[B]' + ADDONname + '[/B]','[COLOR red]Get Files DB failed - copy failed![/COLOR]\nDelete= %r\nCopy= %r' % (deleteresult,copyOK))
        if xbmcvfs.exists(destf) == True and copyOK :
            definition.log('getFileBase Get File Database Finished!')
        elif xbmcvfs.exists(destf) == True :
            definition.log('getFileBase Get File Database NOT UPDATED!')
        else:
            definition.log('getFileBase Get File Database FAILED!')
            dialog = xbmcgui.Dialog()
            dialog.ok('[B]' + ADDONname + '[/B]','[COLOR red]Get Files DB failed![/COLOR]\nDelete= %r\nCopy= %r\n Source= %r' % (deleteresult,copyOK,destf))
    except Exception as e:
        pass
        definition.log('getFileBase Get File Database Exception: %r' % e)
        
def setRecordsBase():
    try:
        log('2363 error Set Records Database')
        dbPath = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
        if not xbmcvfs.exists(dbPath):
            xbmcvfs.mkdir(dbPath)
        sourf = os.path.join(dbPath, RECORDS_DB)
        ###utils.makeOldFile(sourf)
        
        ###result = xbmcvfs.delete(sourf)
        ###log('error xbmcvfs.delete(sourf) delete result= %r\n sourf= %r' % (result,sourf))
        log('error 2307 sourf= %r' % sourf)
        destf = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_path'), RECORDS_DB))
        log('error 2309 destf= %r' % destf)
        destf = definition.FileManagerPath(destf)
        log('error 2377 destf= %r' % destf)
        copyOK = xbmcvfs.copy(sourf, destf)  ### Source and destination to Recordings Folder
        log('error 2379 destf= %r' % destf)
        if not copyOK:
            log('error Set RECORDS_DB failed')
            ###utils.getOldFile(sourf)
            dialog = xbmcgui.Dialog()
            dialog.ok('[B]' + ADDONname + '[/B]','[COLOR red]Copy Records DB failed - copy failed![/COLOR]')
        if xbmcvfs.exists(destf) == True and copyOK :
            log('2316 error Get Records Database Finished! \n%r' % destf)
        elif xbmcvfs.exists(destf) == True :
            log('2318 error Copy Records Database NOT UPDATED in Recordings Folder! \n%r' % destf)
        else:
            log('2320 error Copy Records Database FAILED! \n%r' % destf)
            dialog = xbmcgui.Dialog()
            dialog.ok('[B]' + ADDONname + '[/B]','[COLOR red]Copy Records DB to Recordings Folder failed![/COLOR]')
    except Exception as e:
        log('error 2324 Copy Records Database Exception: %r' % e)
        pass
        log('2326 Error in Copy Records DataBase: ' + repr(e))   
    
def getRecordsBase():
    try:
        log('2330 error Get Records Database')
        dbPath = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
        if not xbmcvfs.exists(dbPath):
            xbmcvfs.mkdir(dbPath)
        sourf = os.path.join(dbPath, RECORDS_DB)
        utils.makeOldFile(sourf)
        
        result = xbmcvfs.delete(sourf)
        log('error xbmcvfs.delete(sourf) delete result= %r\n sourf= %r' % (result,sourf))
        log('error 2307 sourf= %r' % sourf)
        destf = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_path'), RECORDS_DB))
        log('error 2309 destf= %r' % destf)
        destf = definition.FileManagerPath(destf)
        log('error 2412 destf= %r' % destf)
        copyOK = xbmcvfs.copy(destf, sourf)  ### Source and destination changed
        if not copyOK:
            log('error Get RECORDS_DB failed')
            utils.getOldFile(sourf)
            dialog = xbmcgui.Dialog()
            dialog.ok('[B]' + ADDONname + '[/B]','[COLOR red]Get Records DB failed - copy failed![/COLOR]')
        if xbmcvfs.exists(destf) == True and copyOK :
            log('2316 error Get Records Database Finished!')
        elif xbmcvfs.exists(destf) == True :
            log('2318 error Get Records Database NOT UPDATED!')
        else:
            log('2320 error Get Records Database FAILED!')
            dialog = xbmcgui.Dialog()
            dialog.ok('[B]' + ADDONname + '[/B]','[COLOR red]Get Records DB failed![/COLOR]')
    except Exception as e:
        log('error 2324 Get Records Database Exception: %r' % e)
        pass
        log('2326 Error in Get Records DataBase: ' + repr(e))   
    
def createFileTable(conn):
    try:
        log( 'err createFileTable START(conn= %r)' % (conn))
        c = conn.cursor()
        c.execute("CREATE TABLE IF NOT EXISTS files(filename TEXT, ext TEXT, path TEXT, video TEXT, description TEXT, size TEXT, archive TEXT, updated INTEGER, created INTEGER, updatedHuman INTEGER, command TEXT, options TEXT, realtitle TEXT, startmark TEXT, duration TEXT, fileduration TEXT, PRIMARY KEY (filename, ext, path, archive))")
        conn.commit()
        c.close()
        log( 'err createFileTable END(conn= %r)' % (conn))
    except Exception as e:
        log('err 1730 Except: %r' % e)
        pass
        log( 'createFileTable(conn) failed! \nERROR= %r' % (e))
        
def realTitle(c, filename, ext, path, archive):
    try:
        path = path.replace('\\','/')   ### 2024-01-01
        log('err realTitle(c, filename= %r, ext= %r, path= %r, archive= %r)' % (filename, ext, path, archive))
        ###c = conn.cursor()
        ###c.execute("CREATE TABLE IF NOT EXISTS files(filename TEXT, ext TEXT, path TEXT, video TEXT, description TEXT, size TEXT, archive TEXT, updated INTEGER, created INTEGER, updatedHuman INTEGER, command TEXT, options TEXT, realtitle TEXT, PRIMARY KEY (filename, ext, path, archive))")
        c.execute("SELECT realtitle FROM files WHERE filename=? and ext=? and (path=? or path=?) and archive=? and video=?" , [filename, ext, path.replace('\\','/'), path.replace('/','\\'), archive, 'True'])
        ###c.execute("SELECT * FROM files WHERE filename=? and ext=? and video=?" , [filename, ext,'True'])
        realtitle = c.fetchall()
        log('err realtitle count= %r' % len(realtitle))
        return realtitle[0][0]
        ###conn.commit()
        ###c.close()
    except Exception as e:
        log('err 1747 Except: %r' % e)
        pass
        log( 'realTitle failed! ERROR= %r' % (e))

def addFileCleanup(c,folderpath,archive,cutoffnowTS):
    try:
        c.execute("SELECT * FROM files WHERE archive=? AND updated>=?" , [archive,cutoffnowTS])
        channels = c.fetchall()
        recordsupdated = len(channels)
        log('recordsupdated: %r' % recordsupdated)
        if recordsupdated > 0 or 1==1:   ### Delete all old(previous)Only delete records if records have been updated
            c.execute("SELECT * FROM files WHERE archive=? AND updated<?" , [archive,cutoffnowTS])
            channels = c.fetchall()
            recordstodelete = len(channels)
            log('records to delete: %r' % recordstodelete)
            c.execute("DELETE FROM files WHERE archive=? AND updated<?" , [archive,cutoffnowTS])
    except Exception as e:
        log('err 1764 Except: %r' % e)
        pass
        log('addFileCleanup ERROR: %r' % e)
        
def addFileCommand(c, filename, ext, path, archive, command, options):
    log('err addFileCommand(c, filename= %r, ext= %r, path= %r, archive= %r, command= %r, options= %r)'% (filename, ext, path, archive, command, options))
    path = path.replace('\\','/')   ### 2024-01-01
    filename = filename.replace('+','xXx')   ### 2019-03-16 + seems to fuck up SQlite
    urldirectorypath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_path')))
    ###if '\\' in urldirectorypath:
    ###    path = path.replace('/','\\')   ### 2024-01-02
    log('addFileCommand(c= %r, filename= %r, ext= %r, path= %r, archive= %r, command= %r, options= %r)' % (c, filename, ext, path, archive, command, options))
    now = datetime.now()
    ###nowTS = int(time.mktime(now.timetuple()))
    nowTS = int(datetime.timestamp(now))
    nowTSold =    nowTS - 31536000    ### 365 * 24 * 60 * 60  now-timedelta(days=365)
    now = parseDate(datetime.now()) 
    filename = filename.strip()
    if filename != '':
        try:
            c.execute("SELECT * FROM files WHERE filename=? AND ext=? AND path=? AND archive=? AND video=?", [filename,ext,path,archive,'True'])
            ###c.execute("SELECT * FROM files WHERE filename=? AND path=? AND archive=? AND video=?", [filename,path,archive,'True']) 
            channels = c.fetchall()
            if len(channels) > 0:
                for chan in channels:
                    c.execute("INSERT OR REPLACE INTO files(filename, ext, path, video, description, size, archive, updated, created, updatedHuman, command, options, realtitle, startmark, duration, fileduration) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [filename, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], nowTS, chan[8], humantime(nowTS), command, options, chan[12], chan[13], chan[14], chan[15]])
            else:
                log('addFileCommand err - DB record not found for %r' % filename)
        except Exception as e:
            log('err 1791 Except: %r' % e)
            log('addFileCommand ERROR %r' % e)
            pass
        
def addFile(c, filename, ext, path, video, description, size, archive, realtitle='', startmark='', duration='', fileduration= ''):
    log('err addFile')
    path = path.replace('\\','/')   ### 2024-01-01
    filename = filename.replace('+','xXx')   ### 2019-03-16 + seems to fuck up SQlite
    log('err addFile(c= %r, filename= %r, ext= %r, path= %r, video= %r, description= %r, size= %r, archive= %r, realtitle= %r, startmark= %r, duration= %r)' % (c, filename, ext, path, video, description, size, archive, realtitle, startmark, duration))
    now = datetime.now()
    ###nowTS = int(time.mktime(now.timetuple()))
    nowTS = int(datetime.timestamp(now))
    nowTSold =    nowTS - 31536000    ### 365 * 24 * 60 * 60  now-timedelta(days=365)
    now = parseDate(datetime.now()) 
    filename = filename.strip()
    if filename != '':
        try:
            c.execute("SELECT * FROM files WHERE filename=? AND ext=? AND path=? AND archive=?", [filename,ext,path,archive]) 
            channels = c.fetchall()
            if len(channels) > 0:
                for chan in channels:
                    log('err addFile filename= %r, ext= %r, duration= %r' % (filename, ext, duration))
                    if duration == '':
                        duration = chan[14]
                    if fileduration == '':
                        fileduration = chan[15]
                    c.execute("INSERT OR REPLACE INTO files(filename, ext, path, video, description,  size, archive, updated, created, updatedHuman, command, options, realtitle, startmark, duration, fileduration) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [filename, ext, path, video, description, size, archive, nowTS, chan[8], humantime(nowTS), chan[10], chan[11], realtitle, startmark, duration, fileduration])
            else:
                log('err new addFile filename= %r, ext= %r, duration= %r' % (filename, ext, duration))
                c.execute("INSERT OR REPLACE INTO files(filename, ext, path, video, description, size, archive, updated, created, updatedHuman, command, options, realtitle, startmark, duration, fileduration) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [filename, ext, path, video, description, size, archive, nowTS, nowTS, humantime(nowTS),'','',realtitle, startmark, duration, fileduration])    
        except Exception as e:
            log('err 1813 Except: %r' % e)
            log('addFile ERROR %r' % e)
            pass

def addTVSeries(c, name, episodes):
    ###name = name.replace('+','xXx')   ### 2019-03-16 + seems to fuck up SQlite
    log('addTVSeries(c= %r, name= %r, episodes= %r)' % (c, name, episodes))
    now = datetime.now()
    ###nowTS = int(time.mktime(now.timetuple()))
    nowTS = int(datetime.timestamp(now))
    nowTSold =    nowTS - 31536000    ### 365 * 24 * 60 * 60  now-timedelta(days=365)
    now = parseDate(datetime.now()) 
    name = name.strip()
    if name != '':
        try:
            c.execute("SELECT * FROM tvseries WHERE name=?", [name]) 
            channels = c.fetchall()
            if len(channels) > 0:
                for chan in channels:
                    c.execute("INSERT OR REPLACE INTO tvseries(name, episodes, updated, created) VALUES(?, ?, ?, ?)", [name, episodes, nowTS, chan[3]])
            else:
                c.execute("INSERT OR REPLACE INTO tvseries(name, episodes, updated, created) VALUES(?, ?, ?, ?)", [name, episodes, nowTS, nowTS]) 
        except Exception as e:
            log('err 1835 Except: %r' % e)
            log('addTVSeries ERROR %r' % e)
            pass
       
def addChannel(name,url,iconimage,cat,origin,visible=1,weight=0,epg_channel='',description=''):
    try:
        name = utils.untilD8(name)
        weight = utils.SeriesEpisodeVOD(name)[0]  ###2021-01-17
        epg_channel = epg_channel.lower()
        log('0err addChannel name= %r,url= %r,iconimage= %r,cat= %r,origin= %r, weight= %r, epg_channel= %r' % (name,url,iconimage,cat,origin,weight,epg_channel))
        ### add to channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER)
        now = datetime.now()
        log('01 addChannel name= %r' % name)
        ###nowTS = int(time.mktime(now.timetuple()))
        nowTS = int(datetime.timestamp(now))
        log('02 addChannel name= %r' % name)
        nowTSold =    nowTS - 31536000    ### 365 * 24 * 60 * 60  
        log('03 addChannel name= %r' % name)
        now-timedelta(days=365)
        log('04 addChannel name= %r' % name)
        now = parseDate(datetime.now())  ### 2017-09-30
        log('05 addChannel name= %r' % name)
        cat = cat.strip()
        log('06 addChannel name= %r' % name)
        name = name.strip()
        log('1 addChannel name= %r' % name)
        if name != '':
            log('2 addChannel name= %r' % name)
            try:
                log('3 addChannel name= %r' % name)
                conn = getConnection()
                c = conn.cursor()
                c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])  ### 2017-08-26
                ###c.execute("SELECT * FROM channels WHERE id=?", [cat])
                channels = c.fetchall()
                log('4 addChannel name= %r' % name)
                
                if len(channels) > 0:
                    for chan in channels:
                        log('6 addChannel chan[0]= %r, chan[1]= %r, len(chan)= %r, weight= %r' % (chan[0], chan[1],len(chan),weight))
                        ChannelEpg = getChannelEpgid(c,cat)   ### 2020-04-13
                        if ChannelEpg == '':
                            epg_channel = chan[9].lower()
                        else:
                            epg_channel = ChannelEpg.lower()
                        if description in chan[10]:   ### 2018-07-20
                            log('7 addChannel c.execute("INSERT OR REPLACE INTO channels')
                            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, name, iconimage, url, origin, chan[5], weight, chan[7], chan[8], epg_channel, chan[10], nowTS, chan[12]]) ### 2019-02-11 test
                            log('8 addChannel c.execute("INSERT OR REPLACE INTO channels')
                        else:
                            log('9 addChannel c.execute("INSERT OR REPLACE INTO channels')
                            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, name, iconimage, url, origin, chan[5], weight, chan[7], chan[8], epg_channel, chan[10]+'\n' + description, nowTS, chan[12]])
                            log('10 addChannel c.execute("INSERT OR REPLACE INTO channels')
                else:
                    log('11 addChannel c.execute("INSERT OR REPLACE INTO channels')
                    c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, name, iconimage, url, origin, visible, weight, 'False', 0,epg_channel, description,nowTS,nowTSold]) 
                    log('12 addChannel c.execute("INSERT OR REPLACE INTO channels')                    
                ###c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite) VALUES(?, ?, ?, ?, ?, ?, ?)", [cat, name, iconimage, url, origin, 'True', '0'])
            
                log('13 addChannel conn.commit()')
                conn.commit()
            except Exception as e:
                log('err 1896 Except: %r' % e)
                pass
                log('14 addChannel 1 ERROR: %r' % e)
            c.close()
    except Exception as e:
        log('err 1901 Except: %r' % e)
        pass
        log('15 addChannel ERROR: %r' % e)

### recordings.addEPGChannel(c,stream_id,name,url,stream_icon,epg_channel_id,EPGgenerator)  
def addEPGChannel(c,cid,name,url,iconimage,cat,origin,visible=1,weight=0,epg_channel='',description=''):
    epg_channel = epg_channel.lower()
    ### Remove /live/ from url
    if definition.ADDONgetSetting('notliveinurl') == 'true' :
        url = url.replace('/live/','/')  ### 2023-07-29
    ### add to channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER)
    weight = utils.SeriesEpisodeVOD(name)[0]  ###2021-01-17
    log('0err addEPGChannel name= %r,url= %r,iconimage= %r,cat= %r,origin= %r, weight= %r, epg_channel= %r' % (name,url,iconimage,cat,origin,weight,epg_channel))
    now = datetime.now()
    ###nowTS = int(time.mktime(now.timetuple()))
    nowTS = int(datetime.timestamp(now))
    nowTSold =    nowTS - 31536000    ### 365 * 24 * 60 * 60  now-timedelta(days=365)
    if cid == '' or cid == None:
        return
    try:
        cid = cid.strip()
    except Exception as e:
        log('err 1919 Except: %r' % e)
        pass
    try:
        if ',' in name:
            log('name.replace(, with ;).strip() name= %r'% (name))
        name = name.replace(',',';').strip()   ### 2018-07-18
    except Exception as e:
        log('err 1926 Except: %r' % e)
        pass
        log('name.replace(, with ¤).strip() name= %r, Error: %r'% (name,e))
    ###conn = getConnection()
    ###c = conn.cursor()
    try:
        ###c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, description) VALUES(?, ?, ?, ?, ?, ?)", [cid, name, iconimage, url, origin, cat])
        c.execute("SELECT * FROM channels WHERE id=?", [cid])
        channels = c.fetchall()
        ###utils.logdevarray(module+'-addChannel',channels)
        if len(channels) > 0:
            for chan in channels:
                ###utils.logdevarray(module+'-addChannel',chan)
                if chan[9] != '':
                    epg_channel = chan[9].lower()   ### 2020-04-01 Save EPG channel in lower
                c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cid, name, iconimage, url, origin, chan[5], weight, chan[7], chan[8], epg_channel, description, nowTS, chan[12]])  ### 2018-02-13 description <== chan[10]
        else:
            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cid, name, iconimage, url, origin, visible, weight, 'False', 0, epg_channel, description, nowTS, nowTSold])
    except Exception as e:
        log('err 1945 Except: %r' % e)
        pass
        ###definition.ADDONsetSetting('KeyErrorStop',repr(e))
        log('ChannelId= %r' % cid)
        log( 'c.execute("INSERT OR REPLACE INTO channels(id= %r, title= %r, logo= %r, stream_url= %r, source= %r, description= %r, now= %r) failed! \nERROR= %r' % (cid, name, iconimage, url, origin, description, now, e))
    ###conn.commit()
    ###c.close()

###c.execute("CREATE TABLE IF NOT EXISTS programs(channel TEXT, title TEXT, sub_title TEXT, start_date TIMESTAMP, end_date TIMESTAMP, description TEXT, categories TEXT, image_large TEXT, image_small TEXT, season TEXT, episode TEXT, is_movie TEXT, language TEXT, source TEXT, updates_id INTEGER, UNIQUE (channel, start_date, end_date))")    

def addEPGProgram(c, prog, channel, title, sub_title, start_date, end_date, description='', categories='', image_large='', image_small='', season= '', episode='', is_movie='', language='', source=''):
    ### add to channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER)
    channel = channel.strip().lower()  ### 2020-04-01
    ###title = title.strip()
    ###conn = getConnection()
    ###c = conn.cursor()
    
    ### 2025-02-12 Is channel available for this program?
    log('2693 error addEPGProgram channel= %r' % channel)
    c.execute("SELECT DISTINCT id FROM channels WHERE epg_channel=? and favorite!=? COLLATE NOCASE", [channel,'False'])
    channels = c.fetchall()
    if len(channels) <= 0 :
        log('2697 error addEPGProgram IGNORE program= %r on channel= %r' % (prog,channel))
        return
    log('2699 error addEPGProgram accepted program= %r on channel= %r' % (prog,channel))    
    now = datetime.now()
    ###nowTS = int(time.mktime(now.timetuple()))
    nowTS = int(datetime.timestamp(now))
    updates_id = nowTS
    
    try:
        title = utils.untilD8(title)
        log('2264 error addEPGProgram title= %r' % title)
    except Exception as e:
        log('error 2266 addEPGProgram Exception: %r' % e)
        pass
        title = title[0:24]
    
    try:
        description = utils.untilD8(description)
        log('2264 error addEPGProgram description= %r' % description)
    except Exception as e:
        log('error 2266 addEPGProgram Exception: %r' % e)
        pass
        description = description[0:200]
    
    try:
        c.execute("INSERT OR REPLACE INTO programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source, updates_id) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source, updates_id])
    except Exception as e:
        log('err 2214 Except: %r' % e)
        pass
        ###definition.ADDONsetSetting('KeyErrorStop',repr(e))
        log('Programdict= %r' % prog)
        log( 'c.execute("INSERT OR REPLACE INTO programs(channel= %r, title= %r, sub_title= %r, start_date= %r, end_date= %r, description= %r, categories= %r, image_large= %r, image_small= %r, season= %r, episode= %r, is_movie= %r, language= %r, source= %r) failed! \nERROR= %r' % (channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source, e))
    
    ###conn.commit()
    ###c.close()
    
def getEPGPrograms(channel):
    ###log('getEPGPrograms: channel= %r' % channel)
    channel = channel.strip().lower()  ### 2020-04-01
    conn = getConnection()
    c = conn.cursor()
    ###programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
    try:
        ###c.execute("SELECT * FROM programs WHERE channel=?", [channel])
        ###c.execute("SELECT DISTINCT title, description, source, start_date, end_date  FROM programs WHERE channel=? COLLATE NOCASE", [channel])
        c.execute("SELECT DISTINCT title, description, source, start_date, end_date  FROM programs WHERE channel=? ", [channel]) ### 2018-12-07
        programs = c.fetchall()
        programs = sorted(programs, key=itemgetter('start_date')) ### Sort by startdate
    except Exception as e:
        log('err 1089 Except: %r' % e)
        pass
        log( 'c.execute(SELECT DISTINCT title, description, start_date, end_date, source FROM programs WHERE channel=?, [channel]) failed! \nERROR= %r' % e)
        programs = []
    c.close()
    ###utils.logdevarray(module+' TEST',programs)
    return programs

def getEPGProgramsNow(channel):
    ###now= datetime.today()
    ###nowplus = now + timedelta(hours = 2)
    channel = channel.strip().lower()  ### 2020-04-01
    now = datetime.now()
    ###nowTS = int(time.mktime(now.timetuple()))   ### 2021-04-25
    nowTS = int(datetime.timestamp(now))
    nowTSplus =    nowTS + 7200    ### 2 * 60 * 60  now-timedelta(hours=2)
    ###log('now= datetime.today(%r) nowplus = %r' % (nowTS,nowTSplus))
    conn = getConnection()
    c = conn.cursor()
    c.execute("SELECT DISTINCT title, description, source, start_date, end_date  FROM programs WHERE channel=? COLLATE NOCASE", [channel])
    
    allprograms = c.fetchall()
    ###log('error 1 getEPGProgramsNow(channel)= %r)' % channel)
    ###log('error getEPGProgramsNow(len(allprograms))= %r)' % len(allprograms))
    last_end_date = 0
    for prog in allprograms:
        end_date =  prog[4]
        if end_date > last_end_date :
            last_end_date = end_date
        log('error 2 getEPGProgramsNow(last_end_date)= %r)' % last_end_date)
    if last_end_date > 0 :
        definition.ADDONsetSetting('Channel:last_end_date',channel + '¤' + utils.ht(last_end_date))
    else:
        definition.ADDONsetSetting('Channel:last_end_date',channel + '¤Not updated')
    try:
        channel = channel.replace(' (R)','').replace(' (r)','')   ### 2017-07-27
        ###log('error getEPGProgramsNow(channel= %r)' % channel )
        ###log('error 2 getEPGProgramsNow(nowTS= %r %r)' % (nowTS,utils.ht(nowTS)))
        ###log('error getEPGProgramsNow(nowTSplus= %r %r)' % (nowTSplus,utils.ht(nowTSplus)))
        c.execute("SELECT DISTINCT title, description, source, start_date, end_date  FROM programs WHERE channel=? and start_date < ? and end_date > ? COLLATE NOCASE", [channel,nowTSplus,nowTS])
        ###c.execute("SELECT DISTINCT title, description, source, start_date, end_date  FROM programs WHERE channel=? and start_date < ? and end_date > ? COLLATE NOCASE", [channel,nowplus,now])
        programs = c.fetchall()
        ###log('error getEPGProgramsNow(programs= %r)' % programs )
        programs = sorted(programs, key=itemgetter('start_date')) ### Sort by startdate
    except Exception as e:
        pass
        log( 'c.execute(SELECT DISTINCT title, description, start_date, end_date, source FROM programs WHERE channel=?and start_date < ? and end_date > ? , [channel]) failed! \nERROR= %r' % e)
        programs = []
    c.close()
    return programs

def delEPGProgram(channel, start_date, end_date):
    channel = channel.strip().lower()  ### 2020-04-01
    log( 'delEPGProgram(channel= %r, start_date= %r, end_date= %r)'% (channel, ht(start_date), ht(end_date)))
    success = False
    conn = getConnection()
    c = conn.cursor()
    ###programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
    c.execute("SELECT * FROM programs WHERE channel=? AND start_date=? AND end_date=?", [channel, start_date, end_date])
    favorites = c.fetchall()
    log( 'delEPGProgram favorites= %r, len(favorites)= %r' % (favorites, len(favorites)))
    if len(favorites) >= 1:   ### 2019-09-16 == to >=
        c.execute("DELETE FROM programs WHERE channel=? AND start_date=? AND end_date=?", [channel, start_date, end_date])
        conn.commit()
        log( 'delEPGProgram Succeded')
        success = True
    c.close()
    return success

    
def delOldEPGPrograms():
    log( 'Start to delete old programs, channels and TV series - cutoffdate')
    conn = getConnection()
    c = conn.cursor()
    ###programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
    ###c.execute("SELECT * FROM programs WHERE channel=?", [channel])
    cutoffdate = (datetime.today() - timedelta(days = 365))   ### Dummy 1 year
    daystoremove = 14   ### Dummy 2 weeks
    try:
        tv_archive_duration = definition.ADDONgetSetting('tv_archive_duration')
        if tv_archive_duration == '':
            tv_archive_duration = '2'
            definition.ADDONresetSetting('tv_archive_duration',tv_archive_duration)
        log('err tv_archive_duration= %r' % tv_archive_duration)
        daystoremove = int(tv_archive_duration)
        if daystoremove <= 1 :
            daystoremove = 2
        log('err daystoremove= %r' % daystoremove)
        ###cutoffdate = (datetime.today() - timedelta(days = daystoremove + 1)).timetuple()
        cutoffdate = (datetime.today() - timedelta(days = daystoremove + 1))
        cutoffdate = int(datetime.timestamp(cutoffdate))
        log('err Programs: cutoffdate(tuple)= %r' % cutoffdate)
    except Exception as e:
        log('err 2062 Except: %r' % e)
        pass
        log( 'c.execute(DELETE FROM programs or channels WHERE end_date or updated<? , 6 [cutoffdate]= %r) failed in beginning! \nERROR= %r' % (cutoffdate,e))
    try:
        ###time_tuple = dt_obj.timetuple()
        ###timestamp = time.mktime(time_tuple)
        ###datetime.fromtimestamp(timestamp)
        cutoffdate = (datetime.today() - timedelta(days = daystoremove + 10))
        cutoffdateTS = int(datetime.timestamp(cutoffdate))
        ##cutoffdate = int(time.mktime(cutoffdate))
        log('Programs: cutoffdate(timestamp)= %r' % cutoffdateTS)
        ###c4.execute("DELETE FROM recordings_adc WHERE alarmname=? and end=?",  [alarmname,endDate])
        c.execute("DELETE FROM programs WHERE end_date<? ", [cutoffdateTS])
    except Exception as e:
        log('err 2074 Except: %r' % e)
        pass
        log( 'c.execute(DELETE FROM programs  WHERE end_date<? , 5 [cutoffdate]= %r) failed! \nERROR= %r' % (cutoffdate,e))
    try:
        cutoffdate = (datetime.today() - timedelta(days = daystoremove + 10)).strftime("%Y-%m-%d %H:%M:%S")
        log('err recordings_adc: cutoffdate= %r' % cutoffdate)
        c.execute("DELETE FROM recordings_adc WHERE end<? and not name LIKE '%Recursive:%' ", [cutoffdate])  ### 2019-01-21 Only delete recursive manually
    except Exception as e:
        log('err 2082 Except: %r' % e)
        pass
        log( 'c.execute(DELETE FROM recordings_adc WHERE end<? , 4 [cutoffdate]= %r) failed! \nERROR= %r' % (cutoffdate,e))
    try:
        log('err 1 Channels: cutoffdate start')
        cutoffdate = datetime.today() - timedelta(days = 2)
        log('err 2 Channels: cutoffdate= %r' % cutoffdate)
        ###cutoffdateTS = datetime.timestamp(cutoffdate.replace(microsecond=0))
        ###log('err 3 Channels: cutoffdate(TS)= %r' % cutoffdateTS)
        cutoffdateTS = int(datetime.timestamp(cutoffdate))
        log('err 4 Channels: cutoffdate(TS)= %r' % cutoffdateTS)
        ###c4.execute("DELETE FROM recordings_adc WHERE alarmname=? and end=?",  [alarmname,endDate])
        c.execute("DELETE FROM channels WHERE updated<? ", [cutoffdateTS])
        log('err Delete Channels: cutoffdate(timestamp)= %r' % cutoffdateTS)
        c.execute("DELETE FROM tvseries WHERE updated<? ", [cutoffdateTS])
        log('err Delete tvseries: cutoffdate(timestamp)= %r' % cutoffdateTS)
    except Exception as e:
        log('err 2094 Except: %r' % e)
        pass
        log( 'c.execute(DELETE FROM channels WHERE updated<? , 2 [cutoffdate]= %r) failed! \nERROR= %r' % (cutoffdate,e))
    conn.commit()
    c.close()
    return
    
def delAllEPGPrograms():   ### If to many programs have changed - update full afterwards
    log( 'Start to delete all programs - cutoffdate')
    conn = getConnection()
    c = conn.cursor()
    ###programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
    ###c.execute("SELECT * FROM programs WHERE channel=?", [channel])
    try:
        ###time_tuple = dt_obj.timetuple()
        ###timestamp = time.mktime(time_tuple)
        ###datetime.fromtimestamp(timestamp)
        ##cutoffdate = datetime.today().timetuple()   ### now
        ##log('Programs: cutoffdate(tuple)= %r' % cutoffdate)
        ##cutoffdate = time.mktime(cutoffdate)
        cutoffdate = int(datetime.timestamp(datetime.today()))
        log('Programs: cutoffdate(timestamp)= %r' % cutoffdate)
        ###c4.execute("DELETE FROM recordings_adc WHERE alarmname=? and end=?",  [alarmname,endDate])
        c.execute("DELETE FROM programs WHERE end_date>? ", [cutoffdate])  ### Delete New programs
        c.execute("DELETE FROM programs WHERE end_date<? ", [cutoffdate])  ### Delete Old programs
    except Exception as e:
        log('err 2118 Except: %r' % e)
        pass
        log( 'c.execute(DELETE FROM programs WHERE start_date or updated<? , 1 [cutoffdate]= %r) failed! \nERROR= %r' % (cutoffdate,e))
    conn.commit()
    c.close()
    return

def delNewEPGPrograms():   ### If to many programs have changed - update full afterwards
    log( 'Start to delete all programs - cutoffdate')
    conn = getConnection()
    c = conn.cursor()
    ###programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
    ###c.execute("SELECT * FROM programs WHERE channel=?", [channel])
    try:
        ###time_tuple = dt_obj.timetuple()
        ###timestamp = time.mktime(time_tuple)
        ###datetime.fromtimestamp(timestamp)
        ##cutoffdate = datetime.today().timetuple()   ### now
        ##log('Programs: cutoffdate(tuple)= %r' % cutoffdate)
        ##cutoffdate = time.mktime(cutoffdate)
        cutoffdate = int(datetime.timestamp(datetime.today()))
        log('Programs: cutoffdate(timestamp)= %r' % cutoffdate)
        ###c4.execute("DELETE FROM recordings_adc WHERE alarmname=? and end=?",  [alarmname,endDate])
        c.execute("DELETE FROM programs WHERE end_date>? ", [cutoffdate])  ### Delete New programs
        ### c.execute("DELETE FROM programs WHERE end_date<? ", [cutoffdate])  ### Delete Old programs
    except Exception as e:
        log('err 2118 Except: %r' % e)
        pass
        log( 'c.execute(DELETE FROM programs WHERE start_date or updated<? , 1 [cutoffdate]= %r) failed! \nERROR= %r' % (cutoffdate,e))
    conn.commit()
    c.close()
    return

def RestoreFavorites(url):
    utils.notificationforced('[COLOR green]Restoring Favorites[/COLOR]',time=100000)
    log('Restoring Favorites url= ' + repr(url))
    restorecount = RestoreOldFavorites(url)
    utils.notificationforced('[COLOR green]Restoring Favorites Finished![/COLOR] %s records restored' % repr(restorecount))
    
def RestoreRecursiveChannels(url):
    utils.notificationforced('[COLOR green]Restoring Recursive Channels[/COLOR]',time=100000)
    log('Restoring Recursive Channels url= ' + repr(url))
    restorecount = RestoreOldRecursiveChannels(url)
    utils.notificationforced('[COLOR green]Restoring Recursive Channels Finished![/COLOR] %s records restored' % repr(restorecount))
    
def RestoreChannels(url):
    try:
        utils.notificationforced('[COLOR green]Restoring Channels[/COLOR]',time=100000)
        log('Restoring Channels url= ' + repr(url))
        restorecount = RestoreOldChannels(url)
        utils.notificationforced('[COLOR green]Restoring Channels Finished![/COLOR] %s records restored' % repr(restorecount))
    except Exception as  e:
        log('err 2144 Except: %r' % e)
        pass
        
def RestoreEPG(url):
    try:
        utils.notificationforced('[COLOR green]Restoring EPG[/COLOR]',time=100000)
        log('Restoring EPG url= ' + repr(url))
        restorecount = RestoreOldEPG(url)
        utils.notificationforced('[COLOR green]Restoring EPG Finished![/COLOR] %s records restored' % repr(restorecount))
    except Exception as  e:
        log('err 2154 Except: %r' % e)
        pass
    
def delAllChannels():   ### If user have changed - update full afterwards
    log( 'Start to delete all channels')
    conn = getConnection()
    c = conn.cursor()
    ###programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
    ###c.execute("SELECT * FROM programs WHERE channel=?", [channel])
    try:
        c.execute("DELETE FROM channels")
    except Exception as e:
        log('err #2166 Except: %r' % e)
        pass
        log( 'c.execute(DELETE FROM channels) failed! \nERROR= %r' % (e))
    conn.commit()
    c.close()
    return

def delAllPlannedPrograms():   ### If recursive have made too many recordings - Stop all recordings and clear parts of database but not the recursive recordings
    log( 'Start to delete all recordings')
    conn = getConnection()
    c = conn.cursor()
    ###programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
    ###c.execute("SELECT * FROM programs WHERE channel=?", [channel])
    try:
        c.execute("SELECT DISTINCT alarmname FROM recordings_adc WHERE not name LIKE '%Recursive:%'")
        favorites = c.fetchall()
        log( 'len(favorites)= %r' % len(favorites))
        for nameAlarm in favorites:
            try:
                log( 'nameAlarm= %r' % (nameAlarm))
                cancelAlarm(nameAlarm)
                ###xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
            except Exception as e:
                log('err #2188 Except: %r' % e)
                pass
                log( 'xbmc.executebuiltin(CancelAlarm(nameAlarm,True)) failed! \nERROR= %r' % (e))
        c.execute("DELETE FROM recordings_adc WHERE not name LIKE '%Recursive:%'")
    except Exception as e:
        log('err #2193 Except: %r' % e)
        pass
        log( 'c.execute(DELETE FROM recordings_adc) failed! \nERROR= %r' % (e))
    conn.commit()
    c.close()
    definition.ADDONresetSetting('RecordingFromOtherAddon','')  ### Clear last record time 2021-05-04
    return

def delAllPlannedProgramsInclusiveRecursive():   ### If recursive have made too many recordings - Stop all recordings and clear parts of database
    log( 'Start to delete all recordings')
    conn = getConnection()
    c = conn.cursor()
    ###programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
    ###c.execute("SELECT * FROM programs WHERE channel=?", [channel])
    try:
        c.execute("SELECT DISTINCT alarmname FROM recordings_adc")
        favorites = c.fetchall()
        for nameAlarm in favorites:
            try:
                cancelAlarm(nameAlarm)
                ###xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
            except Exception as e:
                log('err #2213 Except: %r' % e)
                pass
        c.execute("DELETE FROM recordings_adc")
    except Exception as e:
        log('err #2217 Except: %r' % e)
        pass
        log( 'c.execute(DELETE FROM recordings_adc) failed! \nERROR= %r' % (e))
    conn.commit()
    c.close()
    return

def setChannelCatchup(c,cat,catchup):
    
    if cat == '' or cat == None:
        return
    try:
        cat = cat.strip()
    except Exception as e:
        log('err #2231 Except: %r' % e)
        pass
    ###conn = getConnection()
    ###c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin]) 
    favorites = c.fetchall()
    ###utils.logdevarray(module+'-setChannelCatchup',favorites)
    for chan in favorites:
        c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], catchup, chan[9], chan[10], chan[11], chan[12]])
    ###conn.commit()
    ###c.close()

def getChannelDescription(cat):
    
    if cat == '' or cat == None:
        return ''
    try:
        cat = cat.strip()
    except Exception as e:
        log('err #2250 Except: %r' % e)
        pass
    conn = getConnection()
    c = conn.cursor()
    c.execute("SELECT DISTINCT description FROM channels WHERE id=? and source=?", [cat,origin]) 
    favorites = c.fetchall()
    des = ''
    for chan in favorites:
        if chan[0] != None:
            des += chan[0]
    c.close()
    return des

def setChannelDescription(cat,description):
    log('setChannelDescription cat= %r, description= %r' % (cat,description))
    if cat == '' or cat == None:
        return
    try:
        cat = cat.strip()
    except Exception as e:
        log('err #2270 Except: %r' % e)
        pass
    conn = getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin]) 
    favorites = c.fetchall()
    for chan in favorites:
        try:
            log('setChannelDescription id= %r, title= %r' % (cat, chan[1]))
        except Exception as e:
            log('err #2280 Except: %r' % e)
            pass
            log('setChannelDescription id= %r, ERROR: %r' % (cat, e))
        c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9], description, chan[11], chan[12]])
    conn.commit()
    c.close()

def setChannelAdded(c,cat,added):
    if cat == '' or cat == None:
        return
    try:
        cat = cat.strip()
    except Exception as e:
        log('err #2293 Except: %r' % e)
        pass    
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin]) 
    favorites = c.fetchall()
    for chan in favorites:
        c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9], chan[10], chan[11], added])

def getChannelEpgid(c,cat):
    if cat == '' or cat == None:
        return
    try:
        cat = cat.strip()
    except Exception as e:
        log('err #2306 Except: %r' % e)
        pass    
    c.execute("SELECT DISTINCT epg_channel FROM channels WHERE id=? and source=?", [cat,origin]) 
    favorites = c.fetchall()
    if len(favorites) > 0:
        try:
            fav = favorites[0][0]
        except Exception as e:
            log('err #2314 Except: %r' % e)
            pass
            log( 'c.execute(SELECT DISTINCT epg_channel FROM channels WHERE id=%r, [cat]) failed! \nERROR= %r' % (cat,e))
            fav = ''
    else:
        fav = ''
    log('getChannelEpgid(c,cat= %r)-->Epgid= %r' % (cat,fav))
    return fav.lower().strip()
    
def setChannelEpgid(c,cat,fav):
    if cat == '' or cat == None or fav == None:
        return
    try:
        cat = cat.strip()
    except Exception as e:
        log('err #2329 Except: %r' % e)
        pass    
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin]) 
    favorites = c.fetchall()
    fav = fav.lower().strip()
    for chan in favorites:
        if fav != None : 
            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], fav, chan[10], chan[11], chan[12]]) 
    log('setChannelEpgid(c,cat= %r)-->Epgid= %r' % (cat,fav))
    
    c.execute("SELECT * FROM channelsRecursive WHERE id=? and source=?", [cat,origin]) 
    favorites = c.fetchall()
    for chan in favorites:
        if fav != None : 
            c.execute("INSERT OR REPLACE INTO channelsRecursive(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], fav, chan[10], chan[11], chan[12]]) 
        
def getChannelFav(c,cat):
    
    if cat == '' or cat == None:
        return
    try:
        cat = cat.strip()
    except Exception as e:
        log('err #2352 Except: %r' % e)
        pass    
    c.execute("SELECT DISTINCT favorite FROM channels WHERE id=? and source=?", [cat,origin])  ### 2017-09-28
    favorites = c.fetchall()
    if len(favorites) > 0:
        try:
            fav = favorites[0][0]
            ###if fav == 'false':
            ###    fav = 'False'
        except Exception as e:
            log('err #2362 Except: %r' % e)
            pass
            log( 'c.execute(SELECT DISTINCT favorite FROM channels WHERE id=%r, [cat]) failed! \nERROR= %r' % (cat,e))
            fav = 'False'
    else:
        fav = 'False'
    return fav
    
def setChannelFav(c,cat,fav):
    if cat == '' or cat == None or fav == '' or fav == None:
        return
    try:
        cat = cat.strip()
    except Exception as e:
        log('err #2376 Except: %r' % e)
        pass    
    ###c.execute("SELECT * FROM channels WHERE id=?", [cat])   ### 2018-12-07
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])  ### 2017-08-26
    favorites = c.fetchall()
    for chan in favorites:
        if fav != '' and fav != None and fav.lower() != 'false': 
            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], fav, chan[8], chan[9], chan[10], chan[11], chan[12]])
        else:
            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], 'False', chan[8], chan[9], chan[10], chan[11], chan[12]])

def getFavoriteChannelsEPG():
    conn = getConnection()
    c = conn.cursor()
    c.execute("SELECT epg_channel FROM channels WHERE favorite=? and source=?", ['True',origin])
    favorites = c.fetchall()
    c.close()
    EPGchannels = []
    for chan in favorites:
        EPGchannels.append(chan[0])
    definition.log('getFavoriteChannelsEPG %r' % EPGchannels)
    return EPGchannels
    
def addChannelFav(cat,fav):
    log(' addChannelFav cat= %r' % (cat))
    if cat == '' or cat == None:
        return
    try:
        cat = cat.strip()
    except Exception as e:
        log('err #2394 Except: %r' % e)
        pass
    conn = getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])
    ###c.execute("SELECT * FROM channels WHERE id=? ", [cat]) ### 2018-12-07
    favorites = c.fetchall()
    for chan in favorites:
        c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], fav, chan[8], chan[9], chan[10], chan[11], chan[12]])
        utils.notificationforced('Favorite added: %s' % chan[1])
    conn.commit()
    c.close()

def delChannelFav(cat):
    log('-delChannelFav cat= %r' % (cat))
    cat = cat.strip()
    conn = getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])
    ###c.execute("SELECT * FROM channels WHERE id=? ", [cat])   ### 2018-12-07
    favorites = c.fetchall()
    for chan in favorites:
        log('-delChannelFav 1 cat= %r' % (cat))
        c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], 'False', chan[8], chan[9], chan[10], chan[11], chan[12]])
    conn.commit()
    c.close()

    
def setChannelIcon(c,cat,fav):
    log('err #2475 setChannelIcon(c= %r,cat= %r,fav= %r)' % (c,cat,fav))
    if cat == '' or cat == None or fav == '' or fav == None:
        return
    try:
        cat = cat.strip()
    except Exception as e:
        log('err #2376 Except: %r' % e)
        pass    
    ###c.execute("SELECT * FROM channels WHERE id=?", [cat])   ### 2018-12-07
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])  ### 2017-08-26
    favorites = c.fetchall()
    for chan in favorites:
        if fav != '' and fav != None: 
            log('err #2488 setChannelIcon(c= %r,cat= %r,fav= %r)' % (c,cat,fav))
            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], fav, chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9], chan[10], chan[11], chan[12]])

def setChannelHide(cat):
    cat = cat.strip()
    conn = getConnection()
    c = conn.cursor()
    ###c.execute("SELECT * FROM channels WHERE id=?", [cat])
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])
    favorites = c.fetchall()
    for chan in favorites:
        c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], 0, chan[6], chan[7], chan[8], chan[9], chan[10], chan[11], chan[12]])
        utils.notificationforced('Channel Hidden: %s' % chan[1])
    conn.commit()
    c.close()
    
def delChannelHide(cat):
    cat = cat.strip()
    log('delChannelHide(cat= %r)' % cat)
    conn = getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])
    favorites = c.fetchall()
    log('delChannelHide len(favorites)= %r' % len(favorites))
    for chan in favorites:
        c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], 1, chan[6], chan[7], chan[8], chan[9], chan[10], chan[11], chan[12]])
    ###log('delChannelHide-1 len(favorites)= %r' % len(favorites))
    conn.commit()
    c.close()

def setChannelRecursive(cat):
    cat = cat.strip()
    conn = getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])
    favorites = c.fetchall()
    for chan in favorites:
        if not chan[9] is None:
            if not ' (R)' in chan[9]:
                recursive = chan[9] + ' (R)'
            else:
                recursive = chan[9]
            ### Only mark as recursive channel if epg_channel assigned
            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], recursive.replace(' (R)',''), chan[10], chan[11], chan[12]])
            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], ADDONid, chan[5], chan[6], 'False', 0, chan[9].replace(' (R)',''), '', '', ''])  ### Play channel Source = ADDONid
            c.execute("INSERT OR REPLACE INTO channelsRecursive(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], 'False', 0, chan[9].replace(' (R)',''), '', '', ''])  ### Play channelRecursive
            utils.notificationforced('Recursive added: %s' % chan[1])

    conn.commit()
    c.close()
    
def delChannelRecursive(cat):
    cat = cat.strip()
    log('delChannelRecursive(cat= %r)' % cat)
    conn = getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])
    favorites = c.fetchall()
    for chan in favorites:
        c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], 1, chan[6], chan[7], chan[8], chan[9].replace(' (R)',''), chan[10], chan[11], chan[12]])
        c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], ADDONid, chan[5], chan[6], 'False', 0, chan[9].replace(' (R)',''), '', '', ''])  ### Play channel Source = ADDONid
        c.execute("INSERT OR REPLACE INTO channelsRecursive(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [cat, chan[1], chan[2], chan[3], chan[4], 0, chan[6], chan[7], chan[8], chan[9].replace(' (R)',''), chan[10], chan[11], chan[12]])
    ###log('delChannelHide-1 len(favorites)= %r' % len(favorites))
    conn.commit()
    c.close()
    
def isChannelRecursive(cat):
    log('isChannelRecursive(cat= %r)' % cat)
    cat = cat.strip()
    conn = getConnection()
    c = conn.cursor()
    favorites =  []
    try:
        c.execute("SELECT visible FROM channelsRecursive WHERE id=? and source=?", [cat,origin])
        favorites = c.fetchall()
        if repr(favorites[0][0]) == '1':
            result = True
        else:
            result = False
    except Exception as e:
        log('err #2498 Except: %r' % e)
        pass
        log('isChannelRecursive(Error= %r)' % e)
        result = False
    
    c.close()
    log('isChannelRecursive(result= %r)' % result)
    return result
  
def isChannelVisible(cat):
    ###log('isChannelVisible(cat=%r)' % cat)
    cat = cat.strip()
    conn = getConnection()
    c = conn.cursor()
    try:
        c.execute("SELECT DISTINCT visible FROM channels WHERE id=? and source=?", [cat,origin])
        favorites = c.fetchall()
    except Exception as e:
        log('err #2516 Except: %r' % e)
        pass
        favorites =  []
    result = False
    if len(favorites) > 0:
        result = favorites[0][0]
        ###log('result= %r' % result)
        if result == 1:
            result = True
        ###log('result1= %r' % result)
    c.close()
    return result

def LookupAllActiveEPGs():
    log('error LookupAllActiveEPGs()')
    c = getConnection().cursor()
    try:
        ### channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER)
        c.execute("SELECT DISTINCT channel, source FROM programs")
        ###c.execute("SELECT * FROM channels WHERE source=?",[origin])
        channels = c.fetchall()
    except Exception as e:
        log('error LookupAllActiveEPGs Exception: %r' % e)
        pass
        channels =  []
    ###channels = sorted(channels, key=itemgetter('title'))
    channels = sorted(channels,key=lambda i:i[0].lower())  ### Sort ignore case coloum 0
    
    log('error LookupAllActiveEPGs - len= %r' % len(channels))
    c.close()
    return channels

   
def getAllChannels():
    log('error getAllChannels()')
    c = getConnection().cursor()
    try:
        ### channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER)
        c.execute("SELECT * FROM channels")
        ###c.execute("SELECT * FROM channels WHERE source=?",[origin])
        channels = c.fetchall()
    except Exception as e:
        log('error #2538 Except: %r' % e)
        pass
        channels =  []
    ###channels = sorted(channels, key=itemgetter('title'))
    channels = sorted(channels,key=lambda i:i[1].lower())  ### Sort ignore case coloum 1
    
    log('error getAllChannels() - len= %r' % len(channels))
    c.close()
    return channels

def getAllChannelSources():
    log('error getAllChannelSources')
    c = getConnection().cursor()
    try:
        ### channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER)
        c.execute("SELECT DISTINCT source FROM channels")
        channels = c.fetchall()
        log('errX 0 getAllChannelSources - len= %r' % len(channels))
    except Exception as e:
        log('err #2559 Except: %r' % e)
        pass
        log('errX getAllChannelSources ERROR: %r' % e)
        channels =  []
    ###channels = sorted(channels, key=itemgetter('title'))
    log('errX 1 getAllChannelSources - len= %r' % len(channels))
    channels = sorted(channels,key=lambda i:i[0].lower())  ### Sort ignore case coloum 1
    ###channels = sorted(channels)
    log('errX 2 getAllChannelSources - len= %r' % len(channels))
    log('errX channels= %r' % channels)
    for chan in channels:
        log('errX chan= %r' % chan)
        log('errX chan= %r' % chan[0])
    c.close()
    return channels 
    
def getAllChannelsList():
    c = getConnection().cursor()
    try:
        ### channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER)
        c.execute("SELECT DISTINCT id, title, stream_url, epg_channel, logo FROM channels")
        channels = c.fetchall()
    except Exception as e:
        log('error #2577 Except: %r' % e)
        pass
        channels =  []
    ###channels = sorted(channels, key=itemgetter('title'))
    channels = sorted(channels,key=lambda i:i[1].lower())  ### Sort ignore case coloum 1
    log('error getAllChannelsList() - len= %r' % len(channels))
    return channels

def getAllChannelsList0(epg_channel):
    c = getConnection().cursor()
    try:
        ### channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER)
        c.execute("SELECT DISTINCT id,title,epg_channel FROM channels WHERE epg_channel LIKE ? and source=? COLLATE NOCASE",['%' + epg_channel + '%',origin])
        channels = c.fetchall()
        c.execute("SELECT DISTINCT id,title,epg_channel FROM channels WHERE id LIKE ? and source=? COLLATE NOCASE",['%' + epg_channel + '%',origin])
        channelsid = c.fetchall()
    except Exception as e:
        log('err #2594 Except: %r' % e)
        pass
        channels =  []
        channelsid = []
    channelsall = []    
    for chan in channels:
        channelsall.append(chan)
    for chan in channelsid:
        channelsall.append(chan)
    channels = channelsall
    ###channels = sorted(channels, key=itemgetter('title'))
    channels = sorted(channels,key=lambda i:i[1].lower())  ### Sort ignore case coloum 1
    log('getAllChannelsList() - len= %r' % len(channels))
    return channels

def urlFromCat(cat):
    c = getConnection().cursor()
    try:
        c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])
        urls = c.fetchall()
        ###log('urls= %s --> cat= %s' %(repr(urls),cat))
    except Exception as e:
        log('err #2616 Except: %r' % e)
        pass
        urls = ''
    if len(urls) > 0:
        url = urls[0][3]
    else:
        url = ''
        ###utils.notification( 'NOT FOUND: channel= %s' % (cat))
    c.close()
    ###log('cat= %s --> url= %s' %(cat,url))
    return url

def titleFromCat(cat):
    c = getConnection().cursor()
    try:
        c.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,origin])
        urls = c.fetchall()
        ###log('urls= %s --> cat= %s' %(repr(urls),cat))
    except Exception as e:
        log('err #2635 Except: %r' % e)
        pass
        urls = ''
    if len(urls) > 0:
        url = urls[0][1]  # Return title
    else:
        url = ''
        ###utils.notification( 'NOT FOUND: channel= %s' % (cat))
    c.close()
    ###log('cat= %s --> url= %s' %(cat,url))
    return url
    
def directprograms(cat):
    ###Direct programs always have 'DIR' as first characters of cat
    ### Channel name has (D) in the end to be Direct
    ###channelname = ChannelName(cat)
    ###log('directprograms(cat= %r) channelname= %r, last 4= %r' % (cat, channelname,channelname[-4:]))
    ###if not ' (D' in channelname[-5:]:
    if cat != None and cat[:3] != 'DIR':
        log('Not direct program cat= %r' % cat)
        return ''
    url = urlFromCat(cat)
    log('directprograms(cat= %r) url= %r' % (cat, url))
    return url

def catFromEPGcat(EPGcat):
    c = getConnection().cursor()
    try:
        c.execute("SELECT * FROM channelsRecursive WHERE epg_channel=?", [EPGcat])   ### channels == channelsRecursive
        cats = c.fetchall()
        ###log('cats= %r <-- EPGcat= %r' %(cats,EPGcat))
        if len(cats) > 0:
            cat = cats[0][0]
        else:
            c.execute("SELECT * FROM channelsRecursive WHERE id=?", [EPGcat])   ### channels == channelsRecursive
            cats = c.fetchall()
            if len(cats) > 0:
                cat = cats[0][0]
            else:
                ###cat = EPGcat
                cat = ''   ### 2018-12-07
            log('cat= %r <-- EPGcat= %r' %(cat,EPGcat))
    except Exception as e:
        log('err #2678 Except: %r' % e)
        pass
        ###cat = EPGcat
        cat = ''   ### 2018-12-07
    c.close()
    return cat

def catFromUrl(url):
    c = getConnection().cursor()
    try:
        c.execute("SELECT * FROM channels WHERE stream_url=?", [url])
        cats = c.fetchall()
        ###log('cats= %r <-- url= %r' %(cats,url))
        if len(cats) > 0:
            cat = cats[0][0]
        else:
            if ':25461' in url:
                url  = url.replace(':25461',':8080')
                c.execute("SELECT * FROM channels WHERE stream_url=?", [url])
                cats = c.fetchall()
                ###log('cats= %r <-- url= %r' %(cats,url))
                if len(cats) > 0:
                    cat = cats[0][0]
                else:
                    cat = ''
            else:
                cat = ''
            ###utils.notification( 'NOT FOUND: channel= %s' % (url))
    except Exception as e:
        log('err #2707 Except: %r' % e)
        pass
        cat = ''
    c.close()
    ###log('cat= %s <-- url= %s' %(cat,url))
    ###2017-06-12 19:41:13 default.py: catThis = recordings.catFromUrl(StreamURL)= '' 
    ###2017-06-12 19:41:13 default.py: 0 addDir(name= FORMULA 1 (2017) - CANADIAN GRAN PRIX RACE (1080),url= http://roq-tv.net:25461/movie/<username>/<password>/3518.mp4,mode= 200,iconimage= ,cat= ,date= ,description= IMDB_ID: 
    if not cat == '':
        return cat
    else:
        try:
            cat=url.split('live/')[1].split('/')[0]
        except Exception as e:
            log('err #2720 Except: %r' % e)
            pass
            try:
                cat=url.split('tv2danmark/')[1].split('/')[0]
            except Exception as e:
                log('err #2725 Except: %r' % e)
                pass
                try:
                    cat=url.split('i/')[1].split('/')[0]
                except Exception as e:
                    log('err #2730 Except: %r' % e)
                    pass
                    try:
                        cat=url.split('.')[-2].split('/')[-1]
                    except Exception as e:
                        log('err #2735 Except: %r' % e)
                        pass
                        cat=''
                        log('catFromUrl(url) FAILED: url= %r' % url)
    return cat
    
def IconFromCat(cat):
    catin = cat
    url = ''
    if cat!= '#':
        c = getConnection().cursor()
        try:
            ### c.execute("INSERT OR REPLACE INTO channelsRecursive(0id, 1title, 2logo, 3stream_url, 4source, 5visible, 6weight, 7favorite, 8catchup, 9epg_channel, 10description, 11updated, 12created)
            log('err 1 cat= %r, url= %r' % (cat,url))
            c.execute("SELECT * FROM channels WHERE id=? and source=? AND visible=1", [cat.strip(),origin])
            ### testc.execute("SELECT * FROM channels WHERE id=?", [cat.strip()])
            urls = c.fetchall()
            log('err 2 cat= %r, urls= %r' % (cat,urls))
            if len(urls) > 0:
                log('err 3 len(urls) > 0')
                cat = urls[0][9].lower()   ### use epg_channel
            if cat == '':
                log('err 4a cat= %r' % (cat))
                try:
                    log('err 4b cat= %r, urls[0]= %r' % (cat,urls[0]))
                    url = urls[0][2]           ### use channel icon
                except Exception as e:
                    log('err #3572 Except: %r' % e)
                    pass  
            else:
                log('err 5 cat= %r, url= %r' % (cat,url))
                url = ''
                ###if not 'http' in cat and not cat == '#':
                ###    utils.notification( '1. NOT FOUND: channel= %s' % (cat))
            if url == '':
                log('err 6 cat= %r, urls[0]= %r' % (cat,urls[0]))
                try:
                    cat = urls[0][9].lower()   ### use epg_channel
                except Exception as e:
                    log('err #3572 Except: %r' % e)
                    pass   
        except Exception as e:
            log('err #3575 Except: %r' % e)
            pass
            url = ''
        c.close()
    
    if url == '':
        if cat == '#':
            cat= 'vod4'
        log('IconFromCat cat= %r' % cat)
        if cat == '':
            cat = 'tv1'
        if cat == 'tv3max.dk':
            cat = 'tv3max2.dk'
        url = 'https://raw.githubusercontent.com/krogsbell/Logos/master/'+str(cat)+'.png'
    log('IconFromCat catin= %r, url= %r' % (catin,url))
    return url
    

def ChannelName(cat):
    c = getConnection().cursor()
    try:
        #xbmc.log('recordings.py: ChannelName cat= %s' % (repr(cat)))
        ###c = getIconConnection().cursor()
        #c.execute("SELECT * FROM channels WHERE title=? COLLATE NOCASE", [title.strip()])
        ###c.execute("SELECT * FROM channels WHERE title=? and source=? COLLATE NOCASE", [ChannelName.strip(),origin])
        c.execute("SELECT * FROM channels WHERE id=? and source=? COLLATE NOCASE", [cat.strip(),origin])  ### 2017-09-30
        logos = c.fetchall()
        #xbmc.log('recordings.py: ChannelName logos title= %s' % repr(logos))
        if len(logos) > 0:
            logo = logos[0][1]
        else:
            logo = cat
            ###utils.notification( 'NOT FOUND: channel= %s' % (cat))
        #xbmc.log('recordings.py: ChannelName logo= %s' % repr(logo))
    except Exception as e:
        log('err #2797 Except: %r' % e)
        pass
        logo = cat
    c.close()
    return logo
    
def EPG_ChannelFromCat(cat):
    c = getConnection().cursor()
    try:
        logo = ''
        c.execute("SELECT * FROM recordings_adc WHERE cat=? COLLATE NOCASE", [cat.strip()]) 
        logos = c.fetchall()
        if len(logos) > 0:
            logo = logos[0][6]
        log('err 1 EPG_ChannelFromCat(cat= %r)= %r' % (cat,logo))
        if logo == '':    
            c.execute("SELECT * FROM channels WHERE id=? and source=? COLLATE NOCASE", [cat.strip(),origin]) 
            logos = c.fetchall()
            if len(logos) > 0:
                logo = logos[0][9]
            else:
                logo = ''
        log('err 2 EPG_ChannelFromCat(cat= %r)= %r' % (cat,logo))
    except Exception as e:
        log('err #2815 Exception: %r' % e)
        pass
        logo = ''
    logo = logo.lower().strip()
    c.close()
    return logo

def EPG_ChannelFromCname(ChannelName):
    cat = ChannelName
    c = getConnection().cursor()
    try:
        c.execute("SELECT * FROM channels WHERE title=? and source=? COLLATE NOCASE", [cat.strip(),origin]) 
        logos = c.fetchall()
        if len(logos) > 0:
            logo = logos[0][9]
        else:
            logo = ''
            ###utils.notification( 'NOT FOUND: channel= %s' % (cat))
        #xbmc.log('recordings.py: ChannelName logo= %s' % repr(logo))
    except Exception as e:
        log('err #2835 Exception: %r' % e)
        pass
        logo = ''
    logo = logo.lower().strip()
    c.close()
    return logo
    
def catsfromEPGid(epgid):
    c = getConnection().cursor()
    try:
        ###c.execute("SELECT * FROM channels WHERE epg_channel=? favorite=? and visible=? and source=?", [epgid,'True',1,origin])
        c.execute("SELECT * FROM channels WHERE epg_channel=?", [epgid])
        ###c.execute("SELECT * FROM channels WHERE title=? COLLATE NOCASE", [epgid.strip()])
        logos = c.fetchall()
        cat= logos[0][0]
    except Exception as e:
        log('err #2851 Exception: %r' % e)
        pass
        logos= []
    if len(logos) > 0:
        logo = logos[0][0]
    else:
        logo = '0'
        if not 'http' in epgid:
            utils.notification( 'NOT FOUND: epgid= %s' % (epgid))
    utils.logdebug('catsfromEPGid', 'epgid= %r, cat= %r' % (epgid, logo))
    c.close()
    return logo
    
    
def CatFromChannelName(ChannelName):
    c = getConnection().cursor()
    try:
        ###c = getIconConnection().cursor()
        c.execute("SELECT * FROM channels WHERE title=? and source=? COLLATE NOCASE", [ChannelName.strip(),origin])
        logos = c.fetchall()
        if len(logos) > 1:
            log('err More channels with same name: ChannelName= %r --> %r' % (ChannelName,logos[1][0]))
        if len(logos) == 1:
            log('err One channels with name: ChannelName= %r --> %r' % (ChannelName,logos[0][0]))
    except Exception as e:
        log('err #2876 Exception: %r' % e)
        pass
        log('CatFromChannelName(ChannelName= %r) ERROR: %r' % (ChannelName,e))
        logos= []
    if len(logos) > 0:
        logo = logos[0][0]
    else:
        logo = '0'
        log('2. NOT FOUND: channel= %s' % ChannelName)
    log('CatFromChannelName ChannelName= %r, cat= %r' % (ChannelName, logo))
    c.close()
    return logo
    
def ChannelNameDb(cat,c,origin):  ###  and source=?", [cat,origin])
    try:
        #xbmc.log('recordings.py: ChannelName cat= %s' % (repr(cat)))
        ###c = getIconConnection().cursor()
        ###c = getConnection().cursor()
        #c.execute("SELECT * FROM channels WHERE title=? and source=? COLLATE NOCASE", [title.strip(),origin])
        c.execute("SELECT * FROM channels WHERE id=? and source=? COLLATE NOCASE", [cat.strip(),origin])  ### 2017-09-30

        logos = c.fetchall()
        #xbmc.log('recordings.py: ChannelName logos title= %s' % repr(logos))
    except Exception as e:
        log('err #2900 Exception: %r' % e)
        pass
        logos= []
    if len(logos) > 0:
        logo = logos[0][1]
    else:
        logo = cat
        ###utils.notification( 'NOT FOUND: channel= %s' % (cat))
    #xbmc.log('recordings.py: ChannelName logo= %s' % repr(logo))
    ###c.close()  # 2017-12-29
    return logo

def CatFromChannelNameDb(ChannelName,c,origin):
    try:
        ###c = getIconConnection().cursor()
        ###c = getConnection().cursor()
        c.execute("SELECT * FROM channels WHERE title=? and source=? COLLATE NOCASE", [ChannelName.strip(),origin])
        #c.execute("SELECT * FROM channels WHERE id=?", [cat.strip()])
        logos = c.fetchall()
        
        cat= int(logos[0][0])
    except Exception as e:
        log('err #2922 Exception: %r' % e)
        pass
        logos= []
    if len(logos) > 0:
        logo = logos[0][0]
    else:
        logo = '0'
        ###utils.notification( 'NOT FOUND: channel= %s' % (ChannelName))
    utils.logdebug('CatFromChannelName', 'ChannelName= %r, cat= %r' % (ChannelName, logo))
    ###c.close()  # 2017-12-29
    return logo

def getRecordings():
    #print "getRecordings"
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    c = getConnection().cursor()
    #print "getRecordings1"
    try:
        c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE start > ?" , [now])
        #print "getRecordings2"
        recordings = c.fetchall()
        recordings = sorted(recordings, key=itemgetter('start'))
        #print "getRecordings3"
        log('getRecordings len(recordings)= ' + str(len(recordings)))
        for index in range(0, len(recordings)):
            cat         = recordings[index][0]
            name        = recordings[index][1]
            startDate   = parseDate(recordings[index][2]) 
            log('getRecordings() Name= %r StartDate=%r' %(recordings[index][1],recordings[index][2]))
    except Exception as e:
        log('err #2952 Exception: %r' % e)
        pass
        log('getRecordings() failed! \nERROR= %r' % e)
        recordings = []
    ##for index in range(0, len(recordings)):
    ##  #print "getRecordings4"
    ##  cat         = recordings[index][0]
    ##  #print "getRecordings5"
    ##  name        = recordings[index][1]
    ##  #print "getRecordings6"
    ##  startDate   = parseDate(recordings[index][2])
    ##  #print "getRecordings7"
    ##  endDate     = parseDate(recordings[index][3])
    ##  #print "getRecordings8"
    ##  alarmname   = recordings[index][4]
    ##  #print "getRecordings9"
    ##  description = recordings[index][5]
    ##  #print "getRecordings9a"
    ##  #print "recording# " + str(index) + ": " + str(cat) + " , " + str(name) + " , " + repr(startDate) + " , " + repr(endDate) + " , " + alarmname + " , " + str(description)
    #print "getRecordings10"
    #try:
    #   conn.commit()
    #   #print 'recordings.py conn.commit OK'
    #except Exception as e:
    #   log('err #2976 Exception: %r' % e)
    #   pass
    #   #print 'recordings.py conn.commit failed!'
    #try:
    #   c.commit()
    #   #print 'recordings.py c.commit OK'
    #except Exception as e:
    #   pass
    #   #print 'recordings.py c.commit failed!'
    c.close()
    #print "getRecordings"
    return recordings
    
def isRecursiveRecord(cat,recordname):
    log( 'c.execute(SELECT * FROM recordings_adc WHERE cat= %r and name= %r)' % (cat,recordname))
    c = getConnection().cursor()
    try:  ### WHERE
        c.execute("SELECT * FROM recordings_adc WHERE cat=? and name=?",  [cat,recordname])
    except Exception as e:
        log('err #2995 Exception: %r' % e)
        pass
        log( 'c.execute(SELECT * FROM recordings_adc WHERE cat=? and name=?) failed! \nERROR= %r' % e)
    recordings = c.fetchall()
    c.close()
    if len(recordings) > 0:
        return True
    else:
        return False
    
def isRecording(cat,name,startD,endD):
    startD = parseDate(startD)
    endD = parseDate(endD)
    c = getConnection().cursor()
    if '[' in name:
        name = name.split('[')[0].strip() + '%'
    ###name = name.replace('[','%').replace(']','%').replace('(','%').replace(')','%').replace('.','%').replace('%%','%').replace('  ','%').replace('%%','%').replace('% %','%')
    log( 'c.execute(SELECT * FROM recordings_adc WHERE cat=%r and name like %r)' % (cat,name))
    try:  ### WHERE
        c.execute("SELECT * FROM recordings_adc WHERE cat=? and name like ? and start <= ? and end >= ? ",  [cat,name,startD,endD])
        
    except Exception as e:
        log('err #3017 Exception: %r' % e)
        pass
        log( 'c.execute(SELECT * FROM recordings_adc WHERE cat=? and name like ?) failed! \nERROR= %r' % e)
    recordings = c.fetchall()
    c.close()
    return recordings
    
def getRecordingsActive(startD,endD):
    try:
        startPadding = 60 * int(definition.ADDONgetSetting('TimeBefore')) + 1
        endPadding   = 60 * int(definition.ADDONgetSetting('TimeAfter')) + 1
    except Exception as e:
        log('err #3029 Exception: %r' % e)
        startPadding = 60 * 3
        endPadding   = 60 * 15
    startD = parseDate(startD)
    endD = parseDate(endD)
    startD = startD + timedelta(seconds = startPadding)
    endD = endD - timedelta(seconds = endPadding)
    if endD < startD:
        endD = startD
    c = getConnection().cursor()
    try:
        c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc")
    except Exception as e:
        log('err #3042 Exception: %r' % e)
        pass
        log( 'c.execute(SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc) failed! \nERROR= %r' % e)
    recordings = c.fetchall()
    recordingsActive=[]

    for index in range(0, len(recordings)): 
        cat         = recordings[index][0]
        ###noblock     = utils.directprograms(cat)
        noblock     = directprograms(cat)
        name        = recordings[index][1]
        startDate   = parseDate(recordings[index][2]) + timedelta(seconds = startPadding+1)
        endDate     = parseDate(recordings[index][3]) - timedelta(seconds = endPadding+1)
        alarmname   = recordings[index][4]
        description = recordings[index][5]
        if not('Recursive:' in name) and not ('[COLOR blue]' in name) and noblock == '':
            if ((endDate >= startD and startDate <= endD) or (endDate >= endD and startDate <= startD) or (endDate <= endD and startDate >= startD)):
                recordingsActive.append(name)
    c.close()
    return recordingsActive

def getRecordingsActiveAll(startD,endD):
    try:
        startPadding = 60 * int(definition.ADDONgetSetting('TimeBefore')) + 1
        endPadding   = 60 * int(definition.ADDONgetSetting('TimeAfter')) + 1
    except Exception as e:
        log('err #3068 Exception: %r' % e)
        startPadding = 60 * 3
        endPadding   = 60 * 15
    startD = parseDate(startD)
    endD = parseDate(endD)
    startD = startD + timedelta(seconds = startPadding)
    endD = endD - timedelta(seconds = endPadding)
    if endD < startD:
        endD = startD
    c = getConnection().cursor()
    c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc")
    recordings = c.fetchall()
    recordingsActive=[]

    for index in range(0, len(recordings)): 
        cat         = recordings[index][0]
        name        = recordings[index][1]
        startDate   = parseDate(recordings[index][2]) + timedelta(seconds = startPadding+1)
        endDate     = parseDate(recordings[index][3]) - timedelta(seconds = endPadding+1)
        alarmname   = recordings[index][4]
        description = recordings[index][5]
        if not('Recursive:' in name) and not ('[COLOR blue]' in name):
            if ((endDate >= startD and startDate <= endD) or (endDate >= endD and startDate <= startD) or (endDate <= endD and startDate >= startD)):
                recordingsActive.append(name)
    c.close()
    return recordingsActive

def getRecordingsActiveAllCat(startD,endD):
    try:
        startPadding = 60 * int(definition.ADDONgetSetting('TimeBefore')) + 1
        endPadding   = 60 * int(definition.ADDONgetSetting('TimeAfter')) + 1
    except Exception as e:
        log('err #3100 Exception: %r' % e)
        startPadding = 60 * 3
        endPadding   = 60 * 15
    startD = parseDate(startD)
    endD = parseDate(endD)
    startD = startD + timedelta(seconds = startPadding)
    endD = endD - timedelta(seconds = endPadding)
    if endD < startD:
        endD = startD
    try:
        c = getConnection().cursor()
        c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc")
        recordings = c.fetchall()
    except Exception as e:
        log('err #3114 Exception: %r' % e)
        pass
        recordings = []
    recordingsActive=[]

    for index in range(0, len(recordings)): 
        cat         = recordings[index][0]
        name        = recordings[index][1]
        startDate   = parseDate(recordings[index][2]) + timedelta(seconds = startPadding+1)
        endDate     = parseDate(recordings[index][3]) - timedelta(seconds = endPadding+1)
        alarmname   = recordings[index][4]
        description = recordings[index][5]
        if not('Recursive:' in name) and not ('[COLOR blue]' in name):
            if ((endDate >= startD and startDate <= endD) or (endDate >= endD and startDate <= startD) or (endDate <= endD and startDate >= startD)):
                recordingsActive.append(cat)
    c.close()
    return recordingsActive

def getNextVOD():
    ### Only if no recording is started
    now = parseDate(datetime.now())
    try:
        c = getConnection().cursor()
        c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name like '[COLOR yellow]Started%' and end > ? ", [now])
        recordings = c.fetchall()
        if len(recordings) == 0:
            c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name like '[COLOR violet]%' and start >= ? ", [now])
            recordings = c.fetchall()
            recordings = sorted(recordings, key=itemgetter(2)) ### Sort by startdate
        else:
            recordings = []
    except Exception as e:
        log('err #3146 Exception: %r' % e)
        pass
        recordings = []
    recordingsActive=[]

    for index in range(0, len(recordings)): 
        cat         = recordings[index][0]
        name        = recordings[index][1]
        startDate   = recordings[index][2]
        endDate     = recordings[index][3]
        alarmname   = recordings[index][4]
        description = recordings[index][5]
        recordingsActive.append([cat, name, startDate, endDate, alarmname, description])
    c.close()
    return recordingsActive

def getRecordingsActiveNoOrange(startD,endD):
    try:
        startPadding = 60 * int(definition.ADDONgetSetting('TimeBefore')) + 1
        endPadding   = 60 * int(definition.ADDONgetSetting('TimeAfter')) + 1
    except Exception as e:
        log('err #3167 Exception: %r' % e)
        startPadding = 60 * 3
        endPadding   = 60 * 15
    startD = parseDate(startD)
    endD = parseDate(endD)
    startD = startD + timedelta(seconds = startPadding)
    endD = endD - timedelta(seconds = endPadding)
    if endD < startD:
        endD = startD
    try:
        c = getConnection().cursor()
        c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc")
        recordings = c.fetchall()
    except Exception as e:
        log('err #3181 Exception: %r' % e)
        pass
        recordings = []
    recordingsActive=[]

    for index in range(0, len(recordings)): 
        cat         = recordings[index][0]
        name        = recordings[index][1]
        startDate   = parseDate(recordings[index][2]) + timedelta(seconds = startPadding+1)
        endDate     = parseDate(recordings[index][3]) - timedelta(seconds = endPadding+1)
        alarmname   = recordings[index][4]
        description = recordings[index][5]
        if not('Recursive:' in name) and not ('[COLOR blue]' in name) and not ('[COLOR orange]' in name ) and not ('[COLOR violet]' in name ) and not ('[COLOR green]Complete ' in name) and directprograms(cat) == '':  ### 2017-09-21/2018-11-25
            if ((endDate >= startD and startDate <= endD) or (endDate >= endD and startDate <= startD) or (endDate <= endD and startDate >= startD)):
                recordingsActive.append(name)
    c.close()
    return recordingsActive
    
def getRecordingsConcurrent(startD,endD):
    try:
        startPadding = 60 * int(definition.ADDONgetSetting('TimeBefore')) + 1
        endPadding   = 60 * int(definition.ADDONgetSetting('TimeAfter')) + 1
    except Exception as e:
        log('err #3204 Exception: %r' % e)
        pass
        startPadding = 60 * 3
        endPadding   = 60 * 15
    startD = parseDate(startD)
    endD = parseDate(endD)
    startD = startD + timedelta(seconds = startPadding) * 2
    endD = endD - timedelta(seconds = endPadding) * 2
    if endD < startD:
        endD = startD
    try:
        c = getConnection().cursor()
        c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc")
        recordings = c.fetchall()
    except Exception as e:
        log('err #3219 Exception: %r' % e)
        pass
        recordings = []
    recordingsActive=[]

    for index in range(0, len(recordings)): 
        cat         = recordings[index][0]
        name        = recordings[index][1]
        startDate   = parseDate(recordings[index][2]) + timedelta(seconds = startPadding+1)
        endDate     = parseDate(recordings[index][3]) - timedelta(seconds = endPadding+1)
        alarmname   = recordings[index][4]
        description = recordings[index][5]
        if not('Recursive:' in name) and not ('[COLOR blue]' in name) and not ('[COLOR orange]' in name): 
            if ((endDate >= startD and startDate <= endD) or (endDate >= endD and startDate <= startD) or (endDate <= endD and startDate >= startD)):
                recordingsActive.append(name)
    c.close()
    return recordingsActive

def add(cat, startDate, endDate, recordname, description):
    log('err add(cat= %r, startDate= %r, endDate= %r, recordname= %r, description= %r)' %(cat, startDate, endDate, recordname, description))
    now = datetime.now()
    if startDate == '' and endDate == '':
        startDate = now
        endDate = now + timedelta(hours=4)
    startDate = parseDate(startDate)
    endDate = parseDate(endDate)
    now = parseDate(now)
    if startDate < now and not 'Recursive:' in recordname:
        log('err Dont accept add of recordings, when late')
        return
    if 'Complete' in recordname:
        log('err Dont accept schedule of Completed recordings, when late')
        return   
    if 'Restarted' in recordname:
        log('Dont accept schedule of Restarted recordings, when late')
        return  
    log('err add(startDate= %r, endDate= %r)' %(startDate, endDate))
    marker = 'BbBb'  ### Allow change of cat
    if marker in recordname:
        recordname = recordname.replace(marker,'')
        ### Change cat
        oldcat = cat
        epg_channel = EPG_ChannelFromCat(cat)
        log('err EPG_ChannelFromCat(cat= %r)= %r' % (cat, epg_channel))
        if epg_channel == '':
            if cat[0:3] == 'DIR':
                epg_channel = '%'+cat[4:].split(' ')[0]+'%'
            else:
                ###epg_channel = '%'+cat.split(' ')[0]+'%'
                epg_channel = '%.%'   ### 2021-04-26 Any channel with EPG
            log('err epg_channel like recordingsSelected= %r' % epg_channel)
        if epg_channel != '':
            mychannels = getAllChannelsList0(epg_channel)   ### id, title, EPG
            if len(mychannels) > 1:
                
                recursiveChannels = RecursiveChannels()
    
                mychannellist = []
                for cpair in mychannels:
                    if cpair[0] in recursiveChannels:
                        mychannellist.append(cpair[1] + ' (' + cpair[0] + ') EPG= '+ cpair[2]+ ' Recursive')
                    else:
                        mychannellist.append(cpair[1] + ' (' + cpair[0] + ') EPG= '+ cpair[2])
                originalchannel = titleFromCat(cat) + ' (' + cat + ')'
                originalchannelidx = 0
                for y in range(0, len(mychannellist)):
                    if originalchannel in mychannellist[y]:  ### Find first entry with match
                        originalchannelidx = y
                        break
                log('add originalchannel= %r' % originalchannel)
                log('add mychannellist= %r' % mychannellist)
                SelectedChannel = xbmcgui.Dialog().select('New Channel for ' + originalchannel, mychannellist, preselect = originalchannelidx)
                log( 'SelectedChannelNo= %r' % SelectedChannel)
                if SelectedChannel >= 0:
                    try:
                        log( 'try SelectedChannel= %r' % mychannellist[SelectedChannel])
                        newcat = mychannellist[SelectedChannel].split('(')[-1].split(')')[0].strip()
                        
                        log('Selected: ' + titleFromCat(newcat) + ' (' + newcat + ')')
                        cat = newcat
                        if cat != oldcat:
                            recordname = recordname.replace('AaAa','',1)  ### dont change dates if channel changed
                    except Exception as e:
                        log('err #3296 Exception: %r' % e)
                        pass
                        log( 'SelectedChannel FAILED Channel= %r \nERROR= %r' % (SelectedChannel,e))
    
    log('add(startDate= %r, endDate= %r)' %(startDate, endDate))
    if 'Recursive:' in recordname or directprograms(cat) != '':
        recordingsActive = []
    else:
        recordingsActive=getRecordingsActiveNoOrange(startDate, endDate)
    try:
        concurrentstreams = int(definition.ADDONgetSetting('concurrentstreams'))
    except Exception as e:
        log('err #3308 Exception: %r' % e)
        pass
        concurrentstreams = 1
    ### if not recordingsActive == []:
    log('errr %r\nlen(recordingsActive) %r >= %r concurrentstreams' % (recordingsActive, len(recordingsActive),concurrentstreams))
    if len(recordingsActive) >= concurrentstreams and concurrentstreams > 0:
        utils.notificationforced('[COLOR red]OVERLAPPING Recording NOT allowed:[/COLOR] %s' % recordingsActive[0])
    if 'Complete' in recordname:
        log('err Dont accept schedule of Completed recordings, when late')
        return
    if 'Restarted' in recordname:
        log('err Dont accept schedule of Restarted recordings, when late')
        return  
    if schedule(cat, startDate, endDate, recordname, description):
        utils.notification('Recording [COLOR red]set[/COLOR] for %s' % recordname)
    return

def schedule(cat, startDate, endDate, recordname, description, DB='default'):
    ###recordname = recordname.split('[')[0]### 2018-09-12  limmit size of recordname
    added = False
    log('err recordings.schedule DB= %r' % DB)
    log('err schedule(cat= %r, startDate= %r, endDate= %r, recordname= %r, description= %r, DB= %r' % (cat, startDate, endDate, recordname, description, DB))
    if description == None:
        description = 'None 1'
    recordPath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_path')))
    if recordPath == '':
        recordPath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_path_old')))
        ###log('err second read recordPath= %r Writable? %r' % (recordPath,utils.folderwritable(recordPath,module)))
    ###log('err recordPath= %r Writable? %r' % (recordPath,utils.folderwritable(recordPath,module)))
    if definition.ADDONgetSetting('enable_record')=='true' and not utils.folderwritable(recordPath,module):
        utils.notificationforced('Recording not possible [COLOR red]You must set the recording path writable![/COLOR] \nGoto Settings/Recording/Record Path and set that to a writable path')
        ###log('You must set the recording path writable!')
        ###log('err 3375 xbmcaddon.Addon(id=ADDONid).openSettings()')
        ###xbmcaddon.Addon(id=ADDONid).openSettings()   
    recordname = ' '.join(recordname.split())  ## Remove doublespaces etc
    log('err startDate= %r > endDate= %r - timedelta(minutes=1)= %r' % (startDate,endDate - timedelta(minutes=1),startDate > endDate - timedelta(minutes=1)))
    if startDate > endDate - timedelta(minutes=1) :
        startDate = datetime.now()
        endDate = datetime.now() + timedelta(hours=2) # missing time in schedule
    log('err schedule(cat= %r, startDate= %r, endDate= %r, recordname= %r, description= %r)' % ( cat,startDate,endDate,recordname,description))
    if cat[0:4].lower() == 'http':
        playchannel = 'VOD or from other Addon' ### 2019-01-06
    else:
        playchannel = EPG_ChannelFromCat(cat)  ### 2018-07-09
    originalduration = ''
    startDate = parseDate(startDate)
    endDate   = parseDate(endDate)
    durationstring = str(endDate - startDate).split(':')
    log('startDate= %r, endDate= %r, durationstring= %r' % (startDate,endDate,durationstring))
    if endDate > startDate and not 'day' in durationstring[0]:
        originalduration =  'Duration [' + durationstring[0] + ':' + durationstring[1] + ']. '
        log('err originalduration= %r' % originalduration)
    ###if not 'Duration [' in description and not ']. ' in description:
    if not ('Duration [' in description and ']. ' in description):  ### 2019-09-08
        description = originalduration + description
        log('err Added to description originalduration= %r' % originalduration)
    AdjustDates = False
    recordModified = False
    recordRescheduled = False
    recordRecursive = False
    recordInactive = False
    t = startDate - datetime.now()
    log('t= %r, t.days= %r' % (t,t.days))
    timeToRecording = (t.days * 86400) + t.seconds
    log('err timeToRecording= %r' % timeToRecording)
    log('err Dont accept schedule during reschedule, if they are late. Rescheduling= %r' % definition.ADDONgetSetting('rescheduling'))
    if (timeToRecording < 0) and not ('Recursive' in recordname):  ### 2019-01-06
        log('timeToRecording is negative: Dont accept schedule, if they are late')
        AdjustDates = True
        recordModified = True
        if 'Complete' in recordname:
            log('Dont accept schedule of Completed recordings, when late')
            return False
        if 'Restarted' in recordname:
            log('Dont accept schedule of Restarted recordings, when late')
            return  
        if definition.ADDONgetSetting('rescheduling').lower() == 'true' :
            log('Dont accept schedule during reschedule, if they are late')
            return False ## Dont accept schedule during reschedule, if they are late
    if 'Complete' in recordname:
        log('Dont accept schedule of Completed recordings')
        return False  
    if 'Restarted' in recordname:
        log('Dont accept schedule of Restarted recordings')
        return  
    now = parseDate(datetime.now()) ### 2018-09-05
    ###now = datetime.now()
    log('now= %r' % now)
    try:
        startPadding = 60 * int(definition.ADDONgetSetting('TimeBefore'))
        endPadding   = 60 * int(definition.ADDONgetSetting('TimeAfter'))
    except Exception as e:
        log('err #3399 Exception: %r' % e)
        pass
        startPadding = 60 * 3
        endPadding   = 60 * 15
    
    if ('CcCc' in recordname) and (timeToRecording < (startPadding * 2)):
        log('Dont accept schedule from TV Grab if they are late')
        return False ## Dont accept schedule from TV Grab if they are late
    recordname = recordname.replace('CcCc','',1)
    if ('AaAa' in recordname):
        AdjustDates = True
        recordModified = True
        if 'Modified' in recordname:
            recordname = recordname.replace('AaAa','',1)
        else:
            #recordname = recordname.replace('AaAa',' Modified',1)  # 2015-10-11 Don't add Modified to record name
            recordname = recordname.replace('AaAa','',1)
    if ('BbBb' in recordname):
        recordRescheduled = True
        AdjustDates = False
        
        if 'Rescheduled' in recordname:
            recordname = recordname.replace('BbBb','',1)
        else:
            #recordname = recordname.replace('BbBb',' Rescheduled',1)  # 2015-10-11 Don't put Rescheduled in recordname
            recordname = recordname.replace('BbBb','',1)
    if ('Recursive' in recordname):
        recordRecursive = True
        AdjustDates = False
        recordname = recordname.replace('AaAa','',1)
        recordname = recordname.replace('BbBb','',1)
        recordname = recordname.replace('Modified','',1)
        recordname = recordname.replace('Rescheduled','',1)
        recordname = recordname.replace('  ',' ')
    recordname = recordname.replace('[COLOR blue]','') # remove inactive marker
    recordname = recordname.replace('[COLOR green]','') # remove inactive marker
    recordname = recordname.replace('[COLOR orange]','*') # remove inactive marker
    recordname = recordname.replace('[COLOR red]','') # remove inactive marker
    recordname = recordname.replace('[/COLOR]','')
    if recordname == '':
        recordname = 'missing'
    ###log('recordname= ' + repr(recordname))
    if recordname[0][0] == '*':   # DISABLE RECORD
        recordInactive = True
        AdjustDates = False
        recordname = recordname.replace('*','',1)  # 'schedule *-->inactive'
        recordname = recordname.replace('AaAa','',1)
        recordname = recordname.replace('BbBb','',1)
        recordname = recordname.replace('Modified','',1)
        recordname = recordname.replace('Rescheduled','',1)
        recordname = recordname.replace('  ',' ')
    
    showNotification = True
    if timeToRecording < 0:
        showNotification = True
        timeToRecording  = 0
        startDate        = now
    else:
        if (not recordModified) and (not recordRescheduled) and (not recordRecursive) and (not recordInactive): 
            startDate = startDate - timedelta(seconds = startPadding)
        #modify startDate if necessary; it shouldn't be earlier that 'now'
        if startDate < now:
            startDate = now
    
    if (startDate == now or recordModified) and (not recordRescheduled) and (not recordRecursive) and (not recordInactive):
        AdjustDates = True
    if AdjustDates == True:
        startDate=AdjustDateTime(startDate,"Start")
    if (endDate <= startDate) and (not recordRecursive) and (not recordInactive):
        endDate = startDate + timedelta(seconds = endPadding)
        AdjustDates = True
    if AdjustDates == True:
        endDate=AdjustDateTime(endDate,"End")
    if (recordname == 'n a' or AdjustDates == True) and (not recordRescheduled) and (not recordInactive) or recordModified:
        if recordModified and recordRecursive:
            recordname='Recursive:' + NAMErecord(recordname.replace('Recursive:','',1).strip())
        else:
            recordname=NAMErecord(recordname)
    if recordModified:
        try:
            ### description = latin1_to_ascii(DescriptionRecord(description))
            description = DescriptionRecord(description)   ### 2019-09-08
        except Exception as e:
            log('err #3482 Exception: %r' % e)
            pass
            log('if recordModified ERROR %r' % e)
    t =  startDate - now
    timeToRecording = (t.days * 86400) + t.seconds     
    showNotification = True
    if timeToRecording < 0:
        timeToRecording  = 0
        startDate        = now
    ###nameAlarm = ADDONid +'-recording-%s-%s-%s' % (cat, startDate, latin1_to_ascii_force(recordname))
    nameAlarm = '-recording-%s-%s-%s' % (cat, startDate, latin1_to_ascii_force(recordname))
    nameAlarm = nameAlarm.replace(':','.').replace('/','').replace('[','').replace(']','').replace('&','.')
    nameAlarm = nameAlarm.replace(',','').replace('.','').replace(' ','').strip()
    ###nameAlarm = stringtoargument(nameAlarm)   ### Removed 2019-12-17
    duration = endDate - startDate
    ######log('duration is %s, if less than 3 minutes - no recording of %s with startDate= %s and endDate= %s' % (repr(duration),repr(recordname),repr(startDate),repr(endDate)))
    if (not recordRecursive) and duration < timedelta(0, 180): # Dont record if les than 3 minutes 2016-03-16
        ###log('duration is %s, is less than 3 minutes - no recording of %s with startDate= %s and endDate= %s' % (repr(duration),repr(recordname),repr(startDate),repr(endDate)))
        log('Dont record if les than 3 minutes')
        return False
    duration = (duration.days * 86400) + duration.seconds
    if (not recordModified) and (not recordRescheduled) and (not recordInactive):
        duration = duration + endPadding
    if recordRecursive or recordInactive:
        script         =  ''   #os.path.join(definition.ADDONgetAddonInfo('path'), 'findrecursiveX.py')
    else:
        if definition.ADDONgetSetting('recordusing')  == '0':
            script   = os.path.join(definition.ADDONgetAddonInfo('path'), 'record-rtmpdump.py')
        else:
            if 'Record from VOD' in description:   
                script   = os.path.join(definition.ADDONgetAddonInfo('path'), 'recorduriffmpeg.py')
                ### Parameters: uri, title, nameAlarm
            elif 'Record from AddOn' in description:   
                script   = os.path.join(definition.ADDONgetAddonInfo('path'), 'recorduriffmpeg.py')
                ### Parameters: uri, title, nameAlarm
            else:
                script   = os.path.join(definition.ADDONgetAddonInfo('path'), 'record-ffmpeg.py')
                ### Parameters: cat, startTime, endTime, duration, title, argv6, argv7, nameAlarm
    log('err script for recording= %r' % script)
    if (not recordModified) and (not recordRescheduled) and (not recordRecursive) and (not recordInactive):
        endDate = endDate + timedelta(seconds = endPadding)
    recordname = re.sub(',', '', recordname) 
    ###recordname = stringtoargument(recordname) 
    args     = stringtoargument(cat) + ',' + str(startDate) + ',' + str(endDate) + ',' + str(duration) + ',' + recordname + ',' + '60' + ',' + 'True'
    cmd     = ''
    if not(recordRecursive or recordInactive):
        args= args + ',' + nameAlarm + ',' + utils.base64b64encode(description)  ### 2020-02-02
        cmd = 'AlarmClock(%s,RunScript(%s,%s),%d,True)' % (nameAlarm, script, args, timeToRecording//60)  ### 2021-06-21
        ### setAlarm(nameAlarm, script, args, starttimedeltahms,options='')
        ### cmd = 'AlarmClock(%s,RunScript(%s,%s),%s,%s)' % (nameAlarm, script, args, starttimedelta, options)
    recordingsActive = []
    if recordRecursive or recordInactive:
        if recordRecursive:
            endDate = startDate
    else:
        recordingsActive=getRecordingsActive(startDate, endDate)
    ###recordname = latin1_to_ascii(recordname) ###
    if recordInactive:
        added = addRecordingPlanned(cat, startDate, endDate, '[COLOR orange]' + recordname + '[/COLOR]', '[COLOR orange]' + nameAlarm + '[/COLOR]', description, playchannel,DB)
        return False
    if recordRecursive:
        # Test if it exists before scheduling
        if isRecursiveRecord(cat,recordname):
            log('Test if it exists before scheduling - isRecursiveRecord(cat= %r,recordname= %r)' % (cat,recordname))
            return False
    unblock = directprograms(cat)
    if not unblock == '':
        # Handle scheduling of Direct Channel - Noblock
        if not cat in getRecordingsActiveAllCat(startDate, endDate):
            added = addRecordingPlanned(cat, startDate, endDate, recordname, nameAlarm, description, playchannel,DB)
            if not recordRescheduled:
                cancelAlarm(nameAlarm)
                ###xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
            else:
                if not recordRecursive:
                    utils.notificationforced('[COLOR lightgreen]Direct Channel Recording: [/COLOR] %s' % (playchannel + ': ' + recordname))
            setAlarm(nameAlarm, script, args, timeToRecording//60, options='silent')
            ###cmd= latin1_to_ascii(cmd)
            ###xbmc.executebuiltin(cmd)
            
        log('err Handle scheduling of Direct Channel - Noblock')
        return added
    for  RecordingActive in recordingsActive:
        if ('[COLOR orange]' in RecordingActive) and (recordname in RecordingActive):
            # 2016-03-13 utils.notification('[COLOR orange]Disabled Recording: [/COLOR] %s' % (str(RecordingActive)))
            log('[COLOR orange]Disabled Recording: [/COLOR] %r' % RecordingActive)
            return False
        if (not '[COLOR orange]' in RecordingActive) and (not recordRescheduled) and (not recordRecursive) : ### and 1 == 0 :  ### DISABLE 2019-07-22/2020-02-08
            try:
                log('err recordname= %r,RecordingActive= %r, cat= %r\ngetRecordingsActiveAllCat= %r'% (recordname, RecordingActive, cat,  getRecordingsActiveAllCat(startDate, endDate)))
                if not (recordname in RecordingActive and cat in getRecordingsActiveAllCat(startDate, endDate)) : ### 2017-03-18 mark program with same name in a new channel
                    log('err if not recordname= %r in RecordingActive= %r' % (recordname,RecordingActive))
                    delRecordingPlanned(cat, startDate, endDate, '[COLOR blue]' + recordname + '[/COLOR]')
                    log('err before added')
                    added = addRecordingPlanned(cat, startDate, endDate, '[COLOR blue]' + recordname + '[/COLOR]', '[COLOR blue]' + nameAlarm + '[/COLOR]', description, playchannel,DB)
                else:
                    log('err IGNORE if recordname= %r in RecordingActive= %r' % (recordname,RecordingActive))
                    added = False
                return added
            except Exception as e:
                log('err #3572 Exception: %r' % e)
                pass
                log('schedule: ERROR: %r' % e)  # Put in LOG
                return False
    #cancel alarm first just in case it already exists
    if not recordRescheduled:
        ###xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
        cancelAlarm(nameAlarm)
    setAlarm(nameAlarm, script, args, timeToRecording//60, options='silent')
    ###cmd= latin1_to_ascii(cmd)
    ###xbmc.executebuiltin(cmd)
    if recordRecursive:
        #cancel alarm first just in case it already exists
        if not recordRescheduled:
            ###xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
            cancelAlarm(nameAlarm)
    added = addRecordingPlanned(cat, startDate, endDate, recordname, nameAlarm, description, playchannel,DB)
    if ('Recursive:' not in recordname):
        utils.notificationforced('Recording [COLOR red]set[/COLOR] for %s' % recordname)
    return added

def EPGOnce():
    nameAlarmEPGonce = ADDONname +'updateepgonce' 
    scriptEPG   = os.path.join(definition.ADDONgetAddonInfo('path'), 'updateepg.py')
    ###cmdEPGonce = 'AlarmClock(%s,RunScript(%s,%s),00:00:00,silent)' % (nameAlarmEPGonce, scriptEPG, 'once')
    cmdEPGonce = 'AlarmClock(%s,RunScript(%s,%s),00:00:00,silent)' % (nameAlarmEPGonce, scriptEPG, 'once')
    setAlarm('updateepgonce', scriptEPG, 'once', '00:00:00', options='silent')
    ###xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmEPGonce)
    ###xbmc.executebuiltin(cmdEPGonce)
    log('err updateepgonce')
    log('err xbmc.executebuiltin(cmdEPGonce)= %r' % cmdEPGonce)

def reschedule():
    addAlarm('reschedule', 'Start', '', '00:00:00', 'options')   ### 2022-08-14
    backupSetupxml()
    definition.ADDONsetSetting('fixsetup','false')
    definition.ADDONsetSetting('rescheduling','true')
    backupDataBase()
    if definition.ADDONgetSetting('enable_record')=='true' or definition.ADDONgetSetting('record_display_path') != '' or definition.ADDONgetSetting('record_display_path') and ((definition.ADDONgetSetting('record_archive_path_enable') == 'true') or (definition.ADDONgetSetting('record_archiveb_path_enable') == 'true')) :
        logic = True
    else:
        logic= False
        
    logic = True    ### test 2023-08-19 - just do it!
        
    addAlarm('reschedule', 'Logic', '', '00:00:00', logic)
    if logic:
        args     = str('True')
        addAlarm('reschedule1', args, '', '00:00:00', logic)   ### 2022-08-14
        #script   = os.path.join(definition.ADDONgetAddonInfo('path'), 'findrecursivetimed.py')
        #scriptOnce   = os.path.join(definition.ADDONgetAddonInfo('path'), 'findrecursivetimedOnce.py')
        #scriptHour   = os.path.join(definition.ADDONgetAddonInfo('path'), 'findrecursivetimedHour.py')
        
        #nameAlarmRepeat = ADDONid+'-recording-recursive-repeat' 
        #cmdrepeat = 'AlarmClock(%s,RunScript(%s,%s),02:00:00,loop,silent)' % (nameAlarmRepeat, script, args)
        #xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmRepeat)
        # xbmc.executebuiltin(cmdrepeat)  # Active
        #nameAlarmRepeat = ADDONid+'-recording-recursive-once' 
        #cmdrepeat = 'AlarmClock(%s,RunScript(%s,%s),00:05:00,silent)' % (nameAlarmRepeat, scriptOnce, args)
        #xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmRepeat)
        #xbmc.executebuiltin(cmdrepeat)  # Active
        TVguide= utils.TVguide()
        
        prog = 'startrepeatprog.py'
        now= datetime.today().strftime('%H:%M:%S')
        now = now.split(':')
        nowhm = int(now[0]) * 60 + int(now[1])
        ###starttime = '07:00:00'.split(':')
        starttime = definition.ADDONgetSetting('epgimportstarttime').split(':')
        ###interval  = '08:00:00'
        interval  = definition.ADDONgetSetting('epgimportinterval')
        intervalh  = interval.split(':')
        starttimehm = int(starttime[0]) * 60 + int(starttime[1])
        intervalhm = int(intervalh[0]) * 60 + int(intervalh[1])
        ###log('interval= %r starttime= %r - now= %r' %(interval, starttime, now))
        i = 0
        while starttimehm < nowhm and i < 50:
            starttimehm += intervalhm
            i += 1
            ###log('interval= %r starttime= %r - now= %r' %(intervalhm, starttimehm, nowhm))
        starttimedelta = starttimehm - nowhm
        starttimedeltahms = str(starttimedelta//60) + ':' + str(starttimedelta%60) + ':00'
        intervalhms = interval.replace(':','h',1).replace(':','m',1)
        log('starttimedeltahms= %r starttime= %r - now= %r' %(starttimedeltahms, starttime, now))
        ###nameAlarmstartrepeatprog = ADDONname +'startrepeatprog' 
        scriptstartrepeatprog   = os.path.join(definition.ADDONgetAddonInfo('path'), prog)
        ###cmdstartrepeatprog = 'AlarmClock(%s,RunScript(%s,%s),%s,silent)' % (nameAlarmstartrepeatprog, scriptstartrepeatprog, intervalhms,starttimedeltahms)
        ###xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmstartrepeatprog)
        if definition.ADDONgetSetting('notifyduringepgupdate') == 'true':
            utils.notification('Start EPG import in '+starttimedeltahms.replace(':','h',1).replace(':','m',1) + 's')
        ###xbmc.executebuiltin(cmdstartrepeatprog) 
        setAlarm('startrepeatprog', scriptstartrepeatprog, intervalhms, starttimedeltahms,options='silent')
        ### setAlarm(nameAlarm, script, args, starttimedeltahms,options='')
        ### cmd = 'AlarmClock(%s,RunScript(%s,%s),%s,%s)' % (nameAlarm, script, args, starttimedelta, options)
        try:
            log('error Start EPG import in '+starttimedeltahms.replace(':','h',1).replace(':','m',1) + 's')
        except:
            pass
        ###log('err xbmc.executebuiltin(cmdstartrepeatprog)= %r' % cmdstartrepeatprog)
        ###nameAlarmEPG = ADDONname +'updateepg' 
        channels = getAllChannelsList()
        if definition.ADDONgetSetting('epgimportonstart').lower() == 'true' or len(channels) == 0:
            EPGOnce()
        ###cmdEPG = 'AlarmClock(%s,RunScript(%s,%s),08:10:00,loop,silent)' % (nameAlarmEPG, scriptEPG, 'hourly')
        ###xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmEPG) 
        ###xbmc.executebuiltin(cmdEPG)  # Active
        log('errYYY http-keep-alive.py')
        setAlarm('http-keep-alive-loop','http-keep-alive.py','loop','00:05:30','loop,silent')
        """
        nameAlarmKeep = ADDONname +'http-keep-alive' 
        scriptKeep   = os.path.join(definition.ADDONgetAddonInfo('path'), 'http-keep-alive.py')
        cmdKeep = 'AlarmClock(%s,RunScript(%s,%s),00:05:30,loop,silent)' % (nameAlarmKeep, scriptKeep, '')
        xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmKeep)
        xbmc.executebuiltin(cmdKeep)  # Active
        log('errYYY http-keep-alive.py')
        log('err xbmc.executebuiltin(cmdKeep)= %r' % cmdKeep)
        """
    if definition.ADDONgetSetting('enable_record')=='true' :
        logic1 = True
    else:
        logic1 = False
    logic1 = True  ### Just do it 2023-08-19
    addAlarm('reschedule', 'Logic1', '', '00:00:00', logic1)
    if logic1 :    
        nameAlarmRepeat = '-recording-recursive-hours' 
        addAlarm('reschedule2', nameAlarmRepeat, '', '00:00:00', 'options')   ### 2022-08-14
        cancelAlarm(nameAlarmRepeat)
        import findtvguidenotifications
        setAlarm(nameAlarmRepeat,'findtvguidenotificationstimed.py',args,'00:50:00','loop,silent')
        log('err Timers set[/COLOR] for TV Guide grab recordings reguarly')
        if definition.ADDONgetSetting('notifyduringepgupdate') == 'true':
            utils.notification('[COLOR green]Timers set[/COLOR] for TV Guide grab recordings reguarly')
        ##xbmc.executebuiltin("Container.Refresh")
        
        scriptTrig   = os.path.join(definition.ADDONgetAddonInfo('path'), 'TrigTVGuide.py')       
        try:
            TrigInterval = definition.ADDONgetSetting('startstopguideinterval')
        except Exception as e:
            log('err #3676 Exception: %r' % e)
            pass
            ###log( 'Trigger TV Guide interval failed! Guide= %s ERROR= %s' % (guide,repr(e)))
            TrigInterval = '01:00:00'
        
        for Guide in range(0, len(TVguide)):
            guide = TVguide[Guide][0]
            # Trigger Guide...
            try:
                cmdTrig = 'AlarmClock(%s,RunScript(%s,%s,%s),%s,loop,silent)' % (ADDONname +'TrigTVGuide'+guide, scriptTrig, guide,'ExtraParameter',TrigInterval)
                if not (TrigInterval == '00:00:00' or TrigInterval == '0'):
                    xbmc.executebuiltin(cmdTrig)  # Active
                    ###xbmc.executebuiltin("StopScript(" + guide + ")")  ### Stop Guide
                    ###xbmc.executebuiltin("RunAddon(" + guide + ")")    ### Start Guide
                    ###log( 'Trigger TV Guide= %s with interval %s' % (guide,TrigInterval))
                ###else:
                    
                    ###log( 'No Trigger TV Guide= %s' % (guide))
            except Exception as e:
                log('err #3695 Exception: %r' % e)
                pass
                ###log( 'Trigger TV Guide failed! Guide= %s ERROR= %s' % (guide,repr(e)))
        
        
        now = parseDate(datetime.now())
        recordings = getRecordings()
        if definition.ADDONgetSetting('notifyduringepgupdate') == 'true':
            utils.notification('[COLOR green]Rescheduling Recordings[/COLOR]',time=100000)
        lenrecordings = len(recordings)
        for index in range(0, lenrecordings): 
            cat       = recordings[index][0]
            name      = recordings[index][1]
            #startDate = parseDate(recordings[index][2])
            startDate = recordings[index][2]
            #endDate   = parseDate(recordings[index][3])
            endDate   = recordings[index][3]
            alarmname = recordings[index][4]
            description = recordings[index][5]
            addAlarm('reschedule', cat, index, '00:00:00', lenrecordings)
            try:
                if not ('Recursive:' in name) and not('[COLOR blue]' in name):
                    delRecordingPlanned(cat, startDate, endDate, name)
            except Exception as e:
                log('err #3719 Exception: %r' % e)
                pass
                log('delRecordingPlanned: FAILED(index= %r, cat= %r, startDate= %r, endDate= %r, name= %r)' %(index,cat,startDate,endDate,name))  # Put in LOG
            startDate = parseDate(startDate)
            endDate   = parseDate(endDate)
            if not('Recursive:' in name) or (startDate >= now):  ### Don't restart in the middle of a recording
                if '[COLOR orange]' in name:
                    schedule(cat,startDate,endDate,name+'BbBb',description)
                elif '[COLOR blue]' in name:
                    log('Blue recordings are not deleted')
                else:
                    schedule(cat,startDate,endDate,name+'BbBb',description)
    definition.ADDONsetSetting('rescheduling','false')
    addAlarm('reschedule', 'Ended', '', '00:00:00', 'options')   ### 2022-08-14

def Numeric(timeT,funk):
        dialog = xbmcgui.Dialog()
        keyboard=dialog.numeric(2, funk + ' Time To Record?',timeT)
        return keyboard

def NumericStart(timeD,funk):
        dialog = xbmcgui.Dialog()
        keyboard=dialog.numeric(1, funk + ' Date To Record?',timeD)
        return keyboard

def NAMErecord(recordName):
        search_entered = recordName
        keyboard = xbmc.Keyboard(search_entered, 'Please Enter Program Name')
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText()
            if search_entered == None:
                return False          
        return search_entered 
         
def DescriptionRecord(recordName):
        search_entered = recordName
        keyboard = xbmc.Keyboard(search_entered, 'Please Enter Programme Description')
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText()
            if search_entered == None:
                return False          
        return search_entered  

def AdjustDateTime(aDateTime,funk):
    startTime=aDateTime.strftime('%H:%M')
    aDateTime=NumericStart(aDateTime.strftime('%d/%m/%Y'),funk)
    startTime=Numeric(startTime,funk)
    startYear=int(aDateTime.split('/')[2])
    startMonth=int(aDateTime.split('/')[1])
    startDay=int(aDateTime.split('/')[0])
    startHour=int(startTime.split(':')[0])
    startMinute=int(startTime.split(':')[1])
    aDateTime=(startYear,startMonth,startDay,startHour,startMinute,0,0,0,-1)
    aDateTime=datetime(*aDateTime[0:6])
    return aDateTime

def safe_unicode(obj, *args):
    """ return the unicode representation of obj """
    try:
        return unicode(obj, *args)
    except UnicodeDecodeError:
        ascii_text = str(obj).encode('string_escape')
        return unicode(ascii_text)

def safe_str(obj):
    """ return the byte string representation of obj """
    try:
        return str(obj)
    except UnicodeEncodeError:
        return unicode(obj).encode('unicode_escape')

# ------------------------------------------------------------------------
# Sample code below to illustrate their usage

def write_unicode_to_file(filename, unicode_text):
    """
    Write unicode_text to filename in UTF-8 encoding.
    Parameter is expected to be unicode. But it will also tolerate byte string.
    """
    fp = file(filename,'wb')
    # workaround problem if caller gives byte string instead
    unicode_text = safe_unicode(unicode_text)
    utf8_text = unicode_text.encode('utf-8')
    fp.write(utf8_text)
    fp.close()


def _decodeHtmlEntities(string):
        """Decodes the HTML entities found in the string and returns the modified string.

        Both decimal (&#000;) and hexadecimal (&x00;) are supported as well as HTML entities,
        such as &aelig;

        Keyword arguments:
        string -- the string with HTML entities

        """
        if type(string) not in [str, unicode]:
            return string

        def substituteEntity(match):
            ent = match.group(3)
            if match.group(1) == "#":
                # decoding by number
                if match.group(2) == '':
                    # number is in decimal
                    return unichr(int(ent))
            elif match.group(2) == 'x':
                # number is in hex
                return unichr(int('0x' + ent, 16))
            else:
                # they were using a name
                cp = name2codepoint.get(ent)
                if cp:
                    return unichr(cp)
                else:
                    return match.group()

        entity_re = re.compile(r'&(#?)(x?)(\w+);')
        return entity_re.subn(substituteEntity, string)[0]


"""
latin1_to_ascii -- The UNICODE Hammer -- AKA "The Stupid American"

This takes a UNICODE string and replaces Latin-1 characters with
something equivalent in 7-bit ASCII. This returns a plain ASCII string. 
This function makes a best effort to convert Latin-1 characters into 
ASCII equivalents. It does not just strip out the Latin1 characters.
All characters in the standard 7-bit ASCII range are preserved. 
In the 8th bit range all the Latin-1 accented letters are converted to 
unaccented equivalents. Most symbol characters are converted to 
something meaningful. Anything not converted is deleted.

Background:

One of my clients gets address data from Europe, but most of their systems 
cannot handle Latin-1 characters. With all due respect to the umlaut,
scharfes s, cedilla, and all the other fine accented characters of Europe, 
all I needed to do was to prepare addresses for a shipping system.
After getting headaches trying to deal with this problem using Python's 
built-in UNICODE support I gave up and decided to use some brute force.
This function converts all accented letters to their unaccented equivalents. 
I realize this is dirty, but for my purposes the mail gets delivered.


#!/usr/bin/env python
# -*- coding: utf-8 -*-

u = 'idzie wąż wąską dróżką'
uu = u.decode('utf8')
s = uu.encode('cp1250')
print(s)
"""

import re, html.entities

##
# Removes HTML or XML character references and entities from a text string.
#
# @param text The HTML (or XML) source text.
# @return The plain text, as a Unicode string, if necessary.

def unescape(text):
    def fixup(m):
        text = m.group(0)
        if text[:2] == "&#":
            # character reference
            try:
                if text[:3] == "&#x":
                    return unichr(int(text[3:-1], 16))
                else:
                    return unichr(int(text[2:-1]))
            except ValueError:
                pass
        else:
            # named entity
            try:
                text = unichr(html.entities.name2codepoint[text[1:-1]])
            except KeyError:
                pass
        return text # leave as is
    return re.sub("&#?\w+;", fixup, text)

def latin1_to_ascii (unicrap):
    """This takes a UNICODE string and replaces Latin-1 characters with
        something equivalent in 7-bit ASCII. It returns a plain ASCII string. 
        This function makes a best effort to convert Latin-1 characters into 
        ASCII equivalents. It does not just strip out the Latin-1 characters.
        All characters in the standard 7-bit ASCII range are preserved. 
        In the 8th bit range all the Latin-1 accented letters are converted 
        to unaccented equivalents. Most symbol characters are converted to 
        something meaningful. Anything not converted is deleted.
    """
    u = unicrap   ## TEST 2016-04-29 ###############################################################################################
    
    return u
    #return u ######################################
    if isinstance(u, unicode):
        #   uu = u.encode('utf-8')
        #else:
        #   uu = u
    #try:
        uu = u.encode('utf8')
    else:
        uu = u.encode('utf8', 'xmlcharrefreplace')
    #except Exception as e:
    #   uu = 'a' + u +'b'
    
    #try:
    ##s = uu.encode('ascii', 'xmlcharrefreplace')
    #except Exception as e:
    #   s = 'x' + u +'y'
    
    return uu ## TEST 2016-04-29 ###############################################################################################

def latin1_to_ascii_force(unitext):
    """
2020-02-02 13:43:56 default.py: l TEST i= 127, str(j)= '\x7f'=, unicrap(j)= '\x7f'
2020-02-02 13:43:56 default.py: l TEST i= 128, str(j)= '\x80'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 129, str(j)= '\x81'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 130, str(j)= '\x82'=, unicrap(j)= 'Euro'
2020-02-02 13:43:56 default.py: l TEST i= 131, str(j)= '\x83'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 132, str(j)= '\x84'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 133, str(j)= '\x85'=, unicrap(j)= 'AA'
2020-02-02 13:43:56 default.py: l TEST i= 134, str(j)= '\x86'=, unicrap(j)= 'AE'
2020-02-02 13:43:56 default.py: l TEST i= 135, str(j)= '\x87'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 136, str(j)= '\x88'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 137, str(j)= '\x89'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 138, str(j)= '\x8a'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 139, str(j)= '\x8b'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 140, str(j)= '\x8c'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 141, str(j)= '\x8d'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 142, str(j)= '\x8e'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 143, str(j)= '\x8f'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 144, str(j)= '\x90'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 145, str(j)= '\x91'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 146, str(j)= '\x92'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 147, str(j)= '\x93'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 148, str(j)= '\x94'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 149, str(j)= '\x95'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 150, str(j)= '\x96'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 151, str(j)= '\x97'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 152, str(j)= '\x98'=, unicrap(j)= 'OE'
2020-02-02 13:43:56 default.py: l TEST i= 153, str(j)= '\x99'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 154, str(j)= '\x9a'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 155, str(j)= '\x9b'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 156, str(j)= '\x9c'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 157, str(j)= '\x9d'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 158, str(j)= '\x9e'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 159, str(j)= '\x9f'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 160, str(j)= '\xa0'= , unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 161, str(j)= '\xa1'=¡, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 162, str(j)= '\xa2'=¢, unicrap(j)= 'c'
2020-02-02 13:43:57 default.py: l TEST i= 163, str(j)= '\xa3'=£, unicrap(j)= 'L'
2020-02-02 13:43:57 default.py: l TEST i= 164, str(j)= '\xa4'=¤, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 165, str(j)= '\xa5'=¥, unicrap(j)= 'Y'
2020-02-02 13:43:57 default.py: l TEST i= 166, str(j)= '\xa6'=¦, unicrap(j)= ':'
2020-02-02 13:43:57 default.py: l TEST i= 167, str(j)= '\xa7'=§, unicrap(j)= 's'
2020-02-02 13:43:57 default.py: l TEST i= 168, str(j)= '\xa8'=¨, unicrap(j)= '..'
2020-02-02 13:43:57 default.py: l TEST i= 169, str(j)= '\xa9'=©, unicrap(j)= 'c'
2020-02-02 13:43:57 default.py: l TEST i= 170, str(j)= '\xaa'=ª, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 171, str(j)= '\xab'=«, unicrap(j)= '<<'
2020-02-02 13:43:57 default.py: l TEST i= 172, str(j)= '\xac'=¬, unicrap(j)= '-'
2020-02-02 13:43:57 default.py: l TEST i= 173, str(j)= '\xad'=­, unicrap(j)= '-'
2020-02-02 13:43:57 default.py: l TEST i= 174, str(j)= '\xae'=®, unicrap(j)= 'R'
2020-02-02 13:43:57 default.py: l TEST i= 175, str(j)= '\xaf'=¯, unicrap(j)= '_'
2020-02-02 13:43:57 default.py: l TEST i= 176, str(j)= '\xb0'=°, unicrap(j)= 'deg'
2020-02-02 13:43:57 default.py: l TEST i= 177, str(j)= '\xb1'=±, unicrap(j)= '+/-'
2020-02-02 13:43:57 default.py: l TEST i= 178, str(j)= '\xb2'=², unicrap(j)= '^2'
2020-02-02 13:43:57 default.py: l TEST i= 179, str(j)= '\xb3'=³, unicrap(j)= '^3'
2020-02-02 13:43:57 default.py: l TEST i= 180, str(j)= '\xb4'=´, unicrap(j)= "'"
2020-02-02 13:43:57 default.py: l TEST i= 181, str(j)= '\xb5'=µ, unicrap(j)= 'm'
2020-02-02 13:43:57 default.py: l TEST i= 182, str(j)= '\xb6'=¶, unicrap(j)= 'pi'
2020-02-02 13:43:57 default.py: l TEST i= 183, str(j)= '\xb7'=·, unicrap(j)= '*'
2020-02-02 13:43:57 default.py: l TEST i= 184, str(j)= '\xb8'=¸, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 185, str(j)= '\xb9'=¹, unicrap(j)= '^1'
2020-02-02 13:43:57 default.py: l TEST i= 186, str(j)= '\xba'=º, unicrap(j)= '^0'
2020-02-02 13:43:57 default.py: l TEST i= 187, str(j)= '\xbb'=», unicrap(j)= '>>'
2020-02-02 13:43:57 default.py: l TEST i= 188, str(j)= '\xbc'=¼, unicrap(j)= '1/4'
2020-02-02 13:43:57 default.py: l TEST i= 189, str(j)= '\xbd'=½, unicrap(j)= '1/2'
2020-02-02 13:43:57 default.py: l TEST i= 190, str(j)= '\xbe'=¾, unicrap(j)= '3/4'
2020-02-02 13:43:57 default.py: l TEST i= 191, str(j)= '\xbf'=¿, unicrap(j)= '?'
2020-02-02 13:43:57 default.py: l TEST i= 192, str(j)= '\xc0'=À, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 193, str(j)= '\xc1'=Á, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 194, str(j)= '\xc2'=Â, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 195, str(j)= '\xc3'=Ã, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 196, str(j)= '\xc4'=Ä, unicrap(j)= 'AA'
2020-02-02 13:43:57 default.py: l TEST i= 197, str(j)= '\xc5'=Å, unicrap(j)= 'AA'
2020-02-02 13:43:57 default.py: l TEST i= 198, str(j)= '\xc6'=Æ, unicrap(j)= 'AE'
2020-02-02 13:43:57 default.py: l TEST i= 199, str(j)= '\xc7'=Ç, unicrap(j)= 'C'
2020-02-02 13:43:57 default.py: l TEST i= 200, str(j)= '\xc8'=È, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 201, str(j)= '\xc9'=É, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 202, str(j)= '\xca'=Ê, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 203, str(j)= '\xcb'=Ë, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 204, str(j)= '\xcc'=Ì, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 205, str(j)= '\xcd'=Í, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 206, str(j)= '\xce'=Î, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 207, str(j)= '\xcf'=Ï, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 208, str(j)= '\xd0'=Ð, unicrap(j)= 'Th'
2020-02-02 13:43:57 default.py: l TEST i= 209, str(j)= '\xd1'=Ñ, unicrap(j)= 'N'
2020-02-02 13:43:57 default.py: l TEST i= 210, str(j)= '\xd2'=Ò, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 211, str(j)= '\xd3'=Ó, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 212, str(j)= '\xd4'=Ô, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 213, str(j)= '\xd5'=Õ, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 214, str(j)= '\xd6'=Ö, unicrap(j)= 'OE'
2020-02-02 13:43:57 default.py: l TEST i= 215, str(j)= '\xd7'=×, unicrap(j)= '*'
2020-02-02 13:43:57 default.py: l TEST i= 216, str(j)= '\xd8'=Ø, unicrap(j)= 'OE'
2020-02-02 13:43:57 default.py: l TEST i= 217, str(j)= '\xd9'=Ù, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 218, str(j)= '\xda'=Ú, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 219, str(j)= '\xdb'=Û, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 220, str(j)= '\xdc'=Ü, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 221, str(j)= '\xdd'=Ý, unicrap(j)= 'Y'
2020-02-02 13:43:57 default.py: l TEST i= 222, str(j)= '\xde'=Þ, unicrap(j)= 'th'
2020-02-02 13:43:57 default.py: l TEST i= 223, str(j)= '\xdf'=ß, unicrap(j)= 'ss'
2020-02-02 13:43:57 default.py: l TEST i= 224, str(j)= '\xe0'=à, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 225, str(j)= '\xe1'=á, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 226, str(j)= '\xe2'=â, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 227, str(j)= '\xe3'=ã, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 228, str(j)= '\xe4'=ä, unicrap(j)= 'ae'
2020-02-02 13:43:57 default.py: l TEST i= 229, str(j)= '\xe5'=å, unicrap(j)= 'aa'
2020-02-02 13:43:57 default.py: l TEST i= 230, str(j)= '\xe6'=æ, unicrap(j)= 'ae'
2020-02-02 13:43:57 default.py: l TEST i= 231, str(j)= '\xe7'=ç, unicrap(j)= 'c'
2020-02-02 13:43:57 default.py: l TEST i= 232, str(j)= '\xe8'=è, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 233, str(j)= '\xe9'=é, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 234, str(j)= '\xea'=ê, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 235, str(j)= '\xeb'=ë, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 236, str(j)= '\xec'=ì, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 237, str(j)= '\xed'=í, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 238, str(j)= '\xee'=î, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 239, str(j)= '\xef'=ï, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 240, str(j)= '\xf0'=ð, unicrap(j)= 'th'
2020-02-02 13:43:57 default.py: l TEST i= 241, str(j)= '\xf1'=ñ, unicrap(j)= 'n'
2020-02-02 13:43:57 default.py: l TEST i= 242, str(j)= '\xf2'=ò, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 243, str(j)= '\xf3'=ó, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 244, str(j)= '\xf4'=ô, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 245, str(j)= '\xf5'=õ, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 246, str(j)= '\xf6'=ö, unicrap(j)= 'oe'
2020-02-02 13:43:57 default.py: l TEST i= 247, str(j)= '\xf7'=÷, unicrap(j)= '/'
2020-02-02 13:43:57 default.py: l TEST i= 248, str(j)= '\xf8'=ø, unicrap(j)= 'oe'
2020-02-02 13:43:57 default.py: l TEST i= 249, str(j)= '\xf9'=ù, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 250, str(j)= '\xfa'=ú, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 251, str(j)= '\xfb'=û, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 252, str(j)= '\xfc'=ü, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 253, str(j)= '\xfd'=ý, unicrap(j)= 'y'
2020-02-02 13:43:57 default.py: l TEST i= 254, str(j)= '\xfe'=þ, unicrap(j)= 'th'
2020-02-02 13:43:57 default.py: l TEST i= 255, str(j)= '\xff'=ÿ, unicrap(j)= 'y'
N\xc3\xa5r st\xc3\xb8vet har lagt sig
N      å r st      ø vet har lagt sig 
S\xc3\xb8ren Ryge pr\xc3\xa6senterer
S      ø ren Ryge pr      æ senterer 
    """
    xc3flag = False
    xlatec3={0x82:'Euro', 0x85:'AA', 0x86:'AE', 0x98:'OE', 
        0xa0:'',
        0xa1:'', 0xa2:'c', 0xa3:'L', 0xa4:'o',
        0xa5:'aa', 0xa6:'ae', 0xa7:'s', 0xa8:'..',
        0xa9:'c', 0xaa:'a', 0xab:'<<', 0xac:'-',
        0xad:'-', 0xae:'R', 0xaf:'_', 
        0xb0:'deg',
        0xb1:'+/-', 0xb2:'^2', 0xb3:'^3', 0xb4:"'",
        0xb5:'m', 0xb6:'oe', 0xb7:'*', 0xb8:'oe',
        0xb9:'^1', 0xba:'^0', 0xbb:'>>', 
        0xbc:'1/4', 0xbd:'1/2', 0xbe:'3/4', 0xbf:'?',
        0xc0:'A', 0xc1:'A', 0xc2:'A', 0xc3:'', 0xc4:'AA', 0xc5:'AA',
        0xc6:'AE', 0xc7:'C',
        0xc8:'E', 0xc9:'E', 0xca:'E', 0xcb:'E',
        0xcc:'I', 0xcd:'I', 0xce:'I', 0xcf:'I',
        0xd0:'Th', 0xd1:'N',
        0xd2:'O', 0xd3:'O', 0xd4:'O', 0xd5:'O', 0xd6:'OE', 
        0xd7:'*', 
        0xd8:'OE',
        0xd9:'U', 0xda:'U', 0xdb:'U', 0xdc:'U',
        0xdd:'Y', 0xde:'th', 0xdf:'ss',
        0xe0:'a', 0xe1:'a', 0xe2:'a', 0xe3:'a', 0xe4:'ae', 0xe5:'aa',
        0xe6:'ae', 0xe7:'c',
        0xe8:'e', 0xe9:'e', 0xea:'e', 0xeb:'e',
        0xec:'i', 0xed:'i', 0xee:'i', 0xef:'i',
        0xf0:'th', 0xf1:'n',
        0xf2:'o', 0xf3:'o', 0xf4:'o', 0xf5:'o', 0xf6:'oe', 0xf7:'/', 0xf8:'oe',
        0xf9:'u', 0xfa:'u', 0xfb:'u', 0xfc:'u',
        0xfd:'y', 0xfe:'th', 0xff:'y',
        }
    xlate={0x82:'Euro', 0x85:'AA', 0x86:'AE', 0x98:'OE', 
        0xa0:'',
        0xa1:'', 0xa2:'c', 0xa3:'L', 0xa4:'o',
        0xa5:'aa', 0xa6:':', 0xa7:'s', 0xa8:'..',
        0xa9:'c', 0xaa:'a', 0xab:'<<', 0xac:'-',
        0xad:'-', 0xae:'R', 0xaf:'_', 
        0xb0:'deg',
        0xb1:'+/-', 0xb2:'^2', 0xb3:'^3', 0xb4:"'",
        0xb5:'m', 0xb6:'pi', 0xb7:'*', 0xb8:'oe',
        0xb9:'^1', 0xba:'^0', 0xbb:'>>', 
        0xbc:'1/4', 0xbd:'1/2', 0xbe:'3/4', 0xbf:'?',
        0xc0:'A', 0xc1:'A', 0xc2:'A', 0xc3:'', 0xc4:'AA', 0xc5:'AA',
        0xc6:'AE', 0xc7:'C',
        0xc8:'E', 0xc9:'E', 0xca:'E', 0xcb:'E',
        0xcc:'I', 0xcd:'I', 0xce:'I', 0xcf:'I',
        0xd0:'Th', 0xd1:'N',
        0xd2:'O', 0xd3:'O', 0xd4:'O', 0xd5:'O', 0xd6:'OE', 
        0xd7:'*', 
        0xd8:'OE',
        0xd9:'U', 0xda:'U', 0xdb:'U', 0xdc:'U',
        0xdd:'Y', 0xde:'th', 0xdf:'ss',
        0xe0:'a', 0xe1:'a', 0xe2:'a', 0xe3:'a', 0xe4:'ae', 0xe5:'aa',
        0xe6:'ae', 0xe7:'c',
        0xe8:'e', 0xe9:'e', 0xea:'e', 0xeb:'e',
        0xec:'i', 0xed:'i', 0xee:'i', 0xef:'i',
        0xf0:'th', 0xf1:'n',
        0xf2:'o', 0xf3:'o', 0xf4:'o', 0xf5:'o', 0xf6:'oe', 0xf7:'/', 0xf8:'oe',
        0xf9:'u', 0xfa:'u', 0xfb:'u', 0xfc:'u',
        0xfd:'y', 0xfe:'th', 0xff:'y', 
        }
    r = ''
    unitext = unitext.replace('\xef\xbb\xbf','')   ### Remove: byte order mark (BOM)
    for i in unitext:
        if ord(i) == 0xc3:
            xc3flag = True
        else:
            if xc3flag == True:
                ###if xlatec3.has_key(ord(i)):
                if ord(i) in xlatec3:
                    r += xlatec3[ord(i)]
                elif ord(i) >= 0x80:
                    pass
                else:
                    r += str(i)
                xc3flag = False
            else:
                ###if xlate.has_key(ord(i)):
                if ord(i) in xlate:
                    r += xlate[ord(i)]
                elif ord(i) >= 0x80:
                    pass
                else:
                    r += str(i)
    return r

def latin1_to_ascii_forceOLD(unicrap):
    """This takes a UNICODE string and replaces Latin-1 characters with
        something equivalent in 7-bit ASCII. It returns a plain ASCII string. 
        This function makes a best effort to convert Latin-1 characters into 
        ASCII equivalents. It does not just strip out the Latin-1 characters.
        All characters in the standard 7-bit ASCII range are preserved. 
        In the 8th bit range all the Latin-1 accented letters are converted 
        to unaccented equivalents. Most symbol characters are converted to 
        something meaningful. Anything not converted is deleted.
    """ 
    
    xlate={0x82:'Euro', 0x85:'Aa', 0x86:'Ae', 0x98:'Oe', 0xc0:'A', 0xc1:'A', 0xc2:'', 0xc3:'', 0xc4:'A', 0xc5:'A',
        0xc6:'Ae', 0xc7:'C',
        0xc8:'E', 0xc9:'E', 0xca:'E', 0xcb:'E',
        0xcc:'I', 0xcd:'I', 0xce:'I', 0xcf:'I',
        0xd0:'Th', 0xd1:'N',
        0xd2:'O', 0xd3:'O', 0xd4:'O', 0xd5:'O', 0xd6:'O', 0xd7:'x', 0xd8:'O',
        0xd9:'U', 0xda:'U', 0xdb:'U', 0xdc:'U',
        0xdd:'Y', 0xde:'th', 0xdf:'ss',
        0xe0:'a', 0xe1:'a', 0xe3:'a', 0xe4:'a', 0xe5:'a',
        0xe6:'ae', 0xe7:'.0xe7.',
        0xe8:'e', 0xe9:'e', 0xea:'e', 0xeb:'e',
        0xec:'i', 0xed:'i', 0xee:'i', 0xef:'i',
        0xf0:'th', 0xf1:'n',
        0xf2:'o', 0xf3:'o', 0xf4:'o', 0xf5:'o', 0xf6:'o', 0xf8:'o',
        0xf9:'u', 0xfa:'u', 0xfb:'u', 0xfc:'u',
        0xfd:'y', 0xfe:'th', 0xff:'y',0xa0:'a',
        0xa1:'a', 0xa2:'.0xa2.', 0xa3:'', 0xa4:'a',
        0xa5:'aa', 0xa6:'ae', 0xa7:'s', 0xa8:'u',
        0xa9:'e', 0xaa:'e', 0xab:'<<', 0xac:'',
        0xad:'-', 0xae:'R', 0xaf:'_', 0xb0:'d',
        0xb1:'+/-', 0xb2:'^2', 0xb3:'^3', 0xb4:"'",
        0xb5:'m', 0xb6:'o', 0xb7:'*', 0xb8:'oe',
        0xb9:'^1', 0xba:'^o', 0xbb:'>>', 
        0xbc:'u', 0xbd:'1/2', 0xbe:'3/4', 0xbf:'?',
        0xd7:'*', 0xf7:'/'
        }
    r = ''
    for i in unicrap:
        if ord(i) in xlate:
            r += xlate[ord(i)]
        elif ord(i) >= 0x80:
            pass
        else:
            r += str(i)
    
    return r

def imageUrlicon(imageUrl,cat,ext):
    #print 'recordings.py imageUrlicon(imageUrl,cat,ext)'
    iurl=icon(cat)
    #print repr(iurl)
    if iurl == '':
        return imageUrl + 'ntvlogo' + ext
    #print iurl.lower()[0] 
    if iurl.lower()[0] =='h':
        return iurl
    else:
        return imageUrl + 'ntvlogo' + ext

def icon(oldicon):
    #print repr(definition.ADDONgetSetting('Use2014Icons').lower())
    #print repr('true')
    if not definition.ADDONgetSetting('Use2014Icons').lower()=='true':
        return oldicon
    #print 'Exchange DR1(183->147) with DR1 HD(508->413) Krogsbell 2014-12-20
    
    """"
    Icons found with this lookup: Krogsbell 2015-02-15
    http://www.ntv.mx/res/content/tv/<no>.png
    2   Itv
    3   Itv 2
    4   BBC ONE
    5   BBC TWO
    7   SKY 1
    8   SKY Movies Action & Adventure
    9   SKY Comedy
    10  SKY Movies Sci Fi & Horror
    11  SKY Movies Sci Fi & Horror
    12  SKY Sports 1
    13  SKY Sports 3
    14  SKY Sports F1
    15  ESPN
    17  SKY News
    26  SKY Movies Drama & Romance
    27  SKY Movies Family
    29  SKY Movies Modern Great
    30  SKY Movies Premiere
    33  SKY Movies Showcase
    39  SKY Sports 2
    40  SKY 2
    43  Animal Planet   310 + 55 *
    44  Discovery Channel   56 + 306 *
    51  SKY Sports 4
    52  SKY Sports News
    54  FOX News
    56  National Geographic Channel
    57  SKY Movies Chrime & Thriller
    59  Itv 4
    60  Five
    61  5USA
    63  Movies4men
    64  Aljazeera
    65  4 (build of sticks)
    79  Gold (in a circle)
    80  Y Yesterday
    81  MTV
    82  VHR 71
    83  VIVA    72
    84  Alibi
    93  SKY Movies Select
    94  SKY Atlantic
    96  Discovery History   78 *
    97  Sc Discovery Science    79 *
    99  Discovery Home & Health 80 *
    100 Eden
    101 Comedy Channel
    102 Fox
    106 4E (E within 4)
    108 4More
    123 TCM Turner Classic Movies
    125 5*
    126 4Film   109 *
    135 NickJR
    137 Nickelodeon
    138 N TV Norge  100 *
    139 2 Bliss
    141 STV 1   91 *
    142 STV 2   104*
    143 4 Guld (in a star)  105 *
    146 2 Filmkanalen
    153 2
    157 4 Sport 119 *
    159 TV2 Lorry
    164 BBC News
    167 NRK 1   127 *
    168 NRK 2   128 *
    169 NRK 3   129 *
    170 3   140 + 141
    171 3 Puls Viasat
    175 3 tv3.se
    177 6 in circle
    179 4 in quadrant   125 *
    183 DR1 147 *
    184 DR2 148 *
    187 TV2 zulu *
    188 TV2 charlie *
    192 Dave
    197 At The Races
    198 Racing UK   Pure Racing Entertainment
    199 BT Sport1
    201 BT Sport2
    202 Box Nation
    204 TLC
    207 SETANTA IRELAND
    208 SETANTA SPORTS
    209 Aljazeera +6
    210 Aljazeera +7
    211 Aljazeera +8
    212 Aljazeera +9
    213 Aljazeera +5
    214 Bein Sports 1
    215 Bein Sports 2
    216 Bein Sports 3
    217 Bein Sports 4
    218 Bein Sports 10
    219 H History UK
    224 Virgin
    241 TNT HD
    252 RT Russia Today
    273 Gulli
    282 DR K    230 *
    283 DR Ultra    231 *
    286 6 on blue background
    290 H2
    291 DBC Drama
    292 Pick TV
    294 Euronews
    295 BBC News
    296 Cartoonito
    297 SKY Arts 2
    298 SKY Movies Disney
    299 Itv 3+1
    303 SKY Arts 1
    304 SKY Living
    305 Good Food
    309 TV2 Fri 261 *
    310 3+ Viasat   262 *
    315 FEM
    316 SKY Sports 1 HD
    317 SKY Sports 2 HD
    318 SKY Sports 4 HD
    319 SKY Sports News HD
    320 SKY Sports 3 HD
    321 SKY Sports F1 HD
    330 OSN Sports 3
    331 OSN Sports 4
    333 Fox Sports 1 HD
    336 TSN 2 HD
    337 Sports Net World HD
    339 Sports Net One HD
    340 Bein Sport HD
    341 CTV HD
    341 HBO HD
    343 NBA  TV High Definition
    344 NBC & N HD
    http://www.ntv.mx/res/content/tv/400.png
    http://www.ntv.mx/res/content/tv/478.png
    115 http://cloud.yousee.tv/static/img/logos/Large_TV2_ny.png
    136 http://cloud.yousee.tv/static/img/logos/Large_TV2_NEWS.png
    259 http://cloud.yousee.tv/static/img/logos/Large_DR_3.png
    249     http://cloud.yousee.tv/static/img/logos/IK_dk4.png
    """
    iconold =['71','72','115','136','259','249','99','303','412','245','267','298','227','141','125','127','128','129','119','105','104','91','100','109','78','79','80','306','56','55','310','115','235','140','240','138','231','131','230','261','137','148','262','147','413']
    iconnew=['82','83','a','b','c','d','139','204','141','56','315','44','44','170','179','167','168','169','157','143','142','141','138','126','96','97','99','44','44','43','43','155','287','170','294','187','283','171','282','309','188','184','310','183','183']
    i = 0
    r = ''
    while i < len(iconold) and r =='':
        if oldicon==iconold[i]:
            r = iconnew[i]
        i += 1
    #print r
    #r = ''
    #for i in oldicon:
    #   if xlate.has_key(str(i)):
    #       r += xlate[str(i)]
    #       print 'recordings.py icon(oldicon) %s--> icon= %s' %(str(repr(oldicon)),str(repr(r)))
    if r=='':
        r = ''
    elif r=='a':
        return 'http://cloud.yousee.tv/static/img/logos/Large_TV2_ny.png'
    elif r=='b':
        return 'http://cloud.yousee.tv/static/img/logos/Large_TV2_NEWS.png'
    elif r=='c':
        return 'http://cloud.yousee.tv/static/img/logos/Large_DR_3.png'
    elif r=='d':
        return 'http://cloud.yousee.tv/static/img/logos/IK_dk4.png'
    #   else:
    #       r += str(i)
    #print 'recordings.py icon(oldicon) %s--> icon= %s' %(str(repr(oldicon)),str(repr(r)))
    return r
    
def stringtoargument(txtstring):
    return txtstring
    txtstring= txtstring.replace('\n','..NewLine..').replace(',','..Comma..').replace(' ','AAabBB').replace('?','aAabBb').replace('=','BBabAA').replace(',','###').replace('&','AaAaA').replace('\n','NlNlNl')
    return txtstring
    
def argumenttostring(txtstring):
    return txtstring
    txtstring= txtstring.replace('..NewLine..','\n').replace('..Comma..',',').replace('AAabBB',' ').replace('aAabBb','?').replace('BBabAA','=').replace('###',',').replace('AaAaA','&').replace('NlNlNl','\n')
    return txtstring

def addRecordingPlanned(cat, startDate, endDate, recordname, alarmname, description, playchannel, DB='default',uri='url'):
    log('err addRecordingPlanned(cat= %r, startDate= %r, endDate= %r, recordname= %r, alarmname= %r, playchannel= %r, DB= %r,uri= %r)' % (cat, startDate, endDate, recordname, alarmname, playchannel, DB, uri))
    added = False
    if type(cat) in [str] and '&' in cat and 1==0:   ###2020-02-25 keep all commands (1==0)
        cat = cat.split('&')[0]    ### Remove trailing commands from url in cat if & in cat 2020-01-29
    startDate = parseDate(startDate).replace(second=0, microsecond=0)  ### 2021-02-18
    endDate   = parseDate(endDate).replace(second=0, microsecond=0)
    ###startDate = parseDate(startDate)
    ###endDate   = parseDate(endDate)
    log('err addRecordingPlanned(cat= %r, startDate= %r, endDate= %r)' % (cat, startDate, endDate))
    if endDate < startDate:
        endDate = startDate  
    log('err addRecordingPlanned DB= %r' % DB)
    if cat:
        if playchannel == cat:
            playchannel = EPG_ChannelFromCat(cat)  ### 2018-07-09
        if playchannel == '' and 'http' == cat.lower()[4:]:
            playchannel = 'VOD'
    if DB == 'default':
        log('err addRecordingPlanned using default database')
        conn      = getConnection()
        conn.text_factory = str  ### 2016-04-30 TEST
        c         = conn.cursor()
    else:
        c = DB
    log('err addRecordingPlanned(cat= %r, startDate= %r, endDate= %r, recordname= %r, alarmname= %r, description= %r, playchannel= %r)' % (cat, startDate, endDate, recordname, alarmname, description, playchannel))
    try:
        c.execute("INSERT OR REPLACE INTO recordings_adc(cat, name, start, end, alarmname, description, playchannel) VALUES(?, ?, ?, ?, ?, ?, ?)", [cat, recordname, str(startDate), str(endDate), alarmname, description, playchannel])
        added = True
    except Exception as e:
        log('err #4440 Exception: %r' % e)
        pass
        log('err addRecordingPlanned FAILED cat= %r ERROR= %r' % (cat,e))
    if DB == 'default':
        conn.commit()
        c.close()
    return added

def updateRecordingPlanned(alarmname, name, newdescription=''):
    #print 'recordings.py updateRecordingPlanned(alarmname= %s, name= %s)' %(repr(alarmname), repr(name))
    try:
        conn = getConnection()
        c    = conn.cursor()
        c4   = c.execute("SELECT * FROM recordings_adc WHERE alarmname=?",  [alarmname])
        recordingsSelected = c4.fetchall()
        if len(recordingsSelected) > 0:
            for index in range(0, len(recordingsSelected)): 
                cat       = recordingsSelected[index][0]
                nameOLD      = recordingsSelected[index][1]
                startDate = recordingsSelected[index][2].split('.')[0]  ###207-09-30
                ###endDate   = recordingsSelected[index][3].split('.')[0]  ###207-09-30
                now     = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                endDate = now    ### 2023-12-30
                alarmnameOLD = recordingsSelected[index][4]
                description = recordingsSelected[index][5]
                if newdescription != '':  ### 2018-12-26
                    newdescription += '\n\n' + description
                else:
                    newdescription = description
                playchannel = recordingsSelected[index][6]
                if playchannel == cat:
                    playchannel = EPG_ChannelFromCat(cat)  ### 2018-07-09
                c4.execute("DELETE FROM recordings_adc WHERE alarmname=?",  [alarmname])
                c4.execute("INSERT OR REPLACE INTO recordings_adc(cat, name, start, end, alarmname, description, playchannel) VALUES(?, ?, ?, ?, ?, ?, ?)", [cat, name, startDate, endDate, alarmname, newdescription, playchannel])
        conn.commit()
    except Exception as e:
        log('err #4474 Exception: %r' % e)
        pass
        log('Exception updateRecordingPlanned error= %r' % e)
    c.close()
    xbmc.executebuiltin("Container.Refresh")

def delRecordingPlanned(cat, startDate, endDate, recordname):
    try:
        startDate = startDate.split('.')[0]
        endDate = endDate.split('.')[0]
    except Exception as e:
        log('err #4485 Exception: %r' % e)
        pass
        log('Exception Date.split error= %r' % e)
    log('err delRecordingPlanned(cat= %r, startDate= %r, endDate= %r, recordname= %r)' % (cat, startDate, endDate, recordname))
    ### recordings_adc(cat, name, start, end, alarmname, description, playchannel)
    conn = getConnection()
    c    = conn.cursor()
    c4=c.execute("SELECT * FROM recordings_adc WHERE cat=? AND name=? AND start=? AND end=?", [cat, recordname, startDate, endDate])
    ###c4=c.execute("SELECT * FROM recordings_adc WHERE cat=? AND name=? AND start=?", [cat, recordname, startDate])
    recordingsSelected = c4.fetchall()
    log('err delRecordingPlanned(len(recordingsSelected= %r))' % (len(recordingsSelected)))
    for index in range(0, len(recordingsSelected)): 
        #cat       = recordingsSelected[index][0]
        name       = recordingsSelected[index][1]
        #startDate = recordingsSelected[index][2]
        endDateXX  = recordingsSelected[index][3]
        
        alarmname = recordingsSelected[index][4]
        Recordings = definition.ADDONgetSetting('Recordings').replace(alarmname,'')
        definition.ADDONresetSetting('Recordings',Recordings)
        log('DELETE FROM recordings_adc WHERE alarmname= %r and end= %r' % (alarmname,endDateXX))
        now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        ###xbmcgui.Dialog().ok(ADDONname, 'startDate= %r' % startDate, 'now= %r' % now)
        RECURSIVEMARKER = 'Recursive:'
        LastView = definition.ADDONgetSetting('LastView')  ###, 'RECORDINGSPLANNED')
        if startDate > now or (RECURSIVEMARKER in recordname and LastView=='RECORDINGSPLANNED'):  ### 2019-01-11 
            c4.execute("DELETE FROM recordings_adc WHERE alarmname=? and end=?",  [alarmname,endDateXX]) ### 2018-09-04 delete only future programs
        cancelAlarm(alarmname)
        ###xbmc.executebuiltin('CancelAlarm(%s,True)' % alarmname)
    conn.commit()   
    c.close()

def modifyRecordingPlanned(cat, startDate, endDate, recordname, description):
    try:
        startDate = startDate.split('.')[0]
        endDate = endDate.split('.')[0]
    except Exception as e:
        log('err #4521 Exception: %r' % e)
        pass
    log('modifyRecordingPlanned (cat= %r, startDate= %r, endDate= %r, recordname= %r, description= %r)' % (cat, startDate, endDate, recordname, description))
    startDate = parseDate(startDate)
    endDate   = parseDate(endDate)
    conn      = getConnection()
    c         = conn.cursor()
    ###recordingsSelected = c.fetchall()   ###2020-04-07 
    ###for rec in recordingsSelected:
    ### utils.logdevarray('modifyRecordingPlanned-recordingsSelected', repr(rec[0]))
    dialog = xbmcgui.Dialog()
    log('cat recordingsSelected= %r' % cat)
    
    c1=c.execute("SELECT * FROM recordings_adc WHERE cat=? AND name=?", [cat,recordname])
    recordingsSelected = c1.fetchall()
    log('c1 recordingsSelected= %r' % recordingsSelected)
    
    ###for rec in recordingsSelected:
    ###    utils.logdevarray('modifyRecordingPlanned-recordingsSelected-3', repr(rec[0]))
    ##c2=c1.execute("SELECT * FROM recordings_adc WHERE name=?",  [unicode(recordname, 'utf-8')])
    ###c2=c1.execute("SELECT * FROM recordings_adc WHERE name=?",  [recordname])
    ###recordingsSelected = c2.fetchall()
    ###for rec in recordingsSelected:
    ### utils.logdevarray('modifyRecordingPlanned-recordingsSelected-2', repr(rec[0]))
    ###c3=c2.execute("SELECT * FROM recordings_adc WHERE start=?", [startDate])
    ###recordingsSelected = c3.fetchall()
    ###for rec in recordingsSelected:
    ### utils.logdevarray('modifyRecordingPlanned-recordingsSelected-3', repr(rec[0]))
    ###c4=c3.execute("SELECT * FROM recordings_adc WHERE end=?", [endDate])
    ###recordingsSelected = c4.fetchall()
    c4 = c1
    ###for rec in recordingsSelected:
    ###    utils.logdevarray('modifyRecordingPlanned-recordingsSelected-4', repr(rec[0]))

    for index in range(0, len(recordingsSelected)): 
        cat         = recordingsSelected[index][0]
        name        = recordingsSelected[index][1]
        ###if TVguideNR == '0':  ##############################################################<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        startDateXX = parseDate(recordingsSelected[index][2])
        endDateXX   = parseDate(recordingsSelected[index][3])
        alarmname   = recordingsSelected[index][4]
        description = recordingsSelected[index][5]
        ### else:
        ###     startDateXX = parseDate(recordingsSelected[index][2])
        ###     endDateXX   = parseDate(recordingsSelected[index][3])
        ###     alarmname   = recordingsSelected[index][4]
        ###     description = recordingsSelected[index][5]
        ###log('cat= %r, name= %r, startDateXX= %r, endDateXX= %r, alarmname= %r, description= %r' % (cat, name, startDateXX, endDateXX, alarmname, description))
        
    if len(recordingsSelected) > 0:
        log('err name= %r, recordname= %r' % (name,recordname))
        ###recordname = unicode(name, 'utf-8')
        ###log('XXXXname= %r, recordname= %r' % (name,recordname))
        log('c4.execute(DELETE FROM recordings_adc WHERE alarmname= %r' % alarmname)
        
        try:
            cutoffdate = datetime.today().strftime("%Y-%m-%d %H:%M:%S")
            log('Modifyrecordingsplanned recordings_adc: cutoffdate= %r' % cutoffdate)
            c.execute("DELETE FROM recordings_adc WHERE alarmname=? and start>?", [alarmname,cutoffdate])  ### Only delete future recordings
        except Exception as e:
            log('err #4581 Exception: %r' % e)
            pass
            log( 'c.execute(DELETE FROM recordings_adc WHERE alarmname=? and start>?, [alarmname,cutoffdate]= %r) failed! \nERROR= %r' % (cutoffdate,e))
        
        ###c4.execute("DELETE FROM recordings_adc WHERE alarmname=?",  [alarmname])
        cancelAlarm(alarmname)
        ###xbmc.executebuiltin('CancelAlarm(%s,True)' % alarmname)
        try:
            conn.commit()
            
        except Exception as e:
            log('err #4591 Exception: %r' % e)
            pass
            
        c4.close()
        if '[COLOR orange]' in recordname:
            activatemarker = True
        else:
            activatemarker = False
        recordname = recordname.replace('[COLOR blue]','') # remove inactive marker
        recordname = recordname.replace('[COLOR green]','') # remove inactive marker
        recordname = recordname.replace('[COLOR orange]','') # remove inactive marker
        recordname = recordname.replace('[COLOR red]','') # remove inactive marker
        recordname = recordname.replace('[/COLOR]','')
        if not activatemarker:   # Just activate disabled recordings
            recordname += 'AaAa' # marker to force change of date
        recordname += 'BbBb' # marker to allow change of cat
        
        log('add(cat= %r, startDate= %r, endDate= %r, recordname= %r, description= %r)' % (cat, startDate, endDate, recordname, description))
        add(cat, startDate, endDate, recordname, description)
    else:
        ###dialog.ok(ADDONid + " Modify Recording planned [COLOR red]FAILED![/COLOR]", "Selected record? " + unicode(recordname, 'utf-8'),'', "How many selected: " + str(len(recordingsSelected)))
        dialog.ok('[B]' + ADDONname + '[/B]'+" Modify Recording planned [COLOR red]FAILED![/COLOR]","Selected record? " + recordname + "\nHow many selected: " + str(len(recordingsSelected)))
    try:
        conn.commit()
        
    except Exception as e:
        log('err #4616 Exception: %r' % e)
        pass
        
    c.close()

def ht(ts):    ### Timestamp to short human time
    if type(ts) != int:
        return ts
    dt = datetime.fromtimestamp(ts)
    ###ht = dt.strftime("%Y-%m-%d %H:%M:%S")
    ht = dt.strftime("%m-%d %H:%M")
    return ht
    
def humantime(ts):   ### Timestamp to human time
    try:
        ts = int(ts)
        dt = datetime.fromtimestamp(ts)
        ht = dt.strftime("%Y-%m-%d %H:%M:%S")
    except Exception as e:
        log('err #4635 Exception: %r' % e)
        pass
        log('humantime(ts= %r) Error: %r' % (ts,e))
        ht = ts
    return ht

def humantimefraction(ts):   ### Timestamp to human time
    try:
        dt = datetime.fromtimestamp(ts)
        ht = dt.strftime("%Y-%m-%d %H:%M:%S.%f")
    except Exception as e:
        log('err #4635 Exception: %r' % e)
        pass
        log('humantime(ts= %r) Error: %r' % (ts,e))
        ht = ts
    return ht

def humantimestop(dt):   ### datetime to human time with microseconds
    ###dt = datetime.fromtimestamp(ts)
    ###htms = dt.strftime("%f")[:3]
    ###ht = dt.strftime("%Y-%m-%d %H:%M:%S") + ',' + htms
    ht = dt.strftime("%H:%M:%S") ###+ ',' + htms
    return ht

def dt(ts):   ### DateTime from Timestamp
    if type(ts) != int:
        return ts
    dt = datetime.fromtimestamp(ts)
    return dt
    
def ts(ds):   ### Date string to timestamp
    if type(ds) != str:
        return ds
    ###ds = "2008-11-10 17:53:59"
    time_tuple = time.strptime(ds, "%Y-%m-%d %H:%M:%S")
    ###time_tuple = (2008, 11, 12, 13, 59, 27, 2, 317, 0)
    ts = int(time.mktime(time_tuple))
    return ts
    
def finddoubletes():
    findanddeleteoverlappingepg = definition.ADDONgetSetting('findanddeleteoverlappingepg')
    updateplanedrecordings = definition.ADDONgetSetting('updateplanedrecordings')
    deleteddublets = 0
    dublets = 0
    updatedrecordings = 0
    if findanddeleteoverlappingepg == 'true':
        try:
            ### find dublette programs, find the newest update any programmings and then delete the oldest program
            log('5115 errorX finddoubletes() started')
            now = datetime.now()
            nowTS = int(datetime.timestamp(now))
            ###nowTSplus = nowTS + 86400    ### 24 * 60 * 60  now+timedelta(hours=24)
            nowTSplus = nowTS + 432000   ### +5 days
            log('err nowTSplus= %r = HT %r' % (nowTSplus,humantime(nowTSplus)))
            conn      = getConnection()
            c         = conn.cursor()
            ### programs(channel TEXT, title TEXT, sub_title TEXT, start_date INTEGER, end_date INTEGER, description TEXT, categories TEXT, image_large TEXT, image_small TEXT, season TEXT, episode TEXT, is_movie TEXT, language TEXT, source TEXT, updates_id INTEGER, UNIQUE (channel, start_date, end_date))")
            j = 0
            c.execute("SELECT p.* FROM channels c, programs p WHERE p.channel = c.epg_channel and p.start_date>? and p.start_date<?", [nowTS,nowTSplus])
            programs = c.fetchall()
            log('err finddoubletes() 1')
            programs = sorted(programs, key=itemgetter('updates_id'), reverse=True)
            log('err Programs in timespan= %r' % len(programs))
            for prog in programs:
                j += 1
                if j < 10:
                    log('err #j %03d channel= %r, title= %r, start_date= %r, end_date= %r, updates_id= %r' % (j, prog[0], prog[1], ht(prog[3]), ht(prog[4]), ht(prog[14])))
                c.execute("SELECT * FROM programs WHERE channel=? and title=? and ((start_date<? and end_date>?) or (start_date<? and end_date>?))",  [prog[0],prog[1],prog[3],prog[3],prog[4],prog[4]])
                overlappingprograms0 = c.fetchall()
                c.execute("SELECT * FROM programs WHERE channel=? and title=? and ((start_date<=? and end_date>?) or (start_date<=? and end_date>?) or (start_date<? and end_date>=?) or (start_date<? and end_date>=?))",  [prog[0],prog[1],prog[3],prog[3],prog[4],prog[4],prog[3],prog[3],prog[4],prog[4]])
                overlappingprograms = c.fetchall()
                overlappingprograms = sorted(overlappingprograms, key=itemgetter('updates_id'), reverse=True)
                log('#j %r Overlappingprograms= %r:%r\nChannel= %r\nProgram= %r' % (j,len(overlappingprograms0),len(overlappingprograms),prog[0], prog[1]))  ### < and > changed to <= and >= 2019-09-16
                if len(overlappingprograms) > 0:
                    finalProg = ['channel', 'title', 'sub_title', 'start_date', 'end_date', 'description', 'categories', 'image_large', 'image_small', 'season', 'episode', 'is_movie', 'language', 'source', 'updates_id']
                    i = 0
                    log('#j %06d channel= %r, title= %r, start_date= %r, end_date= %r, updates_id= %r' % (j, prog[0], prog[1], ht(prog[3]), ht(prog[4]), ht(prog[14])))
                    
                    for overlap in overlappingprograms:
                        i += 1
                        dublets += 1
                        log('#i %06d channel= %r, title= %r, start_date= %r, end_date= %r, updates_id= %r' % (i, overlap[0], overlap[1], ht(overlap[3]), ht(overlap[4]), ht(overlap[14])))
                        log('\n   prog[14]= %r\n overlap[14]= %r'% (prog[14],overlap[14]))
                        try:
                            if prog[14] == None:
                                deleted = delEPGProgram(prog[0], prog[3], prog[4])
                                if deleted: deleteddublets += 1
                                log('#j %06d channel= %r, title= %r, start_date= %r, end_date= %r, updates_id= %r\nDeleted with success 1: %r' % (j, prog[0], prog[1], ht(prog[3]), ht(prog[4]), ht(prog[14]),deleted))
                                finalProg = overlap
                            elif prog[14] > overlap[14]:
                                ### The newest found
                                ### delEPGProgram(channel, start_date, end_date)
                                deleted = delEPGProgram(overlap[0], overlap[3], overlap[4])
                                if deleted: deleteddublets += 1
                                log('#i %06d channel= %r, title= %r, start_date= %r, end_date= %r, updates_id= %r\nDeleted with success 2: %r' % (i, overlap[0], overlap[1], ht(overlap[3]), ht(overlap[4]), ht(overlap[14]),deleted))
                                finalProg = prog
                            elif prog[14] < overlap[14]:
                                deleted = delEPGProgram(prog[0], prog[3], prog[4])
                                if deleted: deleteddublets += 1
                                log('#j %06d channel= %r, title= %r, start_date= %r, end_date= %r, updates_id= %r\nDeleted with success 3: %r' % (j, prog[0], prog[1], ht(prog[3]), ht(prog[4]), ht(prog[14]),deleted)) 
                                finalProg = overlap
                            elif prog[14] == overlap[14]:
                                if prog[3] < overlap[3]:
                                    finalProg = prog
                                elif prog[4] < overlap[4]: 
                                    finalProg = overlap
                        except Exception as e:
                            log('err #4734 Exception: %r' % e)
                            pass
                            log('#i %06d channel= %r, title= %r\n ERROR: %r ' % (i, overlap[0], overlap[1], e))
                    log('#j %06d channel= %r, title= %r, start_date= %r, end_date= %r, updates_id= %r\nFinal surviving program' % (j, finalProg[0], finalProg[1], ht(finalProg[3]), ht(finalProg[4]), ht(finalProg[14])))
                    if finalProg[0] != 'channel':
                        ### This is the survival EPG program - now find planned recordings for this program and update start and stop dates
                        log('This is the survival EPG program - now find planned recordings for this program and update start and stop dates')
            if updateplanedrecordings == 'true':
                ### recordings_adc(cat 0, name 1, start 2, end 3, alarmname 4, description 5, playchannel 6)
                ### programs(channel 0, title 1, sub_title 2, start_date 3, end_date 4, description 5, categories 6, image_large 7, image_small 8, season 9, episode 10, is_movie 11, language 12, source 13, updates_id 14)
                ### channels(id 0, title 1, logo 2, stream_url 3, source 4, visible 5, weight 6, favorite 7, catchup 8, epg_channel 9, description 10, updated 11, created 12)
                c.execute("SELECT * FROM recordings_adc WHERE start>? AND end<?", [humantime(nowTS),humantime(nowTSplus)])
                programs = c.fetchall()
                programs = sorted(programs, key=itemgetter('start'))
                log('Planned recordings in timespan= %r' % len(programs))
                ###c.execute("SELECT r.*, p.* FROM channels c, programs p, recordings_adc r WHERE p.title=r.name and p.channel=c.epg_channel and r.cat = c.id and p.start_date>? and p.start_date<?", [nowTS,nowTSplus]) 
                c.execute("SELECT r.*, p.* FROM programs p, recordings_adc r WHERE p.title=r.name and p.channel=r.playchannel and p.start_date>? and p.start_date<?", [nowTS,nowTSplus]) 
                programs = c.fetchall()
                programs = sorted(programs)
                log('Planned recordings/programs in timespan= %r' % len(programs))
                try:
                    startPadding = 60 * int(definition.ADDONgetSetting('TimeBefore'))
                    endPadding   = 60 * int(definition.ADDONgetSetting('TimeAfter'))
                    MaxTimeDifference = int(definition.ADDONgetSetting('MaxTimeDifference')) * 60 * 60   ### Max default 2 hours difference 2019-08-30
                except Exception as e:
                    log('err #4759 Exception: %r' % e)
                    startPadding = 60 * 3  ###  3 minutes
                    endPadding   = 60 * 15 ### 15 minutes
                    MaxTimeDifference = 2 * 60 * 60  ### 2 hours
                
                for prog in programs:
                    data = []
                    for index in range(0, len(prog)): 
                        data.append(prog[index])
                    log('err planned recording= %r' % data)
                    ### cat 0, name 1, start 2, end 3, alarmname 4, description 5, playchannel 6, channel 0/7, title 1/8, sub_title 2/9, start_date 3/10, end_date 4/11, description 5, categories 6, image_large 7, image_small 8, season 9, episode 10, is_movie 11, language 12, source 13, updates_id 14
                    nowDS = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                    log('nowDS= %r' % nowDS)
                    cat = data[0]
                    log('log cat= %r' % cat)
                    recordname = data[1]
                    log('recordname= %r' % recordname)
                    alarmname = data[4]
                    log('alarmname= %r' % alarmname)
                    playchannel = data[6]
                    log('playchannel= %r' % playchannel)
                    e_start = ts(data[2])
                    log('e_start= %r' % e_start)
                    e_end = ts(data[3])
                    log('e_end= %r' % e_end)
                    p_start_date = data[10] - startPadding
                    log('p_start_datet= %r' % p_start_date)
                    p_end_date = data[11] + endPadding
                    log('p_end_date= %r' % p_end_date)
                    startdate = e_start
                    log('err startdate= %r' % startdate)
                    enddate = e_end
                    log('enddate= %r' % enddate)
                    startep = abs(e_start - p_start_date)
                    log('err startep= %r' % startep)
                    if startep < MaxTimeDifference : 
                        if e_start < p_start_date and abs(e_start - p_start_date) < MaxTimeDifference : 
                            startdate = e_start
                        else:
                            startdate = p_start_date
                    endep = abs(e_end - p_end_date)
                    log('err endep= %r' % endep)
                    if endep < MaxTimeDifference : 
                        if e_end > p_end_date : 
                            enddate = e_end
                        else:
                            enddate = p_end_date
                    if startdate != e_start or enddate != e_end:
                        description = data[5] + '\n\nStart/Stop Time changed ' + nowDS + '\nStartNEW ' + repr(startdate) + ' - ' + humantime(startdate)+ '\nStartORG ' + repr(e_start) + ' - ' + humantime(e_start)+ '\nEndNEW ' + repr(enddate) + ' - ' + humantime(enddate)+ '\nEndORG ' + repr(e_end) + ' - ' + humantime(e_end)
                        updatedrecordings += 1
                        startDate = humantime(startdate)
                        endDate = humantime(enddate)
                        delRecordingPlanned(cat, data[2], data[3], recordname)
                        addRecordingPlanned(cat, startDate, endDate, recordname, alarmname, description, playchannel)      
        except Exception as e:
            log('error #5251 Exception: %r' % e)
            pass
            log('finddoubletes FAILED j= %r \nERROR= %r' % (j,e))
        log('finddoubletes ended\n Deleted %r dublet EPG Programs\n Doublets found= %r\n Updated recordings= %r' % (deleteddublets,dublets,updatedrecordings))  
        definition.ADDONresetSetting('lastEPGimportdublets',repr(dublets))
        definition.ADDONresetSetting('lastEPGimportdubletsdeleted',repr(deleteddublets))
        definition.ADDONresetSetting('lastEPGimportplannedupdated',repr(updatedrecordings))
        if definition.ADDONgetSetting('notifyduringepgupdate') == 'true':
            if updateplanedrecordings == 'true' :
                utils.notificationforced('Finddoubletes ended\nDeleted %r Updated %r' % (deleteddublets,updatedrecordings))
            else:
                utils.notificationforced('Finddoubletes ended\nDeleted %r' % (deleteddublets))
        c.close()
    return updatedrecordings
    
def updateOrigin(dbpathnew,originnew):
    conn   = sqlite3.connect(dbpathnew, timeout = 20, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    ###conn.execute('PRAGMA case_sensitive_like = true;')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    try:
        c = conn.cursor()
        c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, favorite BOLEAN, catchup BOLEAN, epg_channel TEXT, description TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (id, title, source))")
        c.execute("CREATE TABLE IF NOT EXISTS channelsRecursive(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, favorite BOLEAN, catchup BOLEAN, epg_channel TEXT, description TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (id, title, source))")
        c.execute("CREATE TABLE IF NOT EXISTS recordings_adc (cat TEXT, name TEXT, start TEXT, end TEXT, alarmname TEXT, description TEXT, playchannel TEXT, PRIMARY KEY (cat,name,start,end))")
        conn.commit()
        
        c.execute("SELECT * FROM channels WHERE source=?", [origin]) 
        channels = c.fetchall()
        if len(channels) > 0:
            for chan in channels:
                c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], originnew, chan[5], chan[6], chan[7], chan[8], chan[9], chan[10], chan[11], chan[12]])                        
        c.execute("DELETE FROM channels WHERE source=?",  [origin])
        conn.commit()
        c.close()
    except Exception as e:
        log('err #4852 Exception: %r' % e)
        pass
        log( 'Update with new origin database failed! \nERROR= %r' % (e))
