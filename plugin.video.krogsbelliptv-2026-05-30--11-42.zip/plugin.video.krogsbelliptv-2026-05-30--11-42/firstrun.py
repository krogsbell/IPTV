#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import net
import recordings,utils
from datetime import datetime, timedelta
import definition

module = 'firstrun.py'
utils.logdev(module,'Start')
ADDON    = definition.getADDON()
datapath = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))

def LOGIN():
    utils.logdev(module,'LOGIN')
    username = definition.ADDONgetSetting('user')
    password = definition.ADDONgetSetting('pass')
    
    ###if '@' in username and not (username == '' or password == ''):
    if username.lower() != 'none':
        if not (username == '' or password == ''):
            definition.ADDONsetSetting('firstrun','true')
        else:
            dialog = xbmcgui.Dialog()
            if dialog.yesno(definition.ADDONgetAddonInfo('name'), '', '', 'Please Login Again'):
                SIGNIN()
            else:
                EXIT()
def EXIT():
        ###xbmc.executebuiltin("XBMC.Container.Update(path,replace)")
        xbmc.executebuiltin("Container.Update(path,replace)")
        ###xbmc.executebuiltin("XBMC.ActivateWindow(Home)")
        ###xbmc.executebuiltin("ActivateWindow(Home)")
        xbmc.executebuiltin("ActivateWindow('1000')")
 
def Search(name):
        search_entered = ''
        keyboard = xbmc.Keyboard(search_entered, 'Please Enter '+str(name))
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText()
            if search_entered == None:
                return False          
        return search_entered    
        
def Numeric(name):
        dialog = xbmcgui.Dialog()
        keyboard=dialog.numeric(0, 'Please Enter '+str(name))
        return keyboard  
    
def SIGNIN():
    utils.log(module,'SIGNIN')
    email=Search('Email')
    definition.ADDONsetSetting('user',email)
    password=Search('Password')
    definition.ADDONsetSetting('pass',password) 
    LOGIN()

def Launch():        
    utils.logdev(module,'Launch')
    username= definition.ADDONgetSetting('user')
    utils.logdev(module,'username= %s' % username)
    password = definition.ADDONgetSetting('pass')
    if definition.ADDONgetSetting('enable_record')=='true':   ### don't ask for login if not recording 2024-05-18
        if username.lower() != 'none':
            if username == '' or password == '':
                dialog = xbmcgui.Dialog()
                if dialog.yesno(definition.ADDONgetAddonInfo('name'), 'Do you Wish To Register\nOr Sign In','Register','Sign In'):
            
                    SIGNIN()
            
                else:
                    dialog.ok(definition.ADDONgetAddonInfo('name'), 'Please register for ' + definition.ADDONgetAddonInfo('name') + ' at ' + definition.getREGISTRATION() +'\nAfter registering check your email to verify account\nThen come back and sign in.')
                    EXIT()
                


Launch()                
