#!/usr/bin/python
# -*- coding: utf-8 -*-
#print "findrecursivetimedOnce.py"
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import urllib,sys,re,os
import datetime
import time
import utils
import net
from hashlib import md5  
import json
import recordings, glob
import findrecursive
import locking
import definition
ADDON      = definition.getADDON()
module     = 'findrecursivetimedOnce.py'
utils.logdev(module,'Start')
if not locking.isAnyRecordLocked(): 
	findrecursive.RecursiveRecordingsPlanned('Once')
	#xbmc.executebuiltin("Container.Refresh")

def deleteFile(file):
    tries    = 0
    maxTries = 10
    while os.path.exists(file) and tries < maxTries:
        try:
            os.remove(file)
            #print 'findrecursivetimed.py: Deleted os.remove(file)= %s' % repr(file)
            break
        except:
            xbmc.sleep(50)
            tries = tries + 1

lockDescription = '*Stop Recording*.flv'
recordingLock = os.path.join(definition.ADDONgetSetting('record_path'),lockDescription)
LockFiles = glob.glob(recordingLock)

# delete lock files
for file in LockFiles:
	deleteFile(file)
