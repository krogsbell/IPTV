#!/usr/bin/python
# -*- coding: utf-8 -*-
#print "findtvguidenotifications.py"

try:
    import xbmc,utils,locking
    import definition
    ADDON      = definition.getADDON()

    program  = sys.argv[0]
    guide    = sys.argv[1]
    extrapar = sys.argv[2]
    modul    = 'StopTVGuide'

    utils.logdev(modul,repr(sys.argv))

    if locking.isAnyRecordLocked():
        utils.logdev(modul, 'Recording - No Stop TV Guide= %s' % (guide))
    else:
        try:
            utils.logdev(modul, 'Trigger TV Guide= %s' % (guide))
            xbmc.executebuiltin("StopScript(" + guide + ")")  ### Stop Guide
        except Exception, e:
            pass
            utils.logdev(modul, 'Trigger TV Guide failed! Guide= %s ERROR= %s' % (guide,repr(e)))
except: pass