#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmcaddon,xbmc,xbmcvfs,xbmcgui,os,shutil,io
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)

referral= 0       
BASEURL = ''
COMMAND = ''
COMMANDEND = ''
REGISTRATION = ''
DEFAULTSTREAMTYPE = ''
ADDON   = xbmcaddon.Addon('plugin.video.krogsbelliptv-2025-12-17--19-42')
ADDONid = ADDON.getAddonInfo('id')
module = 'definition.py'
"""
def log(infotext,showlength=1024,module='definition.py'):
        ALL = 'F'   ### 'T'   ### for True  'F' for False
        if "ADDONsetSetting: 'debug', Value " in infotext:
            return   ### ignore logning with debug setting 2025-07-13
        if DEBUGL == '' :
            if ('exception' in infotext.lower()) or ALL == 'T':
                 a = 0
            else:
                return 
        if ('exception' in infotext.lower()) or (DEBUGL in infotext.lower()) or (DEBUGL in module.lower()) or ALL == 'T':
            a = 1
        else:
            return  
        nowht = ht(nowTS())
        file = os.path.join(datapath,'definition.log')
        text = infotext[0:showlength]
        LF = io.open(file, 'a', encoding = 'utf-8')
        LF.write('|\n%s | %s | %s | %s |\n%r' % (nowht,ALL,DEBUG,module,text))
        LF.close()
"""
def log(infotext,showlength=1024,module='definition.py'):
        ALL = 'F'   ### 'T'   ### for True  'F' for False
        a = -2   ### dummy
        if "ADDONsetSetting: 'debug', Value " in infotext:
            a = -1   ### ignore logning with debug setting 2025-07-13
        if DEBUGL == '' and a != -1:
            if ('exception' in infotext.lower()) or ALL == 'T':
                 a = 0
            else:
                a = -1 
        if ('exception' in infotext.lower()) or (DEBUGL in infotext.lower()) or (DEBUGL in module.lower()) or ALL == 'T' and a != -1:
            a = 1
        else:
            a = -1   
        if a != -1:
            nowht = ht(nowTS())
            file = os.path.join(datapath,'definition.log')
            text = infotext[0:showlength]
            LF = io.open(file, 'a', encoding = 'utf-8')
            LF.write('|\n%s | %s | %s | %s |\n%r' % (nowht,ALL,DEBUG,module,text))
            LF.close()
            
def logX(infotext,showlength=1024):
    return
        
def ht(ts):    ### Timestamp to short human time
    if not isinstance(ts, int):
        return ts
    dt = datetime.fromtimestamp(ts)
    ###ht = dt.strftime("%Y-%m-%d %H:%M:%S")
    ht = dt.strftime("%m-%d %H:%M")
    return ht
    
def nowTS():   ### Local time
    dt_obj= datetime.now()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
   
def nowutcTS():   ### UTC time
    dt_obj= datetime.utcnow()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
    
def timeZone():
    tz = (nowTS() - nowutcTS())//3600
    return tz
    
def DaylightSaving():
    dialog = xbmcgui.Dialog()
    if dialog.yesno(ADDONgetAddonInfo('name'), "[COLOR red]Are you using daylight saving[/COLOR]", '', "What Do You Want To Do","[COLOR red]Use Daylight Saving[/COLOR]","[COLOR green]No[/COLOR]"):
        ### No
        return False
    else:
        ### Yes
        return True
        
def Numeric(name,default):
    dialog = xbmcgui.Dialog()
    keyboard=dialog.numeric(0, 'Please Enter '+str(name),default)
    if keyboard:
        if keyboard[0:1] == '0':
            keyboard = str(0-int(keyboard))
    return keyboard
    
### xbmcgui.Dialog().browse(type, heading, shares[, mask, useThumbs, treatAsFolder, defaultt, enableMultiple])
def getFile(name,default):
    dialog = xbmcgui.Dialog()
    file = dialog.browse(1, 'Please Enter '+str(name), '', defaultt=default)
    return file
    
def Search(name,search_entered):
    keyboard = xbmc.Keyboard(search_entered, '[COLOR lightgreen][B]Please Enter '+str(name)+'[/B][CR][COLOR grey][I]<ESC> or Cancel to clear[/I][/COLOR]')
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_entered = keyboard.getText()
        if search_entered == None:
            return False 
    else:
        return False
    return search_entered 
    
def FileManagerPath(PathInput):
    try:
        sources = xbmcvfs.translatePath('special://masterprofile/sources.xml')
        file = open(sources,'r', encoding = 'utf-8')
        allsources = file.read()
        files = allsources.split('<files>')[1]
        logX('error FileManagerPath files= %r' % files)
        searchtext = '<name>'+PathInput+'</name>'
        logX('error FileManagerPath searchtext= %r' % searchtext)
        files = files.split(searchtext)[1]
        logX('error FileManagerPath 1 files= %r' % files)
        files = files.split('>')[1]
        logX('error FileManagerPath 3 files= %r' % files)
        Path = files = files.split('</path')[0]
        
    except Exception as e:
        pass
        Path = PathInput
        log('Exception in FileManagerPath= %r' % e)
    log('FileManagerPath= %r' % Path)    
    return Path    
    
def ADDONgetAddonInfo(info):
    file = os.path.join(datapath,'ADDON-' + info) + '.set'
    if os.path.isfile(file) == False:
        value = ADDON.getAddonInfo(info)
        LF = open(file, 'w')
        LF.write(value)
        LF.close()
    else:
        LF = open(file,'r')
        value = LF.read()
    return value
    
def getSETTINGSONLYINFILE():
    return ['allownamechange','basicuserinfoerror']     ###'debug',

def getSETTINGSINFILE():
    return ['debug','basicuserinfo','basicuserinfofile','BASEURL']  ### 'directchannelsfromextraXMLTVfile',

def getSETTINGINFILEMANAGER():
    return ['record_path','record_archive_path','record_archiveb_path','record_archivef_path','sharepath','tvguideimport','backup_path']
   
SETTINGSONLYINFILE = getSETTINGSONLYINFILE()
SETTINGSINFILE = getSETTINGSINFILE()
SETTINGINFILEMANAGER = getSETTINGINFILEMANAGER()

def ADDONsetSetting(setting,value):
    if setting == 'basicuserinfoerror' :
        return   ### TEST 2024-07-10
    if  not setting == 'debug' :
        log('ADDONsetSetting: %r, Value %r' % (setting,value))
    if value != '' :
        if setting in SETTINGSONLYINFILE : 
            ext = '.fix'
        else:
            ext = '.set'
            ADDON.setSetting(setting,value)
        try:
            if setting in SETTINGSONLYINFILE or setting in SETTINGSINFILE: 
                file = os.path.join(datapath,'ADDONsetting-'+setting) + ext
                LF = open(file, 'w')
                LF.write(value)
                LF.close()
        except Exception as e:
            pass
            log('ADDONsetSetting: %r, Exception %r' % (setting,e))
  
def ADDONresetSetting(setting,value):
    if setting == 'basicuserinfoerror' :
        return   ### TEST 2024-07-10
    if setting in SETTINGSONLYINFILE : 
        ext = '.fix'
    else:
        ext = '.set'
        ADDON.setSetting(setting,value)
    try:
        if setting in SETTINGSONLYINFILE or setting in SETTINGSINFILE: 
            file = os.path.join(datapath,'ADDONsetting-'+setting) + ext
            LF = open(file, 'w')
            LF.write(value)
            LF.close()
    except Exception as e:
        pass
        log('ADDONresetSetting: %r, Exception %r' % (setting,e))
  
def ADDONgetIntSetting(setting):
    setting = ADDONgetSetting(setting)
    if setting == '':
        setting = '-1'
    value = int(setting)
    return value
    
def ADDONgetSetting(setting):
    if setting == 'basicuserinfoerror' :
        return  ''  ### TEST 2024-07-10
    if setting in SETTINGSONLYINFILE : 
        ext = '.fix'
    else:
        ext = '.set'
        ADDON.getSetting(setting)
    if setting in SETTINGSONLYINFILE or setting in SETTINGSINFILE: 
        file = os.path.join(datapath,'ADDONsetting-'+setting) + ext
        if os.path.isfile(file) == False:
            value = ADDON.getSetting(setting)
            if setting == 'my_referral_name':
                value = value.replace('\n','')
                if value == '':
                    value = ADDON.getSetting('fixedname')
                    if value == '':
                        value = ADDONgetAddonInfo('name')   ### 2025-02-13
            ADDONresetSetting(setting,value)
        LF = open(file,'r')
        try:
            value = LF.read()
        except Exception as e:
            pass
            log('ADDONgetSetting Exception %r' % e)
            LF = open(file,'rb')
            valueb = LF.read()
            try:
                value = valueb.decode('utf8')
            except Exception as e:
                pass
                log('ADDONgetSetting Exception %r' % e)
                value = 'Error getting setting: %r' % setting
        if setting == 'my_referral_name':
            value = value.replace('\n','')
        ADDONsetSetting(setting,value)
    else:
        value = ADDON.getSetting(setting)
    
    if setting in SETTINGINFILEMANAGER :
        value = FileManagerPath(value)
        
    return value

def Parameter(ADDON,name,parameter):
    VALUE = ADDONgetSetting(parameter)
    fixedname = ADDONgetSetting('fixedname')
    if fixedname != '' and parameter == 'my_referral_name':
        VALUE = fixedname
    if VALUE == '' and parameter == 'my_referral_name':
        VALUE = ADDONgetAddonInfo('name')
        if VALUE == '':
            VALUE = 'Krogsbell'
    ###newVALUE = Search(name,VALUE)
    newVALUE = VALUE   ### 2025-07-07
    ADDONsetSetting('parameter',str(VALUE) + '-->' + str(newVALUE))
    if newVALUE == '' and parameter == 'my_referral_name':
        newVALUE = ADDONgetAddonInfo('name')
        if newVALUE == '':
            newVALUE = 'Krogsbell'
    if newVALUE:
        ADDONsetSetting(parameter,newVALUE)
    return newVALUE

if referral==0:
    ADDON = xbmcaddon.Addon(id='plugin.video.krogsbelliptv-2025-12-17--19-42')
    datapath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    DEBUG  = ADDONgetSetting('debug')
    DEBUGL = DEBUG.lower()
    if not xbmcvfs.exists(datapath):
        xbmcvfs.mkdir(datapath)
    ADDONsetSetting('addon_program_path',ADDONgetAddonInfo('path'))
    ADDONsetSetting('versionofsetting',ADDONgetAddonInfo('version'))
    BASEURLlast = ADDONgetSetting('BASEURLlast')
    log('BASEURLlast= %r' % BASEURLlast)
    BASEURL = ADDONgetSetting('BASEURL')
    log('BASEURL= %r' % BASEURL)
    if BASEURLlast != BASEURL :
        ADDONsetSetting('BASEURLlast',BASEURL)
        log('BASEURLlast changed to= %r' % BASEURL)
    
    log('timeZone= %r' % timeZone())
    TIMEZONE = str(timeZone())
    ADDONsetSetting('TIMEZONE',TIMEZONE)
    log('setSetting(TIMEZONE= %r' % TIMEZONE)
    ADDONsetSetting('AdjustTVguideTimeZoneOffset',TIMEZONE)
    log('setSetting(AdjustTVguideTimeZoneOffset= %r' % TIMEZONE)
    ###ADDONsetSetting('archiveoffset','0')  ### Archive uses GMT 2019-03-30
    ADDONsetSetting('AdjustTVguideTimeZoneOffsetExtraXML',TIMEZONE)
    log('setSetting(AdjustTVguideTimeZoneOffsetExtraXML= %r' % TIMEZONE)
    log('BASEURL= %r' % BASEURL)
    allownamechange = ADDONgetSetting('allownamechange') 
    if allownamechange.lower() == 'true' :   ### 2022-10-26 set user automatically if allowed
        if not 'http://' in BASEURL and not 'https://' in BASEURL:
            try:
                my_referral_name = Parameter(ADDON,'Addon Name','my_referral_name')
                log('my_referral_name= %r' % my_referral_name)
                my_referral_registration = Parameter(ADDON,'Krogsbell IPTV','my_referral_registration')
                log('my_referral_registration= %r' % my_referral_registration)
                basicuserinfofile = ADDONgetSetting('basicuserinfofile')
                log('1 basicuserinfofile= %r' % basicuserinfofile)
                if 'none.txt' in basicuserinfofile:
                    basicuserinfofile = os.path.join(ADDONgetAddonInfo('path'), 'none.txt')
                ### basicuserinfo = Parameter(ADDON,'Your Connection Details Text File','basicuserinfo')
                ### http://<url>/get.php?username=<>&password=<>&type=m3u_plus&output=ts
                log('2 basicuserinfofile= %r' % basicuserinfofile)
                basicuserinfofile = getFile('Your Connection Details Text File or none',basicuserinfofile)
                log('3 basicuserinfofile= %r' % basicuserinfofile)
                ADDONsetSetting('basicuserinfofile',basicuserinfofile)
                
                ChannelFile = ADDONgetSetting('directchannelsfromextraXMLTVfile')
                if os.path.isfile(ChannelFile):
                    directchannelsdef = ChannelFile
                else:
                    directchannelsdef = os.path.join(ADDONgetAddonInfo('path'), 'directchannels.m3u.txt')
                directchannels    = getFile('Your Direct Channels m3u File or keep last',directchannelsdef)
                datapath = xbmcvfs.translatePath(ADDONgetAddonInfo('profile'))
                if os.path.isfile(directchannels) and directchannels != directchannelsdef:
                    directchannelsdata = os.path.join(datapath,'directchannels.m3u')
                    ADDONsetSetting('directchannelsfromextraXMLTVfile',directchannelsdata)
                    shutil.copyfile(directchannels, directchannelsdata)
                else:
                    try:
                        ADDONsetSetting('directchannelsfromextraXMLTVfile','')
                        os.remove(os.path.join(datapath,'directchannels.m3u'))
                    except:
                        pass
                
                file = open(basicuserinfofile,'r')
                desc = file.read()
                file.close()
                basicuserinfo = desc
                ADDONsetSetting('basicuserinfo','File read: '+ basicuserinfo)
                
                if basicuserinfo:
                    if basicuserinfo.lower().replace('\n','').replace('\r','').replace("'",'') == 'none':
                        basicuserinfo = 'http://none.none:80/get.php?username=none&password=none&type=m3u_plus&output=ts'
                    basicuserinfo = basicuserinfo.replace('&amp;','&')
                    
                    ADDONsetSetting('AAA','basicuserinfo= %r' % basicuserinfo)
                    if 'http://' in basicuserinfo.lower():
                        
                        server = basicuserinfo.split('http://',1)[1]
                    else:
                        
                        server = basicuserinfo.split('https://',1)[1]
                    
                    BASEURL = server.split('/')[0]
                    
                    command = server.replace(BASEURL,'',1)
                    BASEURL = 'http://' + BASEURL
                    COMMAND = command.split('username=',1)[0]
                    
                    username = command.split('username=',1)[1].split('&',1)[0]
                    
                    password = command.split('password=',1)[1].split('&',1)[0]
                    
                    COMMANDEND = '&type=' + command.split('&type=',1)[1]
                    ADDONsetSetting('COMMAND',COMMAND)
                    ADDONsetSetting('COMMANDEND',COMMANDEND)
                    if BASEURL != '' and username != '' and password != '':
                        
                        ADDONsetSetting('BASEURL',BASEURL)
                        ADDONsetSetting('user',str(username))
                        ADDONsetSetting('pass',str(password))
            except Exception as e:
                pass
                ADDONsetSetting('basicuserinfoerror', 'l= %r, ERROR= %r' % (l,e))
        else:
            ADDONsetSetting('basicuserinfo','Name change allowed')
            BASEURL = ADDONgetSetting('BASEURL').replace('&amp;','&')
            COMMAND = ADDONgetSetting('COMMAND').replace('&amp;','&')
            COMMANDEND = ADDONgetSetting('COMMANDEND').replace('&amp;','&')
        REFERRALNAME = ADDONgetSetting('Addon Name')
        REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'
        DEFAULTSTREAMTYPE = 'live'
else:
    DEBUG = ''
    ADDONsetSetting('basicuserinfo','No name change allowed')
    ADDON = xbmcaddon.Addon(id='plugin.video.krogsbelliptv-2025-12-17--19-42')
    if ADDONgetSetting('BASEURL') == '':
        basicuserinfo = Search('Your connection details file')
        ### http://<url>/get.php?username=<>&password=<>&type=m3u_plus&output=ts
        if basicuserinfo:
            if 'http://' in basicuserinfo.lower():
                server = basicuserinfo.split('http://',1)[1].split('/')[0]
                BASEURL = basicuserinfo.split('http://',1)[1].split('/')[0]
                COMMAND = ''
    REGISTRATION = ''
    COMMAND = '/panel_api.php?'
    COMMANDEND = '&type=m3u_plus&output=m3u8'
    REGISTRATION = ''
    REFERRALNAME = 'Krogsbell IPTV 2024-07-06--10-14 Rec'
    REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'

ADDONsetSetting('my_referral_link',str(referral))
REFERRALNAME = ADDONgetSetting('my_referral_name')
REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'
REGISTRATION = ADDONgetSetting('my_referral_registration')
###xbmc.log('definition.py in %s with referral= %s' % (ADDON.getAddonInfo('id'), repr(referral)))

def getADDON():
    return ADDON

def getBASEURL():
    return BASEURL  
  
def getCOMMAND():
    return COMMAND 
    
def getCOMMANDEND():
    return COMMANDEND  
    
def getREGISTRATION():
    return REGISTRATION 
 
def getTITLE():
    return REFERRALTITLE 
    
def getDefaultStreamType():
    return DEFAULTSTREAMTYPE
    
def getKrogsbellAddOns():
    ###return ['plugin.video.glowiptv.rec','plugin.video.premiumiptv.rec','plugin.video.roqtv.rec']
    ###return ['plugin.video.glowiptv.rec','plugin.video.krogsbelliptv-2025-12-17--19-42.rec',]
    return []

def getNTVAddOns():
    return ['plugin.video.unlimtv']
    ###return []
    
def DRLYD():
    return 'plugin://plugin.audio.dr.dk.netradio/'

def kodiuserfiles():
    return ['sources.xml','passwords.xml','mediasources.xml','upnpserver.xml','favourites.xml','guisettings.xml','Database/MyVideos131.db']
        
def xmlimportfiles():
    return ['sources.xml','mediasources.xml','passwords.xml','favourites.xml']
            
def getdatafiles():
    return ['scanLockEPG_update.txt','definition.log','definitionOLD.log','settings.xml','master.xml','epg//favoritesEPG.xml','extraxmltvfile.m3u','recordings_adc.db','categories.db',ADDONid+'EPG.xml','files.db'] 