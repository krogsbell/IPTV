#!/usr/bin/python
# -*- coding: utf-8 -*-
import recordings, utils, locking, updateepg
import xbmcaddon, xbmc, xbmcvfs, datetime, os
from sqlite3 import dbapi2 as sqlite3

import definition
ADDON	    = definition.getADDON()
ADDONid     = definition.ADDONgetAddonInfo('id')
ADDONname   = definition.ADDONgetAddonInfo('name')
module      = 'startmarker.py'

###kodi.log contains Running database version MyVideos121
###MyVideos_DB = 'MyVideos116.db'      ### Kodi 18
###MyVideos_DB = 'MyVideos119.db'      ### Kodi 19
###MyVideos_DB = 'MyVideos120.db'      ### Kodi 20..

def log(infotext,showlength=1024):
    definition.log(infotext,showlength,module)

log('Start')
"""
KodiVersion = int(xbmc.getInfoLabel('System.BuildVersion')[:2])
###log('xbmc.getInfoLabel(System.BuildVersion)[:2]= %r' % KodiVersion)
if KodiVersion < 18:  
    MyVideos_DB = 'MyVideos116.db'   ### Kodi 18
elif KodiVersion == 19:
    MyVideos_DB = 'MyVideos119.db'   ### Kodi 19
else:
    MyVideos_DB = 'MyVideos121.db'   ### Kodi 20..
"""    
MyVideos_DB = utils.MyVideos_DB()
log('MyVideos_DB= %r' % MyVideos_DB)

def getConnection():    
    ### ...\Kodi\userdata\Database\MyVideos116.db
    dbPath = xbmcvfs.translatePath('special://masterprofile/')
    log('MyVideos dbPath= %r' % dbPath)
    log('MyVideos os.path.join(dbPath, MyVideos_DB)= %r' % os.path.join(dbPath, 'Database', MyVideos_DB))
    conn   = sqlite3.connect(os.path.join(dbPath, 'Database', MyVideos_DB), timeout = 20, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    return conn

def setStartTime(starttime,filename):
    log('err starttime= %r\nfilename= %r' % (starttime,filename))
    startat = starttime
    conn = getConnection()
    c = conn.cursor()
    log('c= %r' % c)
    c.execute("SELECT * FROM files WHERE strFilename = ?",[filename])
    filematch = c.fetchall()
    log('filename= %r, len(filematch)= %r' % (filename, len(filematch)))
    try:
        if ':' in starttime:
            starttime = starttime.split(':')
            starttime = int(starttime[0]) * 60 + int(starttime[1])
        else:
            starttime = int(starttime)
    except Exception as e:
        pass
        log('setStartTime ERROR: %r' % e)
        starttime = 0
    totalTimeInSeconds= starttime * 1000
    thumbNailImage= ''
    player= 'VideoPlayer'
    playerState= ''
    type= 1
    for file in filematch:
        idFile = file[0]
        c.execute("DELETE FROM bookmark WHERE idFile=?", [idFile]) 
        ###CREATE TABLE bookmark ( idBookmark integer primary key, idFile integer, timeInSeconds double, totalTimeInSeconds double, thumbNailImage text, player text, playerState text, type integer)
        c.execute("INSERT OR REPLACE INTO bookmark(idFile, timeInSeconds, totalTimeInSeconds, thumbNailImage, player, playerState, type) VALUES(?, ?, ?, ?, ?, ?, ?)", [idFile, starttime, totalTimeInSeconds, thumbNailImage, player, playerState, type])  
    try:
        conf = recordings.getFilesConnection()
        recordings.createFileTable(conf)
        c = conf.cursor()
        ###recordPath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_path')))
        ###recordArchivePath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_archive_path')))
        ###recordArchivebPath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_archiveb_path')))
        if '.' in filename:
            ext = filename.split('.')[-1]
            filename = filename.split('.'+ext)[0]
        else:
            ext = ''
        c.execute("SELECT * FROM files WHERE filename=? AND ext=?", [filename,ext]) 
        selected = c.fetchall()
          
        for chan in selected:
            ###c.execute("INSERT OR REPLACE INTO files(filename, ext, path, video, description, size, archive, updated, created, updatedHuman, command, options, realtitle, startmark) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [filename, chan[1], chan[2], chan[3], chan[4], chan[5], archive, nowTS, chan[8], humantime(nowTS), command, options, realtitle, startmark])
            try:    ### changetitle
                log('changetitle')
                urlbase = chan[0] 
                if chan[1] != '':
                    fileext = '.' + chan[1]
                else:
                    fileext = ''
                archive = chan[6]
                urldirectorypath = utils.geturldirectorypath(archive)
                """
                if archive == 'L':
                    urldirectorypath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_path')))
                else:
                    if definition.ADDONgetSetting('record_archive_path_enable') == 'true':
                        urldirectorypath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_archive_path')))
                    elif definition.ADDONgetSetting('record_archiveb_path_enable') == 'true':
                        urldirectorypath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_archiveb_path')))
                    else:
                        urldirectorypath = ''
                """
                path = chan[2]
                if path != '':
                    urldirectorypath = os.path.join(urldirectorypath,path)   
                if not os.path.exists(urldirectorypath):
                    log('os.makedirs(urldirectorypath= %r' % urldirectorypath)
                    os.makedirs(urldirectorypath)    
                log('FindCommands changetitle archive= %r, urldirectorypath= %r' % (archive, urldirectorypath))
                urlnewi = chan[12]   ### real title
                if urlnewi == '':
                    urlnewi = filename
                if urlnewi != '':
                    urlnewi = ' '.join(urlnewi.split())  ## Remove doublespaces etc
                    urlbase = os.path.join(urldirectorypath,urlbase)
                    log('urlbase= %r' % urlbase)
                    urlbase = urlbase.replace('aMp ','& ').replace('xXx','+')   ### 2019-03-17
                    ###write to .tit file
                    try:
                        titleFile = urlbase + '.tit'
                        LF = open(titleFile, 'w', encoding="utf-8") 
                        if urlnewi != '':
                            LF.write(urlnewi)
                            if startat != '':
                                LF.write('\n'+startat)
                        # Close our file so no further writing is posible.
                        LF.close()
                        ###def addFile(c, filename, ext, path, video, description, size, archive, realtitle='', startmark='')
                        recordings.addFile(c, chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], urlnewi, startat)  ### change real title
                        ###recordings.addFileCommand(c, chan[0], chan[1], chan[2], chan[6], '', '')  ### Clear command
                        try:
                            os.chmod(titleFile, 0o776 )
                            log('titleFile permission set to 0776')
                        except Exception as e:
                            pass
                            log('Failed to set titleFile permission to 0776 Except: ' + repr(e))
                    except Exception as e:
                        pass
                        log('error writing titleFile= %r\nExcept: %r' % (titleFile,e))
            except Exception as e:
                pass
                log('changetitle Except %r' % e)
        
        conf.commit()
        c.close() 
    except Exception as e:
        pass
        log('Update .tit file Except: %r' % e )