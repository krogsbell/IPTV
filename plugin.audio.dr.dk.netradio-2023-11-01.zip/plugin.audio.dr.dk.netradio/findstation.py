#!/usr/bin/python
# -*- coding: utf-8 -*-

import urllib
try:
    # For Python 3.0 and later
    from urllib.request import urlopen
except ImportError:
    # Fall back to Python 2's urllib2
    from urllib2 import urlopen

import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import _strptime
import calendar
import os
import xbmcgui, xbmcplugin
import utils
import json as simplejson
import xbmcvfs,xbmcaddon
import xmltodict
import channelsDR
import channels

from infotagger.listitem import ListItemInfoTag

ADDON = xbmcaddon.Addon('plugin.audio.dr.dk.netradio')
###import addon    ### Use functions from main program NO 2023-10-12
###import urlquick

###CHANNELS_URL = 'https://www.dr.dk/mu-online/api/1.0/channel/all-active-dr-radio-channels'
PATHargv = sys.argv[1]
###idtext = PATH.replace('plugin:','').replace('/','').replace('special:homeaddons','')
###ADDON = xbmcaddon.Addon(id=idtext)
ADDON = xbmcaddon.Addon('plugin.audio.dr.dk.netradio')
ADDONname = ADDON.getAddonInfo('name')
ADDONid   = ADDON.getAddonInfo('id')
ADDONpath = xbmcvfs.translatePath('special://home/addons/%s/' % ADDONid)
progpath  = ADDON.getAddonInfo('path')
PATH      = progpath
datapath  = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
LOGO_PATH = os.path.join(PATH, 'resources', 'logos')
ICON = os.path.join(PATH, 'icon.png')
FANART = os.path.join(PATH, 'fanart.jpg')
module = 'findstation.py'
dateformat = '%Y-%m-%dT%H:%M:%S%z'
dateformatX = '%Y-%m-%d %H:%M:%S'

if utils.ADDONgetSetting('noepg') == 'true':
    noepg = True
else:
    noepg = False

def __log(text):
    utils.logdev(module,' '.join(text.split())[0:200])  ### Remove doublespaces etc
###def __log(text):
###    utils.logdev(sys.argv[0]+' '+sys.argv[2],'%r' % text[0:200])

def TSlts(timestamp):
    TO = datetime.fromtimestamp(timestamp)
    TOTS = int(time.mktime(TO.timetuple()))
    utcTO = datetime.utcfromtimestamp(timestamp)
    utcTOTS = int(time.mktime(utcTO.timetuple()))
    timeoffset = TOTS-utcTOTS
    ###__log('timeoffset= %r' % timeoffset)
    return(timestamp+timeoffset) 

def TSl(timestr):
    ### time format 2019-05-21T22:05:00Z to date string i local
    time_tuple = time.strptime(timestr, dateformat)
    timestamp = time.mktime(time_tuple)
    TO = datetime.fromtimestamp(timestamp)
    TOTS = int(time.mktime(TO.timetuple()))
    utcTO = datetime.utcfromtimestamp(timestamp)
    utcTOTS = int(time.mktime(utcTO.timetuple()))
    timeoffset = TOTS-utcTOTS
    ###__log('timeoffset= %r' % timeoffset)
    return(timestamp+timeoffset) 
        
def TS(timestr):
    ### time format 2019-05-21T22:05:00Z
    time_tuple = time.strptime(timestr, dateformat)
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def TSx(timestr):
    ### time format 2019-05-21T22:05:00Z
    time_tuple = time.strptime(timestr, dateformatX)
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
    
def nowTS():   ### UTC time
    dt_obj= datetime.utcnow()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def nowS(format):   ### Now date string UTC time
    time_tuple = time.localtime(nowTS())
    date_str = time.strftime(format, time_tuple)
    return(date_str)

def now():   ### Local time
    dt_obj= datetime.now()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    ###__log('humantime-now= %r' % humantime(timestamp))
    return(timestamp)
    
def todayDate():
    dt_obj= datetime.today().date()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
    
def AdjustDateTime(dateTS,Hours,Minutes):
    dt_obj = datetime.fromtimestamp(dateTS) + timedelta(hours= int(Hours), minutes= int(Minutes))
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
    
def humantime(ts):   ### Timestamp to human time
    if isinstance(ts, int):
        dt = datetime.fromtimestamp(ts)
    elif isinstance(ts, datetime.datetime):
        dt = ts
    else:
        return ts
    ###dt = datetime.datetime.fromtimestamp(ts)
    ht = dt.strftime("%Y-%m-%d %H:%M:%S")
    ###ht = dt.strftime("%m-%d %H:%M")
    return ht

def humanTS(timestr):
    ### time format 2019-05-21T22:05:00Z
    __log('timestr= %r' % timestr) 
    nowdate = nowS("%Y-%m-%d")
    __log('nowdate= %r' % nowdate)
    timestr = nowdate + ' ' + timestr
    __log('timestr= %r' % timestr) 
    ###ts = calendar.timegm(time.strptime(timestr, '%Y-%m-%d %H:%M'))  ###UTC
    ts = time.mktime(time.strptime(timestr, '%Y-%m-%d %H:%M'))
    
    ###ts = datetime.strptime(timestr, '%H:%M')
    __log('ts= %r' % ts) 
    timestamp = int(ts)
    __log('timestamp= %r' % timestamp) 
    """
    nowdate = nowS("%Y-%m-%d")
    __log('nowdate= %r' % nowdate)
    timestr = nowdate + ' ' + timestr
    __log('timestr= %r' % timestr) 
    time_tuple = time.strptime(timestr, "%Y-%m-%d %H:%M")
    __log('time_tuple= %r' % time_tuple) 
    timestamp = int(time.mktime(time_tuple))
    __log('timestamp= %r' % timestamp) 
    """
    return(timestamp)
    
def datestr(timestamp,format):   ### Now date string UTC time %Y-%m-%dT%H:%M:%S%z
    time_tuple = time.localtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)

def datestrdelta(timestamp,format):   ### Now date string UTC time %Y-%m-%dT%H:%M:%SZ
    time_tuple = time.gmtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)
    
def takeSecond(elem): 
    return elem[1]

def getSchedule(dataepg,station_id):   ### returns channelTitle, channelSlug, [schedule]
    if dataepg != '':
        datadict = xmltodict.parse(dataepg)
        __log('538 len(datadict)= %r' % len(datadict))
        __log('539 datadict= %r' % datadict)
        Channelfile = os.path.join(datapath, station_id + '.dic')  ### filename here 2022-05-31
        __log('540 Channelfile= %r' % Channelfile)
        try:
            with open(Channelfile,'wb') as output:
                ###output.write('%r'% datadict)
                __log('575 datadict= %r' % datadict)
                output.write(b'%r'% datadict)
                
        except Exception as e:
            pass
            __log('552 write error Channelfile.dic= %r' % e)
        masterkey = '-html-body-script-0-'
        __log('554 masterkey= %r' % masterkey)
        datadict = datadict['html']['body']['script']      ### 2022-10-15 removed [0]
        __log('550 datadict= %r' % datadict)
        dict_keys = list(datadict.keys())
        __log('552 dict_keys= %r' % dict_keys)
        Channelfile = os.path.join(datapath, station_id + masterkey + '.keys')
        __log('589 Channelfile= %r' % Channelfile)
        try:
            with open(Channelfile,'wb') as output:
                output.write(b'%r'% dict_keys)
        except Exception as e:
            pass
            __log('559 write error Channelfile.keys= %r' % e)
        
        for i in range(len(dict_keys)):
            key = dict_keys[i]
            name = datadict[key] 
            __log('563 datadict[key= %r]= %r' % (key,name))
            if isinstance(name, list):
                for j in range(len(name)):
                    Channelfile = os.path.join(datapath, station_id + masterkey + key + str(j) + '.dic')
                    __log('567 datadict[key= %r]= %r' % (key,j))
                    __log('568 datadict[key= %r] to %r' % (key,Channelfile))
                    try:
                        with open(Channelfile,'wb') as output:
                            output.write(b'%r'% name[j])
                    except Exception as e:
                        pass
                        __log('578 write error Channelfile.keys= %r' % e)
            else:
                Channelfile = os.path.join(datapath, station_id + masterkey + key + '.dic')
                __log('573 datadict[key= %r] to %r' % (key,Channelfile))
                try:
                    with open(Channelfile,'wb') as output:
                        output.write(b'%r'% name)
                except Exception as e:
                    pass
                    __log('587 write error Channelfile.keys= %r' % e)
            schedule = []
            __log('577 key= %r' % key)
            if key == '#text' :
                __log('579 key= %r' % key)
                datapanel = simplejson.loads(name)
                __log('581 datapanel= %r' % datapanel)
                try:
                    channelTitle= datapanel['props']['pageProps']['schedule']['channel']['title']
                    __log('582 channelTitle= %r' % channelTitle)
                    channelSlug = datapanel['props']['pageProps']['schedule']['channel']['slug']
                    __log('624 channelSlug= %r' % channelSlug)
                    items = datapanel['props']['pageProps']['schedule']['items']
                except Exception as e:
                    pass
                    __log('schedule Exception: %r' % e)
                    channelTitle = 'missing'
                    channelSlug = 'missing'
                    items = []   ### 2023-09-28
                for j in range(len(items)):
                    startTime = datapanel['props']['pageProps']['schedule']['items'][j]['startTime']
                    __log('628 startTime= %r' % startTime)
                    endTime = datapanel['props']['pageProps']['schedule']['items'][j]['endTime']
                    __log('630 endTime= %r' % endTime)
                    title = datapanel['props']['pageProps']['schedule']['items'][j]['title']
                    __log('634 title= %r' % title)
                    try:
                        description = datapanel['props']['pageProps']['schedule']['items'][j]['description']
                        __log('636 description= %r' % description)
                    except Exception as e:
                        pass
                        description = ''
                    schedule.append([channelTitle,channelSlug,startTime,endTime,title,description])
                
                __log('3 Schedule= %r' % schedule)
                Channelfile = os.path.join(datapath, station_id + masterkey + key + '.json')
                try:
                    with open(Channelfile,'wb') as output:
                        output.write(b'%r'% schedule)
                except Exception as e:
                    pass
                    __log('621 write error Channelfile.keys= %r' % e)
        return [channelTitle, channelSlug, schedule]
    else:
        return ['','','']

def StartChannelFromSchedule():
    __log("StartChannelFromSchedule Start")
    dayofweek = datetime.today().weekday()
    nowts = now()
    __log('nowts= %r' % nowts)
    actualschedule = 'schedule' + str(dayofweek)
    __log('actualschedule= %r' % actualschedule)      
    schedule = utils.ADDONgetSetting(actualschedule)
    __log('schedule= %r' % schedule) 
    schedules = schedule.split(',')
    __log('schedules ,= %r' % schedules) 
    for schedule in schedules:
        __log('schedule in loop= %r' % schedule) 
        if schedule :
            station_id= schedule.split('@')[0]
            __log('station_id= %r' % station_id) 
            starttime = schedule.split('-')[0].split('@')[1]
            __log('starttime= %r' % starttime) 
            starttimeTS = humanTS(starttime)
            __log('starttimeTS= %r' % starttimeTS) 
            endtime   = schedule.split('-')[1]
            __log('endtime= %r' % endtime) 
            endtimeTS = humanTS(endtime)
            __log('endtimeTS= %r' % endtimeTS) 
            __log('schedule C= %r, S= %r, E= %r' % (station_id, starttime, endtime))
            __log('schedule C= %r, S= %r, N= %r, E= %r' % (station_id, starttimeTS-nowts, nowts, endtimeTS-nowts))
            ProgramPlaying = utils.ADDONgetSetting('ProgramPlaying')
            ProgramPlayingScheduled = utils.ADDONgetSetting('ProgramPlayingScheduled')
            __log('\nProgramPlaying         = %r\nProgramPlayingScheduled= %r' % (ProgramPlaying,ProgramPlayingScheduled))
            if starttimeTS < nowts and nowts < endtimeTS :
                __log("StartChannelFromSchedule Start Scheduled Channel if not active")
                if  ProgramPlaying != station_id :
                    __log("StartChannelFromSchedule Start Scheduled Channel")
                    StartProgramLocal(station_id,starttimeTS)  
                utils.ADDONsetSetting('ProgramPlayingScheduled',station_id)
                return True
            ###StartProgram(station_id,starttimeTS)
    __log("StartChannelFromSchedule NO Start of Scheduled Channel")
    return False
    
def direct_play(url):
    __log("direct_play ["+url+"]")

    title = ""

    try:
        xlistitem = xbmcgui.ListItem( title, path=url)
    except Exception as e:
        pass
        xlistitem = xbmcgui.ListItem( title )
    xlistitem.setArt({ 'icon': "DefaultAudio.png", 'thumb' : "DefaultAudio.png" })
    ###xlistitem.setInfo( "audio", { 'title': title } )
    info_tag = ListItemInfoTag(xlistitem, 'music')
    infolabels = { 'title': channel.name, 'genre': 'Not Set' }
    info_tag.set_info(infolabels)
    __log('326 infolabels= %r' % infolabels)
    playlist = xbmc.PlayList( xbmc.PLAYLIST_MUSIC )
    player_type = xbmc.PLAYER_CORE_AUTO
    xbmcPlayer = xbmc.Player( player_type )
    xbmcPlayer.play(playlist) 
    
def StopAllStartProgramTimers():
    for radioEPGi in channelsDR.CHANNELS:   ### DR Channels
        station_id = radioEPGi.name
        nameAlarm = ADDONid + '-start-' + onlyAscii(str(station_id))
        xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
        __log('CancelAlarm(%s,True)' % nameAlarm)
    for radioEPGi in channels.CHANNELS:  ### Other channels
        station_id = radioEPGi.name
        nameAlarm = ADDONid + '-start-' + onlyAscii(str(station_id))
        xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
        __log('CancelAlarm(%s,True)' % nameAlarm)

def StartProgramLocal(station_id,timestamp):
    try:
        
        __log('StartProgramLocal ADDON %r - %r' % (ADDONname,ADDONid))
        __log('StartProgramLocal station_id= %r Start @ %r' % (station_id,datestr(timestamp,'%H:%M:%S')))
        __log('StartProgramLocal station_id= %r Start @ %r' % (station_id,timestamp))
        __log('StartProgramLocal station_id= %r Start @ %r' % (station_id,humantime(timestamp)))
        if not station_id:
            station_id = preferredstation
            __log('StartProgramLocal playEPG(DEFAULT station_id= %r)' % station_id)
        script = os.path.join(ADDONpath, 'startstation.py')    
        ###script = os.path.join(PATH, 'startstation.py')
        __log('StartProgramLocal script= %r' % script)
        nameAlarm = ADDONid + '-startLocal-' + onlyAscii(str(station_id)) 
        __log('StartProgramLocal nameAlarm= %r' % nameAlarm)
        delay = timestamp - now()
        if delay < 0:
            delay = 0
        __log('StartProgramLocal delay= %r' % delay)
        delayHMS = datestrdelta(delay,'%H:%M:%S')
        __log('StartProgramLocal delayHMS= %r' % delayHMS)
        if delay >= 0 and delay < 24*3600:
            cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),%s,silent)' % (nameAlarm, script, PATH,station_id,delayHMS)
            __log('StartProgramLocal cmd= %s' % cmd)
            
            ###__log('StartProgramLocal LastStartStation:' + station_id + ': '+datestr(TS(timestamp),'d%dh%Hm%M'))
            ###utils.ADDONsetSetting('LastStartStation',station_id + ': '+datestr(timestamp,'d%dh%Hm%Ms%S'))
            ###utils.ADDONsetSetting('LastStartStation',station_id + ': '+datestrdelta(timestamp,'d%dh%Hm%M'))
            utils.ADDONsetSetting('LastStartStation',station_id + ': '+datestr(timestamp,'d%dh%Hm%M'))
            utils.ADDONsetSetting('StartStation',station_id)
            xbmc.executebuiltin(cmd)  # Active
    except Exception as e:
        pass
        __log('StartProgramLocal(station_id= %r,timestamp= %r) ERROR: %r' % (station_id,timestamp,e))

def onlyAscii(unicrap):
    """This takes a UNICODE string and ignores all characters 128 (0x80) and higher
    """ 
    r = ''
    for i in unicrap:
        if ord(i) >= 0x80:
            pass
        else:
            r += str(i)
    return r

def showError(message):
    heading = 'Error in Findstation!'
    line1 = ADDON.getLocalizedString(30900)
    line2 = ADDON.getLocalizedString(30901)
    ###xbmcgui.Dialog().ok(heading, line1, line2, message)
    __log(heading+'\n'+line1+'\n'+line2+'\n'+message)

def sleep(sleeptime):
    __log('sleep(sleeptime= %r)' % (sleeptime))
    xbmc.sleep(sleeptime) 
   
def playEPG(idx):
    __log('playEPG(idx= %r)'% idx)
    try:
        u = urlopen(CHANNELS_URL)
        channelList = simplejson.loads(u.read())
        u.close()
    except Exception as  ex:
        showError(str(ex))
        return
    try:
        for channel in channelList:
            title = channel['Title']
            slug  = channel['Slug']
            if title[0:3] == 'DR ':
                title = title[3:]
            __log('playEPG(title= %r slug= %r)'% (title,slug))
            idxlower = idx.lower()
            if ('p4' in idxlower and idxlower == slug) or idxlower[:2] == slug[:2] and not 'p4' in idxlower:   
            ###if idx.lower() == slug:
                sourceUrl = channel['SourceUrl']
                logoImage = os.path.join(LOGO_PATH, sourceUrl[sourceUrl.rindex('/') + 1:] + '.png')
                if xbmcvfs.exists(logoImage):
                    item = xbmcgui.ListItem(title)
                    item.setArt({ 'icon': logoImage, 'thumb' : logoImage })
                    limage = logoImage
                else:
                    item = xbmcgui.ListItem(title)
                    item.setArt({ 'icon': ICON, 'thumb' : ICON })
                    limage = ICON
                item.setProperty('IsPlayable', 'true')
                item.setProperty('Fanart_Image', FANART)
                info_tag = ListItemInfoTag(item, 'music')
                infolabels = { 'title': title, 'genre': 'Not Set' }
                info_tag.set_info(infolabels)
                __log('1715 infolabels= %r' % infolabels)
                """
                item.setInfo(type='music', infoLabels={
                    'title': title
                })
                """
                url = None

                if 'StreamingServers' in channel:
                    for server in channel['StreamingServers']:
                        if 'LinkType' in server and server['LinkType'] == 'ICY' and 'Qualities' in server:
                            try:
                                url = server['Server'] + '/' + server['Qualities'][0]['Streams'][0]['Stream']
                                break
                            except:
                                pass
                __log('playEPG(url= %r)'% url)
                if url:
                    __log('play-ing-EPG(url= %r)'% url)
                    logoImage = os.path.join(LOGO_PATH, title + '.png')
                    item = xbmcgui.ListItem(path=url, thumbnailImage=logoImage)
                    info_tag = ListItemInfoTag(item, 'music')
                    infolabels = { 'title': title, 'genre': 'Not Set' }
                    info_tag.set_info(infolabels)
                    __log('459 infolabels= %r' % infolabels)
                    """
                    item.setInfo(type='music', infoLabels={
                        'title': title
                    })
                    """
                    xbmc.Player().play(url, item, True)
                    __log('play-ing-EPG-started(url= %r)'% url)
                break   ### Stop at first match
    except Exception as e:
        pass
        __log('PlayEPG ERROR: %r' % e)
    
try:
    program    = sys.argv[0]
    PATHargv   = sys.argv[1]
    Interval   = sys.argv[2]
    utils.ADDONsetSetting('LastFindStationStart',datestr(nowTS(),dateformat))
    ###addon.
    utils.shareLogs(False)  ### Only change in addon and not in this
    
except Exception as e:
    pass
    title    = 'FindStation'
    PATHargv = repr(e)
    Interval = '00:01:00'
    
try:
    __log('sys.argv= %r' % sys.argv)
    __log('os.environ= %s' % os.environ['OS'] ) #put in LOG
    __log('PATH= %r' % PATH)
    __log('PATHargv= %r' % PATHargv)
    __log('LOGO_PATH= %r' % LOGO_PATH)
    __log('ICON= %r' % ICON)
    __log('FANART= %r' % FANART)
    
    

except Exception as e:
    pass
    __log('ERROR data: %r' % e)
try:
    player = xbmc.Player()
    try:
        timebetweenupdates = utils.ADDONgetSetting('timebetweenupdates').split(':')
        __log('402 timebetweenupdates= %r' % timebetweenupdates)
        timebetweenupdatesH = int(timebetweenupdates[0])
        timebetweenupdatesM = int(timebetweenupdates[1])
        timebetweenupdatesS = int(timebetweenupdates[2])
        
        timeaftervideodummy = int(utils.ADDONgetSetting('timeaftervideo'))//(timebetweenupdatesH*3600 + timebetweenupdatesM*60 + timebetweenupdatesS)
        __log('timeaftervideodummy= %r' % timeaftervideodummy)
    except Exception as e:
        pass
        timeaftervideodummy = 5
        __log('timeaftervideodummy ERROR: %r' % e)
    
    if player.isPlayingAudio():
        music = xbmc.Player().getMusicInfoTag()
        title = music.getTitle()
        __log('music.getTitle()= %r' % title)
        __log('getMusicInfoTag()= %r' % music)
        __log('music.getURL= %r' % music.getURL())
        __log('music.getTitle= %r' % music.getTitle())
        __log('music.getArtist= %r' % music.getArtist())
        __log('music.getTrack= %r' % music.getTrack())
    else:
        __log('getMusicInfoTag()= %r' % 'Not playing Music!')
    
    if player.isPlayingVideo():
        PlayingVideo = True
        timeaftervideo = timeaftervideodummy
        try:
            utils.ADDONsetSetting('timeaftervideo',str(timeaftervideo*(timebetweenupdatesH*3600 + timebetweenupdatesM*60 + timebetweenupdatesS)))  ### Adjust to actual time based on timeupdateinterval
            utils.ADDONsetSetting('timeaftervideocounter',str(timeaftervideo))
        except Exception as e:
            pass
            __log('1 timeaftervideo ERROR: %r' % e)
        __log('PlayingVideo = True')
    else:
        PlayingVideo = False
        timeaftervideoI = utils.ADDONgetSetting('timeaftervideocounter')
        
        if timeaftervideoI == '':
            timeaftervideoI = timeaftervideodummy
        timeaftervideo = int(timeaftervideoI)
        timeaftervideo -= 1
        if timeaftervideo <= 0:
            timeaftervideo = 0
        utils.ADDONsetSetting('timeaftervideocounter',str(timeaftervideo))
        __log('PlayingVideo = False')
except Exception as e:
    pass
    PlayingVideo = False
    timeaftervideo = timeaftervideodummy
    try:
        utils.ADDONsetSetting('timeaftervideo',str(timeaftervideo*(timebetweenupdatesH*3600 + timebetweenupdatesM*60 + timebetweenupdatesS)))
    except Exception as e:
        pass
        __log('2 timeaftervideo ERROR: %r' % e)
    utils.ADDONsetSetting('timeaftervideocounter',str(timeaftervideo))
    __log('Is Palying Video Test ERROR: %r' % e)
"""
try:
    if utils.ADDONgetSetting('autovolumen') == 'true' and not PlayingVideo:
        __log('Set Volume')
        ### volumens = 100@6:30, 80@23:30
        testnow = now()
        today   = todayDate()
        ChannelVolumen = utils.getChannelVolumen(station_id)
        __log('Set testnow= %r, today= %r' % (humantime(testnow), humantime(today)))
        newvol = '100'
        volumens = utils.ADDONgetSetting('volumens').split(',')
        __log('Set Volumens= %r' % volumens)
        newvol = '0'
        for volumen in volumens:
            __log('Set Volumen= %r' % volumen)
            vol = volumen.split('@')
            volu = vol[0]
            if int(newvol) < int(volu):
                newvol = volu
                __log('newvol adjusted to: %r' % newvol)
        for volumen in volumens:
            __log('Set Volumen= %r' % volumen)
            vol = volumen.split('@')
            volu = vol[0]
            vtim = vol[1].split(':')
            __log('Set vtim= %r' % vtim)
            vtimadjusted = AdjustDateTime(today,vtim[0],vtim[1])
            __log('Set vtimadjusted= %r' % humantime(vtimadjusted))
            if vtimadjusted <= testnow:
                newvol = str(int(volu) * int(ChannelVolumen) / 100)
        xbmc.executebuiltin( "SetVolume(%s,showvolumebar)" % ( newvol ) )
        __log('Set Volumen now to %r' % newvol)
        utils.ADDONsetSetting('setvolumen',newvol)
except Exception as e:
    pass
    __log('Set Volumen ERROR: %r' % e)
"""   
try:
    __log('code part:Play Video= %r, timeaftervideo= %r' % (PlayingVideo,timeaftervideo))
    timer = now()
    __log('Timer at start! %r' % timer)
    if not PlayingVideo and timeaftervideo <= 0 :
        programswanted = utils.ADDONgetSetting('programswanted').split(',')
        __log('programswanted= %r' % programswanted)
        ProgramPlaying = utils.ADDONgetSetting('ProgramPlaying')
        __log('ProgramPlaying= at start %r' % ProgramPlaying)
        programsnogo   = utils.ADDONgetSetting('programsnogo').split(',')
        __log('programsnogo= %r' % programsnogo)
        preferredstation = utils.ADDONgetSetting('preferredstation') ### P4 København
        __log('preferredstation= %r' % preferredstation)
        backupstation    = utils.ADDONgetSetting('backupstation') ### P5
        __log('backupstation= %r' % backupstation)
        backupbackupstation    = utils.ADDONgetSetting('backupbackupstation') ### DR P6 Beat
        __log('backupbackupstation= %r' % backupbackupstation)
        ###utils.ADDONsetSetting('now','Now in UTC: %s' % nowS("%Y-%m-%dT%H:%M:%S%z"))
        __log('now= %r' % datestr(now(),"%Y-%m-%d %H:%M:%S"))
        utils.ADDONsetSetting('now','%s' % datestr(now(),"%Y-%m-%d %H:%M:%S"))
        utils.TestInfoTag(module)
        try:
            player = xbmc.Player()
            if not player.isPlaying():
                __log('Player is not playing at start')
                ###if ProgramPlaying == '':
                ProgramPlaying = preferredstation    ### If not playing - start preferred station
                __log('534 setSetting(programplaying= %r' % ProgramPlaying)
                utils.ADDONsetSetting('ProgramPlaying',ProgramPlaying)
                __log('ADDONgetSetting(ProgramPlaying 1= %r)' % utils.ADDONgetSetting('ProgramPlaying'))
                utils.StartProgram(ProgramPlaying,nowTS())
                sleep(2000)
            __log('ADDONgetSetting(ProgramPlaying 2= %r)' % utils.ADDONgetSetting('ProgramPlaying'))
            P4selected = utils.ADDONgetSetting('selectedp4station')
            P5selected = utils.ADDONgetSetting('selectedp5station')
            items = []
            WantedPrograms = []
            NogoPrograms   = []
            scheduleActive = True
            if not StartChannelFromSchedule():
                scheduleActive = False
                __log('After StartChannelFromSchedule NOT Started')
                items = []
                ###WantedPrograms = []
                ###NogoPrograms   = []
                for radioEPGi in channelsDR.CHANNELS:
                    station_id = radioEPGi.name
                    radioEPG  = radioEPGi.epg
                    __log('station_id= %r ' % station_id)
                    if 'P4' in station_id and not station_id == P4selected:
                        __log('Ignore Station: %r' % station_id)
                    elif 'P5' in station_id and not station_id == P5selected:
                        __log('Ignore Station: %r' % station_id)
                    else:
                        if not noepg and radioEPG != '':
                            
                            __log('765 station_id= %r, radioEPG= %r ' % (station_id,radioEPG))
                            
                            maxage= utils.max_age()
                            __log('maxage= %r' % maxage)
                            resp = utils.readChannelEPG(station_id,radioEPG,maxage)
                            
                            __log('1121 resp= %r' % resp)
                            
                            dataepg = resp
                            
                            ###Schedule = addon.getSchedule(dataepg,station_id)   ### returns channelTitle, channelSlug, [schedule]
                            Schedule = getSchedule(dataepg,station_id)   ### returns channelTitle, channelSlug, [schedule]
                            
                            stationname =  Schedule[0]
                            __log('546 stationname= %r' % stationname)
                            i = 0
                            for program in Schedule[2]:
                                ### schedule.append([channelTitle 0,channelSlug 1,startTime 2,endTime 3,title 4,description 5])
                                stop = program[3]
                                ### datestr(timestamp,format):   ### Date string UTC time %Y-%m-%dT%H:%M:%S%z
                                stop = datestr(TS(stop) - 120,dateformat)   ### adjust stop with 2 minute
                                __log('550 stop= %r' % stop)
                                start = program[2]
                                startactual = program[2]
                                __log('553 startactual= %r' % startactual)
                                if TS(stop) > nowTS():
                                    title = program[4]
                                    titleDesc = program[4]  + program[5]   ### 2023-05-24 Go/Nogo search in title and description
                                    __log('556 title= %r' % title)
                                    
                                    description= program[5]
                                    channel= program[0]                                    
                                    for wanted in programswanted:
                                        __log('581 onlyAscii(titleDesc= %r\nonlyAscii(wanted= %r' % (onlyAscii(titleDesc.lower()),onlyAscii(wanted.lower())))
                                        if onlyAscii(wanted.lower()) in onlyAscii(titleDesc.lower()):
                                            WantedPrograms.append([station_id,startactual,stop,title,description,channel])
                                    for notwanted in programsnogo:
                                        __log('585 onlyAscii(titleDesc= %r\nonlyAscii(notwanted= %r' % (onlyAscii(titleDesc.lower()),onlyAscii(notwanted.lower())))
                                        if onlyAscii(notwanted.lower()) in onlyAscii(titleDesc.lower()):
                                            NogoPrograms.append([station_id,startactual,stop,title,description,channel])
                            __log('620 \nWantedPrograms= %r\nNogoPrograms  = %r' % (WantedPrograms,NogoPrograms))
            __log('568 After StartChannelFromSchedule')
        except Exception as e:
            pass
            __log('571 radioEPG ERROR: %r' % e)
        __log('Timer at Programs %r' % (now() - timer))
        Programs = []
        if WantedPrograms != []:
            __log('575 WantedPrograms= %r' % WantedPrograms)
            for prog in WantedPrograms:  ### Dont accept nogo programs
                if NogoPrograms != []:
                    for noprog in NogoPrograms:
                        if noprog != prog:
                            Programs.append(prog)
                else:
                    Programs.append(prog)
        if NogoPrograms != []:
            __log('584 NogoPrograms= %r' % NogoPrograms)
            ProgramPlaying = utils.ADDONgetSetting('ProgramPlaying')
            for prog in NogoPrograms:
                ###if prog[0] == preferredstation and Programs == []: ### 2023-10-01 only change to backupstation if no wanted programs
                if (prog[0] == preferredstation or prog[0] == ProgramPlaying) and prog[0] != backupstation: 
                    Programs.append((backupstation,prog[1],prog[2],prog[3],prog[4],prog[5]))
                elif (prog[0] == preferredstation or prog[0] == ProgramPlaying) and prog[0] == backupstation:    ### 2023-11-01 
                    Programs.append((backupbackupstation,prog[1],prog[2],prog[3],prog[4],prog[5]))
        __log('588 Programs= %r' % Programs)
        Programs = sorted(Programs, key=takeSecond)   ###
        __log('697 Programs Sorted= %r' % Programs)
        NogoPrograms = sorted(NogoPrograms, key=takeSecond)
        __log('699 NogoPrograms Sorted= %r' % NogoPrograms)
        if Programs == []:
            ### Stop all timers to start programs
            StopAllStartProgramTimers()
        __log('594 after StopAllStartProgramTimers()')
        ProgramPlaying = utils.ADDONgetSetting('ProgramPlaying')
        ProgramPlayingScheduled = utils.ADDONgetSetting('ProgramPlayingScheduled')
        ###if ProgramPlaying == preferredstation :
        ###    utils.ADDONsetSetting('ProgramPlayingScheduled','')
        if ProgramPlayingScheduled == ProgramPlaying and not scheduleActive:
            ProgramPlaying = preferredstation
            __log('646 setSetting(programplaying= %r' % ProgramPlaying)
            utils.ADDONsetSetting('ProgramPlaying',ProgramPlaying)
            utils.ADDONresetSetting('ProgramPlayingScheduled','')
            utils.StartProgram(ProgramPlaying,nowTS())
        __log('ProgramPlaying=  %r' % ProgramPlaying)
        player = xbmc.Player()
        if not player.isPlaying():
            utils.StartProgram(ProgramPlaying,nowTS())
        if not player.isPlaying() and Programs == [] and not scheduleActive:
            __log('Player is not playing')
            if ProgramPlaying == '' :
                ProgramPlaying = preferredstation
            __log('656 setSetting(programplaying= %r' % ProgramPlaying)
            utils.ADDONsetSetting('ProgramPlaying',ProgramPlaying)
            utils.StartProgram(ProgramPlaying,nowTS())
        utils.setChannelVolumen(ProgramPlaying)
        utils.ADDONresetSetting('LastStartStation','')
        utils.ADDONresetSetting('LastEndStation','')
        if Programs != []:
            try:
                if Programs[0][0] != ProgramPlaying or not player.isPlaying() and not scheduleActive:
                    sleep(1)
                    ProgramPlaying = Programs[0][0]
                    utils.StartProgram(preferredstation,TS(Programs[0][2]))
                    utils.ADDONsetSetting('LastEndStation',preferredstation+ ': '+Programs[0][3]+ ' @ ' +datestr(TSl(Programs[0][2]),'d%dh%Hm%M'))
                    utils.StartProgram(Programs[0][0],TS(Programs[0][1]))
                    utils.ADDONsetSetting('LastStartStation',Programs[0][0] + ': '+Programs[0][3]+ ' @ ' +datestr(TSl(Programs[0][1]),'d%dh%Hm%M'))
                    
            except Exception as e:
                pass
                __log('Programs[0][0] ERROR: %r' % e)
                __log('No Program Change possible')
        else:
            __log('No Program Change needed')
        __log('Timer at LastFindStation %r' % (now() - timer))
        utils.ADDONsetSetting('LastFindStation',datestr(nowTS(),dateformat))
        CurrentWindowId = repr(xbmcgui.getCurrentWindowId())
        EPGWindowId = utils.ADDONgetSetting('EPGWindowId')
        __log('FindStation module= %r, CurrentWindowIdWindowId= %r, EPGWindowId= %r' % (module, CurrentWindowId, EPGWindowId))
        ###ContainerContent = xbmc.executebuiltin("Container.FolderName")
        ###utils.logdev('window','Container.FolderName= %r' % ContainerContent)
        ###currentWindow = xbmcgui.Window(xbmcgui.getCurrentWindowId())
        ###utils.logdev('window','currentWindow(%r)' % currentWindow)
        ###currentControlList = currentWindow.getFocusId()
        ###utils.logdev('window','currentControlList(%r)' % currentControlList)
        ###selectedListItem = currentWindow.getControl(currentControlList).getSelectedItem()
        ###utils.logdev('window','selectedListItem(%s)' % selectedListItem)
        __log('xbmc.Player().isPlayingAudio() ???')
        
        if xbmc.Player().isPlayingAudio():
            __log('xbmc.Player().isPlayingAudio()')
            music = xbmc.Player().getMusicInfoTag()
            title = music.getTitle()
            ###title = 'TEST'   ### TEST 2023-09-14  #####################################################
            __log('music.getTitle()= %r' % title)
            titleOLD = utils.ADDONgetSetting('titleOLD')
            __log('titleOLD= %r' % titleOLD)
            titleOLDtime = utils.ADDONgetSetting('titleOLDtime')
            __log('titleOLDtime= %r' % titleOLDtime)
            if titleOLD != title :
                __log('titleOLD != title %r != %r' % (titleOLD, title))
                utils.ADDONsetSetting('titleOLD',title)
                utils.ADDONsetSetting('titleOLDtime','%s' % datestr(now(),"%Y-%m-%d %H:%M:%S"))
            else:
                __log('titleOLD == title %r' % title)
            try:
                utils.ADDONsetSetting('titleOLDtimenow','%s' % datestr(now(),"%Y-%m-%d %H:%M:%S"))
                titleOLDtimenow = utils.ADDONgetSetting('titleOLDtimenow')
                __log('utils.ADDONgetSetting(titleOLDtimenow)= %r' % titleOLDtimenow)
                __log('utils.ADDONgetSetting(TSx(titleOLDtimenow))= %r' % TSx(titleOLDtimenow))
                __log('utils.ADDONgetSetting(titleOLDtime)= %r' % titleOLDtime)
                __log('utils.ADDONgetSetting(TSx(titleOLDtime))= %r' % TSx(titleOLDtime))  
                diff = TSx(titleOLDtimenow) - TSx(titleOLDtime)
                __log('TSx(titleOLDtimenow) - TSx(titleOLDtime)= %r' % diff)
            except Exception as e:
                pass
                __log('diff ERROR: %r' % e)
                diff = 0
            if titleOLD == title and diff > 10*60:  ### 10 minutes
                __log('Play Title is NOT updating')
                utils.ADDONsetSetting('titleupdating',ADDON.getLocalizedString(30413))
            else:
                __log('Play Title is updating')
                titletext = ADDON.getLocalizedString(30404)+ ': ' + title
                utils.ADDONsetSetting('titleupdating',titletext)   ### 2023-09-13 ' ' --> titletext
            __log('getMusicInfoTag()= %r' % music)
            __log('music.getURL= %r' % music.getURL())
            __log('music.getTitle= %r' % music.getTitle())
            __log('music.getArtist= %r' % music.getArtist())
            __log('music.getTrack= %r' % music.getTrack())
        else:
            __log('xbmc.Player().isPlayingAudio() NO NOT PLAYING')
            utils.StartProgram(utils.ADDONgetSetting('preferredstation'),nowTS())
            
        if CurrentWindowId == EPGWindowId:   ### and 1 == 0:   ### Disable refresh
            utils.logdev('window','ActivateWindow(%s)' % EPGWindowId.replace("'",""))
            xbmc.executebuiltin("ActivateWindow(%s)" % EPGWindowId.replace("'",""))
            xbmc.executebuiltin("Container.Refresh")
    else:
        __log('PlayingVideo or timeaftervideo > 0')
    __log('Find station finished')
except Exception as e:
    pass
    __log('ERROR: %r' % e)
__log('Find Station Total Finished')
__log('now()= %r' % now())
__log('timer= %r' % timer)
__log('Timer at Finished %r' % (now() - timer))