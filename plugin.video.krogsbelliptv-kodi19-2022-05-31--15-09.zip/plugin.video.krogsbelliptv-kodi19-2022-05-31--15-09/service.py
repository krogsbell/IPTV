#!/usr/bin/python
# -*- coding: utf-8 -*-
import recordings, utils, locking
import xbmcaddon, xbmc, datetime, os

import definition
ADDON      = definition.getADDON()
ADDONname  = ADDON.getAddonInfo('name')
xbmc.log('service.py in %s' % ADDON.getAddonInfo('name'))
module= 'service.py'

def log(infotext):
    if 'err' in infotext.lower():
        utils.logdev('err',module + ': ' + infotext)
    else:
        utils.logdev(module,infotext)  ### log all if module selected
        
utils.logdevreset()
log('err Start')
log('err Version= %r' % utils.version())    
log('err VersionDate= %r' % utils.versiondate())

try:
    ###reload(sys)  
    ###sys.setdefaultencoding('utf8')
    log('err defaultencoding= %r' % sys.getdefaultencoding())
    Platform = utils.rtmpdumpFilename()
    if not Platform == '':
        utils.notification('[COLOR green]Platform found and set[/COLOR]')
except:
    pass
    log('err FindPlatform FAILED')  # Put in LOG
    
log('err 34')
locking.recordUnlockAll()
log('err 36')
locking.scanUnlockAll()
log('err 38')
locking.markUnlockAll()
log('err 40')
recordings.backupSetupxml()
log('err 42')
recordings.restoreLastSetupXml()
log('err 44')
###utils.logdevreset()
recordings.cleanTempFiles()
recordings.ftvntvlist()  ### also made after EPG Update
log('err 48')
recordings.setAlarm('http-keep-alive-once','http-keep-alive.py','once','00:00:00','silent')
###nameAlarmKeep = ADDONname +'http-keep-alive-once' 
###scriptKeep   = os.path.join(ADDON.getAddonInfo('path'), 'http-keep-alive.py')
###cmdKeep = 'AlarmClock(%s,RunScript(%s,%s),00:00:00,silent)' % (nameAlarmKeep, scriptKeep, 'once')
###xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmKeep)
###xbmc.executebuiltin(cmdKeep)  # Active
log('err 41')
###recordings.downloadicons()
ADDON.setSetting('allmessages','')
ADDON.setSetting('RecursiveSearch','false')
ADDON.setSetting('RecordingFromOtherAddon','0')
ADDON.setSetting('Recordings','')   ### Reset setting with recording names
ADDON.setSetting('castsubpr','')    ### Reset cast info
ADDON.setSetting('castsubprcmd','')
log('err 49')
if ADDON.getSetting('enable_record')=='true':
    now = recordings.parseDate(datetime.datetime.now()) 
    startDate=now - datetime.timedelta(days = 10)
    endDate=now + datetime.timedelta(days = 100)
    recordingsActive=recordings.getRecordingsActive(startDate, endDate)
    log('err recordingsActive ' + repr(recordingsActive))
    log('err 56')
    try:
        recordings.backupDataBase()
        recordings.reschedule()
        utils.notification('[COLOR green]Reschedule Complete[/COLOR]')
        ADDON.setSetting('DebugRecording','false')
        log('err 62')
    except:
        pass
        utils.notification('[COLOR red]Reschedule failed:[/COLOR] Check your planned recordings! - Recording Debug has been set')
        ADDON.setSetting('DebugRecording','true')
        log('err 67')
        xbmc.sleep(5000)

