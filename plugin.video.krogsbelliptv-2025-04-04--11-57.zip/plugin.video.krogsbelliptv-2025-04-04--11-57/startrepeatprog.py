#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import sys
import xbmc, xbmcvfs
import utils
import definition
from recordings import setAlarm

args = sys.argv
ADDON       = definition.getADDON()
ADDONid     = definition.ADDONgetAddonInfo('id')
ADDONname   = definition.ADDONgetAddonInfo('name')
datapath    = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
progpath    = definition.ADDONgetAddonInfo('path')
module      = 'startrepeatprog.py'
utils.logdev(module,'Start - args= %r' % args)

interval = args[1].replace('h',':').replace('m',':')
utils.logdev(module,'interval= %r' % args[1])
utils.notification('Start EPG import with interval '+args[1] + 's')
nameAlarmEPGfirst = ADDONname +'nameEPGfirst' 
nameAlarmEPGt = ADDONname +'nameEPGt' 
scriptEPGt   = os.path.join(definition.ADDONgetAddonInfo('path'), 'updateepg.py')
cmdEPGfirst = 'AlarmClock(%s,RunScript(%s,%s),00:00:00,silent)' % (nameAlarmEPGfirst, scriptEPGt, 'hourly')
cmdEPGt = 'AlarmClock(%s,RunScript(%s,%s),%s,loop,silent)' % (nameAlarmEPGt, scriptEPGt, 'hourly',interval)
utils.logdev(module,'cmdEPGfirst= %r' % cmdEPGfirst)
utils.logdev(module,'cmdEPGt= %r' % cmdEPGt)
###xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmEPGfirst)
###xbmc.executebuiltin(cmdEPGfirst)  # Active
###xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmEPGt)
###xbmc.executebuiltin(cmdEPGt)  # Active
setAlarm('nameEPGfirst', scriptEPGt, 'hourly', '00:00:00',options='silent')
setAlarm('nameEPGt', scriptEPGt, 'hourly',interval,options='loop,silent')
