#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmc, xbmcvfs
# For Python 3.0 and later
from urllib.request import urlopen
import sys
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import definition
import utils
import recordings
import glob
import os
import locking
    
try:
    ADDON     = definition.getADDON()
    ADDONid   = definition.ADDONgetAddonInfo('id')
    ADDONname = definition.ADDONgetAddonInfo('name')
    datapath  = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
    progpath  = definition.ADDONgetAddonInfo('path')
    module    = 'cleanup.py'
    utils.logdev(module,'error cleanup Started')
    utils.logdev(module,'error sys.argv= %r' % sys.argv)
    alarmName = 'cleanup'
    marker    = 'once'
    try:
        marker = sys.argv[1]
    except Exception as e:
        pass
        utils.logdev(module,'30 ERROR: %r' % e)
    alarmName = alarmName + '-' + marker   
    recordings.updateAlarm(alarmName)
    utils.logdev(module,'error cleanup after updateAlarm')
    titext = '*.tit'
    try:
        path = definition.ADDONgetSetting('record_path')
        ###path = xbmcvfs.translatePath(definition.ADDONgetSetting('record_path'))
        utils.logdev(module,'error  path= %r' % path)
        files =  glob.glob(os.path.join(path, titext))
        utils.logdev(module,'error  files= %r' % files)
        for f in files:
            utils.logdev(module,'error f: %r' % f)
            fl = f.replace('.tit','.log').replace('[','?').replace(']','?')
            f = f.replace('.tit','*').replace('[','?').replace(']','?')
            utils.logdev(module,'error f.replaced= %r' % f)
            allfiles = glob.glob(f)
            logfiles = glob.glob(fl)
            utils.logdev(module,'error len(allfiles)= %r' % len(allfiles))
            utils.logdev(module,'error .tit file siblings: %r' % allfiles)
            videoext = definition.ADDONgetSetting('extorgcollection').split(',')
            VideoExt = ''
            for vext in videoext:
                vext = '.' + vext
                utils.logdev(module,'error vext= %r' % vext)
                if VideoExt == '' :
                    for file in allfiles:
                        utils.logdev(module,'error file= %r' % file)
                        extension = os.path.splitext(file)[1]
                        utils.logdev(module,'error extension= %r' % extension)
                        if extension == vext :
                            VideoExt = vext
            utils.logdev(module,'error file has video %r with ext %r' % (f,VideoExt))
            if VideoExt == '' :
                logdeleted = True
                for file in logfiles:
                    utils.logdev(module,'error DELETE FILE= %r' % file)
                    destination = definition.ADDONgetSetting('backup_path')
                    utils.copyFiles(file,destination)
                    locking.deleteLockFile(file)
                    if os.path.isfile(file):
                        logdeleted = False
                if logdeleted:
                    for file in allfiles:
                        utils.logdev(module,'error DELETE FILE= %r' % file)
                        destination = definition.ADDONgetSetting('backup_path')
                        utils.copyFiles(file,destination)
                        locking.deleteLockFile(file)
    except Exception as  e:
        pass
        utils.logdev(module, 'Error Exception in cleanup= %r' % e)
        
except Exception as  e:
    pass
    utils.logdev(module, 'Exception in cleanup= %s ERROR= %s' % (repr(link),repr(e)))
utils.logdev(module,'Ended')

