#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#      Copyright (C) 2014 Tommy Winther
#      http://tommy.winther.nu
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
import pickle
import os
import sys
import urlparse
import re
import datetime
import time
import _strptime

import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin

import tvapi
import tvgui
import buggalo

import shutil
import base64

###from operator import itemgetter
ADDON      = xbmcaddon.Addon()
ADDONname  = ADDON.getAddonInfo('name')
ADDONid    = ADDON.getAddonInfo('id')
xbmc.log('DRNU: Start')

def RecordFlagSet(sourceApp,flag):   ### 2018-11-08
    if sourceApp == '':
        ADDONsource = xbmcaddon.Addon()
    else:
        ADDONsource = xbmcaddon.Addon(sourceApp)
    datapath = xbmc.translatePath(ADDONsource.getAddonInfo('profile'))
    recordflag = os.path.join(datapath, 'RecordFlag.txt')
    FlagFile = open(recordflag, 'w')
    # Write to our text file the information we have provided and then goto next line in our file.
    # LogDev.write(repr(module) + ': ' + repr(message) + '\n')
    FlagFile.write(flag)
    FlagFile.close()

def RecordFlagGet(sourceApp):   ### 2018-11-08
    if sourceApp == '':
        ADDONsource = xbmcaddon.Addon()
    else:
        ADDONsource = xbmcaddon.Addon(sourceApp)
    datapath = xbmc.translatePath(ADDONsource.getAddonInfo('profile'))
    recordflag = os.path.join(datapath, 'RecordFlag.txt')
    if os.path.isfile(recordflag):
        FlagFile = open(recordflag, 'r')
        # Write to our text file the information we have provided and then goto next line in our file.
        # LogDev.write(repr(module) + ': ' + repr(message) + '\n')
        flag = FlagFile.read()
    else:
        flag = ''
    return flag

def logdev(module,message):
    nowHMS=datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    datapath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
    addonlog = os.path.join(datapath, 'addon.log')
    xbmc.log('DRNU: logdev before reset')
    logdevreset(addonlog)
    # create lock file
    LogDev = open(addonlog, 'a')
    # Write to our text file the information we have provided and then goto next line in our file.
    # LogDev.write(repr(module) + ': ' + repr(message) + '\n')
    LogDev.write(nowHMS + ' ' + module + ': ' + message + '\n')

def logdevreset(addonlog):
    xbmc.log('DRNU: logdevreset')
    addonOLDlog = addonlog.replace('.log','OLD.log')
    try:
        size = os.path.getsize(addonlog)
        xbmc.log('DRNU: addon.log size= %r' % size)
        maxsize = 1 * 1024 * 1024 # 1 MB 
        xbmc.log('DRNU: log size= %r' % size)
        if os.path.exists(addonlog) and size > maxsize:
            shutil.copyfile(addonlog, addonOLDlog)
            tries    = 0
            maxTries = 10
            maxSleep = 50
            while os.path.exists(addonlog) and tries < maxTries:
                try:
                    os.remove(addonlog)
                    break
                except:
                    xbmc.sleep(maxSleep)
                    tries = tries + 1
    except Exception, e:
        pass
        xbmc.log('DRNU: Reset addon.log failed: %r' % e)
        
def __log(text):
    logdev('addon.py',text.encode("utf-8"))
    
def printL(message):
        xbmc.log('DRNU: %r' % message)
        logdev('addon.py',message.encode("utf-8"))

def krogsbellAddons():
    ### Krogsbell IPTV addons have the file 'definition.py'
    addons = []
    try:
        SwFileFolder = os.path.join(xbmc.translatePath('special://masterprofile/'), 'addon_data','krogsbell.switchaddons')
        SwFile = os.path.join(SwFileFolder,'switchaddons.txt')
        if not os.path.exists(SwFileFolder):
            os.mkdir(SwFileFolder)
            open(SwFile, 'a').close()
        printL('SwFile= %r' % SwFile)
        switchfile = open(SwFile, 'r')
        addonsO = switchfile.read()
        switchfile.close() 
        if not ADDONid in addonsO:
            addonsO += '\n' + ADDONrefer + ':' + ADDONid
            addonsO = addonsO.replace('\n\n\n\n','\n').replace('\n\n\n','\n').replace('\n\n','\n')
            LF = open(SwFile, 'w')
            LF.write(addonsO)
            LF.close()
        ADDON.setSetting('switchaddons',addonsO)
        if addonsO != '' :
            addonsO = addonsO.split('\n')
            for addon in addonsO:
                if addon != '':
                    newaddon = addon.split(':')
                    if newaddon[1] != ADDONid:
                        try:
                            testAddon = xbmcaddon.Addon(id=newaddon[1])
                            pathTOaddon = os.path.join(xbmc.translatePath('special://home/addons'), newaddon[1])
                            if os.path.exists(pathTOaddon):
                                addons.append(newaddon)
                        except Exception,e:
                            pass
                            printL('testAddon FAILED= %r' % e)
    except Exception,e:
        pass
        addons.append(['ERROR',repr(e)])
    ###[['GlowIPTV','plugin.video.glowiptv.rec'],['DR NU','plugin.video.drnu'],['BBC iPlayer','plugin.video.iplayerwww'],['ITV Player','plugin.video.itv']]
    addons = sorted(addons)
    choises = []
    for choise in addons:
       choises.append(choise[0] + ': ' + choise[1])
    return choises

def krogsbellAddonsSelect():
    printL('krogsbellAddonsSelect: Start')
    choisesall = krogsbellAddons()
    choises    = []
    progpath   = ADDON.getAddonInfo('path')
    datapath   = xbmc.translatePath(ADDON.getAddonInfo('profile'))
    for choise in choisesall:
        try:
            newADDONid = choise.replace(': ',':').split(':')[1]
            progpathnew= os.path.join(progpath.replace(ADDONid,newADDONid),'definition.py')
            printL('progpathnew= %r' % progpathnew)
            if os.path.exists(progpathnew):
                ### ...\addon_data\...\storage\channels.json
                datapathnew= os.path.join(datapath.replace(ADDONid,newADDONid),'storage','channels.json')
                printL('datapathnew= %r' % datapathnew)
                if not os.path.exists(datapathnew):
                    targetADDON = xbmcaddon.Addon(id=newADDONid)
                    enable_record = targetADDON.getSetting('enable_record')
                    printL('targetADDON= %r, enable_record= %r'% (targetADDON, enable_record))            
                    if enable_record == 'true':
                        printL('choises.append(choise)= %r' % choise)
                        choises.append(choise)
        except Exception,e:
            pass
            choises.append('Error: %r' % e)
    selected = -1
    if len(choises) > 0:
        dialog = xbmcgui.Dialog()
        selected = dialog.select(ADDON.getAddonInfo('name') + ' - Select the Addon to Record Episode:', choises) ####################
    if selected != -1:
        printL('selected Addon = %r ' % choises[selected])
        return choises[selected].replace(': ',':').split(':')[1]
    return ''

def krogsbell(name,url,there_are_subtitles,subtitles_file):
    ###def PLAY_STREAM_HLS_LIVE(name,url,iconimage):
    ### Krogsbell 2019-01-14 VVVVVVV#####################################################
    printL('krogsbell(name=%r\n,url=%r\n,there_are_subtitles=%r\n,subtitles_file=%r\n)'% (name,url,there_are_subtitles,subtitles_file))
    cmd  = 'XBMC.Notification(%s, %s, %r, %s)' % (name, url, 10000, '') 
    xbmc.executebuiltin(cmd) 
    description = 'From DRNU Addon'
    if there_are_subtitles == 1:
        subtitles_url = subtitles_file
    else:
        subtitles_url = ''
    name = name.replace(',','') 
    printL('replace , in name with (nothing) name= %r' % name)
    iconimage = 'DefaultVideo.png'
    ###xbmc.log('ITV Player url= ' + repr(url))
    ###URI='plugin://plugin.video.wozboxntv/?url=url&mode=2011&name=BBC iPlayer WWW - '+name+'&uri='+url.replace(',','###').replace('=','BBabAA')+'&description=BBC iPlayer: '+description
    krogsbellAddonID = krogsbellAddonsSelect()
    recording = False
    if krogsbellAddonID != '' :
        if not '&description=' in url:
            ###URI='plugin://'+krogsbellAddonID+'/?url=url&mode=2011&name='+name+' [ITV Player]&uri='+(url+'&description='+description+'&subtitlesurl='+subtitles_url+'&subtitlesoffset=0').replace(' ','AAabBB').replace('?','aAabBb').replace('=','BBabAA').replace(',','###').replace('&','AaAaA')
            URI='plugin://'+krogsbellAddonID+'/?url=url&mode=2011&name=b64'+base64.b64encode(name+' [ITV Player]')+'&uri=b64'+base64.b64encode(url+'&description=' + description+'&subtitlesurl='+subtitles_url+'&subtitlesoffset=0')
            ### &description=b64' + base64.b64encode(description)
        else:
            URI='plugin://'+krogsbellAddonID+'/?url=url&mode=2011&name=b64'+base64.b64encode(name+' [ITV Player]')+'&uri=b64'+base64.b64encode(url+'&subtitlesurl='+subtitles_url+'&subtitlesoffset=0')
        xbmc.log('ITV iPlayer URI= ' + repr(URI))
        printL('URI= %r' % URI)
        ###URI= URI.split('?')[0] + '?' + URI.split('?')[1]
        ###URI+='&description='+description
        ###xbmc.log('ITV iPlayer URI= ' + repr(URI))
        ###printL(URI)
        try:
            xbmc.executebuiltin('XBMC.RunPlugin(%s)' % URI)
            recording = True
        except:
            pass
            printL('No valid Addon to record stream!')
            printL('Play Video')
    return recording


def recordingaddons():
    try:
        addons = []
        SwFileFolder = os.path.join(xbmc.translatePath('special://masterprofile/'), 'addon_data','krogsbell.switchaddons')
        SwFile = os.path.join(SwFileFolder,'switchaddons.txt')
        if not os.path.exists(SwFileFolder):
            os.mkdir(SwFileFolder)
            open(SwFile, 'a').close()
        __log('SwFile= %r' % SwFile)
        switchfile = open(SwFile, 'r')
        addonsO = switchfile.read()
        switchfile.close() 
        if addonsO != '' :
            addonsO = addonsO.split('\n')
            for addon in addonsO:
                if addon != '':
                    __log('addon= %r' % addon)
                    newaddon = addon.split(':')
                    if newaddon[1] != ADDONid:
                        if 'video.' in newaddon[1]:
                            pathTOaddon = os.path.join(xbmc.translatePath('special://home/addons'), newaddon[1])
                            if os.path.exists(pathTOaddon):
                                addons.append(newaddon)
    except Exception,e:
        pass
        addons.append(['ERROR',repr(e)])
    addons = sorted(addons)
    return addons

def TS(timestr):
    ### time format 2019-05-21T22:05:00Z
    time_tuple = time.strptime(timestr, "%Y-%m-%dT%H:%M:%SZ")
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def now():   ### Local time
    dt_obj= datetime.datetime.now()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
   
def nowTS():   ### UTC time
    dt_obj= datetime.datetime.utcnow()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def nowS(format):   ### Now date string UTC time
    time_tuple = time.localtime(nowTS())
    date_str = time.strftime(format, time_tuple)
    return(date_str)
    
def datestr(timestamp,format):   ### Date string UTC time %Y-%m-%dT%H:%M:%SZ
    time_tuple = time.localtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)

def datestrdelta(timestamp,format):   ### Now date string UTC time %Y-%m-%dT%H:%M:%SZ
    time_tuple = time.gmtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)
  
def installOPENaddon(IDdoADDON):    
    pathTOaddon = os.path.join(xbmc.translatePath('special://home/addons'), IDdoADDON)
    __log('pathTOaddon= %r' % pathTOaddon)
    if not os.path.exists(pathTOaddon)==True:
        xbmc.executebuiltin('InstallAddon(%s)' % (IDdoADDON))
        xbmc.executebuiltin('SendClick(11)'), time.sleep(2), xbmcgui.Dialog().ok("Add-on Install", "The addon was not present. Please wait for installation to finish.")
    else:
        pass
    if os.path.exists(pathTOaddon)==True:
        xbmc.executebuiltin('RunAddon(%s)' % (IDdoADDON))
        __log('RunAddon(%s)' % (IDdoADDON))
    else:
        xbmcgui.Dialog().ok("Add-on Error", "Could not install or open add-on. Please try again...")
  
def switch(x):
    findP = ADDON.getSetting('LastSwitch')  ### datestr(nowTS(),'h%Hm%Ms%S'))
    if findP == '':
        delta = 10
    else:
        delta = nowTS() - TS(findP)
    __log('delta= %r' % delta)
    if delta > 9:
        ADDON.setSetting('LastSwitch',datestr(nowTS(),'%Y-%m-%dT%H:%M:%SZ'))
        dialog = xbmcgui.Dialog()
        addons = []
        try:
            SwFileFolder = os.path.join(xbmc.translatePath('special://masterprofile/'), 'addon_data','krogsbell.switchaddons')
            SwFile = os.path.join(SwFileFolder,'switchaddons.txt')
            if not os.path.exists(SwFileFolder):
                os.mkdir(SwFileFolder)
                open(SwFile, 'a').close()
            __log('SwFile= %r' % SwFile)
            switchfile = open(SwFile, 'r')
            addonsO = switchfile.read()
            switchfile.close() 
            if not ADDONid in addonsO:
                addonsO += '\n' + ADDONname + ':' + ADDONid
                addonsO = addonsO.replace('\n\n\n\n','\n').replace('\n\n\n','\n').replace('\n\n','\n')
                LF = open(SwFile, 'w')
                LF.write(addonsO)
                LF.close()
            ADDON.setSetting('switchaddons',addonsO)
            if addonsO != '' :
                addonsO = addonsO.split('\n')
                for addon in addonsO:
                    if addon != '':
                        __log('addon= %r' % addon)
                        newaddon = addon.split(':')
                        if newaddon[1] != ADDONid:
                            try:
                                testAddon = xbmcaddon.Addon(id=newaddon[1])
                                pathTOaddon = os.path.join(xbmc.translatePath('special://home/addons'), newaddon[1])
                                if os.path.exists(pathTOaddon):
                                    addons.append(newaddon)
                            except Exception,e:
                                pass
                                __log('testAddon FAILED= %r' % e)
        except Exception,e:
            pass
            addons.append(['ERROR',repr(e)])
        addons = sorted(addons)
        choises = []
        for choise in addons:
           choises.append(choise[0] + ': ' + choise[1])
        if len(choises) > 0:
            selected = dialog.select(ADDON.getAddonInfo('name') + ' - Select an Addon to switch to:', choises)
            if selected != -1:
                try:
                    __log('selected Addon= %r - %r' % (addons[selected][0],addons[selected][1]))
                    IDdoADDON = addons[selected][1]
                    targetADDON = xbmcaddon.Addon(id=IDdoADDON)
                    name = targetADDON.getAddonInfo('name')
                    datapath = xbmc.translatePath(targetADDON.getAddonInfo('profile'))
                    __log('Start Addon= %r ID=%r' % (name,IDdoADDON))
                    
                    
                    ###installOPENaddon(IDdoADDON)
                    
                    xbmc.executebuiltin('Dialog.Close(busydialog)')   ### 2019-09-03 needed to allow switch addon
                    ###cmd = "ActivateWindow(10025,'plugin://%s/default',return)"% IDdoADDON
                    ###cmd = "ActivateWindow(10025,'plugin://%s/default')"% IDdoADDON
                    ###cmd = 'RunPlugin(%s)' % IDdoADDON
                    cmd = 'RunAddon(%s)' % IDdoADDON
                    __log('cmd= %r' % cmd)
                    response = xbmc.executebuiltin(cmd)
                    __log('0 response= %r' % response)
                    cmd = "Action(Back,%s)" % xbmcgui.getCurrentWindowId()
                    response = xbmc.executebuiltin(cmd)
                    __log('1 response= %r' % response)
                    ###cmd = "Action(ParentDir,%s)" % xbmcgui.getCurrentWindowId()
                    ###xbmc.executebuiltin("XBMC.Container.Update(path,replace)")
                    ###xbmc.executebuiltin("XBMC.ActivateWindow(Home)")
                    
                except Exception,e:
                    pass
                    __log('ERROR switch addon: <%r>' % e)
     
class DrDkTvAddon(object):
    
    def __init__(self):
        self.api = tvapi.Api(CACHE_PATH)
        self.favorites = list()
        self.recentlyWatched = list()

        self.menuItems = list()
        runScript = "RunAddon(plugin.video.drnu,?show=areaselector&random=%d)" % HANDLE
        self.menuItems.append((ADDON.getLocalizedString(30511), runScript))


    def _save(self):
        # save favorites
        self.favorites.sort()
        pickle.dump(self.favorites, open(FAVORITES_PATH, 'wb'))

        self.recentlyWatched = self.recentlyWatched[0:25]  # Limit to 25 items
        pickle.dump(self.recentlyWatched, open(RECENT_PATH, 'wb'))

    def _load(self):
        # load favorites
        if os.path.exists(FAVORITES_PATH):
            try:
                self.favorites = pickle.load(open(FAVORITES_PATH, 'rb'))
            except Exception:
                pass

        # load recently watched
        if os.path.exists(RECENT_PATH):
            try:
                self.recentlyWatched = pickle.load(open(RECENT_PATH, 'rb'))
            except Exception:
                pass

    def showAreaSelector(self):
        gui = tvgui.AreaSelectorDialog()
        gui.doModal()
        areaSelected = gui.areaSelected
        del gui

        if areaSelected == 'none':
            pass
        elif areaSelected == 'drtv':
            self.showMainMenu()
        else:
            items = self.api.getChildrenFrontItems('dr-' + areaSelected)
            #xbmc.executebuiltin('Container.SetViewMode(500)')
            self.listSeries(items)

    def showMainMenu(self):
        items = list()
        # Live TV
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30027), iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'livetv.png'))
        item.setProperty('Fanart_Image', FANART_IMAGE)
        item.addContextMenuItems(self.menuItems, False)
        items.append((PATH + '?show=liveTV', item, True))

        # A-Z Program Series
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30000), iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'all.png'))
        item.setProperty('Fanart_Image', FANART_IMAGE)
        item.addContextMenuItems(self.menuItems, False)
        items.append((PATH + '?show=listAZ', item, True))

        # Latest
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30001), iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'all.png'))
        item.setProperty('Fanart_Image', FANART_IMAGE)
        item.addContextMenuItems(self.menuItems, False)
        items.append((PATH + '?show=latest', item, True))

        # Premiere
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30025), iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'new.png'))
        item.setProperty('Fanart_Image', FANART_IMAGE)
        item.addContextMenuItems(self.menuItems, False)
        items.append((PATH + '?listVideos=%s' % tvapi.SLUG_PREMIERES, item, True))

        # Themes / Repremiere
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30028), iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'all.png'))
        item.setProperty('Fanart_Image', FANART_IMAGE)
        item.addContextMenuItems(self.menuItems, False)
        items.append((PATH + '?show=themes', item, True))

        # Most viewed
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30011), iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'eye.png'))
        item.setProperty('Fanart_Image', FANART_IMAGE)
        item.addContextMenuItems(self.menuItems, False)
        items.append((PATH + '?show=mostViewed', item, True))

        # Spotlight
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30002), iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'star.png'))
        item.setProperty('Fanart_Image', FANART_IMAGE)
        item.addContextMenuItems(self.menuItems, False)
        items.append((PATH + '?show=highlights', item, True))

        # Search videos
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30003), iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'search.png'))
        item.setProperty('Fanart_Image', FANART_IMAGE)
        item.addContextMenuItems(self.menuItems, False)
        items.append((PATH + '?show=search', item, True))

        # Recently watched Program Series
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30007), iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'eye-star.png'))
        item.setProperty('Fanart_Image', FANART_IMAGE)
        item.addContextMenuItems(self.menuItems, False)
        items.append((PATH + '?show=recentlyWatched', item, True))

        # Favorite Program Series
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30008), iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'plusone.png'))
        item.setProperty('Fanart_Image', FANART_IMAGE)
        items.append((PATH + '?show=favorites', item, True))
        item.addContextMenuItems(self.menuItems, False)
        
        # Switch Krogsbell Addons
        doyouhavekrogsbellAddons = krogsbellAddons()
        printL('doyouhavekrogsbellAddons= %r' % doyouhavekrogsbellAddons)
        if not 'error' in str(krogsbellAddons()).lower():
            item = xbmcgui.ListItem(ADDON.getLocalizedString(30030), iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'eye-star.png'))
            item.setProperty('Fanart_Image', FANART_IMAGE)
            items.append((PATH + '?switch=x', item, True))
            item.addContextMenuItems(self.menuItems, False)

        xbmcplugin.addDirectoryItems(HANDLE, items)
        xbmcplugin.endOfDirectory(HANDLE)

    def showFavorites(self):
        self._load()
        if not self.favorites:
            xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'), ADDON.getLocalizedString(30013))
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        else:
            series = []
            for slug in self.favorites:
                printL('self.favorites:slug= %r' % slug)
                series.extend(self.api.searchSeries(slug))
                printL('self.favorites:series= %r' % series)
            ###self.listSeriesFlat(series, addToFavorites=False) 
            self.listSeries(series, addToFavorites=False)  
            
            """
            try:
                    series.extend(self.api.searchSeries(slug))
                    item = self.api.getEpisode(slug)
                    series.append(item)
                except Exception,e:
                    pass
                    printL('self.favorites:slug error= %r' % e)
            self.listEpisodes(series)
                series.extend(self.api.searchSeries(slug))
            self.listSeries(series, addToFavorites=False)
            """
    def showRecentlyWatched(self):
        self._load()
        videos = list()
        for slug in self.recentlyWatched:
            printL('self.showRecentlyWatched:slug= %r' % slug)
            try:
                item = self.api.getEpisode(slug)
                if item is None:
                    self.recentlyWatched.remove(slug)
                else:
                    videos.append(item)
            except tvapi.ApiException:
                # probably a 404 - non-existent slug
                self.recentlyWatched.remove(slug)

        self._save()
        if not videos:
            xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'), ADDON.getLocalizedString(30013), ADDON.getLocalizedString(30020))
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        else:
            self.listEpisodes(videos)

    def showLiveTV(self):
        items = list()
        for channel in self.api.getLiveTV():
            if channel['WebChannel']:
                continue

            server = None
            for streamingServer in channel['StreamingServers']:
                if streamingServer['LinkType'] == 'HLS':
                    server = streamingServer
                    break

            if server is None:
                continue

            item = xbmcgui.ListItem(channel['Title'], iconImage=channel['PrimaryImageUri'])
            item.setProperty('Fanart_Image', channel['PrimaryImageUri'])
            item.addContextMenuItems(self.menuItems, False)

            url = server['Server'] + '/' + server['Qualities'][0]['Streams'][0]['Stream']
            items.append((url, item, False))

        items = sorted(items, lambda mine, yours: cmp(mine[1].getLabel().replace(' ', ''), yours[1].getLabel().replace(' ', '')))

        xbmcplugin.addDirectoryItems(HANDLE, items)
        xbmcplugin.endOfDirectory(HANDLE)

    def showAZ(self):
        # All Program Series
        iconImage = os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'all.png')

        items = list()
        for programIndex in self.api.getProgramIndexes():
            item = xbmcgui.ListItem(programIndex['Title'], iconImage=iconImage)
            item.setProperty('Fanart_Image', FANART_IMAGE)
            item.addContextMenuItems(self.menuItems, False)

            url = PATH + '?listProgramSeriesByLetter=' + programIndex['_Param']
            items.append((url, item, True))

        items = sorted(items) ### 2018-01-02
        xbmcplugin.addDirectoryItems(HANDLE, items)
        xbmcplugin.endOfDirectory(HANDLE)

    def showThemes(self):
        items = list()
        for theme in self.api.getThemes():
            item = xbmcgui.ListItem(theme['ThemeTitle'], iconImage=theme['PrimaryImageUri'])
            item.setProperty('Fanart_Image', theme['PrimaryImageUri'])
            item.addContextMenuItems(self.menuItems, False)

            url = PATH + '?listVideos=' + theme['ThemeSlug']
            items.append((url, item, True))

        items = sorted(items) ### 2018-01-02
        xbmcplugin.addDirectoryItems(HANDLE, items)
        xbmcplugin.endOfDirectory(HANDLE)

    def searchSeries(self):
        keyboard = xbmc.Keyboard('', ADDON.getLocalizedString(30003))
        keyboard.doModal()
        if keyboard.isConfirmed():
            keyword = keyboard.getText()
            self.listSeries(self.api.getSeries(keyword)) 

    def listSeries(self, items, addToFavorites=True):
        if not items:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            if not addToFavorites:
                xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'), ADDON.getLocalizedString(30013),
                                    ADDON.getLocalizedString(30018), ADDON.getLocalizedString(30019))
            else:
                xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'), ADDON.getLocalizedString(30013))
        else:
            directoryItems = list()
            items = sorted(items) ### 2018-01-02
            for item in items:
                menuItems = list(self.menuItems)
                printL('listSeries item= %r' % item)
                
                try:
                    if item['PrimaryAsset']['RestrictedToDenmark']:
                        RestrictedToDenmark = True
                    else: 
                        RestrictedToDenmark = False
                except Exception,e:
                    pass
                    printL('RestrictedToDenmark ERROR: %r' % e)
                    RestrictedToDenmark = False
                if RestrictedToDenmark == True:
                    RestrictedToDenmarkMarker = ' [COLOR red]Kun DK[/COLOR]'
                else:
                    RestrictedToDenmarkMarker = ''
                
                try:
                    if self.favorites.count(item['SeriesTitle']) > 0:
                        ###runScript = "XBMC.RunPlugin(plugin://plugin.video.drnu/?delfavorite=%s)" % (item['SeriesTitle']+RestrictedToDenmarkMarker).replace('&', '%26').replace(',', '%2C')
                        runScript = "XBMC.RunPlugin(plugin://plugin.video.drnu/?delfavorite=%s)" % (item['SeriesTitle']).replace('&', '%26').replace(',', '%2C')
                        menuItems.append((ADDON.getLocalizedString(30201), runScript))
                    else:
                        ###runScript = "XBMC.RunPlugin(plugin://plugin.video.drnu/?addfavorite=%s)" % (item['SeriesTitle']+RestrictedToDenmarkMarker).replace('&', '%26').replace(',', '%2C')
                        runScript = "XBMC.RunPlugin(plugin://plugin.video.drnu/?addfavorite=%s)" % (item['SeriesTitle']).replace('&', '%26').replace(',', '%2C')
                        menuItems.append((ADDON.getLocalizedString(30200), runScript))
                except Exception,e:
                    pass
                    printL('Error in favorites.count(item[SeriesTitle]): %r' % e)

                iconImage = item['PrimaryImageUri']
                printL(repr(item['SeriesTitle']))
                listItem = xbmcgui.ListItem(item['SeriesTitle']+RestrictedToDenmarkMarker, iconImage=iconImage)
                listItem.setProperty('Fanart_Image', iconImage)
                listItem.addContextMenuItems(menuItems, False)
                
                url = PATH + '?listVideos=' + item['SeriesSlug']
                printL('listSeries.url= %r' % url)
                directoryItems.append((item['SeriesTitle']+RestrictedToDenmarkMarker.lower(),url, listItem, True))

            printL('directoryItems0 %r' % directoryItems)
            directoryItems = sorted(directoryItems) ### 2018-01-02
            directoryItemsNoTitle = []
            for dir in directoryItems:
                directoryItemsNoTitle.append((dir[1],dir[2],dir[3]))
            printL('directoryItems1 %r' % directoryItemsNoTitle)
            xbmcplugin.addDirectoryItems(HANDLE, directoryItemsNoTitle)
            xbmcplugin.endOfDirectory(HANDLE)
            
    def listSeriesFlat(self, items, addToFavorites=True):
        ###printL('listSeriesFlat:items= %r' % items)
        if not items:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            if not addToFavorites:
                xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'), ADDON.getLocalizedString(30013),
                                    ADDON.getLocalizedString(30018), ADDON.getLocalizedString(30019))
            else:
                xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'), ADDON.getLocalizedString(30013))
        else:
            directoryItems = list()
            ###items = sorted(items) ### 2018-01-02
            for item in items:
                printL('listSeriesFlat:\nitem.Title= %r\nitem.SeriesTitle= %r\nitem.SeriesSlug= %r' % (item['Title'],item['SeriesTitle'],item['SeriesSlug']))
                ### url = PATH + '?listVideos=' + item['SeriesSlug']
                episodes = self.api.getSeries(item['SeriesSlug'])
                printL('listSeriesFlat:episodes= %r' % episodes)
                for episode in episodes:
                    printL('listSeriesFlat:episode= %r' % episode)
                    directoryItems.append(episode)
                printL(repr(directoryItems))
            """
            printL('directoryItems0 %r' % directoryItems)
            directoryItems = sorted(directoryItems) ### 2018-01-02
            directoryItemsNoTitle = []
            for dir in directoryItems:
                directoryItemsNoTitle.append((dir[1],dir[2],dir[3]))
            printL('directoryItems1 %r' % directoryItemsNoTitle)
            xbmcplugin.addDirectoryItems(HANDLE, directoryItemsNoTitle)
            xbmcplugin.endOfDirectory(HANDLE)
            """
    def listEpisodes(self, items, addSortMethods=True):
        directoryItems = list()
        items = sorted(items) ### 2018-01-02
        for item in items:
            printL('item= %r' % item)  ### 2018-12-19
            if 'PrimaryAsset' not in item or 'Uri' not in item['PrimaryAsset'] or not item['PrimaryAsset']['Uri']:
                continue
            
            IsRerun = 0
            IsExpiresSoon = 0
            infoLabels = {
                'title': item['Title']
            }
            duration = ''
            Title = item['Title']
            try:
                year = str(item['ProductionYear'])
                if year < '1920':
                    year = ''
                ###year = item['Year'] 
            except Exception, e:
                pass
                #year = 'Error geting Year: ' + repr(e)
                year = ''
            printL('year= %r, item= %r' % (year, item))
            
            try:
                if item['PrimaryAsset']['RestrictedToDenmark']:
                    RestrictedToDenmark = True
                else: 
                    RestrictedToDenmark = False
            except Exception,e:
                pass
                printL('RestrictedToDenmark ERROR: %r' % e)
                RestrictedToDenmark = False
            try:
                if item['PrimaryBroadcast']['BroadcastDate']:
                    FirstAired = str(item['PrimaryBroadcast']['BroadcastDate'])
                else: 
                    FirstAired = ''
            except Exception,e:
                pass
                printL('FirstAired ERROR: %r' % e)
                FirstAired = ''
            if 'T' in FirstAired:
                FirstAired = FirstAired.split('T')[0]
            if FirstAired:
                FirstAired = '[COLOR blue]'+ FirstAired + ' [/COLOR] '
            if RestrictedToDenmark == True:
                RestrictedToDenmarkMarker = '[COLOR red]Kun DK [/COLOR] '
            else:
                RestrictedToDenmarkMarker = ''
            
            try:
                ### IsRerun = Genudsendelse  "SeasonSlug"
                duration = int(item['PrimaryAsset']['DurationInMilliseconds'])
                duration = duration/1000/60
                if duration:
                    ###duration = ' [' + str(duration) + ' min]'
                    duration = str(int(item['PrimaryAsset']['DurationInMilliseconds'])/1000/60)
                    durationH = int(int(duration)/60)
                    durationM = (int(duration) - durationH*60)
                    duration =  '[' + str(durationH) + 'h' + str(durationM).zfill(2) + 'm] '
                else:
                    duration = ''
                duration = duration.encode('utf-8')
                
                SeasonTitle = item['SeasonTitle']
                if not SeasonTitle.lower() in Title.lower():
                    duration = duration + SeasonTitle.encode("utf-8")+ ' '   ### 2018-02-01
                if year != '' and not year in Title and not year in duration:
                    duration = year + ' ' + duration
                try:
                    IsRerun = item['PrimaryBroadcast']['IsRerun']
                except:
                    pass
                    IsRerun = 0
                if IsRerun:
                    ###duration = duration + ' [COLOR red]Genudsendelse[/COLOR]'
                    rerun = '[COLOR red]Genudsendelse[/COLOR] '
                else:
                    rerun = ''
                try:
                    IsExpiresSoon = item['ExpiresSoon']
                except:
                    pass
                    IsExpiresSoon = 0
                if IsExpiresSoon:
                    ###duration = duration + ' \n[COLOR lightgreen]Udløber snart[/COLOR]'
                    expiresoon = '[COLOR lightgreen]Udløber snart[/COLOR] '
                else:
                    expiresoon = ''
                try:
                    bct = '[COLOR grey]'+ broadcastTime.strftime('%Y-%m-%d') + ' [/COLOR] '
                except:
                    pass
                    bct = ''
                duration = duration +'\n[I]'+ rerun + expiresoon + FirstAired + RestrictedToDenmarkMarker  + bct + '[/I]'### 2020-02-11 
            except Exception,e:
                pass
                printL('Title duration fails: %r, \n%r' % (item,e))
                duration = duration + ' [ '+repr(e)+']'
                duration = str(duration)   ### 2018-02-09
            duration = duration.decode('utf-8').encode('utf-8')   ### 2018-02-09
            if IsRerun or IsExpiresSoon:
                infoLabels = {
                    'title': ('[COLOR red]*[/COLOR] [B]' + item['Title'].encode('utf-8') + '[/B] ' + duration)  
                } 
            else:
                if IsExpiresSoon:
                    infoLabels = {
                        'title': ('[COLOR red]¤[/COLOR][COLOR lightgreen][B]' + item['Title'].encode('utf-8') + '[/COLOR][/B] ' + duration)  
                    }   
                else:
                        infoLabels = {
                        'title': ('[COLOR lightgreen][B]' + item['Title'].encode('utf-8') + '[/COLOR][/B] ' + duration)  
                    }   

                
            if 'Description' in item:
                infoLabels['plot'] = item['Description']
            iconImage = item['PrimaryImageUri']
            if 'PrimaryBroadcastStartTime' in item and item['PrimaryBroadcastStartTime'] is not None:
                broadcastTime = self.parseDate(item['PrimaryBroadcastStartTime'])
                if broadcastTime:
                    infoLabels['date'] = broadcastTime.strftime('%d.%m.%Y')
                    infoLabels['aired'] = broadcastTime.strftime('%Y-%m-%d')
                    infoLabels['year'] = int(broadcastTime.strftime('%Y'))
                    ###infoLabels['year'] = int(year)
            printL('XXYYZZ ' +  item['Slug'] + '==>' +item['Title'])        
            ###listItem = xbmcgui.ListItem(item['Slug'] + '==>' +item['Title'], iconImage=iconImage)  ### 2018-02-02
            listItem = xbmcgui.ListItem(item['Title'], iconImage=iconImage)  ### 2018-02-09
            listItem.setInfo('video', infoLabels)
            listItem.setProperty('Fanart_Image', iconImage)
            url = PATH + '?playVideo=' + item['Slug']
            listItem.setProperty('IsPlayable', 'true')
            listItem.addContextMenuItems(self.menuItems, False)
            directoryItems.append((item['Title'].lower(),url, listItem))

        printL('directoryItems2 %r' % directoryItems)
        directoryItems = sorted(directoryItems) ### 2018-01-02
        directoryItemsNoTitle = []
        for dir in directoryItems:
            directoryItemsNoTitle.append((dir[1],dir[2]))  ### 2018-02-02
        printL('directoryItems1 %r' % directoryItemsNoTitle)
        xbmcplugin.addDirectoryItems(HANDLE, directoryItemsNoTitle)
        if addSortMethods:
            xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_DATE)
            xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_TITLE)
        xbmcplugin.endOfDirectory(HANDLE)
  
    def playVideo(self, slug):
        self.updateRecentlyWatched(slug)
        item = self.api.getEpisode(slug)
        ###u'PrimaryAsset': {u'Kind': u'VideoResource', u'Target': u'Default', u'StartPublish': u'2019-01-24T21:24:52Z', u'Uri': u'https://www.dr.dk/mu-online/api/1.4/bar/5c45d4a36187a51250a0dac7'
        
        printL( 'drnu addon.py: \nself= %r\nslug= %r\nitem= %r' % (self,slug,item))
        if not 'PrimaryAsset' in item:
            self.displayError(ADDON.getLocalizedString(30904))
            return

        video = self.api.getVideoUrl(item[u'PrimaryAsset'][u'Uri'])
        
        printL('video= %r' % video)
        try:
            Title = item['Title']
            OrgTitle = Title
            printL('TitleUTF-8= %r' % Title)
            Title = latin1_to_ascii_force(Title)   ### No UTF-8 in filename 
            printL('TitleNoUTF-8= %r' % Title)
            Title = Title.replace(':',';').replace('\\','-').replace('/','-').replace(',',';')
            printL('Title= %r' % Title)
        except Exception, e:
            pass
            Title = '%r - Error in Title: %r' % (Title,e)
        try:
            year = item['ProductionYear']
            if year > 1900:
                year = str(year)
            else:
                year = ''
            ###year = item['Year'] 
        except Exception, e:
            pass
            #year = 'Error geting Year: ' + repr(e)
            year = ''
        try:
            description = item['Description'].replace('/n','NewLine').encode("utf-8")  ### 2017-01-28
        except Exception, e:
            pass
            description = 'Error geting description/Plot: ' + repr(e)
        try:
            duration = str(int(item['PrimaryAsset']['DurationInMilliseconds'])/1000/60 +1)    ### 2019-01-24 add the last full minute
            durationH = int(int(duration)/60)
            durationM = (int(duration) - durationH*60)
            orgduration =  str(durationH) + 'h' + str(durationM).zfill(2) + 'm'
        except Exception, e:
            pass
            orgduration = ''
            duration = 'Error geting duration: ' + repr(e)    
        item = xbmcgui.ListItem(path=video['Uri'], thumbnailImage=item['PrimaryImageUri'])
        
        printL( 'video= %s' % repr(video).replace(',','###'))
        printL( 'URI= %s' % repr(video['Uri']))
        printL( repr(PATH))
        ADDON      = xbmcaddon.Addon()
        datapath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
        playlist = os.path.join(datapath, 'DRarkiv') + '.m3u'
        if os.path.isfile(playlist ) == False: 
            LF = open(playlist , 'a')
            LF.write('#EXTM3U \n')
            LF.write(str(video['Uri']) + '\n')
        else:
            LF = open(playlist , 'a')
            LF.write(str(video['Uri']) + '\n')
        try:
            printL('duration= %r' % duration)
            durationVideo = '&duration='+duration
        except Exception,e:
            pass
            printL('Error in duration= %r\n%r' %(0,e))
            duration = ''
            durationVideo = ''
        try:
            if year == '' or year == '0':
                descriptionE = '&description='+description
            else:
                descriptionE = '&description='+year+': '+description
        except Exception,e:
            pass
            printL('Error in descriptionE= %r\n%r' %(description,e))
            descriptionE = ''
        if video['SubtitlesUri']:  ### Previous used '+ str(slug).title()'
            descriptionE += '&subtitlesurl=' + video['SubtitlesUri'].encode("utf-8") + '&subtitlesoffset=0'
        if not year in Title:
            Title += ' ' + year
            OrgTitle += ' ' + year
        OrgTitle = (OrgTitle +' ['+orgduration+']' + '[DR NU]').encode("utf-8")
        printL('err OrgTitle= %r' % OrgTitle)
        ###OrgTitleb64 = '&OrgTitle=b64' + base64.b64encode(OrgTitle)
        OrgTitleb64 = '&OrgTitle=b64' + base64.b64encode(OrgTitle)
        RecordingFromOtherAddon = ADDON.getSetting('enable.recording')
        if RecordingFromOtherAddon.lower() == 'true':
            RecordingFromOtherAddon = RecordFlagGet('')   ###ADDON.getSetting('RecordingFromOtherAddon')
            printL(repr(RecordingFromOtherAddon))
            printL(repr(ADDON))
            RecordFlagSet('','yyy') 
            printL('Reset RecordingFromOtherAddon to yyy')
            
            RecordingFromOtherAddon = RecordFlagGet('')   ###ADDON.getSetting('RecordingFromOtherAddon')
            printL(repr(RecordingFromOtherAddon))
            printL(repr(ADDON))
            ### recAddons = recordingaddons()
            recAddons = krogsbellAddonsSelect()   ### 2019-10-24
            printL('recAddons= %r' % recAddons)
            tries    = 0
            maxTries = 10
            maxSleep = 500
            if recAddons != '':
                ###URI='plugin://plugin.video.krogsbelliptvDEVELOPMENT/?url=url&mode=2011&source='+ADDONid+'&name=' + Title.encode("utf-8") + ' ['+orgduration+']' + ' [DR NU]&uri='+ (str(video['Uri'])+ descriptionE+ durationVideo).replace(' ','AAabBB').replace('?','aAabBb').replace('=','BBabAA').replace(',','###').replace('&','AaAaA')
                ###URI='plugin://' +recAddons+ '/?url=url&mode=2011&source='+ADDONid+'&name=' + Title.encode("utf-8") + ' ['+orgduration+']' + ' [DR NU]&uri=b64'+ (str(video['Uri'])+ descriptionE+ durationVideo).replace(' ','AAabBB').replace('?','aAabBb').replace('=','BBabAA').replace(',','###').replace('&','AaAaA')
                URI='plugin://' +recAddons+ '/?url=url&mode=2011&source='+ADDONid+'&name=b64' + base64.b64encode(Title.encode("utf-8") + ' ['+orgduration+']' + '[DR NU]')+'&uri=b64'+base64.b64encode(str(video['Uri'])+ descriptionE+ durationVideo+OrgTitleb64)
                
                printL('drnu-->recorduri.py: URI= %r' % URI)

                try:
                    xbmc.executebuiltin('XBMC.RunPlugin(%s)' % URI) 
                    xbmc.sleep(maxSleep)
                    
                    RecordingFromOtherAddon = RecordFlagGet('')   ###ADDON.getSetting('RecordingFromOtherAddon')
                    printL(repr(RecordingFromOtherAddon))
                    printL(repr(ADDON))
                except:
                    pass 
            
            printL('Play Video')
            if ADDON.getSetting('enable.subtitles') == 'true':
                if video['SubtitlesUri']:
                    item.setSubtitles([video['SubtitlesUri']])
            
            ###RecordingFromOtherAddon = ADDON.onSettingsChanged()
            ###printL('RecordingFromOtherAddon = ADDON.onSettingsChanged(): %r' % RecordingFromOtherAddon)
            RecordingFromOtherAddon = RecordFlagGet('')   ###ADDON.getSetting('RecordingFromOtherAddon')
            printL(RecordingFromOtherAddon)
            printL(repr(ADDON))
            printL(repr(tries))
      
            while RecordingFromOtherAddon != 'False' and RecordingFromOtherAddon != 'True' and tries < maxTries:
                try:
                    xbmc.sleep(maxSleep)
                    ###RecordingFromOtherAddon = ADDON.onSettingsChanged()
                    ###printL('RecordingFromOtherAddon = ADDON.onSettingsChanged(): %r' % RecordingFromOtherAddon)
                    RecordingFromOtherAddon = RecordFlagGet('')   ###ADDON.getSetting('RecordingFromOtherAddon')
                    printL(repr(RecordingFromOtherAddon))
                    printL(repr(ADDON))
                    printL(repr(tries))
                    if RecordingFromOtherAddon == 'False' or RecordingFromOtherAddon == 'True':
                        printL(repr('Break'))
                        break
                    else:
                        tries = tries + 1
                except Exception,e:
                    pass
                    printL(repr('Exception'))
                    printL(repr('e'))
                    RecordingFromOtherAddon = 'False' 
            printL(repr(RecordingFromOtherAddon))
            printL(repr(ADDON))
            printL(repr(tries))
            if RecordingFromOtherAddon == 'False' or tries >= maxTries:
                printL(repr('Play URI: ')+ repr(video['Uri']))
                xbmcplugin.setResolvedUrl(HANDLE, video['Uri'] is not None, item)
        else:
            printL(repr('Play URI: ')+ repr(video['Uri']))
            xbmcplugin.setResolvedUrl(HANDLE, video['Uri'] is not None, item)
                
    def parseDate(self, dateString):
        if dateString is not None:
            try:
                m = re.search('(\d+)-(\d+)-(\d+)T(\d+):(\d+):(\d+)', dateString)
                year = int(m.group(1))
                month = int(m.group(2))
                day = int(m.group(3))
                hours = int(m.group(4))
                minutes = int(m.group(5))
                seconds = int(m.group(6))
                return datetime.datetime(year, month, day, hours, minutes, seconds)
            except ValueError:
                return None
        else:
            return None
    
    def addFavorite(self, key):
        self._load()
        if not self.favorites.count(key):
            self.favorites.append(key)
        self._save()

        xbmcgui.Dialog().ok(ADDON.getLocalizedString(30008), ADDON.getLocalizedString(30009))

    def delFavorite(self, key):
        self._load()
        if self.favorites.count(key):
            self.favorites.remove(key)
        self._save()
        xbmcgui.Dialog().ok(ADDON.getLocalizedString(30008), ADDON.getLocalizedString(30010))

    def updateRecentlyWatched(self, assetUri):
        self._load()
        if self.recentlyWatched.count(assetUri):
            self.recentlyWatched.remove(assetUri)
        self.recentlyWatched.insert(0, assetUri)
        self._save()

    def displayError(self, message='n/a'):
        heading = buggalo.getRandomHeading()
        line1 = ADDON.getLocalizedString(30900)
        line2 = ADDON.getLocalizedString(30901)
        xbmcgui.Dialog().ok(heading, line1, line2, message)

    def displayIOError(self, message='n/a'):
        heading = buggalo.getRandomHeading()
        line1 = ADDON.getLocalizedString(30902)
        line2 = ADDON.getLocalizedString(30903)
        xbmcgui.Dialog().ok(heading, line1, line2, message)

def latin1_to_ascii_force(unitext):
    """
2020-02-02 13:43:56 default.py: l TEST i= 127, str(j)= '\x7f'=, unicrap(j)= '\x7f'
2020-02-02 13:43:56 default.py: l TEST i= 128, str(j)= '\x80'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 129, str(j)= '\x81'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 130, str(j)= '\x82'=, unicrap(j)= 'Euro'
2020-02-02 13:43:56 default.py: l TEST i= 131, str(j)= '\x83'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 132, str(j)= '\x84'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 133, str(j)= '\x85'=, unicrap(j)= 'AA'
2020-02-02 13:43:56 default.py: l TEST i= 134, str(j)= '\x86'=, unicrap(j)= 'AE'
2020-02-02 13:43:56 default.py: l TEST i= 135, str(j)= '\x87'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 136, str(j)= '\x88'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 137, str(j)= '\x89'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 138, str(j)= '\x8a'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 139, str(j)= '\x8b'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 140, str(j)= '\x8c'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 141, str(j)= '\x8d'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 142, str(j)= '\x8e'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 143, str(j)= '\x8f'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 144, str(j)= '\x90'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 145, str(j)= '\x91'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 146, str(j)= '\x92'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 147, str(j)= '\x93'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 148, str(j)= '\x94'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 149, str(j)= '\x95'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 150, str(j)= '\x96'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 151, str(j)= '\x97'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 152, str(j)= '\x98'=, unicrap(j)= 'OE'
2020-02-02 13:43:56 default.py: l TEST i= 153, str(j)= '\x99'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 154, str(j)= '\x9a'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 155, str(j)= '\x9b'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 156, str(j)= '\x9c'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 157, str(j)= '\x9d'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 158, str(j)= '\x9e'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 159, str(j)= '\x9f'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 160, str(j)= '\xa0'= , unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 161, str(j)= '\xa1'=¡, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 162, str(j)= '\xa2'=¢, unicrap(j)= 'c'
2020-02-02 13:43:57 default.py: l TEST i= 163, str(j)= '\xa3'=£, unicrap(j)= 'L'
2020-02-02 13:43:57 default.py: l TEST i= 164, str(j)= '\xa4'=¤, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 165, str(j)= '\xa5'=¥, unicrap(j)= 'Y'
2020-02-02 13:43:57 default.py: l TEST i= 166, str(j)= '\xa6'=¦, unicrap(j)= ':'
2020-02-02 13:43:57 default.py: l TEST i= 167, str(j)= '\xa7'=§, unicrap(j)= 's'
2020-02-02 13:43:57 default.py: l TEST i= 168, str(j)= '\xa8'=¨, unicrap(j)= '..'
2020-02-02 13:43:57 default.py: l TEST i= 169, str(j)= '\xa9'=©, unicrap(j)= 'c'
2020-02-02 13:43:57 default.py: l TEST i= 170, str(j)= '\xaa'=ª, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 171, str(j)= '\xab'=«, unicrap(j)= '<<'
2020-02-02 13:43:57 default.py: l TEST i= 172, str(j)= '\xac'=¬, unicrap(j)= '-'
2020-02-02 13:43:57 default.py: l TEST i= 173, str(j)= '\xad'=­, unicrap(j)= '-'
2020-02-02 13:43:57 default.py: l TEST i= 174, str(j)= '\xae'=®, unicrap(j)= 'R'
2020-02-02 13:43:57 default.py: l TEST i= 175, str(j)= '\xaf'=¯, unicrap(j)= '_'
2020-02-02 13:43:57 default.py: l TEST i= 176, str(j)= '\xb0'=°, unicrap(j)= 'deg'
2020-02-02 13:43:57 default.py: l TEST i= 177, str(j)= '\xb1'=±, unicrap(j)= '+/-'
2020-02-02 13:43:57 default.py: l TEST i= 178, str(j)= '\xb2'=², unicrap(j)= '^2'
2020-02-02 13:43:57 default.py: l TEST i= 179, str(j)= '\xb3'=³, unicrap(j)= '^3'
2020-02-02 13:43:57 default.py: l TEST i= 180, str(j)= '\xb4'=´, unicrap(j)= "'"
2020-02-02 13:43:57 default.py: l TEST i= 181, str(j)= '\xb5'=µ, unicrap(j)= 'm'
2020-02-02 13:43:57 default.py: l TEST i= 182, str(j)= '\xb6'=¶, unicrap(j)= 'pi'
2020-02-02 13:43:57 default.py: l TEST i= 183, str(j)= '\xb7'=·, unicrap(j)= '*'
2020-02-02 13:43:57 default.py: l TEST i= 184, str(j)= '\xb8'=¸, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 185, str(j)= '\xb9'=¹, unicrap(j)= '^1'
2020-02-02 13:43:57 default.py: l TEST i= 186, str(j)= '\xba'=º, unicrap(j)= '^0'
2020-02-02 13:43:57 default.py: l TEST i= 187, str(j)= '\xbb'=», unicrap(j)= '>>'
2020-02-02 13:43:57 default.py: l TEST i= 188, str(j)= '\xbc'=¼, unicrap(j)= '1/4'
2020-02-02 13:43:57 default.py: l TEST i= 189, str(j)= '\xbd'=½, unicrap(j)= '1/2'
2020-02-02 13:43:57 default.py: l TEST i= 190, str(j)= '\xbe'=¾, unicrap(j)= '3/4'
2020-02-02 13:43:57 default.py: l TEST i= 191, str(j)= '\xbf'=¿, unicrap(j)= '?'
2020-02-02 13:43:57 default.py: l TEST i= 192, str(j)= '\xc0'=À, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 193, str(j)= '\xc1'=Á, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 194, str(j)= '\xc2'=Â, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 195, str(j)= '\xc3'=Ã, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 196, str(j)= '\xc4'=Ä, unicrap(j)= 'AA'
2020-02-02 13:43:57 default.py: l TEST i= 197, str(j)= '\xc5'=Å, unicrap(j)= 'AA'
2020-02-02 13:43:57 default.py: l TEST i= 198, str(j)= '\xc6'=Æ, unicrap(j)= 'AE'
2020-02-02 13:43:57 default.py: l TEST i= 199, str(j)= '\xc7'=Ç, unicrap(j)= 'C'
2020-02-02 13:43:57 default.py: l TEST i= 200, str(j)= '\xc8'=È, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 201, str(j)= '\xc9'=É, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 202, str(j)= '\xca'=Ê, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 203, str(j)= '\xcb'=Ë, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 204, str(j)= '\xcc'=Ì, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 205, str(j)= '\xcd'=Í, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 206, str(j)= '\xce'=Î, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 207, str(j)= '\xcf'=Ï, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 208, str(j)= '\xd0'=Ð, unicrap(j)= 'Th'
2020-02-02 13:43:57 default.py: l TEST i= 209, str(j)= '\xd1'=Ñ, unicrap(j)= 'N'
2020-02-02 13:43:57 default.py: l TEST i= 210, str(j)= '\xd2'=Ò, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 211, str(j)= '\xd3'=Ó, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 212, str(j)= '\xd4'=Ô, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 213, str(j)= '\xd5'=Õ, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 214, str(j)= '\xd6'=Ö, unicrap(j)= 'OE'
2020-02-02 13:43:57 default.py: l TEST i= 215, str(j)= '\xd7'=×, unicrap(j)= '*'
2020-02-02 13:43:57 default.py: l TEST i= 216, str(j)= '\xd8'=Ø, unicrap(j)= 'OE'
2020-02-02 13:43:57 default.py: l TEST i= 217, str(j)= '\xd9'=Ù, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 218, str(j)= '\xda'=Ú, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 219, str(j)= '\xdb'=Û, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 220, str(j)= '\xdc'=Ü, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 221, str(j)= '\xdd'=Ý, unicrap(j)= 'Y'
2020-02-02 13:43:57 default.py: l TEST i= 222, str(j)= '\xde'=Þ, unicrap(j)= 'th'
2020-02-02 13:43:57 default.py: l TEST i= 223, str(j)= '\xdf'=ß, unicrap(j)= 'ss'
2020-02-02 13:43:57 default.py: l TEST i= 224, str(j)= '\xe0'=à, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 225, str(j)= '\xe1'=á, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 226, str(j)= '\xe2'=â, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 227, str(j)= '\xe3'=ã, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 228, str(j)= '\xe4'=ä, unicrap(j)= 'ae'
2020-02-02 13:43:57 default.py: l TEST i= 229, str(j)= '\xe5'=å, unicrap(j)= 'aa'
2020-02-02 13:43:57 default.py: l TEST i= 230, str(j)= '\xe6'=æ, unicrap(j)= 'ae'
2020-02-02 13:43:57 default.py: l TEST i= 231, str(j)= '\xe7'=ç, unicrap(j)= 'c'
2020-02-02 13:43:57 default.py: l TEST i= 232, str(j)= '\xe8'=è, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 233, str(j)= '\xe9'=é, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 234, str(j)= '\xea'=ê, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 235, str(j)= '\xeb'=ë, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 236, str(j)= '\xec'=ì, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 237, str(j)= '\xed'=í, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 238, str(j)= '\xee'=î, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 239, str(j)= '\xef'=ï, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 240, str(j)= '\xf0'=ð, unicrap(j)= 'th'
2020-02-02 13:43:57 default.py: l TEST i= 241, str(j)= '\xf1'=ñ, unicrap(j)= 'n'
2020-02-02 13:43:57 default.py: l TEST i= 242, str(j)= '\xf2'=ò, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 243, str(j)= '\xf3'=ó, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 244, str(j)= '\xf4'=ô, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 245, str(j)= '\xf5'=õ, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 246, str(j)= '\xf6'=ö, unicrap(j)= 'oe'
2020-02-02 13:43:57 default.py: l TEST i= 247, str(j)= '\xf7'=÷, unicrap(j)= '/'
2020-02-02 13:43:57 default.py: l TEST i= 248, str(j)= '\xf8'=ø, unicrap(j)= 'oe'
2020-02-02 13:43:57 default.py: l TEST i= 249, str(j)= '\xf9'=ù, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 250, str(j)= '\xfa'=ú, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 251, str(j)= '\xfb'=û, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 252, str(j)= '\xfc'=ü, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 253, str(j)= '\xfd'=ý, unicrap(j)= 'y'
2020-02-02 13:43:57 default.py: l TEST i= 254, str(j)= '\xfe'=þ, unicrap(j)= 'th'
2020-02-02 13:43:57 default.py: l TEST i= 255, str(j)= '\xff'=ÿ, unicrap(j)= 'y'
N\xc3\xa5r st\xc3\xb8vet har lagt sig
N      å r st      ø vet har lagt sig 
S\xc3\xb8ren Ryge pr\xc3\xa6senterer
S      ø ren Ryge pr      æ senterer 
    """
    xc3flag = False
    xlatec3={0x82:'Euro', 0x85:'AA', 0x86:'AE', 0x98:'OE', 
        0xa0:'',
        0xa1:'', 0xa2:'c', 0xa3:'L', 0xa4:'ae',
        0xa5:'aa', 0xa6:'ae', 0xa7:'s', 0xa8:'..',
        0xa9:'e', 0xaa:'a', 0xab:'<<', 0xac:'-',
        0xad:'-', 0xae:'R', 0xaf:'_', 
        0xb0:'deg',
        0xb1:'+/-', 0xb2:'^2', 0xb3:'o', 0xb4:"'",
        0xb5:'m', 0xb6:'oe', 0xb7:'*', 0xb8:'oe',
        0xb9:'^1', 0xba:'^0', 0xbb:'>>', 
        0xbc:'1/4', 0xbd:'1/2', 0xbe:'3/4', 0xbf:'?',
        0xc0:'A', 0xc1:'A', 0xc2:'A', 0xc3:'', 0xc4:'AA', 0xc5:'AA',
        0xc6:'AE', 0xc7:'C',
        0xc8:'E', 0xc9:'E', 0xca:'E', 0xcb:'E',
        0xcc:'I', 0xcd:'I', 0xce:'I', 0xcf:'I',
        0xd0:'Th', 0xd1:'N',
        0xd2:'O', 0xd3:'O', 0xd4:'O', 0xd5:'O', 0xd6:'OE', 
        0xd7:'*', 
        0xd8:'OE',
        0xd9:'U', 0xda:'U', 0xdb:'U', 0xdc:'U',
        0xdd:'Y', 0xde:'th', 0xdf:'ss',
        0xe0:'a', 0xe1:'a', 0xe2:'a', 0xe3:'a', 0xe4:'ae', 0xe5:'aa',
        0xe6:'ae', 0xe7:'c',
        0xe8:'e', 0xe9:'e', 0xea:'e', 0xeb:'e',
        0xec:'i', 0xed:'i', 0xee:'i', 0xef:'i',
        0xf0:'th', 0xf1:'n',
        0xf2:'o', 0xf3:'o', 0xf4:'o', 0xf5:'o', 0xf6:'oe', 0xf7:'/', 0xf8:'oe',
        0xf9:'u', 0xfa:'u', 0xfb:'u', 0xfc:'u',
        0xfd:'y', 0xfe:'th', 0xff:'y',
        }
    xlate={0x82:'Euro', 0x85:'AA', 0x86:'AE', 0x98:'OE', 
        0xa0:'',
        0xa1:'', 0xa2:'c', 0xa3:'L', 0xa4:'o',
        0xa5:'aa', 0xa6:':', 0xa7:'s', 0xa8:'..',
        0xa9:'c', 0xaa:'a', 0xab:'<<', 0xac:'-',
        0xad:'-', 0xae:'R', 0xaf:'_', 
        0xb0:'deg',
        0xb1:'+/-', 0xb2:'^2', 0xb3:'o', 0xb4:"'",
        0xb5:'m', 0xb6:'pi', 0xb7:'*', 0xb8:'oe',
        0xb9:'^1', 0xba:'^0', 0xbb:'>>', 
        0xbc:'1/4', 0xbd:'1/2', 0xbe:'3/4', 0xbf:'?',
        0xc0:'A', 0xc1:'A', 0xc2:'A', 0xc3:'', 0xc4:'AA', 0xc5:'AA',
        0xc6:'AE', 0xc7:'C',
        0xc8:'E', 0xc9:'E', 0xca:'E', 0xcb:'E',
        0xcc:'I', 0xcd:'I', 0xce:'I', 0xcf:'I',
        0xd0:'Th', 0xd1:'N',
        0xd2:'O', 0xd3:'O', 0xd4:'O', 0xd5:'O', 0xd6:'OE', 
        0xd7:'*', 
        0xd8:'OE',
        0xd9:'U', 0xda:'U', 0xdb:'U', 0xdc:'U',
        0xdd:'Y', 0xde:'th', 0xdf:'ss',
        0xe0:'a', 0xe1:'a', 0xe2:'a', 0xe3:'a', 0xe4:'ae', 0xe5:'aa',
        0xe6:'ae', 0xe7:'c',
        0xe8:'e', 0xe9:'e', 0xea:'e', 0xeb:'e',
        0xec:'i', 0xed:'i', 0xee:'i', 0xef:'i',
        0xf0:'th', 0xf1:'n',
        0xf2:'o', 0xf3:'o', 0xf4:'o', 0xf5:'o', 0xf6:'oe', 0xf7:'/', 0xf8:'oe',
        0xf9:'u', 0xfa:'u', 0xfb:'u', 0xfc:'u',
        0xfd:'y', 0xfe:'th', 0xff:'y', 
        }
    r = ''
    printL('unitext= %r' % unitext)
    unitext = unitext.encode("utf-8")
    printL('unitext-utf-8= %r' % unitext)
    unitext = unitext.replace('\xef\xbb\xbf','')   ### Remove: byte order mark (BOM)
    printL('unitext-noBOM= %r' % unitext)
    for i in unitext:
        printL('i= %r, ord(i)= %r' %  (i,ord(i)))
        if ord(i) == 0xc3:
            xc3flag = True
        else:
            if xc3flag == True:
                if xlatec3.has_key(ord(i)):
                    r += xlatec3[ord(i)]
                elif ord(i) >= 0x80:
                    pass
                else:
                    r += str(i)
                xc3flag = False
            else:
                if xlate.has_key(ord(i)):
                    r += xlate[ord(i)]
                elif ord(i) >= 0x80:
                    pass
                else:
                    r += str(i)
    return r

def latin1_to_ascii_forceOLD(unitext):
    """
2020-02-02 13:43:56 default.py: l TEST i= 127, str(j)= '\x7f'=, unicrap(j)= '\x7f'
2020-02-02 13:43:56 default.py: l TEST i= 128, str(j)= '\x80'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 129, str(j)= '\x81'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 130, str(j)= '\x82'=, unicrap(j)= 'Euro'
2020-02-02 13:43:56 default.py: l TEST i= 131, str(j)= '\x83'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 132, str(j)= '\x84'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 133, str(j)= '\x85'=, unicrap(j)= 'AA'
2020-02-02 13:43:56 default.py: l TEST i= 134, str(j)= '\x86'=, unicrap(j)= 'AE'
2020-02-02 13:43:56 default.py: l TEST i= 135, str(j)= '\x87'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 136, str(j)= '\x88'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 137, str(j)= '\x89'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 138, str(j)= '\x8a'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 139, str(j)= '\x8b'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 140, str(j)= '\x8c'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 141, str(j)= '\x8d'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 142, str(j)= '\x8e'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 143, str(j)= '\x8f'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 144, str(j)= '\x90'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 145, str(j)= '\x91'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 146, str(j)= '\x92'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 147, str(j)= '\x93'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 148, str(j)= '\x94'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 149, str(j)= '\x95'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 150, str(j)= '\x96'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 151, str(j)= '\x97'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 152, str(j)= '\x98'=, unicrap(j)= 'OE'
2020-02-02 13:43:56 default.py: l TEST i= 153, str(j)= '\x99'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 154, str(j)= '\x9a'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 155, str(j)= '\x9b'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 156, str(j)= '\x9c'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 157, str(j)= '\x9d'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 158, str(j)= '\x9e'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 159, str(j)= '\x9f'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 160, str(j)= '\xa0'= , unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 161, str(j)= '\xa1'=¡, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 162, str(j)= '\xa2'=¢, unicrap(j)= 'c'
2020-02-02 13:43:57 default.py: l TEST i= 163, str(j)= '\xa3'=£, unicrap(j)= 'L'
2020-02-02 13:43:57 default.py: l TEST i= 164, str(j)= '\xa4'=¤, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 165, str(j)= '\xa5'=¥, unicrap(j)= 'Y'
2020-02-02 13:43:57 default.py: l TEST i= 166, str(j)= '\xa6'=¦, unicrap(j)= ':'
2020-02-02 13:43:57 default.py: l TEST i= 167, str(j)= '\xa7'=§, unicrap(j)= 's'
2020-02-02 13:43:57 default.py: l TEST i= 168, str(j)= '\xa8'=¨, unicrap(j)= '..'
2020-02-02 13:43:57 default.py: l TEST i= 169, str(j)= '\xa9'=©, unicrap(j)= 'c'
2020-02-02 13:43:57 default.py: l TEST i= 170, str(j)= '\xaa'=ª, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 171, str(j)= '\xab'=«, unicrap(j)= '<<'
2020-02-02 13:43:57 default.py: l TEST i= 172, str(j)= '\xac'=¬, unicrap(j)= '-'
2020-02-02 13:43:57 default.py: l TEST i= 173, str(j)= '\xad'=­, unicrap(j)= '-'
2020-02-02 13:43:57 default.py: l TEST i= 174, str(j)= '\xae'=®, unicrap(j)= 'R'
2020-02-02 13:43:57 default.py: l TEST i= 175, str(j)= '\xaf'=¯, unicrap(j)= '_'
2020-02-02 13:43:57 default.py: l TEST i= 176, str(j)= '\xb0'=°, unicrap(j)= 'deg'
2020-02-02 13:43:57 default.py: l TEST i= 177, str(j)= '\xb1'=±, unicrap(j)= '+/-'
2020-02-02 13:43:57 default.py: l TEST i= 178, str(j)= '\xb2'=², unicrap(j)= '^2'
2020-02-02 13:43:57 default.py: l TEST i= 179, str(j)= '\xb3'=³, unicrap(j)= '^3'
2020-02-02 13:43:57 default.py: l TEST i= 180, str(j)= '\xb4'=´, unicrap(j)= "'"
2020-02-02 13:43:57 default.py: l TEST i= 181, str(j)= '\xb5'=µ, unicrap(j)= 'm'
2020-02-02 13:43:57 default.py: l TEST i= 182, str(j)= '\xb6'=¶, unicrap(j)= 'pi'
2020-02-02 13:43:57 default.py: l TEST i= 183, str(j)= '\xb7'=·, unicrap(j)= '*'
2020-02-02 13:43:57 default.py: l TEST i= 184, str(j)= '\xb8'=¸, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 185, str(j)= '\xb9'=¹, unicrap(j)= '^1'
2020-02-02 13:43:57 default.py: l TEST i= 186, str(j)= '\xba'=º, unicrap(j)= '^0'
2020-02-02 13:43:57 default.py: l TEST i= 187, str(j)= '\xbb'=», unicrap(j)= '>>'
2020-02-02 13:43:57 default.py: l TEST i= 188, str(j)= '\xbc'=¼, unicrap(j)= '1/4'
2020-02-02 13:43:57 default.py: l TEST i= 189, str(j)= '\xbd'=½, unicrap(j)= '1/2'
2020-02-02 13:43:57 default.py: l TEST i= 190, str(j)= '\xbe'=¾, unicrap(j)= '3/4'
2020-02-02 13:43:57 default.py: l TEST i= 191, str(j)= '\xbf'=¿, unicrap(j)= '?'
2020-02-02 13:43:57 default.py: l TEST i= 192, str(j)= '\xc0'=À, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 193, str(j)= '\xc1'=Á, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 194, str(j)= '\xc2'=Â, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 195, str(j)= '\xc3'=Ã, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 196, str(j)= '\xc4'=Ä, unicrap(j)= 'AA'
2020-02-02 13:43:57 default.py: l TEST i= 197, str(j)= '\xc5'=Å, unicrap(j)= 'AA'
2020-02-02 13:43:57 default.py: l TEST i= 198, str(j)= '\xc6'=Æ, unicrap(j)= 'AE'
2020-02-02 13:43:57 default.py: l TEST i= 199, str(j)= '\xc7'=Ç, unicrap(j)= 'C'
2020-02-02 13:43:57 default.py: l TEST i= 200, str(j)= '\xc8'=È, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 201, str(j)= '\xc9'=É, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 202, str(j)= '\xca'=Ê, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 203, str(j)= '\xcb'=Ë, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 204, str(j)= '\xcc'=Ì, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 205, str(j)= '\xcd'=Í, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 206, str(j)= '\xce'=Î, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 207, str(j)= '\xcf'=Ï, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 208, str(j)= '\xd0'=Ð, unicrap(j)= 'Th'
2020-02-02 13:43:57 default.py: l TEST i= 209, str(j)= '\xd1'=Ñ, unicrap(j)= 'N'
2020-02-02 13:43:57 default.py: l TEST i= 210, str(j)= '\xd2'=Ò, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 211, str(j)= '\xd3'=Ó, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 212, str(j)= '\xd4'=Ô, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 213, str(j)= '\xd5'=Õ, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 214, str(j)= '\xd6'=Ö, unicrap(j)= 'OE'
2020-02-02 13:43:57 default.py: l TEST i= 215, str(j)= '\xd7'=×, unicrap(j)= '*'
2020-02-02 13:43:57 default.py: l TEST i= 216, str(j)= '\xd8'=Ø, unicrap(j)= 'OE'
2020-02-02 13:43:57 default.py: l TEST i= 217, str(j)= '\xd9'=Ù, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 218, str(j)= '\xda'=Ú, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 219, str(j)= '\xdb'=Û, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 220, str(j)= '\xdc'=Ü, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 221, str(j)= '\xdd'=Ý, unicrap(j)= 'Y'
2020-02-02 13:43:57 default.py: l TEST i= 222, str(j)= '\xde'=Þ, unicrap(j)= 'th'
2020-02-02 13:43:57 default.py: l TEST i= 223, str(j)= '\xdf'=ß, unicrap(j)= 'ss'
2020-02-02 13:43:57 default.py: l TEST i= 224, str(j)= '\xe0'=à, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 225, str(j)= '\xe1'=á, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 226, str(j)= '\xe2'=â, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 227, str(j)= '\xe3'=ã, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 228, str(j)= '\xe4'=ä, unicrap(j)= 'ae'
2020-02-02 13:43:57 default.py: l TEST i= 229, str(j)= '\xe5'=å, unicrap(j)= 'aa'
2020-02-02 13:43:57 default.py: l TEST i= 230, str(j)= '\xe6'=æ, unicrap(j)= 'ae'
2020-02-02 13:43:57 default.py: l TEST i= 231, str(j)= '\xe7'=ç, unicrap(j)= 'c'
2020-02-02 13:43:57 default.py: l TEST i= 232, str(j)= '\xe8'=è, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 233, str(j)= '\xe9'=é, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 234, str(j)= '\xea'=ê, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 235, str(j)= '\xeb'=ë, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 236, str(j)= '\xec'=ì, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 237, str(j)= '\xed'=í, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 238, str(j)= '\xee'=î, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 239, str(j)= '\xef'=ï, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 240, str(j)= '\xf0'=ð, unicrap(j)= 'th'
2020-02-02 13:43:57 default.py: l TEST i= 241, str(j)= '\xf1'=ñ, unicrap(j)= 'n'
2020-02-02 13:43:57 default.py: l TEST i= 242, str(j)= '\xf2'=ò, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 243, str(j)= '\xf3'=ó, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 244, str(j)= '\xf4'=ô, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 245, str(j)= '\xf5'=õ, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 246, str(j)= '\xf6'=ö, unicrap(j)= 'oe'
2020-02-02 13:43:57 default.py: l TEST i= 247, str(j)= '\xf7'=÷, unicrap(j)= '/'
2020-02-02 13:43:57 default.py: l TEST i= 248, str(j)= '\xf8'=ø, unicrap(j)= 'oe'
2020-02-02 13:43:57 default.py: l TEST i= 249, str(j)= '\xf9'=ù, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 250, str(j)= '\xfa'=ú, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 251, str(j)= '\xfb'=û, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 252, str(j)= '\xfc'=ü, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 253, str(j)= '\xfd'=ý, unicrap(j)= 'y'
2020-02-02 13:43:57 default.py: l TEST i= 254, str(j)= '\xfe'=þ, unicrap(j)= 'th'
2020-02-02 13:43:57 default.py: l TEST i= 255, str(j)= '\xff'=ÿ, unicrap(j)= 'y'
N\xc3\xa5r st\xc3\xb8vet har lagt sig
N      å r st      ø vet har lagt sig 
S\xc3\xb8ren Ryge pr\xc3\xa6senterer
S      ø ren Ryge pr      æ senterer 
    """
    xc3flag = False
    xlatec3={0x82:'Euro', 0x85:'AA', 0x86:'AE', 0x98:'OE', 
        0xa0:'',
        0xa1:'', 0xa2:'c', 0xa3:'L', 0xa4:'o',
        0xa5:'aa', 0xa6:'ae', 0xa7:'s', 0xa8:'..',
        0xa9:'c', 0xaa:'a', 0xab:'<<', 0xac:'-',
        0xad:'-', 0xae:'R', 0xaf:'_', 
        0xb0:'deg',
        0xb1:'+/-', 0xb2:'^2', 0xb3:'o', 0xb4:"'",
        0xb5:'m', 0xb6:'pi', 0xb7:'*', 0xb8:'oe',
        0xb9:'^1', 0xba:'^0', 0xbb:'>>', 
        0xbc:'1/4', 0xbd:'1/2', 0xbe:'3/4', 0xbf:'?',
        0xc0:'A', 0xc1:'A', 0xc2:'A', 0xc3:'', 0xc4:'AA', 0xc5:'AA',
        0xc6:'AE', 0xc7:'C',
        0xc8:'E', 0xc9:'E', 0xca:'E', 0xcb:'E',
        0xcc:'I', 0xcd:'I', 0xce:'I', 0xcf:'I',
        0xd0:'Th', 0xd1:'N',
        0xd2:'O', 0xd3:'O', 0xd4:'O', 0xd5:'O', 0xd6:'OE', 
        0xd7:'*', 
        0xd8:'OE',
        0xd9:'U', 0xda:'U', 0xdb:'U', 0xdc:'U',
        0xdd:'Y', 0xde:'th', 0xdf:'ss',
        0xe0:'a', 0xe1:'a', 0xe2:'a', 0xe3:'a', 0xe4:'ae', 0xe5:'aa',
        0xe6:'ae', 0xe7:'c',
        0xe8:'e', 0xe9:'e', 0xea:'e', 0xeb:'e',
        0xec:'i', 0xed:'i', 0xee:'i', 0xef:'i',
        0xf0:'th', 0xf1:'n',
        0xf2:'o', 0xf3:'o', 0xf4:'o', 0xf5:'o', 0xf6:'oe', 0xf7:'/', 0xf8:'oe',
        0xf9:'u', 0xfa:'u', 0xfb:'u', 0xfc:'u',
        0xfd:'y', 0xfe:'th', 0xff:'y',
        }
    xlate={0x82:'Euro', 0x85:'AA', 0x86:'AE', 0x98:'OE', 
        0xa0:'',
        0xa1:'', 0xa2:'c', 0xa3:'L', 0xa4:'o',
        0xa5:'aa', 0xa6:':', 0xa7:'s', 0xa8:'..',
        0xa9:'c', 0xaa:'a', 0xab:'<<', 0xac:'-',
        0xad:'-', 0xae:'R', 0xaf:'_', 
        0xb0:'deg',
        0xb1:'+/-', 0xb2:'^2', 0xb3:'o', 0xb4:"'",
        0xb5:'m', 0xb6:'pi', 0xb7:'*', 0xb8:'oe',
        0xb9:'^1', 0xba:'^0', 0xbb:'>>', 
        0xbc:'1/4', 0xbd:'1/2', 0xbe:'3/4', 0xbf:'?',
        0xc0:'A', 0xc1:'A', 0xc2:'A', 0xc3:'', 0xc4:'AA', 0xc5:'AA',
        0xc6:'AE', 0xc7:'C',
        0xc8:'E', 0xc9:'E', 0xca:'E', 0xcb:'E',
        0xcc:'I', 0xcd:'I', 0xce:'I', 0xcf:'I',
        0xd0:'Th', 0xd1:'N',
        0xd2:'O', 0xd3:'O', 0xd4:'O', 0xd5:'O', 0xd6:'OE', 
        0xd7:'*', 
        0xd8:'OE',
        0xd9:'U', 0xda:'U', 0xdb:'U', 0xdc:'U',
        0xdd:'Y', 0xde:'th', 0xdf:'ss',
        0xe0:'a', 0xe1:'a', 0xe2:'a', 0xe3:'a', 0xe4:'ae', 0xe5:'aa',
        0xe6:'ae', 0xe7:'c',
        0xe8:'e', 0xe9:'e', 0xea:'e', 0xeb:'e',
        0xec:'i', 0xed:'i', 0xee:'i', 0xef:'i',
        0xf0:'th', 0xf1:'n',
        0xf2:'o', 0xf3:'o', 0xf4:'o', 0xf5:'o', 0xf6:'oe', 0xf7:'/', 0xf8:'oe',
        0xf9:'u', 0xfa:'u', 0xfb:'u', 0xfc:'u',
        0xfd:'y', 0xfe:'th', 0xff:'y', 
        }
    r = ''
    for i in unitext:
        if ord(i) == 0xc3:
            xc3flag = True
        else:
            if xc3flag == True:
                if xlatec3.has_key(ord(i)):
                    r += xlatec3[ord(i)]
                elif ord(i) >= 0x80:
                    pass
                else:
                    r += str(i)
                xc3flag = False
            else:
                if xlate.has_key(ord(i)):
                    r += xlate[ord(i)]
                elif ord(i) >= 0x80:
                    pass
                else:
                    r += str(i)
    return r

def latin1_to_ascii_forceORG(unicrap):
    """This takes a UNICODE string and replaces Latin-1 characters with
        something equivalent in 7-bit ASCII. It returns a plain ASCII string. 
        This function makes a best effort to convert Latin-1 characters into 
        ASCII equivalents. It does not just strip out the Latin-1 characters.
        All characters in the standard 7-bit ASCII range are preserved. 
        In the 8th bit range all the Latin-1 accented letters are converted 
        to unaccented equivalents. Most symbol characters are converted to 
        something meaningful. Anything not converted is deleted.
    """ 
    #return unicrap
    ###utils.logdev('TEST-unicrap',repr(unicrap))
    xlate={0x82:'Euro', 0x85:'Aa', 0x86:'Ae', 0x98:'Oe', 0xc0:'A', 0xc1:'A', 0xc2:'', 0xc3:'', 0xc4:'A', 0xc5:'A',
        0xc6:'Ae', 0xc7:'C',
        0xc8:'E', 0xc9:'E', 0xca:'E', 0xcb:'E',
        0xcc:'I', 0xcd:'I', 0xce:'I', 0xcf:'I',
        0xd0:'Th', 0xd1:'N',
        0xd2:'O', 0xd3:'O', 0xd4:'O', 0xd5:'O', 0xd6:'O', 0xd7:'x', 0xd8:'O',
        0xd9:'U', 0xda:'U', 0xdb:'U', 0xdc:'U',
        0xdd:'Y', 0xde:'th', 0xdf:'ss',
        0xe0:'a', 0xe1:'a', 0xe3:'a', 0xe4:'ae', 0xe5:'a',
        0xe6:'ae', 0xe7:'.0xe7.',
        0xe8:'e', 0xe9:'e', 0xea:'e', 0xeb:'e',
        0xec:'i', 0xed:'i', 0xee:'i', 0xef:'i',
        0xf0:'th', 0xf1:'n',
        0xf2:'o', 0xf3:'o', 0xf4:'o', 0xf5:'o', 0xf6:'oe', 0xf8:'o',
        0xf9:'u', 0xfa:'u', 0xfb:'u', 0xfc:'u',
        0xfd:'y', 0xfe:'th', 0xff:'y',0xa0:'a',
        0xa1:'a', 0xa2:'.0xa2.', 0xa3:'', 0xa4:'a',
        0xa5:'aa', 0xa6:'ae', 0xa7:'s', 0xa8:'u',
        0xa9:'e', 0xaa:'e', 0xab:'<<', 0xac:'',
        0xad:'-', 0xae:'R', 0xaf:'_', 0xb0:'d',
        0xb1:'+/-', 0xb2:'^2', 0xb3:'o', 0xb4:"'",
        0xb5:'m', 0xb6:'o', 0xb7:'*', 0xb8:'oe',
        0xb9:'^1', 0xba:'^o', 0xbb:'>>', 
        0xbc:'u', 0xbd:'1/2', 0xbe:'3/4', 0xbf:'?',
        0xd7:'*', 0xf7:'/'
        }
    r = ''
    for i in unicrap:
        if xlate.has_key(ord(i)):
            r += xlate[ord(i)]
        elif ord(i) >= 0x80:
            pass
        else:
            r += str(i)
    ###utils.logdev('TEST-unicrap',repr(r))
    return r


if __name__ == '__main__':
    ###xbmc.executebuiltin('Dialog.Close(busydialog)')   ### 2019-06-27 needed to allow switch addon
    ADDON      = xbmcaddon.Addon()
    ADDONname  = ADDON.getAddonInfo('name')
    ADDONid    = ADDON.getAddonInfo('id')
    PATH = sys.argv[0]
    HANDLE = int(sys.argv[1])
    PARAMS = urlparse.parse_qs(sys.argv[2][1:])

    CACHE_PATH = xbmc.translatePath(ADDON.getAddonInfo("Profile"))
    if not os.path.exists(CACHE_PATH):
        os.makedirs(CACHE_PATH)

    FAVORITES_PATH = os.path.join(CACHE_PATH, 'favorites.pickle')
    RECENT_PATH = os.path.join(CACHE_PATH, 'recent.pickle')
    FANART_IMAGE = os.path.join(ADDON.getAddonInfo('path'), 'fanart.jpg')

    buggalo.SUBMIT_URL = 'http://tommy.winther.nu/exception/submit.php'
    buggalo.addExtraData('cache_path', CACHE_PATH)
    drDkTvAddon = DrDkTvAddon()
    if 'switch' in PARAMS:
        switch(PARAMS['switch'][0])
    elif 'show' in PARAMS:
        if PARAMS['show'][0] == 'liveTV':
            drDkTvAddon.showLiveTV()
        elif PARAMS['show'][0] == 'listAZ':
            drDkTvAddon.showAZ()
        elif PARAMS['show'][0] == 'latest':
            drDkTvAddon.listEpisodes(drDkTvAddon.api.getLatestPrograms(), addSortMethods=False)
        elif PARAMS['show'][0] == 'mostViewed':
            drDkTvAddon.listEpisodes(drDkTvAddon.api.getMostViewed())
        elif PARAMS['show'][0] == 'highlights':
            drDkTvAddon.listEpisodes(drDkTvAddon.api.getSelectedList())
        elif PARAMS['show'][0] == 'search':
            drDkTvAddon.searchSeries()
        elif PARAMS['show'][0] == 'favorites':
            drDkTvAddon.showFavorites()
        elif PARAMS['show'][0] == 'recentlyWatched':
            drDkTvAddon.showRecentlyWatched()
        elif PARAMS['show'][0] == 'areaselector':
            drDkTvAddon.showAreaSelector()
        elif PARAMS['show'][0] == 'themes':
            drDkTvAddon.showThemes()

    elif 'listProgramSeriesByLetter' in PARAMS:
        drDkTvAddon.listSeries(drDkTvAddon.api.getSeries(PARAMS['listProgramSeriesByLetter'][0]))

    elif 'listVideos' in PARAMS:
        drDkTvAddon.listEpisodes(drDkTvAddon.api.getEpisodes(PARAMS['listVideos'][0]))

    elif 'playVideo' in PARAMS:
        drDkTvAddon.playVideo(PARAMS['playVideo'][0])

    elif 'addfavorite' in PARAMS:
        drDkTvAddon.addFavorite(PARAMS['addfavorite'][0])

    elif 'delfavorite' in PARAMS:
        drDkTvAddon.delFavorite(PARAMS['delfavorite'][0])

    else:
        try:
            area = int(ADDON.getSetting('area'))
        except:
            area = 0

        if area == 0:
            drDkTvAddon.showAreaSelector()
        elif area == 1:
            drDkTvAddon.showMainMenu()
        elif area == 2:
            items = drDkTvAddon.api.getChildrenFrontItems('dr-ramasjang')
            drDkTvAddon.listSeries(items)
        elif area == 3:
            items = drDkTvAddon.api.getChildrenFrontItems('dr-ultra')
            drDkTvAddon.listSeries(items)
"""
    except tvapi.ApiException, ex:
        drDkTvAddon.displayError(str(ex))

    except IOError, ex:
        drDkTvAddon.displayIOError(str(ex))

    except Exception:
        buggalo.onExceptionRaised()
"""
