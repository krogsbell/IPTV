#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmcaddon,xbmc,xbmcvfs,xbmcgui,os,shutil
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)

referral= 0       
BASEURL = ''
COMMAND = ''
COMMANDEND = ''
REGISTRATION = ''
DEFAULTSTREAMTYPE = ''
module = 'definition.py'

def log(infotext,showlength=1024):
    logtext = ADDONgetSetting('basicuserinfoerror')
    logtext = infotext + ' ¤ \n' + logtext
    ADDONsetSetting('basicuserinfoerror', logtext[0:showlength])


def nowTS():   ### Local time
    dt_obj= datetime.now()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
   
def nowutcTS():   ### UTC time
    dt_obj= datetime.utcnow()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
    
def timeZone():
    tz = (nowTS() - nowutcTS())//3600
    return tz
    
def DaylightSaving():
    dialog = xbmcgui.Dialog()
    if dialog.yesno(ADDONgetAddonInfo('name'), "[COLOR red]Are you using daylight saving[/COLOR]", '', "What Do You Want To Do","[COLOR red]Use Daylight Saving[/COLOR]","[COLOR green]No[/COLOR]"):
        ### No
        return False
    else:
        ### Yes
        return True
        
def Numeric(name,default):
    dialog = xbmcgui.Dialog()
    keyboard=dialog.numeric(0, 'Please Enter '+str(name),default)
    if keyboard:
        if keyboard[0:1] == '0':
            keyboard = str(0-int(keyboard))
    return keyboard
    
### xbmcgui.Dialog().browse(type, heading, shares[, mask, useThumbs, treatAsFolder, defaultt, enableMultiple])
def getFile(name,default):
    dialog = xbmcgui.Dialog()
    file = dialog.browse(1, 'Please Enter '+str(name), '', defaultt=default)
    return file
    
def Parameter(ADDON,name,parameter):
    VALUE = ADDON.getSetting(parameter)
    fixedname = ADDON.getSetting('fixedname')
    if fixedname != '' and parameter == 'my_referral_name':
        VALUE = fixedname
    if VALUE == '' and parameter == 'my_referral_name':
        VALUE = ADDON.getAddonInfo('name')
        if VALUE == '':
            VALUE = 'Krogsbell'
    newVALUE = Search(name,VALUE)
    ADDON.setSetting('parameter',str(VALUE) + '-->' + str(newVALUE))
    if newVALUE == '' and parameter == 'my_referral_name':
        newVALUE = ADDON.getAddonInfo('name')
        if newVALUE == '':
            newVALUE = 'Krogsbell'
    if newVALUE:
        ADDON.setSetting(parameter,newVALUE)
    return newVALUE
    
def Search(name,search_entered):
    keyboard = xbmc.Keyboard(search_entered, '[COLOR lightgreen][B]Please Enter '+str(name)+'[/B][CR][COLOR grey][I]<ESC> or Cancel to clear[/I][/COLOR]')
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_entered = keyboard.getText()
        if search_entered == None:
            return False 
    else:
        return False
    return search_entered 
    
def FileManagerPath(PathInput):
    try:
        sources = xbmcvfs.translatePath('special://masterprofile/sources.xml')
        file = open(sources,'r', encoding = 'utf-8')
        allsources = file.read()
        files = allsources.split('<files>')[1]
        log('error FileManagerPath files= %r' % files)
        searchtext = '<name>'+PathInput+'</name>'
        log('error FileManagerPath searchtext= %r' % searchtext)
        files = files.split(searchtext)[1]
        log('error FileManagerPath 1 files= %r' % files)
        files = files.split('>')[1]
        log('error FileManagerPath 3 files= %r' % files)
        Path = files = files.split('</path')[0]
        
    except Exception as e:
        pass
        Path = PathInput
        log('error in FileManagerPath= %r' % e)
        
    return Path    
    
def ADDONgetAddonInfo(info):
    file = os.path.join(datapath,'ADDON-' + info) + '.set'
    if os.path.isfile(file) == False:
        value = ADDON.getAddonInfo(info)
        LF = open(file, 'w')
        LF.write(value)
        LF.close()
    else:
        LF = open(file,'r')
        value = LF.read()
    return value
   
SETTINGSINFILE = ['my_referral_name','my_referral_link','my_referral_init','NetworkType']
SETTINGINFILEMANAGER = ['record_path','record_archive_path','record_archiveb_path','sharepath','tvguideimport','backup_path']
   
def ADDONsetSetting(setting,value):
    ###if setting == 'my_referral_name' :
    ###   value = 'Krogsbell IPTV 2024-07-06--10-14'    ### TEST 2024-02-01
    ADDON.setSetting(setting,value)
    if setting in SETTINGSINFILE :
        file = os.path.join(datapath,'ADDONsetting-'+setting) + '.set'
        LF = open(file, 'w')
        LF.write(value)
        LF.close()
  
def ADDONresetSetting(setting,value):
    ADDON.setSetting(setting,value)
    if setting in SETTINGSINFILE :
        file = os.path.join(datapath,'ADDONsetting-'+setting) + '.set'
        LF = open(file, 'w')
        LF.write(value)
        LF.close()
      
def ADDONgetSetting(setting):
    if setting in SETTINGSINFILE :
        file = os.path.join(datapath,'ADDONsetting-'+setting) + '.set'
        if os.path.isfile(file) == False:
            value = ADDON.getSetting(setting)
            if setting == 'my_referral_name':
                value = value.replace('\n','')
            ADDONsetSetting(setting,value)
        LF = open(file,'r')
        try:
            value = LF.read()
        except Exception as e:
            pass
            log('error ADDONgetSetting Exception %r' % e)
            LF = open(file,'rb')
            valueb = LF.read()
            try:
                value = valueb.decode('utf8')
            except Exception as e:
                pass
                log('error ADDONgetSetting Exception %r' % e)
                value = 'Error getting setting: %r' % setting
        if setting == 'my_referral_name':
            value = value.replace('\n','')
        ADDONsetSetting(setting,value)
    else:
        value = ADDON.getSetting(setting)
    
    if setting in SETTINGINFILEMANAGER :
        value = FileManagerPath(value)
        
    return value

if referral==0:
    ADDON = xbmcaddon.Addon(id='plugin.video.krogsbelliptv-2025-01-22--22-26')
    datapath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not xbmcvfs.exists(datapath):
        xbmcvfs.mkdir(datapath)
    ADDONsetSetting('addon_program_path',ADDONgetAddonInfo('path'))
    ADDONsetSetting('versionofsetting',ADDONgetAddonInfo('version'))
    BASEURLlast = ADDONgetSetting('BASEURLlast')
    log('err BASEURLlast= %r' % BASEURLlast)
    BASEURL = ADDONgetSetting('BASEURL')
    log('err BASEURL= %r' % BASEURL)
    if BASEURLlast != BASEURL :
        ADDONsetSetting('BASEURLlast',BASEURL)
        log('err BASEURLlast changed to= %r' % BASEURL)
    l=0
    log('100 %r' % l)
    
    log('timeZone= %r' % timeZone())
    TIMEZONE = str(timeZone())
    ADDONsetSetting('TIMEZONE',TIMEZONE)
    log('setSetting(TIMEZONE= %r' % TIMEZONE)
    ADDONsetSetting('AdjustTVguideTimeZoneOffset',TIMEZONE)
    log('setSetting(AdjustTVguideTimeZoneOffset= %r' % TIMEZONE)
    ###ADDONsetSetting('archiveoffset','0')  ### Archive uses GMT 2019-03-30
    ADDONsetSetting('AdjustTVguideTimeZoneOffsetExtraXML',TIMEZONE)
    log('setSetting(AdjustTVguideTimeZoneOffsetExtraXML= %r' % TIMEZONE)
    log('err BASEURL= %r' % BASEURL)
    allownamechange = ADDONgetSetting('allownamechange') 
    if allownamechange.lower() == 'true' :   ### 2022-10-26 set user automatically if allowed
        if not 'http://' in BASEURL and not 'https://' in BASEURL:
            try:
                log('try %r' % l)
                my_referral_name = Parameter(ADDON,'Addon Name','my_referral_name')
                log('my_referral_name= %r' % my_referral_name)
                my_referral_registration = Parameter(ADDON,'Krogsbell IPTV 2024-07-06--10-14 Registred at','my_referral_registration')
                log('my_referral_registration= %r' % my_referral_registration)
                basicuserinfo = ADDONgetSetting('basicuserinfo')
                log('basicuserinfo= %r' % basicuserinfo)
                if 'none.txt' in basicuserinfo:
                    basicuserinfo = os.path.join(ADDONgetAddonInfo('path'), 'none.txt')
                ### basicuserinfo = Parameter(ADDON,'Your Connection Details Text File','basicuserinfo')
                ### http://<url>/get.php?username=<>&password=<>&type=m3u_plus&output=ts
                log('2 basicuserinfo= %r' % basicuserinfo)
                basicuserinfo = getFile('Your Connection Details Text File or none',basicuserinfo)
                log('3 basicuserinfo= %r' % basicuserinfo)
                ADDONsetSetting('basicuserinfo',basicuserinfo)
                
                ChannelFile = ADDONgetSetting('directchannelsfromextraXMLTVfile')
                if os.path.isfile(ChannelFile):
                    directchannelsdef = ChannelFile
                else:
                    directchannelsdef = os.path.join(ADDONgetAddonInfo('path'), 'directchannels.m3u.txt')
                directchannels    = getFile('Your Direct Channels m3u File or keep last',directchannelsdef)
                datapath = xbmcvfs.translatePath(ADDONgetAddonInfo('profile'))
                if os.path.isfile(directchannels) and directchannels != directchannelsdef:
                    directchannelsdata = os.path.join(datapath,'directchannels.m3u')
                    ADDONsetSetting('directchannelsfromextraXMLTVfile',directchannelsdata)
                    shutil.copyfile(directchannels, directchannelsdata)
                else:
                    try:
                        ADDONsetSetting('directchannelsfromextraXMLTVfile','')
                        os.remove(os.path.join(datapath,'directchannels.m3u'))
                    except:
                        pass
                
                file = open(basicuserinfo,'r')
                desc = file.read()
                file.close()
                basicuserinfo = desc
                l=1
                log('152 %r' % l)
                if basicuserinfo:
                    if basicuserinfo.lower().replace('\n','').replace('\r','').replace("'",'') == 'none':
                        basicuserinfo = 'http://none.none:80/get.php?username=none&password=none&type=m3u_plus&output=ts'
                    basicuserinfo = basicuserinfo.replace('&amp;','&')
                    l=2
                    log('158 %r' % l)
                    ADDONsetSetting('AAA','basicuserinfo= %r' % basicuserinfo)
                    if 'http://' in basicuserinfo.lower():
                        l=3
                        log('162 %r' % l)
                        server = basicuserinfo.split('http://',1)[1]
                    else:
                        l=4
                        log('166 %r' % l)
                        server = basicuserinfo.split('https://',1)[1]
                    l=5
                    log('169 %r' % l)
                    BASEURL = server.split('/')[0]
                    l=6
                    log('172 %r' % l)
                    l=10
                    log('227 %r' % l)
                    command = server.replace(BASEURL,'',1)
                    BASEURL = 'http://' + BASEURL
                    COMMAND = command.split('username=',1)[0]
                    l=11
                    log('233 %r' % l)
                    username = command.split('username=',1)[1].split('&',1)[0]
                    l=12
                    log('236 %r' % l)
                    password = command.split('password=',1)[1].split('&',1)[0]
                    l=13
                    log('239 %r' % l)
                    COMMANDEND = '&type=' + command.split('&type=',1)[1]
                    ADDONsetSetting('COMMAND',COMMAND)
                    ADDONsetSetting('COMMANDEND',COMMANDEND)
                    if BASEURL != '' and username != '' and password != '':
                        l=14
                        log('245 %r' % l)
                        ADDONsetSetting('BASEURL',BASEURL)
                        ADDONsetSetting('user',str(username))
                        ADDONsetSetting('pass',str(password))
            except Exception as e:
                pass
                ADDONsetSetting('basicuserinfoerror', 'l= %r, ERROR= %r' % (l,e))
        else:
            BASEURL = ADDONgetSetting('BASEURL').replace('&amp;','&')
            COMMAND = ADDONgetSetting('COMMAND').replace('&amp;','&')
            COMMANDEND = ADDONgetSetting('COMMANDEND').replace('&amp;','&')
        REFERRALNAME = ADDONgetSetting('Addon Name')
        REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'
        DEFAULTSTREAMTYPE = 'live'
else:
    ADDON = xbmcaddon.Addon(id='plugin.video.krogsbelliptv-2025-01-22--22-26')
    if ADDONgetSetting('BASEURL') == '':
        basicuserinfo = Search('Your connection details')
        ### http://<url>/get.php?username=<>&password=<>&type=m3u_plus&output=ts
        if basicuserinfo:
            if 'http://' in basicuserinfo.lower():
                server = basicuserinfo.split('http://',1)[1].split('/')[0]
                BASEURL = basicuserinfo.split('http://',1)[1].split('/')[0]
                COMMAND = ''
    REGISTRATION = ''
    COMMAND = '/panel_api.php?'
    COMMANDEND = '&type=m3u_plus&output=m3u8'
    REGISTRATION = ''
    REFERRALNAME = 'Krogsbell IPTV 2024-07-06--10-14 Rec'
    REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'

ADDONsetSetting('my_referral_link',str(referral))
REFERRALNAME = ADDONgetSetting('my_referral_name')
REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'
REGISTRATION = ADDONgetSetting('my_referral_registration')
###xbmc.log('definition.py in %s with referral= %s' % (ADDON.getAddonInfo('id'), repr(referral)))

def getADDON():
    return ADDON

def getBASEURL():
    return BASEURL  
  
def getCOMMAND():
    return COMMAND 
    
def getCOMMANDEND():
    return COMMANDEND  
    
def getREGISTRATION():
    return REGISTRATION 
 
def getTITLE():
    return REFERRALTITLE 
    
def getDefaultStreamType():
    return DEFAULTSTREAMTYPE
    
def getKrogsbellAddOns():
    ###return ['plugin.video.glowiptv.rec','plugin.video.premiumiptv.rec','plugin.video.roqtv.rec']
    ###return ['plugin.video.glowiptv.rec','plugin.video.krogsbelliptv-2025-01-22--22-26.rec',]
    return []

def getNTVAddOns():
    return ['plugin.video.unlimtv']
    ###return []
    
def DRLYD():
    return 'plugin://plugin.audio.dr.dk.netradio/'



