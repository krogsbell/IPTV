#
#      Copyright (C) 2014 Tommy Winther, (C) 2018 krogsbell
#      http://tommy.winther.nu
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#

import os
import glob
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon('plugin.video.drnu')

CACHE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("Profile"))

def deleteFile(file):
    tries    = 0
    maxTries = 10
    while os.path.exists(file) and tries < maxTries:
        try:
            os.remove(file)
            break
        except:
            xbmc.sleep(500)
            tries = tries + 1

if not os.path.exists(CACHE_PATH):
    os.makedirs(CACHE_PATH)

FAVORITES_PATH = os.path.join(CACHE_PATH, '*.cache')
files =  glob.glob(FAVORITES_PATH)
for infile in files:
    deleteFile(infile)

xbmcgui.Dialog().ok(ADDON.getLocalizedString(30004), ADDON.getLocalizedString(30203))
