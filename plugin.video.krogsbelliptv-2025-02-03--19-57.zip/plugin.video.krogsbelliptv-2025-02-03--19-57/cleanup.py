#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmc, xbmcvfs
# For Python 3.0 and later
from urllib.request import urlopen
import sys
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import definition
import utils
import recordings
import glob
import os
import locking
    
try:
    ADDON     = definition.getADDON()
    ADDONid   = definition.ADDONgetAddonInfo('id')
    ADDONname = definition.ADDONgetAddonInfo('name')
    datapath  = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
    progpath  = definition.ADDONgetAddonInfo('path')
    module    = 'cleanup.py'
    utils.logdev(module,'error cleanup Started')
    utils.logdev(module,'error sys.argv= %r' % sys.argv)
    alarmName = 'cleanup'
    marker    = 'once'
    try:
        marker = sys.argv[1]
    except Exception as e:
        pass
        utils.logdev(module,'30 ERROR: %r' % e)
    alarmName = alarmName + '-' + marker   
    recordings.updateAlarm(alarmName)
    utils.logdev(module,'error cleanup after updateAlarm')
    BACKUP_PATH = definition.ADDONgetSetting('backup_path')
    utils.logdev(module,'37 error BACKUP_PATH= %r' % BACKUP_PATH)
    RECORD_PATH = definition.ADDONgetSetting('record_path')
    utils.logdev(module,'37 error RECORD_PATH= %r' % RECORD_PATH)
    titext = '*.tit'
    try:
        ###path = definition.ADDONgetSetting('record_path')
        ###path = xbmcvfs.translatePath(definition.ADDONgetSetting('record_path'))
        ###utils.logdev(module,'error record_path path= %r' % path)
        files =  glob.glob(os.path.join(RECORD_PATH, titext))
        utils.logdev(module,'error  files= %r' % files)
        for f in files:
            utils.logdev(module,'error file f= %r' % f)
            fl = f.replace('.tit','.log',-1).replace('[','?').replace(']','?')
            utils.logdev(module,'error logfile fl= %r' % fl)
            ###f = f.replace('.tit','*').replace('[','?').replace(']','?')
            fa = f.replace('.tit','.???').replace('[','?').replace(']','?')  ### 2024-08-17 only files with same as .tit
            fx = f.replace('.tit','*').replace('[','?').replace(']','?') 
            utils.logdev(module,'error fa.replaced= %r' % fa)
            utils.logdev(module,'error fx.replaced= %r' % fx)
            allfiles = glob.glob(fx)
            utils.logdev(module,'error len(allfiles)= %r' % len(allfiles))
            utils.logdev(module,'error .tit file siblings: %r' % allfiles)
            allbasicfiles = glob.glob(fa)
            utils.logdev(module,'error len(allbasicfiles)= %r' % len(allbasicfiles))
            utils.logdev(module,'error .tit basic files: %r' % allbasicfiles)
            logfiles = glob.glob(fl)
            utils.logdev(module,'error .log files: %r' % logfiles)
            videoext = definition.ADDONgetSetting('extorgcollection').split(',')
            VideoExt = ''
            for vext in videoext:
                vext = '.' + vext
                utils.logdev(module,'error vext= %r' % vext)
                if VideoExt == '' :
                    for file in allbasicfiles:
                        utils.logdev(module,'error file= %r' % file)
                        extension = os.path.splitext(file)[1]
                        utils.logdev(module,'error extension= %r' % extension)
                        if extension == vext :
                            VideoExt = vext
            utils.logdev(module,'error file has video %r with ext %r' % (f,VideoExt))
            if VideoExt == '' :
                utils.logdev(module,'error logfiles= %r' % logfiles)
                logdeleted = True
                if len(logfiles) != 0 :
                    for file in logfiles:
                        utils.logdev(module,'error DELETE FILE= %r' % file)
                        filetime = datetime.fromtimestamp(os.path.getmtime(file))
                        now = (datetime.today() - timedelta(days=1))
                        utils.logdev(module,'error file time= %r, now - 1 day= %r' % (filetime,now))
                        if now >= filetime:   ### only delete if logfile is more than one day old
                            utils.copyFiles(file,BACKUP_PATH)
                            locking.deleteLockFile(file)
                            if os.path.isfile(file):
                                logdeleted = False
                                utils.logdev(module,'error log file was not deleted= %r' % (file))
                            if logdeleted:    ### only delete if logfile was deleted
                                utils.logdev(module,'error log file WAS deleted= %r' % (file))
                                for file in allfiles:
                                    utils.logdev(module,'error DELETE FILE= %r' % file)
                                    utils.copyFiles(file,BACKUP_PATH)
                                    locking.deleteLockFile(file)
                        else:
                            utils.logdev(module,'error log file not one day old and was not deleted= %r' % (file))
                else:
                    utils.logdev(module,'error log file WAS NOT found')
                    for file in allfiles:
                        utils.logdev(module,'error DELETE FILE= %r' % file)
                        filetime = datetime.fromtimestamp(os.path.getmtime(file))
                        now = (datetime.today() - timedelta(days=1))
                        utils.logdev(module,'error file time= %r, now - 1 day= %r' % (filetime,now))
                        if now >= filetime:   ### only delete if logfile is more than one day old
                            utils.copyFiles(file,BACKUP_PATH)
                            locking.deleteLockFile(file)
                            if os.path.isfile(file):
                                logdeleted = False
                                utils.logdev(module,'error log file was not deleted= %r' % file)
                        else:
                            utils.logdev(module,'error log file not one day old and was not deleted= %r' % (file))
    except Exception as  e:
        pass
        utils.logdev(module, 'Error Exception in cleanup= %r' % e)
        
except Exception as  e:
    pass
    utils.logdev(module, 'Exception in cleanup= %s ERROR= %s' % (repr(link),repr(e)))
utils.logdev(module,'Ended')

