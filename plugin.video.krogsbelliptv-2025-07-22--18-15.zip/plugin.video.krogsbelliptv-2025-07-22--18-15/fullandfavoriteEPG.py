#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmc, xbmcvfs
# For Python 3.0 and later
from urllib.request import urlopen
import sys
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import definition
import utils
import recordings
import glob
import os
import locking
import updateepg
 
try:
    ADDON     = definition.getADDON()
    ADDONid   = definition.ADDONgetAddonInfo('id')
    ADDONname = definition.ADDONgetAddonInfo('name')
    datapath  = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
    progpath  = definition.ADDONgetAddonInfo('path')
    module    = 'fullandfavoriteEPG.py'
    definition.log('fullandfavoriteEPG: Started')
    definition.log('fullandfavoriteEPG: sys.argv= %r' % sys.argv)
    alarmName = 'fullandfavoriteEPG'
    marker    = 'once'
    try:
        marker = sys.argv[1]
    except Exception as e:
        pass
        definition.log('fullandfavoriteEPG: ERROR: %r' % e)
    alarmName = alarmName + '-' + marker   
    recordings.updateAlarm(alarmName)
    definition.log('fullandfavoriteEPG: after updateAlarm')
    BACKUP_PATH = definition.ADDONgetSetting('backup_path')
    definition.log('fullandfavoriteEPG: BACKUP_PATH= %r' % BACKUP_PATH)
    RECORD_PATH = definition.ADDONgetSetting('record_path')
    definition.log('fullandfavoriteEPG: RECORD_PATH= %r' % RECORD_PATH)
    enabled = definition.ADDONgetSetting('fullandfavoriteEPGenable')
    definition.log('fullandfavoriteEPG: enabled= %r' % enabled)
    
    try:
        ChannelFile2 = os.path.join(datapath,ADDONname) + 'fullEPG.xml'         
        definition.log('fullandfavoriteEPG: ChannelFile2= %r' % ChannelFile2)
        ChannelFile4 = 'favoritesEPG.xml'
        definition.log('CfullandfavoriteEPG: ChannelFile4= %r' % ChannelFile4)
        ROQuser = definition.ADDONgetSetting('user')
        ROQpass = definition.ADDONgetSetting('pass')
        httplinkEPG = definition.getBASEURL() + '/xmltv.php?username=' +ROQuser+ '&password=' +ROQpass +'&next_days=7'
        definition.log('fullandfavoriteEPG:  httplinkEPG= %r' % httplinkEPG)
        data = utils.readlink(httplinkEPG,ChannelFile2,module)
        definition.log('fullandfavoriteEPG: data= %r' % data)
        ### copy EPG to master.xml in Recordingsfolder
        if os.path.exists(ChannelFile2):
            definition.log('fullandfavoriteEPG: ChannelFile2 exists= %r' % ChannelFile2)
            Recordings = xbmcvfs.translatePath(definition.FileManagerPath('Recordings'))
            destf = os.path.join(Recordings,'fullEPG.xml')
            definition.log('fullandfavoriteEPG: 1 destf= %r' % destf)
            copyOK = xbmcvfs.copy(ChannelFile2, destf)
            if not copyOK:
                definition.log('fullandfavoriteEPG: Copy of %r failed - ERR: %r' %  (destf,copyOK))
            wanted = recordings.getFavoriteChannelsEPG()
            definition.log('fullandfavoriteEPG: wanted= %r' % wanted)
            utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] Select XMLTV channels Wanted: %r' % wanted)
            ###wanted = ['dr1.dk','493972']
            destf = os.path.join(Recordings,'epg',ChannelFile4)
            definition.log('fullandfavoriteEPG: 2 destf= %r' % destf)
            result = updateepg.SelectXMLTVchannels(wanted,ChannelFile2,destf)
            definition.log('fullandfavoriteEPG: SelectXMLTVchannels result= %r' % result)
        utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] Select XMLTV channels Finished with result %r' % result)
        
    except Exception as e:
        pass
        definition.log('fullandfavoriteEPG: Select XMLTV channels Exception: ' + repr(e))
        utils.notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] Select XMLTV channels failed: %r' % e)
        
except Exception as  e:
    pass
    definition.log('fullandfavoriteEPG: Exception in fullandfavoriteEPG: %r' % e)
definition.log('fullandfavoriteEPG: Ended')

