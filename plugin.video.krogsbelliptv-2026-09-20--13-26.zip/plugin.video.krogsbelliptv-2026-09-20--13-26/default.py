#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os,xbmcvfs
###quote_plus is now included in parse.
from urllib.parse import quote_plus
from urllib.parse import unquote_plus
import urllib.parse as urlparse
# For Python 3.0 and later
from urllib.request import urlopen
import urllib.request
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import calendar
import _strptime

import json
import locking,utils
import recordings
import definition
import findrecursive
import shutil
from shutil import copy2

import xmltodict
import base64
from operator import itemgetter
import updateepg
import findtvguidenotifications
import glob
import fnmatch
import subprocess
import startmarker
import io
from pathlib import PurePath
from pathlib import Path

"""
urllib.request.urlopen(url, data=None, [timeout, ]*, cafile=None, capath=None, cadefault=False, context=None)¶
"""
DEBUG = True
ADDON      = definition.getADDON()
ADDONname  = definition.ADDONgetAddonInfo('name')
ADDONid    = definition.ADDONgetAddonInfo('id')
ADDONrefer = definition.ADDONgetSetting('my_referral_name')
module     = 'default.py'
datapath   = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
progpath   = definition.ADDONgetAddonInfo('path')
origin     = ADDONid +' available_channels'
IPTVuser   = definition.ADDONgetSetting('user')
places     = definition.ADDONgetSetting('newfolders').split(',')

FavoritesCount = recordings.getCount('favorites')
ChannelsCount  = recordings.getCount('all')
CatchupCount   = recordings.getCount('catchup')
AllCounts = 'Favorites: '+FavoritesCount+' All: '+ChannelsCount+' CatchUp: '+CatchupCount
###definition.DRLYD()       = 'plugin://plugin.audio.dr.dk.netradio/'
if 'true' == definition.ADDONgetSetting('enigma2'): 
    enigma2 = True
else:
    enigma2 = False
definition.ADDONresetSetting('show_list_item','0')
searchhighlightcolor = definition.ADDONgetSetting('searchhighlightcolor')

def log(infotext,showlength=1024):
    definition.log(infotext,showlength,module)

try:
    Handle = int(sys.argv[1])
    if Handle != -1 :
        definition.ADDONsetSetting('LastHandle',str(Handle))
    else:
        Handle = definition.ADDONgetIntSetting('LastHandle')
except Exception as e:
    log('75 Handle Except: %r' % e)
    pass
    Handle = definition.ADDONgetIntSetting('LastHandle')
    log('Handle sys.argv[1] ERROR: %r' % e)

log('80 Handle= %r' % Handle)

def notification(infotext):  
    if notifyduringepgupdate:
        utils.notification(repr(infotext)) 

def FolderActions(y):
    parent = y.parent
    log('error Folder Actions parent= %r' % parent)
    choises = ['Folder Actions','Cancel']   ### Cancel must be last
    ###headline = 'What to do with: ' + str(y.name) + '\n' + str(y.parent)
    dialog = xbmcgui.Dialog()
    ###selected = dialog.select(headline, choises)
    ###result = choises[selected]
    selected = 0
    if selected == 0:
        result = choises[selected]    ### Folder Actions
        log('error Folder Actions y= %r' % y)
        headline = '[COLOR red]Folder Actions?: [/COLOR]' + str(y.name) + '\n' + str(y.parent)
        choises = ['Jump to Folder','Delete if empty','Delete Tree','Stat','Cancel']   ### Cancel must be last
        headline = 'What to do with: ' + str(y.name) + '\n' + str(y.parent)
        dialog = xbmcgui.Dialog()
        selected = dialog.select(headline, choises)
        if selected == 0:
            result = choises[selected]    ### Jump to Folder
            headline = 'Jump to Folder'  ###  
            browse = dialog.browseSingle(0, headline, '')
            log('174 error Folder Actions browse= %r' % browse)
            if browse != '':
                return Path(browse)
            else:
                return y
        elif selected == 1:
            result = choises[selected]    ### Delete if empty
            log('error Delete if empty= %r' % y)
            try:
                log('error Folder Actions Path.rmdir(y) before' )
                Path.rmdir(y) ###removes an empty directory
                log('error Folder Actions Path.rmdir(y) after' )
            except Exception as e:
                pass
                log('error Delete if empty Except: %r' % e)
                headline = 'Delete if empty Except: '  ###  + str(y.name) + '\n' + str(y.parent)
                dialog.ok(headline, '%r' % e)
            log('139 error Folder Actions parent= %r' % parent)
            return parent
        elif selected == 2:
            result = choises[selected]    ### Delete Tree
            log('error Delete Tree y= %r' % y)
            headline = '[COLOR red]Delete Tree?: [/COLOR]' ##+ str(y.name) + '\n' + str(y.parent)
            filecontents = str(y)
            log('error Delete Tree filecontents= %r' % filecontents)
            if dialog.yesno(headline, filecontents,"[COLOR red]Remove Tree?[/COLOR]","[COLOR green]Ignore[/COLOR]"):
                lockcause = 'ignore' ### Dummy command
            else:
                lockcause = 'change' ### Delete Tree command
                filecontents = str(y.lstat())
                log('error Delete Tree filecontents 2= %r' % filecontents)
                if dialog.yesno(headline, filecontents,"[COLOR red]Delete[/COLOR]","[COLOR green]Ignore[/COLOR]"):
                    lockcause = 'ignore' ### Dummy command
                else:
                    lockcause = 'change' ### Delete Tree command
                    try:
                        log('error Folder Actions shutil.rmtree(str(y)) before' )
                        shutil.rmtree(str(y))
                        log('error Folder Actions shutil.rmtree(str(y)) after' )
                    except Exception as e:
                        pass
                        log('error Delete Tree Except: %r' % e)
                        headline = 'Delete Tree Except: '  ###  + str(y.name) + '\n' + str(y.parent)
                        dialog.ok(headline, '%r' % e)
                    log('166 error Folder Actions parent= %r' % parent)
                    return parent
            log('168 error Folder Actions parent= %r' % parent)
            return parent
        elif selected == 3:
            result = choises[selected]    ### Stat
            ###filecontents = y.stat('*', follow_symlinks=True)
            filecontents = str(y.stat())
            log('error filecontents= %r' % filecontents)
            ###'os.stat_result(st_mode=33206, st_ino=133487437836189409, st_dev=1, st_nlink=1, st_uid=0, st_gid=0, st_size=219, st_atime=1716488231, st_mtime=1716375057, st_ctime=1704270183)'
            st_size=utils.sizeGMKb(y.stat().st_size)
            if st_size == '':
                st_size = '0 b'
            log('error st_size= %r' % st_size)
            st_atime=utils.humantime(y.stat().st_atime)
            log('error st_atime= %r' % st_atime)
            st_mtime=utils.humantime(y.stat().st_mtime)
            log('error st_mtime= %r' % st_mtime)
            st_ctime=utils.humantime(y.stat().st_ctime)
            log('error st_ctime= %r' % st_ctime)
            filecontents = 'Size: ' + st_size + '\nAtime: '+ st_atime + '\nMtime: '+ st_mtime + '\nCtime: '+ st_ctime + '\n\n'+ filecontents
            headline = 'Stat: ' + str(y.name) + '\n' + str(y.parent)
            dialog.textviewer(headline, filecontents)
            return parent
        else:
            result = choises[selected]    ### Cancel
            return 'Cancel'
        return y
    else:
        result = choises[selected]    ### Cancel
        return 'Cancel'   
                
def fileloop(p):
    y = ''
    dbPath = PurePath(p)
    log('error dbPath= %r' % dbPath)
    ###dirs = p.iterdir()
    dirs = []
    for x in p.iterdir():
        dirs.append(str(x))
    log('error dirs= %r' % dirs)
    sorteddirs = sorted(dirs, key=str.casefold)
    log('error sorted dirs= %r' % sorteddirs)
    result = [x for x in sorteddirs]
    ###results = ['%r' % x for x in sorteddirs]
    log('error result= %r' % result,showlength=500000)   ### directories in kodi!
    dialog = xbmcgui.Dialog()
    resultxx = ['..']
    osdelim = os.sep
    i = 0
    for xx in result:
        log('error xx= %r' % xx)  
        if Path(xx).is_dir(): xdir = ''
        else: xdir = '  '
        log('error xdir= %r' % xdir) 
        sizetxt = utils.sizeGMKb(Path(xx).stat().st_size)
        if len(sizetxt) != 0:
            sizetxt = ' - ' + sizetxt
        log('error sizetxt= %r' % sizetxt)
        ###resultxx.append(xdir + xx.split("'")[1].split('/')[-1] + sizetxt)
        resultxx.append(xdir + xx.split(osdelim)[-1] + sizetxt)
        ###resultxx.append(PurePath(xx).name.replace("')",""))
        i += 1
    if len(result) == 0:
        ###results.append('<empty>')
        resultxx.append('<empty>')
    selection = dialog.select('Folder: '+str(dbPath), resultxx)
    if selection == 1 and resultxx[1] == '<empty>':
        return '<empty>'
    elif selection == -1:
        return 'Cancel'
    elif selection > 0:
        y = result[selection-1]
        log('error fileloop y= %r' % y)
        return Path(y)
    else:
        log('error fileloop Path(PurePath(p).parent)= %r' % Path(PurePath(p).parent))
        return Path(PurePath(p).parent)
  
def filehandler(dbPath):
    try:
        log('error dbPath= %r' % dbPath)
        p = Path(dbPath)
        log('error p= %r' % p)
        pp = PurePath(p)
        log('error pp= %r' % pp)
        log('error PurePath(p)-->pp= %r' % pp.name)   ### filename
        y = fileloop(p)
        log('error loop y= %r' % y)
        if y == 'Cancel':
            return 'Cancel'
        log('error y= %r' % y) 
        
        while type(y) != str and y.is_dir():
            log('error loop y= %r' % y) 
            ydir = y
            y = fileloop(y)
                
        result = y
        log('error 2.result= %r' % result)
        ###log('error y.parent= %r' % y.parent)
        if y == 'Cancel' :
            return 'Cancel'
        if y == '<empty>':
            y = ydir
            y = FolderActions(y)
            return y
        elif y.is_file() :
            choises = ['Folder Actions','View','Copy to Log','Edit','Delete','Stat','Cancel']   ### Cancel must be last
            headline = 'What to do with: ' + str(y.name) + '\n' + str(y.parent)
            dialog = xbmcgui.Dialog()
            selected = dialog.select(headline, choises)
            ###result = choises[selected]
            if selected == 0:
                result = choises[selected]    ### Folder Actions
                y = y.parent
                y = FolderActions(y)
                return y
            elif selected == 1:
                result = choises[selected]    ### View
                filecontents = y.read_bytes()
                log('error filecontents= %r' % filecontents)
                headline = 'Viewing: ' + str(y.name) + '\n' + str(y.parent)
                dialog = xbmcgui.Dialog()
                dialog.textviewer(headline, filecontents)
                ###dialog.ok(headline, filecontents)
                return y.parent
            elif selected == 2:
                result = choises[selected]    ### Copy to log
                result += ' '
                result += utils.shareFile(str(y))
                return y.parent
            elif selected == 3:
                result = choises[selected]    ### Edit
                log('error Edit result= %r' % result)
                filecontents = y.read_text() 
                log('error Edit filecontents= %r' % filecontents)
                headline = 'Editing: ' + str(y.name) + '\n' + str(y.parent)
                newline = '\n'
                choises = filecontents.split(newline)
                if not newline in filecontents:
                    newline = ''   ### 2024-06-04 only add newline to edited line if it was there already
                log('error Edit choises= %r' % choises)
                dialog = xbmcgui.Dialog()
                selected = dialog.select(headline, choises)
                log('error selected= %r' % selected)
                headline = 'Editing line '+str(selected)+': ' + str(y.name) + '\n' + str(y.parent)
                defaultt = choises[selected]
                dialog = xbmcgui.Dialog()
                newtext = dialog.input(headline, defaultt)
                if newtext != '':
                    choises[selected] = newtext
                    log('error Edited choises= %r' % choises)
                    newchoises = ''
                    for x in choises:
                        newchoises += x + newline
                    log('error Edited newchoises= %r' % newchoises)
                    y.write_text(newchoises)
                return y.parent
            elif selected == 4:
                result = choises[selected]    ### Delete
                headline = '[COLOR red]Delete?: [/COLOR]' + str(y.name) + '\n' + str(y.parent)
                filecontents = y.read_bytes()
                log('error Delete= %r' % filecontents)
                dialog = xbmcgui.Dialog()
                if dialog.yesno(headline, filecontents,"[COLOR red]Delete[/COLOR]","[COLOR green]Ignore[/COLOR]"):
                    lockcause = 'ignore' ### Dummy command
                else:
                    lockcause = 'change' ### Delete command
                    filecontents = str(y.lstat())
                    dialog = xbmcgui.Dialog()
                    if dialog.yesno(headline, filecontents,"[COLOR red]Delete[/COLOR]","[COLOR green]Ignore[/COLOR]"):
                        lockcause = 'ignore' ### Dummy command
                    else:
                        lockcause = 'change' ### Delete command
                        y.unlink()
                return y.parent
            elif selected == 5:
                result = choises[selected]    ### Stat
                ###filecontents = y.stat('*', follow_symlinks=True)
                filecontents = str(y.stat())
                log('error filecontents= %r' % filecontents)
                ###'os.stat_result(st_mode=33206, st_ino=133487437836189409, st_dev=1, st_nlink=1, st_uid=0, st_gid=0, st_size=219, st_atime=1716488231, st_mtime=1716375057, st_ctime=1704270183)'
                st_size=utils.sizeGMKb(y.stat().st_size)
                log('error st_size= %r' % st_size)
                st_atime=utils.humantime(y.stat().st_atime)
                log('error st_atime= %r' % st_atime)
                st_mtime=utils.humantime(y.stat().st_mtime)
                log('error st_mtime= %r' % st_mtime)
                st_ctime=utils.humantime(y.stat().st_ctime)
                log('error st_ctime= %r' % st_ctime)
                filecontents = 'Size: ' + st_size + '\nAtime: '+ st_atime + '\nMtime: '+ st_mtime + '\nCtime: '+ st_ctime + '\n\n'+ filecontents
                headline = 'Stat: ' + str(y.name) + '\n' + str(y.parent)
                dialog = xbmcgui.Dialog()
                dialog.textviewer(headline, filecontents)
                return y.parent
            else:
                result = choises[selected]    ### Cancel
                return 'Cancel'
            
        utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] Test succeded ;-)\nResult= %r' % result )
    except Exception as e:
        pass
        log('TEST error: ' + repr(e))
        headline = '[COLOR red][B]' + ADDONname + '[/B][/COLOR] Except: ' 
        dialog = xbmcgui.Dialog()
        dialog.ok(headline, '%r' % e)
        utils.notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] Test failed: %r' % e)
        return y.parent
        
def mount():
    recordArchivePath = 'Not Set'
    try:
        Platform = utils.rtmpdumpFilename()
    except Exception as e:
        pass
        log('err 96 Except: %r' % e)
        log('FindPlatform ERROR: %r' % e)  # Put in LOG
        
    e = ''
            
    try:
        """
        In Python you would do basically the same routine as you would in Bash mounting shares:

        #!/usr/bin/python

        import os

        home = os.path.expanduser("~")
        mnt = home + "/mnt"

        if not os.path.exists(mnt): os.makedirs(mnt)
        os.chdir(mnt)

        os.system("mount_smbfs //username@server._smb._tcp.local/share " + mnt)
        What this does is sets the mount point to mnt in the users home directory; if the folder doesn't exist then it creates it. Then the command changes into that directory and mounts thesmb. You'll need to enter your password, or if you want to have a really non-secure way, then you can always include the password in the command (eg. username:password).

        Once your share is mounted you can check if the file exists with:

        os.path.exists(mnt + "/path/to/file")
        """
        dialog = xbmcgui.Dialog()
        #TS = '\\\\Thinkpad\\Holt5TB'
        #TS = 'smb://192.168.20.6:445/Holt5TB/Videos/'
        TS = definition.ADDONgetSetting('record_archive_path')
        if TS[-1] == '/':
            TS = TS[:-1]
        log('record_archive_path= %r' % TS)
        if TS[0:2] == 'W:':  
            log('Network Drive set to W:')
        if 1 == 1: ### Just run this
            log('test TS= %r' % (TS))
            keyboardDefault = str(TS)
            
            keyboard = dialog.input('[COLOR lightgreen][B]Please Enter NetworkPath[/B][CR][COLOR grey][I]Cancel or 25 seconds timeout = Ignore input[/I][/COLOR]',keyboardDefault, type=xbmcgui.INPUT_ALPHANUM, autoclose=25000)
                
            recordArchivePath = keyboard
            
            log('1. recordArchivePath= %r' % (recordArchivePath))
            
            home = os.path.expanduser("~")
            log('home= %r' % home)
            mnt = home + os.sep + 'mnt'
            log('mnt= %r' % mnt)
            
            if not os.path.exists(mnt): 
                log('os.path.exists(mnt)= %r' % os.path.exists(mnt))
                os.makedirs(mnt)
                os.chdir(mnt)
                
            OS = definition.ADDONgetSetting('OS')  ### Windows = '11'
            log('OS= %r' % OS)
            shell = True
            if OS == '11':  ### Windows = '11'
                recordArchivePath = recordArchivePath.replace('smb://','//').replace('/','\\').replace(':445','')
                if TS[0:2] != 'W:':
                    subprocess.call('NET USE W: /d > mnt.log 2> error.log', shell=shell) ### Dont delete W if is beeing used
                else:
                    #os.system('NET USE > mnt.log 2> error.log') 
                    subprocess.call('NET USE >> mnt.log 2>> error.log', shell=shell)
                subprocess.call('NET USE W: ' + recordArchivePath + ' >> mnt.log 2>> error.log', shell=shell)
                
                subprocess.call('NET USE >> mnt.log 2>> error.log', shell=shell)
                
                recordArchivePath = 'W:'
                subprocess.call('dir W: >> mnt.log 2>> error.log', shell=shell)
                if TS[0:2] != 'W:':
                    definition.ADDONresetSetting('record_archive_path','W:')            
                
            else:

                log('2. recordArchivePath= %r' % (recordArchivePath))
                ###result = subprocess.call("mount_smbfs " + recordArchivePath + " " + mnt, shell=shell)
                result = subprocess.call('sudo mount -t cifs ' + recordArchivePath + ' ' + mnt + ' > mnt.log 2> error.log', shell=shell)  ### 2020-05-13
                log('result= %r' % result)
                recordArchivePath = mnt ### + '/' + recordArchivePath.replace('smb://','').replace(':','_').replace('/','_')
                definition.ADDONresetSetting('record_archive_path',recordArchivePath)

            log('3. recordArchivePath= %r' % (recordArchivePath))
            
            if not os.path.exists(recordArchivePath):
                log('not os.path.exists(recordArchivePath= %r)' % recordArchivePath)
                recordArchivePath = ''
                definition.ADDONresetSetting('record_archive_path','')
    except Exception as e:
        log('err 186 Except: %r' % e)
        pass
        log('recordArchivePath error: ' + repr(e))
        
    if e == '':
        utils.notificationsend('[COLOR lightgreen][B]%s[/B][/COLOR] Mount Ended with %r' % (ADDONname,recordArchivePath)) 
    else:
        utils.notificationsend('[COLOR red][B]%s[/B][/COLOR] Mount Ended with %r\n%r' % (ADDONname,recordArchivePath,e)) 
    
def highlight_many(text, keyword, fmark, emark):
    replacement = lambda match: fmark + match.group() + emark
    ###text = re.sub("|".join(map(re.escape, keywords)), replacement, text, flags=re.I)  ### With many keywords or letters in keyword
    text = re.sub(re.escape(keyword), replacement, text, flags=re.I)
    return text
 
def highlight_many_multible_keywords(text, keywords, fmark, emark):
    replacement = lambda match: fmark + match.group() + emark
    text = re.sub("|".join(map(re.escape, keywords)), replacement, text, flags=re.I)  ### With many keywords or letters in keyword
    ###text = re.sub(re.escape(keyword), replacement, text, flags=re.I)
    return text
 
def highlight(text,keyword):
    log('1 keyword= %r' % keyword)
    text = text.replace('[COLOR ' + searchhighlightcolor + ']','[COLOR grey]')
    if keyword == '':
        return text
    keywords = keyword.split('%')
    log('2 keywords= %r' % keywords)
    keywords1 = []
    for keyw in keywords:
        if keyw != '':
           keywords1.append(keyw) 
    if len(keywords1) > 1:
        return highlight_many_multible_keywords(text, keywords, '[COLOR ' + searchhighlightcolor + ']', '[/COLOR]')
    elif len(keywords1) == 1:
        return highlight_many(text, keywords1[0], '[COLOR ' + searchhighlightcolor + ']', '[/COLOR]')
    elif len(keyword) > 0:
        ###return highlight_many(text, keyword, '[COLOR lightcoral]', '[/COLOR]')
        return highlight_many(text, keyword, '[COLOR ' + searchhighlightcolor + ']', '[/COLOR]')
    else:
        return text
            
def ireplace(findtxt, fmark, emark, data):
    log('ireplace re.compile(findtxt, flags=re.I)= %r' % re.compile(findtxt, flags=re.I))
    
    return replacetxt.join(  re.compile(findtxt, flags=re.I).split(data)  )

def play_video(path):
    """
    Play a video by the provided path.
    :param path: str
    :return: None
    """
    # Get the plugin handle as an integer number.
    __handle__ = int(sys.argv[1])
    # Create a playable item with a path to play.
    play_item = xbmcgui.ListItem(path=path)
    # Pass the item to the Kodi player.
    xbmcplugin.setResolvedUrl(__handle__, True, listitem=play_item)
   
def playurl(url):
    log("err playurl [%r]" % url)
    if url != '':
        try:
            PlayLiveUsingVLC = definition.ADDONgetSetting('PlayLiveUsingVLC')
            log('533 err PlayLiveUsingVLC= %r' % PlayLiveUsingVLC)
            
            """
            test = utils.runCommandTest('"C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc-cache-gen.exe" -h')   ### Only works on Windows
            log('err 1 test= %r' % test)
            if not test:
                test = utils.runCommandTest('"C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe" -h')     ### Only works on linux - Starts VLC on Windows
                log('err 2 test= %r' % test)
                if not test:
                    PlayLiveUsingVLC = 'false'
                    definition.ADDONresetSetting('PlayLiveUsingVLC',PlayLiveUsingVLC)
                    log('err VLC not installed - Disable Play Live using VLC')
            """
        except Exception as e:
            pass
            log('547 err PlayLiveUsingVLC Except= %r' % e)
            PlayLiveUsingVLC = 'false'
            definition.ADDONresetSetting('PlayLiveUsingVLC',PlayLiveUsingVLC)
        
        try:
            PlayingCatchup = definition.ADDONgetSetting('PlayingCatchup')
            log('573 err PlayingCatchup= %r' % PlayingCatchup)
            
        except Exception as e:
            pass
            log('577 err PlayingCatchup Except= %r' % e)
            PlayingCatchup = 'false'
            definition.ADDONresetSetting('PlayingCatchup',PlayingCatchup)
        
        if PlayLiveUsingVLC != 'true' and PlayingCatchup != 'true':
            Handle = int(sys.argv[1])
            if Handle == -1 :
                Handle = definition.ADDONgetIntSetting('LastHandle')
            log('552 err url= %r, Handle= %r' % (url,Handle))  
            listitem=xbmcgui.ListItem(path=url)
            listitem.setProperty('IsPlayable','true')
            if definition.ADDONgetSetting('fullscreen') == 'true':
                fullscreen = xbmc.getCondVisibility('System.IsFullscreen')   ### 2021-07-16
                if not fullscreen:
                    xbmc.executebuiltin("Action(togglefullscreen)")
            utils.setDefaultVideoLevel()
            ###xbmc.executebuiltin("SetVolume(100,showvolumebar)")
            
            xbmcplugin.setResolvedUrl(Handle, True, listitem)
            
            return True
        else:
            try: 
                PlayingCatchup = 'false'
                definition.ADDONresetSetting('PlayingCatchup',PlayingCatchup)
                vlcexecutive = definition.ADDONgetSetting('vlcexecutive')
                log("error vlcexecutive= %r" % vlcexecutive)
                cmd = ('"' + vlcexecutive + '" --fullscreen --play-and-stop "%s"') % url
                log("error cmd= %r" % cmd)
                x = RunCmd('"'+cmd+'"')
                log('error VLC x= %r' % x)
            except Exception as e:
                pass
                log('error 256 Except: %r' % e)
                log('Oerr pen VLC Live channel %r\nFAILED ERROR: %r' % (url,e))
                return False
        return True

def sleep(sleeptime):
    log('sleep(sleeptime= %r)' % (sleeptime))
    xbmc.sleep(sleeptime)

def saveIcons(progpathnew,datapath):
    shutil.copy(os.path.join(progpathnew,'icon.png'),os.path.join(datapath,'icon.png'))
    shutil.copy(os.path.join(progpathnew,'icon.jpg'),os.path.join(datapath,'icon.jpg'))
    shutil.copy(os.path.join(progpathnew,'fanart.jpg'),os.path.join(datapath,'fanart.jpg'))
                    
def restIcons(progpathnew,datapath):
    shutil.copy(os.path.join(datapath,'icon.png'),os.path.join(progpathnew,'icon.png'))
    shutil.copy(os.path.join(datapath,'icon.jpg'),os.path.join(progpathnew,'icon.jpg'))
    shutil.copy(os.path.join(datapath,'fanart.jpg'),os.path.join(progpathnew,'fanart.jpg'))

def getFile(name,default):
    dialog = xbmcgui.Dialog()
    file = dialog.browse(1, 'Please Enter '+str(name), '', defaultt=default)
    return file

def getName(xmlfile):
    name="KrogsbellIPTV"
    namedefault = name
    #xmlfile = os.path.join(progpath,'addon.xml')
    try:
        log('errorZ 312 getName(xmlfile= %r)' % (xmlfile))
        ###file = io.open(xmlfile,'r', encoding = 'utf-8')    ### 2022-03-31
        file = open(xmlfile,'r')
        desc = file.read(250)
        log('errorZ 316 desc= %r' % desc)
        file.close()
        name = desc.split(' name="')[1].split('"')[0]
    except Exception as e:
        pass
        #ADDONname
        log('errorZ 322 getName(xmlfile= %r) ERROR: %r' % (xmlfile,e))
    if name == '':
        return namedefault
    else:
        return name

log('error 620 ADDONname= %r,  ADDONrefer= %r' % (ADDONname, ADDONrefer))
addonxml = os.path.join(progpath, 'addon.xml')
log('error 622 addonxml= %r' % addonxml)
ADDONnameFile = getName(addonxml)
log('error 624 ADDONnameFile= %r,  ADDONrefer= %r' % (ADDONnameFile, ADDONrefer))
if ADDONnameFile != ADDONrefer and ADDONrefer != '':
    log('err ADDONname changed from: %r to %r' % (ADDONnameFile, ADDONrefer))
    try:
        ### file = open(addonxml,'rb', encoding = 'utf-8')
        file = open(addonxml,'r', encoding = 'utf-8')
        desc = file.read()
        file.close()
        desc = desc.replace('"'+ADDONnameFile+'"','"'+ADDONrefer+'"',1)
        utils.makeOldFile(addonxml)
        with open(addonxml,'w') as output:
            output.write(desc)
    except Exception as e:
        pass
        log('err ADDONname change ERROR: %r' % e)
        
if definition.ADDONgetSetting('castsubpr') != '':
    chromecast = 'Active'
    definition.ADDONresetSetting('castingon','true')
else:
    if utils.runCommandTest('mkchromecast -h'):
        chromecast = True
        definition.ADDONresetSetting('castingon','true')
    else:
        chromecast = False
        definition.ADDONresetSetting('castingon','false')

try:
    higlights = definition.ADDONgetSetting('higlights')
    ###log('0 higlights= %r' % higlights)
    higlights = higlights.split('¤¤¤¤')
    if higlights == ['']:
        higlights = []
    log('1 higlights= %r' % higlights)
    if higlights != []:
        log('higlights= %r' % higlights)
    else:
        ###higlights = []
        log('Reset: higlights= %r' % higlights)
    highlightscmp = []
    for high in higlights:
        highlightscmp.append(high.split('#description=')[0] + '#')
except Exception as e:
    log('err 335 Except: %r' % e)
    pass
    higlights = []
    log('higlights RESET= %r, ERROR %r' % (higlights,e))
highlightcount = len(higlights)
log('AT START higlights= %r' % higlights)
    
tz = definition.ADDONgetSetting('AdjustTVguideTimeZoneOffset')
if tz == '':
    TimeZone = 0
else:
    TimeZone = int(tz)  
dataepg = []
data= []

def setComandMode(command,mode):
    modeT = str(mode)
    LastCommand= definition.ADDONgetSetting('LastCommand')
    LastMode= definition.ADDONgetSetting('LastMode')
    if LastCommand != command or LastMode != modeT:
        definition.ADDONresetSetting('LastCommand',command)
        definition.ADDONresetSetting('LastMode',modeT)
        definition.ADDONresetSetting('LastCommand2',LastCommand)
        definition.ADDONresetSetting('LastMode2',LastMode)

def GetText(name,search_entered):
    log('err GetText(name= %r,search_entered)= %r' % (name,search_entered))
    keyboard = xbmc.Keyboard(search_entered, '[COLOR lightgreen][B]Please Enter '+str(name)+'[/B][CR][COLOR grey][I]<ESC> or Cancel to clear[/I][/COLOR]')
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_entered = keyboard.getText()
        if search_entered == None:
            return False 
    else:
        return False
    return search_entered 


def RecordFlagSet(sourceApp,flag):   ### 2018-11-08
    log('RecordFlagSet(sourceApp= %r,flag= %r)' % (sourceApp,flag))
    if sourceApp == '':
        ADDONsource = xbmcaddon.Addon()
    else:
        ADDONsource = xbmcaddon.Addon(sourceApp)
    datapath = xbmcvfs.translatePath(ADDONsource.getAddonInfo('profile'))
    recordflag = os.path.join(datapath, 'RecordFlag.txt')
    log('recordflag= %r,flag= %r)' % (recordflag,flag))
    FlagFile = open(recordflag, 'w')
    # Write to our text file the information we have provided and then goto next line in our file.
    # LogDev.write(repr(module) + ': ' + repr(message) + '\n')
    FlagFile.write(flag)
    FlagFile.close()

def RecordFlagGet(sourceApp):   ### 2018-11-08
    if sourceApp == '':
        ADDONsource = xbmcaddon.Addon()
    else:
        ADDONsource = xbmcaddon.Addon(sourceApp)
    datapath = xbmcvfs.translatePath(ADDONsource.getAddonInfo('profile'))
    recordflag = os.path.join(datapath, 'RecordFlag.txt')
    if os.path.isfile(recordflag):
        FlagFile = open(recordflag, 'r', encoding = 'utf-8')
        # Write to our text file the information we have provided and then goto next line in our file.
        # LogDev.write(repr(module) + ': ' + repr(message) + '\n')
        flag = FlagFile.read()
    else:
        flag = ''
    return flag

def find_files(directory, pattern):
    for root, dirs, files in os.walk(directory):
        for basename in files:
            if fnmatch.fnmatch(basename, pattern):
                filename = os.path.join(root, basename)
                yield filename

def urllibunquote_plus(cat):   ### 2021-03-18
    try:
        return unquote_plus(cat)
    except Exception as e:
        log('err 414 Except: %r' % e)
        pass
        log('Error in unquote_plus(cat= %r): %r' % (cat,e))
        return str(cat)

def urllibquote_plus(cat):   ### 2021-03-18
    try:
        return quote_plus(cat)
    except Exception as e:
        log('err 422 Except: %r' % e)
        pass
        log('Error in quote_plus(cat= %r): %r' % (cat,e))
        return str(cat)
        
def urllibquote_plusFirst(cat):
    try:
        if cat == None:
            return '0'   ### 2018-02-24
        else:
            ###return urllib.quote_plus(cat)
            return cat
    except Exception as e:
        log('err 434 Except: %r' % e)
        pass
        log('Error in urllib.quote_plus(cat): ' + repr(e))
        return str(cat)
        
def parse_date(dateString):
    return datetime.fromtimestamp(time.mktime(time.strptime(dateString, "%Y-%m-%d %H:%M:%S")))

recordPath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_path')))
if recordPath != '' and os.path.exists(recordPath):
    log('err Remember old recordPath= %r' % recordPath)
    definition.ADDONresetSetting('record_path_old',recordPath)
else:
    recordPath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_path_old')))
    log('err recordPath from record_path_old= %r' % recordPath)
    if recordPath != '' and os.path.exists(recordPath):
        log('err Use old recordPath= %r' % recordPath)
        ###definition.ADDONresetSetting('record_path_old',recordPath)
streamtype = definition.ADDONgetSetting('streamtype').replace('0','m3u8').replace('1','ts').replace('2','rtmp')
###log('streamtype= %r' % streamtype)

try:
    recordDisplayPath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_display_path')))
    log('recordDisplayPath= %r' % recordDisplayPath)
    if definition.ADDONgetSetting('record_archive_path_enable') == 'true':
        apath= definition.ADDONgetSetting('record_archive_path')
        log('apath= %r' % apath)
        recordArchivePath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_archive_path')))
        log('recordArchivePath= %r' % recordArchivePath)
    else:
        recordArchivePath = ''
    if definition.ADDONgetSetting('record_archiveb_path_enable') == 'true':
        apath= definition.ADDONgetSetting('record_archiveb_path')
        log('apath= %r' % apath)
        recordArchivebPath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_archiveb_path')))
        log('recordArchivebPath= %r' % recordArchivebPath)
    else:
        recordArchivebPath = ''
    if definition.ADDONgetSetting('record_archivef_path_enable') == 'true':
        apath= definition.ADDONgetSetting('record_archivef_path')
        log('apath= %r' % apath)
        recordArchivefPath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_archivef_path')))
        log('recordArchivefPath= %r' % recordArchivefPath)
    else:
        recordArchivefPath = ''
except Exception as e:
    log('err 465 Except: %r' % e)
    pass
    log('error in start: ' + repr(e))
if not os.path.exists(recordDisplayPath):
    recordDisplayPath = recordPath
    definition.ADDONresetSetting('record_display_path',recordDisplayPath)
"""    
if not os.path.exists(recordArchivePath):
    try:
        ¤¤¤
        In Python you would do basically the same routine as you would in Bash mounting shares:

        #!/usr/bin/python

        import os

        home = os.path.expanduser("~")
        mnt = home + "/mnt"

        if not os.path.exists(mnt): os.makedirs(mnt)
        os.chdir(mnt)

        os.system("mount_smbfs //username@server._smb._tcp.local/share " + mnt)
        What this does is sets the mount point to mnt in the users home directory; if the folder doesn't exist then it creates it. Then the command changes into that directory and mounts thesmb. You'll need to enter your password, or if you want to have a really non-secure way, then you can always include the password in the command (eg. username:password).

        Once your share is mounted you can check if the file exists with:

        os.path.exists(mnt + "/path/to/file")
        ¤¤¤
        home = os.path.expanduser("~")
        log('home= %r' % home)
        mnt = home + "/mnt"
        log('mnt= %r' % mnt)

        if not os.path.exists(mnt): 
            os.makedirs(mnt)
            os.chdir(mnt)

        os.system("mount_smbfs " + recordArchivePath + " " + mnt)
        
        if not os.path.exists(recordArchivePath):
            log('not os.path.exists(recordArchivePath= %r)' % recordArchivePath)
            recordArchivePath = ''
            definition.ADDONresetSetting('record_display_path','')
    except Exception as e:
        pass
        log('recordArchivePath error: ' + repr(e))
"""

def LOGIN():
    log('LOGIN')
    username = IPTVuser
    password = definition.ADDONgetSetting('pass')
    ###if '@' in username and not (username == '' or password == ''):
    if not (username == '' or password == ''):
        definition.ADDONresetSetting('firstrun','true')
    else:
        log('Firstrun.Launch(1)')
        import firstrun
        
        ###restoreXml=recordings.restoreLastSetupXml()
        ###log('LOGIN restoreXml= %s' % repr(restoreXml))
        
def AUTH():
        log('AUTH')
        
def sessionExpired():
    return False         

def setLiveEPGchannel(ch):
    ###  ['The Vampire Diaries -x- [Serier] .  (E4)', 
    ##'I k\xc3\xb8lvandet p\xc3\xa5 Elena Gilbert\xc2\x92s afsked, begynder s\xc3\xa6son 7 med nogle personer, der kommer igen og andre, der begynder at vakle. Mens Lily fors\xc3\xb8ger at drive en kile ind mellem Salvatorebr\xc3\xb8drerne, kan vi stadig h\xc3\xa5be p\xc3\xa5 at Stefan og Carolines k\xc3\xa6rlighed er st\xc3\xa6rk nok til at overleve. Baseret p\xc3\xa5 L. J. Smiths bogserie: The Vampire Diaries.\nNina Dobrev, Paul Wesley, Ian Somerhalder, Steven R. McQueen, Kat Graham', 
    ###'Rytec - http://forums.openpli.org', 
    ###datetime.datetime(2017, 7, 15, 3, 45), 
    ###datetime.datetime(2017, 7, 15, 4, 30)]
    ###log('epg= <%r>, \nurl= %r' % (ch[9], ch[3]))
    """
    setLiveEPG: ch= [
        0'TV2Zulu.dk', 
        1'Dybvaaaaad! [Underholdning] .  (S8E9) [Danmark]', 
        2'OrderedDict([(u\'@start\', u\'20180217182500 +0000\'), (u\'@stop\', u\'20180217190000 +0000\'), (u\'@channel\', u\'TV2Zulu.dk\'), (u\'title\', OrderedDict([(u\'@lang\', u\'da\'), (\'#text\', u\'Dybvaaaaad! [Underholdning] .  (S8E9) [Danmark]\')])), (u\'desc\', OrderedDict([(u\'@lang\', u\'da\'), (\'#text\', u"\'Dybvaaaaad kigger endnu engang dybt i flasken af tvivlsomme tv-koncepter og fjogede bem\\xe6rkninger - denne gang fra Holstebro")]))]) \nKeyError(\'sub_title\',)', 
        3 1518891900, 
        4 1518894000, 
        5"'Dybvaaaaad kigger endnu engang dybt i flasken af tvivlsomme tv-koncepter og fjogede bem\xc3\xa6rkninger - denne gang fra Holstebro \n\nEPG Created 2018-02-13 22:10:39", 
        6'', 
        7'', 
        8'', 
        9'', 
        10'', 
        11'', 
        12'', 
        13'WebGrab+Plus/w MDB & REX Postprocess -- version V2.0.1 -- Jan van Straaten - http://www.webgrabplus.com', 
        14'']
        """
    try:
        ###utils.logdev('XYZxyz setLiveEPGchannel','ch= %r' % ch)
        cats = recordings.catsfromEPGid(ch[0])
        EPGnow = updateepg.getEPGnow(cats)
        show_tv_archive_duration = ''
        tv_archive = EPGnow[2]
        tv_archive_duration = EPGnow[3]
        if type(tv_archive_duration) == int : 
            if tv_archive == 1 and tv_archive_duration > 0:
                show_tv_archive_duration = 'Days in archive %r \n' % tv_archive_duration
        
        EPG = EPGnow[0]  ### Insert live EPG in description
        chx = ch[9] + ' \n XXXXX ' + show_tv_archive_duration
        for indexX in range(0, len(EPG)):
            title = str(EPG[indexX][0])
            description = str(EPG[indexX][1]).replace('(n)','')
            ###starttime = str(EPG[indexX][3].strftime('%H:%M'))
            ###endtime = str(EPG[indexX][4].strftime('%H:%M'))
            starttime = str(datetime.fromtimestamp(EPG[indexX][3]).strftime('%H:%M'))
            endtime = str(datetime.fromtimestamp(EPG[indexX][4]).strftime('%H:%M'))
            chx += ' \n[COLOR lightgreen]'+starttime + ' - ' + endtime + '[B][/COLOR] \n[COLOR blue]'+ title+ '[/COLOR][/B] \n'+ description +' \n'
    except Exception as e:
        log('err 580 Except: %r' % e)
        pass
        log('error setLiveEPGchannel: ' + repr(e))
        chx = 'No EPG or info - ' + repr(e)
    return chx

    
def setLiveEPG(ch):
    ###  ['The Vampire Diaries -x- [Serier] .  (E4)', 
    ##'I k\xc3\xb8lvandet p\xc3\xa5 Elena Gilbert\xc2\x92s afsked, begynder s\xc3\xa6son 7 med nogle personer, der kommer igen og andre, der begynder at vakle. Mens Lily fors\xc3\xb8ger at drive en kile ind mellem Salvatorebr\xc3\xb8drerne, kan vi stadig h\xc3\xa5be p\xc3\xa5 at Stefan og Carolines k\xc3\xa6rlighed er st\xc3\xa6rk nok til at overleve. Baseret p\xc3\xa5 L. J. Smiths bogserie: The Vampire Diaries.\nNina Dobrev, Paul Wesley, Ian Somerhalder, Steven R. McQueen, Kat Graham', 
    ###'Rytec - http://forums.openpli.org', 
    ###datetime.datetime(2017, 7, 15, 3, 45), 
    ###datetime.datetime(2017, 7, 15, 4, 30)]
    ###log('epg= <%r>, \nurl= %r' % (ch[9], ch[3]))
    """
    setLiveEPG: ch= [
    0'tv2zulu', 
    1'TV2Zulu (D)', 
    2'https://danishbits.org/static/bitbucket/users/1480871336.0465.png', 
    3'http://tv2danmark-tv2zulu-live.hls.adaptive.level3.net/tv2danmark/tv2zulu/master.m3u8', 
    4'plugin.video.roqtvrec available_channels', 
    5 1, 
    6 11, 
    7'', 
    8'', 
    9'TV2Zulu.dk', 
    10' \n\rcat= tv2zulu \n\rtvg-id= TV2Zulu.dk \n\rtvg-name= TV2Zulu \n\rgroup-title= DANSK \n\rcatsinlink= ! live \n\rlink= http:/ / tv2danmark-tv2zulu-live.hls.adaptive.level3.net/ tv2danmark/ tv2zulu/ master.m3u8', 
    11 1518541841, 
    12 1480374635]
    """
    try:
        log('error setLiveEPG ch= %r' % ch)
        if ch[9] == '' and not 'series' in ch[3]:
            ch[9] = 'No EPG'
        if not ch[0] in ch[9]:
            if ch[9] == '':
                ch[9] = 'ID: ' + ch[0] + ' Fav: ' + ch[7] + '\nUpd: ' + recordings.humantime(ch[11])
            else:
                ch[9] = ch[9] + ' ID: ' + ch[0]+ ' Fav: ' + ch[7] + '\nUpd: ' + recordings.humantime(ch[11])
        ### if 'movie' in ch[3] or ch[9] == '':
        log('error setLiveEPG ch[9]= %r' % ch[9])
        if 'movie' in ch[3] or 'series' in ch[3]:
            chx = ch[10]
            log('error setLiveEPG ch[10]= %r' % ch[10])
        else:
            EPGnow = updateepg.getEPGnow(ch[0])  ### Insert live EPG in description
            log('error setLiveEPG EPGnow= %r' % EPGnow)
            EPG = EPGnow[0]
            show_tv_archive_duration = ''
            tv_archive = EPGnow[2]
            tv_archive_duration = EPGnow[3]
            if type(tv_archive_duration) == int : 
                if tv_archive == 1 and tv_archive_duration > 0:
                    show_tv_archive_duration = 'Days in archive %d\n' % tv_archive_duration
            chx = ch[9] + ' \n' + show_tv_archive_duration
            chx += 'EPG until: ' + definition.ADDONgetSetting('Channel:last_end_date').split('¤')[1]
            for indexX in range(0, len(EPG)):
                title = str(EPG[indexX][0])
                description = str(EPG[indexX][1]).replace('(n)','')
                ###starttime = str(EPG[indexX][3].strftime('%H:%M'))
                ###endtime = str(EPG[indexX][4].strftime('%H:%M'))
                starttime = str(datetime.fromtimestamp(EPG[indexX][3]).strftime('%H:%M'))
                endtime = str(datetime.fromtimestamp(EPG[indexX][4]).strftime('%H:%M'))
                chx += ' \n[COLOR lightgreen]'+starttime + ' - ' + endtime + '[B][/COLOR] \n[COLOR blue]'+ title+ '[/COLOR][/B] \n'+ description +' \n'
    except Exception as e:
        log('err 640 Except: %r' % e)
        pass
        log('error setLiveEPG: ' + repr(e))
        chx = 'No EPG or info - ' + repr(e)
    return chx

def GoHome(view):
    log('695 errorZ GoHome(view= %r)' % view)
    if view != None and view != '':
        
        ###
        userinfo = getuserinfo()
        """
        ROQTVusername = IPTVuser
        ###userinfo = ''
        userinfo = ADDONrefer + ' '
        if ROQTVusername.lower() != 'none':
            try:
                descr = 'Username= %s' % ROQTVusername
                if definition.ADDONgetSetting('panel_api') == 'true':
                    link = definition.getBASEURL() + '/panel_api.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass')
                    file = urllib.request.urlopen(link)
                    data = file.read()
                    file.close()
                    
                    ChannelFile = os.path.join(datapath,ADDONid) + '.info'
                    with open(ChannelFile,'wb') as output:
                        output.write(data)
                    ###name= Status,url= url,mode= 11,iconimage= ,cat= ,date= ,description= {u'username': u'XXX', u'status': u'Active', u'is_trial': u'0', u'created_at': u'1493734688', u'auth': 1, u'allowed_output_formats': [u'm3u8', u'ts', u'rtmp'], u'exp_date': u'1499005088', u'active_cons': u'0', u'password': u'XXXX', u'max_connections': u'1'},startDate= ,endDate= ,recordname= )
                    d = json.loads(data)
                    d1 = d['user_info']
                    
                    ###formats = d1['allowed_output_formats']
                    ###allowedformats = AllowedFormats(formats)
                    
                    ###if d1['is_trial'] == '1':
                    ###    is_trial = '\nThis is a trial '
                    ###else:
                    ###    is_trial = ''
                    now = datetime.now()
                    remainingdays = (recordings.parseDate(d1['exp_date'])-recordings.parseDate(now)).days
                    if remainingdays < 7:
                        remainingdaysS = '[B][COLOR red] '+ str(remainingdays)  + '[/COLOR][/B]'
                    else:
                        remainingdaysS = str(remainingdays)
                    ###descr = 'Username= %s \nStatus= %s \nExpire= %s%s%s\nMax connections= %s \nConnections in use= %s \nAllowed formats= %s' %(d1['username'],d1['status'],recordings.parseDate(d1['exp_date']).strftime('%Y-%m-%d %H:%M'),remainingdaysS,is_trial,d1['max_connections'],d1['active_cons'],allowedformats)
                    if definition.ADDONgetSetting('enable_record')=='true':
                        PRC = getPlannedRecordingCounts()    
                        userinfo += d1['max_connections'] + '/' +d1['active_cons'] + ' ' + remainingdaysS + ' ' + PRC
                    else:    
                        userinfo += d1['max_connections'] + '/' +d1['active_cons'] + ' ' + remainingdaysS
            
                else:
                    if definition.ADDONgetSetting('enable_record')=='true':
                        PRC = getPlannedRecordingCounts()    
                        userinfo += ' ' + PRC
                        
            except Exception as e:
                pass
                utils.notification('Error in getting '+ ADDONid + ' info! Check your User ID\n' + repr(e))
                try:
                    if definition.ADDONgetSetting('enable_record')=='true':
                        PRC = getPlannedRecordingCounts()    
                        userinfo += ' ' + PRC
                except Exception as e:
                    pass
        ###
        
        
        try:
            RytecAddon = xbmcaddon.Addon(id='service.rytecepg.downloader')
            RytecAction = RytecAddon.getSetting('active')
        except Exception as e:
            log('err 711 Except: %r' % e)
            pass
            RytecAction = ''
            log('Get Rytec Action - ERROR: %r' % e)
        """
        if userinfo != '':
            EPG_update = [userinfo]
        else:
            EPG_update = []
        ###if definition.ADDONgetSetting('Recordings') != '':
        ###    EPG_update.append('Recording')
        if locking.isAnymarkLocked():
            EPG_update.append('[COLOR red]Rec[/COLOR]')
        if locking.isScanLocked('EPG_update'):
            EPG_update.append('EPG updating')
        if definition.ADDONgetSetting('RecursiveSearch') == 'true':
            EPG_update.append('Recursive Search')
        ###if RytecAction != '':
        ###    EPG_update.append('Rytec: %s' % RytecAction)
        if locking.isAnyScanLocked():
            EPG_update.append('[COLOR blue]Scanning[/COLOR]') 
        StatusCode = ''
        if len(EPG_update) > 0:
            Status = ', '.join(EPG_update)
            StatusCode = '\n[I][COLOR grey]'+ Status + '[/COLOR][/I]'
        addDir('[COLOR white][B]%s ==> Home[/B][/COLOR]%s' % (view,StatusCode),'',1,'','','','Go to Home menu from %s' % view)
    else:
        addDir('[COLOR white][B]Home[/B][/COLOR]','',1,'','','','Go to Home menu')

def FAVORITES():
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###now= datetime.today()
    ###log('FAVORITES')
    GoHome('Favorites')
    conn = recordings.getConnection()
    c = conn.cursor()
    try:
        c.execute("SELECT * FROM channels WHERE favorite <> ? and favorite <> ? and visible=? and source=? COLLATE NOCASE", ['false','False',1,origin])  ### WHERE favorite <> 'false','False' and source=?", [cat,origin])
        ### c.execute("SELECT * FROM channels WHERE favorite <> ? and visible=? and source=? COLLATE NOCASE", ['False',1,origin])  ### WHERE id=? and source=?", [cat,origin])
        favorites = c.fetchall()
        ###favorites = sorted(favorites, key=itemgetter(9)) ### Sort by EPGname
        favorites = sorted(favorites, key=itemgetter(1)) ### Sort by name
        favorites = sorted(favorites, key=itemgetter(7)) ### Sort by Favorite Label
        ###favorites = sorted(favorites, key=itemgetter(9)) ### Sort by EPGname
    except Exception as e:
        log('error FAVORITES Except: %r' % e)
        favorites = ['ERROR: %r' % e]
        pass
        
    ###utils.logdevarray(module+'-favorite',favorites)
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        log('favorites= %r' % ch)
        if ch[7] != 'True':
            if ch[9] != '':
                favo = ch[7] +' '
            else:
                favo = ch[7]
        else:
            favo = ''
        ###if favo == '' and ch[9] == '':
        if favo == '' :
            favosplit = ''
        else:
            favosplit = ': '
        if favo != '':
            favo = '[COLOR lightgreen][B]' + favo + '[/B][/COLOR]'
        ###if ch[8] >= 1 and ch[8] != '' :   ### Channel with Archive/Catch up
        if type(ch[8]) == type('text') :
            ch[8] = 0
        if ch[8] >= 1 :   ### Channel with Archive/Catch up
            chname = favo + favosplit + '[B]' + ch[1] + ' (A'+str(ch[8])+')[/B]'
        elif ch[8] < 0:
            chname = favo + favosplit + '[B]' + ch[1] + '[/B][COLOR blue] Broken[/COLOR]'
        else:
            chname = favo + favosplit + '[B]' + ch[1] + '[/B]'
        chname = chname + ' \n[I][COLOR grey]['+ch[9].lower()+' '+ch[0]+' '+recordings.humantime(ch[11])+'][/COLOR][/I]'
        
        ###recordings.getIcon(name,cat)  ???
        iconcat = recordings.EPG_ChannelFromCat(ch[0])
        if iconcat != '':
            iconcat = recordings.IconFromCat(iconcat).lower()
        ###iconcat = ch[2]
        else:
            if ch[2] != '' and ch[2] != 'None' or not 'www.touchsportstv' in ch[2]:   
                iconcat =  ch[2]
            else:
                iconcat = recordings.IconFromCat(ch[0])
        log('Error IconFromCat(ch[0])= %r from %r' % (iconcat,ch[2]))
        addDir(chname,ch[3],200,iconcat,ch[0],'',setLiveEPG(ch))
    ###conn.commit()
    c.close()  
    setView('movies', 'main-view')  
    
def NEWSERIES():
    GoHome('New TV Series')
    now = int(time.mktime(datetime.now().timetuple()))
    missing = 0
    skip = 0
    searchcountmax = utils.intADDONgetSetting('searchcountmax')
    try:
        count = utils.intADDONgetSetting('NEWSERIEScount')
    except Exception as e:
        log('err 807 Except: %r' % e)
        pass
        count = 0
        definition.ADDONresetSetting('NEWSERIEScount',str(count))
    log('NEWCHANNELS(count= %r)'% count)
    defaultdaystotest = 62 * 24 * 60 * 60
    try:
        daystotest = utils.intADDONgetSetting('daystotest') * 24 * 60 * 60
        if daystotest == 0:
            daystotest = defaultdaystotest
    except Exception as e:
        log('err 817 Except: %r' % e)
        pass
        daystotest = defaultdaystotest
    startcount = count
    ###if not startcount == 0:
    ###    addDir('[COLOR red][B]First Channels[/B][/COLOR]','url',7007,'','','',str(0)+'[CR][CR]' + str(numberofseries))
    ftvntvini = os.path.join(datapath,'New TV Series '+ADDONrefer) + '.txt'
    LF = open(ftvntvini, 'w')
    conn = recordings.getConnection()
    c = conn.cursor()
    ####c.execute("SELECT * FROM channels WHERE NOT created = ?", [None])   #####
    createdlimit = int(now) - daystotest   ### 62 * 24 * 60 * 60  created-timedelta(days=62)
    log('err 1 createdlimit= %r = %r' % (createdlimit,recordings.humantime(createdlimit)))
    ###seriesmark = '%series%'   ### only series
    ###seriesmark = '%'   ### all channels
    c.execute("SELECT * FROM channels WHERE source=? and weight > 0",[origin])
    favorites = c.fetchall()
    log('err 1 len(favorites)= %r' % len(favorites))
    favorites = sorted(favorites, key=itemgetter(12), reverse=True) ### Sort by Created date
    try:   ### 2021-01-01
        createdlimit = favorites[0][12]
    except Exception as e:
        log('err 838 Except: %r' % e)
        pass
        log('TV Series createdlimit ERROR: %r' % e)
        createdlimit = 0
    log('err 2 createdlimit= %r = %r' % (createdlimit,recordings.humantime(createdlimit)))
    createdlimit -= daystotest
    log('err 3 createdlimit= %r = %r' % (createdlimit,recordings.humantime(createdlimit)))
    c.execute("SELECT * FROM channels WHERE source=? and created > ? and weight > 0",[origin,createdlimit])
    favorites = c.fetchall()
    numberofseries = len(favorites)
    log('err 2 len(favorites)= %r' % len(favorites))
    favorites = sorted(favorites, key=itemgetter(12), reverse=True) ### Sort by Created date
    if not startcount == 0:
        addDir('[COLOR red][B]First Channels[/B][/COLOR]','url',7007,'','','',str(0)+'[CR][CR]Total: ' + str(numberofseries))
    j = 0
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        ###now = int(time.mktime(datetime.now().timetuple()))
        created = favorites[index][12]
        ### log('created= %r' % created)
        ### timestamp = time.mktime(dt_obj.timetuple())
        ### dt_obj = datetime.fromtimestamp(timestamp)
        
        if not created is None and created != '':
            if int(created) > createdlimit : 
                log('err #%r Series: %r\nCreated %r' % (index,ch[1],recordings.humantime(created)))
                created = str(datetime.fromtimestamp(created).strftime('%Y-%m-%d'))
                if ch[8] >= 1 and ch[8] != '' :   ### Channel with Archive/Catch up
                    chname = '[COLOR lightgreen]' + created + ': [/COLOR]' + ch[1] + ' (A)'
                elif ch[8] < 0:
                    chname = '[COLOR lightgreen]' + created + ': [/COLOR]' + ch[1] + '[COLOR blue] Broken[/COLOR]'
                else:
                    chname = '[COLOR lightgreen]' + created + ': [/COLOR]' + ch[1]
                j += 1
                try:
                    LF.write(format(j, '04d') + ' ' + created + ': ' + ch[1] + '\n')
                except Exception as e:
                    pass 
                    try:
                        LF.write('Error %r %r \n' % (j,e))
                    except Exception as e:
                        pass     
                        LF.write('Error %r \n' % j)
                ###LF.write(created + ': ' + ch[1] + '\n')
                if index >= startcount+searchcountmax:
                    missing += 1
                elif index < startcount:
                    skip +=1
                    if skip == 1 and not (startcount-searchcountmax) == 0:
                        addDir('[COLOR red][B]Previous Channels[/B][/COLOR]','url',7007,'','','',str(startcount-searchcountmax)+'[CR][CR]Total: ' + str(numberofseries))
                elif startcount <= index and index < startcount+searchcountmax:
                    addDir(chname,ch[3],200,ch[2],ch[0],'','# ' + str(index) + '[CR]ID ' + ch[0]+ '[CR][CR]' +setLiveEPG(ch))
                else:
                    dialog = xbmcgui.Dialog()
                    dialog.ok('[B]' + ADDONrefer + '[/B]','[COLOR red]1247 Oops - something went wrong![/COLOR]','')
    if missing > 0:
        addDir('[COLOR red][B]Next Channels[/COLOR][/B][CR][COLOR grey][I]Remaining %d[/I][/COLOR]' % missing,'url',7007,'','','',str(startcount+searchcountmax)+'[CR][CR]Total: ' + str(numberofseries))
                
                ###addDir(chname,ch[3],200,ch[2],ch[0],'',setLiveEPG(ch))
    c.close()  
    LF.close()
    setView('movies', 'main-view')  

def NEWCHANNELS():
    GoHome('New Channels and VOD')
    now = int(time.mktime(datetime.now().timetuple()))
    missing = 0
    skip = 0
    searchcountmax = utils.intADDONgetSetting('searchcountmax')
    try:
        count = utils.intADDONgetSetting('NEWCHANNELScount')
    except Exception as e:
        log('err 906 Except: %r' % e)
        pass
        count = 0
        definition.ADDONresetSetting('NEWCHANNELScount',str(count))
    log('NEWCHANNELS(count= %r)'% count)
    defaultdaystotest = 62 * 24 * 60 * 60
    try:
        daystotest = utils.intADDONgetSetting('daystotest') * 24 * 60 * 60
        if daystotest == 0:
            daystotest = defaultdaystotest
    except Exception as e:
        log('err 916 Except: %r' % e)
        pass
        daystotest = defaultdaystotest
    startcount = count
    
    ###now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###now= datetime.today()
    ###log('NEWCHANNELS')
    ftvntvini = os.path.join(datapath,'New Channels and VOD '+ADDONrefer) + '.txt'
    LF = open(ftvntvini, 'w')
    conn = recordings.getConnection()
    c = conn.cursor()
    ####c.execute("SELECT * FROM channels WHERE NOT created = ?", [None])   #####
    createdlimit =    int(now) - daystotest   ### 62 * 24 * 60 * 60  created-timedelta(days=62)
    ###seriesmark = '%series%'   ### only series
    seriesmark = '%'   ### all channels
    c.execute("SELECT * FROM channels WHERE source=? and created < ? and created > ? and stream_url like ? and id not like ?",[origin,now,createdlimit,seriesmark,'UNL%'])
    favorites = c.fetchall()
    favorites = sorted(favorites, key=itemgetter(12), reverse=True) ### Sort by Created date
    numberofseries = len(favorites)
    if not startcount == 0:
        addDir('[COLOR red][B]First Channels[/B][/COLOR]','url',7003,'','','',str(0)+'[CR][CR]Total: ' + str(numberofseries))
    j = 0
    indeX = 0
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        ###now = int(time.mktime(datetime.now().timetuple()))
        created = favorites[index][12]
        ### log('created= %r' % created)
        ### timestamp = time.mktime(dt_obj.timetuple())
        ### dt_obj = datetime.fromtimestamp(timestamp)
        
        if not created is None and created != '':
            createdplus =    int(created) + daystotest   ### 62 * 24 * 60 * 60  created-timedelta(days=62)
            if createdplus > now : 
                created = str(datetime.fromtimestamp(created).strftime('%Y-%m-%d'))
                try:
                    if ch[8] >= 1 and ch[8] != '' :   ### Channel with Archive/Catch up
                        chname = '[COLOR lightgreen]' + created + ': [/COLOR]' + ch[1] + ' (A)'
                    elif ch[8] < 0:
                        chname = '[COLOR lightgreen]' + created + ': [/COLOR]' + ch[1] + '[COLOR blue] Broken[/COLOR]'
                    else:
                        chname = '[COLOR lightgreen]' + created + ': [/COLOR]' + ch[1]
                    j += 1
                    LF.write(format(j, '04d') + ' ' + created + ': ' + ch[1] + '\n')
                except Exception as e:
                    log('error 1012 Except ch[1]: %r' % e)
                    pass
                ###LF.write(created + ': ' + ch[1] + '\n')  ### 2023-03-15 try this
                log('err ch[0][:3]= %r' % ch[0][:3])
                if indeX >= startcount+searchcountmax:
                    missing += 1
                    indeX += 1
                elif indeX < startcount:
                    skip +=1
                    indeX += 1
                    if skip == 1 and not (startcount-searchcountmax) == 0:
                        addDir('[COLOR red][B]Previous Channels[/B][/COLOR]','url',7003,'','','',str(startcount-searchcountmax)+'[CR][CR]Total: ' + str(numberofseries))
                elif startcount <= indeX and indeX < startcount+searchcountmax:
                    addDir(chname,ch[3],200,ch[2],ch[0],'','# ' + str(indeX) + '[CR]ID ' + ch[0]+ '[CR][CR]' +setLiveEPG(ch))
                    indeX += 1
                ###elif ch[0][:3] == 'UNL':
                ###    log('Ignore channels starting with UNL')
                else:
                    log('Ignore when something went wrong!')
                    ###dialog = xbmcgui.Dialog()
                    ###dialog.ok('[B]' + ADDONrefer + '[/B]','[COLOR red]Oops - something went wrong![/COLOR]','')
    if missing > 0:
        addDir('[COLOR red][B]Next Channels[/COLOR][/B][CR][COLOR grey][I]Remaining %d[/I][/COLOR]' % missing,'url',7003,'','','',str(startcount+searchcountmax)+'[CR][CR]Total: ' + str(numberofseries))
                
                ###addDir(chname,ch[3],200,ch[2],ch[0],'',setLiveEPG(ch))
    c.close()  
    LF.close()
    setView('movies', 'main-view')  

def TVEpisodes(seriey):
    ###GoHome('TV Episodes')
    GoHome('TV Series')
    log('err TVEpisodes(seriey= %r)' % seriey)
    now = int(time.mktime(datetime.now().timetuple()))
    missing = 0
    skip = 0
    searchcountmax = utils.intADDONgetSetting('searchcountmax')
    try:
        count = utils.intADDONgetSetting('TVEpisodescount')
    except Exception as e:
        log('err 1002 Except: %r' % e)
        pass
        count = 0
        definition.ADDONresetSetting('TVEpisodescount',str(count))
    startcount = count
    log('err startcount= %r' % startcount)
    if not startcount == 0:
        addDir('[COLOR red][B]First TV Episodes[/B][/COLOR]',seriey,7006,'','','',str(0))
    conn = recordings.getConnection()
    c = conn.cursor()
    ###seriesmark = '%series%'
    seriestitle = '%' + seriey.replace('.','%').replace(' ','%') + '%'
    c.execute("SELECT * FROM channels WHERE source=? and title like ? and weight > 0 COLLATE NOCASE",[origin,seriestitle])
    favorites = c.fetchall()
    log('err TV Episodes for Series= %r\nNumber of Episodes= %r' % (seriey,len(favorites)))
    favorites = sorted(favorites, key=itemgetter(1), reverse=False) ### Sort by Title
    j = 0
    sernumprev = -1
    newseries = False
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        created = favorites[index][12]
        created = str(datetime.fromtimestamp(created).strftime('%Y-%m-%d'))
        chname = ch[1]
        weight = ch[6]
        try:
            ###sernum = int(chname.split(' S')[-1].split(' E')[0])
            sernum = weight/1000
            if sernum > sernumprev:
                newseries = True
                sernumprev = sernum
        except Exception as e:
            log('err 1038 Except: %r' % e)
            pass
            log('err get series: %r' % e)
        j += 1
        if index >= startcount+searchcountmax:
            missing += 1
        elif index < startcount:
            skip +=1
            if skip == 1 and not (startcount-searchcountmax) == 0:
                addDir('[COLOR red][B]Previous TV Episodes[/B][/COLOR]',seriey,7006,'','','',str(startcount-searchcountmax))
        elif startcount <= index and index < startcount+searchcountmax:
            if newseries:
                addDir('[COLOR lightgreen][B]Series ' + str(sernum)+'[/B][/COLOR]',ch[2],0,ch[2],ch[0],'','# ' + str(index+1))
                newseries = False
            addDir(chname,ch[3],200,ch[2],ch[0],'','# ' + str(index+1) + '[CR]ID ' + ch[0]+ '[CR][CR]' +setLiveEPG(ch))
        else:
            dialog = xbmcgui.Dialog()
            dialog.ok('[B]' + ADDONrefer + '[/B]','[COLOR red]1421 Oops - something went wrong![/COLOR]','')
    if missing > 0:
        addDir('[COLOR red][B]Next TV Episodes[/COLOR][/B][CR][COLOR grey][I]Remaining %d[/I][/COLOR]' % missing,seriey,7006,'','','',str(startcount+searchcountmax))
                
                ###addDir(chname,ch[3],200,ch[2],ch[0],'',setLiveEPG(ch))
    c.close()  
    setView('movies', 'main-view')  


def TVSeries():
    ###GoHome('TV Series')
    conn = recordings.getConnection()
    recordings.createTable(conn)
    c = conn.cursor()
    seriesmark = '%series%'
    c.execute("SELECT * FROM tvseries")
    favorites = c.fetchall()
    seriesz = sorted(favorites, key=itemgetter(0), reverse=False) ### Sort by Title
    serieszTitle = []
    for indexS in range(0, len(seriesz)):
        serieszTitle.append(seriesz[indexS][0] + ' (' + str(seriesz[indexS][1]) + ')')
    SelectedSeries = xbmcgui.Dialog().select('TV Series ('+str(len(seriesz))+')', serieszTitle)
    if SelectedSeries != -1:
        ###addDir(seriesz[SelectedSeries],seriesz[SelectedSeries],7006,'','','',str(0))
        definition.ADDONresetSetting('TVEpisodescount','0')
        TVEpisodes(seriesz[SelectedSeries][0])
    else:
        utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] No TV Series selected!')
    c.close()  
    setView('movies', 'main-view')  

def RECURSIVECHANNELS():
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###now= datetime.today()
    ###log('RECURSIVECHANNELS')
    GoHome('Recursive Search Channels')
    conn = recordings.getConnection()
    c = conn.cursor()
    ####c.execute("SELECT * FROM channels WHERE NOT created = ?", [None])   #####
    ###c.execute("SELECT * FROM channels WHERE (epg_channel like '% (R)%' or favorite=?) and visible=? and source=?", ['True',1,origin])
    c.execute("SELECT * FROM channelsRecursive WHERE visible=? and source=?", [1,origin])
    favorites = c.fetchall()
    favorites = sorted(favorites, key=itemgetter(1)) ### Sort by name
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        ###created = favorites[index][11]
        ###if created + timedelta(days=62) > datetime.today():
        ###created = favorites[index][11].strftime('%Y-%m-%d')
        ##created = str(datetime.fromtimestamp(favorites[index][11]).strftime('%Y-%m-%d'))
        created = favorites[index][11]
        if ch[8] >= 1 and ch[8] != '' :   ### Channel with Archive/Catch up
            chname = ch[1] + ' (A)'
        elif ch[8] < 0:
            chname = ch[1] + '[COLOR blue] Broken[/COLOR]'
        else:
            chname = ch[1]
        chname = chname + ' [COLOR grey]['+ch[0]+'][/COLOR]'
        addDir(chname,ch[3],200,ch[2],ch[0],'',setLiveEPG(ch))
    c.close()  
    setView('movies', 'main-view')  

def MYSELECTEDCHANNELS():
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###now= datetime.today()
    ###log('MYSELECTEDCHANNELS')
    GoHome('Direct Channels')
    nowTS = int(time.mktime(datetime.now().timetuple()))
    missing = 0
    skip = 0
    searchcountmax = utils.intADDONgetSetting('searchcountmax')
    try:
        count = utils.intADDONgetSetting('MYSELECTEDCHANNELScount')
    except Exception as e:
        log('err 1132 Except: %r' % e)
        pass
        count = 0
        definition.ADDONresetSetting('MYSELECTEDCHANNELScount',str(count))
    log('MYSELECTEDCHANNELS(count= %r)'% count)
    startcount = count
    if not startcount == 0:
        addDir('[COLOR red][B]First Channels[/B][/COLOR]','url',7004,'','','',str(0))
    conn = recordings.getConnection()
    c = conn.cursor()
    ###c.execute("SELECT * FROM channels WHERE weight > ? and weight <? and visible =?", [0,101,1])
    c.execute("SELECT * FROM channels WHERE title like '% (D)%' and visible=? and source=?", [1,origin])
    favorites = c.fetchall()
    ###favorites = sorted(favorites, key=itemgetter(6))   ### Sort by weight
    ###favorites = sorted(favorites, key=itemgetter(0))   ### Sort by id
    favorites = sorted(favorites, key=itemgetter(1))   ### Sort by title
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
        ###def addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
        ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
        if ch[8] >= 1 and ch[8] != '' :
            chname = ch[1] + ' (A)'
        elif ch[8] < 0:
            chname = ch[1] + '[COLOR blue] Broken[/COLOR]'
        else:
            chname = ch[1]
        """
        if ch[6] >= 1000:
            ch[6] -= 1000
        chname = '[COLOR lightgreen]' + str(ch[6]) +'[/COLOR]  ' + chname
        """
        if index >= startcount+searchcountmax:
            missing += 1
        elif index < startcount:
            skip +=1
            if skip == 1 and not (startcount-searchcountmax) == 0:
                addDir('[COLOR red][B]Previous Channels[/B][/COLOR]','url',7003,'','','',str(startcount-searchcountmax))
        elif startcount <= index and index < startcount+searchcountmax:
            addDir(chname,ch[3],200,ch[2],ch[0],'','# ' + str(index) + '[CR]ID ' + ch[0]+ '[CR][CR]' +setLiveEPG(ch))
        else:
            dialog = xbmcgui.Dialog()
            dialog.ok('[B]' + ADDONrefer + '[/B]','[COLOR red]1546 Oops - something went wrong![/COLOR]','')
        ###addDir(chname,ch[3],200,ch[2],ch[0],'',setLiveEPG(ch))
    ###conn.commit()
    if missing > 0:
        addDir('[COLOR red][B]Next Channels[/COLOR][/B][CR][COLOR grey][I]Remaining %d[/I][/COLOR]' % missing,'url',7004,'','','',str(startcount+searchcountmax))
    c.close()  
    setView('movies', 'main-view')
 
def NTVCHANNELS(kaddonID):
    ###addonID = definition.ADDONgetSetting('LastaddonID')
    GoHome('Channels '+kaddonID)
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    missing = 0
    skip = 0
    searchcountmax = utils.intADDONgetSetting('searchcountmax')
    try:
        count = utils.intADDONgetSetting('NTVCHANNELScount')
    except Exception as e:
        log('err 1196 Except: %r' % e)
        pass
        count = 0
        definition.ADDONresetSetting('NTVCHANNELScount',str(count))
    log('NTVCHANNELS(count= %r)'% count)
    startcount = count
    if not startcount == 0:
        addDir('[COLOR red][B]First Channels[/B][/COLOR]','url',7001,'','','',str(0))
    conn = recordings.getConnection()
    c = conn.cursor()
    kaddonIDmarker = '% ('+kaddonID+')%'
    c.execute("SELECT * FROM channels WHERE title like ? and visible=? and source=?", [kaddonIDmarker,1,origin])
    favorites = c.fetchall()
    ###favorites = sorted(favorites, key=itemgetter(6))   ### Sort by weight
    ###favorites = sorted(favorites, key=itemgetter(0))   ### Sort by id
    favorites = sorted(favorites, key=itemgetter(1))   ### Sort by title
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        if ch[8] >= 1 and ch[8] != '' :
            chname = ch[1] + ' (A)'
        elif ch[8] < 0:
            chname = ch[1] + '[COLOR blue] Broken[/COLOR]'
        else:
            chname = ch[1]
        if index >= startcount+searchcountmax:
            missing += 1
        elif index < startcount:
            skip +=1
            if skip == 1 and not (startcount-searchcountmax) == 0:
                addDir('[COLOR red][B]Previous Channels[/B][/COLOR]','url',7001,'','','',str(startcount-searchcountmax))
        elif startcount <= index and index < startcount+searchcountmax:
            addDir(chname,ch[3],200,ch[2],ch[0],'','# ' + str(index) + '[CR]ID ' + ch[0]+ '[CR][CR]' +setLiveEPG(ch))
        else:
            dialog = xbmcgui.Dialog()
            dialog.ok('[B]' + ADDONrefer + '[/B]','[COLOR red]1603 Oops - something went wrong![/COLOR]','')
    if missing > 0:
        addDir('[COLOR red][B]Next Channels[/COLOR][/B][CR][COLOR grey][I]Remaining %d[/I][/COLOR]' % missing,'url',7001,'','','',str(startcount+searchcountmax))
    c.close()  
    setView('movies', 'main-view')

def TVawayCHANNELS():
    GoHome('TVaway Channels')
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    missing = 0
    skip = 0
    searchcountmax = utils.intADDONgetSetting('searchcountmax')
    try:
        count = utils.intADDONgetSetting('TVawayCHANNELScount')
    except Exception as e:
        log('err 1249 Except: %r' % e)
        pass
        count = 0
        definition.ADDONresetSetting('TVawayCHANNELScount',str(count))
    log('TVawayCHANNELS(count= %r)'% count)
    startcount = count
    if not startcount == 0:
        addDir('[COLOR red][B]First Channels[/B][/COLOR]','url',7002,'','','',str(0))
    conn = recordings.getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE title like '% (TVA)%' and visible=? and source=?", [1,origin])
    favorites = c.fetchall()
    ###favorites = sorted(favorites, key=itemgetter(6))   ### Sort by weight
    ###favorites = sorted(favorites, key=itemgetter(0))   ### Sort by id
    favorites = sorted(favorites, key=itemgetter(1))   ### Sort by title
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        if ch[8] >= 1 and ch[8] != '' :
            chname = ch[1] + ' (A)'
        elif ch[8] < 0:
            chname = ch[1] + '[COLOR blue] Broken[/COLOR]'
        else:
            chname = ch[1]
        if index >= startcount+searchcountmax:
            missing += 1
        elif index < startcount:
            skip +=1
            if skip == 1 and not (startcount-searchcountmax) == 0:
                addDir('[COLOR red][B]Previous Channels[/B][/COLOR]','url',7002,'','','',str(startcount-searchcountmax))
        elif startcount <= index and index < startcount+searchcountmax:
            addDir(chname,ch[3],200,ch[2],ch[0],'','# ' + str(index) + '[CR]ID ' + ch[0]+'[CR][CR]'+setLiveEPG(ch))
        else:
            dialog = xbmcgui.Dialog()
            dialog.ok('[B]' + ADDONrefer + '[/B]','[COLOR red]1656 Oops - something went wrong![/COLOR]')
    if missing > 0:
        addDir('[COLOR red][B]Next Channels[/COLOR][/B][CR][COLOR grey][I]Remaining %d[/I][/COLOR]' % missing,'url',7002,'','','',str(startcount+searchcountmax))
    c.close()  
    setView('movies', 'main-view')
    
def TVawayCHANNELS_OLD():
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###now= datetime.today()
    ###log('TVawayCHANNELS')
    GoHome('TVaway Channels')
    conn = recordings.getConnection()
    c = conn.cursor()
    ###c.execute("SELECT * FROM channels WHERE weight > ? and weight <? and visible =?", [0,101,1])
    c.execute("SELECT * FROM channels WHERE title like '% (TVA)%' and visible=? and source=?", [1,origin])
    favorites = c.fetchall()
    ###favorites = sorted(favorites, key=itemgetter(6))   ### Sort by weight
    ###favorites = sorted(favorites, key=itemgetter(0))   ### Sort by id
    favorites = sorted(favorites, key=itemgetter(1))   ### Sort by title
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
        ###def addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
        ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
        if ch[8] >= 1 and ch[8] != '' :
            chname = ch[1] + ' (A)'
        elif ch[8] < 0:
            chname = ch[1] + '[COLOR blue] Broken[/COLOR]'
        else:
            chname = ch[1]
        """
        if ch[6] >= 1000:
            ch[6] -= 1000
        chname = '[COLOR lightgreen]' + str(ch[6]) +'[/COLOR]  ' + chname
        """
        addDir(chname,ch[3],200,ch[2],ch[0],'',setLiveEPG(ch))
    ###conn.commit()
    c.close()  
    setView('movies', 'main-view')
    
def HIDDENCHANNELS():
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###now= datetime.today()
    ###log('HIDDENCHANNELS')
    GoHome('Hidden Channels')
    conn = recordings.getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE visible=? and source=?", [0,origin])
    favorites = c.fetchall()
    favorites = sorted(favorites, key=itemgetter(1)) ### Sort by name
    ###utils.logdevarray(module+'-favorite',favorites)
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
        ###def addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
        ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
        if ch[8] >= 1 and ch[8] != '' :
            chname = ch[1] + ' (A)'
        elif ch[8] < 0:
            chname = ch[1] + '[COLOR blue] Broken[/COLOR]'
        else:
            chname = ch[1]
        ###chname = '[COLOR lightgreen]' + str(ch[6]) +'[/COLOR]  ' + chname
        addDir(chname,ch[3],200,ch[2],ch[0],'',setLiveEPG(ch))
    ###conn.commit()
    c.close()  
    setView('movies', 'main-view')

def ARCHIVE():
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###now= datetime.today()
    ###log('ARCHIVE')
    GoHome('Archive')
    conn = recordings.getConnection()
    c = conn.cursor()
    ###c.execute("SELECT * FROM channels WHERE catchup>? and visible=?", ['0',1])
    c.execute("SELECT * FROM channels WHERE not catchup=? and catchup>? and visible=? and source=?", ['',0,1,origin])
    favorites = c.fetchall()
    favorites = sorted(favorites, key=itemgetter(1))
    ###utils.logdevarray(module+'-favorite',favorites)
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
        ###def addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
        ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
        if ch[8] >= 1 and ch[8] != '' :
            chname = ch[1] + ' (A)'
        elif ch[8] < 0:
            chname = ch[1] + '[COLOR blue] Broken[/COLOR]'
        else:
            chname = ch[1]
        addDir(chname,ch[3],200,ch[2],ch[0],'',setLiveEPG(ch))
    ###conn.commit()
    c.close()  
    setView('movies', 'main-view')
    
    """
    favorites = c.fetchall()
    favorites = sorted(favorites, key=itemgetter(1))
    ###utils.logdevarray(module+'-archive',favorites)
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
        ###def addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
        ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
        if ch[8] >= 1 and ch[8] != '' :
            chname = ch[1] + ' (A)'
        else:
            chname = ch[1]
        addDir(chname,ch[3],200,ch[2],ch[0],'',ch[9])
    ###conn.commit()
    c.close()  
    setView('movies', 'main-view')      
    """
    
def SearchFav(name):
    dialog = xbmcgui.Dialog()
    if name == '':
        search_entered = 'True'
    else:
        search_entered = name
    keyboard = dialog.input('[COLOR lightgreen][B]Please Enter Favorite Label or True[/B][CR][COLOR grey][I]Cancel or 25 seconds timeout = Ignore input[/I][/COLOR]',search_entered, type=xbmcgui.INPUT_ALPHANUM, autoclose=25000)
    log('keyboard= %r' % keyboard)
    if keyboard.lower() == 'true':
        keyboard = 'True'
    if keyboard != '':
        search_entered = keyboard
    log('search_entered= %r' % search_entered)
    return search_entered 

def SearchEPG(name):
    savedelements = 25
    splittext = '\n'
    empty = '*Time Out - Try Again*'
    newsearch = 'New Search' + splittext
    newsearchempty = 'New Search Empty' + splittext
    searchepgvodcha = definition.ADDONgetSetting('searchepgvodcha').replace(empty + splittext,'').replace(newsearchempty,'').replace(newsearchempty+newsearchempty,'').replace(newsearch,'').replace(newsearch+newsearch,'')
    search_entered_first = searchepgvodcha.split(splittext)[0]
    search_entered_full = search_entered_first + splittext + newsearch + newsearchempty + searchepgvodcha.replace(search_entered_first + splittext,'',1)
    log('err 1481 search_entered_full = %r' % search_entered_full)
    search_entered = search_entered_full.split(splittext)
    justoneelemet = False
    try:
        test = search_entered[1]
    except Exception as e:
        pass
        log('err 1488 Except= %r' % e )
        justoneelemet = True
    try:
        log('err search_entered_full = %r' % (search_entered_full))
        test = search_entered[savedelements+1]
        search_entered_full = ''
        for i in range(0,savedelements) :
            log('err search_entered_full(%r) = %r' % (i,search_entered_full))
            search_entered_full += search_entered[i] + splittext  ### limit number of saven searches
    except Exception as e:
        pass
        log('err 1499 Except= %r' % e )
    dialog = xbmcgui.Dialog()
    if 'Search in Database' in name:
        viewS0 = definition.ADDONgetSetting('limittoseriesname')
        viewSl = definition.ADDONgetSetting('limittoseries')
        log('Exception viewS0= %r' % viewS0)
        if viewSl == '0':
            viewS = ''
        else:
            viewS = '('+viewSl+')'
        if justoneelemet :
            keyboard = dialog.input('[COLOR lightgreen][B]Please Enter '+str(name)+'[/B][CR][COLOR grey][I]! clear - l:local a:archive b:archive r:root c:cmd - n:date d:duration s:series'+viewS+' t:desc[/I][/COLOR]',search_entered[0], type=xbmcgui.INPUT_ALPHANUM, autoclose=60000)
        else:
            selection = dialog.select('[COLOR lightgreen][B]Please Enter '+str(name)+'[/B][CR][COLOR grey][I]! clear - l:local a:archive b:archive r:root c:cmd - n:date d:duration s:series'+viewS+' t:desc[/I][/COLOR]',search_entered, autoclose=60000)
            if selection < 0 :   ### Cancel
                ### Do nothing
                keyboard = empty
            elif selection == 1:
                keyboard = dialog.input('[COLOR lightgreen][B]Please Enter '+str(name)+'[/B][CR][COLOR grey][I]! clear - l:local a:archive b:archive r:root c:cmd - n:date d:duration s:series'+viewS+' t:desc[/I][/COLOR]',search_entered[0], type=xbmcgui.INPUT_ALPHANUM, autoclose=60000)
            elif selection == 2:
                keyboard = dialog.input('[COLOR lightgreen][B]Please Enter '+str(name)+'[/B][CR][COLOR grey][I]! clear - l:local a:archive b:archive r:root c:cmd - n:date d:duration s:series'+viewS+' t:desc[/I][/COLOR]','', type=xbmcgui.INPUT_ALPHANUM, autoclose=60000)
                if keyboard == '':
                    keyboard = empty
            else:
                keyboard = search_entered[selection]
    else:
        if justoneelemet :
            keyboard = dialog.input('[COLOR lightgreen][B]Please Enter '+str(name)+'[/B][CR][COLOR grey][I]! to clear. Not case sensitive search. 25 seconds timeout[/I][/COLOR]',search_entered[1], type=xbmcgui.INPUT_ALPHANUM, autoclose=25000)
        else:
            selection = dialog.select('[COLOR lightgreen][B]Please Enter '+str(name)+'[/B][CR][COLOR grey][I]! clear. Not case sensitive search. 25 seconds timeout[/I][/COLOR]',search_entered, autoclose=60000)
            if selection < 0 :   ### Cancel
                ### Do nothing
                keyboard = empty
            elif selection == 1:
                keyboard = dialog.input('[COLOR lightgreen][B]Please Enter '+str(name)+'[/B][CR][COLOR grey][I]! clear. Not case sensitive search. 25 seconds timeout[/I][/COLOR]',search_entered[0], type=xbmcgui.INPUT_ALPHANUM, autoclose=60000)
            elif selection == 2:   ### New Entry Empty
                keyboard = dialog.input('[COLOR lightgreen][B]Please Enter '+str(name)+'[/B][CR][COLOR grey][I]! clear. Not case sensitive search. 25 seconds timeout[/I][/COLOR]','', type=xbmcgui.INPUT_ALPHANUM, autoclose=60000)
                if keyboard == '':
                    keyboard = empty
            else:
                keyboard = search_entered[selection]
    log('keyboard= %r' % keyboard)
    if keyboard == '!':
        keyboard = ''
        search_entered = ''
        ###definition.ADDONresetSetting('searchepgvodcha','')
    if keyboard != '':
        search_entered = keyboard
        if search_entered in search_entered_full:
            searchepgvodcha = (search_entered + splittext + search_entered_full.replace(search_entered,'')).replace(splittext+splittext,splittext)
        else:
            searchepgvodcha = (keyboard + splittext + search_entered_full).replace(splittext+splittext,splittext)
        definition.ADDONresetSetting('searchepgvodcha',searchepgvodcha)
    return search_entered 

"""
        dialog = xbmcgui.Dialog()
        result = dialog.input(title, utils.to_unicode(default), type=xbmcgui.INPUT_ALPHANUM, autoclose=10000)
        if result:
            text = utils.to_unicode(result)
            return True, text

        return False, u'' 

def SearchEPG(name):
    search_entered = definition.ADDONgetSetting('searchepgvodcha')
    keyboard = xbmc.Keyboard(search_entered, '[COLOR lightgreen][B]Please Enter '+str(name)+'[/B][CR][COLOR grey][I]<ESC> or Cancel to clear. Not case sensitive search[/I][/COLOR]')
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_entered = keyboard.getText()
        if search_entered == None:
            return False 
        else:
            definition.ADDONresetSetting('searchepgvodcha',search_entered)   ### 2018-02-15
    else:
        definition.ADDONresetSetting('searchepgvodcha','')
        return False
    return search_entered 

"""        
def PROGRAMSEARCH():
    """
    try:  ### Get Ritzau icons from dr.dk
        iconsatdr = 'https://www.dr.dk/assets/css/shared/ritzau-logos.css'
        file = request.urlopen(iconsatdr)
        data = file.read()
        file.close()
        log('PROGRAMSEARCH iconsatdr= %r' % data)
        ### Example icon https://www.dr.dk/assets/img/ritzau-logos/ritzau-logo-dk4.png
        data = data.replace('\n','')  ### remove line feed/Carrige return
        data = data.split('../..')
        for i in range(1, len(data)):
            iconlink = data[i].split('"')[0]
            log('PROGRAMSEARCH iconlink= %r' % iconlink)
            addDir(iconlink,'url',0,'https://www.dr.dk/assets'+iconlink,'','','DR.DK ritzau-logo')
    except Exception as e:
        pass
        log('PROGRAMSEARCH iconsatdr Exception= %r' % e)
    """
    searchcount = 0
    searchcountmax = utils.intADDONgetSetting('searchcountmax') + 1
    searchtimemax = utils.intADDONgetSetting('searchtimemax') ### seconds
    searchtimereached = False
    
    GoHome('Search EPG Programs')
    
    searchText = SearchEPG('EPG Program to search for')
    if searchText:
        nowM = datetime.today().replace(microsecond=0)
        now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        nowDT= datetime.today().replace(microsecond=0)
        searchEPGallChannels = definition.ADDONgetSetting('searchEPGallChannels')
        if searchEPGallChannels.lower() == 'true':
            searchEPGallChannelsFlag = True
            searchEPGallChannelsText = 'All '
        else:
            searchEPGallChannelsFlag = False
            searchEPGallChannelsText = 'Preferred '
        addDir('[COLOR lightgreen]Search EPG Programs:[/COLOR] [B]'+searchText+'[/B]\n[I][COLOR grey]'+searchEPGallChannelsText+' Channels[/COLOR][/I]','url',2050,'','','','Search EPG in '+searchEPGallChannelsText+ADDONrefer +' Channels')
        searchTextA = '%' + searchText + '%'
        log('PROGRAMSEARCH %r Channels searchText= %r' % (searchEPGallChannelsText,searchTextA))
        conn = recordings.getConnection()
        c = conn.cursor()
        """
        setLiveEPG: ch= [
        0'tv2zulu', 
        1'TV2Zulu (D)', 
        2'https://danishbits.org/static/bitbucket/users/1480871336.0465.png', 
        3'http://tv2danmark-tv2zulu-live.hls.adaptive.level3.net/tv2danmark/tv2zulu/master.m3u8', 
        4'plugin.video.roqtvrec available_channels', 
        5 1, 
        6 11, 
        7'', 
        8'', 
        9'TV2Zulu.dk', 
        10' \n\rcat= tv2zulu \n\rtvg-id= TV2Zulu.dk \n\rtvg-name= TV2Zulu \n\rgroup-title= DANSK \n\rcatsinlink= ! live \n\rlink= http:/ / tv2danmark-tv2zulu-live.hls.adaptive.level3.net/ tv2danmark/ tv2zulu/ master.m3u8', 
        11 1518541841, 
        12 1480374635]
        
        setLiveEPG: ch= [
        0'TV2Zulu.dk', 
        1'Dybvaaaaad! [Underholdning] .  (S8E9) [Danmark]', 
        2'OrderedDict([(u\'@start\', u\'20180217182500 +0000\'), (u\'@stop\', u\'20180217190000 +0000\'), (u\'@channel\', u\'TV2Zulu.dk\'), (u\'title\', OrderedDict([(u\'@lang\', u\'da\'), (\'#text\', u\'Dybvaaaaad! [Underholdning] .  (S8E9) [Danmark]\')])), (u\'desc\', OrderedDict([(u\'@lang\', u\'da\'), (\'#text\', u"\'Dybvaaaaad kigger endnu engang dybt i flasken af tvivlsomme tv-koncepter og fjogede bem\\xe6rkninger - denne gang fra Holstebro")]))]) \nKeyError(\'sub_title\',)', 
        3 1518891900, 
        4 1518894000, 
        5"'Dybvaaaaad kigger endnu engang dybt i flasken af tvivlsomme tv-koncepter og fjogede bem\xc3\xa6rkninger - denne gang fra Holstebro \n\nEPG Created 2018-02-13 22:10:39", 
        6'', 
        7'', 
        8'', 
        9'', 
        10'', 
        11'', 
        12'', 
        13'WebGrab+Plus/w MDB & REX Postprocess -- version V2.0.1 -- Jan van Straaten - http://www.webgrabplus.com', 
        14'']
        """
        ###programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
        ###c.execute("SELECT DISTINCT p.*, c.epg_channel FROM channelsRecursive c, programs p WHERE p.channel = c.epg_channel AND p.title = ? AND p.start_date >= ?",[program, now])
        """
        ch= [
0'TV2.dk', 
1'Harry Potter og halvblodsprinsen [Film] .  (Harry Potter and the Half-Blood Prince) [England]', 2"OrderedDict([(u'@start', u'20180213133000 +0000'), (u'@stop', u'20180213160000 +0000'), (u'@channel', u'TV2.dk'), (u'title', OrderedDict([(u'@lang', u'da'), ('#text', u'Harry Potter og halvblodsprinsen [Film] .  (Harry Potter and the Half-Blood Prince) [England]')])), (u'desc', OrderedDict([(u'@lang', u'da'), ('#text', u'Lord Voldemort har strammet sit greb om b\\xe5de Mugglerne og troldmandsverdenen, og Hogwarts er ikke l\\xe6ngere sikker. Harry Potter (Daniel Radcliff) har en mistanke om, at faren allerede er indenfor skolens mure, men Dumbledore (Michael Gambon) skyder denne tanke v\\xe6k, og vil hellere forberede Harry Potter p\\xe5 den endelige kamp mod Voldemort. De ops\\xf8ger Dumbledores gamle ven og kollega, Professor Horace Slughorn (Jim Broadbent), som ligger inde med hemmelig viden om Voldemort. Mens de arbejder med dette, blomstrer romantikken ogs\\xe5 p\\xe5 Hogwarts, men det endelige slag n\\xe6rmer sig - og snart vil alt m\\xe5ske v\\xe6re forandret! nDen sjette Harry Potter-film, der baserer sig p\\xe5 J. K. Rowlings roman-serie.\\nDavid Yates\\nDaniel Radcliffe\\nRupert Grint\\nEmma Watson\\nMichael Gambon\\nAlan Rickman\\nJim Broadbent\\nHelen Bonham Carter\\nTomothy Spall')]))]) \nKeyError('sub_title',)", 
3 1518528600, 
4 1518537600, 
5 'Lord Voldemort har strammet sit greb om b\xc3\xa5de Mugglerne og troldmandsverdenen, og Hogwarts er ikke l\xc3\xa6ngere sikker. Harry Potter (Daniel Radcliff) har en mistanke om, at faren allerede er indenfor skolens mure, men Dumbledore (Michael Gambon) skyder denne tanke v\xc3\xa6k, og vil hellere forberede Harry Potter p\xc3\xa5 den endelige kamp mod Voldemort. De ops\xc3\xb8ger Dumbledores gamle ven og kollega, Professor Horace Slughorn (Jim Broadbent), som ligger inde med hemmelig viden om Voldemort. Mens de arbejder med dette, blomstrer romantikken ogs\xc3\xa5 p\xc3\xa5 Hogwarts, men det endelige slag n\xc3\xa6rmer sig - og snart vil alt m\xc3\xa5ske v\xc3\xa6re forandret! nDen sjette Harry Potter-film, der baserer sig p\xc3\xa5 J. K. Rowlings roman-serie.\nDavid Yates\nDaniel Radcliffe\nRupert Grint\nEmma Watson\nMichael Gambon\nAlan Rickman\nJim Broadbent\nHelen Bonham Carter\nTomothy Spall \n\nEPG Created 2018-02-14 10:10:40', 
6'', 
7'', 
8'', 
9'', 
10'', 
11'', 
12'', 
13'WebGrab+Plus/w MDB & REX Postprocess -- version V2.0.1 -- Jan van Straaten - http://www.webgrabplus.com', 
14'', 
15'TV2 dk (D)', 
16'https://danishbits.org/static/bitbucket/users/1485171091.8076.png', 
17'http://tv2danmark-tv2nord-live.hls.adaptive.level3.net/tv2danmark/tv2nord/master.m3u8', 
18'']
        """
        ###c.execute("SELECT p.*, c.title, c.logo, c.stream_url, c.catchup, c.id FROM programs p, channels c WHERE p.channel = c.epg_channel AND p.title LIKE ?  and (c.title like '% (D)%' or c.favorite=?) COLLATE NOCASE", [searchText,'True'])
        try:
            ###c.execute("SELECT p.*, c.title, c.logo, c.stream_url, c.catchup, c.id FROM programs p, channels c WHERE p.channel = c.epg_channel AND p.title LIKE ?  and (c.title like '% (D)%' or c.favorite=? or c.catchup>?) and c.visible=? and c.source=? COLLATE NOCASE", [searchText,'True',0,1,origin])
            if searchEPGallChannelsFlag:
                c.execute("SELECT p.*, c.title, c.logo, c.stream_url, c.catchup, c.id FROM programs p, channels c WHERE p.channel = c.epg_channel AND p.title LIKE ? and c.visible=? and c.source=? COLLATE NOCASE", [searchTextA,1,origin])   ### All Channels 2020-02-01
            else:
                c.execute("SELECT p.*, c.title, c.logo, c.stream_url, c.catchup, c.id FROM programs p, channels c WHERE p.channel = c.epg_channel AND p.title LIKE ?  and (c.title like '% (D%' or c.favorite!=? or c.catchup>?) and c.visible=? and c.source=? COLLATE NOCASE", [searchTextA,'False',0,1,origin])   ### c.favorite!=? 'False' 2020-01-24
            log('PROGRAMSEARCH searchTextA= %r,origin= %r' % (searchTextA,origin))
            favorites = c.fetchall()
        
            log('PROGRAMSEARCH favorites= %r' % favorites)
            for fav in favorites:
                log('PROGRAMSEARCH fav= %r' % fav[0])
        except Exception as e:
            log('err 1596 Except: %r' % e)
            pass
            favorites = []
        favorites = sorted(favorites, key=itemgetter(3)) ### Sort by start date
        log('PROGRAMSEARCH sorted favorites= %r' % favorites)
        for index in range(0, len(favorites)):
            ch = []
            for i in range(0, len(favorites[index])):
                if favorites[index][i] == None:
                    ch.append('')
                else:
                    ch.append(favorites[index][i])
            log('PROGRAMSEARCH ch= %r' % ch)
            """
            channels = recordings.catsfromEPGid(ch[0])
            utils.logdev('XYZxyz','channels= %r' % channels)
            utils.logdev('XYZxyz','type(channels)= %r' % type(channels))
            ###def addDir( name,url,mode,iconimage='',cat='',date='',description='',startDate='',endDate='',recordname='',whatsup=''):
            foundprograms = []
            if type(channels) not in [str, unicode]:
                for cha in channels:
                    if cha != '0':
                        foundprograms.append(cha)
            else:
                if channels != '0':
                    foundprograms.append(channels)
                
            for fprograms in foundprograms:
                guide = updateepg.getEPG(fprograms)
                try:
                    guideEPG = guide[0]
                except Exception as e:
                    pass
                    log('Error in getting TV Guide\n' + repr(e))
                    return
                nameEPG = guide[1]
                tv_archive = guide[2]
                tv_archive_duration= guide[3]
                epg_channel_id = guide[4]
                
                namech = nameEPG
                if namech == 'None' or namech == '':
                    namech = recordings.ChannelName(fprograms)
            addDir(namech +': '+ch[1],ch[3],200,ch[2],fprograms,'',ch[5])
            """
            try:
                startDate= ch[3]
                if type(startDate) == int:
                    startDate= datetime.fromtimestamp(float(ch[3]))
                    endDate= datetime.fromtimestamp(float(ch[4]))
                else:
                    startDate= ch[3]
                    endDate= ch[4]
                ArchiveOffset = definition.ADDONgetSetting('archiveoffset')
                try:
                    ArchiveOffset = int(ArchiveOffset)
                except Exception as e:
                    log('error ArchiveOffset Except: %r' % e)
                    pass
                    ArchiveOffset = TimeZone
                log('error ArchiveOffset= %r' % ArchiveOffset)
                startDateCU= startDate + timedelta(seconds = (ArchiveOffset - TimeZone)*3600 -60)  ### USE UK TimeZone and start 1 minutes early
            except Exception as e:
                log('err 1655 Except: %r' % e)
                pass
                startDate=''
                startDateCU=''
                endDate=''
                log('PROGRAMSEARCH Error in getting dates\n' + repr(e))
            name= ch[15] + ': [B]' + ch[1] + '[/B]'
            cat = ch[19]
            namech = name
            newiconurl = ch[16]
            channelurl = ch[17]
            tv_archive = ch[18]   ### Number of days in archive - 0 No archive on channel
            if type(tv_archive) != int:
                log('tv_archive= %r, type(tv_archive)= %r' % (tv_archive, type(tv_archive)))
                tv_archive = 0
            recordname= ch[1]
            StartDateTime = ''
            Duration = ''
            try:
                StartDateTime = ' \nStart ' + startDate.strftime('%Y-%m-%d %H:%M')
                dura = (endDate - startDate)//60   ### 2021-06-21
                Duration = ' \nDuration [' + str(dura)[-5:] +'] \n'  ###2018-03-08
                #Duration = ' \nDuration ' + str(dura) + ' \n'
                EPGtime = ''
                try:
                    if 'EPG Created ' in ch[5]:
                        EPGtime = 'EPG Created ' + ch[5].split('EPG Created ')[1][0:19]+'\n'
                except Exception as e:
                    log('err 1682 Except: %r' % e)
                    pass 
                description= (namech + ' (' +cat+'):'+StartDateTime+Duration + EPGtime +'\n'+ch[5])   ###.encode("utf-8")
                log('PROGRAMSEARCH Duration= %r' % Duration )
            except Exception as e:
                log('err 1686 Except: %r' % e)
                pass
                log('PROGRAMSEARCH Error in getting duration\n' + repr(e))
                description = (recordings.latin1_to_ascii_force(namech) + ' (' +recordings.latin1_to_ascii_force(cat)+'):' +StartDateTime+Duration+ recordings.latin1_to_ascii_force(ch[1]))
            description = description.replace('(n)','\n').replace('.n)','. \n') 
            try:
                ### change \" to " - it comes from master.xml
                recordname = recordname.replace('\\"','"')
                name = name.replace('\\"','"')
                
                archiveDateCU = nowDT - timedelta(days = tv_archive)
                if tv_archive > 0 and archiveDateCU < startDate and startDate < nowDT:  ### startDate <-- endDate
                    name='[COLOR salmon]%s[/COLOR]'%(name)
                    """
                    colondelimit = False
                    if ':' in recordname:
                        recordname = recordname.replace(':','[',1)
                        colondelimit = True
                    """
                    if '[' in recordname:   ### 2018-04-21
                        log('[ in recordname= %r' % recordname) 
                    ###xbmcgui.Dialog().ok( ADDONname, 'name= %r\nrecordname= %r' % (name,recordname))
                    log('xYzx name= %r\nrecordname= %r' % (name,recordname))
                    
                    if '[' in recordname:   ### 2018-07-15
                        namecolor='[B][COLOR salmon]'
                        name = ch[15] + ': '+ namecolor + recordname.replace('[','[/COLOR][/B]\n[COLOR lemonchiffon][I][',1) + '[/COLOR][/I]'
                        recordnamesizes = recordname.replace('[','aXaXa',1).split('aXaXa')
                        name = name.split('\n')
                        line1 = name[0]
                        lenline1 = len(recordnamesizes[0])
                        line2 = name[1]
                        lenline2 = len(recordnamesizes[1])
                        if lenline1 < lenline2:
                            line1 = line1 + ' ' * (lenline2 - lenline1 )
                        #dialog = xbmcgui.Dialog()
                        #dialog.ok('[COLOR white]ROQTV Test[/COLOR]',recordname,repr(recordnamesizes)+ ' 1= ' +repr(lenline1)+ ' 2= ' + repr(lenline2))

                        name = line1 +'\n' + line2  
                       
                    time=startDate.strftime('Arc %d.%m %H:%M  ')
                    ###addDir(name,url,mode,iconimage='',cat='',date='',description='',startDate='',endDate='',whatsup='')
                    ###duration = str(timedelta.total_seconds(endDate - startDate)//60 + 16)  ### duration plus 15 min
                    ###utils.logdev(module+'repr(endDate - startDate)=',repr(endDate - startDate))
                    ### ANDROID and Linux version
                    duration = str(int(repr(endDate - startDate).replace('datetime.timedelta(seconds=','').split(')')[0].split(',')[0])//60 + 16) ### duration plus 15 min + 1 min ahead   ### 2021-06-21
                    ###start    = startDateCU.strftime('%Y-%m-%d:%H-%M')
                    start    = startDateCU.strftime('%Y-%m-%d:%H:%M:%S')
                    
                    ROQTVusername = IPTVuser
                    if ROQTVusername.lower() != 'none':
                        ###url = definition.getBASEURL() + '/streaming/timeshift.php?username='+ROQTVusername+'&password='+definition.ADDONgetSetting('pass')+'&stream='+cat+'&duration='+duration+'&start='+start
                        ### /streaming/timeshift.php?username=8dnebn9ii5&password=7jbq9bx6nt&stream=493978&duration=53&start=2024-08-16:00-22 HTTP/1.1 
                        ### /timeshift/8dnebn9ii5/7jbq9bx6nt/35/2024-08-16:00:30:00/493978.m3u8
                        url = definition.getBASEURL() + '/timeshift/'+IPTVuser+'/'+definition.ADDONgetSetting('pass')+'/'+duration+'/'+start+'/'+cat+'.m3u8'
                    else:
                        url = 'url'
                    log('timeshift url= ' + url)
                    nowJust = datetime.today().replace(microsecond=0)
                    searchcount += 1
                    if searchcount >= searchcountmax and not searchtimereached:
                        if searchcount == searchcountmax:
                            usedtime = str(int((nowJust-nowM).total_seconds()))
                            addDir('[COLOR red][B]Search limit reached ('+str(searchcountmax-1)+') in '+usedtime+' seconds[/B][/COLOR]' ,'',5011,'','0','0','Limit your search!\n\nClick to change limit','0','0','')
                    else:
                        if nowJust > nowM + timedelta(seconds = searchtimemax):
                            if not searchtimereached:
                                addDir('[COLOR red][B]Search time reached ('+str(searchtimemax)+' seconds)[/B][/COLOR]' ,'',5010,'','0','0','Limit your search!\n\nClick to change limit','0','0','')
                                searchtimereached = True
                        else:
                            addDir(highlight(time+name, searchText),url,2020,newiconurl,cat,startDate,highlight(description, searchText),startDate,endDate,recordname) ### Watch or record Archive
                elif tv_archive < 1 and endDate < nowDT :  ### Show History (1 day)
                    try:
                        hourstoshow = utils.intADDONgetSetting('showhistoryintvguide')
                        ###log('H start= %r, end= %r' % (startDate, endDate))
                        name='[COLOR cyan]%s[/COLOR]'%(name)
                        
                        if '[' in recordname:   ### 2018-04-21
                            namecolor='[B][COLOR cyan]'
                            name = ch[15] + ': '+ namecolor + recordname.replace('[','[/COLOR][/B]\n[COLOR lemonchiffon][I][',1) + '[/COLOR][/I]'
                            recordnamesizes = recordname.replace('[','aXaXa',1).split('aXaXa')
                            name = name.split('\n')
                            line1 = name[0]
                            lenline1 = len(recordnamesizes[0])
                            line2 = name[1]
                            lenline2 = len(recordnamesizes[1])
                            if lenline1 < lenline2:
                                line1 = line1 + ' ' * (lenline2 - lenline1 )
                            #dialog = xbmcgui.Dialog()
                            #dialog.ok('[COLOR white]ROQTV Test[/COLOR]',recordname,repr(recordnamesizes)+ ' 1= ' +repr(lenline1)+ ' 2= ' + repr(lenline2))

                            name = line1 +'\n' + line2  
                        
                        time=startDate.strftime('His %d.%m %H:%M  ')
                        if endDate > nowDT - timedelta(hours = hourstoshow):
                            nowJust = datetime.today().replace(microsecond=0)
                            searchcount += 1
                            if searchcount >= searchcountmax and not searchtimereached:
                                if searchcount == searchcountmax:
                                    usedtime = str(int((nowJust-nowM).total_seconds()))
                                    addDir('[COLOR red][B]Search limit reached ('+str(searchcountmax-1)+') in '+usedtime+' seconds[/B][/COLOR]' ,'',5011,'','0','0','Limit your search!\n\nClick to change limit','0','0','')
                            else:
                                if nowJust > nowM + timedelta(seconds = searchtimemax):
                                    if not searchtimereached:
                                        addDir('[COLOR red][B]Search time reached ('+str(searchtimemax)+' seconds)[/B][/COLOR]' ,'',5010,'','0','0','Limit your search!\n\nClick to change limit','0','0','')
                                        searchtimereached = True
                                else:
                                    addDir(highlight(time+name, searchText),'url',200,newiconurl,cat,startDate,highlight(description, searchText),startDate,endDate,recordname)
                    except Exception as e:
                        log('err 1789 Except: %r' % e)
                        pass
                elif startDate <= nowDT and nowDT <= endDate:
                    name='[COLOR yellow]%s[/COLOR]'%(name)
                    
                    if '[' in recordname:   ### 2018-04-21
                        namecolor='[B][COLOR yellow]'
                        name = ch[15] + ': '+ namecolor + recordname.replace('[','[/COLOR][/B]\n[COLOR lemonchiffon][I][',1) + '[/COLOR][/I]'
                        recordnamesizes = recordname.replace('[','aXaXa',1).split('aXaXa')
                        name = name.split('\n')
                        line1 = name[0]
                        lenline1 = len(recordnamesizes[0])
                        line2 = name[1]
                        lenline2 = len(recordnamesizes[1])
                        if lenline1 < lenline2:
                            line1 = line1 + ' ' * (lenline2 - lenline1 )
                        #dialog = xbmcgui.Dialog()
                        #dialog.ok('[COLOR white]ROQTV Test[/COLOR]',recordname,repr(recordnamesizes)+ ' 1= ' +repr(lenline1)+ ' 2= ' + repr(lenline2))

                        name = line1 +'\n' + line2  
                    
                    time=startDate.strftime('Now %d.%m %H:%M  ')
                    url = channelurl
                    nowJust = datetime.today().replace(microsecond=0)
                    searchcount += 1
                    if searchcount >= searchcountmax and not searchtimereached:
                        if searchcount == searchcountmax:
                            usedtime = str(int((nowJust-nowM).total_seconds()))
                            addDir('[COLOR red][B]Search limit reached ('+str(searchcountmax-1)+') in '+usedtime+' seconds[/B][/COLOR]' ,'',5011,'','0','0','Limit your search!\n\nClick to change limit','0','0','')
                    else:
                        if nowJust > nowM + timedelta(seconds = searchtimemax):
                            if not searchtimereached:
                                addDir('[COLOR red][B]Search time reached ('+str(searchtimemax)+' seconds)[/B][/COLOR]' ,'',5010,'','0','0','Limit your search!\n\nClick to change limit','0','0','')
                                searchtimereached = True
                        else:
                            addDir(highlight(time+name, searchText),url,200,newiconurl,cat,startDate,highlight(description, searchText),startDate,endDate,recordname)
                elif startDate > nowDT and endDate > nowDT:
                    ### Find programs that are recording
                    recprograms = recordings.isRecording(cat,recordname,startDate,endDate)
                    log('PROGRAMSEARCH Is program: %r beeing recorded? SD= %r ED= %r ActivePrograms: %r' %(name,startDate,endDate,recprograms))
                    if recprograms:
                        name='[COLOR red]%s[/COLOR]'%(name)
                        namecolor='[B][COLOR red]'
                    else:
                        name='[COLOR lightgreen]%s[/COLOR]'%(name)
                        namecolor='[B][COLOR lightgreen]'
                    
                    time=startDate.strftime('Rec %d.%m %H:%M  ')
                    nowJust = datetime.today().replace(microsecond=0)
                    searchcount += 1
                    if searchcount >= searchcountmax and not searchtimereached:
                        if searchcount == searchcountmax:
                            usedtime = str(int((nowJust-nowM).total_seconds()))
                            addDir('[COLOR red][B]Search limit reached ('+str(searchcountmax-1)+') in '+usedtime+' seconds[/B][/COLOR]' ,'',5011,'','0','0','Limit your search!\n\nClick to change limit','0','0','')
                    else:
                        if nowJust > nowM + timedelta(seconds = searchtimemax):
                            if not searchtimereached:
                                addDir('[COLOR red][B]Search time reached ('+str(searchtimemax)+' seconds)[/B][/COLOR]' ,'',5010,'','0','0','Limit your search!\n\nClick to change limit','0','0','')
                                searchtimereached = True
                        else:  
                            if '[' in recordname:   ### 2018-04-21
                                name = ch[15] + ': '+ namecolor + recordname.replace('[','[/COLOR][/B]\n[COLOR lemonchiffon][I][',1) + '[/COLOR][/I]'
                                recordnamesizes = recordname.replace('[','aXaXa',1).split('aXaXa')
                                name = name.split('\n')
                                line1 = name[0]
                                lenline1 = len(recordnamesizes[0])
                                line2 = name[1]
                                lenline2 = len(recordnamesizes[1])
                                if lenline1 < lenline2:
                                    line1 = line1 + ' ' * (lenline2 - lenline1 )
                                #dialog = xbmcgui.Dialog()
                                #dialog.ok('[COLOR white]ROQTV Test[/COLOR]',recordname,repr(recordnamesizes)+ ' 1= ' +repr(lenline1)+ ' 2= ' + repr(lenline2))
        
                                name = line1 +'\n' + line2  
                            else:
                                name = '[B]' + name ### + '[/B]'
                            
                            addDir(highlight(time+name, searchText),'url',2001,newiconurl,cat,startDate.strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20'),highlight(description, searchText),startDate.strftime('%Y-%m-%d %H:%M:%S'),endDate.strftime('%Y-%m-%d %H:%M:%S'),recordname) ### Record
                else:
                    log('PROGRAMSEARCH Out of Range start= %r, end= %r' % (startDate, endDate))
            except Exception as e:
                log('err 1869 Except: %r' % e)
                pass
                log('PROGRAMSEARCH Error in setting menu\n' + repr(e))
        if searchcount == 0 and not searchtimereached:
            nowJust = datetime.today().replace(microsecond=0)
            usedtime = str(int((nowJust-nowM).total_seconds()))
            addDir('[COLOR lightgreen][B]Search finished in '+usedtime+' seconds, no EPG Programs found[/B][/COLOR]' ,'url',2050,'','0','0','Searched for: '+searchText.replace('%',''),'0','0','')
        if searchcount > 0 and searchcount < searchcountmax and not searchtimereached:
            usedtime = str(int((nowJust-nowM).total_seconds()))
            addDir('[COLOR lightgreen][B]Search finished in '+usedtime+' seconds, found '+str(searchcount)+' EPG Programs[/B][/COLOR]' ,'url',2050,'','0','0','Searched for: '+searchText.replace('%',''),'0','0','')    
        c.close()  
        setView('movies', 'main-view')      
              
def CHANNELSSEARCH():
    searchcount = 0
    try:
        searchcountmax = utils.intADDONgetSetting('searchcountmax') + 1
    except Exception as e:
        pass   
        searchcountmax = 100
    try:
        searchtimemax = utils.intADDONgetSetting('searchtimemax') ### seconds
    except Exception as e:
        pass
        searchtimemax = 20
    searchtimereached = False
    
    GoHome('Search Channels')
    
    searchText = SearchEPG('Channel or VOD to search for')
    ###dialog = xbmcgui.Dialog()
    ###dialog.ok('[COLOR white]ROQTV Test[/COLOR]','Channel or VOD to search for',repr(searchText))
    if searchText != '' and searchText != None and searchText != False:
        nowM = datetime.today().replace(microsecond=0)
        now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        addDir('[COLOR lightgreen]Search Channels and VOD: [/COLOR][B]'+searchText+'[/B]','url',2008,'','','','Search all '+ADDONrefer +' Channels, VOD and all direct channels')
        searchTextA = '%' + searchText + '%'
        
        conn = recordings.getConnection()
        c = conn.cursor()
        c.execute("SELECT * FROM channels WHERE stream_url <> ? and visible=? and title LIKE ?  and source=? COLLATE NOCASE", ['url',1,searchTextA,origin])   ### 2018-12-07
        favorites = c.fetchall()
        ###utils.logdev(module+'-archive',repr(len(favorites)))
        favorites = sorted(favorites, key=itemgetter(1))
        ###utils.logdev(module+'-archive',repr(len(favorites))) 
        for index in range(0, len(favorites)):
            ch = []
            for i in range(0, len(favorites[index])):
                if favorites[index][i] == None:
                    ch.append('')
                else:
                    ch.append(favorites[index][i])
            ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
            ###def addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
            ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
            if ch[8] >= 1 and ch[8] != '' :
                chname = ch[1] + ' (A)'
            elif ch[8] < 0:
                chname = ch[1] + '[COLOR blue] Broken[/COLOR]'
            else:
                chname = ch[1]
            ###if ch[2].lower()[:4] == 'http':
            ###    logo = ch[2]
            ###else:
            ###    logo = 'vodlogo'   ### 2020-03-12
            if ch[0].lower()[:4] != 'http':
                logo = recordings.IconFromCat(ch[0])
            else:
                logo = 'vod4'
            ###chx = ch[10]    ### Don't insert live EPG in description
            log('logo= %r, ch[2]= %r' % (logo,ch[2]))
            nowJust = datetime.today().replace(microsecond=0)
            searchcount += 1
            if searchcount >= searchcountmax and not searchtimereached:
                if searchcount == searchcountmax:
                    usedtime = str(int((nowJust-nowM).total_seconds()))
                    addDir('[COLOR red][B]Search limit reached ('+str(searchcountmax-1)+') in '+usedtime+' seconds[/B][/COLOR]' ,'',5011,'','0','0','Limit your search!\n\nClick to change limit','0','0','')
            else:
                if nowJust > nowM + timedelta(seconds = searchtimemax):
                    if not searchtimereached:
                        addDir('[COLOR red][B]Search time reached ('+str(searchtimemax)+' seconds)[/B][/COLOR]' ,'',5010,'','0','0','Limit your search!\n\nClick to change limit','0','0','')
                        searchtimereached = True
                else:
                    ###addDir(name,url,mode,iconimage='',cat='',date='',description='',startDate='',endDate='',recordname='',whatsup='')
                    addDir(highlight(chname,searchText),ch[3],200,logo,ch[0],'',highlight(setLiveEPG(ch),searchText))
        ###conn.commit()
        if searchcount == 0 and not searchtimereached:
            nowJust = datetime.today().replace(microsecond=0)
            usedtime = str(int((nowJust-nowM).total_seconds()))
            addDir('[COLOR lightgreen][B]Search finished in '+usedtime+' seconds, no Channels or VOD found[/B][/COLOR]' ,'url',2008,'','0','0','Searched for: '+searchText.replace('%',''),'0','0','')
        if searchcount > 0 and searchcount < searchcountmax and not searchtimereached:
            usedtime = str(int((nowJust-nowM).total_seconds()))
            addDir('[COLOR lightgreen][B]Search finished in '+usedtime+' seconds, found '+str(searchcount)+' Channels and VOD[/B][/COLOR]' ,'url',2008,'','0','0','Searched for: '+searchText.replace('%',''),'0','0','')  
        c.close()  
        setView('movies', 'main-view')      
        
def CHANNELSROQ():
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###now= datetime.today()
    ###log('CHANNELSROQ')
    GoHome('Channels')
    conn = recordings.getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE stream_url <> ? and visible=?", ['url',1])
    favorites = c.fetchall()
    ###utils.logdev(module+'-archive',repr(len(favorites)))
    favorites = sorted(favorites, key=itemgetter(1))
    ###utils.logdev(module+'-archive',repr(len(favorites)))
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
        ###def addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
        ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
        if ch[8] >= 1 and ch[8] != '' :
            chname = ch[1] + ' (A)'
        elif ch[8] < 0:
            chname = ch[1] + '[COLOR blue] Broken[/COLOR]'
        else:
            chname = ch[1]
        ###chx = ch[10]    ### Don't insert live EPG in description
        ###log('cat= %r, description= %r' % (ch[0],setLiveEPG(ch)))  ### 2017-07-29
        addDir(chname,ch[3],200,ch[2],ch[0],'',setLiveEPG(ch))
    ###conn.commit()
    c.close()  
    setView('movies', 'main-view')      
"""

http://roq-tv.net:25461/live/XXX/XXXX!/631.ts

http://roq-tv.net:25461/streaming/timeshift.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass') +'&stream=628&duration=120&start=2017-05-03:15-00

import urllib
mp3file = request.urlopen("http://www.example.com/songs/mp3.mp3")
with open('test.mp3','wb') as output:
  output.write(mp3file.read())

def addDir(name,url,mode,iconimage,description,fanart,genre=''):
        u=sys.argv[0]+"?url="+urllibquote_plus(url)+"&mode="+str(mode)+"&name="+urllibquote_plus(name)+"&iconimage="+urllibquote_plus(iconimage)+"&description="+urllibquote_plus(description)+"&genre="+urllibquote_plus(genre)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description,"Genre": genre} )
        liz.setProperty('fanart_image',str(fanart))
        if mode ==200:
            liz.setProperty("IsPlayable","true")
            ok=xbmcplugin.addDirectoryItem(handle=Handle,url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=Handle,url=u,listitem=liz,isFolder=True)
        return ok
        .......
        try:
        kodilog = xbmcvfs.translatePath(os.path.join('special://logpath' , 'kodi.log'))
        #print kodilog
        try: logfile = open(kodilog,'r')
        except Exception as e:
            pass
            kodilog = xbmcvfs.translatePath(os.path.join('special://logpath' , 'xbmc.log'))
            #print kodilog
            try: logfile = open(kodilog,'r')
            except Exception as e:
                pass
                kodilog = xbmcvfs.translatePath(os.path.join('special://logpath' , 'tvmc.log'))
                #print kodilog
                logfile = open(kodilog,'r')
        #print kodilog
        #print repr(logfile)
        line0 = logfile.readline()
        #print line0
        line1 = logfile.readline()
        
        ............
        
#EXTM3U
#EXTINF:-1 tvg-id="BBC One London" tvg-name="UK: BBC ONE HD" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/1/1a/BBC_One_2002.png" group-title="UK: ENTERTAINMENT",UK: BBC ONE HD
http://roq-tv.net:25461/live/XXX/XXXX!/281.ts
#EXTINF:-1 tvg-id="BBC 1 CI" tvg-name="UK: BBC ONE CI (VPN OR UK ONLY)" tvg-logo="http://www.tv-logo.com/pt-data/uploads/images/logo/bbc_one_channel_islands.jpg" group-title="UK: ENTERTAINMENT",UK: BBC ONE CI (VPN OR UK ONLY)
http://roq-tv.net:25461/live/XXX/XXXX!/1457.ts

"""

def getuserinfo():
    userinfo = ADDONrefer + ' '
    ROQTVusername = IPTVuser
    ###if (ROQTVusername.lower() != 'none' or definition.ADDONgetSetting('internet') != 'true'):
    if (definition.ADDONgetSetting('enable_record') == 'true' and definition.ADDONgetSetting('panel_api') == 'true'): ### 2023-01-20 if recording enabled
        try:
            ChannelFile = os.path.join(datapath,ADDONid) + '.info'
            ### Only read .info file from web if it is more than 1 hour old
            data = ''
            log('2559 error ChannelFile= %r' % ChannelFile)
            if os.path.isfile(ChannelFile):
                now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                nowTS = int(time.mktime(datetime.now().timetuple()))
                log('nowTS= %r' % nowTS)
                filecreated = int(os.path.getmtime(ChannelFile))
                log('error ChannelFile= %r' % ChannelFile)
                log('filecreated= %r' % filecreated)
                t = nowTS - filecreated - 3600 * 12    ### accept one time old file
                log('nowTS - filecreated= %r' % t)
                
                if t < 0:
                    file = open(ChannelFile)
                    data = file.read()
                    log('err data= %r' % (data))
                    file.close()
                else:
                    if definition.ADDONgetSetting('panel_api') == 'true':
                        link = definition.getBASEURL() + '/panel_api.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass')
                        log('err link= %r' % link)
                        data = utils.readlink(link,os.path.join(datapath,ADDONid) + '.info',module)
            log('2580 error ChannelFile= %r' % ChannelFile) 
            log('2581 error data= %r' % data)              
            ###if len(data) > 0 :
            if data != b'No Result' :
                log('2583 error ChannelFile= %r' % ChannelFile)
                ###log('XXX1 date= '+data[:100])
                ###name= Status,url= url,mode= 11,iconimage= ,cat= ,date= ,description= {u'username': u'XXX', u'status': u'Active', u'is_trial': u'0', u'created_at': u'1493734688', u'auth': 1, u'allowed_output_formats': [u'm3u8', u'ts', u'rtmp'], u'exp_date': u'1499005088', u'active_cons': u'0', u'password': u'XXXX', u'max_connections': u'1'},startDate= ,endDate= ,recordname= )
                d = json.loads(data)
                d1 = d['user_info']
                
                formats = d1['allowed_output_formats']
                allowedformats = AllowedFormats(formats)
                
                if d1['is_trial'] == '1':
                    is_trial = '\nThis is a trial '
                else:
                    is_trial = ''
                now = datetime.now()
                forever = definition.ADDONgetSetting('forever')    
                if forever == 'true':
                    expiredate = 'none'
                    remainingdaysS = ''
                else:
                    remainingdays = (recordings.parseDate(d1['exp_date'])-recordings.parseDate(now)).days
                    if remainingdays < 7:
                        remainingdaysS = ' [B][COLOR red] '+ str(remainingdays)  + '[/COLOR][/B]'
                    else:
                        remainingdaysS = ' ' + str(remainingdays)
                ###descr = 'Username= %s \nStatus= %s \nExpire= %s%s%s\nMax connections= %s \nConnections in use= %s \nAllowed formats= %s' %(d1['username'],d1['status'],recordings.parseDate(d1['exp_date']).strftime('%Y-%m-%d %H:%M'),remainingdaysS,is_trial,d1['max_connections'],d1['active_cons'],allowedformats)
                if definition.ADDONgetSetting('enable_record')=='true':
                    PRC = getPlannedRecordingCounts()    
                    userinfo += d1['max_connections'] + '/' +d1['active_cons'] + remainingdaysS + ' ' + PRC
                else:    
                    userinfo += d1['max_connections'] + '/' +d1['active_cons'] + remainingdaysS 
                
        except Exception as e:
            log('err 2129 Except: %r' % e)
            pass
            log('Error in getting '+ ADDONid + ' 2-info! Check your User ID\n' + repr(e))
            utils.notification('Error in getting '+ ADDONid + " 2-info! Use or don't use VPN or check your User ID\n" + repr(e))
            try:
                if definition.ADDONgetSetting('enable_record')=='true':
                        PRC = getPlannedRecordingCounts()    
                        userinfo += ' ' + PRC
            except Exception as e:
                log('err 2136 Except: %r' % e)
                pass
            ###addDir('Basic Info','url',0,'1','','','Error in getting '+ ADDONid + ' info! Check your User ID\n' + repr(e))
            ###d = []
    return userinfo + ' ' + utils.isVPN()
            
def CATEGORIES():
    ###log('CATEGORIES ADDON= ' + ADDONid)
    if definition.ADDONgetSetting('internet') == 'true':
        LOGIN()
        ROQTVusername = IPTVuser
        if ROQTVusername.lower() != 'none':
            channeltxt = 'll '+ADDONrefer +' and direct channel '
        else:
            channeltxt = 'll direct channel '
    userinfo = ADDONrefer + ' '
    userinfo = definition.ADDONgetSetting('my_referral_init') + ' '    ### 2025-08-10
    ROQTVusername = IPTVuser
    remainingdaysS = ''
    max_connectionsdesc = ''
    active_consdesc = ''
    ### if (ROQTVusername.lower() != 'none' or definition.ADDONgetSetting('internet') != 'true' or 1==1): ### 2023-01-18 always
    if (definition.ADDONgetSetting('enable_record') == 'true') and ROQTVusername.lower() != 'none': ### 2025-05-11 if recording enabled and user not none
        try:
            ChannelFile = os.path.join(datapath,ADDONid) + '.info'
            ### Only read .info file from web if it is more than 1 hour old
            data = ''
            if os.path.isfile(ChannelFile):
                now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                nowTS = int(time.mktime(datetime.now().timetuple()))
                log('nowTS= %r' % nowTS)
                filecreated = int(os.path.getmtime(ChannelFile))
                log('ChannelFile= %r' % ChannelFile)
                log('filecreated= %r' % filecreated)
                t = nowTS - filecreated - 3600 * 12    ### accept one time old file
                log('nowTS - filecreated= %r' % t)
                if t < 0:
                    file = open(ChannelFile)
                    data = file.read()
                    log('err data= %r' % (data))
                    file.close()
                else:
                    if definition.ADDONgetSetting('panel_api') == 'true':
                        link = definition.getBASEURL() + '/panel_api.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass')
                        log('err link= %r' % link)
                        data = utils.readlink(link,os.path.join(datapath,ADDONid) + '.info',module)
                        """
                        file = request.urlopen(link)
                        data = file.read()
                        log('err link=%r\ndata= %r' % (link,data))
                        file.close()
                        
                        with open(ChannelFile,'wb') as output:
                            output.write(data)
                        """
            log('2676 error data= %r' % data[:100])
            if data != b'No Result' :       
                log('2678 error data= %r' % data[:100])
                ###name= Status,url= url,mode= 11,iconimage= ,cat= ,date= ,description= {u'username': u'XXX', u'status': u'Active', u'is_trial': u'0', u'created_at': u'1493734688', u'auth': 1, u'allowed_output_formats': [u'm3u8', u'ts', u'rtmp'], u'exp_date': u'1499005088', u'active_cons': u'0', u'password': u'XXXX', u'max_connections': u'1'},startDate= ,endDate= ,recordname= )
                d = json.loads(data)
                log('2684 error d= %r' % d)
                ### d= {'user_info': {'username': 'xxxxxx', 'password': 'yyyyyy', 'auth': 1, 'status': 'Active', 'exp_date': '1760652000', 'is_trial': '0', 'created_at': '1694642400', 'max_connections': '1', 'active_cons': '0', 'allowed_output_formats': [0, 1, 2]}}
                d1 = d['user_info']
                
                formats = d1['allowed_output_formats']
                allowedformats = AllowedFormats(formats)
                
                if d1['is_trial'] == '1':
                    is_trial = '\nThis is a trial '
                else:
                    is_trial = ''
                now = datetime.now()
                forever = definition.ADDONgetSetting('forever')    
                if forever == 'true':
                    expiredate = 'none'
                    remainingdaysS = ''
                else:
                    remainingdays = (recordings.parseDate(d1['exp_date'])-recordings.parseDate(now)).days
                    if remainingdays < 7:
                        remainingdaysS = ' [B][COLOR red] '+ str(remainingdays)  + '[/COLOR][/B]'
                    else:
                        remainingdaysS = ' ' + str(remainingdays)
                ###descr = 'Username= %s \nStatus= %s \nExpire= %s%s%s\nMax connections= %s \nConnections in use= %s \nAllowed formats= %s' %(d1['username'],d1['status'],recordings.parseDate(d1['exp_date']).strftime('%Y-%m-%d %H:%M'),remainingdaysS,is_trial,d1['max_connections'],d1['active_cons'],allowedformats)
                if definition.ADDONgetSetting('enable_record')=='true':
                    PRC = getPlannedRecordingCounts()    
                    userinfo += d1['max_connections'] + '/' +d1['active_cons'] + remainingdaysS + ' ' + PRC
                else:    
                    userinfo += d1['max_connections'] + '/' +d1['active_cons'] + remainingdaysS
                
                ###userinfo = d1['max_connections'] + '/' +d1['active_cons'] + ' ' + remainingdaysS
            
                ###addDir('Basic Info','url',12,'','','',descr)
        except Exception as e:
            log('err 2222 Except: %r' % e)
            pass
            log('Error in getting '+ ADDONid + ' 3-info! Check your User ID\n' + repr(e))
            utils.notification('Error in getting '+ ADDONid + " 3-info! Use or don't use VPN or check your User ID\n" + repr(e))
            try:
                if definition.ADDONgetSetting('enable_record')=='true':
                        PRC = getPlannedRecordingCounts()    
                        userinfo += ' ' + PRC
            except Exception as e:
                log('err 2230 Except: %r' % e)
                pass
            ###addDir('Basic Info','url',0,'1','','','Error in getting '+ ADDONid + ' info! Check your User ID\n' + repr(e))
            d = {'user_info': {'username': 'none', 'password': '', 'auth': 1, 'status': 'Active', 'exp_date': '1760652000', 'is_trial': '0', 'created_at': '1694642400', 'max_connections': '0', 'active_cons': '0', 'allowed_output_formats': [0, 1, 2]}}
            d1 = d['user_info']
    
    StatusCode = ''
    StatusCodeDesc = ''
    if definition.ADDONgetSetting('internet') == 'true':
        """
        try:   ### 2018-10-26
            RytecAddon = xbmcaddon.Addon(id='service.rytecepg.downloader')
            RytecAction = RytecAddon.getSetting('active')
        except Exception as e:
            log('err 2240 Except: %r' % e)
            pass
            RytecAction = ''
            log('Get Rytec Action - ERROR: %r' % e)
        """
        if userinfo != '':
            EPG_update = [userinfo+ ' ' + utils.isVPN()]
        else:
            EPG_update = [utils.isVPN()]
        ###if definition.ADDONgetSetting('Recordings') != '':
        ###    EPG_update.append('Recording')
        recordingdesc = ''
        if locking.isAnymarkLocked():
            EPG_update.append('[COLOR red]Rec[/COLOR]')
            recordingdesc = '[COLOR red]Rec[/COLOR]'
        updatedesc = ''
        if locking.isScanLocked('EPG_update'):
            EPG_update.append('EPG updating')
            updatedesc = 'EPG updating'
        recursivedesc = ''
        if definition.ADDONgetSetting('RecursiveSearch') == 'true':
            EPG_update.append('Recursive Search')
            recursivedesc = 'Recursive Search'
        scanningdesc = ''
        if locking.isAnyScanLocked():
            EPG_update.append('[COLOR blue]Scanning[/COLOR]') 
            scanningdesc = '[COLOR blue]Scanning[/COLOR]'
        ###if RytecAction != '':
        ###    EPG_update.append('Rytec: %s' % RytecAction)
        StatusCode = ''
        if len(EPG_update) > 0:
            Status = ', '.join(EPG_update)
        StatusCode = '[I][COLOR grey]'+ Status + '[/COLOR][/I]' 
        StatusCodeDesc = BasicUserInfoDesc()
        ###addDir('Maintenance\n' + StatusCode,'url',49,'','','','Addon Cloning and Addon update\nAccount Settings\nOpen Channels in Web\nOpen Channels in VLC\nDatabase Maintenance')
        addDir('[B][COLOR orangered]'+ADDONrefer+'[/COLOR][/B]\n' + StatusCode,'url',8,'','','',StatusCodeDesc)
        if ROQTVusername.lower() != 'none':
            addDir('[B][COLOR lightgreen]Favorites (' + FavoritesCount + ')[/COLOR][/B]' ,'url',17,'','','','All '+ADDONrefer +' and direct channel favorites, you have selected on this box')
        else:
            addDir('[B][COLOR lightgreen]Favorites (' + FavoritesCount + ')[/COLOR][/B]','url',17,'','','','All direct channel favorites, you have selected on this box')
        if definition.ADDONgetSetting('enable_record')=='true':
            addDir('[B][COLOR orangered]Planned Recordings[/COLOR][/B]','url',3,'','','','Planned recordings, result of recordings and recursive recordings')
        addDir('[COLOR orangered][B]Search Recordings in Database[/B][/COLOR]','url',2065,'','','','Search recording files and archive in Database' + '[CR][CR]If you want episode 98 of Midsomer Murders, you can seek: midsom%98[CR]To avoid some records add ^notsearchtext[CR][CR]Search in local recordings include l:[CR]Search in archives recordings include a: b: or f:[CR]Search in root of local and archive include r:[CR]Search in recordings with pending commands include c:[CR][CR]Sort by file date decending include n:[CR]Sort by duration include d:[CR]Sort by series/episode include s:[CR][CR]Find Duplicates include x:[CR][CR]Note! Search is NOT case sensitive')
    
        ROQTVusername = IPTVuser
        if ROQTVusername.lower() != 'none':
            addDir('[B][COLOR lightgreen]Search Channels and VOD[/COLOR][/B]','url',2008,'','','','Search all '+ADDONrefer +' channels, VOD and all direct channels')
        else:
            addDir('[B][COLOR lightgreen]Search Channels[/COLOR][/B]','url',2008,'','','','Search all direct channels from XMLTV file ')
    
        ROQTVusername = IPTVuser
        if ROQTVusername.lower() != 'none':
            ###addDir('[COLOR lightgreen]Search EPG Programs[/COLOR]','url',2050,'','','','Search all '+ADDONrefer +' channels EPG')
            searchEPGallChannels = definition.ADDONgetSetting('searchEPGallChannels')
            if searchEPGallChannels.lower() == 'true':
                searchEPGallChannelsFlag = True
                searchEPGallChannelsText = 'All '
            else:
                searchEPGallChannelsFlag = False
                searchEPGallChannelsText = 'Preferred '
            ###addDir('[B][COLOR lightgreen]Search EPG Programs[/COLOR][/B]\n[I][COLOR grey]'+searchEPGallChannelsText+' Channels[/COLOR][/I]','url',2050,'','','','Search EPG in '+searchEPGallChannelsText+ADDONrefer +' Channels')
            addDir('[B][COLOR lightgreen]Search EPG Programs[/COLOR][/B]','url',2050,'','','','Search EPG in '+searchEPGallChannelsText+ADDONrefer +' Channels')
        else:
            addDir('[B][COLOR lightgreen]Search EPG Programs[/COLOR][/B]','url',2050,'','','','Search all direct channels EPG')
    """
    if definition.ADDONgetSetting('enable_record')=='true' or recordArchivePath != '' or recordPath != '' or 1 == 1:  ### 2022-06-23 Always show menu entry
        ###addDir('[COLOR lightgreen]Search Channels and VOD[/COLOR]','url',2008,'','','','Search all '+ADDONname +' channels and all channels from extra XMLTV file ')
        SearchPath = 'All recorded items in[CR]' + recordPath
        SearchPathLocal = SearchPath
        if recordArchivePath != '' or recordArchivebPath != '':
            SearchPath += '[CR][CR]and all items in archive[CR]' 
        if recordArchivePath != '':
            SearchPath += '[CR]' + recordArchivePath
        if recordArchivebPath != '':
            SearchPath += '[CR]' + recordArchivebPath
        SearchPath = SearchPath.replace('/','/ ').replace('\\','\\ ')
        SearchPathLocal = SearchPathLocal.replace('/','/ ').replace('\\','\\ ')
        ###addDir('[COLOR orangered][B]Search Recordings in Database[/B][/COLOR]','url',2065,'','','','Search recording files and archive in Database' + '[CR][CR]If you want episode 98 of Midsomer Murders, you can seek: midsom%98[CR]To avoid some records add ^notsearchtext[CR][CR]Search in local recordings include l:[CR]Search in archive recordings include a:[CR]Search in root of local and archive include r:[CR]Search in recordings with pending commands include c:[CR][CR]Sort by file date decending include n:[CR]Sort by duration include d:[CR]Sort by series/episode include s:[CR][CR]Note! Search is NOT case sensitive')
        
        if definition.ADDONgetSetting('enable_record')=='true' :   ### 2022-06-23
            if definition.ADDONgetSetting('sortalphabetic') == 'true':
                addDir('[B][COLOR lightgreen]Search Recordings Alphabetical[/COLOR][/B]','url',6,'','','',SearchPath+'\n\nSorted alphabetically')
            else:
                addDir('[B][COLOR lightgreen]Search Recordings by Date[/COLOR][/B]','url',66,'','','',SearchPath+'\n\nSorted by file date')
            ###addDir('[COLOR lightgreen]Search Recordings[/COLOR]','url',6,'','','',SearchPath+'\n\nSorted alphabetically')
            addDir('[B][COLOR lightgreen]Latest Recordings[/COLOR][/B]','url',2060,'','','',SearchPathLocal+'\n\nSorted by file date')
            ###addDir('[COLOR lightgreen]Search Channels and VOD[/COLOR]','url',2008,'','','','Search all '+ADDONname +' channels and all channels from extra XMLTV file ')
            ###addDir('[COLOR lightgreen]Planned Recordings[/COLOR]','url',3,'','','','Planned recordings, result of recordings and recursive recordings')
    """
    
    """###Try to access catchup START
    ### 738 5.104997131 192.168.20.6    109.236.84.104  HTTP    234 GET /panel_api.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass') HTTP/1.1 
    link = 'http://roq-tv.net:25461/streaming/timeshift.php?username=XXX&password=XXXX&stream=276&duration=120&start=2017-05-21:16-00'
    ###http://roq-tv.net:25461/streaming/timeshift.php?username=XXX&password=XXXX'
    file = urlopen(link)
    data = file.read()
    file.close()
    for titem in ['title','description']:
        ###utils.logdev('Test Encoding','titem= ' + repr(titem) + ' - data= ' + repr(data))

        data = data.split('<'+titem+'>')
        ###utils.logdev('Test Encoding 1',repr(data))
        i=0
        newdata= ''
        for part in data:
            ###utils.logdev('Test Encoding 2',repr(part))
            if i==0:
                newdata+=part
                ###utils.logdev('Test Encoding 3',repr(newdata))
                i+=1
            else:
                part=part.split('</'+titem+'>',1)
                ###utils.logdev('Test Encoding 4',repr(part))
                ### newdata+='<'+titem+'>' + base64.b64decode(part[0]) +'</'+titem+'>' + part[1]
                newdata+='<'+titem+'>' + base64.b64decode(part[0], '-_') +'</'+titem+'>' + part[1]
                ###utils.logdev('Test Encoding 5',repr(newdata))
        ###utils.logdev('Test Encoding 6',repr(newdata))
        data = newdata
    data = xmltodict.parse(newdata)
    ###utils.logdev('Test Encoding x',repr(data))
    
    for i, (key, value) in enumerate(data.iteritems()):
        ###utils.logdev('Test Encoding y1','i= %s, key= %s, value= %s' % (repr(i), repr(key),repr(value)))
        for i1, (key1, value1) in enumerate(value.iteritems()):
            if key1 == 'channel':
                ###utils.logdev('Test Encoding y2','i1= %s, key1= %s, value1= %s' % (repr(i1), repr(key1),repr(value1)))
                for channelROQ in value1:
                    d=channelROQ

                    ###utils.logdev('Test Encoding y3','i1= %s, key1= %s, channelROQ= %s, url= %s' % (repr(d.items()[0]), repr(d.items()[1]),repr(d.items()[2]),repr(d.items()[3])))
                    ###utils.logdev('Test Encoding y4','\n\ntitle= %s,\n description= %s,\n category_id= %s,\n playlist_url= %s\n' % (repr(d['title']), repr(d['description']),repr(d['category_id']),repr(d['playlist_url'])))
                    addDir(d['title'],d['playlist_url'],22,d['category_id'],'','',d['description'])
    ###Try to access catchup END
    """
    
    ###addDir('Search Channels and VOD','url',2008,'','','','Search all '+ADDONname +' channels and all channels from extra XMLTV file ')
    ###if definition.ADDONgetSetting('enable_record')=='true':
        ###addDir('Recordings','url',6,'','','','All recorded items in ' + recordPath)
        ###addDir('[COLOR lightgreen]Planned Recordings[/COLOR]','url',3,'','','','Planned recordings, result of recordings and recursive recordings')
        ###addDir('Recursive Search Channels','url',26,'','','','All channels used for recursive search')
        ###addDir('Restore Planned Recordings','url',104,'','','','Restore planned recordings or just recursive recordings')
        ###addDir('Delete New EPG programs','url',110,'','','','delNewEPGPrograms():   ### If to many programs have changed - update full afterwards')
        ###addDir('Delete All Channels','url',108,'','','','delAllChannels():   ### If user have changed - update full afterwards')
        ###addDir('Delete All Planned Recordings','url',109,'','','','delAllPlannedPrograms():   ### If recursive have made too many recordings - Stop all recordings and clear parts of database')
    """
    if definition.ADDONgetSetting('internet') == 'true':
        addDir('[B]Streams[/B]','url',490,'','','',ADDONrefer + ' Streams')
    """
    ###
    """
    ### userinfo = ''
    userinfo = ADDONrefer + ' '
    ROQTVusername = IPTVuser
    if (ROQTVusername.lower() != 'none' or definition.ADDONgetSetting('internet') != 'true'):
        try:
            ChannelFile = os.path.join(datapath,ADDONid) + '.info'
            ### Only read .info file from web if it is more than 1 hour old
            
            if os.path.isfile(ChannelFile):
                now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                nowTS = int(time.mktime(datetime.now().timetuple()))
                log('nowTS= %r' % nowTS)
                filecreated = int(os.path.getmtime(ChannelFile))
                log('ChannelFile= %r' % ChannelFile)
                log('filecreated= %r' % filecreated)
                t = nowTS - filecreated - 3600 * 12    ### accept one time old file
                log('nowTS - filecreated= %r' % t)
                if t < 0:
                    file = open(ChannelFile)
                    data = file.read()
                    file.close()
                else:
                    if definition.ADDONgetSetting('panel_api') == 'true':
                        link = definition.getBASEURL() + '/panel_api.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass')
                        file = urlopen(link)
                        data = file.read()
                        file.close()
                        
                        with open(ChannelFile,'wb') as output:
                            output.write(data)
                    else:
                        data = ''
            log('XXX1 date= '+data[:100])
            ###name= Status,url= url,mode= 11,iconimage= ,cat= ,date= ,description= {u'username': u'XXX', u'status': u'Active', u'is_trial': u'0', u'created_at': u'1493734688', u'auth': 1, u'allowed_output_formats': [u'm3u8', u'ts', u'rtmp'], u'exp_date': u'1499005088', u'active_cons': u'0', u'password': u'XXXX', u'max_connections': u'1'},startDate= ,endDate= ,recordname= )
            d = json.loads(data)
            d1 = d['user_info']
            
            formats = d1['allowed_output_formats']
            allowedformats = AllowedFormats(formats)
            
            if d1['is_trial'] == '1':
                is_trial = '\nThis is a trial '
            else:
                is_trial = ''
            now = datetime.now()
            remainingdays = (recordings.parseDate(d1['exp_date'])-recordings.parseDate(now)).days
            if remainingdays < 7:
                remainingdaysS = '[B][COLOR red] '+ str(remainingdays)  + '[/COLOR][/B]'
            else:
                remainingdaysS = str(remainingdays)
            ###descr = 'Username= %s \nStatus= %s \nExpire= %s%s%s\nMax connections= %s \nConnections in use= %s \nAllowed formats= %s' %(d1['username'],d1['status'],recordings.parseDate(d1['exp_date']).strftime('%Y-%m-%d %H:%M'),remainingdaysS,is_trial,d1['max_connections'],d1['active_cons'],allowedformats)
            if definition.ADDONgetSetting('enable_record')=='true':
                PRC = getPlannedRecordingCounts()    
                userinfo += d1['max_connections'] + '/' +d1['active_cons'] + ' ' + remainingdaysS + ' ' + PRC
            else:    
                userinfo += d1['max_connections'] + '/' +d1['active_cons'] + ' ' + remainingdaysS
            
            ###userinfo = d1['max_connections'] + '/' +d1['active_cons'] + ' ' + remainingdaysS
        
            ###addDir('Basic Info','url',12,'','','',descr)
        except Exception as e:
            pass
            log('Error in getting '+ ADDONid + ' info! Check your User ID\n' + repr(e))
            utils.notification('Error in getting '+ ADDONid + ' info! Check your User ID\n' + repr(e))
            try:
                if definition.ADDONgetSetting('enable_record')=='true':
                        PRC = getPlannedRecordingCounts()    
                        userinfo += ' ' + PRC
            except Exception as e:
                pass
            ###addDir('Basic Info','url',0,'1','','','Error in getting '+ ADDONid + ' info! Check your User ID\n' + repr(e))
            ###d = []
    
    StatusCode = ''
    if definition.ADDONgetSetting('internet') == 'true':
        try:   ### 2018-10-26
            RytecAddon = xbmcaddon.Addon(id='service.rytecepg.downloader')
            RytecAction = Rytecdefinition.ADDONgetSetting('active')
        except Exception as e:
            pass
            RytecAction = ''
            log('Get Rytec Action - ERROR: %r' % e)
        if userinfo != '':
            EPG_update = [userinfo]
        else:
            EPG_update = []
        ###if definition.ADDONgetSetting('Recordings') != '':
        ###    EPG_update.append('Recording')
        if locking.isAnymarkLocked():
            EPG_update.append('[COLOR red]Rec[/COLOR]')
        if locking.isScanLocked('EPG_update'):
            EPG_update.append('EPG updating')
        if definition.ADDONgetSetting('RecursiveSearch') == 'true':
            EPG_update.append('Recursive Search')
        if locking.isAnyScanLocked():
            EPG_update.append('[COLOR blue]Scanning[/COLOR]')    
        if RytecAction != '':
            EPG_update.append('Rytec: %s' % RytecAction)
        StatusCode = ''
        if len(EPG_update) > 0:
            Status = ', '.join(EPG_update)
            StatusCode = '[I][COLOR grey]'+ Status + '[/COLOR][/I]'  
    """
    ###addDir('Maintenance\n' + StatusCode,'url',49,'','','','Addon Cloning and Addon update\nAccount Settings\nOpen Channels in Web\nOpen Channels in VLC\nDatabase Maintenance')
    addDir('[COLOR yellow][B]Maintenance[/B][/COLOR]','url',49,'','','','Addon Cloning and Addon update\nAccount Settings\nOpen Channels in Web\nOpen Channels in VLC\nDatabase Maintenance')
    errorInBasicInfo, descr, link = isMyAccountOK()
    if errorInBasicInfo :
        addDir('[B][COLOR orangered]My Account[/COLOR][/B]','url',8,'','','','Change your user name/email address and password or restore previous configurations. \n\nWatch your basic account information\nOpen Channels in Web\nOpen Channels in VLC')
    else:
        addDir('[B][COLOR lightgreen]My Account[/COLOR][/B]','url',8,'','','','Change your user name/email address and password or restore previous configurations. \n\nWatch your basic account information\nOpen Channels in Web\nOpen Channels in VLC')
    ###addDir('Hidden Channels','url',20,'','','','All channels you have hidden from the other views')
    """
    addDir('[B][COLOR grey]Mount Network Drive[/COLOR][/B]','url',4400,'','','','Click to mount the networkdrive set in Settings Recordings used for Archive','','','')
    """
    if definition.ADDONgetSetting('testmenu').lower() == 'true' :
        addDir('[B][COLOR yellow]Test Function @ 4499[/COLOR][/B]','url',4499,'','','','Test function at 4499','','','')
        addDir('[B][COLOR yellow]File Actions[/COLOR][/B]','url',4500,'','','','Execute file and folder actions on this system','','','')
        if definition.ADDONgetSetting('copyrecordingsdatabase')=='true':
            addDir('[B][COLOR yellow]Copy Database to Recordings Folder[/COLOR][/B]','url',4501,'','','','Copy Database to/from Recordings Folder if enabled','','','')  ### Copy recordings database to recordings folder
        
        if definition.ADDONgetSetting('getrecordingsdatabase')=='true':
            addDir('[B][COLOR yellow]Copy Database from Recordings Folder[/COLOR][/B]','url',4501,'','','','Copy Database to/from Recordings Folder if enabled','','','')
    addDir('[B][COLOR orangered]Back to Kodi[/COLOR][/B]','url',29,'','','','Back to Kodi from the %s addon' % ADDONrefer)
    
    """
    try:
        ### httplink = 'http://roq-tv.net:25461/get.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass')+ '&type=m3u_plus&output='+streamtype
        ROQTVusername = IPTVuser
        if ROQTVusername.lower() != 'none':
            httplink = definition.getBASEURL() + '/get.php?username='+IPTVuser+ '&password=' +definition.ADDONgetSetting('pass')+ '&type=m3u_plus&output='+streamtype
            ### Save .m3u file with all channels!
            log('Categories link: ' + repr(httplink))
            m3ufile = urlopen(httplink)
            ChannelFile = os.path.join(datapath,ADDONid) + '.m3u'
            now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
            nowTS = int(time.mktime(datetime.now().timetuple()))
            log('nowTS= %r' % nowTS)
            filecreated = int(os.path.getmtime(ChannelFile))
            log('ChannelFile= %r' % ChannelFile)
            log('filecreated= %r' % filecreated)
            t = nowTS - filecreated - 3600 * 12   ### accept one time old file
            log('nowTS - filecreated= %r' % t)
            log('XXX041')
            if t > 0:
                with open(ChannelFile,'wb') as output:
                    output.write(m3ufile.read())
                    log('AddOn m3u file downloaded: ' + repr(ChannelFile))
    except Exception as e:
        pass
        log('Error in get Categori: ' + repr(e))
    """
    setView('movies', 'main-view')         

def CHANNELSROQOLD(cname,cat,link,description):
    """ Stream
    OrderedDict([
     (u'title', u'UK: SKY SPORTS ACTIVE 5'), 
     (u'description', None), 
     (u'desc_image', u'http://www.tv-logo.com/pt-data/uploads/images/logo/sky_uk_sports_active_hi_01.jpg'), 
     (u'category_id', u'38'), 
     (u'stream_url', u'http://roq-tv.net:25461/live/XXX/XXXX/2782.ts')]), 
     
     Category
     <channel>
     <title>All</title>
     <description>Live Streams Category [ ALL ]</description>
     <category_id>0</category_id>
     <playlist_url><![CDATA[http://roq-tv.net:25461/enigma2.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass') + '&cat_id=0]]></playlist_url>
     </channel>
    """
    GoHome('Live Streams or Vod')
    ###link = 'http://roq-tv.net:25461/enigma2.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass')
    log('err Live Streams or Vod link=\n%r' % link)
    ###file = urlopen(link)
    ###data = file.read()
    ###file.close()
    data = utils.readlink(link,'',module)
    log('err link=%r\ndata= %r' % (link,data))
    data = data.replace('\n','').replace('<description/>','<description></description>')
    ###channelsxml = os.path.join(datapath, 'channelsxml-1')  + '.xml'
    ###LF = open(channelsxml, 'w')
    ###LF.write(data)
    ###LF.close()
    for titem in ['title','description']:
        #########utils.logdev('Test Encoding','titem= ' + repr(titem) + ' - data= ' + repr(data))
        data = data.split('<'+titem+'>')
        #########utils.logdev('Test Encoding 1',repr(data))
        #########log('Test Encoding 1')
        i=0
        newdata= ''
        for part in data:
            #########utils.logdev('Test Encoding 2',repr(part))
            #########log('Test Encoding 2')
            if i==0:
                newdata+=part
                #########utils.logdev('Test Encoding 3',repr(newdata))
                i+=1
                #########log('Test Encoding 3')
            else:
                part=part.split('</'+titem+'>',1)
                #########log('Test Encoding 4')
                #########utils.logdev('Test Encoding 4',repr(part))
                ### newdata+='<'+titem+'>' + base64.b64decode(part[0]) +'</'+titem+'>' + part[1]
                if not part[0] == None:
                    #########log('Test Encoding 5')
                    #########utils.logdev('Test Encoding 4a',repr(part))
                    if titem == 'title':
                        ###decodedtext = recordings.latin1_to_ascii_force(base64.b64decode(part[0], '-_').replace('&','&amp;').split('[',1)[0]).replace('<<','XX')
                        decodedtext = recordings.latin1_to_ascii_force(base64.b64decode(part[0], '-_').replace('&','&amp;')).replace('<<','XX')###.replace('[','|').replace(']','|')  ### 2019-02-11
                        #########log('Test Encoding 6')
                    else:
                        decodedtext = recordings.latin1_to_ascii_force(base64.b64decode(part[0], '-_').replace('&','&amp;')).replace('<<','XX')
                        #########log('Test Encoding 7')
                else:
                    utils.notification('Missing channel: ' + repr(part))
                    decodedtext=''
                    #########log('Test Encoding 8')
                newdata+='<'+titem+'>' + decodedtext +'</'+titem+'>' + part[1]
                #########log('Test Encoding 9')
                #########utils.logdev('Test Encoding 5',repr(newdata))
        #########utils.logdev('Test Encoding 6',repr(newdata))
        #########log('Test Encoding 10')
        data = newdata
    #########log('Test Encoding 11')
    channelsxml = os.path.join(datapath, 'channelsxml')  + '.xml'
    LF = open(channelsxml, 'w')
    LF.write(newdata)
    LF.close()
    #########utils.logdev('Decoded XML file',repr(newdata))
    try:
        data = xmltodict.parse(newdata)
    except Exception as e:
        log('err 2589 Except: %r' % e)
        pass
        log('Error in xmltodict.parse(newdata): ' + repr(e))
        data = ''
    #########utils.logdev('Decoded Dict',repr(data))
    channelsxml = os.path.join(datapath, 'channelsdict')  + '.dict'
    LF = open(channelsxml, 'w')
    LF.write(repr(data))
    LF.close()
    ###addDir('Favorites','url',17,'','','','All '+ADDONname +' favorites, you have selected on this box')
    try:
        log('Test Encoding 12')
        for i, (key, value) in enumerate(data.iteritems()):
            #########utils.logdev('Test Encoding y1','i= %s, key= %s, value= %s' % (repr(i), repr(key),repr(value)))
            #########log('Test Encoding 13')
            for i1, (key1, value1) in enumerate(value.iteritems()):
                ######log('Test Encoding 14')
                if key1 == 'channel':
                    ######log('Test Encoding 15')
                    ######utils.logdev('Test Encoding y2','i1= %s, key1= %s, value1= %s' % (repr(i1), repr(key1),repr(value1)))
                    for channelROQ in value1:
                        log('channelROQ= %r' % channelROQ)  ### 2017-12-29
                        d=channelROQ
                        
                        if 'stream_url' in d and not d['stream_url'] == None:
                            ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
                            log('stream_url in channelROQ')
                            StreamURL=d['stream_url'].replace('![CDATA[','',1).replace(']]','',1)
                        
                            if not d['desc_image'] == None:
                                DescURL=d['desc_image'].replace('![CDATA[','',1).replace(']]','',1)
                            else:
                                DescURL = ''
                            try:
                                Description=d['description']
                                log('Description= %r, type= %r' %(Description,type(Description)))
                                if isinstance(Description, dict):
                                    Description = Description['em']+'\n'+Description['#text']
                                elif not isinstance(Description, unicode):
                                    if not (Description == None or Description == ''):
                                        Description='Unknown description type: ' + repr(type(Description))
                                    else: 
                                        ######log('Description= %s, type= %s' %( repr(Description),repr(type(Description))))
                                        Description = ''
                            except Exception as e:
                                log('err 2633 Except: %r' % e)
                                pass
                                log('Error in get Description: ' + repr(e))
                                Description= 'Error in get Description: ' + repr(e)    ### ''  2018-06-30
                            ###log('Test Encoding 18')
                            log('Test Encoding 18 Title= %s, Stream= %s, DescURL= %s, Category_ID= %s, Description= %s' % (d['title'],StreamURL,DescURL,d['category_id'],Description))
                            catThis = recordings.catFromUrl(StreamURL)
                            if IPTVuser in catThis :
                                catThis = '#'
                            log('catThis= %r' % catThis)
                            if recordings.isChannelVisible(catThis) or catThis == '#': ### 2019-02-11 Always visible
                                log('Visible catThis= %r' % catThis)
                                ###log('catThis = recordings.catFromUrl(StreamURL)= %r ' % catThis)
                                ##recordings.addChannel(d['title'].strip(),StreamURL,DescURL,catThis, ADDONid,description=Description)
                                ###def addDir(name,url,mode,iconimage='',cat='',date='',description='',startDate='',endDate='',recordname='',whatsup=''):
                                try:
                                    olddescription = recordings.getChannelDescription(catThis)
                                    ###log('get olddescription: ' + repr(olddescription))
                                    if catThis == '#' or 1 != 0: ### 2019-02-11 TEST
                                        Description = Description ### Always use original description
                                        if catThis != '#' :
                                            recordings.setChannelDescription(catThis,Description)   ### 2019-02-11 Save descriptions in onlinE DATABASE
                                    elif olddescription != '':    ### 2018-06-30 keep description
                                        Description = olddescription
                                    else:
                                        recordings.setChannelDescription(catThis,Description)
                                except Exception as e:
                                    log('err 2659 Except: %r' % e)
                                    pass
                                    log('Error in get olddescription: ' + repr(e))
                                ###log('cat= <%r>1 \nurl= %r' % (catThis,StreamURL))
                                if 'movie' in StreamURL or 'series' in StreamURL or catThis == '#':
                                    chx = Description  ### Description of Movies
                                    ###log('MOVIE cat= <%r>1 \nurl= %r' % (catThis,StreamURL))
                                else:
                                    EPGx = updateepg.getEPGnow(catThis)  ### Live EPG on channels
                                    EPG  = EPGx[0]
                                    ###log('LIVE cat= <%r>1 \nurl= %r' % (catThis,StreamURL))
                                    ###log('EPGx[4]= <%r> \nEPGx[0]= %r' % (EPGx[4],EPGx[0]))
                                    if EPGx[4] != '':
                                        ###log('LIVE EPG cat= <%r>1 \nurl= %r \nlen(EPG)= %r' % (catThis,StreamURL,len(EPG)))
                                        chx = EPGx[4]
                                        if EPGx[3] > 0:
                                            chx += ' \nArchive Duration ' + str(EPGx[3]) + '\n'   ### 2018-06-11
                                        for indexX in range(0, len(EPG)):
                                            title = str(EPG[indexX][0])
                                            description = str(EPG[indexX][1])
                                            ###starttime = str(EPG[indexX][3].strftime('%H:%M'))
                                            ###endtime = str(EPG[indexX][4].strftime('%H:%M'))
                                            starttime = str(datetime.fromtimestamp(EPG[indexX][3]).strftime('%H:%M'))
                                            endtime = str(datetime.fromtimestamp(EPG[indexX][4]).strftime('%H:%M'))
                                            chx += ' \n[COLOR lightgreen]'+starttime + ' - ' + endtime + '[/COLOR] \n[COLOR blue]'+ title+ '[/COLOR] \n'+ description +' \n'
                                    else:
                                        chx = Description
                                addDir(d['title'].strip(),StreamURL,200,DescURL,catThis,'',chx)
                                log('XXXX Test Encoding stream\n\ntitle= %s,\n description= %s,\n category_id= %s,\n stream_url= %s\n' % (repr(d['title']), repr(d['description']),repr(d['category_id']),repr(d['stream_url'])))
                                
                        elif 'playlist_url' in d and not d['playlist_url'] == None:
                            ######log('Test Encoding 19')
                            PlaylistURL=d['playlist_url'].replace('![CDATA[','',1).replace(']]','',1)
                            try:
                                Description=d['description']
                                ######log('Description= %s, type= %s' %( repr(Description),repr(type(Description))))
                                if isinstance(Description, dict):
                                    Description = Description['em']+'\n'+Description['#text']
                                elif not isinstance(Description, unicode):
                                    if not (Description == None or Description == ''):
                                        Description='Unknown description type: ' + repr(type(Description))
                                    else: 
                                        ######log('Description= %s, type= %s' %( repr(Description),repr(type(Description))))
                                        Description = 'Empty description'
                            except Exception as e:
                                log('err 2703 Except: %r' % e)
                                pass
                                log('Error in get Description: ' + repr(e))
                                Description= 'Error in get Description: ' + repr(e) 
                            
                            addDir(d['title'].strip(),PlaylistURL,22,'','','',Description)
                        else:
                            log('No stream or playlist: ' + repr(d))
                            addDir('Error: '+repr(d),'url',22,'','','','No stream or playlist: ' + repr(d))  ### 2018-06-30
    except Exception as e:
        log('err 2712 Except: %r' % e)
        pass
        log('Error in showing Channels: ' + repr(e))
    log('Test Encoding 22')
    setView('movies', 'main-view')
    
def dictepgdata(date):
    try:
        ###log('dictepgdata(date)')
        for i, (key, value) in enumerate(data.iteritems()):
            #########utils.logdev('Test Encoding y1','i= %s, key= %s, value= %s' % (repr(i), repr(key),repr(value)))
            #########log('Test Encoding 13')
            for i1, (key1, value1) in enumerate(value.iteritems()):
                ######log('Test Encoding 14')
                if key1 == 'channel':
                    ######log('Test Encoding 15')
                    ######utils.logdev('Test Encoding y2','i1= %s, key1= %s, value1= %s' % (repr(i1), repr(key1),repr(value1)))
                    for channelROQ in value1:
                        ######log('Test Encoding 16')
                        d=channelROQ
                        
                        if 'stream_url' in d and not d['stream_url'] == None:
                            ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
                            ######log('Test Encoding 17')
                            StreamURL=d['stream_url'].replace('![CDATA[','',1).replace(']]','',1)
                        
                            if not d['desc_image'] == None:
                                DescURL=d['desc_image'].replace('![CDATA[','',1).replace(']]','',1)
                            else:
                                DescURL = ''
                            try:
                                Description=d['description']
                                ######log('Description= %s, type= %s' %( repr(Description),repr(type(Description))))
                                if isinstance(Description, dict):
                                    Description = Description['em']+'\n'+Description['#text']
                                elif not isinstance(Description, unicode):
                                    if not (Description == None or Description == ''):
                                        Description='Unknown description type: ' + repr(type(Description))
                                    else: 
                                        ######log('Description= %s, type= %s' %( repr(Description),repr(type(Description))))
                                        Description = ''
                            except Exception as e:
                                log('err 2753 Except: %r' % e)
                                pass
                                ###log('Error in get Description: ' + repr(e))
                                Description=''
                            ######log('Test Encoding 18')
                            log('Test Encoding 18 Title= %s, Stream= %s, DescURL= %s, Category_ID= %s, Description= %s' % (d['title'],StreamURL,DescURL,d['category_id'],Description))
                            catThis = recordings.catFromUrl(StreamURL)
                            ###log('catThis = recordings.catFromUrl(StreamURL)= %r ' % catThis)
                            ##recordings.addChannel(d['title'].strip(),StreamURL,DescURL,catThis, ADDONid,description=Description)
                            addDir(d['title'].strip(),StreamURL,200,DescURL,'','',Description)
                            ######utils.logdev('Test Encoding stream','\n\ntitle= %s,\n description= %s,\n category_id= %s,\n stream_url= %s\n' % (repr(d['title']), repr(d['description']),repr(d['category_id']),repr(d['stream_url'])))
                        elif 'playlist_url' in d and not d['playlist_url'] == None:
                            ######log('Test Encoding 19')
                            PlaylistURL=d['playlist_url'].replace('![CDATA[','',1).replace(']]','',1)
                            try:
                                Description=d['description']
                                ######log('Description= %s, type= %s' %( repr(Description),repr(type(Description))))
                                if isinstance(Description, dict):
                                    Description = Description['em']+'\n'+Description['#text']
                                elif not isinstance(Description, unicode):
                                    if not (Description == None or Description == ''):
                                        Description='Unknown description type: ' + repr(type(Description))
                                    else: 
                                        ######log('Description= %s, type= %s' %( repr(Description),repr(type(Description))))
                                        Description = 'No description'
                            except Exception as e:
                                log('err 2778 Except: %r' % e)
                                pass
                                log('Error in get Description: ' + repr(e))
                                Description='Error in get Description: ' + repr(e) ###''  2018-06-30
                            ######utils.logdev('Test Encoding playlist','\n\ntitle= %s,\n description= %s,\n category_id= %s,\n playlist_url= %s\n' % (repr(d['title']), repr(d['description']),repr(d['category_id']),repr(d['playlist_url'])))
                            ######log('Test Encoding 20')
                            ###def addChannel(name,url,iconimage,cat,origin,visible=True,weight=0,description='')
                            ##recordings.addChannel(d['title'].strip(),PlaylistURL,'','', ADDONid,description=Description)
                            addDir(d['title'].strip(),PlaylistURL,22,'','','',Description)
                        else:
                            ######log('Test Encoding 21')
                            utils.notification('No stream or playlist: ' + repr(d))
                            addDir('Error: '+repr(d),'url',22,'','','','No stream or playlist: ' + repr(d))  ### 2018-06-30
    except Exception as e:
        log('err 2791 Except: %r' % e)
        pass
        log('Error in showing Channels: ' + repr(e))
 
def CHANNELS(cname,cat):
    GoHome('Categories')
    channeldescription = 'All '+ADDONrefer +' categories based on information in channel list. A channel may be member of several categoties.'
    i = 0
    categories= []
    channels= []
    log('err CHANNELS(cname= %r, cat= %r) ' %(cname,cat))
    ###ChannelFile = os.path.join(datapath,ADDONid) + '.m3u.txt'
    ChannelFile = definition.ADDONgetSetting('directchannelsfromextraXMLTVfile')
    if not os.path.isfile(ChannelFile):  
        ChannelFile = os.path.join(datapath,'directchannels') + '.m3u'
        log('Use extra ChannelFile in data?: ' + repr(ChannelFile))
    if not os.path.isfile(ChannelFile):    ### If ChannelFile exist in Data directory use it
        ###ChannelFile = os.path.join(progpath,ADDONid) + '.m3u.txt'  ### Otherwise try program directory
        ChannelFile = os.path.join(progpath,'directchannels') + '.m3u.txt'  ### Otherwise try program directory
        log('Use extra ChannelFile in prog?: ' + repr(ChannelFile))
    log('Use extra ChannelFile in: ' + repr(ChannelFile))
    if not os.path.isfile(ChannelFile): 
        log('NOT found xtra ChannelFile in: ' + repr(ChannelFile))
    else:
        log('Use extra ChannelFile in: ' + repr(ChannelFile))
        grouptitle= ''
        tvgnamecat = ''
        for line in open(ChannelFile):  # opened in text-mode; all EOLs are converted to '\n'
            ######log('Line: ' + repr(i) + ' - ' + line)
            line = line.rstrip('\n').rstrip('\r').strip()
            if not line == '' and not line[:2] == '# ' :   # Ignore empty lines and comment lines
                if '#EXTM3U' in line :
                    i += 1
                    ######log('Skip EXTM3U in line: ' + repr(i))
                elif '#EXTINF' in line :
                    i += 1
                    ######log('Use EXTINF in line: ' + repr(i) + ' - ' + line)
                    ###if ',' in line:
                    ### log('Comma(,) in line: ' + repr(i) + ' - ' + line)
                    tvgid=''
                    tvgname=''
                    tvgnamecat = ''
                    tvglogo=''
                    grouptitl=''
                    name=''
                    try:
                        tvgid=line.split('tvg-id="',1)[1].split('"',1)[0]
                        log('Use tvg-id in line: ' + repr(tvgid) + ' - ' + line)
                    except Exception as e:
                        log('err 2837 Except: %r' % e)
                        pass
                    try:
                        tvgname=line.split('tvg-name="',1)[1].split('"',1)[0]
                        log('Use tvg-name in line: ' + repr(tvgname) + ' - ' + line)
                    except Exception as e:
                        log('err 2842 Except: %r' % e)
                        pass
                    try:
                        tvglogo=line.split('tvg-logo="',1)[1].split('"',1)[0]
                        log('Use tvg-logo in line: ' + repr(tvglogo) + ' - ' + line)
                    except Exception as e:
                        log('err 2847 Except: %r' % e)
                        pass
                    try:
                        grouptitle=line.split('group-title="',1)[1].split('"',1)[0]
                        log('Use group-title in line: ' + repr(grouptitle) + ' - ' + line)
                    except Exception as e:
                        log('err 2852 Except: %r' % e)
                        pass
                    try:
                        name=line.split(',')[-1]
                        log('Use name in line: ' + repr(name) + ' - ' + line)
                        grouptitle=grouptitle.split('SEASON')[0].strip()
                    except Exception as e:
                        log('err 2858 Except: %r' % e)
                        pass
                    try:
                        if ':' in tvgname:
                            tvgnamecat=tvgname.split(':')[0].strip()
                    except Exception as e:
                        log('err 2863 Except: %r' % e)
                        pass
                else:
                    i += 1
                    try:
                        cats=line.split('live/')[1].split('/')[0]
                    except Exception as e:
                        log('err 2869 Except: %r' % e)
                        pass
                        try:
                            cats=line.split('tv2danmark/')[1].split('/')[0]
                        except Exception as e:
                            log('err 2873 Except: %r' % e)
                            pass
                            try:
                                cats=line.split('i/')[1].split('/')[0]
                            except Exception as e:
                                log('err 2877 Except: %r' % e)
                                pass
                                try:
                                    cats=line.split('.')[-2].split('/')[-1]
                                except Exception as e:
                                    log('err 3012 Except: %r' % e)
                                    pass   
                                    cats=repr(e)
                    if 'live' in line:
                        catsinlink='! live'
                    elif 'movie' in line:
                        catsinlink='! movie'
                    elif 'series' in line:
                        catsinlink='! series'
                    else:
                        catsinlink='! unknown'
                    
                    if '_' in cats:
                        if not 'bbc_' in cats:   ### 2017-08-28
                            if not 'cbeebies_' in cats:
                                log('cats no_= %r' % cats)
                                cats = cats.split('_')[0]
                                log('cats no_= %r' % cats)
                    
                    ######log('Use cname= ' + repr(cname) + ' - grouptitle= ' + repr(grouptitle))
                    if cname == grouptitle or cname == tvgnamecat or cname == catsinlink or cname == 'Channels':
                        channels.append([name.strip()+' (D0)',line,grouptitle,tvglogo,tvgname,tvgid,cats,catsinlink])
                    elif  cname == 'Categories':
                        if not grouptitle in categories and grouptitle != None :
                            categories.append(grouptitle)
                        if not tvgnamecat == '' and not tvgnamecat in categories and tvgnamecat != None:
                            categories.append(tvgnamecat)
                        if not catsinlink == '' and not catsinlink in categories and catsinlink != None :
                            categories.append(catsinlink)
                    ######log('Use URL in line: ' + repr(repr(i)) + ' - ' + line)
                    ###addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
                    ###addDir(name,line,200,tvglogo,cat,'','cat= ' + cat + '\n\rtvg-id= ' + tvgid + '\n\rtvg-name= '+tvgname + '\n\rgroup-title= ' + grouptitle,'','',tvgname)
    ChannelFile = os.path.join(datapath,ADDONid) + '.m3u'
    log('error 3092 Use ChannelFile ?: ' + repr(ChannelFile))
    if os.path.isfile(ChannelFile):
        log('3094 errorUse ChannelFile: ' + repr(ChannelFile))
        for line in open(ChannelFile):  # opened in text-mode; all EOLs are converted to '\n'
            ####log('Line: ' + repr(i) + ' - ' + line)
            line = line.rstrip('\n').rstrip('\r')
            if not line == '' and not line[:2] == '# ' :   # Ignore empty lines and comment lines
                if '#EXTM3U' in line :
                    i += 1
                    ####log('Skip EXTM3U in line: ' + repr(i))
                elif '#EXTINF' in line :
                    i += 1
                    ###if ',' in line:
                    ### log('Comma(,) in line: ' + repr(i) + ' - ' + line)
                    tvgid=''
                    tvgname=''
                    tvgnamecat = ''
                    tvglogo=''
                    grouptitl=''
                    name=''
                    ####log('Use EXTINF in line: ' + repr(i) + ' - ' + line)
                    try:
                        tvgid=line.split('tvg-id="',1)[1].split('"',1)[0]
                    except Exception as e:
                        log('err 2933 Except: %r' % e)
                        pass
                        tvgid=''
                    ####log('Use tvg-id in line: ' + repr(tvgid) + ' - ' + line)
                    try:
                        tvgname=line.split('tvg-name="',1)[1].split('"',1)[0]
                    except Exception as e:
                        log('err 2939 Except: %r' % e)
                        pass
                        tvgname=''
                    ####log('Use tvg-name in line: ' + repr(tvgname) + ' - ' + line)
                    try:
                        tvglogo=line.split('tvg-logo="',1)[1].split('"',1)[0]
                    except Exception as e:
                        log('err 2945 Except: %r' % e)
                        pass 
                        tvglogo=''
                    ####log('Use tvg-logo in line: ' + repr(tvglogo) + ' - ' + line)
                    try:
                        grouptitle=line.split('group-title="',1)[1].split('"',1)[0]
                    except Exception as e:
                        log('err 2951 Except: %r' % e)
                        pass
                        grouptitle=''
                    ####log('Use group-title in line: ' + repr(grouptitle) + ' - ' + line)
                    try:
                        name=line.split(',')[-1]
                    except Exception as e:
                        log('err 2956 Except: %r' % e)
                        pass
                        name=''
                    ####log('Use name in line: ' + repr(name) + ' - ' + line)
                    try:
                        grouptitle=grouptitle.split('SEASON')[0].strip()
                    except Exception as e:
                        log('err 2963 Except: %r' % e)
                        pass
                    tvgnamecat = ''
                    if ':' in tvgname:
                        tvgnamecat=tvgname.split(':')[0].strip()
                else:
                    i += 1
                    log('3158 error line= %r' % line)
                    cats=line.split('.')[-2].split('/')[-1]
                    catsinlink='! ' + line.split('/')[3]
                    log('3161 error catsinlink= %r' % catsinlink)
                    if IPTVuser in catsinlink :
                        catsinlink = '! live'
                    if  catsinlink == '! rt':
                        catsinlink = ''
                    log('3166 error catsinlink= %r' % catsinlink)
                    ######log('Use cname= ' + repr(cname) + ' - grouptitle= ' + repr(grouptitle))
                    if cname == grouptitle or cname == tvgnamecat or cname == catsinlink or cname == 'Channels':
                        channels.append([name.strip(),line,grouptitle,tvglogo,tvgname,tvgid,cats,catsinlink])
                    elif  cname == 'Categories':
                        if not grouptitle in categories:
                            categories.append(grouptitle)
                        if not tvgnamecat == '' and not tvgnamecat in categories:
                            categories.append(tvgnamecat)
                        if not catsinlink == '' and not catsinlink in categories:
                            categories.append(catsinlink)
                    ######log('Use URL in line: ' + repr(repr(i)) + ' - ' + line)
                    ###addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
                    ###addDir(name,line,200,tvglogo,cat,'','cat= ' + cat + '\n\rtvg-id= ' + tvgid + '\n\rtvg-name= '+tvgname + '\n\rgroup-title= ' + grouptitle,'','',tvgname)
    channels = sorted(channels)
    ######log('Use channels: ' + repr(channels))
    categories = sorted(categories)
    ######log('Use categories: ' + repr(categories))
    for cat in categories:
        ######log('Use categories: ' + repr(cat))
        if cat != '':
            addDir(cat,'url',2,'','','',channeldescription)
    ###cEPG = recordings.getConnection()
    ###recordings.createEPGchannelsTable(cEPG)
    ###c = cEPG.cursor()
    for cat in channels:
        ######log('Use channels: ' + repr(cat))
        if cat[0] != '':
            ###if RecordActive :  ###
            ### addChannel(name,url,iconimage,cat,source)
            ###recordings.addChannel(cat[0],cat[1],cat[3],cat[6], ADDONid)
            description = ''
            if cat[6] != '':
                description += ' \n\rcat= ' + cat[6]
            if cat[5] != '':
                description += ' \n\rtvg-id= ' + cat[5]
            if cat[4] != '':
                description += ' \n\rtvg-name= '+cat[4]
            if cat[2] != '':
                description += ' \n\rgroup-title= ' + cat[2]
            if cat[7] != '':
                description += ' \n\rcatsinlink= '+cat[7]
            if cat[1] != '' and definition.ADDONgetSetting('ShowLink') == 'true':
                description += ' \n\rlink= '+cat[1].replace('/','/ ').replace('\\','\\ ')
            ## 2017-07-12 recordings.addChannel(cat[0],cat[1],cat[3],cat[6], ADDONid+ ' available_channels',description=description)   ### Add channel during build of menus --> move to updateepg.py ###
            olddescription = recordings.getChannelDescription(cat[6])
            if olddescription != '':
                description = olddescription
            ##else:
            ##  recordings.setChannelDescription(cat[6],description)
            ### Add Live EPG
            ###log('cat= <%r>2 \nurl= %r' % (cat[6],cat[1]))
            if 'movie' in cat[1] or 'series' in cat[1]:  ### URL
                chx = description  ### Description of Movies
                ###log('MOVIE cat= <%r>3 \nurl= %r' % (cat[6],cat[1]))
            else:
                ###log('LIVE cat= <%r>4 \nurl= %r' % (cat[6],cat[1]))
                try:
                    EPGx = updateepg.getEPGnow(cat[6])  ### Live EPG on channels
                    EPG  = EPGx[0]
                    ###log('EPGx[0]= %r, EPGx[4]= %r' % (EPGx[0],EPGx[4]))
                    if EPGx[4] == '':
                        chx = description
                        ###log('LIVE no EPG cat= <%r>4 \nurl= %r' % (cat[6],cat[1]))
                    else:
                        chx = EPGx[4]
                        if EPGx[3] > 0:
                            chx += ' \nArchive Duration ' + str(EPGx[3]) + '\n'   ### 2018-06-11
                        for indexX in range(0, len(EPG)):
                            title = str(EPG[indexX][0])
                            description = str(EPG[indexX][1])
                            ###starttime = str(EPG[indexX][3].strftime('%H:%M'))
                            ###endtime = str(EPG[indexX][4].strftime('%H:%M'))
                            starttime = str(datetime.fromtimestamp(EPG[indexX][3]).strftime('%H:%M'))
                            endtime = str(datetime.fromtimestamp(EPG[indexX][4]).strftime('%H:%M'))
                            chx += ' \n[COLOR lightgreen]'+starttime + ' - ' + endtime + '[/COLOR] \n[COLOR blue]'+ title+ '[/COLOR] \n'+ description +' \n'
                except Exception as e:
                    log('err 3052 Except: %r' % e)
                    pass
                    log('Error in getting EPG \n' + repr(e))
                    chx = 'No EPG!'
            ###addDir(cat[0],cat[1],200,cat[3],cat[6],'',chx,'','',cat[4])
            addDir(cat[0],cat[1],200,cat[3],cat[6],'',chx)
            
            ###ChannelFav = recordings.getChannelFav(c,cat[0])
            ###recordings.addEPGChannel(c,cat[0],name,url,stream_icon,epg_channel_id,EPGgenerator)
            ###recordings.setChannelCatchup(c,cat[0],'False')
            ###recordings.setChannelFav(c,cat[0],ChannelFav)
            
            ###addDir(cat[0],cat[1],200,cat[3],cat[6],'','cat= ' + cat[6] + '\n\rtvg-id= ' + cat[5] + '\n\rtvg-name= '+cat[4] + '\n\rgroup-title= ' + cat[2] + ' \n\rcatsinlink= '+cat[7]+ ' \n\rlink= '+cat[1].replace('/','/ '),'','',cat[4])
            ###addDir(cat[0]+'*',cat[1].replace('.ts','.txt').replace('.mp4','.txt'),200,cat[3],cat[6],'',cat[1].replace('.ts','.txt').replace('.mp4','.txt'),'','',cat[4])
    ###link = 'http://roq-tv.net:25461/enigma2.php?username=XXX&password=XXXX&type=get_vod_categories'
    """
    2017-05-17 18:49:21 Test Encoding z: 
    OrderedDict(
    [(u'items', OrderedDict([(u'playlist_name', u'Example'), 
    (u'category', OrderedDict([(u'category_id', u'1'), (u'category_title', u'Example')])), 
    (u'channel', 
    [OrderedDict([(u'title', u'Live Streams'), (u'description', u'Live Streams Category'), (u'category_id', u'0'), (u'playlist_url', u'http://roq-tv.net:25461/enigma2.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass') + '&type=get_live_categories')]), 
    OrderedDict([(u'title', u'Vod'), (u'description', u'Video On Demand Category'), (u'category_id', u'1'), (u'playlist_url', u'http://roq-tv.net:25461/enigma2.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass') + '&type=get_vod_categories')])])]))])
    
How to iterate from end to beginning over an OrderedDict ?
Either:

z = OrderedDict( ... )
for item in z.items()[::-1]:
   # operate on item
Or:

z = OrderedDict( ... )
for item in reversed(z.items()):
   # operate on item

dict = OrderedDict()
# ...

for i, (key, value) in enumerate(dict.iteritems()):
    # Do what you want here

    
    """
    ###link = definition.getBASEURL() + '/enigma2.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass')
    ROQTVusername = IPTVuser
    if ROQTVusername.lower() != 'none' and enigma2 :
        try:
            link = definition.getBASEURL() + '/enigma2.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass')
            log('err link= %r' % link)
            ###file = urlopen(link)
            ###data = file.read()
            data = utils.readlink(link,'',module)
            log('err link=%r\ndata= %r' % (link,data))
            ###file.close()
            
            for titem in ['title','description']:
                ###utils.logdev('Test Encoding','titem= ' + repr(titem) + ' - data= ' + repr(data))
                data = data.split('<'+titem+'>')
                ###utils.logdev('Test Encoding 1',repr(data))
                i=0
                newdata= ''
                for part in data:
                    ###utils.logdev('Test Encoding 2',repr(part))
                    if i==0:
                        newdata+=part
                        ###utils.logdev('Test Encoding 3',repr(newdata))
                        i+=1
                    else:
                        part=part.split('</'+titem+'>',1)
                        ###utils.logdev('Test Encoding 4',repr(part))
                        ### newdata+='<'+titem+'>' + base64.b64decode(part[0]) +'</'+titem+'>' + part[1]
                        newdata+='<'+titem+'>' + base64.b64decode(part[0], '-_') +'</'+titem+'>' + part[1]
                        ###utils.logdev('Test Encoding 5',repr(newdata))
                ###utils.logdev('Test Encoding 6',repr(newdata))
                data = newdata
            
            ### Save file with all newdata!
            ChannelFile = os.path.join(datapath,ADDONid) + '.newdata'
            with open(ChannelFile,'w') as output:
                output.write(newdata)
                
            log('AddOn m3u file downloaded: ' + repr(ChannelFile))
            data = xmltodict.parse(newdata)
            ###utils.logdev('Test Encoding x',repr(data))
            
            ChannelFile = os.path.join(datapath,ADDONid) + '.data'
            with open(ChannelFile,'w') as output:
                output.write('Data= %r' % data)
                
            for i, (key, value) in enumerate(data.iteritems()):
                ###utils.logdev('Test Encoding y1','i= %s, key= %s, value= %s' % (repr(i), repr(key),repr(value)))
                for i1, (key1, value1) in enumerate(value.iteritems()):
                    if key1 == 'channel':
                        ###utils.logdev('Test Encoding y2','i1= %s, key1= %s, value1= %s' % (repr(i1), repr(key1),repr(value1)))
                        for channelROQ in value1:
                            d=channelROQ
                            ###utils.logdev('Test Encoding y3','i1= %s, key1= %s, channelROQ= %s, url= %s' % (repr(d.items()[0]), repr(d.items()[1]),repr(d.items()[2]),repr(d.items()[3])))
                            ###utils.logdev('Test Encoding y4','\n\ntitle= %s,\n description= %s,\n category_id= %s,\n playlist_url= %s\n' % (repr(d['title']), repr(d['description']),repr(d['category_id']),repr(d['playlist_url'])))

            ###z = OrderedDict( ... )
            ###for item in data.items()[::-1]:
                # operate on item
            ### ###utils.logdev('Test Encoding y',repr(item))
                
            """
            Test Encoding 1: OrderedDict(
            [(u'items', OrderedDict(
                [(u'playlist_name', u'Movie [ Example ]'), (u'category', OrderedDict([(u'category_id', u'1'), (u'category_title', u'Movie [ Example ]')])), 
                (u'channel', 
                    [OrderedDict([(u'title', u'QWxs'), (u'description', u'TW92aWUgU3RyZWFtcyBDYXRlZ29yeSBbIEFMTCBd'), (u'category_id', u'0'), (u'playlist_url', u'http://roq-tv.net:25461/enigma2.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass') + '&type=get_vod_streams&cat_id=0')]), 
                    OrderedDict([(u'title', u'Rk9SIEFEVUxUUw=='), (u'description', u'TW92aWUgU3RyZWFtcyBDYXRlZ29yeQ=='), (u'category_id', u'110'), (u'playlist_url', u'http://roq-tv.net:25461/enigma2.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass') + '&type=get_vod_streams&cat_id=110')]), 
                    OrderedDict([(u'title', u'TkVXIE1PVklFUw=='), (u'description', u'TW92aWUgU3RyZWFtcyBDYXRlZ29yeQ=='), (u'category_id', u'111'), (u'playlist_url', u'http://roq-tv.net:25461/enigma2.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass')+'&type=get_vod_streams&cat_id=111')]), 
                    OrderedDict([(u'title', u'S0lEUyBNT1ZJRVM='), (u'description', u'TW92aWUgU3RyZWFtcyBDYXRlZ29yeQ=='), (u'category_id', u'112'), (u'playlist_url', u'http://roq-tv.net:25461/enigma2.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass') + '&type=get_vod_streams&cat_id=112')]), 
                    OrderedDict([(u'title', u'Qk9YU0VUUw=='), (u'description', u'TW92aWUgU3RyZWFtcyBDYXRlZ29yeQ=='), (u'category_id', u'113'), (u'playlist_url', u'http://roq-tv.net:25461/enigma2.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass')+ '&type=get_vod_scategories&scat_id=113')]), 
                    OrderedDict([(u'title', u'VFZTRVJJRVM='), (u'description', u'TW92aWUgU3RyZWFtcyBDYXRlZ29yeQ=='), (u'category_id', u'77'), (u'playlist_url', u'http://roq-tv.net:25461/enigma2.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass')+'&type=get_vod_streams&cat_id=77')]), 
                    OrderedDict([(u'title', u'TU9WSUVT'), (u'description', u'TW92aWUgU3RyZWFtcyBDYXRlZ29yeQ=='), (u'category_id', u'60'), (u'playlist_url', u'http://roq-tv.net:25461/enigma2.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass')+'&type=get_vod_streams&cat_id=60')])])]))])
            http://roq-tv.net:25461/enigma2.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass')+'&type=get_catchup_categories
            http://roq-tv.net:25461/enigma2.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass')+'&type=get_catchup_streams&cat_id=14
            http://roq-tv.net:25461/enigma2.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass')+'&type=get_vod_categories
            http://roq-tv.net:25461/enigma2.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass')+'&type=get_vod_streams&cat_id=110
            import base64
            aircode = base64.b64decode('RElSRUNUT1I6IApQTE9UOiAKQ0FTVDogClJBVElORzogClJFTEVBU0VEQVRFOiAKR0VOUkU6IApJTURCX0lEOiAKRFVSQVRJT05fU0VDUzogMjIxNQpEVVJBVElPTjogMDA6MzY6NTUKVklERU86IEFycmF5CkFVRElPOiBBcnJheQpCSVRSQVRFOiA3NzQK')
            ###utils.logdev('Test Encoding',aircode)
            """
        except Exception as e:
            log('err 3237 Except: %r' % e)
            pass
            log('enigma2.php? ERROR %r' % e)
    setView('movies', 'main-view')     
            
def MyChannels():
    cat='-2'
    net.set_cookies(cookie_jar)
    now= datetime.today().replace(microsecond=0).strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20')
    url='&mwAction=category&xbmc=1&mwData={"id":"%s","time":"%s","type":"tv"}'%(cat,now)
    link = net.http_GET(site+url, headers={'User-Agent' : UA}).content
    log('err link= %r' % link)
    data = json.loads(link)
    channels=data['contents']
    from operator import itemgetter
    #Sort channels by name or id/cat
    if definition.ADDONgetSetting('SortAlphabetically')=='true':
        channels = sorted(channels, key=itemgetter('id'))
    else:
        channels = sorted(channels, key=itemgetter('name'))
    AllMyChannels=[]
    
    for field in channels:
        name         =  field['name'].encode("utf-8")
        channel      =  field['id']
        displaychannelnumber = (name + ' (' +channel+'):\n' )
        AllMyChannels.append(displaychannelnumber)
    return AllMyChannels
        

def GENRE(name,cat):
    GoHome('GENRE')
    _GENRE_=name.lower()
    #now= datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20')
    now= datetime.today().replace(microsecond=0).strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20')
    ## 3.4.6 now= datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20')
    
    net.set_cookies(cookie_jar)
    url='&mwAction=category&xbmc=2&mwData={"id":"%s","time":"%s","type":"tv"}'%(cat,now)
    link = net.http_GET(site+url, headers={'User-Agent' : UA }).content
    log('err link= %r' % link)
    data = json.loads(link)
    channels=data['contents']
    # Krogsbell 2014-09-18 3 lines
    from operator import itemgetter
    #Sort channels by name!
    if definition.ADDONgetSetting('SortAlphabetically')=='true':
         channels = sorted(channels, key=itemgetter('name'))
    ###uniques=[] ###removed 2019-03-03 not used?
    
    offset= int(data['offset'])
    for field in channels:
        genre      =  field['genre']
        endTime      =  field['time_to']
        name         =  field['name'].encode("utf-8")
        channel      =  field['id']
        whatsup      =  field['whatsup'].encode("utf-8")
        displaychannelnumber = (name + ' (' +channel+'):\n' )
        description  =  (displaychannelnumber + field['descr']).encode("utf-8")
        #description  =  field['descr'].encode("utf-8")
        r=re.compile("(.+?)-(.+?)-(.+?) (.+?):(.+?):(.+?)")
        matchend     =  r.search(endTime)
        endyear      =  matchend.group(1)
        endmonth     =  matchend.group(2)
        endday       =  matchend.group(3)
        endhour      =  matchend.group(4)
        endminute    =  matchend.group(5)

        endDate  =  datetime(int(endyear),int(endmonth),int(endday),int(endhour),int(endminute)) + timedelta(seconds = offset)

        
        if definition.ADDONgetSetting('tvguide')=='true':
            if not endDate  == '' and recordings.getRecordingsActiveAll(endDate,endDate): #################################################################
                name='%s - [COLOR red]%s[/COLOR]'%(name,whatsup)
            else:
                name='%s - [COLOR yellow]%s[/COLOR]'%(name,whatsup)
        if genre.lower() == _GENRE_:
            #newiconurl= recordings.imageUrlicon(imageUrl,channel,'.png')
            newiconurl= recordings.getIcon(name,channel)
            addDir(name,'url',200,newiconurl,channel,'',description,now,endDate,whatsup)
    setView('movies', 'channels-view')         
  
def isMyAccountOK():
    errorInBasicInfo = True
    descr = 'No Description'
    username    =IPTVuser
    ROQTVusername = IPTVuser
    link = ''
    if ROQTVusername.lower() != 'none':
        descr = 'Username= %s' % ROQTVusername
        link = ''
        if definition.ADDONgetSetting('panel_api') == 'true':
            try:
                link = definition.getBASEURL() + '/panel_api.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass')
                log('err My_Account link= %r' % link)
                data = utils.readlink(link,os.path.join(datapath,ADDONid) + '.info',module)
                log('err My_Account 1 link= %r' % link)
                if len(data) > 0:
                    d = json.loads(data)
                    log('err My_Account 2 link= %r' % link)
                    d1 = d['user_info']
                    log('err My_Account 3 link= %r' % link)
                    formats = d1['allowed_output_formats']
                    log('err My_Account 4 link= %r' % link)
                    allowedformats = AllowedFormats(formats)
                    log('err My_Account 5 link= %r' % link)
                    if d1['is_trial'] == '1':
                        log('errMy_Account 6 link= %r' % link)
                        is_trial = '\nThis is a trial '
                    else:
                        log('err My_Account 7 link= %r' % link)
                        is_trial = ''
                    log('err My_Account 8 link= %r' % link)   
                    
                    forever = definition.ADDONgetSetting('forever')
                    log('err My_Account 9 link= %r' % link)
                    expiredate = recordings.parseDate(d1['exp_date'])
                    log('err My_Account 10 link= %r' % link)
                    log('err My_Account expiredate= %r' % expiredate)
                    if forever == 'true':
                        log('err My_Account 11 link= %r' % link)
                        expiredate =  'none'
                        remainingdaysS = ''
                        log('err My_Account 2 expiredate= %r' % expiredate)
                    else:
                        log('err My_Account 12 link= %r' % link)
                        now = datetime.now()
                        ###remainingdays = (recordings.parseDate(d1['exp_date'])-recordings.parseDate(now)).days
                        log('err My_Account 13 link= %r' % link)
                        remainingdays = (expiredate-recordings.parseDate(now)).days
                        log('err My_Account 14 link= %r' % link)
                        if remainingdays < 7:
                            log('err My_Account 15 link= %r' % link)
                            remainingdaysS = '\n[B][COLOR red]Remaining days= '+ str(remainingdays)  + '[/COLOR][/B]'
                        else:
                            log('err My_Account 16 link= %r' % link)
                            remainingdaysS = '\n[B][COLOR green]Remaining days= '+ str(remainingdays)  + '[/COLOR][/B]'
                        log('err My_Account 17 link= %r' % link)
                        expiredate = expiredate.strftime('%Y-%m-%d %H:%M')
                        log('err My_Account 3 expiredate= %r' % expiredate)
                    definition.ADDONresetSetting('expiredate',expiredate)
                    log('err My_Account 18 link= %r' % link)
                    
                    ###descr = 'Username= %r \nStatus= %r \nExpire= %r%r%r\nMax connections= %r \nConnections in use= %r \nAllowed formats= %r' %(d1['username'],d1['status'],recordings.parseDate(d1['exp_date']).strftime('%Y-%m-%d %H:%M'),remainingdaysS,is_trial,d1['max_connections'],d1['active_cons'],allowedformats)
                    ###descr = 'Username= %r \nStatus= %r \nExpire= %r%r%r\nMax connections= %r \nConnections in use= %r \nAllowed formats= %r' %(d1['username'],d1['status'],expiredate.strftime('%Y-%m-%d %H:%M'),remainingdaysS,is_trial,d1['max_connections'],d1['active_cons'],allowedformats)
                    descr = 'Username= %s \nStatus= %s \nExpire= %s%s%s\nMax connections= %s \nConnections in use= %s \nAllowed formats= %s' %(d1['username'],d1['status'],expiredate,remainingdaysS,is_trial,d1['max_connections'],d1['active_cons'],allowedformats)
                    log('err My_Account 19 link= %r' % link)
                    errorInBasicInfo = False
                else:
                    errorInBasicInfo = True
                    descr = 'Error in getting My Account Basic Info Missing'
            except Exception as e:
                pass
                errorInBasicInfo = True
                log('Error MYACCOUNT Except: %r'% e)
                descr = 'Error in getting My Account Basic Info: %r'% e
            log('err My_Account Basic Info len= %r\n%r' % (len(descr),descr))
            
            """
            if errorInBasicInfo :
                addDir('[B][COLOR red]Basic Info[/COLOR][/B]','url',12,'','','',descr)
            else:
                addDir('[B][COLOR lightgreen]Basic Info[/COLOR][/B]','url',12,'','','',descr)
            log('My_Account 20 link= %r' % link)
            """
    return [errorInBasicInfo,descr, link]
  
def MYACCOUNT():
    GoHome('My Account')
    username    =IPTVuser
    ROQTVusername = IPTVuser
    if ROQTVusername.lower() != 'none':
        errorInBasicInfo, descr, link = isMyAccountOK()
        """###try:
        if 1 == 1: ### try disable
            descr = 'Username= %s' % ROQTVusername
            link = ''
            if definition.ADDONgetSetting('panel_api') == 'true':
                try:
                    link = definition.getBASEURL() + '/panel_api.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass')
                    log('My_Account link= %r' % link)
                    data = utils.readlink(link,os.path.join(datapath,ADDONid) + '.info',module)
                    log('My_Account 1 link= %r' % link)
                    
                    d = json.loads(data)
                    log('My_Account 2 link= %r' % link)
                    d1 = d['user_info']
                    log('My_Account 3 link= %r' % link)
                    formats = d1['allowed_output_formats']
                    log('My_Account 4 link= %r' % link)
                    allowedformats = AllowedFormats(formats)
                    log('My_Account 5 link= %r' % link)
                    
                    if d1['is_trial'] == '1':
                        log('My_Account 6 link= %r' % link)
                        is_trial = '\nThis is a trial '
                    else:
                        log('My_Account 7 link= %r' % link)
                        is_trial = ''
                    log('My_Account 8 link= %r' % link)   
                    
                    forever = definition.ADDONgetSetting('forever')
                    log('My_Account 9 link= %r' % link)
                    expiredate = recordings.parseDate(d1['exp_date'])
                    log('My_Account 10 link= %r' % link)
                    log('My_Account expiredate= %r' % expiredate)
                    if forever == 'true':
                        log('My_Account 11 link= %r' % link)
                        expiredate =  'none'
                        remainingdaysS = ''
                        log('My_Account 2 expiredate= %r' % expiredate)
                    else:
                        log('My_Account 12 link= %r' % link)
                        now = datetime.now()
                        ###remainingdays = (recordings.parseDate(d1['exp_date'])-recordings.parseDate(now)).days
                        log('My_Account 13 link= %r' % link)
                        remainingdays = (expiredate-recordings.parseDate(now)).days
                        log('My_Account 14 link= %r' % link)
                        if remainingdays < 7:
                            log('My_Account 15 link= %r' % link)
                            remainingdaysS = '\n[B][COLOR red]Remaining days= '+ str(remainingdays)  + '[/COLOR][/B]'
                        else:
                            log('My_Account 16 link= %r' % link)
                            remainingdaysS = '\n[B][COLOR green]Remaining days= '+ str(remainingdays)  + '[/COLOR][/B]'
                        log('My_Account 17 link= %r' % link)
                        expiredate = expiredate.strftime('%Y-%m-%d %H:%M')
                        log('My_Account 3 expiredate= %r' % expiredate)
                    definition.ADDONresetSetting('expiredate',expiredate)
                    log('My_Account 18 link= %r' % link)
                    
                    ###descr = 'Username= %r \nStatus= %r \nExpire= %r%r%r\nMax connections= %r \nConnections in use= %r \nAllowed formats= %r' %(d1['username'],d1['status'],recordings.parseDate(d1['exp_date']).strftime('%Y-%m-%d %H:%M'),remainingdaysS,is_trial,d1['max_connections'],d1['active_cons'],allowedformats)
                    ###descr = 'Username= %r \nStatus= %r \nExpire= %r%r%r\nMax connections= %r \nConnections in use= %r \nAllowed formats= %r' %(d1['username'],d1['status'],expiredate.strftime('%Y-%m-%d %H:%M'),remainingdaysS,is_trial,d1['max_connections'],d1['active_cons'],allowedformats)
                    descr = 'Username= %s \nStatus= %s \nExpire= %s%s%s\nMax connections= %s \nConnections in use= %s \nAllowed formats= %s' %(d1['username'],d1['status'],expiredate,remainingdaysS,is_trial,d1['max_connections'],d1['active_cons'],allowedformats)
                    log('My_Account 19 link= %r' % link)
                    
                    errorInBasicInfo = False
                except Exception as e:
                    pass
                    errorInBasicInfo = True
                    log('Error MYACCOUNT exception: %r'% e)
                    descr = 'Error in getting My Account Basic Info: %r'% e
        """
        log('err My_Account Basic Info len= %r\n%r' % (len(descr),descr))
        descr = BasicUserInfoDesc() ### 2025-05-09
        if errorInBasicInfo :
            addDir('[B][COLOR orangered]Basic Info[/COLOR][/B]','url',12,'','','',descr)
        else:
            addDir('[B][COLOR lightgreen]Basic Info[/COLOR][/B]','url',12,'','','',descr)
        log('My_Account 20 link= %r' % link)
        """
        except Exception as e:
            log('My_Account Exception: %r' % e)
            pass
            log('My_Account 21 link= %r' % link)
            utils.notification('Error in getting '+ ADDONid + ' info! Check your User ID\n' + repr(e))
            addDir('[B][COLOR red]Basic Info[/COLOR][/B]','url',0,'1','','',descr+'\n\nError in getting '+ ADDONid + ' info!\nCheck your User ID\n\n' + repr(e))
            d = []
        """
    addDir('IPTV Home: [B]%s[/B]' % definition.getREGISTRATION(),definition.getREGISTRATION(),1043,'','','','Home page for your IPTV Supplier\nClick to open page in browser')
    my_referral_setup_portal = definition.ADDONgetSetting('my_referral_setup_portal')
    if 'http' in my_referral_setup_portal.lower():
        addDir('IPTV Setup Portal: [B]%s[/B]' % my_referral_setup_portal,my_referral_setup_portal,1043,'','','','Setup page for your IPTV Supplier\nClick to open page in browser')
    addDir('Basic URL: [B]%s[/B]' % definition.getBASEURL(),definition.getBASEURL(),1044,'','','','Basic URL for your IPTV\nClick to open web access to your channels (if possible)')
    addDir('VLC Favorite Channels: [B]%s[/B]' % ADDONrefer + ' Favorites.m3u','url',1045,'','','','VLC Open Favorites\nClick to open VLC access to your favorite channels')
    ###addDir('VLC All Channels: [B]%s[/B]' % ADDONid + '.m3u','url',1046,'','','','VLC Open All Channels\nClick to open VLC access to your channels')
    if definition.ADDONgetSetting('ShowLink') == 'true':
        addDir('VLC All Original Channels: from Basic User Info File\n[I][COLOR grey]'+ definition.ADDONgetSetting('AAA').replace('basicuserinfo= ','').replace("'",'')+ '[/COLOR][/I]','url',1047,'','','','VLC Open All Original Channels\nClick to open VLC access to all your channels')
    else:
        addDir('VLC All Original Channels: from Basic User Info File','url',1047,'','','','VLC Open All Original Channels\nClick to open VLC access to all your channels')
    addDir('User: [B]%s[/B]' % username,'url',14,'','','','Change your username and password. Then all channels will be removed and the EPG starts to update. You will loose favorites, recursive and hidden channels')
    addDir('Past settings.xml','url',15,'','','','Change setting to a previous state and may be user')
    if username.lower() != 'none':
        defaultdaystotest = 62 * 24 * 60 * 60
        try:
            daystotest = utils.intADDONgetSetting('daystotest') * 24 * 60 * 60
            if daystotest == 0:
                daystotest = defaultdaystotest
        except Exception as e:
            log('err 3437 Except: %r' % e)
            pass
            daystotest = defaultdaystotest
        addDir('New Channels and VOD','url',21,'','','','Newest '+ADDONrefer +' Channels and VOD sorted by creation date. \n\nShowing New Channels and VOD the last '+str(daystotest//(24 * 60 * 60))+' days[CR][CR]Show in blocks of ' + definition.ADDONgetSetting('searchcountmax'))  
        ###addDir('New TV Series','url',211,'','','','Newest '+ADDONrefer +' TV Series sorted by creation date. \n\nShowing New TV Series the last '+str(daystotest/(24 * 60 * 60))+' days[CR][CR]Show in blocks of ' + definition.ADDONgetSetting('searchcountmax')) 
        ###addDir('New TV Series','url',211,'','','','Newest '+ADDONrefer +' TV Series sorted by creation date. \n\nShowing New TV Series for '+str(daystotest/(24 * 60 * 60))+' days starting with the latest added TV Series[CR][CR]Show in blocks of ' + definition.ADDONgetSetting('searchcountmax'))
    addDir('[COLOR red][B]Restart with New User[/B][/COLOR]','url',10,'','','','Resets the user, sets the time and resets the database')
    #addDir('My Subscriptions','url',9,'','','','')
    #addDir('Past Orders','url',10,'','','','')
    setView('movies', 'main-view')

def Streams():
    GoHome('Streams')
    ROQTVusername = IPTVuser
    if ROQTVusername.lower() != 'none':
        addDir('[COLOR lightgreen]Archive/Catch up[/COLOR]','url',18,'','','','All '+ADDONrefer +' channels, that have archive/catch up. \n\nGo to TV Guide for the channel to watch or record catch up or comming events')
    xmltvfile = definition.ADDONgetSetting('directchannelsfromextraXMLTVfile').replace('/','/ ').replace('\\','\\ ')
    if xmltvfile != '':
        xmltvfile = '\n\nYour Direct Channels are defined in:\n' + xmltvfile
    addDir('[COLOR lightgreen]Direct Channels[/COLOR]','url',19,'','','','All direct channels from extra XMLTV file. Channels you can watch if you just are in the right country'+xmltvfile)
    
    KrogsbellAddOns = definition.getKrogsbellAddOns()
    log('KrogsbellAddOns= %r' % KrogsbellAddOns)
    for kaddon in KrogsbellAddOns:
        log('kaddon= %r' % kaddon)
        try:
            kaddonID = kaddon.split('.')[2][:3].upper()
            taddonID = ADDONid.split('.')[2][:3].upper()
        except Exception as e:
            log('err 34303 Except: %r' % e)
            pass
            EpgError = 'Error in getting AddOn ID\n' + repr(e) 
            kaddonID = ''
            taddonID = ''
        log('kaddonID= %r' % kaddonID)
        log('taddonID= %r' % taddonID)
        if kaddonID != '' and kaddonID != taddonID:
            try:
                nADDON = xbmcaddon.Addon(id=kaddon)
                naddon = nADDON.getAddonInfo('name')
                NTVchannels = xbmcvfs.translatePath(nADDON.getAddonInfo('profile') + 'channels.csv')
                if os.path.isfile(NTVchannels):
                    addDir('[COLOR lightgreen]'+naddon+' Channels ('+kaddonID+')[/COLOR]','url',190,'','','','All channels from '+naddon+' addon ('+kaddonID+')[CR][CR]Show in blocks of ' + definition.ADDONgetSetting('searchcountmax'))
            except Exception as e:
                log('err 3417 Except: %r' % e)
                pass
                log('NTVchannels '+kaddon+' Error= %r' % e)
    """
    try:
        NTVchannels = xbmcvfs.translatePath( xbmcaddon.Addon(id='plugin.video.tvawayrec').getAddonInfo('profile') + 'channels.csv')
        if os.path.isfile(NTVchannels):
            addDir('[COLOR lightgreen]TVaway Channels[/COLOR]','url',191,'','','','All channels from TVaway Rec addon[CR][CR]Show in blocks of ' + definition.ADDONgetSetting('searchcountmax'))
    except Exception as e:
        pass
        log('NTVchannels TVaway Error= %r' % e)
    """
    ROQTVusername = IPTVuser
    if ROQTVusername.lower() != 'none':
        ###addDir('[COLOR lightgreen]TV Series[/COLOR]','url',192,'','','',ADDONrefer +' TV Series sorted by Title\nSelect TV Series from database and show all Episodes\n\nShow in blocks of ' + definition.ADDONgetSetting('searchcountmax'))
        
        defaultdaystotest = 62 * 24 * 60 * 60
        try:
            daystotest = utils.intADDONgetSetting('daystotest') * 24 * 60 * 60
            if daystotest == 0:
                daystotest = defaultdaystotest
        except Exception as e:
            log('err 3438 Except: %r' % e)
            pass
            daystotest = defaultdaystotest
        
        addDir('[COLOR lightgreen]New Channels and VOD[/COLOR]','url',21,'','','','Newest '+ADDONrefer +' Channels and VOD sorted by creation date. \n\nShowing New Channels and VOD the last '+str(daystotest//(24 * 60 * 60))+' days[CR][CR]Show in blocks of ' + definition.ADDONgetSetting('searchcountmax'))
        ###addDir('[COLOR lightgreen]New TV Series[/COLOR]','url',211,'','','','Newest '+ADDONrefer +' TV Series sorted by creation date. \n\nShowing New TV Series for '+str(daystotest/(24 * 60 * 60))+' days starting with the latest added TV Series[CR][CR]Show in blocks of ' + definition.ADDONgetSetting('searchcountmax'))
    if definition.ADDONgetSetting('enable_record')=='true':
        addDir('[COLOR lightgreen]Recursive Search Channels[/COLOR]','url',26,'','','','All channels used for recursive search')
    try:
        ROQTVusername = IPTVuser
        if ROQTVusername.lower() != 'none' and enigma2:
            link = definition.getBASEURL() + '/enigma2.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass')
            log('err CATEGORIES 0 link= %r' % link)
            ###file = urlopen(link)
            ###data = utils.readlink(logo,'',module)
            ###data = file.read()
            ###log('err link=%r\ndata= %r' % (link,data))
            ###file.close()
              
            ChannelFile = os.path.join(datapath,ADDONid) + '.enigma2'
            utils.makeOldFile(ChannelFile)
            data = utils.readlink(logo,ChannelFile,module)
            ###with open(ChannelFile,'wb') as output:
            ###    output.write(data)
            
            ###log('CATEGORIES 1 data= %r' % data)
            for titem in ['title','description']:
                ###utils.logdev('Test Encoding','titem= ' + repr(titem) + ' - data= ' + repr(data))

                data = data.split('<'+titem+'>')
                ###utils.logdev('Test Encoding 1',repr(data))
                i=0
                newdata= ''
                for part in data:
                    ###utils.logdev('Test Encoding 2',repr(part))
                    if i==0:
                        newdata+=part
                        ###utils.logdev('Test Encoding 3',repr(newdata))
                        i+=1
                    else:
                        part=part.split('</'+titem+'>',1)
                        ###utils.logdev('Test Encoding 4',repr(part))
                        ### newdata+='<'+titem+'>' + base64.b64decode(part[0]) +'</'+titem+'>' + part[1]
                        newdata+='<'+titem+'>' + base64.b64decode(part[0], '-_') +'</'+titem+'>' + part[1]
                        ###utils.logdev('Test Encoding 5',repr(newdata))
                ###log('CATEGORIES 2 data= %r' % data)
                data = newdata
            ChannelFile3 = os.path.join(datapath,ADDONid) + '.enigma3'
            utils.makeOldFile(ChannelFile3)
            with open(ChannelFile3,'w') as output:
                output.write(data)
            data = xmltodict.parse(newdata)
            ###ChannelFile3 = os.path.join(datapath,ADDONid) + '.enigma4'
            ###utils.makeOldFile(ChannelFile3)
            ###with open(ChannelFile3,'wb') as output:
            ###    output.write(data)
            ###log('Test Encoding x(data)' + repr(data))
        
            for i, (key, value) in enumerate(data.iteritems()):
                ###utils.logdev('Test Encoding y1','i= %s, key= %s, value= %s' % (repr(i), repr(key),repr(value)))
                for i1, (key1, value1) in enumerate(value.iteritems()):
                    if key1 == 'channel':
                        ###utils.logdev('Test Encoding y2','i1= %s, key1= %s, value1= %s' % (repr(i1), repr(key1),repr(value1)))
                        for channelROQ in value1:
                            d=channelROQ
                            ###utils.logdev('Test Encoding y3','i1= %s, key1= %s, channelROQ= %s, url= %s' % (repr(d.items()[0]), repr(d.items()[1]),repr(d.items()[2]),repr(d.items()[3])))
                            ###utils.logdev('Test Encoding y4','\n\ntitle= %s,\n description= %s,\n category_id= %s,\n playlist_url= %s\n' % (repr(d['title']), repr(d['description']),repr(d['category_id']),repr(d['playlist_url'])))
                            addDir(d['title'],d['playlist_url'],22,d['category_id'],'','',ADDONrefer+' in original sorting and categorizing: \n' + d['description'])
                            ###addDir(d['title'],d['playlist_url'],22,d['category_id'],'','','description default line 366')
    except Exception as e:
        log('err 3572 Except: %r' % e)
        pass
        utils.notification('Error in get Categori from enigma2: ' + repr(e))
        log('Error in get Categori from enigma2: ' + repr(e))
    
    ROQTVusername = IPTVuser
    if ROQTVusername.lower() != 'none':
        addDir('Categories','url',2,'','','','All '+ADDONrefer +' categories based on information in channel list and all direct channels from extra XMLTV file. \n\nA channel may be member of several categoties. \n\nCategories are sorted alphabetically')
        addDir('Channels','url',23,'','','','All '+ADDONrefer +' channels and all direct channels from extra XMLTV file shown without categories. \n\nUse search to find your channel or VOD. \n\nChannels, Video on Demand are sorted alphabetically')
    else:
        addDir('Categories','url',2,'','','','All categories of all direct channels from extra XMLTV file. \n\nA channel may be member of several categoties. \n\nCategories are sorted alphabetically')
        addDir('Channels','url',23,'','','','All direct channels from extra XMLTV file shown without categories. \n\nUse search to find your channel. \n\nChannels are sorted alphabetically')
    setView('movies', 'main-view')

def getPlannedRecordingCounts():
    result =''
    log('3666 err getPlannedRecordingCounts')
    try:
        c = recordings.getConnection().cursor()
        ###cutoffdate = (datetime.today() - timedelta(days = 1)).strftime('%Y-%m-%d')
        cutoffdate = CutOffDateTime()
        c.execute("SELECT * FROM recordings_adc WHERE start>? AND name NOT LIKE '%Recursive:%'", [cutoffdate])   ### 2018-09-11 use startdate against cutoff date
        recordingsC = c.fetchall()
        result =  'P' + str(len(recordingsC))
        log('3674 err getPlannedRecordingCounts')
    except Exception as e:
        log('err 3595 Except: %r' % e)
        pass
        log( 'c.execute(SELECT * FROM recordings_adc WHERE end>? AND name NOT LIKE Recursive:, [cutoffdate]) failed! \nERROR= %r' % e)
        result = repr(e)
    try:
        log('3681 err getPlannedRecordingCounts')
        c = recordings.getConnection().cursor()
        c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE '%Recursive:%'")
        recordingsC = c.fetchall()
        result +=  '/R' + str(len(recordingsC))
        log('3686 err getPlannedRecordingCounts')
    except Exception as e:
        log('err 3604 Except: %r' % e)
        pass
        log( 'c.execute(SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE Recursive:) failed! \nERROR= %r' % e)
        result += repr(e)
    log('3692 err getPlannedRecordingCounts')
    return result+' '+AllCounts
      
        
def Maintenance():
    log('Maintenance')
    GoHome('Maintenance')
    log('Maintenance1')
    
    if definition.ADDONgetSetting('internet') == 'true':
        addDir('[B]Streams[/B]','url',490,'','','',ADDONrefer + ' Streams')
    
    if definition.ADDONgetSetting('enable_record')=='true' or recordArchivePath != '' or recordPath != '' or 1 == 1:  ### 2022-06-23 Always show menu entry
        ###addDir('[COLOR lightgreen]Search Channels and VOD[/COLOR]','url',2008,'','','','Search all '+ADDONname +' channels and all channels from extra XMLTV file ')
        SearchPath = 'All recorded items in[CR]' + recordPath
        SearchPathLocal = SearchPath
        if recordArchivePath != '' or recordArchivebPath != '':
            SearchPath += '[CR][CR]and all items in archive[CR]' 
        if recordArchivePath != '':
            SearchPath += '[CR]' + recordArchivePath
        if recordArchivebPath != '':
            SearchPath += '[CR]' + recordArchivebPath
        SearchPath = SearchPath.replace('/','/ ').replace('\\','\\ ')
        SearchPathLocal = SearchPathLocal.replace('/','/ ').replace('\\','\\ ')
        ###addDir('[COLOR orangered][B]Search Recordings in Database[/B][/COLOR]','url',2065,'','','','Search recording files and archive in Database' + '[CR][CR]If you want episode 98 of Midsomer Murders, you can seek: midsom%98[CR]To avoid some records add ^notsearchtext[CR][CR]Search in local recordings include l:[CR]Search in archive recordings include a:[CR]Search in root of local and archive include r:[CR]Search in recordings with pending commands include c:[CR][CR]Sort by file date decending include n:[CR]Sort by duration include d:[CR]Sort by series/episode include s:[CR][CR]Note! Search is NOT case sensitive')
        
        if definition.ADDONgetSetting('enable_record')=='true' :   ### 2022-06-23
            if definition.ADDONgetSetting('sortalphabetic') == 'true':
                addDir('[B][COLOR lightgreen]Search Recordings Alphabetical[/COLOR][/B]','url',6,'','','',SearchPath+'\n\nSorted alphabetically')
            else:
                addDir('[B][COLOR lightgreen]Search Recordings by Date[/COLOR][/B]','url',66,'','','',SearchPath+'\n\nSorted by file date')
            addDir('[B][COLOR lightgreen]Latest Recordings[/COLOR][/B]','url',2060,'','','',SearchPathLocal+'\n\nSorted by file date')
    addDir('[B][COLOR grey]Mount Network Drive[/COLOR][/B]','url',4400,'','','','Click to mount the networkdrive set in Settings Recordings used for Archive','','','')
    addDir('[B][COLOR lightblue]Full and Favorite EPG [/COLOR][/B]','url',4440,'','','','Create full and favorite EGP in recordings folder','','','')
    addDir('[B][COLOR lightblue]Reset All Favorites [/COLOR][/B]','url',4441,'','','','Remove favorites flag from all channels','','','')
    addDir('[B][COLOR yellow]Make a Clone of this Addon[/COLOR][/B]','url',2500,'1','1','1','Make a new addon as a clone of this one. \n\nYou set the name of the addon. The files of this addon is copied to this new addon and configuration files uptated. Then all the files are zipped to make a zipfile to install this new addon. You can personalise the addon, by changing .png and .jpg files in the addon')
    addDir('Make a Copy of this Addon with Data','url',2502,'1','1','1','Make a new addon as a copy of this one with copy of data folder. \n\nYou set the name of the addon. The files of this addon is copied to this new addon and configuration files uptated. Then all the files are zipped to make a zipfile to install this new addon. The datafolder is copied and is not part of the zip file. If you install on this box, the datafolder is used with the new installation')
    addDir('[B][COLOR yellow]Update an Addon from this Addon[/COLOR][/B]','url',2501,'1','1','1','Select an addon and update the design from this addon. \n\nStart by making a backup of the addon')
    addDir('Change your Direct Channels m3u file','url',2510,'1','1','1','Select a Direct Channels m3u file or switch back to the default\n\nThen start an update of EPG')
    errorInBasicInfo, descr, link = isMyAccountOK()
    if errorInBasicInfo :
        addDir('[B][COLOR red]My Account[/COLOR][/B]','url',8,'','','','Change your user name/email address and password or restore previous configurations. \n\nWatch your basic account information\nOpen Channels in Web\nOpen Channels in VLC')
    else:
        addDir('[B][COLOR lightgreen]My Account[/COLOR][/B]','url',8,'','','','Change your user name/email address and password or restore previous configurations. \n\nWatch your basic account information\nOpen Channels in Web\nOpen Channels in VLC')
    ###addDir('My Account','url',8,'','','','Change your user name/email address and password or restore previous configurations. \n\nWatch your basic account information\nOpen Channels in Web\nOpen Channels in VLC')
    addDir('Update EPG now','url',115,'','','','Start to Update EPG now')
    addDir('Backup Database and Settings','url',2059,'','','','Backup recordings_adc.db and settings.xml')
    addDir('Delete Database','url',116,'','','','Clear the Database. \nStop all planned recordings and start a new EPG import')
    addDir('Delete File Database','url',1029,'','','','Clear the File Database. \nStart a new scan')
    addDir('Restore from Database','url',104,'','','','Restore Database, Restore recursive recordings or EPG Data')
    addDir('Delete Old EPG programs','url',111,'','','','Delete 7 days old programs and 2 days old channels')
    addDir('Delete All EPG programs','url',110,'','','','Delete All EPG Programs. If to many programs have changed - update full afterwards')
    addDir('Activate or Deactivate Channels from Supplier','url',2550,'','','','Select channels from Supplier to Activate or deactivate. If you start with deleting all channels, next update will only include active channels. New channels from the supplier will be marked active')
    addDir('Delete All Channels','url',108,'','','','Delete All Channels. If user have changed - update full afterwards')
    log('Maintenance2')
    if definition.ADDONgetSetting('enable_record')=='true':
        addDir('Delete All Planned Recordings except Recursive','url',109,'','','','Delete All Planned Programs except Recursive. If recursive have made too many recordings - Stop all recordings and clear planned recording parts of database')
        addDir('Delete All Planned Recordings','url',1090,'','','','Delete All Planned Programs. If recursive have made too many recordings - Stop all recordings and clear planned recording parts of database. You can restore Recursive Recordings from Backup')
        addDir('Clear Record Marker','url',260,'','','','If status shows recording while no recording active - clear the flag')
        addDir('Clean Up after Timezone or Daylight Saving Time shift','url',8000,'','','','1. Delete New EPG programs\n2. Delete All Planned Recordings except Recursive\n3. Update EPG')
    addDir('Clean Up in Recordings Folder','url',261,'','','','Delete all failed recordings\nFiles without a video file with same filename\nThis function is run automatically every 4 hours')
    log('Maintenance3')
    ftvntvini = (os.path.join(datapath,'ftv'+ADDONrefer) + '.ini').replace('/','/ ').replace('\\','\\ ')
    addDir('Make new INI file','url',112,'','','','Create INI file \n' + ftvntvini +' \nfor use with external TV Guides')
    addDir('Force INI and Reschedule','url',4000,'','','','Create INI file \n' + ftvntvini +' \nfor use with external TV Guides, Test for overlapping  EPG programs, Update Planned recordings and Reschedule')
    addDir('Recursive Search Channels','url',26,'','','','All channels used for recursive search')
    addDir('Hidden Channels','url',20,'','','','All channels you have hidden from the other views - Here you can un-hide them')
    ###addDir('Calculate free space on drives','url',1050,'','','','Calculate freespace on local drives')
    addDir('Add Addons to switch to','url',1039,'','','','Find Addons and add them to the krogsbell switch file')
    addDir('Del Addons to switch to','url',1038,'','','','Find Addons and remove them from the krogsbell switch file')
    addDir('Del .set files','url',3010,'','','','Delete all .set files and Clear Recording Paths. They may then be restored from the .ini file')
    log('Maintenance4')
    setView('movies', 'main-view')
    log('Maintenance5')

def BasicUserInfoDesc():
    ROQTVusername = IPTVuser
    descr = 'Username= %s' % ROQTVusername
    d= {'user_info': {'username': '[B][COLOR red]Not Found[/B][/COLOR]', 'password': '', 'auth': 1, 'status': '', 'exp_date': '', 'is_trial': '0', 'created_at': '1694642400', 'max_connections': '0', 'active_cons': '0', 'allowed_output_formats': [0, 1, 2]}}
    d1 = d['user_info']
    expiredate = ''
    remainingdaysS = ''
    is_trial = ''
    allowedformats = ''
    if ROQTVusername.lower() != 'none':
        try:    
            if definition.ADDONgetSetting('panel_api') == 'true':
                link = definition.getBASEURL() + '/panel_api.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass')
                log('errorZ link= %r' % link)
                data = utils.readlink(link,os.path.join(datapath,ADDONid) + '.info',module)
                d = json.loads(data)
                log('errorZ d= %r' % d)
                d1 = d['user_info']
                log('errorZ d1= %r' % d1)
                
                formats = d1['allowed_output_formats']
                allowedformats = AllowedFormats(formats)
                if d1['is_trial'] == '1':
                    is_trial = '\nThis is a trial '
                else:
                    is_trial = ''
                forever = definition.ADDONgetSetting('forever')
                expiredate = recordings.parseDate(d1['exp_date'])
                log('errorZ expiredate= %r' % expiredate)
                if forever == 'true':
                    expiredate =  'none'
                    remainingdaysS = ''
                    log('errorZ 2 expiredate= %r' % expiredate)
                else:
                    now = datetime.now()
                    remainingdays = (expiredate-recordings.parseDate(now)).days
                    if remainingdays < 7:
                        remainingdaysS = '\n[B][COLOR red]Remaining days= '+ str(remainingdays)  + '[/COLOR][/B]'
                    else:
                        remainingdaysS = '\n[B][COLOR green]Remaining days= '+ str(remainingdays)  + '[/COLOR][/B]'
                    expiredate = expiredate.strftime('%Y-%m-%d %H:%M')
                    log('errorZ 3 expiredate= %r' % expiredate)
                definition.ADDONresetSetting('expiredate',expiredate)
        except Exception as e:
            log('errorZ 4309 Except: %r' % e)
            pass
            utils.notification('Error in getting '+ ADDONid + " 4-info! Use or don't use VPN or check your User ID\n" + repr(e))
            ###d1 = ['username':'none','status':'none','max_connections':0,'active_cons':0]
            
            descr = 'Error in getting User Info: %r' % e    
    if definition.ADDONgetSetting('enable_record')=='true':
        PRC = getPlannedRecordingCounts()
    else:
        PRC = ''
    VPNdesc = utils.isVPN()     
    enable_record = definition.ADDONgetSetting('enable_record')
    if enable_record == 'true' :
        recordenabledesc = '[COLOR red]Recording Enabled[/COLOR]'
    else:
        recordenabledesc = '[COLOR grey]Recording Disabled[/COLOR]'
    if locking.isAnymarkLocked():
        recordingdesc = '[COLOR red]Rec[/COLOR]'
    else:
        recordingdesc = 'Not Recording'
    if locking.isScanLocked('EPG_update'):
        updatedesc = 'EPG updating'
    else:
        updatedesc = 'No EPG updating'
    
    if definition.ADDONgetSetting('RecursiveSearch') == 'true':
        recursivedesc = 'Recursive Search'
    else:
        recursivedesc = 'No Recursive Search'

    if locking.isAnyScanLocked():
        scanningdesc = '[COLOR blue]Scanning[/COLOR]'
    else:
        scanningdesc = 'No Scanning'
    """
    try:   ### 2018-10-26
        RytecAddon = xbmcaddon.Addon(id='service.rytecepg.downloader')
        RytecAction = RytecAddon.getSetting('active')
    except Exception as e:
        log('err 2240 Except: %r' % e)
        pass
        RytecAction = ''
        log('Get Rytec Action - ERROR: %r' % e)
    """
    my_referral_init = definition.ADDONgetSetting('my_referral_init')
    if ROQTVusername.lower() != 'none':
        descr = '[B][COLOR orangered]'+ADDONrefer +' / '+my_referral_init+'[/COLOR][/B]\n'+'Username= %s \nStatus= %s \nExpire= %s%s%s\nMax connections= %s \nConnections in use= %s \nAllowed formats= %s\nPlanned/Recursive Recordings= %s\nEPG Update= %s\nVPN= %s\nRecording: %s\nRecording= %s\nScanning= %s\nRecursive Search= %s' %(d1['username'],d1['status'],expiredate,remainingdaysS,is_trial,d1['max_connections'],d1['active_cons'],allowedformats,PRC,updatedesc,VPNdesc,recordenabledesc,recordingdesc,scanningdesc,recursivedesc)
    else:
        descr = '[B][COLOR orangered]'+ADDONrefer +' / '+my_referral_init+'[/COLOR][/B]\nPlanned/Recursive Recordings= %s\nEPG Update= %s\nVPN= %s\nRecording:addon %s\nRecording= %s\nScanning= %s\nRecursive Search= %s' %(PRC,updatedesc,VPNdesc,recordenabledesc,recordingdesc,scanningdesc,recursivedesc)
    log('errorZ 1 Basic Info len= %r\n%r' % (len(descr),descr))

    
    return descr
    
   
def STATUS():
    GoHome('Status')
    descr = BasicUserInfoDesc()
    addDir('Basic Info','url',12,'','','',descr)
    setView('movies', 'main-view') 
    """
    ROQTVusername = IPTVuser
    if ROQTVusername.lower() != 'none':
        try:
            descr = 'Username= %s' % ROQTVusername
            if definition.ADDONgetSetting('panel_api') == 'true':
                link = definition.getBASEURL() + '/panel_api.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass')
                log('errorZ link= %r' % link)
                data = utils.readlink(link,os.path.join(datapath,ADDONid) + '.info',module)
                ¤¤¤
                file = urlopen(link)
                data = file.read()
                log('err link=%r\ndata= %r' % (link,data))
                file.close()
                
                ChannelFile = os.path.join(datapath,ADDONid) + '.info'
                with open(ChannelFile,'wb') as output:
                    output.write(data)
                ###name= Status,url= url,mode= 11,iconimage= ,cat= ,date= ,description= {u'username': u'XXX', u'status': u'Active', u'is_trial': u'0', u'created_at': u'1493734688', u'auth': 1, u'allowed_output_formats': [u'm3u8', u'ts', u'rtmp'], u'exp_date': u'1499005088', u'active_cons': u'0', u'password': u'XXXX', u'max_connections': u'1'},startDate= ,endDate= ,recordname= )
                ¤¤¤
                d = json.loads(data)
                d1 = d['user_info']
                formats = d1['allowed_output_formats']
                allowedformats = AllowedFormats(formats)
                ¤¤¤
                allowedformats = '['
                for f in formats:
                    allowedformats += f + ', '
                allowedformats += ']'
                allowedformats = allowedformats.replace(', ]',']')
                ¤¤¤
                if d1['is_trial'] == '1':
                    is_trial = '\nThis is a trial '
                else:
                    is_trial = ''
                
                forever = definition.ADDONgetSetting('forever')
                expiredate = recordings.parseDate(d1['exp_date'])
                log('errorZ expiredate= %r' % expiredate)
                if forever == 'true':
                    expiredate =  'none'
                    remainingdaysS = ''
                    log('errorZ 2 expiredate= %r' % expiredate)
                else:
                    now = datetime.now()
                    ###remainingdays = (recordings.parseDate(d1['exp_date'])-recordings.parseDate(now)).days
                    remainingdays = (expiredate-recordings.parseDate(now)).days
                    if remainingdays < 7:
                        remainingdaysS = '\n[B][COLOR red]Remaining days= '+ str(remainingdays)  + '[/COLOR][/B]'
                    else:
                        remainingdaysS = '\n[B][COLOR green]Remaining days= '+ str(remainingdays)  + '[/COLOR][/B]'
                    expiredate = expiredate.strftime('%Y-%m-%d %H:%M')
                    log('errorZ 3 expiredate= %r' % expiredate)
                definition.ADDONresetSetting('expiredate',expiredate)
                
                
                ###descr = 'Username= %r \nStatus= %r \nExpire= %r%r%r\nMax connections= %r \nConnections in use= %r \nAllowed formats= %r' %(d1['username'],d1['status'],recordings.parseDate(d1['exp_date']).strftime('%Y-%m-%d %H:%M'),remainingdaysS,is_trial,d1['max_connections'],d1['active_cons'],allowedformats)
                ###descr = 'Username= %r \nStatus= %r \nExpire= %r%r%r\nMax connections= %r \nConnections in use= %r \nAllowed formats= %r' %(d1['username'],d1['status'],expiredate.strftime('%Y-%m-%d %H:%M'),remainingdaysS,is_trial,d1['max_connections'],d1['active_cons'],allowedformats)
                descr = 'Username= %s \nStatus= %s \nExpire= %s%s%s\nMax connections= %s \nConnections in use= %s \nAllowed formats= %s' %(d1['username'],d1['status'],expiredate,remainingdaysS,is_trial,d1['max_connections'],d1['active_cons'],allowedformats)
                
            log('errorZ 1 Basic Info len= %r\n%r' % (len(descr),descr))
            addDir('Basic Info','url',12,'','','',descr)
        except Exception as e:
            log('errorZ 3710 Exception: %r' % e)
            pass
            utils.notification('Error in getting '+ ADDONid + " 4-info! Use or don't use VPN or check your User ID\n" + repr(e))
            addDir('Basic Info','url',0,'1','','','Error in getting '+ ADDONid + ' 4-info! Check your User ID\n' + repr(e))
            d = []
        ###<<<   AddAtom('all',d)
        ###addDir('Test Info','url',12,'','','',d['server_info']['port'])
        ¤¤¤
        for field in d:
            ###log('params= %s' % repr(field))
            ###log('type(field)= %s' % repr(type(field)))
            if type(d[field]) == dict:
                da = d[field]
                for f in d[field]:
                    if type(d[field][f]) == dict:
                    for f in d[field]:
                        addDir(field +'/' +f,'url',12,'','','',repr(d[field][f]))
            else:
                
                addDir(field,'url',12,'','','',d[field])
        ¤¤¤     
    setView('movies', 'main-view') 
    """

def AddAtom(level,data):
    if not type(data) == str:
        for field in data:
            if type(data[field]) == dict:
                AddAtom(level +'/'+ repr(field),data[field])
            else:
                if not field == 'movie' and not field == 'live':
                    ###log('addDir(level/field= %r,data[field]= %r)' % (level +'/'+ field,data[field]))
                    addDirBasic(level +'/'+ field,'url',12,'','','',data[field])

def AllowedFormats(formats):
    allowedformats = '['
    knownformats = ['m3u8','ts','rtmp']
    log('error AllowedFormats knownformats= %r' % knownformats)
    for f in formats :      ### 2023-07-22
        log('error AllowedFormats f= %r, type(f)= %r' % (f,type(f)))
        if type(f) == int and f < len(knownformats):
            log('error AllowedFormats type(f) == int and f < len(knownformats)= True')
            allowedformats += knownformats[f] + ', ' 
        else:
            log('error AllowedFormats type(f) == int and f < len(knownformats)= False')
            allowedformats += str(f) + ', '
    allowedformats += ']'
    allowedformats = allowedformats.replace(', ]',']')
    log('error AllowedFormats allowedformats= %r' % allowedformats)
    return allowedformats
    
def STATUSsub(data):
    GoHome('Status')
    ###log('STATUSsub data= %s' % repr(data))
    ###d = json.loads(data)
    for field in data:
        if len(field) > 2:
            ###log('STATUSsub params= %s' % repr(field))
            ###log('type(field)= %s' % repr(type(field)))
            if type(field) == dict:
                addDir(repr(field),'url',12,'','','',repr(data))
            else:
                addDir(field,'url',0,'','','',repr(data))
    setView('movies', 'main-view') 

def SUBS():
    GoHome('SUBS')
    net.set_cookies(cookie_jar)
    link = net.http_GET(definition.getBASEURL() +'/?' + recordings.referral() + 'c=1&a=18', headers={'User-Agent' : UA}).content
    data = json.loads(link)
    body = data['body']
    for field in body:
        title= field['title']
        platform= field['platforms'].encode("utf-8")
        status= field['status'].encode("utf-8")
        time_left= field['time_left'].encode("utf-8")
        name='%s-%s-(%s)[COLOR yellow] %s[/COLOR] '%(title,platform,time_left,status)
        addDir_STOP(name,'url','','','','')
    setView('movies', 'main-view') 
    
def ORDERS():
    GoHome('ORDERS')
    net.set_cookies(cookie_jar)
    link = net.http_GET(definition.getBASEURL() +'/?' + recordings.referral() + 'c=1&a=19', headers={'User-Agent' : UA}).content.encode('ascii', 'ignore')
    log('err link= %r' % link)
    data = json.loads(link)
    body = data['body']
    for field in body:
        id= field['id'].encode("utf-8")
        price_total= field['price_total'].encode("utf-8")
        created= field['created'].encode("utf-8")
        status= field['status'].encode("utf-8")
        updated= field['updated'].encode("utf-8")
        name='%s-(%s)[COLOR yellow] %s-(%s)[/COLOR] '%(price_total, created, status, updated)
        addDir_STOP(name,'url','','','','')
    setView('movies', 'main-view') 

def Search(name):
    search_entered = ''
    ###search_entered = definition.ADDONgetSetting('searchepgvodcha')
    keyboard = xbmc.Keyboard(search_entered, '[COLOR lightgreen][B]Please Enter '+str(name)+'[/B][CR][COLOR grey][I]<ESC> or Cancel to clear. Not case sensitive search[/I][/COLOR]')
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_entered = keyboard.getText()
        if search_entered == None:
            return False 
        ###else:
        ###    definition.ADDONresetSetting('searchepgvodcha',search_entered)   ### 2018-02-15
    else:
        ###definition.ADDONresetSetting('searchepgvodcha','')
        return False
    return search_entered 
    """    
        keyboard = xbmc.Keyboard(search_entered, '[COLOR lightgreen][B]Please Enter '+str(name)+'[/B][CR][COLOR grey][I](<ESC> or Cancel to clear)[/I][/COLOR]')
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText()
            if search_entered == None:
                return False          
        return search_entered  
    """
    
def Numeric(name):
    dialog = xbmcgui.Dialog()
    keyboard=dialog.numeric(0, 'Please Enter '+str(name))
    return keyboard  

def TextTime(timeT,funk):
    log('err NumericTime(timeT= %r,funk= %r)' % (timeT,funk))
    dialog = xbmcgui.Dialog()
    ###keyboard=dialog.numeric(0, funk,timeT)
    keyboard = dialog.input(funk + ' - 25 seconds timeout',timeT, type=xbmcgui.INPUT_ALPHANUM, autoclose=25000)
    return keyboard

def NumericTime(timeT,funk):
    log('err NumericTime(timeT= %r,funk= %r)' % (timeT,funk))
    dialog = xbmcgui.Dialog()
    keyboard=dialog.numeric(2, funk,timeT)
    return keyboard

def ADD_FAV(cat):
    ### Ask for Fav Text with default 'True' and timeout
    conn = recordings.getConnection()
    c = conn.cursor()
    fav = recordings.getChannelFav(c,cat)
    c.close()
    if fav.lower() == 'false':
        favi = SearchFav('True')
    else:
        favi = SearchFav(fav)
    if favi != fav:
        log('ADD_FAV(cat= %r)= %r' % (cat, favi))
        recordings.addChannelFav(cat, favi)
        if definition.ADDONgetSetting('LastView') == 'FAVORITES':
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            xbmc.executebuiltin("Container.Refresh")
    return
    
def DEL_FAV(cat):
    recordings.delChannelFav(cat)
    return

def SET_HIDE(cat):
    recordings.setChannelHide(cat)
    return
    
def DEL_HIDE(cat):
    recordings.delChannelHide(cat)
    return

def SET_RECURSIVE(cat):
    recordings.setChannelRecursive(cat)
    return
    
def DEL_RECURSIVE(cat):
    recordings.delChannelRecursive(cat)
    return

def SELECT_TV_GUIDE_CHANNEL(name,url,iconimage,cat):
    try:
        log('error SELECT_TV_GUIDE_CHANNEL(\n name= %r,\n url= %r,\n iconimage= %r,\n cat= %r)' % (name,url,iconimage,cat))
        channel = updateepg.getEPGChannel(cat)
        name = channel[0]
        EPGchannel = channel[1]
        source = channel[2]
        #print Platform
        dialog = xbmcgui.Dialog()
        lockcause = 'change' ### Dummy command
        if type(EPGchannel) == str:
            if dialog.yesno(ADDONname, "[COLOR red]Change TV Guide Channel?[/COLOR]" +'\n'+ name + ' (' + cat + ') --> ' + EPGchannel + ' ('  + source + ')' +'\n'+ "What Do You Want To Do","[COLOR red]Change channel[/COLOR]","[COLOR green]Ignore[/COLOR]"):
                ### Ignore
                lockcause = 'ignore' ### Dummy command
            else:
                ### Stop recording and record new
                lockcause = 'change' ### Dummy command
        else:
            EPGchannel = ''
        #########################
        log( 'error SelectedChannel Channel= %r' % (name))
        if lockcause == 'change' :
            ###xbmcgui.Dialog().input(heading[, defaultt, type, option, autoclose])
            EPGchannelNEW = xbmcgui.Dialog().input('[B]'+ADDONname +" - [COLOR red]Change TV Guide Channel?[/COLOR][/B] - 25 seconds timeout\n" +name + ' (' + cat + ') --> ' + EPGchannel + ' ('  + source + ')', defaultt=EPGchannel, autoclose=25000)
            log('error EPGchannel= %r, EPGchannelNEW= %r' % (EPGchannel,EPGchannelNEW))
            if EPGchannel != EPGchannelNEW and EPGchannelNEW != '':
                log('error updateepg.setEPGChannel(\n cat= %r\n EPGchannelNEW.lower= %r)' % (cat,EPGchannelNEW.lower()))
                updateepg.setEPGChannel(cat,EPGchannelNEW.lower())
                utils.notification(name + ' (' + cat + ') --> ' + EPGchannelNEW)
            else:
                log('error cat= %r\n EPGchannel= %r)' % (cat,EPGchannel))
                mychannels = ['No EPG'] + findtvguidenotifications.MyChannels()
                SelectedChannel = xbmcgui.Dialog().select(name + ' (' + cat + ') --> ' + EPGchannel, mychannels)
                log('error SelectedChannelNo= %r' % (SelectedChannel))
                if SelectedChannel >= 0:
                    try:
                        log('error SelectedChannel= %r' % (mychannels[SelectedChannel]))
                        EPGchannelRaw = mychannels[SelectedChannel]
                        log('error EPGchannelRaw= %r' % EPGchannelRaw)
                        if '(' in EPGchannelRaw :
                            EPGchannel = EPGchannelRaw.split('(')[-1].split(' - ')[0].strip().lower()
                        else:
                            EPGchannel = EPGchannelRaw.split(' - ')[0].strip().lower()
                        log('error EPGchannel= 0 %r' % EPGchannel)
                        updateepg.setEPGChannel(cat,EPGchannel)
                        log('error EPGchannel= 1 %r' % EPGchannel)
                        utils.notification(name + ' (' + cat + ') --> ' + EPGchannel)
                        ###dialog = xbmcgui.Dialog()
                        ###dialog.ok('[B]' + ADDONrefer + '[/B]','[COLOR red]' +name + ' (' + cat + ') --> ' + EPGchannel+ '[/COLOR]')
                        result = name + ' (' + cat + ') --> ' + EPGchannel
                        utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] EPG change succeded ;-)\nResult= %r' % result )
                    except Exception as e:
                        log('error 3909 Except: %r' % e)
                        pass
                        log( 'SelectedChannel FAILED Channel= %r \nERROR= %r' % (SelectedChannel,e))
    except Exception as e:
        pass
        log('Error in SELECT_TV_GUIDE_CHANNEL\n' + repr(e))

def TVGUIDE(namech,cat):
    ### [recordings.getEPGPrograms(epg_channel_id), name-1, tv_archive-2, tv_archive_duration-3, epg_channel_id-4]
    GoHome('TV guide')
    now= datetime.today().replace(microsecond=0)
    show_list_item = 3    ### must add 3 to hit
    guide = updateepg.getEPG(cat)
    try:
        guideEPG = guide[0]
    except Exception as e:
        log('err 3924 Except: %r' % e)
        pass
        log('Error in getting TV Guide\n' + repr(e))
        return
    nameEPG = guide[1]
    tv_archive = guide[2]
    if type(tv_archive) != int:
        tv_archive = 0
    tv_archive_duration= guide[3]
    if type(tv_archive_duration) != int:
        tv_archive_duration = 0
    ###tv_archive_duration += 14   ### Test Add 14 days 2018-06-09
    epg_channel_id = guide[4]
    log('errYYYX epg_channel_id= %r, nameEPG= %r, tv_archive= %r, tv_archive_duration= %r'   % (epg_channel_id, nameEPG, tv_archive, tv_archive_duration))
    if tv_archive == 1:
        ###addDir('[COLOR red][B]Search limit reached ('+str(searchcountmax)+' in '+usedtime+' seconds)[/B][/COLOR]' ,'url',5011,'','0','0','Limit your search!\n\nClick to change limit[CR][CR]Searched for: '+searchText+'[CR][CR]'+searchPath+sortmethod,'0','0','')
        archiveoffsetminutes = definition.ADDONgetSetting('archiveoffsetminutes')
        if archiveoffsetminutes != '0':
            show_list_item += 1
            log('err show_list_item= %r' % show_list_item)
            log('err 1 Days in archive %r' % tv_archive_duration)
            addDir('Days in archive %r\n[COLOR grey][I]Offset %r minutes[/I][/COLOR]' % (tv_archive_duration,archiveoffsetminutes),'url',5012,'1','0','0','Days in archive %r\n\nOffset %r minutes\n\nClick on line to modify offset\nUse a leading zero to set a negative offset\nRefresh to see and use the new offset' % (tv_archive_duration,archiveoffsetminutes),'0','0','0')
        else:
            show_list_item += 1
            log('err show_list_item= %r' % show_list_item)
            log('err 2 Days in archive %r' % tv_archive_duration)
            addDir('Days in archive %r' % tv_archive_duration,'url',5012,'1','0','0','Days in archive %r\n\nOffset %r minutes\n\nClick on line to modify offset\nUse a leading zero to set a negative offset\nRefresh to see and use the new offset' % (tv_archive_duration,archiveoffsetminutes),'0','0','0')
    if namech == 'None' or namech == '':
        namech = nameEPG
        if namech == 'None' or namech == '':
            if cat != '#':
                namech = recordings.ChannelName(cat)
            else:
                namech = ''
    log('errYYYZ namech= %r' % ( namech))
    newiconurl = recordings.getIcon(namech,cat)
    for index in range(0, len(guideEPG)):
        ch = []
        for i in range(0, len(guideEPG[index])):
            if guideEPG[index][i] == None:
                ch.append('')
            else:
                ch.append(guideEPG[index][i])
        ###SELECT DISTINCT title-0, description-1, source-2, start_date-3, end_date-4 FROM programs WHERE channel=?
        ###def addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
        ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
        ###addDir(ch[0],'url',200,'',cat,'',ch[1] + ' \nEPG from: \n' + ch[2],ch[3],ch[4],ch[1])
        ###datetime.fromtimestamp
        
        try:
            ###log('start= %r, end= %r' % (ch[3], ch[4] ))
            ###startDate= datetime.fromtimestamp(float(ch[3]))
            startDate= ch[3]
            endDate= ch[4]
            log('err Getting startDate\n' + repr(startDate) + ' of type ' + repr(type(startDate)))
            log('err Getting endDate\n' + repr(endDate) + ' of type ' + repr(type(endDate)))
            if type(startDate) == int:
                startDate= datetime.fromtimestamp(float(ch[3]))
                endDate= datetime.fromtimestamp(float(ch[4]))
            else:
                startDate= ch[3]
                endDate= ch[4]
            ArchiveOffset = definition.ADDONgetSetting('archiveoffset')
            try:
                ArchiveOffset = int(ArchiveOffset)
            except Exception as e:
                log('error ArchiveOffset Except: %r' % e)
                pass
                ArchiveOffset = TimeZone
            log('error ArchiveOffset= %r' % ArchiveOffset)
            ###archiveoffsetminutes = utils.intADDONgetSetting('archiveoffsetminutes',0)
            archiveoffsetminutes = definition.ADDONgetSetting('archiveoffsetminutes')
            try:
                archiveoffsetminutes = int(archiveoffsetminutes)
            except Exception as e:
                log('error archiveoffsetminutes Except: %r' % e)
                pass
                archiveoffsetminutes = 0
            log('error ArchiveOffset= %r' % archiveoffsetminutes)
            startDateCU= startDate + timedelta(seconds = (ArchiveOffset - TimeZone)*3600 - 60*3 + archiveoffsetminutes*60)  ### USE UK TimeZone and start 3 minutes early  2018-06-08
        except Exception as e:
            log('err 4001 Except: %r' % e)
            pass
            startDate=''
            startDateCU=''
            endDate=''
            log('Error in getting dates\n' + repr(e))
        name= ch[0] ###.encode("utf-8")
        recordname= ch[0] ###.encode("utf-8")
        ### change \" to " - it comes from master.xml
        recordname = recordname.replace('\\"','"')
        name = name.replace('\\"','"')
        log('err name= %r' % name)
        log('err recordname= %r' % recordname)
        StartDateTime = ''
        Duration = ''
        try:
            StartDateTime = ' \nStart ' + startDate.strftime('%Y-%m-%d %H:%M')
            ###t = int(ch[4]) - int(ch[3])
            dura = (endDate - startDate)//60  ### 2021-06-21
            ###if dura > 300:
            log('err DurationArchive= %r, start= %r, end= %r' % (dura, startDate, endDate ))
            Duration = ' \nDuration [' + str(dura)[-5:] +']. \n'  ###2018-03-08
            #Duration = ' \nDuration ' + str(dura) + ' \n'
            ###Duration = ' \nDuration ' + str((dura)//60) + ' min \n\n'
            try:  ### When was EPG created?
                if 'EPG Created ' in ch[1]:
                    EPGtime = 'EPG Created ' + ch[1].split('EPG Created ')[1][0:19]+'\n'
            except Exception as e:
                log('err 4028 Except: %r' % e)
                pass
                EPGtime = ''
            description= (namech + ' (' +cat+'):'+StartDateTime+Duration +EPGtime+ '\n' + ch[1])   ###.encode("utf-8")  ### 2018-02-17
            ###log('Duration= %r' % Duration )
        except Exception as e:
            log('err 4033 Except: %r' % e)
            pass
            log('Error in getting duration\n' + repr(e))
            ###recordings.latin1_to_ascii_force (unicrap)
            description = (recordings.latin1_to_ascii_force(namech) + ' (' +recordings.latin1_to_ascii_force(cat)+'):' +StartDateTime+Duration+ recordings.latin1_to_ascii_force(ch[1]))
        log('err 0 Description= %r' % description)
        description = description.replace('video.nordic','video.***nordic').replace('[CR]n','[CR]').replace('.nn','.[CR][CR]').replace('.n','.[CR]').replace('. n','.[CR]').replace('!n','![CR]').replace('?n','?[CR]').replace('(n)','[CR]').replace('video.***nordic','video.###nordic')  ### 2018-12-07
        log('err 1 Description= %r' % description)
        if '[' in name:
            name = '[B]' + name.replace('[','\n[COLOR lemonchiffon][/B][I][',1) + '[/I]'
            name = name.split('\n')
            line1 = name[0]
            lenline1 = len(line1)
            line2 = name[1]
            lenline2 = len(line2)
            if lenline1 < lenline2:
                line1 = line1 + ' ' * (lenline2 - lenline1 - 16)
            name = line1 +'\n' + line2    ### +'.'+ str(lenline1)+'.'+ str(lenline2)
        else:
            name = '[B]' + name + '[/B]'
        try:
            archiveCU = now - timedelta(days = tv_archive_duration) - timedelta(hours = 1)  ### first hours entries may not be visible
            log('err archiveCU= %r' % archiveCU)
            if tv_archive == 1 and startDate < now and startDate > archiveCU:  ### startDate <-- endDate
                log('err ARC tv_archive == 1 and startDate < now and startDate > archiveCU')
                name='[COLOR salmon]%s[/COLOR]'%(name)
                time=startDate.strftime('Arc %d.%m %H:%M  ')
                log('err time= %r' % time)
                ###duration = str(int(repr(endDate - startDate).replace('datetime.timedelta(0, ','').split(')')[0].split(',')[0])//60 + 18) ### duration plus 15 min + 3 min ahead
                duration = str(int(repr(endDate - startDate).replace('datetime.timedelta(seconds=','').split(')')[0].split(',')[0])//60 + 18) ### duration plus 15 min + 3 min ahead  ### 2021-06-21
                log('err duration= %r, Start= %r, End= %r' % (duration, startDate, endDate))
                ###start    = startDateCU.strftime('%Y-%m-%d:%H-%M')
                start    = startDateCU.strftime('%Y-%m-%d:%H:%M:%S')
                
                ROQTVusername = IPTVuser
                ###if ROQTVusername.lower() != 'none':
                ### /streaming/timeshift.php?username=8dnebn9ii5&password=7jbq9bx6nt&stream=493978&duration=53&start=2024-08-16:00-22 HTTP/1.1 
                ###url = definition.getBASEURL() + '/streaming/timeshift.php?username='+IPTVuser+'&password='+definition.ADDONgetSetting('pass')+'&stream='+cat+'&duration='+duration+'&start='+start
                ### /timeshift/8dnebn9ii5/7jbq9bx6nt/35/2024-08-16:00:30:00/493978.m3u8
                url = definition.getBASEURL() + '/timeshift/'+IPTVuser+'/'+definition.ADDONgetSetting('pass')+'/'+duration+'/'+start+'/'+cat+'.m3u8'
                log('err timeshift 4217 url= %r' % url)
                show_list_item += 1
                addDir(time+name,url,2020,newiconurl,cat,startDate,description,startDate,endDate,recordname) ### Watch or record Archive
            elif tv_archive != 1 and endDate < now :  ### Show History (default 2 hours)
                log('err HIS tv_archive != 1 and endDate < now :  ### Show History (default 2 hours)')
                try:
                    hourstoshow = utils.intADDONgetSetting('showhistoryintvguide',2)
                    log('err H start= %r, end= %r' % (startDate, endDate))
                    name='[COLOR cyan]%s[/COLOR]'%(name)
                    time=startDate.strftime('His %d.%m %H:%M  ')
                    if endDate > now - timedelta(hours = hourstoshow):
                        show_list_item += 1
                        addDir(time+name,'url',200,newiconurl,cat,startDate,description,startDate,endDate,recordname)
                except Exception as e:
                    log('err 4082 Except: %r' % e)
                    pass
                    log('Error ourstoshow Except= %r' % e)
            elif startDate <= now and now <= endDate:
                log('err NOW startDate <= now and now <= endDate')
                name='[COLOR yellow]%s[/COLOR]'%(name)
                time=startDate.strftime('Now %d.%m %H:%M  ')
                url = recordings.urlFromCat(cat)
                show_list_item += 1
                log('err show_list_item= %r' % show_list_item)
                addDir(time+name,url,200,newiconurl,cat,startDate,description,startDate,endDate,recordname)
            elif startDate > now and endDate > now:
                log('err REC startDate > now and endDate > now')
                ### Find programs that are recording
                recprograms = recordings.isRecording(cat,name,startDate,endDate)
                log('err Is program: %r beeing recorded? SD= %r ED= %r ActivePrograms: %r' %(name,startDate,endDate,recprograms))
                if recprograms:
                    name='[COLOR red]%s[/COLOR]'%(name)
                else:
                    name='[COLOR lightgreen]%s[/COLOR]'%(name)
                
                time=startDate.strftime('Rec %d.%m %H:%M  ')
                ###show_list_item += 1  ### stop at first rec
                log('err show_list_item= %r' % show_list_item)
                addDir(time+name,'url',2001,newiconurl,cat,startDate.strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20'),description,startDate.strftime('%Y-%m-%d %H:%M:%S'),endDate.strftime('%Y-%m-%d %H:%M:%S'),recordname) ### Record
            else:
                log('err NO SHOW start= %r, end= %r, now= %r, archiveCU= %r\n  startDate > archiveCU: %r' % (startDate, endDate, now, archiveCU, startDate > archiveCU))
        except Exception as e:
            log('err 4107 Except: %r' % e)
            pass
            log('Error in setting menu\n' + repr(e))
    log('err show_list_item= %r' % show_list_item)
    definition.ADDONresetSetting('show_list_item',str(show_list_item))
    setView('movies', 'tvguide-view')

def CutOffDateTime():
    PlannedRecordingsHistoryHours = utils.intADDONgetSetting('showhistoryinplannedrecordings',24)
    cutoffdate = (datetime.today().replace(microsecond=0) - timedelta(hours = PlannedRecordingsHistoryHours)).strftime('%Y-%m-%d %H:%M:%S')
    return cutoffdate
    
def RecordingsPlanned():
    GoHome('Planned Recordings')
    offset=0
    c = recordings.getConnection().cursor()
    #c.execute("SELECT * FROM recordings_adc WHERE end=?", [endDate])
    # SELECT * FROM COMPANY WHERE AGE >= 25 OR SALARY >= 65000;
    ## 3.4.6cutoffdate = (datetime.datetime.today() - datetime.timedelta(days = 1)).strftime('%Y-%m-%d')
    
    cutoffdate = CutOffDateTime()
    # 5) Retrieve all IDs of entries between that are older than 1 day and 12 hrs
    #c.execute("SELECT {idf} FROM {tn} WHERE DATE('now') - {dc} >= 1 AND DATE('now') - {tc} >= 12".\
    #    format(idf=id_field, tn=table_name, dc=date_col, tc=time_col))
    #all_1day12hrs_entries = c.fetchall()
    #c.execute("SELECT * FROM recordings_adc WHERE (DATETIME('now') - end) = 0 ")
    #all_1day12hrs_entries = c.fetchall()
    #print 'default.py: cutoffdate= %s' % repr(cutoffdate)
    #print 'default.py: SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE start > %s' % cutoffdate
    #c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE start > %s  AND name NOT CONTAINS 'Recursive' " % cutoffdate )
    try:
        c.execute("SELECT * FROM recordings_adc WHERE start>? AND name NOT LIKE '%Recursive:%'", [cutoffdate])   ### 2018-09-11 use startdate against cutoff date
        #c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc")
    except Exception as e:
        log('err 4147 Except: %r' % e)
        pass
        log( 'c.execute(SELECT * FROM recordings_adc WHERE start>? AND name NOT LIKE Recursive:, [cutoffdate]) failed! \nERROR= %r' % e)
    recordingsC = c.fetchall()
    #Sort Planned Recordings by start date!
    recordingsD = sorted(recordingsC, key=itemgetter(2))
    # print 'default.py: RecordingsPlanned recordingsD= %s' % repr(recordingsD)
    addDir('[COLOR white][B]Planned Recordings (' + str(len(recordingsD)) + ')[/B][/COLOR]','url',104,'','','','Counter\n\nClick to restore from database','','','')
    for index in range(0, len(recordingsD)):
        if not 'Recursive:' in recordingsD[index][1]:
            showRecording(recordingsD,index)
    # Put recursive recordings last
    try:
        c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE '%Recursive:%'")
    except Exception as e:
        log('err 4161 Except: %r' % e)
        pass
        log('c.execute(SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE Recursive:) failed! \nERROR= %r' % e)
    recordingsC = c.fetchall()
    #recordingsD = sorted(recordingsC, key=itemgetter(1))  # Sort by name
    #recordingsE = sorted(recordingsD, key=itemgetter(6))  # Sort by channel
    recordingsE = sorted(recordingsC, key=itemgetter(1)) # sort by last named
    # print 'default.py: RecordingsPlanned recordingsE= %s' % repr(recordingsE)
    addDir('[COLOR white][B]Recursive Recordings (' + str(len(recordingsE)) + ')[/B][/COLOR]\n[COLOR gray][I]Channel Name [Channel ID] epg: epg.id[/I][/COLOR]','url',104,'','','','Counter\n\nClick to restore from database','','','')
    recursiveChannels = recordings.RecursiveChannels()
    log('err recursiveChannels= %r' % recursiveChannels)
    for index in range(0, len(recordingsE)):
        if 'Recursive:' in recordingsE[index][1]:
            showRecording(recordingsE,index,recursiveChannels)
    setView('movies', 'recordingsplanned-view')
    c.close()

def RecordingsPlannedDebug():
    import recordings
    import utils
    GoHome('Planned Recordings (Debug)')
    offset=0
    c = recordings.getConnection().cursor()
    c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc")
    recordingsC = c.fetchall()
    from operator import itemgetter
    
    #Sort Planned Recordings by start date!
    recordingsD = sorted(recordingsC, key=itemgetter(2))
    #RecordingsPlannedDebugIcons(recordingsD)
    for index in range(0, len(recordingsD)):
        if not 'Recursive:' in recordingsD[index][1]:
            showRecordingDebug(recordingsD,index)
    # Put recursive recordings last
    recordingsD = sorted(recordingsC, key=itemgetter(1))  # Sort by channel
    recordingsE = sorted(recordingsD, key=itemgetter(6))  # Sort by channel
    # recordingsE = sorted(recordingsC, key=itemgetter(2), reverse=True) # sort by last modified
    for index in range(0, len(recordingsE)):
        if 'Recursive:' in recordingsE[index][1]:
            showRecordingDebug(recordingsE,index)
    setView('movies', 'recordingsplanned-view')
    c.close()
    
def RecordingsPlannedDebugIcons(recordingsD):
    for index in range(0, 10):
        showRecordingDebug(recordingsD,str(index))
        #print 'showRecordingDebug index= %s' % str(index)
    setView('movies', 'recordingsplanned-view')
    
def concurrentrecordings(startDate):
    try:
        ccc= recordings.getRecordingsConcurrent(startDate,startDate)
        ###log( 'concurrentrecordings(startDate= %r)= %r' % (startDate,ccc))
        ccc= len(ccc)
        if ccc > 1:
            ccc= '[COLOR red]' + str(ccc) + '[/COLOR] '
        elif ccc == 1:
            ccc= '[COLOR lightgreen]' + str(ccc) + '[/COLOR] '
        else:
            ccc= ''
        ###log( 'len(concurrentrecordings(startDate= %r))= %r' % (startDate,ccc))
    except Exception as e:
        log('err 4230 Except: %r' % e)
        pass
        log( 'concurrentrecordings(startDate= %r) FAILED ERROR: %r' % (startDate,e))
        ccc= ''
    return ccc

def showRecording(recordingsC,index,recursiveChannels=''):
        ###GoHome('Show Recordings')
        now = recordings.parseDate(datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
        ignoreRecording = False
    #for index in range(0, len(recordingsC)): 
        cat         = recordingsC[index][0]
        if cat and 'http' in cat: 
            cat = '#'
        #name        = recordings.latin1_to_ascii (recordingsC[index][1].encode("utf-8"))
        name        = recordingsC[index][1]
        log('4269 errXXX name= %r' % name)
        startDate   = recordings.parseDate(recordingsC[index][2])
        endDate     = recordings.parseDate(recordingsC[index][3])
        alarmname   = recordingsC[index][4]
        description = recordingsC[index][5]
        log('0 Description= %r' % description)
        description = description.replace('video.nordic','video.###nordic').replace('[CR]n','[CR]').replace('.nn','.[CR][CR]').replace('.n','.[CR]').replace('. n','.[CR]').replace('!n','![CR]').replace('?n','?[CR]').replace('(n)','[CR]').replace('video.###nordic','video.nordic')  ### 2018-12-07
        log('1 Description= %r' % description)
        if cat != '#':
            playchannel = recordingsC[index][6] 
            log('4278 errXXX playchannel= %r, cat= %r' % (playchannel, cat))
            """
            try:
                playchannel = recordings.ChannelName(cat)
                log('4281 errXXX playchannel= %r, cat= %r' % (playchannel, cat))
            except Exception as e:
                log('err 4257 Except: %r' % e)
                pass
            """
        else:
            playchannel = ''
        """
        if cat == playchannel:
            playchannel = recordings.EPG_ChannelFromCat(cat)
            log('4291 errXXX playchannel= %r, cat= %r' % (playchannel, cat))
            if playchannel == '':
                playchannel = '[B][COLOR red]No EPG[/COLOR][/B]'  
        """
        log('4294 errXXX playchannel= %r, cat= %r' % (playchannel, cat))
        try:
            #timeShowStart= str(startDate).split(':')[0] + ":" + str(startDate).split(':')[1]
            timeShowStart=str(startDate).split(' ')[0] + ' (' + (str(startDate).split(' ')[1]).split(':')[0] + ":" + (str(startDate).split(' ')[1]).split(':')[1] 
        except Exception as e:
            log('err 4264 Except: %r' % e)
            pass
            #print 'default.py: ERROR in startDate= %s' % repr(startDate)
            ignoreRecording = True
            startDate = now
            timeShowStart = now
        try:
            timeShowEnd=(str(endDate).split(' ')[1]).split(';')[0].split(':')[0] + ":" + (str(endDate).split(' ')[1]).split(':')[1] +')'
        except Exception as e:
            log('err 4272 Except: %r' % e)
            pass
            #print 'default.py: ERROR in endDate= %s' % repr(endDate)
            ignoreRecording = True
            endDate = now
            timeShowEnd = now
        nowY = now.strftime('%Y-')
        nowYM = now.strftime('%Y-%m-')
        nowYMD = now.strftime('%Y-%m-%d ')
        time='[COLOR yellow]%s - %s [/COLOR]'%(timeShowStart.replace(nowYMD,'').replace(nowYM,'').replace(nowY,''),timeShowEnd)
        timeOld='%s - %s '%(timeShowStart.replace(nowYMD,'').replace(nowYM,'').replace(nowY,''),timeShowEnd)
        if cat and cat != '#':
            ###displaychannelnumber = playchannel + ' (' +cat+ '):\n'
            ###displaychannelnumberold = playchannel + ' (' +cat+ '):'
            if name == cat:
                displaychannelnumber = name + ' (' - '):\n'   ### 2022-04-15
                displaychannelnumberold = name + ' (' - '):'
            else:
                displaychannelnumber = name + ' (' +cat+ '):\n'   ### 2022-04-15
                displaychannelnumberold = name + ' (' +cat+ '):'
        else:
            displaychannelnumber = ''
            displaychannelnumberold = ''
        log('2 description= %r' % description)
        log('2 displaychannelnumber= %r' % displaychannelnumber)
        log('2 displaychannelnumberold= %r' % displaychannelnumberold)
        displaydescription = description.replace(displaychannelnumber,'').replace(displaychannelnumberold,'').lstrip()
        recursiveChannel = False
        if ('Recursive:' in name):
            recursiveChannel = True
            timeRecursive = '%s - '%(timeShowStart)
            #nameRecursive = str(name.replace(':','xxx',1))
            #nameRecursive = str(playchannel) + ' - ' + str(nameRecursive.split('xxx')[1])
            nameRecursive = str(name.replace('Recursive:','',1))
            ###nameRecursive = nameRecursive + '¤' +  str(playchannel)
            ###nameRecursive = nameRecursive + '¤' +  str(cat)   ### 2022-04-15
            nameRecursive = nameRecursive + '¤' +  recordings.ChannelName(cat)   ### 2022-04-16
            if len(displaydescription) > 0:
                descriptionstrip =  (str(displaydescription).replace('[COLOR green]Example description of channel to record: [/COLOR]','')).lstrip()
                description = '[COLOR green]Example description of channel to record: [/COLOR]\n' + descriptionstrip
        recordname=name
        log('err recordname= %r' % recordname)
        """
        if recursiveChannel and not cat in recursiveChannels:
            if '[COLOR orange]' in name:
                name = name.replace('[COLOR orange]','[COLOR lightblue]').replace('[/COLOR]',' [I]Channel not recursive[/I][/COLOR]')
            else:
                name = '[COLOR lightblue]' + name + ' [I]Channel not recursive[/I][/COLOR]'
            log('err channel not in Recursive channels: cat= %r, name= %r' % (cat,name))
        """
        if recursiveChannel and not cat in recursiveChannels:
            if '[COLOR orange]' in nameRecursive:
                nameRecursive = nameRecursive.replace('[COLOR orange]','[COLOR blue]').replace('[/COLOR]','[/COLOR]  [COLOR blue]Channel not recursive[/COLOR]')
            else:
                nameRecursive = '[COLOR blue]' + nameRecursive + ' [COLOR blue]Channel not recursive[/COLOR]'
            log('err channel not in Recursive channels: cat= %r, nameRecursive= %r' % (cat,nameRecursive))
        namecolor = ''
        namecolortest = '*'
        log('err 0 name= %r' % name)
        if '[COLOR' in name:
            namecolortest = name.split('[/COLOR]')
            if len(namecolortest) == 1 or len(namecolortest) == 3 or len(namecolortest) == 5:
                namecolor = '[/COLOR]'
        if ' [' in name:
            name = name.replace(' [',namecolor + '[/B]                                                   \n[I][COLOR lemonchiffon][',1)
        log('err 1 name= %r' % name)
        if '\n[I]' in name:
            name = '[B]' + name +'[/COLOR][/I]'
        else:
            name = '[B]' + name + '[/B]'   ### 2021-04-18
        log('err 2 name= %r' % name)
        now = recordings.parseDate(datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
        startDate = recordings.parseDate(startDate)
        endDate = recordings.parseDate(endDate)
        #print 'endDateTest =  endDate= %s + datetime.timedelta(days = 1)' % repr(endDate)
        PlannedRecordingsHistoryHours = utils.intADDONgetSetting('showhistoryinplannedrecordings',24)
        endDateTest =  endDate + timedelta(hours = PlannedRecordingsHistoryHours) # Number of previous days to show in view
        newiconurl= recordings.getIcon(name,cat)
        log('err newiconurl= %r' % newiconurl)
        newurl    = recordings.urlFromCat(cat)
        log('err newurl= %r' % newurl)
        displaydescription = displaychannelnumber + description.replace(displaychannelnumber,'').replace(displaychannelnumberold,'').lstrip().replace('AAabBB',' ').replace('aAabBb','?').replace('BBabAA','=').replace('xXx',' ').replace('###',',').replace('AaAaA','=').replace(';;',',')  ### 2020-01-31            
        if (not ignoreRecording and ((recordings.parseDate(endDateTest) > recordings.parseDate(datetime.today().strftime('%Y-%m-%d %H:%M:%S'))) or recursiveChannel)):
            if (startDate < now and now < endDate) and (not recursiveChannel):
                addDir(time+'[COLOR red]'+name+'[/COLOR]',newurl,200,newiconurl,cat,startDate,displaydescription,startDate,endDate,recordname)
            else:
                if (endDate < now) or (recursiveChannel):
                    if (recursiveChannel):
                        nameRecursive = nameRecursive.split('¤')
                        ###epgchan = recordings.EPG_ChannelFromCname(playchannel)
                        ###log('4396 errXX epgchan= %r, playchannel= %r' % (epgchan, playchannel))
                        ###epgchan = recordings.EPG_ChannelFromCname(cat)
                        epgchan = recordings.EPG_ChannelFromCname(nameRecursive[1])    ### 2022-04-16
                        log('4400 errXX epgchan= %r, playchannel= %r' % (epgchan, nameRecursive[1]))
                        if epgchan == '':
                            epgchan = '[B][COLOR red]No EPG[/COLOR][/B]'
                        catdisplay = str(cat)   ### 2022-04-16
                        if catdisplay == nameRecursive[1]:
                            catdisplay = ' - '
                        if recordings.directprograms(cat) == '':
                            log('err 1 nameRecursive= %r' % nameRecursive)
                            addDir(nameRecursive[0] + '\n[COLOR gray][I]' + nameRecursive[1] + " [" + catdisplay + "] epg: "+epgchan+"[/I][/COLOR]",newurl,200,newiconurl,cat,startDate,displaydescription,startDate,endDate,recordname)
                        else:
                            log('err 2 nameRecursive= %r' % nameRecursive)
                            addDir('[COLOR lightgreen]' + nameRecursive[0] + '\n[COLOR gray][I]' + nameRecursive[1] + " [" + catdisplay + "] epg: "+epgchan+"[/I][/COLOR]",newurl,200,newiconurl,cat,startDate,displaydescription,startDate,endDate,recordname)
                    else:
                        log('err 3 name= %r' % name)
                        addDir(timeOld+name,newurl,200,newiconurl,cat,startDate,displaydescription,startDate,endDate,recordname)
                else:
                    if '[COLOR orange]' in name:  ### 2018-10-05
                        ccc = ''
                    elif '[COLOR blue]' in name:
                        ccc = ''
                    else:
                        ccc = concurrentrecordings(startDate) ###+ ' ' ###+ str(len(name)) + ' '   ### 2018-09-24
                    if recordings.directprograms(cat) == '':
                        log('err 4 name= %r' % name)
                        addDir(time+ccc+name,newurl,200,newiconurl,cat,startDate,displaydescription,startDate,endDate,recordname)
                    else:
                        log('err 6 name= %r' % name)
                        addDir(time+ccc +'[COLOR lightgreen]' + name + '[/COLOR]', 'url', 200, newiconurl, cat, startDate, displaydescription, startDate, endDate, recordname)
            #setView('movies', 'recordingsplanned-view')

def showRecordingDebug(recordingsC,index):
        import recordings
        ###GoHome('Show Recordings (Debug)')
        now = recordings.parseDate(datetime.today().strftime('%Y-%m-%d %H:%M:%S'))

    #for index in range(0, len(recordingsC)): 
        cat         = recordingsC[index][0]
        name        = recordingsC[index][1].encode("utf-8")
        startDate   = recordingsC[index][2]
        endDate     = recordingsC[index][3]
        alarmname   = recordingsC[index][4]
        description = recordingsC[index][5]
        playchannel = recordingsC[index][6]
        #cat            = str(index)
        #name        = str(index)
        #startDate   = now
        #endDate     = now
        #alarmname   = str(index)
        #description = str(index)
        #playchannel = str(index)       #description = '\nind=%s \ncat=%s \nnam=%s \nsta=%s \nend=%s \nala=%s \npla=%s' %(repr(index),repr(cat),repr(name),repr(startDate),repr(endDate),repr(alarmname),repr(playchannel))
        #print str(index)
        #print imageUrl+cat+'.png'
        #newiconurl= recordings.imageUrlicon(imageUrl,cat,'.png')
        newiconurl= recordings.getIcon(name,cat)
        try:
            #print repr(OPEN_URL(imageUrl+cat+'.png')) 
            addDir('[COLOR red]'+name+'[/COLOR]','url',200,newiconurl,cat,startDate,playchannel + ': '  + repr(startDate) + ' - ' + repr(startDate) + ' # ' + description,startDate,endDate,name)
        except Exception as e:
            log('err 4409 Except: %r' % e)
            pass
        #setView('movies', 'recordingsplanned-view')

def playmediaORG(media_url):
    try:
        import traceback
        import  CustomPlayer
        player = CustomPlayer.MyXBMCPlayer()
        ###listitem = xbmcgui.ListItem( label = str(name), iconImage = "DefaultVideo.png", thumbnailImage = xbmc.getInfoImage( "ListItem.Thumb" ), path=media_url )
        listitem=xbmcgui.ListItem(name,label = str(name), path=media_url )
        listitem.setArt({ 'icon': "DefaultFolder.png", 'thumb' : xbmc.getInfoImage( "ListItem.Thumb" ) })
        player.play( media_url,listitem)
        try:   ### Experimental 2023-11-08 - not working
            log('4702 error Player.setAudioDelay .250')
            xbmc.executebuiltin("Player.setAudioDelay(0.250)")
        except Exception as e:
            pass
            log('error 4706  Player.setAudioDelay Except: %r' % e)
        sleep(1000)
        while player.is_active:
            sleep(200)
    except Exception as e:
        log('err 4425 Except: %r' % e)
        traceback.print_exc()
    return ''
    
def playmedia(media_url):
    log('error playmedia(media_url= %r)'% (media_url))
    if definition.ADDONgetSetting('fullscreen') == 'true':
        fullscreen = xbmc.getCondVisibility('System.IsFullscreen')
        if not fullscreen:
            xbmc.executebuiltin("Action(togglefullscreen)")
    utils.setDefaultVideoLevel()
    ###xbmc.executebuiltin("SetVolume(100,showvolumebar)")
    try:   ### Experimental 2023-11-08
        log('4718 error Player.setAudioDelay .250')
        xbmc.executebuiltin("Player.setAudioDelay(0.250)")
    except Exception as e:
        pass
        log('error 4720 Player.setAudioDelay Except: %r' % e)
    
    try:
        import traceback
        import  CustomPlayer
        player = CustomPlayer.MyXBMCPlayer()
        ###listitem = xbmcgui.ListItem( label = str(name), iconImage = "DefaultVideo.png", thumbnailImage = xbmc.getInfoImage( "ListItem.Thumb" ), path=media_url )
        listitem=xbmcgui.ListItem(name,label = str(name), path=media_url )
        listitem.setArt({ 'icon': "DefaultFolder.png", 'thumb' : xbmc.getInfoImage( "ListItem.Thumb" ) })
        log('error player.play( media_url= %r,\nlistitem= %r)' % ( media_url,listitem))
        ###listitem.setInfo('video', { 'duration': 120*60 })  ### Default Video 2 hours  2019-01-09
        player.play( media_url,listitem)
        try:   ### Experimental 2023-11-08 - not working
            log('4741 error Player.setAudioDelay .250')
            Player.setAudioDelay(0.250)
        except Exception as e:
            pass
            log('error 4745 Player.setAudioDelay Except: %r' % e)
        sleep(1000)
        i = 0
        ###while player.is_active and i < 30:
        while player.is_active:
            ###time.sleep(1)
            sleep(1000)
            i += 1
            ###log('player.play( media_url= %r, i= %r)' % ( media_url,i))
    except Exception as e:
        log('err 4448 Except: %r' % e)
        pass
        log('traceback.print_exc()' )
        traceback.print_exc()
    ###return ''
    
def RECORD_CATCHUP(name,url,iconimage,cat,description): 
    ###log('RECORD_CATCHUP url= ' + url)
    log('error RECORD_CATCHUP (name= %r \nurl= %r \niconimage= %r \ncat= %r \ndescription= %r )' % (name,url,iconimage,cat,description))
    ### url= 'http://e900x.com:8000/streaming/timeshift.php?username=xxx&password=yyy&stream=UNL967&duration=73&start=2019-05-09:19-37' 
    
    if 'UNL' == cat[:3]:
        url += '&'
        cat = param(url,'stream')
        duration = param(url,'duration')
        startDate = param(url,'start')
        ### 2017-05-21:16-00
        try:
            time_tuple = time.strptime(startDate, "%Y-%m-%d:%H-%M")
            startDateTS = int(time.mktime(time_tuple))
        except Exception as e:
            pass
            log('err 4547 Except: %r' % e)
            nowTS = int(time.mktime(datetime.now().timetuple()))
            startDateTS = nowTS
        ### Get url: '/channels/get-record/' + chId + '/' + evtStart + '/' + evtDuration
        ### https://www.unlim.tv:443/channels/get-record/949/1557407400/6000
        ###url = 'https://www.unlim.tv:443/channels/get-record/'+cat+'/'+str(startDateTS)+'/'+duration
        ###URI='plugin://plugin.video.unlimtv/?url=url#startdate=' + str(startDateTS) +'#duration='+ duration + '&mode=2100&cat=' + cat[3:] + '#startdate=' + str(startDateTS) +'#duration='+ duration + '&source='+ADDONid
        URIpart = 'recordfromunlimcat='+cat+'recordfromunlimtitle='+name+'recordfromunlimstartDate='+startDate+'recordfromunlimduration='+duration+'recordfromunlimdescription='+description
        log('err URIpart= %r' % URIpart)
        URI='plugin://plugin.video.unlimtv/?mode=2100&cat='+cat[3:]+'&url=plugin://'+ADDONid+'/&uri='+utils.base64b64encode(URIpart)
        
        log('err 0 Get uri from unlimtv: URI= %r' % URI)
        maxSleep = 500
        try:
            log('err 1 Get uri from unlimtv: URI= %r' % URI)
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            xbmc.executebuiltin('RunPlugin(%s)' % URI) 
            sleep(maxSleep)
        except Exception as e:
            log('err 4482 Except: %r' % e)
            pass
            log('Recording from UNL FAILED ERROR: %r' % e)
    else:
        log('error RECORD_CATCHUP(name= %r,url= %r,iconimage= %r,cat= %r,description= %r)' % (name,url,iconimage,cat,description))
        startD = recordings.parseDate(datetime.now())
        endD = startD

        recordingsActive = []
        recordingsActiveAll = recordings.getRecordingsActive(startD,endD)
        log('recordingsActiveAll= %r' % recordingsActiveAll)
        for x in recordingsActiveAll:
            log('x= %s' % repr(x))
            if not '[COLOR orange]' in x and not '[COLOR violet]' in x :
                log('recordingsActive= %s' % repr(recordingsActive))
                recordingsActive.append(x)
                log('recordingsActive= %s' % repr(recordingsActive))
        if (recordingsActive != []) or locking.isAnyRecordLocked():
            utils.notification('OVERLAPPING Recordings Warning: %s' % str(recordingsActive))
            #if (repr(recordingsActive) != "[]"):
            lockcause = repr(locking.RecordsLocked())
            #else:
            #   lockcause = repr(recordingsActive)
            dialog = xbmcgui.Dialog()
            if dialog.yesno(ADDONname, "[COLOR red]Stop recording?[/COLOR]" +'\n'+ repr(recordingsActive) +'\n'+ "What Do You Want To Do","[COLOR red]Stop recording[/COLOR]","[COLOR green]Ignore[/COLOR]"):
                ### Ignore
                lockcause = 'Ignore' ### Dummy command
            else:
                ### Stop recording and record new
                ###Recordffmpeg(name, url, '', '', description.replace(' ','AAabBB').replace('?','aAabBb').replace('=','BBabAA').replace(',','###').replace('&','AaAaA').replace('\n','NlNlNl'), auth, sourceApp)
                ###Recordffmpegarc(name, url, '', '', utils.base64b64encode(description), auth, sourceApp)
                Recordffmpegarc(name, url, '', '', utils.base64b64encode(description), auth, 'Record from Archive Anyhow')
        else:
            ###Recordffmpeg(name, url, '', '', description.replace(' ','AAabBB').replace('?','aAabBb').replace('=','BBabAA').replace(',','###').replace('&','AaAaA').replace('\n','NlNlNl'), auth, sourceApp)
            ###Recordffmpegarc(name, url, '', '', utils.base64b64encode(description), auth, sourceApp)
            Recordffmpegarc(name, url, '', '', utils.base64b64encode(description), auth, 'Record from Archive')
        
def PLAY_CATCHUP(name,url,iconimage,cat,description):    ### Watch Archive 2020
    ###http://roq-tv.net:25461/streaming/timeshift.php?username=XXX&password=XXXX&stream=276&duration=120&start=2017-05-21:16-00
    ###duration = endDate - startDate  ### in minutes
    ###start    = startDate.strftime('%Y-%m-%d:%H-%M')
    ###url = 'http://roq-tv.net:25461/streaming/timeshift.php?username='+IPTVuser+'&password='+definition.ADDONgetSetting('password')+'&stream='+cat+'&duration='+duration+'&start='+start
    log('err 5188 PLAY_CATCHUP 2020 (name= %r \nurl= %r \niconimage= %r \ncat= %r \ndescription= %r )' % (name,url,iconimage,cat,description))
    ### PLAY_STREAM(name,url,iconimage,cat)
    startD = recordings.parseDate(datetime.now())
    endD = startD + timedelta(hours = 2)

    recordingsActive = []
    recordingsActiveAll = recordings.getRecordingsActive(startD,startD)  ### 2019-01-08 test at start
    log('recordingsActiveAll= %r' % recordingsActiveAll)
    for x in recordingsActiveAll:
        log('x= %s' % repr(x))
        if not '[COLOR orange]' in x and not '[COLOR violet]' in x :
            log('recordingsActive= %s' % repr(recordingsActive))
            recordingsActive.append(x)
            log('recordingsActive= %s' % repr(recordingsActive))
    if (recordingsActive != []) or locking.isAnyRecordLocked():
        utils.notification('OVERLAPPING Recordings Warning: %s' % str(recordingsActive))
        #if (repr(recordingsActive) != "[]"):
        lockcause = repr(locking.RecordsLocked())
        #else:
        #   lockcause = repr(recordingsActive)
        dialog = xbmcgui.Dialog()
        if dialog.yesno(ADDONname, "[COLOR red]Stop recording?[/COLOR]" +'\n'+  repr(recordingsActive) +'\n'+ "What Do You Want To Do","[COLOR red]Stop recording[/COLOR]","[COLOR green]Record this later[/COLOR]"):
            ### Code to record/download
            playchannel = recordings.ChannelName(cat)
            RECORD_CATCHUP(name+' ('+playchannel+')',url,iconimage,cat,description)
            return
    """
    #print 'default.py: locking.recordUnlockAll()'
    locking.recordUnlockAll()
    # Test locking and unlock
    testX = 'TEST'
    locking.recordLock(testX)
    if locking.isRecordLocked(testX):
        locking.recordUnlock(testX)
    else:
        recordingLock = os.path.join(progpath,'rtmpdump', 'recordingLock') +  testX + '.txt'
        utils.notification('Record Locking fails at %s' % str(recordingLock))
    """
    try:
        _name=name.split(' -')[0].replace('[/COLOR]','').replace('[COLOR salmon]','')
        playername=name.split('- ')[1].replace('[/COLOR]','').replace('[COLOR salmon]','')
    except Exception as e:
        log('err 4562 Except: %r' % e)
        _name=name.replace('[/COLOR]','')
        playername=name.replace('[/COLOR]','')
    dialog = xbmcgui.Dialog()
    ###if dialog.yesno(ADDONname, "[COLOR red]Record from archive?[/COLOR]", playername, "What Do You Want To Do","[COLOR red]Record[/COLOR]","[COLOR green]Watch[/COLOR]"):
    if dialog.yesno(ADDONname, "[COLOR red]Record from archive?[/COLOR]" +'\n'+ name +'\n'+  "What Do You Want To Do","[COLOR red]Record[/COLOR]","[COLOR green]Watch[/COLOR]"):
        log('err playmedia(url= %r)' % url)
        if 'UNL' == cat[:3]:
            log('err UNL in cat')
            url += '&'
            cat = param(url,'stream')
            try:
                duration = param(url,'duration')
                duration = str(int(duration)*60)  ###2020-10-05
            except Exception as e:
                pass
                log('err 4657 Except: %r' % e)
                duration = '7200'   ### 2h = 120 x 60 = 7200
            startDate = param(url,'start')
            ### 2017-05-21:16-00
            try:
                time_tuple = time.strptime(startDate, "%Y-%m-%d:%H-%M")
                startDateTS = int(time.mktime(time_tuple))
            except Exception as e:
                pass
                log('err 4666 Except: %r' % e)
                nowTS = int(time.mktime(datetime.now().timetuple()))
                startDateTS = nowTS
            ### Get url: '/channels/get-record/' + chId + '/' + evtStart + '/' + evtDuration
            ### https://www.unlim.tv:443/channels/get-record/949/1557407400/6000
            ###url = 'https://www.unlim.tv:443/channels/get-record/'+cat+'/'+str(startDateTS)+'/'+duration
            ###URI='plugin://plugin.video.unlimtv/?url=url#startdate=' + str(startDateTS) +'#duration='+ duration + '&mode=2100&cat=' + cat[3:] + '#startdate=' + str(startDateTS) +'#duration='+ duration + '&source='+ADDONid
            URIpart = 'recordfromunlimcat='+cat+'recordfromunlimtitle='+name+'recordfromunlimstartDate='+startDate+'recordfromunlimduration='+duration+'recordfromunlimdescription='+description.replace(',',';;')
            log('err URIpart= %r' % URIpart)
            URI='plugin://plugin.video.unlimtv/?mode=2101&cat='+cat[3:]+'&url=plugin://'+ADDONid+'/&uri='+utils.base64b64encode(URIpart)  ### Play Archive???
            
            log('err 0 Get uri from unlimtv: URI= %r' % URI)
            maxSleep = 500
            try:
                log('err 1 Get uri from unlimtv: URI= %r' % URI)
                xbmc.executebuiltin('Dialog.Close(busydialog)')
                xbmc.executebuiltin('RunPlugin(%s)' % URI) 
                sleep(maxSleep)
            except Exception as e:
                log('err 4594 Except: %r' % e)
                pass
                log('Recording from UNL FAILED ERROR: %r' % e)
        else:
            log('err playmedia(url) %r' % url)
            """
            playcmd='plugin://' + ADDONid + '/?url=url&mode=2222&name=%s&cat=%s'% (name,cat)
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            xbmc.executebuiltin('PlayMedia(' + playcmd + ')')
            #PLAY_STREAM(name,url,iconimage,cat)
            try:
                xbmc.executebuiltin('Dialog.Close(busydialog)')
                xbmc.executebuiltin('RunAddon(' + recordname + ')')  ### Return
            except Exception as e:
                log('err 9144 Exception: %r' % e)
                pass
                log('Return to caling addon failed ERROR: %r' % e)
            """
            ###PLAY_STREAM(name,url,iconimage,cat)
            PlayingCatchup = 'true'
            definition.ADDONresetSetting('PlayingCatchup',PlayingCatchup)
            playingOK = playurl(url)
            if playingOK == True:
               dialog.ok('[B]' + ADDONrefer + '[/B]','[COLOR red] PLAYING VLC [/COLOR]')
            else:
                dialog.ok('[B]' + ADDONrefer + '[/B]','[COLOR red]Not Playing: %r \nurl= %r[/COLOR]' % (playingOK,url))
            ###playmedia(url)   ###2025-04-03
            
    else:
        ### Code to record/download
        playchannel = recordings.ChannelName(cat)
        RECORD_CATCHUP(name+' ('+playchannel+')',url,iconimage,cat,description)
        ###RECORD_CATCHUP(name,url,iconimage,cat,description)

def FreeLine(cat):
    concurrentlines = 1
    usedlines       = 0
    
    ROQTVusername = IPTVuser
    if ROQTVusername.lower() != 'none' and definition.ADDONgetSetting('panel_api') == 'true':
        try:
            link = definition.getBASEURL() + '/panel_api.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass')
            log('err link= %r' % link)
            data = utils.readlink(link,os.path.join(datapath,ADDONid) + '.info',module)
            """
            file = urlopen(link)
            data = file.read()
            log('err link=%r\ndata= %r' % (link,data))
            file.close()
            
            ChannelFile = os.path.join(datapath,ADDONid) + '.info'
            with open(ChannelFile,'wb') as output:
                output.write(data)
            ###name= Status,url= url,mode= 11,iconimage= ,cat= ,date= ,description= {u'username': u'XXX', u'status': u'Active', u'is_trial': u'0', u'created_at': u'1493734688', u'auth': 1, u'allowed_output_formats': [u'm3u8', u'ts', u'rtmp'], u'exp_date': u'1499005088', u'active_cons': u'0', u'password': u'XXXX', u'max_connections': u'1'},startDate= ,endDate= ,recordname= )
            """
            d = json.loads(data)
            d1 = d['user_info']
            concurrentlines = int(d1['max_connections'])
            usedlines       = int(d1['active_cons'])
        except Exception as e:
            log('err 4630 Except: %r' % e)
            pass
            log('FreeLine(cat= %r) Error %r' % (cat,e))
            concurrentlines = 1
            usedlines       = 0
    return concurrentlines - usedlines
        
def PLAY_STREAM(name,url,iconimage,cat):
    log('5309 error PLAY_STREAM(name= %r,url= %r,iconimage= %r,cat= %r)' % (name,url,iconimage,cat))
    url = utils.removedoubleslash(url)
    log('5311 error PLAY_STREAM(url= %r)' % url)
    """
2019-05-07 11:29:13 default.py: PLAY_STREAM(name= 'TV2 Charlie DK (A)',url= 'plugin.video.unlimtv',iconimage= 'TV2_Charlie.png',cat= 'UNL967')
2019-05-07 11:29:13 recordings.py: directprograms(cat= 'UNL967') channelname= 'TV2 Charlie DK', last 4= 'e DK'
2019-05-07 11:29:13 default.py: PLAY_STREAM(playchannel= 'TV2 Charlie DK (A) (UNL967)',recorddrdirectly= '')
2019-05-07 11:29:15 default.py: PLAY_STREAM(cat= 'UNL967',freeline= 1)

        URI='plugin://plugin.video.unlimtv/?url=url&mode=210&source='+ADDONid+'&cat=967' 
        definition.ADDONresetSetting('recordfromunlim','967') 
        definition.ADDONresetSetting('recordfromunlimtitle','Titel på optagelsen')
        definition.ADDONresetSetting('recordfromunlimduration','3600') 
        definition.ADDONresetSetting('recordfromunlimdescription','Her er så beskrivelsen af optagelsen') 
        log('Get uri from unlimtv: URI= %r' % URI)
        tries    = 0
        maxTries = 10
        maxSleep = 500
        try:
            log(repr(URI))
            xbmc.executebuiltin('RunPlugin(%s)' % URI) 
            sleep(maxSleep)
        except Exception as e:
            pass 
    """
    ### Set volumen to 100% and full screen  2021-07-16
    if definition.ADDONgetSetting('fullscreen') == 'true':
        fullscreen = xbmc.getCondVisibility('System.IsFullscreen')
        if not fullscreen:
            xbmc.executebuiltin("Action(togglefullscreen)")
    utils.setDefaultVideoLevel()
    ###xbmc.executebuiltin("SetVolume(100,showvolumebar)")
    
    
    log('5339 err PLAY_STREAM(name= %r,url= %r,iconimage= %r,cat= %r)' % (name,url,iconimage,cat))
    if cat == '':
        cat=recordings.catFromUrl(url)
    if url != None and 'plugin.video' in url:
        URI = '?mode=200&cat=' + cat[3:] + '&source=' ### + ADDONid  ### NO source = play
        cmd = 'RunAddon(%s,%s)' % (url, URI)
        
        log('5346 err PLAY_STREAM UNL cmd= %s' % cmd)
        
        utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] Play with unlimtv started!')
        log('5349 err after notificationsend')
        ###xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin(cmd)  # Active
        log('5352 err after cmd= %s' % cmd)
        utils.notificationsend('[COLOR lightgreen][B]¤' + ADDONname + '¤[/B][/COLOR] Play with unlimtv started!')
        
        """
        ###cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),00:00:00,silent)' % (nameAlarm, script, uri, name)
        
        ###RunScript(plugin.video.iptv-forever, 3010, ?cat=1&date&description=Delete%20all%20.set%20files.%20They%20will%20then%20be%20restored%20from%20the%20.ini%20file&endDate&iconimage&mode=3010&name=Del%20.set%20files&recordname&startDate&url=url
        URI='plugin://'+url+'/?mode=200&cat=' + cat[3:]
        try:  ### Get the set webport
            webport = utils.getGuiSetting('webserverport','8080')
        except Exception as e:
            pass
            webport = '8080'
        url = 'http://127.0.0.1:' + webport + '/jsonrpc?request={"jsonrpc":"2.0","method":"Addons.ExecuteAddon","params":{"wait":false,"addonid":"' +url + '","params":["cat=' + cat[3:] + '","mode=200","name=' + name + '","recordname='+ADDONid+'"]},"id":200}'
        log(repr(URI))
        log(repr(url))
        ###xbmc.executebuiltin('RunPlugin(%s)' % URI)
        try: 
          ###res = urlopen(utils.addHeader(url))   ### 2021-01-01 addHeader 
          log('err urlopen(utilsaddHeader(url))= %r\nurl= %r' % (urlopen(utils.addHeader(url)),url))
          import webbrowser
          webbrowser.open(url)   
        except Exception as e:
          pass
          log('Open URL in browser %r\nFAILED ERROR: %r' % (url,e))
        """
    else:
        recorddrdirectly=recordings.directprograms(cat)  ### Get direct links
        playchannel = name + ' (' + str(cat) + ')'
        log('5381 err PLAY_STREAM(playchannel= %r,recorddrdirectly= %r)' % (playchannel,recorddrdirectly))
        PlayDefaultStream = True
        if recorddrdirectly == '':
            freeline = FreeLine(cat)
            log('5385 err PLAY_STREAM(cat= %r,freeline= %r)' % (cat,freeline))
            if freeline < 1 :
                dialog = xbmcgui.Dialog()
                if dialog.yesno(ADDONname, "[COLOR red]No free lines[/COLOR]" +'\n'+  "What Do You Want To Do","[COLOR red]Use line anyhow[/COLOR]","[COLOR green]Ignore[/COLOR]"):
                    return
            log('5390 err PLAY_STREAM(cat= %r,freeline= %r)' % (cat,freeline))
            LastPlayedStreamname = definition.ADDONgetSetting('LastPlayedStreamname')
            LastPlayedStreamurl = definition.ADDONgetSetting('LastPlayedStreamurl')
            LastPlayedStreamurl = LastPlayedStreamurl[0:1024]
            LastPlayedStreamiconimage = definition.ADDONgetSetting('LastPlayedStreamiconimage')
            LastPlayedStreamcat = definition.ADDONgetSetting('LastPlayedStreamcat')
            if cat != '':
                definition.ADDONresetSetting('LastPlayedStreamname', name)
                definition.ADDONresetSetting('LastPlayedStreamurl', url)
                definition.ADDONresetSetting('LastPlayedStreamiconimage', iconimage)
                definition.ADDONresetSetting('LastPlayedStreamcat', cat)
                PlayDefaultStream = False
            else:
                name = LastPlayedStreamname
                url = LastPlayedStreamurl
                iconimage = LastPlayedStreamiconimage
            cat = LastPlayedStreamcat
            PlayDefaultStream = True
        startD = recordings.parseDate(datetime.now())
        endD = startD
        log('PlayDefaultStream= %s' % repr(PlayDefaultStream))
        if PlayDefaultStream:
            recordingsActive = []
        else:
            recordingsActive = []
            recordingsActiveAll = recordings.getRecordingsActive(startD,endD)
            log('recordingsActiveAll= %r' % (recordingsActiveAll))
            for x in recordingsActiveAll:
                log('x= %r' % (x))
                if not '[COLOR orange]' in x and not '[COLOR violet]' in x :
                    log('recordingsActive= %r' % (recordingsActive))
                    recordingsActive.append(x)
                    log('recordingsActive= %r' % (recordingsActive))
        if (recordingsActive != []) or locking.isAnyRecordLocked():
            utils.notification('OVERLAPPING Recordings Warning: %r' % (recordingsActive))
            lockcause = repr(locking.RecordsLocked())
            dialog = xbmcgui.Dialog()
            if dialog.yesno(ADDONname, "[COLOR red]Stop recording?[/COLOR]" +'\n'+ repr(recordingsActive) +'\n'+ "What Do You Want To Do","[COLOR red]Stop recording[/COLOR]","[COLOR green]Ignore[/COLOR]"):
                return
        else:
            log('play direct channel' + repr(name))
        try:
            _name=name.split(' -')[0].replace('[/COLOR]','').replace('[COLOR yellow]','')
            playername=name.split('- ')[1].replace('[/COLOR]','').replace('[COLOR yellow]','')
        except Exception as e:
            log('err 4753 Except: %r' % e)
            _name=name.replace('[/COLOR]','')
            playername=name.replace('[/COLOR]','')
        log('error TIMESHIFT Start TimeShift')
        timeshiftsetting = definition.ADDONgetSetting('timeshift')
        log('error TIMESHIFT timeshiftsetting= %r' % timeshiftsetting)
        if timeshiftsetting == '1':
            ask = xbmcgui.Dialog().yesno( ADDONname, name + '\n\nUse TimeShift?')
            #utils.notificationbox(repr(ask))
            if repr(ask) == '1':
                timeshiftsetting = '2'
            else:
                timeshiftsetting = '0'
        if timeshiftsetting == '2':
            ###utils.logdev('default.py','RecordTimeShift(timeshift, url= %s, playpath= %s, app= %s)' % (url, playpath,app))
        
            ###timeshiftfileold = timeshiftfile.replace('.ts','OLD.ts')
            ###utils.logdev('default.py','shutil.copyfile(timeshiftfile= %s,timeshiftfileold= %s)' % (timeshiftfile,timeshiftfileold))
            ###deleteFile(timeshiftfileold)
            ###try:
            ###    shutil.copyfile(timeshiftfile,timeshiftfileold)  ###
            ###utils.logdev('default.py','shutil.copyfile(timeshiftfile,timeshiftfileold) EXECUTED')
            ###except Exception as e:
            ###    pass
            """if os.path.isfile(timeshiftfile) == True: 
                deleteFile(timeshiftfile)
                count = 0
                test = os.path.isfile(timeshiftfile)
                while not test == True and count < 10:
                    ###time.sleep(1)
                    sleep(1000)
                    count += 1
                    test = os.path.isfile(timeshiftfile)
                    ###utils.logdev('default.py','RecordTimeShift test delete count= %s' % repr(count))
            """
            definition.ADDONresetSetting('timeshiftfile','')  ### Clear Filename
            count = 0
            timeshiftfile = definition.ADDONgetSetting('timeshiftfile')
            while timeshiftfile != '' and count < 10:
                sleep(100)
                timeshiftfile = definition.ADDONgetSetting('timeshiftfile')
                count += 1
            log('error RecordTimeShift 1 #%r file= %r' % (count,timeshiftfile))
            stoptimeshift()
            """
            subprpid = xbmcgui.Window(10000).getProperty(ADDONname + 'subprpid')
            subprcmd = xbmcgui.Window(10000).getProperty(ADDONname + 'subprcmd')
            utils.logdev('runCommand','OldTimeShift subprpid= %r, subprcmd= %r' % (subprpid, subprcmd))
            if subprpid != '' and definition.ADDONgetSetting('timeshiftbase') in subprcmd:
                utils.terminateSubpr(subprpid)
            try:
                xbmcgui.Window(10000).setProperty(ADDONname + 'subprpid', '')
                xbmcgui.Window(10000).setProperty(ADDONname + 'subprcmd', '')
            except Exception as e:
                pass
                utils.logdev('runCommand','Error reset \ncmd= %r\nError= %r' % (cmd,e))
            """
        
            RecordTimeShift(name, url, playpath, app, cat)  #### TimeShift record  ##########################
        
            try:
                timeshiftPID = xbmcgui.Window(10000).getProperty(ADDONname + 'subprpid')
                timeshiftCMD = xbmcgui.Window(10000).getProperty(ADDONname + 'subprcmd')
            except Exception as e:
                log('err 4815 Except: %r' % e)
                pass
                log('error runCommand Error get \ncmd= %r\nError= %r' % (cmd,e))
                timeshiftPID = '*'
                timeshiftCMD = '*'
        
            log('error runCommand 0 timeshiftPID= %r, timeshiftCMD= %r' % (timeshiftPID, timeshiftCMD))
            recordPath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_path')))
            timeshiftbase = definition.ADDONgetSetting('timeshiftbase')
            timeshiftfileexpected = recordPath + timeshiftbase + '_' + datetime.today().strftime('%Y-%m-%d_%H-%M') + '.ts'
        
            count = 0
            timeshiftfile = definition.ADDONgetSetting('timeshiftfile')
            while timeshiftfile == '' and count < 10:
                log('error RecordTimeShift 2 #%r file= %r' % (count,timeshiftfile))
                sleep(100)
                timeshiftfile = definition.ADDONgetSetting('timeshiftfile')
                count += 1
            log('error RecordTimeShift 3 #%r file= %r' % (count,timeshiftfile))
        
            try:
                timeshiftPID = xbmcgui.Window(10000).getProperty(ADDONname + 'subprpid')
                timeshiftCMD = xbmcgui.Window(10000).getProperty(ADDONname + 'subprcmd')
            except Exception as e:
                log('err 4838 Except: %r' % e)
                pass
                log('runCommand Error get \ncmd= %r\npid= %r' % (cmd,e))
                timeshiftPID = '*'
                timeshiftCMD = '*'
        
            log('error runCommand 1 timeshiftPID= %r, timeshiftCMD= %r' % (timeshiftPID, timeshiftCMD))
        
            title = name
            playername = title
            channel = cat
        
            timeshiftfile = definition.ADDONgetSetting('timeshiftfile')
            count = 0
            while timeshiftfile == '' and count < 10:
                log('RecordTimeShift 4 #%r file= %r' % (count,timeshiftfile))
                sleep(100)
                count += 1
                timeshiftfile = definition.ADDONgetSetting('timeshiftfile')
            log('RecordTimeShift 5 #%r file= %r' % (count,timeshiftfile))
        
            try:
                timeshiftPID = xbmcgui.Window(10000).getProperty(ADDONname + 'subprpid')
                timeshiftCMD = xbmcgui.Window(10000).getProperty(ADDONname + 'subprcmd')
            except Exception as e:
                log('err 4862 Except: %r' % e)
                pass
                log('runCommand Error get \ncmd= %r\npid= %r' % (cmd,e))
                timeshiftPID = '*'
                timeshiftCMD = '*'
        
            log('runCommand 2 timeshiftPID= %r, timeshiftCMD= %r' % (timeshiftPID, timeshiftCMD))
        
            count = 0
            timeshiftrunning = os.path.isfile(timeshiftfile)
            while timeshiftrunning == False and count < 10: 
                log('RecordTimeShift 6 #%r running= %r' % (count,timeshiftrunning))
                sleep(100)
                count += 1
                timeshiftrunning = os.path.isfile(timeshiftfile)
            if count == 10:   ### Set default filename
                timeshiftfile = timeshiftfileexpected
                log('RecordTimeShift 7 #%r running= %r file= %r' % (count,timeshiftrunning,timeshiftfile))
        
            try:
                timeshiftPID = xbmcgui.Window(10000).getProperty(ADDONname + 'subprpid')
                timeshiftCMD = xbmcgui.Window(10000).getProperty(ADDONname + 'subprcmd')
            except Exception as e:
                log('err 4884 Except: %r' % e)
                pass
                log('runCommand Error get \ncmd= %r\npid= %r' % (cmd,e))
                timeshiftPID = '*'
                timeshiftCMD = '*'
        
            log('runCommand 3 timeshiftPID= %r, timeshiftCMD= %r' % (timeshiftPID, timeshiftCMD))
        
            log('RecordTimeShift 8 #%r running= %r file= %r' % (count,timeshiftrunning,timeshiftfile))   
            #liz=xbmcgui.ListItem(title, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
            liz=xbmcgui.ListItem(playername)
            liz.setInfo( type="Video", infoLabels={ "Title": playername} )
            liz.setProperty("IsPlayable","true")
            ###log('timeshiftfile= %s' % (timeshiftfile))
            liz.setPath(timeshiftfile)
            ###log('RecordTimeShift 0++++ file= %s liz= %s' % (repr(timeshiftfile), repr(liz)))
            ##sleep(5000) ## Shows only theese 5 sec?
            log('runCommand 1 timeshiftPID= %r, timeshiftCMD= %r' % (timeshiftPID, timeshiftCMD))
            count = 0
            countmax = utils.intADDONgetSetting('timeshiftbuffer')
            while count < countmax: 
                sleep(1000)
                count += 1
                utils.notification('Record TimeShift filling buffer: #%s %s (%s)' % (str(count),recordname,channel))
            ###playmedia(timeshiftfile)
            ###xbmc.executebuiltin("PlayMedia("+timeshiftfile+")")
            log('runCommand 2 timeshiftPID= %r, timeshiftCMD= %r' % (timeshiftPID, timeshiftCMD))
            if definition.ADDONgetSetting('fullscreen') == 'true':
                fullscreen = xbmc.getCondVisibility('System.IsFullscreen')
                if not fullscreen:
                    xbmc.executebuiltin("Action(togglefullscreen)")
            utils.setDefaultVideoLevel()
            ###xbmc.executebuiltin("SetVolume(100,showvolumebar)")
            
            xbmcplugin.setResolvedUrl(Handle, True, liz) 
    
    
        if timeshiftsetting == '0':
            log('err timeshiftsetting=0 url= %r' % url)
            liz=xbmcgui.ListItem(name)
            liz.setArt({ 'icon': "DefaultVideo.png", 'thumb' : iconimage })
            liz.setInfo( type="Video", infoLabels={ "Title": name} )
            #liz.setInfo('video', { 'duration': 120*60 })  ### Default Video 2 hours 2019-01-09
            #lizVideoInfo = liz.getInfo('video')
            
            BASEURL = definition.getBASEURL()
            ###PLAYURL = definition.getPLAYURL()
            ### "server_info_https_port" 25463 "server_info_port" 8000 "server_info_protocol" http "server_info_url" e900x.com
            server_info_ip = definition.ADDONgetSetting('server_info_ip')
            if definition.ADDONgetSetting('server_info_protocol').lower() == 'http':
                PLAYURL = 'http://' + definition.ADDONgetSetting('server_info_url') + ':' + definition.ADDONgetSetting('server_info_port')
                PLAYURLIP = 'http://' + definition.ADDONgetSetting('server_info_ip') + ':' + definition.ADDONgetSetting('server_info_port')
            else:
                PLAYURL = 'https://' + definition.ADDONgetSetting('server_info_url') + ':' + definition.ADDONgetSetting('server_info_https_port')
                PLAYURLIP = 'https://' + definition.ADDONgetSetting('server_info_ip') + ':' + definition.ADDONgetSetting('server_info_https_port')
            log('err BASEURL= %r' % BASEURL)
            log('err PLAYURL= %r' % PLAYURL)
            log('err PLAYURLIP= %r' % PLAYURLIP)
            log('err url= %r' % url)  
            if server_info_ip != '':
                try:             
                    log('errserver_info_ip= %r' % server_info_ip)
                    url = url.split('/',3)
                    url = PLAYURLIP + '/' + url[3]
                except Exception as e:
                    log('err 4940 Except: %r' % e)
                    pass
                log('err url IP= %r' % url)
            elif PLAYURL != None and PLAYURL != '' and PLAYURL != 'http://:' and PLAYURL != 'https://:' and BASEURL.split(':')[1] in url:
                ### Ignore port from url if it is there
                try:             
                    url = url.split('/',3)
                    url = PLAYURL + '/' + url[3]
                except Exception as e:
                    log('err 4948 Except: %r' % e)
                    pass
                log('err url Play= %r' % url)
            log('5645 err PLAY_STREAM Path= %r' % url)
            ###url = url.replace('https://','http://')
            log( 'err 1 PLAY_STREAM Path= %r' % url)
            ###playurl(url)
            playedOK = playurl(url)
            log('err playurl playedOK= %r Path= %r' % (playedOK,url))
            
            ###liz.setProperty("IsPlayable","true")
            ###liz.setPath(url)
            ###listitem.setInfo('video', { 'genre': 'Comedy' })
            ###duration integer (245) - duration in seconds
            ###log('XBMC.PlayMedia("%s")' % url)
            ###xbmc.executebuiltin('XBMC.PlayMedia("%s")' % url)
            ###log( 'PLAY_STREAM Path= %r, HANDLE= %r' % (url,Handle))
            ###xbmcplugin.setResolvedUrl(Handle, True, liz) 

def stoptimeshift():
        subprpid = xbmcgui.Window(10000).getProperty(ADDONname + 'subprpid')
        subprcmd = xbmcgui.Window(10000).getProperty(ADDONname + 'subprcmd')
        log('OldTimeShift to stop and reset subprpid= %r, subprcmd= %r' % (subprpid, subprcmd))
        if subprpid != '' and definition.ADDONgetSetting('timeshiftbase') in subprcmd:
            utils.terminateSubpr(subprpid)
        try:
            xbmcgui.Window(10000).setProperty(ADDONname + 'subprpid', '')
            xbmcgui.Window(10000).setProperty(ADDONname + 'subprcmd', '')
        except Exception as e:
            log('err 5234 Except: %r' % e)
            pass
            log('OldTimeShift to stop and reset - Error \ncmd= %r\nError= %r' % (subprcmd,e))
def exit():
        xbmc.executebuiltin("Container.Update(path,replace)")
        ###xbmc.executebuiltin("ActivateWindow(Home)")
        xbmc.executebuiltin("ActivateWindow('1000')")

def EXIT():
    recordings.backupSetupxml()
    if locking.isAnyRecordLocked():
        locking.recordUnlockAll()
    if locking.isAnyScanLocked():
        locking.scanUnlockAll()
    if locking.isAnymarkLocked():
        locking.markUnlockAll()
    recordings.backupDataBase()
    ###recordings.stopAllRecordings()
        
def Record(recordname, uri, playpath,app):
    script   = os.path.join(progpath, 'recorduri.py')
    nameAlarm = ADDONid + '-Record-' + recordname
    try:
        if playpath == None:
            log('No playpath')
        else:
            uri = uri + ' playpath=' + playpath
            log('With playpath: uri= %s' % uri)
    except Exception as e:
        log('err 5261 Except: %r' % e)
        pass
    try:
        if app == None:
            log('No app')
        else:
            uri = uri + ' app=' + app
            log('With app: uri= %s' % uri)
    except Exception as e:
        log('err 5269 Except: %r' % e)
        pass
    cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),00:00:00,silent)' % (recordname.replace(',','####'), script, uri,recordname.replace(',','####'))
    log('default.py: cmd= %s' % cmd)
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin(cmd)  # Active
    
def Recordffmpeg(recordname, uri, playpath, app, description, auth, sourceApp): 
    try:
        timeintervalbetweenrecordings = utils.intADDONgetSetting('RecordingFromOtherAddonTimeInterval')*60 
    except Exception as e:
        log('err 5279 Except: %r' % e)
        pass
        timeintervalbetweenrecordings = 30 * 60  # Default 30 min
    log('err Recordffmpeg(recordname= %r, uri= %r, playpath= %r, app= %r, description= %r, auth= %r, sourceApp= %r, timeintervalbetweenrecordings= %r)' % (recordname, uri, playpath, app, description, auth, sourceApp,timeintervalbetweenrecordings))
    try:
        uridescription =  param(uri,'description')
        if description == None:
            description = uridescription
        elif uridescription != '' and uridescription not in description:  ### 2020-02-26
            description += uridescription
    except Exception as e:
        log('err 5289 Except: %r' % e)
        pass
        log('err Recordffmpeg(description= %r\nERROR: %r' % (description,e))
    try:
        OrgTitle =  param(uri,'OrgTitle')
        OrgTitle = utils.decode64(OrgTitle).replace('aBcDeF','&')     ### 2024-05-31
    except Exception as e:
        log('err 5295 Except: %r' % e)
        pass
        log('Recordffmpeg(OrgTitle)\nERROR: %r' % (e)) 
    if OrgTitle == '' :
        OrgTitle = recordname
    script   = os.path.join(progpath, 'recorduriffmpeg.py') 
    ### Conversion at script!
    ### uri= sys.argv[1].replace('AAabBB',' ').replace('aAabBb','?').replace('BBabAA','=').replace('xXx',' ').replace('###',',').replace('AaAaA','=').replace('NlNlNl','\n')
    nowTS = int(time.mktime(datetime.now().timetuple()))
    log('nowTS= %r - %r' % (nowTS,time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(nowTS))))
    try:
        RecordingFromOtherAddon = recordings.ts(definition.ADDONgetSetting('RecordingFromOtherAddon'))
    except Exception as e:
        log('err 5306 Except: %r' % e)
        pass
        RecordingFromOtherAddon = nowTS - timeintervalbetweenrecordings  ### One hour ago
        log('RecordingFromOtherAddon= %r\nError: %r' % (RecordingFromOtherAddon,e))
    log('RecordingFromOtherAddon= %r - %r' % (RecordingFromOtherAddon,time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(RecordingFromOtherAddon))))
    timesincelast = nowTS - RecordingFromOtherAddon
    if timesincelast > 0:
        log('timesincelast= %r - %r' % (timesincelast,time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(timesincelast))))
    else:
        log('timesincelast= %r' % (timesincelast))
    if timesincelast < timeintervalbetweenrecordings :
        RecordingFromOtherAddon += timeintervalbetweenrecordings
        ###definition.ADDONresetSetting('RecordingFromOtherAddon',str(RecordingFromOtherAddon))
    else:
        RecordingFromOtherAddon = nowTS
        ###definition.ADDONresetSetting('RecordingFromOtherAddon',str(nowTS))
    log('RecordingFromOtherAddon= %r - %r' % (RecordingFromOtherAddon,time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(RecordingFromOtherAddon))))
    #timestamp = 1226527167.595983
    #time_tuple = time.localtime(timestamp)
    #date_str = time.strftime("%Y-%m-%d %H:%M:%S", time_tuple)
    #timestamp = 1226527167.595983
    #dt_obj = datetime.datetime.utcfromtimestamp(timestamp)
    timedif = RecordingFromOtherAddon - nowTS
    log('timedif= %r, timedif/3600= %r, timedif/60= %r' % (timedif,timedif/3600,(timedif/60)%60))
    #StartRecordAt = time.strftime("%H:%M:%S",time.localtime(RecordingFromOtherAddon - nowTS))
    #str(starttimedelta/60) + ':' + str(starttimedelta%60) + ':00'
    StartRecordAt = '%02d:%02d:00' % (timedif//3600,(timedif//60)%60)   ### Ignore seconds  ### 2021-06-21
    log('StartRecordAt= %r' % StartRecordAt)
    qrecord = xbmcgui.Dialog()
    ###utils.notification('RecordFrom?: %r' % (sourceApp))
    try:
        recordname = recordname.split('&uri=')[0]  ###+'\n'+utils.decode64(recordname.split('&uri=')[1])
    except Exception as e:
        log('err 5338 Except: %r' % e)
        pass
        log('Error uri extract failed: %r' % e)
    
    
    if timedif > 0:
        arecord = qrecord.yesno(ADDONname,'Do you want to record?\n'+sourceApp+'\n[COLOR red]Start after: '+ StartRecordAt+ '[/COLOR]\n'+OrgTitle)
    else:
        arecord = qrecord.yesno(ADDONname,'Do you want to record?\n'+sourceApp+'\n'+OrgTitle)
    log('answer= %s' % repr(arecord))
    ###utils.notification('RecordFrom: %r' % (sourceApp))
    if not arecord:
        ### Recording not set - play 2018-11-06
        if sourceApp != '':
            try:
                RecordFlagSet(sourceApp,'False')
                log('RecordFlagSet False: %r' % (sourceApp))
                utils.notification('RecordFlagSet False: %r' % (sourceApp))
            except Exception as e:
                log('err 5354 Except: %r' % e)
                pass
                utils.notification('RecordFlagSet Failed: %r\n%r' % (sourceApp,e))
                log('RecordFlagSet Failed ERROR: %r\n%r' % (sourceApp,e))
    if arecord:
        ### Recording set - dont play 2018-11-06
        if sourceApp != '':
            try:
                RecordFlagSet(sourceApp,'True')
                log('RecordFlagSet True: %r' % (sourceApp))
                utils.notification('RecordFlagSet True: %r' % (sourceApp))
            except Exception as e:
                log('err 5365 Except: %r' % e)
                pass
                utils.notification('RecordFlagSet Failed: %r\n%r' % (sourceApp,e))
                log('RecordFlagSet Failed ERROR: %r\n%r' % (sourceApp,e))
        definition.ADDONresetSetting('RecordingFromOtherAddon',recordings.humantime(RecordingFromOtherAddon))
        ###StartRecordAt = '00:00:00'   ### Ignore delay until it works 2018-05-22
        try:
            recordname50 = re.sub('[(,:\\*?<>|")]+', '', recordname)  ### Remove unwanted characters 2019-01-05
            recordname50 = recordname50[0:100].replace('[','').replace(']','')
            nameAlarm = ADDONid + '-Recordffmpeg-' + recordname50 ### 2019-01-05 limit length of nameAlarm
        except Exception as e:
            log('err 5375 Except: %r' % e)
            pass
            nameAlarm = ADDONid+'-Recordffmpeg-missing-name'
        nameAlarm = recordings.latin1_to_ascii_force(nameAlarm) ### 2019-01-03
        ###nameAlarm = nameAlarm.replace(':','.').replace('/','').replace('[','').replace(']','').replace('&','.')
        nameAlarm = re.sub('[(,:\\*?<>|")]+', '', nameAlarm).replace('[','').replace(']','')   ### Remove unwanted characters 2019-01-05
        try:
            if not auth == None:
                uri += '?auth=' + auth
        except Exception as e:
            log('err 5384 Except: %r' % e)
            pass
        ###Description = ''
        try:
            if description != None and description != '' and not '&description=' in uri:
                uri += '&description=' + description
                ###Description = description.replace('AAabBB',' ').replace('aAabBb','?').replace('BBabAA','=').replace('###',',').replace('AaAaA','&').replace('NlNlNl','\n')
            else:
                description = ''
        except Exception as e:
            log('err 5393 Except: %r' % e)
            pass
            log('Except error description: %r' % e)
        try:
            if playpath != None and playpath != '':
                uri += ' playpath=' + playpath
        except Exception as e:
            log('err 5399 Except: %r' % e)
            pass
            log('Except error playpath: %r' % e)
        try:
            if app != None and app != '':
                uri += ' app=' + app
        except Exception as e:
            log('err 5405 Except: %r' % e)
            pass
            log('Except error app: %r' % e)
        startrecording = time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(RecordingFromOtherAddon))
        try:
            stoprecording = datetime.fromtimestamp(RecordingFromOtherAddon) + timedelta(minutes= utils.intADDONgetSetting('RecordingFromOtherAddonTimeInterval',30))
            ##stoprecording = time.strftime("%Y-%m-%d %H:%M:%S",stoprecording)
        except Exception as e:
            log('err 5412 Except: %r' % e)
            pass
            log('stoprecording Error: %r' % e)
            ### File "C:\Users\hans\AppData\Roaming\Kodi\addons\plugin.video.roqtv.rec\default.py", line 3516, in Recordffmpeg
            ### stoprecording = time.localtime(RecordingFromOtherAddon) + timedelta(minutes= 30)
            ### TypeError: can only concatenate tuple (not "datetime.timedelta") to tuple
            stoprecording = datetime.fromtimestamp(RecordingFromOtherAddon) + timedelta(minutes= 30)
            ##stoprecording = time.strftime("%Y-%m-%d %H:%M:%S",stoprecording)
        ### def addRecordingPlanned(cat, startDate, endDate, recordname, alarmname, description, playchannel, DB='default',uri='url')
        """
        decoded = description
        if description != None and description != '':
            try:
                log('decodeparameter(description= %r)' % description)
                if description[:3] == 'b64':
                    decoded = base64.b64decode(description[3:])
                else:
                    decoded = description
            except Exception as e:
                pass
                log('base64.b64decode Error %r' % e)
                decoded = description
        """
        description = utils.decode64(description)
        
        try:    ### 2024-05-08
            recordusing = definition.ADDONgetSetting('recordusing')
            recordingprograms = ['rtmpdump','ffmpeg','yt-dlp']
            recordwith = recordingprograms[int(recordusing)]
        except Exception as e:
            pass
            log('error 676 Except: %r' % e)
            recordwith = 'ffmpeg'
        nameAlarm += recordwith   ### 2024-05-08
        
        recordings.addRecordingPlanned(uri, startrecording, stoprecording, '[COLOR violet]' + recordname.replace(',','').replace('+','Plus') + '[/COLOR]', nameAlarm, 'Record from VOD/Series or from other AddOn\n\n' + OrgTitle+'\n'+recordname + '\n\n' + description, '', DB='default')
        ###recordings.add(cat, startDate, endDate, recordname, description)
        cmd = 'AlarmClock(%s,RunScript(%s,%s,%s,%s),%s,silent)' % (nameAlarm, script, utils.base64b64encode(uri), recordname.replace(',',''),utils.base64b64encode(nameAlarm),StartRecordAt)  ### 2017-08-05 + 2018-05-22
        log('err Recordffmpeg cmd= %r' % cmd)
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin(cmd)  # Active
    
def Recordffmpegarc(recordname, uri, playpath, app, description, auth, sourceApp): 
    try:
        timeintervalbetweenrecordings = utils.intADDONgetSetting('RecordingFromOtherAddonTimeInterval')*60 
    except Exception as e:
        log('err 5279 Except: %r' % e)
        pass
        timeintervalbetweenrecordings = 30 * 60  # Default 30 min
    log('err Recordffmpeg(recordname= %r, uri= %r, playpath= %r, app= %r, description= %r, auth= %r, sourceApp= %r, timeintervalbetweenrecordings= %r)' % (recordname, uri, playpath, app, description, auth, sourceApp,timeintervalbetweenrecordings))
    try:
        uridescription =  param(uri,'description')
        if description == None:
            description = uridescription
        elif uridescription != '' and uridescription not in description:  ### 2020-02-26
            description += uridescription
    except Exception as e:
        log('err 5289 Except: %r' % e)
        pass
        log('Recordffmpeg(description= %r\nERROR: %r' % (description,e))
    try:
        OrgTitle =  param(uri,'OrgTitle')
        OrgTitle = utils.decode64(OrgTitle)
    except Exception as e:
        log('err 5295 Except: %r' % e)
        pass
        log('Recordffmpeg(OrgTitle)\nERROR: %r' % (e))  
        OrgTitle = recordname
    script   = os.path.join(progpath, 'recordarcffmpeg.py') 
    ### Conversion at script!
    ### uri= sys.argv[1].replace('AAabBB',' ').replace('aAabBb','?').replace('BBabAA','=').replace('xXx',' ').replace('###',',').replace('AaAaA','=').replace('NlNlNl','\n')
    nowTS = int(time.mktime(datetime.now().timetuple()))
    log('nowTS= %r - %r' % (nowTS,time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(nowTS))))
    try:
        RecordingFromOtherAddon = recordings.ts(definition.ADDONgetSetting('RecordingFromOtherAddon'))
    except Exception as e:
        log('err 5306 Except: %r' % e)
        pass
        RecordingFromOtherAddon = nowTS - timeintervalbetweenrecordings  ### One hour ago
        log('RecordingFromOtherAddon= %r\nError: %r' % (RecordingFromOtherAddon,e))
    log('RecordingFromOtherAddon= %r - %r' % (RecordingFromOtherAddon,time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(RecordingFromOtherAddon))))
    timesincelast = nowTS - RecordingFromOtherAddon
    if timesincelast > 0:
        log('timesincelast= %r - %r' % (timesincelast,time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(timesincelast))))
    else:
        log('timesincelast= %r' % (timesincelast))
    if timesincelast < timeintervalbetweenrecordings :
        RecordingFromOtherAddon += timeintervalbetweenrecordings
        ###definition.ADDONresetSetting('RecordingFromOtherAddon',str(RecordingFromOtherAddon))
    else:
        RecordingFromOtherAddon = nowTS
        ###definition.ADDONresetSetting('RecordingFromOtherAddon',str(nowTS))
    log('RecordingFromOtherAddon= %r - %r' % (RecordingFromOtherAddon,time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(RecordingFromOtherAddon))))
    #timestamp = 1226527167.595983
    #time_tuple = time.localtime(timestamp)
    #date_str = time.strftime("%Y-%m-%d %H:%M:%S", time_tuple)
    #timestamp = 1226527167.595983
    #dt_obj = datetime.datetime.utcfromtimestamp(timestamp)
    timedif = RecordingFromOtherAddon - nowTS
    log('timedif= %r, timedif/3600= %r, timedif/60= %r' % (timedif,timedif/3600,(timedif/60)%60))
    #StartRecordAt = time.strftime("%H:%M:%S",time.localtime(RecordingFromOtherAddon - nowTS))
    #str(starttimedelta/60) + ':' + str(starttimedelta%60) + ':00'
    StartRecordAt = '%02d:%02d:00' % (timedif//3600,(timedif//60)%60)   ### Ignore seconds  ### 2021-06-21
    log('StartRecordAt= %r' % StartRecordAt)
    qrecord = xbmcgui.Dialog()
    ###utils.notification('RecordFrom?: %r' % (sourceApp))
    try:
        recordname = recordname.split('&uri=')[0]  ###+'\n'+utils.decode64(recordname.split('&uri=')[1])
    except Exception as e:
        log('err 5338 Except: %r' % e)
        pass
        log('Error uri extract failed: %r' % e)
    if timedif > 0:
        arecord = qrecord.yesno(ADDONname,'Do you want to record?\n'+sourceApp+'\n[COLOR red]Start after: '+ StartRecordAt+ '[/COLOR]\n'+OrgTitle)
    else:
        arecord = qrecord.yesno(ADDONname,'Do you want to record?\n'+sourceApp+'\n'+OrgTitle)
    log('answer= %s' % repr(arecord))
    ###utils.notification('RecordFrom: %r' % (sourceApp))
    if not arecord:
        ### Recording not set - play 2018-11-06
        if sourceApp != '' and 1 == 0:  ### Record from Archive do not use RecordFlag
            try:
                RecordFlagSet(sourceApp,'False')
                log('RecordFlagSet False: %r' % (sourceApp))
                utils.notification('RecordFlagSet False: %r' % (sourceApp))
            except Exception as e:
                log('err 5354 Except: %r' % e)
                pass
                utils.notification('RecordFlagSet Failed: %r\n%r' % (sourceApp,e))
                log('RecordFlagSet Failed ERROR: %r\n%r' % (sourceApp,e))
    if arecord:
        ### Recording set - dont play 2018-11-06
        if sourceApp != '' and 1 == 0:  ### Record from Archive do not use RecordFlag
            try:
                RecordFlagSet(sourceApp,'True')
                log('RecordFlagSet True: %r' % (sourceApp))
                utils.notification('RecordFlagSet True: %r' % (sourceApp))
            except Exception as e:
                log('err 5365 Except: %r' % e)
                pass
                utils.notification('RecordFlagSet Failed: %r\n%r' % (sourceApp,e))
                log('RecordFlagSet Failed ERROR: %r\n%r' % (sourceApp,e))
        definition.ADDONresetSetting('RecordingFromOtherAddon',recordings.humantime(RecordingFromOtherAddon))
        ###StartRecordAt = '00:00:00'   ### Ignore delay until it works 2018-05-22
        try:
            recordname50 = re.sub('[(,:\\*?<>|")]+', '', recordname)  ### Remove unwanted characters 2019-01-05
            recordname50 = recordname50[0:100].replace('[','').replace(']','')
            nameAlarm = ADDONid + '-Recordffmpeg-' + recordname50 ### 2019-01-05 limit length of nameAlarm
        except Exception as e:
            log('err 5375 Except: %r' % e)
            pass
            nameAlarm = ADDONid+'-Recordffmpeg-missing-name'
        nameAlarm = recordings.latin1_to_ascii_force(nameAlarm) ### 2019-01-03
        ###nameAlarm = nameAlarm.replace(':','.').replace('/','').replace('[','').replace(']','').replace('&','.')
        nameAlarm = re.sub('[(,:\\*?<>|")]+', '', nameAlarm).replace('[','').replace(']','')   ### Remove unwanted characters 2019-01-05
        try:
            if not auth == None:
                uri += '?auth=' + auth
        except Exception as e:
            log('err 5384 Except: %r' % e)
            pass
        ###Description = ''
        try:
            if description != None and description != '' and not '&description=' in uri:
                uri += '&description=' + description
                ###Description = description.replace('AAabBB',' ').replace('aAabBb','?').replace('BBabAA','=').replace('###',',').replace('AaAaA','&').replace('NlNlNl','\n')
            else:
                description = ''
        except Exception as e:
            log('err 5393 Except: %r' % e)
            pass
            log('Except error description: %r' % e)
        try:
            if playpath != None and playpath != '':
                uri += ' playpath=' + playpath
        except Exception as e:
            log('err 5399 Except: %r' % e)
            pass
            log('Except error playpath: %r' % e)
        try:
            if app != None and app != '':
                uri += ' app=' + app
        except Exception as e:
            log('err 5405 Except: %r' % e)
            pass
            log('Except error app: %r' % e)
        startrecording = time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(RecordingFromOtherAddon))
        try:
            stoprecording = datetime.fromtimestamp(RecordingFromOtherAddon) + timedelta(minutes= utils.intADDONgetSetting('RecordingFromOtherAddonTimeInterval',30))
            ##stoprecording = time.strftime("%Y-%m-%d %H:%M:%S",stoprecording)
        except Exception as e:
            log('err 5412 Except: %r' % e)
            pass
            log('stoprecording Error: %r' % e)
            ### File "C:\Users\hans\AppData\Roaming\Kodi\addons\plugin.video.roqtv.rec\default.py", line 3516, in Recordffmpeg
            ### stoprecording = time.localtime(RecordingFromOtherAddon) + timedelta(minutes= 30)
            ### TypeError: can only concatenate tuple (not "datetime.timedelta") to tuple
            stoprecording = datetime.fromtimestamp(RecordingFromOtherAddon) + timedelta(minutes= 30)
            ##stoprecording = time.strftime("%Y-%m-%d %H:%M:%S",stoprecording)
        ### def addRecordingPlanned(cat, startDate, endDate, recordname, alarmname, description, playchannel, DB='default',uri='url')
        """
        decoded = description
        if description != None and description != '':
            try:
                log('decodeparameter(description= %r)' % description)
                if description[:3] == 'b64':
                    decoded = base64.b64decode(description[3:])
                else:
                    decoded = description
            except Exception as e:
                pass
                log('base64.b64decode Error %r' % e)
                decoded = description
        """
        description = utils.decode64(description)
        recordings.addRecordingPlanned(uri, startrecording, stoprecording, '[COLOR violet]' + recordname.replace(',','').replace('+','Plus') + '[/COLOR]', nameAlarm, 'Record from VOD/Series or from other AddOn\n\n' + OrgTitle+'\n'+recordname + '\n\n' + description, '', DB='default')
        ###recordings.add(cat, startDate, endDate, recordname, description)
        cmd = 'AlarmClock(%s,RunScript(%s,%s,%s,%s),%s,silent)' % (nameAlarm, script, utils.base64b64encode(uri), recordname.replace(',',''),utils.base64b64encode(nameAlarm),StartRecordAt)  ### 2017-08-05 + 2018-05-22
        log('err Recordffmpeg cmd= %r' % cmd)
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin(cmd)  # Active
    
def Recordffmpeguri(recordname, uri, duration, description, nameAlarm=''):
    script   = os.path.join(progpath, 'recorduriffmpeg.py')
    log('err Recordffmpeguri(recordname= %r\nuri= %r\nduration= %r\nnameAlarm= %r\ndescription= %r' % (recordname, uri, duration, nameAlarm, description))
    
    try:
        uridescription =  param(uri,'description')
        if description == None:
            description = uridescription
        elif uridescription != '' and uridescription not in description:  ### 2020-02-26
            description += uridescription
    except Exception as e:
        log('err 5452 Except: %r' % e)
        pass
        log('Recordffmpeguri(description= %r\nERROR: %r' % (description,e))
    
    ###description = recordings.argumenttostring(description)  ### Remove ..NewLine.. etc
    ### Conversion at script!
    ### uri= sys.argv[1].replace('AAabBB',' ').replace('aAabBb','?').replace('BBabAA','=').replace('xXx',' ').replace('###',',').replace('AaAaA','=').replace('NlNlNl','\n')
    nowTS = int(time.mktime(datetime.now().timetuple()))
    log('err nowTS= %r - %r' % (nowTS,time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(nowTS))))
    if nameAlarm == '':
        try:
            recordname50 = re.sub('[(,:\\*?<>|")]+', '', recordname) 
            recordname50 = recordname50[0:100].replace('[','').replace(']','')
            nameAlarm = ADDONid + '-Recordffmpeguri-' + recordname50 ### 2019-01-05 limit length of nameAlarm
        except Exception as e:
            log('err 5466 Except: %r' % e)
            pass
            nameAlarm = ADDONid+'-Recordffmpeguri-missing-name'
        nameAlarm = recordings.latin1_to_ascii_force(nameAlarm) 
        nameAlarm = re.sub('[(,:\\*?<>|")]+', '', nameAlarm).replace('[','').replace(']','')   ### Remove unwanted characters 2019-01-05
    log('err nameAlarm= %r' % nameAlarm)
    try:
        if int(duration)//60 <= 5 :  ### 2022-09-20
            uri += '&duration=120'  ### Default 2 hours
            duration = '120'
        else:
            uri += '&duration=' + str(int(duration)//60)  ### 2021-06-21
    except Exception as e:
        log('err 5474 Except: %r' % e)
        pass
        uri += '&duration=120'  ### Default 2 hours
        duration = '120'
    try:
        if description != None and description != '':
            uri += '&description=' + utils.base64b64encode(description)
    except Exception as e:
        log('err 5481 Except: %r' % e)
        pass
        description = 'Error in description: %r' % e
    startrecording = nowTS
    stoprecording = nowTS + int(duration)
    recordings.addRecordingPlanned(uri, startrecording, stoprecording, '[COLOR violet]' + recordname.replace(',','') + '[/COLOR]', nameAlarm, 'Record from AddOn\n\n' + recordname + '\n\n' + description, '', DB='default')
    ###recordings.add(cat, startDate, endDate, recordname, description)
    cmd = 'AlarmClock(%s,RunScript(%s,%s,%s,%s),00:00:00,silent)' % (nameAlarm, script, utils.base64b64encode(uri), recordname.replace(',',''),utils.base64b64encode(nameAlarm))  
    ###cmd = 'AlarmClock(%s,RunScript(%s,%s,%s,%s),00:00:00,silent)' % (nameAlarm, script, 'b64' + base64.b64encode(uri), 'b64' + base64.b64encode(recordname),'b64' + base64.b64encode(nameAlarm))  
    log( 'XXXX Recordffmpeguri cmd= %r' % cmd)
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin(cmd)  # Active

def RunCmd(cmd):
    log('err RunCmd(cmd= %r)' % (cmd))
    script   = os.path.join(progpath, 'runcmd.py')
    nameAlarm = ADDONid + 'runcmd' + cmd[:50].replace('"','').replace("'","").replace(" ","").replace(":","").replace("\\","")   ### 2024-08-12
    rcmd = 'AlarmClock(%s,RunScript(%s,%s),00:00:00,silent)' % (nameAlarm, script, cmd)
    log( 'err rcmd= %s' % rcmd)
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin(rcmd)  # Active
        
def RecordTimeShift(name, uri, playpath,app,cat):
    log( 'RecordTimeShift(name= %r, uri= %r, playpath= %r, app= %r, cat= %r)' % (name, uri, playpath,app,cat))
    script   = os.path.join(progpath, 'recordtimeshift.py')
    nameAlarm = ADDONid + '-record-timeshift-' + name
    try:
        if not playpath == None:
            uri = uri + ' playpath=' + playpath
    except Exception as e:
        log('err 5510 Except: %r' % e)
        pass
    try:
        if not app == None:
            uri = uri + ' app=' + app
    except Exception as e:
        log('err 5515 Except: %r' % e)
        pass
    cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),00:00:00,silent)' % (nameAlarm, script, uri, name)
    log( 'cmd= %s' % cmd)
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin(cmd)  # Active
    
    #script   = os.path.join(progpath, 'recordtimeshiftshow.py')
    #nameAlarm = 'record-timeshift-show' + name
    #
    #cmd = 'AlarmClock(%s,RunScript(%s,%s,%s,%s,%s,%s),00:00:00,silent)' % (nameAlarm, script, uri, nameAlarm, sys.argv[1],name,cat)
    
    #log( 'cmd= %s' % cmd)
    #xbmc.executebuiltin(cmd)  # Active
    
def scheduleRecording(cat, startDate, endDate, recordname, description):
    if cat != 0 and cat != '0' and cat != '' and cat != None:   
        log('err scheduleRecording(\n cat= %r\n startDate= %r\n endDate= %r\n recordname= %r\n description= %r)' % (cat, startDate, endDate, recordname, description))
        recordings.add(cat, startDate, endDate, recordname, description)

def delRecording(cat, startDate, endDate, recordname):
    recordings.delRecordingPlanned(cat, startDate, endDate, recordname)
    
def modifyRecording(cat, startDate, endDate, recordname, description):
    recordings.modifyRecordingPlanned(cat, startDate, endDate, recordname, description)

def getCaseInsensitivePath(path, RET_FOUND=False):
    '''
    Get a case insensitive path on a case sensitive system
    
    RET_FOUND is for internal use only, to avoid too many calls to os.path.exists
    # Example usage
    getCaseInsensitivePath('/hOmE/mE/sOmEpAtH.tXt')
    '''
    import os
    
    if path=='' or os.path.exists(path):
        if RET_FOUND:   ret = path, True
        else:           ret = path
        return ret
    
    f = os.path.basename(path) # f may be a directory or a file
    d = os.path.dirname(path)
    
    suffix = ''
    if not f: # dir ends with a slash?
        if len(d) < len(path):
            suffix = path[:len(path)-len(d)]

        f = os.path.basename(d)
        d = os.path.dirname(d)
    
    if not os.path.exists(d):
        d, found = getCaseInsensitivePath(d, True)
        
        if not found:
            if RET_FOUND:   ret = path, False
            else:           ret = path
            return ret
    
    # at this point, the directory exists but not the file
    
    try: # we are expecting 'd' to be a directory, but it could be a file
        files = os.listdir(d)
    except Exception as e:
        log('err 5578 Except: %r' % e)
        if RET_FOUND:   ret = path, False
        else:           ret = path
        return ret
    
    f_low = f.lower()
    
    try:    f_nocase = [fl for fl in files if fl.lower() == f_low][0]
    except Exception as e:
        log('err 5586 Except: %r' % e)
        f_nocase = None
    
    if f_nocase:
        if RET_FOUND:   ret = os.path.join(d, f_nocase) + suffix, True
        else:           ret = os.path.join(d, f_nocase) + suffix
        return ret
    else:
        if RET_FOUND:   ret = path, False
        else:           ret = path
        return ret # cant find the right one, just return the path as is.
    
def isExtKnown(infile):
    ffmpegoutputtype = definition.ADDONgetSetting('ffmpegoutputtype').lower()
    infileext = infile.lower().rsplit('.',1)[-1]
    log('infileext= %r, ffmpegoutputtype= %r' % (infileext, ffmpegoutputtype))
    if infileext == ffmpegoutputtype:
        return True
    extorgcollection = definition.ADDONgetSetting('extorgcollection').lower().split(',')
    if infileext in extorgcollection:
    ###if infile[-3:].lower()=='.ts' or infile[-4:].lower()=='.mp4' or infile[-4:].lower()=='.mkv' or infile[-4:].lower()== '.avi' or infile[-4:].lower() == '.m4v' or infile[-4:].lower()=='.flv' or infile[-ffmpegoutputtypelen:].lower()==ffmpegoutputtype:
        return True
    else:
        return False

def ScanFiles(c,folderPath,Archive):
    log('ScanFiles(c,folderPath= %r,Archive= %r)' % (folderPath,Archive))
    if definition.ADDONgetSetting('enable_record') == 'false':
        return
    try:
        nowTS = int(time.mktime(datetime.now().timetuple()))  ### Tell scan has taken place
        definition.ADDONsetSetting('lastnowTS',str(nowTS))
        log('err test sdiskusage folderPath= %r' % folderPath)
        import psutil
        sdiskusage = psutil.disk_usage(folderPath)
        log('err xx sdiskusage= %r' % sdiskusage)
        #sdiskusage(total=21378641920, used=4809781248, free=15482871808, percent=22.5)
        
    except Exception as e:
        log('err 5619 Except: %r' % e)
        pass
        log('error sdiskusage %r' % e)
    
    for infile in find_files(folderPath, '*'):
        try:
            fileext = ''
            fileextt = ''
            if '.' in infile:
                fileext = infile.split('.')[-1]
                fileextt = '.' + fileext
        except Exception as e:
            log('err 5630 Except: %r' % e)
            pass
            fileext = repr(e)
            fileextt = fileext
        infilebasename = os.path.basename(infile).replace(fileextt,'',-1) # the file name only
        if len(folderPath)>0:
            pathoffile = os.path.dirname(infile).replace(folderPath[:-1],'',1)
            if len(pathoffile) >0:
                pathoffile = pathoffile[1:]
        else:
            pathoffile = ''
        video = repr(isExtKnown(infile))
        descriptionfilename = infile.replace(fileextt,'.txt',-1)
        if video == 'True' and os.path.isfile(descriptionfilename):
            try:               ### Description:
                descf = open(descriptionfilename,'r')
                desc = descf.read()
                descf.close()
                description = 'Description:\n' + desc.split('Description:')[1]
                ###log('desc= ' + repr(desc))
            except Exception as e: 
                log('err 5650 Except: %r' % e)
                pass
                description = ''
                log('description ERROR= ' + repr(e))
        else:
            description = ''
        log('infile= %r, infilebasename= %r' % (infile, infilebasename))
        log('pathoffile= %r, folderPath= %r,  os.path.dirname(infile)= %r' % (pathoffile, folderPath, os.path.dirname(infile)))
        recordings.addFile(c, infilebasename, fileext, pathoffile, video, description, repr(os.stat(infile).st_size), Archive)  ### Archive/Local

def ScanLocalRecordingsNoEX():
    ### Only scan if more than 10 minutes ago and recording enabled
    if definition.ADDONgetSetting('enable_record') != 'true' or definition.ADDONgetSetting('scanlocalrecordingsnoex') != 'true':
        return
    nowTS = int(time.mktime(datetime.now().timetuple()))
    definition.log('ScanLocalRecordingsNoEX nowTS= %r' % (utils.ht(nowTS)))
    try:
        nowTS = int(time.mktime(datetime.now().timetuple()))
        lastnowTS = int(definition.ADDONgetSetting('lastnowTS'))
        delaysec = 60*10   ### 10 min
        delay = nowTS - lastnowTS - delaysec
        definition.log('ScanLocalRecordingsNoEX nowTS= %r, lastnowTS= %r, delay= %d' % (utils.ht(nowTS),utils.ht(lastnowTS),delay/60))
        if delay > 0 : 
            ### 2025-05-24 Ask if L should be scanned 10 sec timeout
            dialog = xbmcgui.Dialog()
            if dialog.yesno(ADDONname, "[COLOR lightgreen]Scan Local drive for changes?[/COLOR]" +'\n'+ "What Do You Want To Do","[COLOR red]Scan L:[/COLOR]","[COLOR green]No Scan[/COLOR]", autoclose=10000):
                ### Ignore - No Scan
                lockcause = 'ignore' ### Dummy command
            else:
                ### Stop recording and record new
                lockcause = 'change' ### Dummy command
                definition.log('ScanLocalRecordingsNoEX nowTS= %r, lastnowTS= %r, delay= %d' % (utils.ht(nowTS),utils.ht(lastnowTS),delay/60))
                definition.ADDONsetSetting('lastnowTS',str(nowTS))
                conf = recordings.getFilesConnection()
                recordings.createFileTable(conf)
                c = conf.cursor()
                recordPath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_path')))
                updateepg.ScanFiles(c,recordPath,'L',excommand=False)  ### Dont execute commands during local scan
                conf.commit()
                c.close()  
    except Exception as e: 
        definition.log('ScanLocalRecordingsNoEX Exception: %r' % e)
        pass
    nowTS = int(time.mktime(datetime.now().timetuple()))
    definition.ADDONsetSetting('lastnowTS',str(nowTS))
        
def ScanLocalRecordings():
    if definition.ADDONgetSetting('enable_record') == 'false':
        return
    conf = recordings.getFilesConnection()
    recordings.createFileTable(conf)
    c = conf.cursor()
    recordPath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_path')))
    updateepg.ScanFiles(c,recordPath,'L')
    conf.commit()
    c.close()  
        
def ScanRecordings():
    if definition.ADDONgetSetting('enable_record') == 'false':
        return
    GoHome('Scan Recordings')
    conf = recordings.getFilesConnection()
    recordings.createFileTable(conf)
    c = conf.cursor()
    recordPath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_path')))
    updateepg.ScanFiles(c,recordPath,'L')
    conf.commit()
    if definition.ADDONgetSetting('record_archive_path_enable') == 'true':
        recordArchivePath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_archive_path')))
        updateepg.ScanFiles(c,recordArchivePath,'A')
        conf.commit()
    if definition.ADDONgetSetting('record_archiveb_path_enable') == 'true':
        recordArchivePath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_archiveb_path')))
        updateepg.ScanFiles(c,recordArchivePath,'B')
        conf.commit()
    c.close()  

def DOWNLOADS(view):
    GoHome('Recordings')
    utils.krogsbellWatchingVideo()
    path = recordDisplayPath
    recordPath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_path')))
    searchcount = 0
    searchcountmax = utils.intADDONgetSetting('searchcountmax')
    searchtimemax = utils.intADDONgetSetting('searchtimemax') ### seconds
    searchtimereached = False
    
    ##name = 'Local Video Archive'
    ##addDir('Recordings searched: '+searchText,'url',6,'','','','All recorded items in ' + recordPath)
    ##addDir(name,'url',66,'',recordArchivePath,'','Local Video Archive in ' + recordArchivePath)
    ###liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage="DefaultFolder.png")
    ###liz.setInfo( type="Folder", infoLabels={ "Title": str(name), "Plot":"PLOT" } )
    ###liz.setProperty("IsPlayable","false")
    ###contextMenu = []
    ###liz.addContextMenuItems(contextMenu,replaceItems=True)
    ###xbmcplugin.addDirectoryItem(handle = Handle, url=infile,listitem = liz, isFolder = True)
    if view == '2060':
        sortmethod = ': Sorted by file date '
    elif view == '2065':
        sortmethod = ': Search in Database '
        utils.get_free_space_gb(datapath,archive='/')   ### 2025-02-04
        ### Update Local always
        ScanLocalRecordingsNoEX()   ### 2022-01-27 Dont execute commands
    elif view == '66' or view == '6':
        if definition.ADDONgetSetting('sortalphabetic') == 'true':
            sortmethod = ': Sorted alphabetically '
        else:
            sortmethod = ': Sorted by file date '
    elif view == '67':
        sortmethod = ': Search in Descriptions '
    else:
        sortmethod = ': ' + view
    
    searchText = SearchEPG('Recording to search for'+sortmethod)   ### 2018-10-03 Search starts empty - SearchEPG search same as last
    if not searchText == False :
        nowM = datetime.today().replace(microsecond=0)
        nowJust = nowM
        searchPath = 'All recorded items in[CR]' + path
        searchPath2060 = searchPath
        searchPathLocal = searchPath
        if recordArchivePath != '' and not view == '2060':
            searchPath += '[CR][CR]and[CR]' + recordArchivePath + '[CR]' + recordArchivebPath
        if recordArchivePath != '':
            searchPath2060 += '[CR][CR]and[CR]' + recordArchivePath + '[CR]' + recordArchivebPath
        searchPath = searchPath.replace('/','/ ').replace('\\','\\ ')
        searchPath2060 = searchPath2060.replace('/','/ ').replace('\\','\\ ')
        if view == '2060' or view == '66':
            sortmethod = '[CR][CR]Sorted by file date '
        if view == '6':
            sortmethod = '[CR][CR]Sorted alphabetically '
        if view == '67':
            sortmethod = '[CR][CR]Search in Descriptions '
        if view == '2065':
            sortmethod = '[CR][CR]Search in Database '
        
        ###if view == '2060' or view == '67' or view == '66' or view == '2065':
        if view == '2060' or view == '67' or view == '66':
            addDir('Change sort method to: Sorted alphabetically','url',6,'','','',searchPath2060 + '[CR][CR]If you want episode 98 of Midsomer Murders, you can seek: midsom%98[CR]To avoid some records add ^notsearchtext[CR][CR]Note! Search is NOT case sensitive')
        ###if view == '67' or view == '6' or view == '2065':
        if view == '67' or view == '6':
            addDir('Change sort method to: Sorted by file date','url',66,'','','',searchPath + '[CR][CR]If you want episode 98 of Midsomer Murders, you can seek: midsom%98[CR]To avoid some records add ^notsearchtext[CR][CR]Note! Search is NOT case sensitive')
        if view == '2060' or view == '67' or view == '66' or view == '6':
            addDir('Change sort method to: Search in Database','url',2065,'','','','Search in local database with local and archive files' + '[CR][CR]If you want episode 98 of Midsomer Murders, you can seek: midsom%98[CR]To avoid some records add ^notsearchtext[CR][CR]Search in local recordings include l:[CR]Search in archive recordings include a: b: or f:[CR]Search in root of local and archive include r:[CR]Search in recordings with pending commands include c:[CR]Search in description include t:[CR][CR]Sort by file date decending include n:[CR]Sort by series/episode include s:[CR][CR]Note! Search is NOT case sensitive')
        ###addDir('Execute Commands and Update File Database','url',2070,'','','','[I][COLOR grey]Execute Commands and then Scan through Recorded files and the Archive [/COLOR][/I]\n\nPlease wait')
        if view == '67':
            addDir('[B][COLOR lightgreen]Recordings searched: [/COLOR]'+searchText+'[/B]\n[I][COLOR grey]'+sortmethod.replace('[CR]','')+'[/COLOR][/I]','url',int(view),'','','',searchPath + '[CR][CR]Note! Search is NOT case sensitive'+sortmethod)
        else:
            if view == '2065':
                searchPathDB = 'Search in local database with local and archive files[CR][CR]Search in local recordings include l:[CR]Search in archive recordings include a: b: or f:[CR]Search in root of local and archive include r:[CR]Search in recordings with pending commands include c:[CR]Search in description include t:[CR][CR]Sort by file date decending include n:[CR]Sort by duration include d:[CR]Sort by series/episode include s:[CR]Show only one series by ending search with e:+, e:- or e:<ser>. e:0 shows all series[CR]Find dublets include x: (Experimental)'
            else:
                searchPathDB = searchPath
                addDir('Search in Descriptions','url',67,'','','',searchPath2060 + '[CR][CR]Note! Search is NOT case sensitive')
            
            archive = ''
            command = ''
            duration= ''
            sortflags = ''
            seriesflag = ''
            folder  = ''
            limitSeries = False
            
            if 'episode:' in searchText or 'e:' in searchText or 'E:' in searchText:
                log('err setting series/episode: searchText= %r' % searchText)
                searchText = searchText.replace('episode:','e:').replace('E:','e:')
                episode = searchText.split('e:')
                searchText = episode[0]
                viewS0 = searchText.lower().replace('s:','')
                definition.ADDONresetSetting('limittoseriesname',viewS0)
                log('Except setting series/episode: viewS0= %r' % viewS0)
                viewSl = definition.ADDONgetSetting('limittoseries')
                if viewSl == '':
                    viewSl = '0'
                try:
                    if episode[1] == '+':
                        viewSl = int(viewSl) + 1
                    elif episode[1] == '-':
                        viewSl = int(viewSl) - 1
                    else:
                        viewSl = int(episode[1])
                    log('err setting series/episode: viewSl= %r' % viewSl)
                    if viewSl <= 0:
                        viewSl = 0
                    definition.ADDONresetSetting('limittoseries',str(viewSl))
                    log('err setting series/episode to: viewSl= %r' % viewSl)
                except Exception as e:
                    log('err 5773 Except: %r' % e)
                    pass
                    log('Error setting series/episode: %r' % e)
            
            if 'root:' in searchText or 'r:' in searchText or 'R:' in searchText:
                folder = 'R'
            if 'archive:' in searchText or 'a:' in searchText or 'A:' in searchText:
                archive = 'A'
            if 'archiveb:' in searchText or 'b:' in searchText or 'B:' in searchText:
                archive = 'B'
            if 'archivef:' in searchText or 'f:' in searchText or 'F:' in searchText:
                archive = 'F'
            if 'local:' in searchText or 'l:' in searchText or 'L:' in searchText:
                archive = 'L'
            if 'command:' in searchText or 'c:' in searchText or 'C:' in searchText:
                command = 'C'
            if 'duration:' in searchText or 'd:' in searchText or 'D:' in searchText:
                duration = 'D'
            if 'series:' in searchText or 's:' in searchText or 'S:' in searchText:
                duration = 'S'
            if 'text:' in searchText or 't:' in searchText or 'T:' in searchText:
                duration = 'T'   ### 2019-09-17
            if 'new:' in searchText or 'n:' in searchText or 'N:' in searchText:
                duration = 'N'
            if 'x:' in searchText or 'X:' in searchText:
                finddublets = True
                sortkey = definition.ADDONgetSetting('sortkey')
                if sortkey == '0':
                    sortkeydisplay = 'Filename'
                elif sortkey == '12':
                    sortkeydisplay = 'Title'
                else:
                    sortkeydisplay = sortkey
                sortflags += 'Find Duplicates size= '+definition.ADDONgetSetting('sortsize')+' sortkey= '+sortkeydisplay
            else:
                finddublets = False
            if folder == 'R':
                sortflags += ' Root only'
            elif archive != '':
                sortflags += ' Local/Archive=' + archive
            elif command != '':
                sortflags += ' Command=' + command
            if duration != '':
                viewS0 = definition.ADDONgetSetting('limittoseriesname')
                log('6727 Except viewS0= %r searchText= %r' % (viewS0,searchText))
                if viewS0.lower() == searchText.lower().replace('s:','') :
                    limitSeries = True
                    viewSl = definition.ADDONgetSetting('limittoseries')
                    if duration == 'S' and viewSl != '0' and viewSl != '':
                        sortflags += ' Duration/Series/Text/New=' + duration + viewSl
                        seriesflag = ' [/B][COLOR yellow](only S' + viewSl + ')[/COLOR][B]'
                else:
                    limitSeries = False
                    sortflags += ' Duration/Series/Text/New=' + duration ###+ ' XXX'+viewS0.lower() +'xxx'+ searchText.lower().replace('s:','')
            ###if duration != 'T' and view == '2065':
            ###    searchText = recordings.latin1_to_ascii_force(searchText)
            ### 2019-12-25 Add this menu here!
            ###contextMenu.append(('[COLOR orange][B]Execute/Update Database[/B][/COLOR]', 'RunPlugin(%s?mode=1025&url=url&name=&recordname=)'% (sys.argv[0])))
            addDir('[B][COLOR lightgreen]Recordings searched: [/COLOR]'+highlight(searchText,searchText)+seriesflag+'[/B]\n[I][COLOR lightyellow]'+sortmethod.replace('[CR]','')+sortflags+'[/COLOR][/I]','url',int(view),'','','',searchPathDB + '[CR][CR]If you want episode 98 of Midsomer Murders, you can seek: midsom%98[CR]To avoid some records add ^notsearchtext[CR][CR]Note! Search is NOT case sensitive'+sortmethod)
        
        files = []
        filecount = 0
        filecountmax = utils.intADDONgetSetting('searchcountmax')
        filesallA = []
        
        if view == '2065': ### Search in database
            log('View 2065')
            if definition.ADDONgetSetting('enable_record')!='true':
                recordings.getFileBase()    ### Copy files.db from recordings folder
                filebaseonNAS = True
            else:
                filebaseonNAS = False
            log('errorY View 2065 filebaseonNAS= %r' % filebaseonNAS)
            archive = ''
            command = ''
            duration= ''
            folder  = ''
            """
            if 'episode:' in searchText or 'e:' in searchText or 'E:' in searchText:
                log('err setting series/episode: searchText= %r' % searchText)
                searchText = searchText.replace('episode:','e:').replace('E:','e:')
                episode = searchText.split('e:')
                searchText = episode[0]
                log('err 1 setting series/episode: searchText= %r' % searchText)
                viewSl = definition.ADDONgetSetting('limittoseries')
                try:
                    if episode[1] == '+':
                        viewSl = int(viewSl) + 1
                    elif episode[1] == '-':
                        viewSl = int(viewSl) - 1
                    else:
                        viewSl = int(episode[1])
                    log('err setting series/episode: viewSl= %r' % viewSl)
                    if viewSl <= 0:
                        viewSl = 0
                    definition.ADDONresetSetting('limittoseries',str(viewSl))
                    log('err setting series/episode to: viewSl= %r' % viewSl)
                except Exception as e:
                    pass
                    log('Error setting series/episode: %r' % e)
            """
            if 'root:' in searchText or 'r:' in searchText or 'R:' in searchText:
                folder = 'R'
                searchText = searchText.replace('root:','').replace('r:','').replace('R:','')
            if 'archive:' in searchText or 'a:' in searchText or 'A:' in searchText:
                archive = 'A'
                searchText = searchText.replace('archive:','').replace('a:','').replace('A:','')
            if 'archiveb:' in searchText or 'b:' in searchText or 'B:' in searchText:
                archive = 'B'
                searchText = searchText.replace('archiveb:','').replace('b:','').replace('B:','')
            if 'archivef:' in searchText or 'f:' in searchText or 'F:' in searchText:
                archive = 'F'
                searchText = searchText.replace('archivef:','').replace('f:','').replace('F:','')
            if 'local:' in searchText or 'l:' in searchText or 'L:' in searchText:
                archive = 'L'
                searchText = searchText.replace('local:','').replace('l:','').replace('L:','')
            if 'command:' in searchText or 'c:' in searchText or 'C:' in searchText:
                command = 'C'
                searchText = searchText.replace('command:','').replace('c:','').replace('C:','')
            if 'duration:' in searchText or 'd:' in searchText or 'D:' in searchText:
                duration = 'D'
                searchText = searchText.replace('duration:','').replace('d:','').replace('D:','')
            if 'series:' in searchText or 's:' in searchText or 'S:' in searchText:
                duration = 'S'
                searchText = searchText.replace('series:','').replace('s:','').replace('S:','')
            if 'text:' in searchText or 't:' in searchText or 'T:' in searchText:
                duration = 'T'   ### 2019-09-17
                searchText = searchText.replace('text:','').replace('t:','').replace('T:','')
            if 'new:' in searchText or 'n:' in searchText or 'N:' in searchText:
                duration = 'N'
                searchText = searchText.replace('new:','').replace('n:','').replace('N:','')
            if 'x:' in searchText or 'X:' in searchText:
                finddublets = True
                sortflags += 'Find Duplicates'
                searchText = searchText.replace('x:','').replace('X:','')
            else:
                finddublets = False
            
            conf = recordings.getFilesConnection()
            recordings.createFileTable(conf)
            c = conf.cursor()
            ###c.execute("CREATE TABLE IF NOT EXISTS files(0filename TEXT, 1ext TEXT, 2path TEXT, 3video TEXT, 4description TEXT, 5size TEXT, 6archive TEXT, 7updated INTEGER, 8created INTEGER, 9updatedHuman INTEGER, 10command TEXT, 11options TEXT, PRIMARY KEY (filename, ext, path, archive))")
            log('err searchText= %r' % searchText)
            searchTextAll = searchText.split('^')
            log('err searchTextAll= %r' % searchTextAll)
            searchText = searchTextAll[0]
            try:
                searchTextNOT = searchTextAll[1]
            except Exception as e:
                log('err 5882 Except: %r' % e)
                pass
                log('searchTextNOT ERROR: %r' % e)
                searchTextNOT = 'XXXXXXXXXXXXXXXXX'
            
            try:
                if folder == 'R' and duration == 'T':
                    c.execute("SELECT * FROM files WHERE description like ? AND NOT description like ? AND video = 'True' AND path=? COLLATE NOCASE", ['%'+searchText+'%','%'+searchTextNOT+'%',''])
                elif duration == 'T':
                    c.execute("SELECT * FROM files WHERE description like ? AND NOT description like ? AND video = 'True' COLLATE NOCASE", ['%'+searchText+'%','%'+searchTextNOT+'%'])           
                elif folder == 'R':
                    c.execute("SELECT * FROM files WHERE ((filename like ? AND NOT filename like ?) OR  (realtitle like ? AND NOT realtitle like ?)) AND video = 'True' AND path=? COLLATE NOCASE", ['%'+searchText+'%','%'+searchTextNOT+'%','%'+searchText+'%','%'+searchTextNOT+'%',''])  ### 2020-05-17
                elif archive != '' and command != '':
                    c.execute("SELECT * FROM files WHERE ((filename like ? AND NOT filename like ?) OR  (realtitle like ? AND NOT realtitle like ?)) AND video = 'True' AND archive=? AND NOT command=? COLLATE NOCASE", ['%'+searchText+'%','%'+searchTextNOT+'%','%'+searchText+'%','%'+searchTextNOT+'%',archive,''])  
                elif archive == '' and command != '':
                    c.execute("SELECT * FROM files WHERE ((filename like ? AND NOT filename like ?) OR  (realtitle like ? AND NOT realtitle like ?)) AND video = 'True' AND NOT command=? COLLATE NOCASE", ['%'+searchText+'%','%'+searchTextNOT+'%','%'+searchText+'%','%'+searchTextNOT+'%',''])  
                elif archive != '' and command == '':
                    c.execute("SELECT * FROM files WHERE ((filename like ? AND NOT filename like ?) OR  (realtitle like ? AND NOT realtitle like ?)) AND video = 'True' AND archive=? COLLATE NOCASE", ['%'+searchText+'%','%'+searchTextNOT+'%','%'+searchText+'%','%'+searchTextNOT+'%',archive])  
                else:
                    c.execute("SELECT * FROM files WHERE ((filename like ? AND NOT filename like ?) OR  (realtitle like ? AND NOT realtitle like ?)) AND video = 'True' COLLATE NOCASE", ['%'+searchText+'%','%'+searchTextNOT+'%','%'+searchText+'%','%'+searchTextNOT+'%']) 
                
                channels = c.fetchall()
                if finddublets :     ### 2025-08-29 Find dublettes
                    ### Sort key filename = 0, realtitle = 12
                    sortkey = int(definition.ADDONgetSetting('sortkey'))
                    size = int(definition.ADDONgetSetting('sortsize'))
                    log('exception sortkey= %r channels= %r' % (sortkey,channels))
                    channels = sorted(channels, key=itemgetter(sortkey))
                    dubletchannels = []
                    prevfilename = ['','','','','','','','','','','','','']
                    i = 0
                    lasti = 0
                    for chan in channels:
                        i += 1
                        se = utils.SeriesEpisodeVOD(chan[sortkey])[0]
                        log('except VODse= %r chan[sortkey]= %r' % (se,chan[sortkey]))
                        if se == 0:
                            se = utils.SeriesEpisode(chan[sortkey])
                            log('except se= %r chan[sortkey]= %r' % (se,chan[sortkey]))
                        log('except chan[sortkey]= %r prevfilename[0:size]= %r' % (chan[sortkey],prevfilename[sortkey][0:size]))
                        see = se%1000
                        log('except see= %r' % see)
                        if chan[sortkey][0:size] == prevfilename[sortkey][0:size] and (se < 1 or see == 0):
                            if i > lasti+1 :
                                dubletchannels.append(prevfilename)
                            dubletchannels.append(chan)
                            lasti = i
                        prevfilename = chan
                        
                    channels = dubletchannels
                    log('except channels= %r' % channels)
            except Exception as e:
                pass
                log('error File Database Except: %r' % e)
                channels = ''
                utils.notificationforced('[COLOR red]File Database Exception: %r[/COLOR]' % e, time = 5)
                
            log('errorY Channels count= %r\narchive= %r\ncommand= %r\nduration= %r\nfolder= %r\n' % (len(channels),archive,command,duration,folder))
            if duration == 'D':
                log('Duration Mode')
                channelsarray = []
                for chan in channels:
                    size = chan[5].split('\n')[-1].split(' ')[-1]
                    if 'm' in size:
                        Length = int(size.split('m')[0])
                    else:
                        Length = 0
                    if Length != 0:
                        channelsarray.append([Length,chan])
                channelsarray = sorted(channelsarray, key=itemgetter(0))
                log('channelsarray= %r' % channelsarray)
            elif duration == 'S':
                log('SeriesEpisode Mode')
                channelsarray = []
                for chan in channels:
                    Length = utils.SeriesEpisode(chan[12])
                    if Length == 0:
                        Length = utils.SeriesEpisode(chan[0])
                    viewS0 = definition.ADDONgetSetting('limittoseriesname')  
                    viewSl = definition.ADDONgetSetting('limittoseries')
                    if viewS0 != searchText :
                        log('1 Except multi searchText= %r, viewS0= %r, viewSl= %r' % (searchText,viewS0,viewSl))
                        channelsarray.append([Length,chan])
                        log('1.1 Except multi searchText= %r, viewS0= %r, viewSl= %r' % (searchText,viewS0,viewSl))
                        channelsarray = sorted(channelsarray, key=itemgetter(0))  
                        log('1.2 Except multi searchText= %r, viewS0= %r, viewSl= %r' % (searchText,viewS0,viewSl))                        
                    else:
                        viewS = str(Length//1000)   ###.split('.')[0]  ### 2021-03-26
                        log('2 Except multi searchText= %r, viewS0= %r, viewSl= %r, viewS= %r' % (searchText,viewS0,viewSl,viewS))
                        
                        if Length > 0 and (viewSl == '' or viewSl == '0' or viewSl == viewS or duration != 'S'):
                            channelsarray.append([Length,chan])
                            channelsarray = sorted(channelsarray, key=itemgetter(0))
                log('Except channelsarray= %r' % channelsarray)
            elif duration == 'N':
                ### channels[5] = size = Size: 1.608 GB\nDate: 2018-04-02 18:44:29\nDuration: 0h45m 45m
                log('File Date Decending Mode')
                channelsarray = []
                for chan in channels:
                    try:
                        log('chan[5]= %r' % chan[5])
                        date_str   = chan[5].split('\n')[1].replace('Date: ','')  ### 2018-04-02 18:44:29
                        time_tuple = time.strptime(date_str, "%Y-%m-%d %H:%M:%S")
                        Length  = int(time.mktime(time_tuple))  ### timestamp
                        channelsarray.append([-Length,chan])
                    except Exception as e:
                        log('err 5942 Except: %r' % e)
                        pass
                        log('File Date Decending Mode Error: %r' % e)
                channelsarray = sorted(channelsarray, key=itemgetter(0))
                log('channelsarray= %r' % channelsarray)  
            else:
                channels = sorted(channels, key=itemgetter(7), reverse=True)
                ###channels = sorted(channels, key=itemgetter(0))
                channels = sorted(channels, key=itemgetter(12))  ### 2020-12-03
                channelsarray = []
                Length = 0
                for chan in channels:
                    channelsarray.append([Length,chan])
                log('Except channelsarray= %r' % channelsarray)
            
            ### 0 filename, 1 ext, 2 path, 3 video, 4 description, 5 size, 6 archive, 7 updated, 8 created, 9 updatedHumanTime, 10 command, 11 options, 12 realtitle
            channelsarrayList = 'Last Action Performed: ' + definition.ADDONgetSetting('lastdatabaseaction')
            log('Except channelsarrayList= %r' % channelsarrayList)
            for chan in channelsarray:
                log('Except chan[1][0]= %r' % chan[1][0] )
                channelsarrayList +=  '#'+chan[1][0] +':'+chan[1][1] +':'+chan[1][2] +':'+chan[1][6]+':'+chan[1][10]
            log('Exception channelsarrayList= %r' % channelsarrayList)
            channelsarrayList = channelsarrayList.replace(',','[COLOR red] No comma in Filenames! [/COLOR]').replace('+','[COLOR red] No plus sign in Filenames! [/COLOR]')  ### Do not include commas
            for chan in channelsarray:
                ### chan[y] --> chan[1][y]
            ###channels = channelsarray[1]
            ###for chan in channels:
                ###name = chan[1][0].replace(',','[COLOR red] No comma in Filenames! [/COLOR]').replace('+','[COLOR red] No plus sign in Filenames! [/COLOR]')  ### Do not include commas
                filename = chan[1][0]
                try:
                    name = chan[1][12]
                    log('name[:1]=1 %r' % name[:1])
                    log('err 0 xname= %r' % name)
                except Exception as e:
                    log('err 5974 Except: %r' % e)
                    pass
                    log('Error name = chan[1][12]: %r' % e)
                    name = filename
                if name[:1] == '[':   ### 2019-03-09
                    nameparts = name.split(']',1)
                    name = nameparts[1] + ' ' + nameparts[0] + ']'
                    name = name.strip()
                log('err 1 xname= %r' % name)
                Duration = chan[0]
                DurationP = ''
                viewS = '0'
                if Duration > 0 and duration == 'D':
                    Duration = ' ' + str(Duration) + 'm'
                elif Duration >= 0 and duration == 'S':
                    ###viewS = str(Duration/1000).split('.')[0]
                    viewS = str(Duration//1000)
                    viewE = Duration%1000
                    if viewE == 0 :
                        if len(viewS) == 4:
                            Duration = ' [COLOR yellow]' + str(Duration//1000) + '[/COLOR] '
                        else:
                            Duration = ' [COLOR yellow]S' + str(Duration//1000) + '[/COLOR] '
                    else:
                        Duration = ' [COLOR yellow]S' + str(Duration//1000) + 'E' + str(Duration%1000)+ '[/COLOR] '
                    DurationP = Duration.strip() + ' '
                else:
                    Duration = ''
                
                Duration +=  ' '+chan[1][6] + '://' +chan[1][2] ### 2026-09-20
                """
                try:
                    Duration = name.split('[',1)[1].split(']',1)[0]
                    if not 'h' in Duration or not 'm' in Duration:
                        Duration = name.split(']')[-2].split('[')[-1].split(' ')[-1]
                        if not 'h' in Duration or not 'm' in Duration:
                            Duration = ''
                except Exception as e:
                    pass
                    log('Duration ERROR: %r' % e)
                    Duration = ''
                Length = 0
                if Duration != '':
                    Length = int(Duration.split('h')[0])*60 + int(Duration.split('h')[1].split('m')[0])
                """
                if chan[1][11] != '' and '[' in name:
                    if '[' in chan[1][11]:
                        name = chan[1][11]  ### Show pending command
                        log('err 2 xname= %r' % name)
                    name = DurationP + '[B]' + name.replace('[','[/B]'+Duration+'\n[COLOR lightcoral][I]'+ 'Pending: ' + chan[1][10] + ' ' + chan[1][6]+' [',1) + '[/I][/COLOR]'
                    log('err 3 xname= %r' % name)
                    name = name.split('\n')
                    log('err 4 xname= %r' % name)
                    line1 = name[0]
                    lenline1 = len(line1)
                    line2 = name[1]
                    lenline2 = len(line2)
                    if lenline1 < lenline2:
                        line1 = line1 + ' ' * (lenline2 - lenline1 - 16)
                    name = line1 +'\n' + line2    ### +'.'+ str(lenline1)+'.'+ str(lenline2)
                    log('err 5 xname= %r' % name)
                elif chan[1][11] != '' and not '[' in name:
                    name = chan[1][11]  ### Show pending command
                    log('err 6 xname= %r' % name)
                    name = DurationP + '[B]' + chan[1][11] +'[/B]'+Duration+'\n[COLOR lightcoral][I]'+ 'Pending: ' + chan[1][10] +' ' +chan[1][6]+'[/I][/COLOR]'
                    log('err 7 xname= %r' % name)
                    name = name.split('\n')
                    line1 = name[0]
                    lenline1 = len(line1)
                    line2 = name[1]
                    lenline2 = len(line2)
                    if lenline1 < lenline2:
                        line1 = line1 + ' ' * (lenline2 - lenline1 - 16)
                    name = line1 +'\n' + line2    ### +'.'+ str(lenline1)+'.'+ str(lenline2)
                    log('err 8 xname= %r' % name)
                elif chan[1][11] == '' and '[' in name:
                    name = DurationP + '[B]' + name.replace('[','[/B]'+Duration+'\n[COLOR lemonchiffon][I]' +chan[1][6]+' [',1) + '[/I][/COLOR]'
                    log('err 9 xname= %r' % name)
                    name = name.split('\n')
                    log('err 10 xname= %r' % name)
                    line1 = name[0]
                    lenline1 = len(line1)
                    line2 = name[1]
                    lenline2 = len(line2)
                    if lenline1 < lenline2:
                        line1 = line1 + ' ' * (lenline2 - lenline1 - 16)
                    name = line1 +'\n' + line2    ### +'.'+ str(lenline1)+'.'+ str(lenline2)
                    log('err 11 xname= %r' % name)
                else:
                    ###name = '[B]' + chan[1][0] + '[/B]'+Duration+'\n[COLOR lemonchiffon][I]' +chan[1][6]+'[/I][/COLOR]'
                    name = DurationP + '[B]' + name + '[/B]'+Duration+'\n[COLOR lemonchiffon][I]' +chan[1][6]+'[/I][/COLOR]'
                    log('err 12 xname= %r' % name)
                if chan[1][10] != '':
                    #.replace('/','/ ').replace('\\','\\ ')
                    commandX = '\n\n[COLOR lightcoral]Pending: '  + chan[1][10] + '\n' + chan[1][11].replace('/','/ ').replace('\\','\\ ') + '[/COLOR]'  ### 2019-09-11
                else:
                    commandX = ''
                try:
                    log('err0 logo= %r' % chan[1][4])
                    try:
                        e1 = ''
                        logo = chan[1][4].split('Logo: ')[1].split('\n')[0]
                    except Exception:
                        pass
                        logo = chan[1][4].split('COVER_BIG:')[1].split('\n')[0]
                    log('err1 logo= %r' % logo)
                except Exception as e:
                    log('err 6072 Except: %r' % e)
                    pass
                    logo = "DefaultVideo.png"
                    log('err logo Failure\n%r\n%r\nNo logo found in description!' % (e1,e))
                ###liz=xbmcgui.ListItem(highlight(name,searchText), iconImage=logo, thumbnailImage=logo)    ### 2020-03-13
                Genre = utils.utf((chan[1][2] + '\nStart at: ' + chan[1][13] + '\n' + chan[1][5]).strip().replace('\n',' - '))
                log('err Genre 5402= %r' % Genre)
                log('err 13 xname= %r' % name)
                try:
                    if chan[1][13] != '':
                        # set start marker in MyVideos116.db Kodi 18
                        # set start marker in MyVideos119.db Kodi 19
                        startmarker.setStartTime(chan[1][13],chan[1][0]+'.'+chan[1][1])
                except Exception as e:
                    log('err 6084 Except: %r' % e)
                    pass
                    log('err startmarker ERROR startmarker%r\nFilename= %r\n%r' % (chan[1][13],chan[1][0]+'.'+chan[1][1],e))        
                if chan[1][13] != '':
                    startTime = '\nStart at: ' + chan[1][13]
                else:
                    startTime = ''
                viewSl = definition.ADDONgetSetting('limittoseries')
                log('err viewSl= %r, viewS= %r' % (viewSl,viewS))
                if viewSl == '' or viewSl == '0' or viewSl == viewS or duration != 'S' or limitSeries == False: 
                    ###liz=xbmcgui.ListItem(highlight(name+' [COLOR lightyellow][I]'+chan[1][5].strip().replace('Size:','').replace('Date:','').replace('\n',' - ',1)+' [/COLOR][/I]',searchText))    ### 2021-02-25/2024-08-31
                    
                    ###chan[1][11]    .encode('utf-8','ignore')
                    liz=xbmcgui.ListItem(utils.utf(highlight(name+' [COLOR lightyellow][I]'+chan[1][5].strip().replace('Size:','').replace('Date:','').replace('\n',' - ',1)+' [/COLOR][/I]',searchText)))   ### 2021-02-25/2024-08-31
                    liz.setArt({ 'icon': logo, 'thumb' : logo })
                    liz.setInfo( type="Video", infoLabels={ "Title": utils.utf(highlight(chan[1][0],searchText)), "Plot": utils.utf(highlight(utils.utf(name),searchText).replace('\\','\\ ').replace('  ',' ').strip()  + startTime +  '\n' + highlight(chan[1][4].replace('.n','.\n'), searchText)+"\nLast updated: " + chan[1][9]+"\nArchive: " + chan[1][6]+"\nFilename: " + chan[1][0]+"\nPath: "  +chan[1][2]+"\nExtension: " +chan[1][1]+"\n"+chan[1][5]+ commandX +'\n\n'+highlight(chan[1][4], searchText)),"Genre":Genre+' xXx'})
                    liz.setProperty("IsPlayable","true") 
                    contextMenu = []
                    ####contextMenu.append(('[COLOR brown][B]View: '+view+'[/B][/COLOR]','Container.Update(%s?name=Home&mode=None&url=None&iconimage=None&cat=None)'% (sys.argv[0])))
                    contextMenu.append(('[COLOR yellow][B]Home[/B][/COLOR]','Container.Update(%s?name=Home&mode=None&url=None&iconimage=None&cat=None)'% (sys.argv[0])))
                    if definition.ADDONgetSetting('enable_record')=='true' :
                        contextMenu.append(('[COLOR red][B]Planned Recordings[/B][/COLOR]','Container.Update(%s?name=None&mode=3&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                    contextMenu.append(('[COLOR blue][B]Stop Player/Set Video Volumen[/B][/COLOR]', 'RunPlugin(%s?mode=10232&url=%s&name=%s&recordname=%s&description=%s)'% (definition.DRLYD(), chan[1][0], chan[1][6], chan[1][1], chan[1][13])))    ### 2022-06-24
                    
                    contextMenu.append(('[COLOR blue][B]Audio Volumen %[/B][/COLOR]', 'RunPlugin(%s?mode=10233&url=%s&name=%s&recordname=%s&description=%s)'% (definition.DRLYD(), chan[1][0], chan[1][6], chan[1][1], chan[1][13])))    ### 2024-06-16
                    ### If Record Disabled ignore functions 2022-08-28
                    if not filebaseonNAS:
                        contextMenu.append(('[COLOR yellow][B]Execute/Update Database[/B][/COLOR]', 'RunPlugin(%s?mode=1025&url=%s&name=%s&recordname=%s&description=%s)'% (sys.argv[0], chan[1][0], chan[1][6], chan[1][1], chan[1][2])))
                        contextMenu.append(('[COLOR orange][B]Set Start Time[/B][/COLOR]', 'RunPlugin(%s?mode=10231&url=%s&name=%s&recordname=%s&description=%s)'% (sys.argv[0], chan[1][0], chan[1][6], chan[1][1], chan[1][13])))
                        contextMenu.append(('[COLOR orange][B]Change Title[/B][/COLOR]', 'RunPlugin(%s?mode=10230&url=%s&name=%s&recordname=%s&description=%s)'% (sys.argv[0], chan[1][0], chan[1][6], chan[1][1], chan[1][2])))
                        contextMenu.append(('[COLOR orange][B]Rename[/B][/COLOR]', 'RunPlugin(%s?mode=1023&url=%s&name=%s&recordname=%s&description=%s)'% (sys.argv[0], chan[1][0], chan[1][6], chan[1][1], chan[1][2])))
                        """
                        if chan[1][6] == 'A':
                            contextMenu.append(('[COLOR orange][B]Move from Archive[/B][/COLOR]', 'RunPlugin(%s?mode=1024&url=%s&name=%s&recordname=%s&description=%s)'% (sys.argv[0], chan[1][0], chan[1][6], chan[1][1], chan[1][2])))
                            contextMenu.append(('[COLOR orange][B]Copy to Local[/B][/COLOR]', 'RunPlugin(%s?mode=1124&url=%s&name=%s&recordname=%s&description=%s)'% (sys.argv[0], chan[1][0], chan[1][6], chan[1][1], chan[1][2])))
                        else:
                            contextMenu.append(('[COLOR orange][B]Move to Archive[/B][/COLOR]', 'RunPlugin(%s?mode=1024&url=%s&name=%s&recordname=%s&description=%s)'% (sys.argv[0], chan[1][0], chan[1][6], chan[1][1], chan[1][2])))
                        """    
                        contextMenu.append(('[COLOR orange][B]Move to Folder[/B][/COLOR]', 
                        'RunPlugin(%s?mode=1028&url=%s&name=%s&recordname=%s&description=%s)'% (sys.argv[0], chan[1][0], chan[1][6], chan[1][1], chan[1][2])))
                        contextMenu.append(('[COLOR orange][B]Delete[/B][/COLOR]', 
                        'RunPlugin(%s?mode=1026&url=%s&name=%s&recordname=%s&description=%s)'% (sys.argv[0], chan[1][0], chan[1][6], chan[1][1], chan[1][2])))
                        contextMenu.append(('[COLOR orange][B]Clear Command[/B][/COLOR]', 
                        'RunPlugin(%s?mode=1027&url=%s&name=%s&recordname=%s&description=%s)'% (sys.argv[0], chan[1][0], chan[1][6], chan[1][1], chan[1][2])))
                        contextMenu.append(('[COLOR orange][B]Multiselect[/B][/COLOR]', 
                        'RunPlugin(%s?mode=1031&url=%s&name=%s&recordname=%s&description=%s)'% (sys.argv[0], channelsarrayList, chan[1][6], chan[1][1], chan[1][2])))
                        
                    ###default.py: Just before commands: (cat= None, mode= 1023, url= 'Kriminalkommissaer Barnaby XVIII [1h30m][TV-Serie. Programmer] . (Midsomer Murders) (S0E108) (2016) [2019-02-27 15-19 DR1 (D)]', startDate= None, endDate= None, name= 'A', recordname= '', description= None)
                    log('6279 err RunPlugin(%s?mode=1025&url=%s&name=%s&recordname=%s&description=%s)'% (sys.argv[0], chan[1][0], chan[1][6], chan[1][1], chan[1][2]))
                    if chromecast: 
                        if chan[1][6] == 'A':
                            infile = os.path.join(os.path.join(recordArchivePath,chan[1][2]),chan[1][0]+'.'+chan[1][1])
                        elif chan[1][6] == 'B':
                            infile = os.path.join(os.path.join(recordArchivebPath,chan[1][2]),chan[1][0]+'.'+chan[1][1])
                        elif chan[1][6] == 'F':
                            infile = os.path.join(os.path.join(recordArchivefPath,chan[1][2]),chan[1][0]+'.'+chan[1][1])
                        else:
                            ###infile = os.path.join(os.path.join(path,chan[1][2]),chan[1][0]+'.'+chan[1][1])
                            infile = os.path.join(os.path.join(recordPath,chan[1][2]),chan[1][0]+'.'+chan[1][1])
                        contextMenu.append(('[COLOR yellow][B]Cast to first ChromeCast[/B][/COLOR]', 'RunPlugin(%s?mode=1041&url=%s)'% (sys.argv[0], infile)))
                        contextMenu.append(('[COLOR yellow][B]Stop Cast[/B][/COLOR]', 'RunPlugin(%s?mode=1042&url=%s)'% (sys.argv[0], infile)))
                    contextMenu.append(('[COLOR lightgreen][B]Search Again[/B][/COLOR]','Container.Update(%s?name=None&mode=%s&url=url&iconimage=None&cat=0)'% (sys.argv[0],view)))
                    ###contextMenu.append(('[COLOR lightgreen][B]Search Channels/VOD/TV Series[/B][/COLOR]','Container.Update(%s?name=None&mode=2008&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                    contextMenu.append(('[COLOR lightgreen][B]Search EPG Programs[/B][/COLOR]','Container.Update(%s?name=None&mode=2050&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                    contextMenu.append(('[COLOR lightgreen][B]Search Recorded[/B][/COLOR]','Container.Update(%s?name=None&mode=%s&url=None&iconimage=None&cat=%s)'% (sys.argv[0],view,cat)))
                    if definition.ADDONgetSetting('enable_record')=='true':
                        contextMenu.append(('[COLOR red][B]Planned Recordings[/B][/COLOR]','Container.Update(%s?name=None&mode=3&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                    contextMenu.append(('[COLOR lightgreen][B]Favorites (' + FavoritesCount + ')[/B][/COLOR]','Container.Update(%s?name=None&mode=17&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                    liz.addContextMenuItems(contextMenu,replaceItems=True)
                    if chan[1][6] == 'A':
                        url = os.path.join(os.path.join(recordArchivePath,chan[1][2]),chan[1][0]+'.'+chan[1][1])
                    elif chan[1][6] == 'B':
                        url = os.path.join(os.path.join(recordArchivebPath,chan[1][2]),chan[1][0]+'.'+chan[1][1])
                    elif chan[1][6] == 'F':
                        url = os.path.join(os.path.join(recordArchivefPath,chan[1][2]),chan[1][0]+'.'+chan[1][1])
                    else:
                        ###url = os.path.join(os.path.join(path,chan[1][2]),chan[1][0]+'.'+chan[1][1])
                        url = os.path.join(os.path.join(recordPath,chan[1][2]),chan[1][0]+'.'+chan[1][1])
                    log('err Database Search url= %r' % url)
                    nowJust = datetime.today().replace(microsecond=0)
                    if nowJust > nowM + timedelta(seconds = searchtimemax):
                        if not searchtimereached:
                            searchtimereached = True
                            break   ### 2019-09-25
                    if filecount < filecountmax and not searchtimereached:
                        filecount += 1
                        usedtime = str(int((nowJust-nowM).total_seconds()))
                        xbmcplugin.addDirectoryItem(handle = Handle, url=url,listitem = liz, isFolder = False)
                    else:
                        break
            c.close()
            ### 2019-12-25
            if filecount == 0 :
                liz=xbmcgui.ListItem('[COLOR red][B]No files found[/B][/COLOR]')
                liz.setArt({ 'icon': "DefaultVideo.png", 'thumb' : "DefaultVideo.png" })
                liz.setInfo( type="Video", infoLabels={ "Title": 'Nothing found', "Plot":"Use menu on this line to Execute/Update the file database"})
                liz.setProperty("IsPlayable","false")
                contextMenu = []
                contextMenu.append(('[COLOR orange][B]Execute/Update Database[/B][/COLOR]', 'RunPlugin(%s?mode=1025&url=url&name=&recordname=&description=)'% (sys.argv[0])))
                contextMenu.append(('[COLOR blue][B]Stop Player/Set Video Volumen[/B][/COLOR]', 'RunPlugin(%s?mode=10232&url=url&name=exupd&recordname=&description=)'% (definition.DRLYD())))    ### 2024-06-22
                contextMenu.append(('[COLOR blue][B]Audio Volumen %[/B][/COLOR]', 'RunPlugin(%s?mode=10233&url=url&name=mute&recordname=&description=)'% (definition.DRLYD())))    ### 2024-06-22
                liz.addContextMenuItems(contextMenu,replaceItems=True)
                xbmcplugin.addDirectoryItem(handle = Handle, url='url',listitem = liz, isFolder = False)

            
            if filecount > 0 and filecount < filecountmax and not searchtimereached:
                usedtime = str(int((nowJust-nowM).total_seconds()))
                addDir('[COLOR lightgreen][B]Search finished in '+usedtime+' seconds, found '+str(filecount)+' files[/B][/COLOR]\n[I]' +recordings.humantimestop(nowM)+' ==> ' +recordings.humantimestop(nowJust)+ '[/I]' ,'url',int(view),'','0','0','Searched for: '+searchText+'[CR][CR]Search in Database','0','0','')
            if filecount >= filecountmax:
                ###addDir('[COLOR red]Search limit reached: '+str(filecountmax-1)+'[/COLOR]','url',6,'','','','Refine your search to reduce number of hits')
                usedtime = str(int((nowJust-nowM).total_seconds()))
                addDir('[COLOR red][B]Search limit reached ('+str(searchcountmax)+' in '+usedtime+' seconds)[/B][/COLOR]\n[I]' +recordings.humantimestop(nowM)+' ==> ' +recordings.humantimestop(nowJust)+'[/I]' ,'url',5011,'','0','0','Limit your search!\n\nClick to change limit[CR][CR]Searched for: '+searchText+'[CR][CR]Search in Database','0','0','')
            if searchtimereached:
                ###addDir('[COLOR red]Search time limit reached: ('+str(searchtimemax)+' secondes)[/COLOR]','url',6,'','','','Refine your search to reduce number of hits')
                addDir('[COLOR red][B]Search time reached ('+str(searchtimemax)+' seconds - Found '+str(filecount)+' files)[/B][/COLOR]\n[I]' +recordings.humantimestop(nowM)+' ==> ' +recordings.humantimestop(nowJust)+'[/I]','url',5010,'','0','0','Limit your search!\n\nClick to change limit[CR][CR]Searched for: '+searchText+'[CR][CR]Search in Database','0','0','')
            
        elif view == '67': ### search descriptions
            for descfile in find_files(path,'*.txt'):
                if os.path.isfile(descfile):
                    try:               ### Description:
                        descf = open(descfile,'r')
                        desc = descf.read()
                        descf.close()
                        desc = desc.split('Description:')[1]
                        ###log('desc= ' + repr(desc))
                    except Exception as e: 
                        log('err 6182 Except: %r' % e)
                        pass
                        desc = ''
                        log('desc ERROR= ' + repr(e))
                if searchText.lower() in desc.lower():
                    ###addDir(descfile,'url',67,'','','',desc)
                    ###descfilename = os.path.basename(descfile).replace('.txt','.*').replace('[','*').replace(']','*').replace('(','*').replace(')','*')
                    descfilename = descfile.replace('.txt','.*').replace('[','*').replace(']','*').replace('(','*').replace(')','*')
                    ###dialog = xbmcgui.Dialog()
                    ###dialog.ok(ADDONname, 'Fundet i description:', descfilename)
                    vodfiles = glob.glob(descfilename)
                    ###dialog.ok(ADDONname, 'Fundet i description:', repr(vodfiles))
                    for vodfile in vodfiles:
                        if isExtKnown(vodfile):
                            ###addDir(os.path.basename(vodfile),'url',67,'','','',desc)
                            Genre = str(vodfile)
                            log('Genre 5501= %r' % Genre)
                            liz=xbmcgui.ListItem(highlight(os.path.basename(vodfile), searchText))
                            liz.setArt({ 'icon': "DefaultVideo.png", 'thumb' : "DefaultVideo.png" })
                            liz.setInfo( type="Video", infoLabels={ "Title": os.path.basename(vodfile).replace('/','/ ').replace('\\','\\ '), "Plot":highlight(desc, searchText),"Genre":Genre})
                            liz.setProperty("IsPlayable","true")
                            contextMenu = []
                            contextMenu.append(('[COLOR brown][B]View: '+'3'+'[/B][/COLOR]','Container.Update(%s?name=Home&mode=None&url=None&iconimage=None&cat=None)'% (sys.argv[0])))
                            contextMenu.append(('[COLOR yellow][B]Home[/B][/COLOR]','Container.Update(%s?name=Home&mode=None&url=None&iconimage=None&cat=None)'% (sys.argv[0])))
                            ###contextMenu.append(('[COLOR orange][B]Rename[/B][/COLOR]', 'RunPlugin(%s?mode=1023&url=%s&name=%s)'% (sys.argv[0], vodfile,'L')))
                            contextMenu.append(('[COLOR lightgreen][B]Search Again[/B][/COLOR]','Container.Update(%s?name=None&mode=%s&url=url&iconimage=None&cat=0)'% (sys.argv[0],view)))
                            contextMenu.append(('[COLOR lightgreen][B]Search Channels and VOD[/B][/COLOR]','Container.Update(%s?name=None&mode=2008&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                            contextMenu.append(('[COLOR lightgreen][B]Search EPG Programs[/B][/COLOR]','Container.Update(%s?name=None&mode=2050&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                            contextMenu.append(('[COLOR lightgreen][B]Search Recorded[/B][/COLOR]','Container.Update(%s?name=None&mode=%s&url=None&iconimage=None&cat=%s)'% (sys.argv[0],view,cat)))
                            contextMenu.append(('[COLOR red][B]Planned Recordings[/B][/COLOR]','Container.Update(%s?name=None&mode=3&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                            contextMenu.append(('[COLOR lightgreen][B]Favorites (' + FavoritesCount + ')[/B][/COLOR]','Container.Update(%s?name=None&mode=17&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                            liz.addContextMenuItems(contextMenu,replaceItems=True)
                            xbmcplugin.addDirectoryItem(handle = Handle, url=vodfile,listitem = liz, isFolder = False)
            
            for archive in [recordArchivePath,recordArchivebPath]:
                for descfile in find_files(archive, '*.txt'):
                    if os.path.isfile(descfile):
                        try:               ### Description:
                            descf = open(descfile,'r')
                            desc = descf.read()
                            descf.close()
                            desc = desc.split('Description:')[1]
                            ###log('desc= ' + repr(desc))
                        except Exception as e: 
                            log('err 6223 Except: %r' % e)
                            pass
                            desc = ''
                            log('desc ERROR= ' + repr(e))
                    if searchText.lower() in desc.lower():
                        ###addDir(descfile,'url',67,'','','',desc)
                        ###descfilename = os.path.basename(descfile).replace('.txt','.*').replace('[','*').replace(']','*').replace('(','*').replace(')','*')
                        descfilename = descfile.replace('.txt','.*').replace('[','*').replace(']','*').replace('(','*').replace(')','*')
                        ###dialog = xbmcgui.Dialog()
                        ###dialog.ok(ADDONname, 'Fundet i description:', descfilename)
                        vodfiles = glob.glob(descfilename)
                        ###dialog.ok(ADDONname, 'Fundet i description:', repr(vodfiles))
                        for vodfile in vodfiles:
                            if isExtKnown(vodfile):
                                ###addDir(os.path.basename(vodfile),'url',67,'','','',desc)
                                Genre = str(vodfile)
                                log('Genre 5540= %r' % Genre)
                                liz=xbmcgui.ListItem(highlight(os.path.basename(vodfile), searchText))
                                liz.setArt({ 'icon': "DefaultVideo.png", 'thumb' : "DefaultVideo.png" })
                                liz.setInfo( type="Video", infoLabels={ "Title": os.path.basename(vodfile).replace('/','/ ').replace('\\','\\ '), "Plot":highlight(desc, searchText),"Genre":Genre})
                                liz.setProperty("IsPlayable","true")
                                contextMenu = []
                                contextMenu.append(('[COLOR brown][B]View: '+'2'+'[/B][/COLOR]','Container.Update(%s?name=Home&mode=None&url=None&iconimage=None&cat=None)'% (sys.argv[0])))
                                contextMenu.append(('[COLOR yellow][B]Home[/B][/COLOR]','Container.Update(%s?name=Home&mode=None&url=None&iconimage=None&cat=None)'% (sys.argv[0])))
                                ###contextMenu.append(('[COLOR orange][B]Rename[/B][/COLOR]', 'RunPlugin(%s?mode=1023&url=%s&name=%s)'% (sys.argv[0], vodfile,'A')))
                                contextMenu.append(('[COLOR lightgreen][B]Search Again[/B][/COLOR]','Container.Update(%s?name=None&mode=%s&url=url&iconimage=None&cat=0)'% (sys.argv[0],view)))
                                contextMenu.append(('[COLOR lightgreen][B]Search Channels and VOD[/B][/COLOR]','Container.Update(%s?name=None&mode=2008&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                                contextMenu.append(('[COLOR lightgreen][B]Search EPG Programs[/B][/COLOR]','Container.Update(%s?name=None&mode=2050&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                                contextMenu.append(('[COLOR lightgreen][B]Search Recorded[/B][/COLOR]','Container.Update(%s?name=None&mode=%s&url=None&iconimage=None&cat=%s)'% (sys.argv[0],view,cat)))
                                contextMenu.append(('[COLOR red][B]Planned Recordings[/B][/COLOR]','Container.Update(%s?name=None&mode=3&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                                contextMenu.append(('[COLOR lightgreen][B]Favorites (' + FavoritesCount + ')[/B][/COLOR]','Container.Update(%s?name=None&mode=17&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                                
                                liz.addContextMenuItems(contextMenu,replaceItems=True)
                                xbmcplugin.addDirectoryItem(handle = Handle, url=vodfile,listitem = liz, isFolder = False)
                
        else:
            ###conf = recordings.getFilesConnection()
            ###recordings.createFileTable(conf)
            ###c = conf.cursor()
            for infile in find_files(path, '*'):
                filesallA.append([infile,infile.lower()])
            """
                try:
                    fileext = ''
                    fileextt = ''
                    if '.' in infile:
                        fileext = infile.split('.')[-1]
                        fileextt = '.' + fileext
                except Exception as e:
                    pass
                    fileext = repr(e)
                    fileextt = fileext
                infilebasename = os.path.basename(infile).replace(fileextt,'',-1) # the file name only
                pathoffile = os.path.dirname(infile).replace(path[:-1],'',1)
                if len(path)>0:
                    pathoffile = os.path.dirname(infile).replace(path[:-1],'',1)
                    if len(pathoffile) >0:
                        pathoffile = pathoffile[1:]
                else:
                    pathoffile = ''
                video = repr(isExtKnown(infile))
                descriptionfilename = infile.replace(fileextt,'.txt',-1)
                if video == 'True' and os.path.isfile(descriptionfilename):
                    try:               ### Description:
                        descf = open(descriptionfilename,'r')
                        desc = descf.read()
                        descf.close()
                        description = 'Description:\n' + desc.split('Description:')[1]
                        ###log('desc= ' + repr(desc))
                    except Exception as e: 
                        pass
                        description = ''
                        log('description ERROR= ' + repr(e))
                else:
                    description = ''
                log('infile= %r, infilebasename= %r' % (infile, infilebasename))
                log('pathoffile= %r, path= %r,  os.path.dirname(infile)= %r' % (pathoffile, path, os.path.dirname(infile)))
                recordings.addFile(c, infilebasename, fileext, pathoffile, video, description, repr(os.stat(infile).st_size), 'L')  ### No archive
            conf.commit()
            c.close()
            """
            for infileA in filesallA:
                infile = infileA[0]
                if isExtKnown(infile):
                    searchTextA = searchText.lower().split('%')
                    ###log('searchTextA= %r' % searchTextA)
                    hit    = 0
                    hits   = 0
                    hitall = len(searchTextA)
                    ###log('***hitall= %r' % (hitall))
                    for searchTextB in searchTextA:
                        ###log('searchTextB= %r' % searchTextB)
                        hits += 1
                        if searchTextB in infileA[1]:
                            hit += 1
                            ###log('hit= %r, hits= %r' % (hit,hits))
                    if hit == hitall and hit > 0 and not searchtimereached:
                        nowJust = datetime.today().replace(microsecond=0)
                        if nowJust > nowM + timedelta(seconds = searchtimemax):
                            if not searchtimereached:
                                ###addDir('[COLOR red][B]Search time reached ('+str(searchtimemax)+' seconds)[/B][/COLOR]' ,'',0,'','0','0','Limit your search!\n\nClick to change limit','0','0','')
                                searchtimereached = True
                        if filecount < filecountmax and not searchtimereached:
                            log('Search filename= %r' % infile)
                            ###name = infile.replace(recordPath,'',1).replace(recordArchivePath,'',1)
                            try:
                                name = infile.replace('/','¤').replace('\\','¤').split('¤')[-1]
                            except Exception as e:
                                log('err 6329 Except: %r' % e)
                                pass
                                name = repr(e)
                            filecount += 1
                            usedtime = str(int((nowJust-nowM).total_seconds()))
                            log( 'filecount= %r, nowM= %r, nowJust= %r, usedtime= %r, searchtimereached= %r' % (filecount, nowM, nowJust, usedtime, searchtimereached))
                            files.append([name,infile,int(os.path.getmtime(infile))])
            
            ###if filecount < filecountmax and not searchtimereached:
            if filecount < filecountmax and not searchtimereached and not view == '2060':  ### Latest recordings only from local store
                #filesA =  glob.glob(os.path.join(recordArchivePath, '*'))
                filesallA = []
                #for infile in filesA:
                ###conf = recordings.getFilesConnection()
                ###recordings.createFileTable(conf)
                ###c = conf.cursor()
                for infile in find_files(recordArchivePath, '*'):
                    filesallA.append([infile,infile.lower()])
                for infile in find_files(recordArchivebPath, '*'):
                    filesallA.append([infile,infile.lower()])
                """    try:
                        fileext = ''
                        fileextt = ''
                        if '.' in infile:
                            fileext = infile.split('.')[-1]
                            fileextt = '.' + fileext
                    except Exception as e:
                        pass
                        fileext = repr(e)
                        fileextt = fileext
                    infilebasename = os.path.basename(infile).replace(fileextt,'',-1) # the file name only
                    if len(recordArchivePath)>0:
                        pathoffile = os.path.dirname(infile).replace(recordArchivePath[:-1],'',1)
                        if len(pathoffile) >0:
                            pathoffile = pathoffile[1:]
                    else:
                        pathoffile = ''
                    log('infile= %r, infilebasename= %r' % (infile, infilebasename))
                    log('pathoffile= %r, recordArchivePath= %r' % (pathoffile, recordArchivePath))
                    video = repr(isExtKnown(infile))
                    descriptionfilename = infile.replace(fileextt,'.txt',-1)
                    if video == 'True' and os.path.isfile(descriptionfilename):
                        try:               ### Description:
                            descf = open(descriptionfilename,'r')
                            desc = descf.read()
                            descf.close()
                            description = 'Description:\n' + desc.split('Description:')[1]
                            ###log('desc= ' + repr(desc))
                        except Exception as e: 
                            pass
                            description = ''
                            log('description ERROR= ' + repr(e))
                    else:
                        description = ''
                    recordings.addFile(c, infilebasename, fileext, pathoffile, video, description, repr(os.stat(infile).st_size), 'A')  ### archive
                conf.commit()
                c.close()
                """
                ###for infile in find_files(recordArchivePath, '*'):
                ###    filesallA.append([infile,infile.lower()])
                for infileA in filesallA:
                    infile = infileA[0]
                    ###if not infile[-4:].lower()=='.zip' and not infile[-4:].lower()=='.txt' and not infile[-4:].lower()=='.srt' and not infile[-4:].lower()=='.ini' and not infile[-4:].lower()=='.nfo' and not infile[-4:].lower()=='.log':
                    if isExtKnown(infile):
                    ###if infile[-3:].lower()=='.ts' or infile[-4:].lower()=='.mp4'  or infile[-4:].lower()=='.mkv' or infile[-4:].lower()== '.avi' or infile[-4:].lower() == '.m4v' or infile[-4:].lower()=='.flv' or infile[-ffmpegoutputtypelen:].lower()==ffmpegoutputtype:
                        searchTextA = searchText.lower().split('%')
                        ###log('searchTextA= %r' % searchTextA)
                        hit    = 0
                        hits   = 0
                        hitall = len(searchTextA)
                        ###log('***hitall= %r' % (hitall))
                        for searchTextB in searchTextA:
                            ###log('searchTextB= %r' % searchTextB)
                            hits += 1
                            if searchTextB in infileA[1]:
                                hit += 1
                                ###log('hit= %r, hits= %r' % (hit,hits))
                        if hit == hitall and hit > 0 and not searchtimereached:
                            nowJust = datetime.today().replace(microsecond=0)
                            if nowJust > nowM + timedelta(seconds = searchtimemax):
                                if not searchtimereached:
                                    ###addDir('[COLOR red][B]Search time reached ('+str(searchtimemax)+' seconds)[/B][/COLOR]' ,'',0,'','0','0','Limit your search!\n\nClick to change limit','0','0','')
                                    searchtimereached = True
                            if filecount < filecountmax and not searchtimereached:
                                log('Search filename= %r' % infile)
                                ###name = infile.replace(recordPath,'',1).replace(recordArchivePath,'',1)
                                try:
                                    name = infile.replace('/','¤').replace('\\','¤').split('¤')[-1]
                                except Exception as e:
                                    log('err 6415 Except: %r' % e)
                                    pass
                                    name = repr(e)
                                filecount += 1
                                usedtime = str(int((nowJust-nowM).total_seconds()))
                                log( 'filecount= %r, nowM= %r, nowJust= %r, usedtime= %r, searchtimereached= %r' % (filecount, nowM, nowJust, usedtime, searchtimereached))
                                files.append([name,infile,int(os.path.getmtime(infile))])
            
            if filecount > 0 and filecount < filecountmax and not searchtimereached:
                usedtime = str(int((nowJust-nowM).total_seconds()))
                addDir('[COLOR lightgreen][B]Search finished in '+usedtime+' seconds, found '+str(filecount)+' files[/B][/COLOR]' ,'url',int(view),'','0','0','Searched for: '+searchText+'[CR][CR]'+searchPath+sortmethod,'0','0','')
            if filecount >= filecountmax:
                ###addDir('[COLOR red]Search limit reached: '+str(filecountmax-1)+'[/COLOR]','url',6,'','','','Refine your search to reduce number of hits')
                usedtime = str(int((nowJust-nowM).total_seconds()))
                addDir('[COLOR red][B]Search limit reached ('+str(searchcountmax)+' in '+usedtime+' seconds)[/B][/COLOR]' ,'url',5011,'','0','0','Limit your search!\n\nClick to change limit[CR][CR]Searched for: '+searchText+'[CR][CR]'+searchPath+sortmethod,'0','0','')
            if searchtimereached:
                ###addDir('[COLOR red]Search time limit reached: ('+str(searchtimemax)+' secondes)[/COLOR]','url',6,'','','','Refine your search to reduce number of hits')
                addDir('[COLOR red][B]Search time reached ('+str(searchtimemax)+' seconds - Found '+str(filecount)+' files)[/B][/COLOR]' ,'url',5010,'','0','0','Limit your search!\n\nClick to change limit[CR][CR]Searched for: '+searchText+'[CR][CR]'+searchPath+sortmethod,'0','0','')
            ###files1 = sorted(files, reverse=False)
            log('files= %r' % files)
            if view == '2060' or view == '66':
                files1 = sorted(files, key=itemgetter(2), reverse=True)
                log('files1(2060)= %r' % files1)
            else:
                files1 = sorted(files)
                log('files1= %r' % files1)
            for inxfile in files1:
                name   = inxfile[0]
                log('name[:1]=2 %r' % name[:1])
                if name[:1] == '[':    ### 2019-03-09
                    nameparts = name.split(']',1)
                    name = nameparts[1] + ' ' + nameparts[0] + ']'
                    name = name.strip()
                infile = inxfile[1]
                infilecreated = inxfile[2]
                if os.path.isdir(infile):
                    ###name = infile.replace(recordPath,'',1).replace(recordArchivePath,'',1)
                    liz=xbmcgui.ListItem(name)
                    liz.setArt({ 'icon': "DefaultVideo.png", 'thumb' : "DefaultVideo.png" })
                    liz.setInfo( type="Folder", infoLabels={ "Title": str(name).replace('/','/ ').replace('\\','\\ ')})
                    liz.setProperty("IsPlayable","false")
                    contextMenu = []
                    ###contextMenu.append(('[COLOR red][B]Grab from %s[/B][/COLOR]'% (activetvguide),'Container.Update(%s?name=None&mode=3000&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                    contextMenu.append(('[COLOR brown][B]View: '+'1'+'[/B][/COLOR]','Container.Update(%s?name=Home&mode=None&url=None&iconimage=None&cat=None)'% (sys.argv[0])))
                    contextMenu.append(('[COLOR yellow][B]Home[/B][/COLOR]','Container.Update(%s?name=Home&mode=None&url=None&iconimage=None&cat=None)'% (sys.argv[0])))
                    contextMenu.append(('[COLOR lightgreen][B]Search Channels and VOD[/B][/COLOR]','Container.Update(%s?name=None&mode=2008&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                    contextMenu.append(('[COLOR lightgreen][B]Search EPG Programs[/B][/COLOR]','Container.Update(%s?name=None&mode=2050&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                    contextMenu.append(('[COLOR lightgreen][B]Search Recorded[/B][/COLOR]','Container.Update(%s?name=None&mode=%s&url=None&iconimage=None&cat=%s)'% (sys.argv[0],view,cat)))
                    contextMenu.append(('[COLOR red][B]Planned Recordings[/B][/COLOR]','Container.Update(%s?name=None&mode=3&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                    contextMenu.append(('[COLOR lightgreen][B]Favorites (' + FavoritesCount + ')[/B][/COLOR]','Container.Update(%s?name=None&mode=17&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                    contextMenu.append(('[COLOR orange][B]Refresh[/B][/COLOR]','RunPlugin(%s?name=None&mode=2004&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
                    if isTimeShiftActive():
                        contextMenu.append(('[COLOR red][B]Stop Timeshift Recording[/B][/COLOR]','RunPlugin(%s?name=None&mode=30&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
                    contextMenu.append(('[COLOR red][B]Back to Kodi[/B][/COLOR]','RunPlugin(%s?name=None&mode=29&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
                    contextMenu.append(('[COLOR orange][B]Delete Folder (if empty)[/B][/COLOR]', 'RunPlugin(%s?mode=103&url=%s)'% (sys.argv[0], infile)))
                    liz.addContextMenuItems(contextMenu,replaceItems=True)
                    xbmcplugin.addDirectoryItem(handle = Handle, url=infile,listitem = liz, isFolder = True)
                else:
                    if isExtKnown(infile):
                        descfile = infile.replace('.flv','.txt').replace('.mp4','.txt').replace('.mkv','.txt').replace('.avi','.txt').replace('.m4v','.txt').replace('.ts','.txt')
                        log('descfile= ' + repr(descfile))
                        desc = ''
                        if os.path.isfile(descfile):
                            try:               ### Description:
                                descf = open(descfile,'r')
                                desc = descf.read()
                                descf.close()
                                desc = desc.split('Description:')[1]
                                log('desc= ' + repr(desc))
                            except Exception as e: 
                                log('err 6483 Except: %r' % e)
                                pass
                                log('desc ERROR= ' + repr(e))
                        createdtime = datetime.fromtimestamp(infilecreated).strftime("%Y-%m-%d %H:%M")
                        desc =  'Created: ' + createdtime + '\n' + infile + '\n\n' + desc + '\n\n' + infile
                        desc = desc.replace('/B','¤B').replace('/C','¤C').replace('/I','¤I').replace('/','/ ').replace('\\','\\ ').replace('¤B','/B').replace('¤C','/C').replace('¤I','/I')
                        displayname = name.replace('[',' '*80 + '\n[COLOR lemonchiffon][I][',1)
                        if '\n[COLOR lemonchiffon][I][' in displayname:
                            displayname += '[/COLOR][/I]'
                        Genre = utils.utf(str(infile))
                        log('Genre 5795= %r' % Genre)
                        liz=xbmcgui.ListItem(highlight(displayname, searchText))
                        liz.setArt({ 'icon': "DefaultVideo.png", 'thumb' : "DefaultVideo.png" })
                        liz.setInfo( type="Video", infoLabels={ "Title": str(name).replace('/','/ ').replace('\\','\\ '), "Plot":highlight(desc, searchText),"Genre":Genre})
                        liz.setProperty("IsPlayable","true")
                        contextMenu = []
                        contextMenu.append(('[COLOR brown][B]View: '+'6'+'[/B][/COLOR]','Container.Update(%s?name=Home&mode=None&url=None&iconimage=None&cat=None)'% (sys.argv[0])))
                        contextMenu.append(('[COLOR yellow][B]Home[/B][/COLOR]','Container.Update(%s?name=Home&mode=None&url=None&iconimage=None&cat=None)'% (sys.argv[0])))
                        contextMenu.append(('[COLOR lightgreen][B]Search Channels and VOD[/B][/COLOR]','Container.Update(%s?name=None&mode=2008&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                        contextMenu.append(('[COLOR lightgreen][B]Search EPG Programs[/B][/COLOR]','Container.Update(%s?name=None&mode=2050&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                        contextMenu.append(('[COLOR lightgreen][B]Search Recorded[/B][/COLOR]','Container.Update(%s?name=None&mode=%s&url=None&iconimage=None&cat=%s)'% (sys.argv[0],view,cat)))
                        contextMenu.append(('[COLOR red][B]Planned Recordings[/B][/COLOR]','Container.Update(%s?name=None&mode=3&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                        contextMenu.append(('[COLOR lightgreen][B]Favorites (' + FavoritesCount + ')[/B][/COLOR]','Container.Update(%s?name=None&mode=17&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                        contextMenu.append(('[COLOR orange][B]Refresh[/B][/COLOR]','RunPlugin(%s?name=None&mode=2004&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
                        if isTimeShiftActive():
                            contextMenu.append(('[COLOR red][B]Stop Timeshift Recording[/B][/COLOR]','RunPlugin(%s?name=None&mode=30&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
                        contextMenu.append(('[COLOR red][B]Back to Kodi[/B][/COLOR]','RunPlugin(%s?name=None&mode=29&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
                        contextMenu.append(('[COLOR orange][B]Rename[/B][/COLOR]', 'RunPlugin(%s?mode=1022&url=%s)'% (sys.argv[0], infile)))
                        contextMenu.append(('[COLOR orange][B]Convert[/B][/COLOR]', 'RunPlugin(%s?mode=1040&url=%s)'% (sys.argv[0], infile)))
                        if chromecast: 
                            contextMenu.append(('[COLOR yellow][B]Cast to first ChromeCast[/B][/COLOR]', 'RunPlugin(%s?mode=1041&url=%s)'% (sys.argv[0], infile)))
                            contextMenu.append(('[COLOR yellow][B]Stop Cast[/B][/COLOR]', 'RunPlugin(%s?mode=1042&url=%s)'% (sys.argv[0], infile)))
                        contextMenu.append(('[COLOR orange][B]Delete[/B][/COLOR]', 'RunPlugin(%s?mode=102&url=%s)'% (sys.argv[0], infile)))
                        liz.addContextMenuItems(contextMenu,replaceItems=True)
                        ###log('xbmcplugin.addDirectoryItem(handle = Handle= %s, url=infile= %s,listitem = liz= %s, isFolder = False)' % (repr(Handle),repr(infile),repr(liz)))
                        xbmcplugin.addDirectoryItem(handle = Handle, url=infile,listitem = liz, isFolder = False)
            
            if filecount == 0 and not searchtimereached:
                nowJust = datetime.today().replace(microsecond=0)
                usedtime = str(int((nowJust-nowM).total_seconds()))
                addDir('[COLOR lightgreen][B]Search finished in '+usedtime+' seconds, no files found[/B][/COLOR]' ,'url',int(view),'','0','0','Searched for: '+searchText+'[CR][CR]'+searchPath+sortmethod,'0','0','')
            if filecount > 0 and filecount < filecountmax and not searchtimereached:
                usedtime = str(int((nowJust-nowM).total_seconds()))
                addDir('[COLOR lightgreen][B]Search finished in '+usedtime+' seconds, found '+str(filecount)+' files[/B][/COLOR]' ,'url',int(view),'','0','0','Searched for: '+searchText+'[CR][CR]'+searchPath+sortmethod,'0','0','')
            if filecount >= filecountmax:
                usedtime = str(int((nowJust-nowM).total_seconds()))
                addDir('[COLOR red][B]Search limit reached ('+str(searchcountmax)+' in '+usedtime+' seconds)[/B][/COLOR]' ,'url',5011,'','0','0','Limit your search!\n\nClick to change limit[CR][CR]Searched for: '+searchText+'[CR][CR]'+searchPath+sortmethod,'0','0','')
            if searchtimereached:
                addDir('[COLOR red][B]Search time reached ('+str(searchtimemax)+' seconds - Found '+str(filecount)+' files)[/B][/COLOR]' ,'url',5010,'','0','0','Limit your search!\n\nClick to change limit[CR][CR]Searched for: '+searchText+'[CR][CR]'+searchPath+sortmethod,'0','0','')
    setView('movies', 'movies')

def DataBases():
    GoHome('Restore Planned Recordings')
    path = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
    files =  glob.glob(os.path.join(path, '*'))
    
    files1 = sorted(files, reverse=True)
    log('DOWNLOADS: files1= %r' % files1)
    index = 0
    BackupCount = utils.intADDONgetSetting('BackupCount')
    for infile in files1:
        if index < BackupCount:
            ###index += 1
            try:
                
                if infile[-3:].lower()=='.db':
                    name = infile.replace(path,'').replace('.db','')
                    ############################# How many records/recursive?
                    count = recordings.RecursiveRecordingsCount(infile)
                    user  = name.split('-')[1]
                    X = name.split('-')[0]
                    date  = X[:4]+'-'+X[4]+X[5]+'-'+X[6]+X[7]+' '+X[8]+X[9]+':'+X[10]+X[11]+':'+X[12]+X[13]
                    desc  = 'Date: ' + date + '\nUser: ' + user + '\n' +count.replace(' (P','Programs: ').replace('/R','\nRecursive programs: ').replace(')','')
                    ###liz=xbmcgui.ListItem(name + count, iconImage="DefaultFile.png", thumbnailImage="DefaultFile.png")
                    liz=xbmcgui.ListItem(date + ' ' + user + count)
                    liz.setArt({ 'icon': "DefaultVideo.png", 'thumb' : "DefaultVideo.png" })
                    liz.setInfo( type="Video", infoLabels={ "Title": str(name).replace('/','/ ').replace('\\','\\ '), "Plot":desc})   ### TEST 2018-01-25
                    liz.setProperty("IsPlayable","false")
                    contextMenu = []
                    activeDB = recordings.RECORDS_DB.split('.')[0]
                    
                    if not name == activeDB: 
                        contextMenu.append(('[COLOR orange][B]Restore Backup[/B][/COLOR]', 'RunPlugin(%s?mode=105&url=%s)'% (sys.argv[0], infile)))
                        contextMenu.append(('[COLOR orange][B]Restore Channels[/B][/COLOR]', 'RunPlugin(%s?mode=113&url=%s)'% (sys.argv[0], infile)))
                        contextMenu.append(('[COLOR orange][B]Restore Recursive Channels[/B][/COLOR]', 'RunPlugin(%s?mode=118&url=%s)'% (sys.argv[0], infile)))
                        contextMenu.append(('[COLOR orange][B]Restore Favorites[/B][/COLOR]', 'RunPlugin(%s?mode=117&url=%s)'% (sys.argv[0], infile)))
                        contextMenu.append(('[COLOR orange][B]Restore EPG[/B][/COLOR]', 'RunPlugin(%s?mode=114&url=%s)'% (sys.argv[0], infile)))
                        contextMenu.append(('[COLOR orange][B]Restore Recursive Records[/B][/COLOR]', 'RunPlugin(%s?mode=107&url=%s)'% (sys.argv[0], infile)))
                        contextMenu.append(('[COLOR orange][B]Rename[/B][/COLOR]', 'RunPlugin(%s?mode=1022&url=%s)'% (sys.argv[0], infile)))
                        contextMenu.append(('[COLOR orange][B]Delete[/B][/COLOR]', 'RunPlugin(%s?mode=102&url=%s)'% (sys.argv[0], infile)))
                        liz.addContextMenuItems(contextMenu,replaceItems=True)
                        xbmcplugin.addDirectoryItem(handle = Handle, url=infile,listitem = liz, isFolder = False)
                        index += 1
            except Exception as e:
                log('err 6575 Except: %r' % e)
                pass
                
    setView('movies', 'main-view')

def SetupxmlFiles():
    GoHome('Past setting.xml')
    path = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
    files =  glob.glob(os.path.join(path, '*'))
    defaultfile = os.path.join(path, recordings.SETTINGSXML)
    log('DOWNLOADS: files= %r' % files)
    files1 = sorted(files, reverse=True)
    log('DOWNLOADS: files1= %r' % files1)
    activeDB = recordings.SETTINGSXML.split('.')[0]+ ' - ' + utils.username(defaultfile)
    index = 0
    BackupCount = utils.intADDONgetSetting('BackupCount')
    for infile in files1:
        log('0 infile= %r' % infile)
        if index < BackupCount:
            log('1 infile= %r' % infile)
            ###index += 1
            try:
                
                log('infile[-4:].lower()= %r' % infile[-4:].lower())
                if infile[-4:].lower()=='.xml':
                    log('infile(.xml)= %r' % infile)
                    mail = utils.username(infile)
                    log('mail= %r' % mail)
                    ###folder = utils.folder(defaultfile)
                    ###log('folder= %r' % folder)
                    if mail != '':
                        name = infile.replace(path,'').replace('.xml','') + ' - ' + mail 
                        liz=xbmcgui.ListItem(name)
                        liz.setArt({ 'icon': "DefaultVideo.png", 'thumb' : "DefaultVideo.png" })
                        liz.setInfo( type="File", infoLabels={ "Title": str(name).replace('/','/ ').replace('\\','\\ ')})
                        liz.setProperty("IsPlayable","false")
                        contextMenu = []
                        ###if not name == activeDB and '@' in mail:
                        if not name == activeDB: 
                            contextMenu.append(('[COLOR orange][B]Restore settings.xml[/B][/COLOR]', 'RunPlugin(%s?mode=106&url=%s)'% (sys.argv[0], infile)))
                            contextMenu.append(('[COLOR orange][B]Rename[/B][/COLOR]', 'RunPlugin(%s?mode=1022&url=%s)'% (sys.argv[0], infile)))
                            contextMenu.append(('[COLOR orange][B]Convert[/B][/COLOR]', 'RunPlugin(%s?mode=1040&url=%s)'% (sys.argv[0], infile)))
                            if chromecast: 
                                contextMenu.append(('[COLOR yellow][B]Cast to first ChromeCast[/B][/COLOR]', 'RunPlugin(%s?mode=1041&url=%s)'% (sys.argv[0], infile))) 
                                contextMenu.append(('[COLOR yellow][B]Stop Cast[/B][/COLOR]', 'RunPlugin(%s?mode=1042&url=%s)'% (sys.argv[0], infile)))
                            contextMenu.append(('[COLOR orange][B]Delete[/B][/COLOR]', 'RunPlugin(%s?mode=102&url=%s)'% (sys.argv[0], infile)))
                            liz.addContextMenuItems(contextMenu,replaceItems=True)
                            xbmcplugin.addDirectoryItem(handle = Handle, url=infile,listitem = liz, isFolder = False)
                            index += 1
            except Exception as e:
                log('err 6624 Except: %r' % e)
                pass
                log('SetupxmlFiles %r  Failed ERROR: %r' % (infile,e))
                
    setView('movies', 'main-view')


def deleteFile(file):
    tries    = 0
    maxTries = 2
    while os.path.exists(file) and tries < maxTries:
        try:
            log( 'removeFile: %s' % file ) # Put in LOG
            os.remove(file)
            break
        except Exception as e:
            pass
            log('err 6639 Except: %r' % e)
            log( 'ERROR Failed #= %d' % tries)  # Put in LOG
            sleep(500)
            tries = tries + 1

def deleteDir(file):
    tries    = 0
    maxTries = 10
    while os.path.exists(file) and tries < maxTries:
        try:
            log('err removeDir: %s' % file)  # Put in LOG
            os.rmdir(file)
            break
        except Exception as e:
            pass
            log('err 6652 Except: %r' % e)
            log('ERROR Failed deleteDir #= %d' % tries) # Put in LOG
            sleep(500)
            tries = tries + 1

def deleteFolder(folder):
    try:
        for filename in os.listdir(folder):
            file_path = os.path.join(folder, filename)
            try:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    os.unlink(file_path)
                elif os.path.isdir(file_path):
                    shutil.rmtree(file_path)
            except Exception as e:
                pass
                log('err Failed to delete %s. Reason: %s' % (file_path, e))
    except Exception as e:
        pass
        log('err Failed to find folder %s. Reason: %s' % (folder, e))

def deleteMask(mask):
    log('err deleteMask(mask= %r)' % mask)
    files = glob.glob(mask)
    log('err deleteMask(files= %r)' % files)
    for file in files:
        log('err deleteMask(file= %r)' % file)
        deleteFile(file)

def get_sub_parameters(params,param):
    cleanedparams=params.replace('?','').replace('& ','aMp ').replace('&%20','aMp%20')   ### 2019-02-23 Accept &<space> in filename
    ###log('err cleanedparams= %r' % cleanedparams)
    if (params[len(params)-1]=='/'):
        params=params[0:len(params)-2]
        ###log('err 2 params= %r' % params)
    pairsofparams=cleanedparams.split('&')
    ###log('err pairsofparams= %r' % pairsofparams)
    
    for j in range(len(pairsofparams)):
        splitparams={}
        splitparams=pairsofparams[j].split('=',1)
        ###log('err splitparams= %r' % splitparams)
        ###log('err len(splitparams)= %r' % len(splitparams))
        if (len(splitparams))==2:
            log('err len(splitparams)== 2') 
            secondpart = utils.decode64(splitparams[1])
            ###log('err secondpart= %r' % secondpart)
            if '&' in secondpart:
                get_sub_parameters(splitparams[0]+'='+secondpart,param)
            else:
                param[splitparams[0]]= secondpart.replace('aMp ','& ').replace('aMp%20','&%20')
                ###log('err 0 param= %r' % param)
            
def get_params():
    log('err sys.argv= %r' % sys.argv)
    i = 0
    for x in sys.argv:
        log('err sys.argv [%r] x= %r' % (i,x))
        if i == 2:
            params=sys.argv[2]
            param={}
            get_sub_parameters(params,param)
            if 'uri=' in params:
                param['uriorg']= sys.argv[2].split('uri=')[1]
            """
            log('err params= %r' % params)
            log('err len(params)= %r' % len(params))
            if len(params)>=2:
                log('err 1 params= %r' % params)
                cleanedparams=params.replace('?','').replace('& ','aMp ').replace('&%20','aMp%20')   ### 2019-02-23 Accept &<space> in filename
                log('err cleanedparams= %r' % cleanedparams)
                if (params[len(params)-1]=='/'):
                    params=params[0:len(params)-2]
                    log('err 2 params= %r' % params)
                pairsofparams=cleanedparams.split('&')
                log('err pairsofparams= %r' % pairsofparams)
                param={}
                for j in range(len(pairsofparams)):
                    splitparams={}
                    splitparams=pairsofparams[j].split('=',1)
                    log('err splitparams= %r' % splitparams)
                    log('err len(splitparams)= %r' % len(splitparams))
                    if (len(splitparams))==2:
                        log('err len(splitparams)== 2') 
                        secondpart = utils.decode64(splitparams[1])
                        log('err secondpart= %r' % secondpart)
                        secondpairsofparams=secondpart.split('&')
                        log('err secondpairsofparams= %r' % secondpairsofparams)
                        
                        param[splitparams[0]]= secondpart.replace('aMp ','& ').replace('aMp%20','&%20')
                        log('err 0 param= %r' % param)
            """
        i += 1
    log('err 1 param= %r' % param)
    return param
"""
xbmcplugin.setContent(Handle, 'movies')
xbmcplugin.setPluginCategory(Handle, 'Comedy')
xbmcplugin.setPluginFanart(Handle, 'special://home/addons/plugins/video/Apple movie trailers II/fanart.png', color2='0xFFFF3300')
xbmcplugin.setProperty(Handle, 'Emulator', 'M.A.M.E.')
"""
def param(u,match):
    try:
        ###log('err param(u= %r, match= %r)' % (u,match))
        u = urllibunquote_plus(u)
        u = u.replace('& ','¤¤¤')
        x = u.split('&'+match+'=')[1].split('&')[0]
        x = x.replace('¤¤¤','& ')
    except Exception as e:
        log('err 6734 Except: %r' % e)
        pass
        log('err 1 param Except: %r' % e)
        try:
            x = u.split('?'+match+'=')[1].split('&')[0]
        except Exception as e:
            log('err 6739 Except: %r' % e)
            pass
            log('err 2 param Except: %r' % e)
            x = ''
    ###log('err x= %r' % x)
    return x

def isHighlighted(u):
    try:
        log('isHighlighted u= %r' % u)
        cat        = param(u,'cat')
        startDate  = param(u,'startDate')
        endDate    = param(u,'endDate')
        name       = '' ### param(u,'name')
        recordname = param(u,'name')
        
        ThisHighlight = '#cat=' + cat + '#startDate=' + startDate +'#endDate=' + endDate + '#name=' + name + '#recordname=' + recordname + '#'  
        log('HIGHLIGHT ThisHighlight= %r' % ThisHighlight)
        
        if ThisHighlight in highlightscmp:
            log('HIGHLIGHT set in URL u= %r' % u)
            return True
            """
            if not 'name=%5BCOLOR+red%5DHighLight%5B%2FCOLOR%5D' in u:
                u=u.replace('name=','name=%5BCOLOR+red%5DHighLight%5B%2FCOLOR%5D').replace('recordname=','recordname=%5BCOLOR+red%5DHighLight%5B%2FCOLOR%5D')
                log('HIGHLIGHT set in URL u= %r' % u)
            """
    except Exception as e:
        log('err 6766 Except: %r' % e)
        pass
        log('HIGHLIGHT failed u= %r, ERROR= %r' % (u,e))
    return False

def addDir(name,url,mode,iconimage='',cat='',date='',description='',startDate='',endDate='',recordname='',whatsup=''):
    ###def addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
    log('0 addDir(name= %s,url= %s,mode= %s,iconimage= %s,cat= %s,date= %s,description= %s)' % (name,url,mode,iconimage,cat,date,description))          
    name = utils.TwoLines(name)
    if cat == '' and not url == '':
        cat = recordings.catFromUrl(url)
    ###log('type(str(iconimage= %r))= %r' % (iconimage,type(str(iconimage))))
    ###if not type(str(iconimage)) == str:
    ###    iconimage = ''
    if 'www.touchsportstv.com' in iconimage:
        log('IconFromCat cat= %r' % cat)
        iconimage = 'https://raw.githubusercontent.com/krogsbell/Logos/master/'+str(cat)+'.png'
    if not type(str(description)) == str:
        description = ''
    ###if not type(str(cat)) == str:
    ### cat = ''
    log('1 addDir(name= %s,url= %s,mode= %s,iconimage= %s,cat= %s,date= %s,description= %s)' % (name,url,mode,iconimage,cat,date,description))
    try:
        u=sys.argv[0]+"?url="+urllibquote_plus(url)+"&mode="+str(mode)+"&name="+urllibquote_plus(name)+"&iconimage="+urllibquote_plus(iconimage)+"&cat="+urllibquote_plus(cat)+"&date="+urllibquote_plus(str(date))+"&description="+urllibquote_plus(recordings.latin1_to_ascii(description))+"&startDate="+urllibquote_plus(str(startDate))+"&endDate="+urllibquote_plus(str(endDate))+"&recordname="+urllibquote_plus(recordings.latin1_to_ascii(recordname)) 
    except Exception as e:
        log('err 6790 Except: %r' % e)
        pass
        log('Error in setting u\n' + repr(e))
        u=str(sys.argv[0])+"?url="+str(urllibquote_plus(url))+"&mode="+str(mode)+"&name="+str(name)+"&iconimage="+str(urllibquote_plus(iconimage))+"&cat="+str(cat)+"&date="+str(date)+"&description="+str(recordings.latin1_to_ascii(description))
    log('addDir args u= %r' % u)
    if startDate != '':
        u += "&startDate="+str(startDate)
    if endDate != '':
        u += "&endDate="+str(endDate)
    if whatsup != '':
        u += "&whatsup="+whatsup
    if isHighlighted(u):
        name = '[COLOR red][B]¤[/B][/COLOR]' + name + ' [COLOR red][B]SELECTED[/B][/COLOR]'
    
    ok=True
    log('addDir iconImage= %r' % iconimage)
    ###liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz=xbmcgui.ListItem(name)
    liz.setArt({ 'icon': iconimage, 'thumb' : iconimage })
    liz.setInfo( type="Video", infoLabels={ "Title": name,"Plot":description } )
    try: # Find the mode on entry = the actual view '3' = Planned Recordings
        view= sys.argv[2].split('mode=',1)[1].split('&')[0] 
    except Exception as e:
        log('err 6813 Except: %r' % e)
        pass
        try:
            modeidx = 0
            """
            Home - 0
            Favorites - 17 
            Planned Recordings - 3 
            My Account - 8
            Maintenance - 49
            Streams - 490
            """
            modetable = [0,17,3,8,49,490]
            modeidx = utils.intADDONgetSetting('StartView')
            log('1 modeidx= %r' % (modeidx))
            view = str(modetable[modeidx])
            log('1 mode= %r' % (view))
        except Exception as e:
            log('err 6830 Except: %r' % e)
            pass
            view= '0'
            log('view set to 0. modeidx= %r/ERROR: %r' % (modeidx,e))
    TVguide= utils.TVguide()
    activetvguide= definition.ADDONgetSetting('activetvguide')
    menu=[]
    
    if mode==200 or mode==12 or mode == 2020 or mode == 2001:
        defaultdocmenu = True
    else:
        defaultdocmenu = False
    KodiVersion = int(xbmc.getInfoLabel('System.BuildVersion')[:2])
    ###log('xbmc.getInfoLabel(System.BuildVersion)[:2]= %r' % KodiVersion)
    if KodiVersion < 17:  ### 2017-08-02 
        ###log('Use menu scroll!')
        try:
            scroll = definition.ADDONgetSetting('scroll')
            if scroll == '' or (scroll != 'top' and scroll != 'buttom'):
                scroll = 'top'
                definition.ADDONresetSetting('scroll',scroll)
        except Exception as e:
            log('err 6851 Except: %r' % e)
            pass
            scroll = 'top'
            definition.ADDONresetSetting('scroll',scroll)
    else:
        scroll = 'noscroll'
    ###utils.notification('scroll= ' + repr(scroll))
    
    if scroll == 'buttom':
        menu.append(('[COLOR yellow][B]Top[/B][/COLOR]','Container.Update(%s?name=None&mode=50&url=None&iconimage=None&cat=%s)'% (sys.argv[0],scroll)))
    menu.append(('[COLOR red][B]Back to Kodi[/B][/COLOR]','RunPlugin(%s?name=None&mode=29&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
    menu.append(('[COLOR blue][B]Switch Addon[/B][/COLOR]','RunPlugin(%s?name=None&mode=1030&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
    ###menu.append(('[COLOR brown][B]View: '+view+'[/B][/COLOR]','Container.Update(%s?name=Home&mode=None&url=None&iconimage=None&cat=None)'% (sys.argv[0])))
    menu.append(('[COLOR yellow][B]Home[/B][/COLOR]','Container.Update(%s?name=Home&mode=1&url=None&iconimage=None&cat=None)'% (sys.argv[0])))
    menu.append(('[COLOR blue][B]Audio Volumen %[/B][/COLOR]', 'RunPlugin(%s?mode=10233&url=url&name=mute&recordname=&description=)'% (definition.DRLYD())))    ### 2024-06-22
    menu.append(('[COLOR orange][B]Refresh[/B][/COLOR]','RunPlugin(%s?name=None&mode=2004&url=url&cat=0)'% (sys.argv[0])))
    menu.append(('[COLOR yellow][B]Maintenance[/B][/COLOR]','Container.Update(%s?name=Maintenance&mode=49&url=url&cat=0)'% (sys.argv[0])))
    menu.append(('[COLOR orange][B]Open Settings[/B][/COLOR]','Container.Update(%s?name=Maintenance&mode=52&url=url&cat=0)'% (sys.argv[0])))
    
    if definition.ADDONgetSetting('LastView') != 'FAVORITES':
        menu.append(('[COLOR lightgreen][B]Favorites (' + FavoritesCount + ')[/B][/COLOR]','Container.Update(%s?name=None&mode=17&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    if definition.ADDONgetSetting('enable_record')=='true' and not view == '3':
    ###if not view == '3':
        if scroll == 'top' or scroll == 'noscroll':
            menu.append(('[COLOR red][B]Planned Recordings[/B][/COLOR]','Container.Update(%s?name=None&mode=3&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    if definition.ADDONgetSetting('LastView') != 'DOWNLOADS':
        menu.append(('[COLOR red][B]Search Recordings in Database[/B][/COLOR]','Container.Update(%s?name=None&mode=2065&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))   ### 2024-02-01
    
    LastCommand= definition.ADDONgetSetting('LastCommand')
    LastMode= definition.ADDONgetSetting('LastMode')
    ### 2018-12-25
    if LastCommand != '' and LastMode != '' and defaultdocmenu:       
        menu.append(('[COLOR lightblue][B]Repeat: %r[/B][/COLOR]' % (LastCommand),'RunPlugin(%s?mode=%s&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],LastMode,urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
    LastCommand2= definition.ADDONgetSetting('LastCommand2') 
    LastMode2= definition.ADDONgetSetting('LastMode2') 
    if LastCommand2 != '' and LastMode2 != '' and defaultdocmenu:     
        menu.append(('[COLOR lightblue][B]Repeat2: %r[/B][/COLOR]' % (LastCommand2),'RunPlugin(%s?mode=%s&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],LastMode2,urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
    """                    
    if definition.ADDONgetSetting('enable_record')=='true' and not view == '3':
    ###if not view == '3':
        if scroll == 'top' or scroll == 'noscroll':
            menu.append(('[COLOR red][B]Planned Recordings[/B][/COLOR]','Container.Update(%s?name=None&mode=3&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    
    if definition.ADDONgetSetting('enable_record')=='true' and not view == '2065':
    ###if not view == '3':
        if scroll == 'top' or scroll == 'noscroll':
            menu.append(('[COLOR red][B]Search Recordings in Database 3[/B][/COLOR]','Container.Update(%s?name=None&mode=2065&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    """        
    if definition.ADDONgetSetting('tvguide')=='true' and defaultdocmenu:
        menu.append(('[COLOR yellow][B]TV Guide[/B][/COLOR]','Container.Update(%s?name=None&mode=4&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        if scroll == 'top' or scroll == 'noscroll' and defaultdocmenu:
            menu.append(('[COLOR yellow][B]Select TV Guide Channel[/B][/COLOR]','Container.Update(%s?name=None&mode=1004&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        if scroll == 'top' or scroll == 'noscroll' and (view == '4' or view == '2050'):
            menu.append(('[COLOR red][B]Delete EPG Entry[/B][/COLOR]','RunPlugin(%s?mode=6000&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(name)),urllibquote_plus(recordings.latin1_to_ascii(description))))) 
        log('len(higlights)= %r \nhiglights= %r' % (len(higlights),higlights))
        if scroll == 'top' or scroll == 'noscroll' and defaultdocmenu and highlightcount > 0 and(IPTVuser == 'test1' or 'krogsbell' in IPTVuser): 
            menu.append(('[COLOR red][B]Deselect All (' + str(highlightcount) + ')[/B][/COLOR]','RunPlugin(%s?mode=5001&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(name)),urllibquote_plus(recordings.latin1_to_ascii(description))))) 
        if scroll == 'top' or scroll == 'noscroll' and defaultdocmenu and (IPTVuser == 'test1' or 'krogsbell' in IPTVuser): 
            menu.append(('[COLOR red][B]Select[/B][/COLOR]','RunPlugin(%s?mode=5000&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(name)),urllibquote_plus(recordings.latin1_to_ascii(description))))) 
    if scroll == 'top' or scroll == 'noscroll':
        if activetvguide.replace('plugin.video.','') == 'none':
            menu.append(('[COLOR red][B]No EPG grab[/B][/COLOR]',''))  ### Do nothing
        else:
            log('activetvguide= %r, ADDONid= %r' % (activetvguide,ADDONid))
            if activetvguide.replace("'","").replace('"','') == ADDONid:
                menu.append(('[COLOR orange][B]Grab from %s[/B][/COLOR]'% ADDONrefer,'Container.Update(%s?name=None&mode=3000&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
            else:
                menu.append(('[COLOR orange][B]Grab from %s[/B][/COLOR]'% (activetvguide.replace('plugin.video.','')),'Container.Update(%s?name=None&mode=3000&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        menu.append(('[COLOR lightgreen][B]Search Channels and VOD[/B][/COLOR]','Container.Update(%s?name=None&mode=2008&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        menu.append(('[COLOR lightgreen][B]Search EPG Programs[/B][/COLOR]','Container.Update(%s?name=None&mode=2050&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        ###menu.append(('[COLOR red][B]Search Recordings in Database x[/B][/COLOR]','Container.Update(%s?name=None&mode=2065&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        if definition.ADDONgetSetting('sortalphabetic') == 'true':
            menu.append(('[COLOR lightgreen][B]Search Recordings Alphabetic[/B][/COLOR]','Container.Update(%s?name=None&mode=6&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        else:
            menu.append(('[COLOR lightgreen][B]Search Recordings by Date[/B][/COLOR]','Container.Update(%s?name=None&mode=66&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        menu.append(('[COLOR lightgreen][B]Latest Recordings[/B][/COLOR]','Container.Update(%s?name=None&mode=2060&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))

    if definition.ADDONgetSetting('enable_record')=='true':
        if not name[0:9] =='Recursive':
            if scroll == 'top' or scroll == 'noscroll' and defaultdocmenu:
                menu.append(('[COLOR red][B]RECORD[/B][/COLOR]','RunPlugin(%s?mode=2001&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(name)),urllibquote_plus(recordings.latin1_to_ascii(description))))) ###
                
            if scroll == 'top' or scroll == 'noscroll' and defaultdocmenu:
                menu.append(('[COLOR red][B]RECORD RECURSIVE[/B][/COLOR]','RunPlugin(%s?mode=2005&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
        if view == '3':
            if scroll == 'top' or scroll == 'noscroll' and defaultdocmenu:
                menu.append(('[COLOR red][B]MODIFY RECORD[/B][/COLOR]','RunPlugin(%s?mode=2003&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s)'% (sys.argv[0],urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)))))
            if scroll == 'top' or scroll == 'noscroll' and defaultdocmenu:
                menu.append(('[COLOR orange][B]DISABLE RECORD[/B][/COLOR]','RunPlugin(%s?mode=2006&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))  
            if scroll == 'top' or scroll == 'noscroll' and defaultdocmenu:
                menu.append(('[COLOR red][B]DELETE RECORD[/B][/COLOR]','RunPlugin(%s?mode=2002&url=%s&cat=%s&startDate=%s&endDate=%s&name=%s&recordname=%s)'% (sys.argv[0],urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(name)),urllibquote_plus(recordings.latin1_to_ascii(recordname)))))

        if definition.ADDONgetSetting('DebugRecording')=='true':
            if scroll == 'top' or scroll == 'noscroll':
                menu.append(('[COLOR green][B]Planned Recordings Debug[/B][/COLOR]','Container.Update(%s?name=None&mode=13&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))

    if definition.ADDONgetSetting('LastView') == 'FAVORITES':
        if scroll == 'buttom' or scroll == 'noscroll' and defaultdocmenu:
            menu.append(('[COLOR orange][B]Remove '+ADDONrefer+' Favourite[/B][/COLOR]','RunPlugin(%s?name=None&mode=77&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        if scroll == 'buttom' or scroll == 'noscroll' and defaultdocmenu:
            menu.append(('[COLOR orange][B]Modify '+ADDONrefer+' Favourite[/B][/COLOR]','RunPlugin(%s?name=None&mode=7&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    else:
        if scroll == 'buttom' or scroll == 'noscroll' and defaultdocmenu:
            menu.append(('[COLOR orange][B]Set '+ADDONrefer+' Favourite[/B][/COLOR]','RunPlugin(%s?name=None&mode=7&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))

    if definition.ADDONgetSetting('LastView') == 'RECURSIVECHANNELS':
        if scroll == 'buttom' or scroll == 'noscroll' and defaultdocmenu:
            menu.append(('[COLOR orange][B]Remove '+ADDONrefer+' Recursive Channel[/B][/COLOR]','RunPlugin(%s?name=None&mode=28&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    else:
        if scroll == 'buttom' or scroll == 'noscroll' and defaultdocmenu:
            menu.append(('[COLOR orange][B]Set '+ADDONrefer+' Recursive Channel[/B][/COLOR]','RunPlugin(%s?name=None&mode=27&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    if definition.ADDONgetSetting('LastView') == 'HIDDENCHANNELS':
        if scroll == 'buttom' or scroll == 'noscroll' and defaultdocmenu:
            menu.append(('[COLOR orange][B]Remove '+ADDONrefer+' Hidden Channel[/B][/COLOR]','RunPlugin(%s?name=None&mode=25&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    else:
        if scroll == 'buttom' or scroll == 'noscroll' and defaultdocmenu:
            menu.append(('[COLOR orange][B]Set '+ADDONrefer+' Hidden Channel[/B][/COLOR]','RunPlugin(%s?name=None&mode=24&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))

    if definition.ADDONgetSetting('enable_record')=='true':
        menu.append(('[COLOR orange][B]Restore from Database[/B][/COLOR]','RunPlugin(%s?name=&mode=104&url=url&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        menu.append(('[COLOR red][B]Delete All Planned Recordings ex Recursive[/B][/COLOR]','RunPlugin(%s?name=&mode=109&url=url&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        ###addDir('Delete All Planned Recordings ex Recursive','url',109,'','','','Delete All Planned Programs except Recursive. If recursive have made too many recordings - Stop all recordings and clear planned recording parts of database')

    if isTimeShiftActive():
        menu.append(('[COLOR red][B]Stop Timeshift Recording[/B][/COLOR]','RunPlugin(%s?name=None&mode=30&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))

    if scroll == 'top':
        menu.append(('[COLOR yellow][B]Buttom[/B][/COLOR]','Container.Update(%s?name=None&mode=51&url=None&iconimage=None&cat=%s)'% (sys.argv[0],scroll)))
    if mode==200 and cat != '#': 
        liz.setProperty("IsPlayable","true")
    else:
        liz.setProperty("IsPlayable","false")  ### 2020-03-24
    liz.addContextMenuItems(items=menu, replaceItems=True)
    if mode==200 or mode==12 or mode == 2020 or mode == 2001 or mode == 0:
        ok=xbmcplugin.addDirectoryItem(handle=Handle,url=u,listitem=liz,isFolder=False)
    else:
        ok=xbmcplugin.addDirectoryItem(handle=Handle,url=u,listitem=liz,isFolder=True)
    return ok

def isTimeShiftActive():
    subprpid = xbmcgui.Window(10000).getProperty(ADDONname + 'subprpid')
    subprcmd = xbmcgui.Window(10000).getProperty(ADDONname + 'subprcmd')
    log('OldTimeShift to stop and reset subprpid= %r, subprcmd= %r' % (subprpid, subprcmd))
    if subprpid != '' and definition.ADDONgetSetting('timeshiftbase') in subprcmd:
        return True
    else:
        return False
    
def addDirBasic(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='',u=''):
    u=sys.argv[0]+"?url="+str(url)+"&mode="+str(mode)+"&name="+str(name)+"&iconimage="+str(iconimage)+"&cat="+str(cat)+"&date="+str(date)+"&description="+str(description)+"&startDate="+str(startDate)+"&endDate="+str(endDate)+"&recordname="+str(recordname)
    
    ok=True
    ###liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz=xbmcgui.ListItem(name)
    liz.setArt({ 'icon': "DefaultFolder.png", 'thumb' : iconimage })
    liz.setInfo( type="Video", infoLabels={ "Title": name,"Plot":description } )
    try: # Find the mode on entry = the actual view '3' = Planned Recordings
        view= sys.argv[2].split('mode=',1)[1].split('&')[0]
        
    except Exception as e:
        log('err 6996 Except: %r' % e)
        pass
        view= '0'
    
    ok=xbmcplugin.addDirectoryItem(handle=Handle,url=u,listitem=liz,isFolder=True)
    return ok


def addDir_STOP(name,url,iconimage,cat,date,description,startDate='',endDate='',recordname=''):
        u=sys.argv[0]+"?url="+urllibquote_plus(url)+"&name="+urllibquote_plus(name)+"&iconimage="+urllibquote_plus(iconimage)+"&cat="+urllibquote_plus(cat)+"&date="+str(date)+"&description="+urllibquote_plus(description)+"&startDate="+str(startDate)+"&endDate="+str(endDate)+"&recordname="+recordings.latin1_to_ascii(recordname)
        ok=True
        ###liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz=xbmcgui.ListItem(name)
        liz.setArt({ 'icon': "DefaultFolder.png", 'thumb' : iconimage })
        liz.setInfo( type="Video", infoLabels={ "Title": name,"Premiered":date,"Plot":description} )
        ok=xbmcplugin.addDirectoryItem(handle=Handle,url=u,listitem=liz,isFolder=False)
        return ok
        
def SetUserAndPasswordNew():
    dialog = xbmcgui.Dialog()
    ##Dialog.radiolist(text, height=None, width=None, list_height=None, choices=[], **kwargs)
    ##choices – an iterable of (tag, item, status) tuples where status specifies the initial selected/unselected state of each entry; can be True or False, 1 or 0, "on" or "off" (True, 1 and "on" meaning selected), or any case variation of these two strings. No more than one entry should be set to True.
    choises = []
    selected = dialog.select(ADDONname + ' - Select a previous login:', choises ) ####################
    if selected == 'newmail':
        email=Search('Email')
    else:
        email = choises[selected]
    #email=Search('Email')
    ###log('email= %s' % repr(email))
    email = str(email)
    ###log('str(email)= %s' % repr(email))
    if not email == "":
        password=Search('Password')
        if not email == "" and not password == "":
            definition.ADDONresetSetting('user',email)
            definition.ADDONresetSetting('pass',password)
            AUTH()
            utils.notification('[COLOR green]Email and password updated[/COLOR]')
    MYACCOUNT()
    
def SetUserAndPassword():
    email=Search('Email')
    ###log('email= %s' % repr(email))
    email = str(email)
    ###log('str(email)= %s' % repr(email))
    if not email == "":
        password=Search('Password')
        if email != "" and password != "" and email != False and password != False:
            definition.ADDONresetSetting('user',email)
            definition.ADDONresetSetting('pass',password)
            AUTH()
            utils.notification('[COLOR green]Email and password updated[/COLOR]')
            ### Delete all chanels
            recordings.delAllChannels()
            ### Start update of EPG
            recordings.EPGOnce()
    MYACCOUNT()

def krogsbellAddonsDel(delADDONid):
    try:
        delADDONid = delADDONid.split(':[/COLOR][/B] ')[1]
    except Exception as e:
        log('err 7058 Except: %r' % e)
        pass
    addons    = []
    addonsAll = []
    addonDeleted = False
    lines = []
    try:
        SwFileFolder = os.path.join(xbmcvfs.translatePath('special://masterprofile/'), 'addon_data','krogsbell.switchaddons')
        SwFile = os.path.join(SwFileFolder,'switchaddons.txt')
        if not os.path.exists(SwFileFolder):
            os.mkdir(SwFileFolder)
            open(SwFile, 'a').close()
        log('SwFile= %r' % SwFile)
        ###switchfile = open(SwFile, 'r')
        
        with open(SwFile) as file_in:
            
            for line in file_in:
                if not delADDONid in line:
                    lines.append(line)
                else:
                    addonDeleted = True
        log('err krogsbellAddonsDel(delADDONid= %r)\nLines: %r' % (delADDONid,lines))
    except Exception as e:
        log('err 7080 Except: %r' % e)
        pass
        log('ERROR in deleting in Switch file: ' + repr(e))
    ###[['GlowIPTV','plugin.video.glowiptv.rec'],['DR NU','plugin.video.drnu'],['BBC iPlayer','plugin.video.iplayerwww'],['ITV Player','plugin.video.itv']]
    SwFileFolder = os.path.join(xbmcvfs.translatePath('special://masterprofile/'), 'addon_data','krogsbell.switchaddons')
    SwFile = os.path.join(SwFileFolder,'switchaddons.txt')
    LF = open(SwFile, 'w')
    log('err LF.write(lines= %r)' % lines)
    OutputFile = ''
    for line in lines:
        OutputFile += line
    LF.write(OutputFile)
    LF.close()
    return addonDeleted

def krogsbellAddonsAdd(addADDONid):
    try:
        addADDONid = addADDONid.split(':[/COLOR][/B] ')[1]
    except Exception as e: pass
    addons    = []
    addonsAll = []
    try:
        SwFileFolder = os.path.join(xbmcvfs.translatePath('special://masterprofile/'), 'addon_data','krogsbell.switchaddons')
        SwFile = os.path.join(SwFileFolder,'switchaddons.txt')
        if not os.path.exists(SwFileFolder):
            os.mkdir(SwFileFolder)
            open(SwFile, 'a').close()
        log('SwFile= %r' % SwFile)
        switchfile = open(SwFile, 'r')
        addonsO = switchfile.read()
        switchfile.close() 
        
        if not addADDONid in addonsO:
            targetADDON = xbmcaddon.Addon(id=addADDONid)
            newADDONname = targetADDON.getAddonInfo('name')
            log('err newADDONname= %r' % newADDONname)
            ###addonsO += '\n' + ADDONrefer + ':' + ADDONid
            addonsO += '\n' + newADDONname + ':' + addADDONid
        if addonsO != '' :
            addonsO = addonsO.split('\n')
            for addon in addonsO:
                if addon != '':
                    newaddon = addon.split(':')
                    targetADDON = xbmcaddon.Addon(id=newaddon[1])
                    newaddon[0] = targetADDON.getAddonInfo('name')
                    if newaddon[1] != ADDONid:
                        try:
                            testAddon = xbmcaddon.Addon(id=newaddon[1])
                            pathTOaddon = os.path.join(xbmcvfs.translatePath('special://home/addons'), newaddon[1])
                            if os.path.exists(pathTOaddon):
                                addons.append(newaddon)
                                addonsAll.append(newaddon)
                        except Exception as e:
                            log('err 7132 Except: %r' % e)
                            pass
                            log('testAddon FAILED ERROR: %r' % e)
                    else:
                        addonsAll.append(newaddon)
    except Exception as e:
        log('err 7137 Except: %r' % e)
        pass
        addons.append(['ERROR',repr(e)])
    ###[['GlowIPTV','plugin.video.glowiptv.rec'],['DR NU','plugin.video.drnu'],['BBC iPlayer','plugin.video.iplayerwww'],['ITV Player','plugin.video.itv']]
    addonsAll = sorted(addonsAll)
    log('err krogsbellAddons addonsAll= %r' % addonsAll)
    addonsO = ''
    for addon in addonsAll:
        addonsO += addon[0] + ':' + addon[1] + '\n'
    definition.ADDONresetSetting('switchaddons',addonsO)
    LF = open(SwFile, 'w')
    LF.write(addonsO)
    LF.close()

def krogsbellAddons():
    ### Krogsbell IPTV addons have the file 'definition.py'
    addons    = []
    addonsAll = []
    try:
        SwFileFolder = os.path.join(xbmcvfs.translatePath('special://masterprofile/'), 'addon_data','krogsbell.switchaddons')
        SwFile = os.path.join(SwFileFolder,'switchaddons.txt')
        if not os.path.exists(SwFileFolder):
            os.mkdir(SwFileFolder)
            open(SwFile, 'a').close()
        log('SwFile= %r' % SwFile)
        switchfile = open(SwFile, 'r')
        addonsO = switchfile.read()
        switchfile.close() 
        
        if not ADDONid in addonsO:
            targetADDON = xbmcaddon.Addon(id=ADDONid)
            newADDONname = targetADDON.getAddonInfo('name')
            log('err newADDONname= %r' % newADDONname)
            ###addonsO += '\n' + ADDONrefer + ':' + ADDONid
            addonsO += '\n' + newADDONname + ':' + ADDONid
        if addonsO != '' :
            addonsO = addonsO.split('\n')
            for addon in addonsO:
                if addon != '':
                    newaddon = addon.split(':')
                    targetADDON = xbmcaddon.Addon(id=newaddon[1])
                    newaddon[0] = targetADDON.getAddonInfo('name')
                    if newaddon[1] != ADDONid:
                        try:
                            testAddon = xbmcaddon.Addon(id=newaddon[1])
                            pathTOaddon = os.path.join(xbmcvfs.translatePath('special://home/addons'), newaddon[1])
                            if os.path.exists(pathTOaddon):
                                addons.append(newaddon)
                                addonsAll.append(newaddon)
                        except Exception as e:
                            log('err 7186 Except: %r' % e)
                            pass
                            log('testAddon FAILED ERROR: %r' % e)
                    else:
                        addonsAll.append(newaddon)
    except Exception as e:
        log('err 7191 Except: %r' % e)
        pass
        addons.append(['ERROR',repr(e)])
    ###[['GlowIPTV','plugin.video.glowiptv.rec'],['DR NU','plugin.video.drnu'],['BBC iPlayer','plugin.video.iplayerwww'],['ITV Player','plugin.video.itv']]
    addonsAll = sorted(addonsAll)
    log('err krogsbellAddons addonsAll= %r' % addonsAll)
    addonsO = ''
    for addon in addonsAll:
        addonsO += addon[0] + ':' + addon[1] + '\n'
    definition.ADDONresetSetting('switchaddons',addonsO)
    LF = open(SwFile, 'w')
    LF.write(addonsO)
    LF.close()
            
    addons = sorted(addons)
    choises = []
    for choise in addons:
       choises.append('[B][COLOR lightgreen]'+ choise[0] + ':[/COLOR][/B] ' + choise[1])
    return choises

def views(name,cat,url,description):
    lastview = definition.ADDONgetSetting('LastView')
    ###log('lastview= %r, name= %r, cat= %r' % (lastview, name, cat))
    if lastview == 'TVGUIDE':
        TVGUIDE(name,cat)
    elif lastview == 'CHANNELS': 
        CHANNELS(name,cat)
    
    elif lastview == 'STATUS':
        STATUS()
    
    elif lastview == 'MYACCOUNT':
        MYACCOUNT()

    elif lastview == 'DOWNLOADS':
        DOWNLOADS('6')
    
    elif lastview == 'CATEGORIES':
        CATEGORIES()

    elif lastview == 'RECORDINGSPLANNED':
        RecordingsPlanned()

    elif lastview == 'ntvCATEGORIES':
        ntvCATEGORIES()

    elif lastview == 'FAVORITES':
        FAVORITES()
    
    elif lastview == 'ARCHIVE':
        ARCHIVE()

    elif lastview == 'MYSELECTEDCHANNELS':
        MYSELECTEDCHANNELS()

    elif lastview == 'HIDDENCHANNELS':
        HIDDENCHANNELS()

    elif lastview == 'NEWCHANNELS':
        NEWCHANNELS()

    elif lastview == 'CHANNELSROQOLD':
        CHANNELSROQOLD(name,cat,url,description)

    elif lastview == 'CHANNELSROQ':
        CHANNELSROQ()
        
    elif lastview == 'CHANNELSSEARCH':
        CHANNELSSEARCH()
        
    elif lastview == 'PROGRAMSEARCH':
        PROGRAMSEARCH()
              
    elif lastview == 'RECURSIVECHANNELS':
        RECURSIVECHANNELS()
    
    elif lastview == 'SUBS':
        SUBS()
    ###xbmc.executebuiltin("Container.Refresh")
    
def getVersion(xmlfile):
    ### version="2019.08.10"
    #xmlfile = os.path.join(progpath,'addon.xml')
    try:
        file = open(xmlfile,'r',encoding='utf-8')
        desc = file.read()
        file.close()
        version = desc.split('ersion="')[2].split('"')[0]
    except Exception as e:
        pass
        log('err 7424 Except: %r' % e)
        version = datetime.today().strftime('%Y.%m.%d')
        log('getVersion(xmlfile= %r) ERROR: %r' % (xmlfile,e))
    return version
    
def setVersion(xmlfile,versionnew,versionold):
    ### version="2019.08.10"
    #xmlfile = os.path.join(progpath,'addon.xml')
    try:
        log('errX 7433 xmlfile= %r' % xmlfile ,showlength=5000)
        file = open(xmlfile,'r',encoding='utf-8')
        desc = file.read()
        log('errX 7436 desc= %r' % desc ,showlength=5000)
        file.close()
        desc = desc.replace(versionold,versionnew,1)
        log('errX 7439 desc= %r' % desc ,showlength=5000)
        with open(xmlfile,'w',encoding='utf-8') as output:
            output.write(desc)
    except Exception as e:
        pass
        log('err 7440 Except: %r' % e)
        log('setVersion(xmlfile= %r,versionnew= %r,versionold= %r) ERROR: %r' % (xmlfile,versionnew,versionold,e))
        
def ParameterSearch(name,search_entered):
    keyboard = xbmc.Keyboard(search_entered, '[COLOR lightgreen][B]Please Enter '+str(name)+'[/B][CR][COLOR grey][I]<ESC> or Cancel to clear[/I][/COLOR]')
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_entered = keyboard.getText()
        if search_entered == None:
            return False 
    else:
        return False
    return search_entered 
    
def Parameter(ADDON,name,parameter):
    VALUE = definition.ADDONgetSetting(parameter)
    fixedname = definition.ADDONgetSetting('fixedname')
    if fixedname != '' and parameter == 'my_referral_name':
        VALUE = fixedname
    if VALUE == '' and parameter == 'my_referral_name':
        VALUE = definition.ADDONgetAddonInfo('name')
        if VALUE == '':
            VALUE = 'Krogsbell'
    newVALUE = ParameterSearch(name,VALUE)
    ###newVALUE = VALUE   ### 2025-07-07
    definition.ADDONsetSetting('parameter',str(VALUE) + '-->' + str(newVALUE))
    if newVALUE == '' and parameter == 'my_referral_name':
        newVALUE = definition.ADDONgetAddonInfo('name')
        if newVALUE == '':
            newVALUE = 'Krogsbell'
    if newVALUE:
        definition.ADDONsetSetting(parameter,newVALUE)
    return newVALUE
"""
listitem.setInfo(type='Music', infoLabels={'title': a.get('title') or '',
                                           'artist': a.get('artist') or '',
                                           'album': a.get('artist') or '',
                                           'duration': a.get('duration') or 0,
                                           'genre': 'Karaoke',
                                           'lyrics': lyrics})
                                           
setInfo(type, infoLabels)[source]
Sets the listitem’s infoLabels.

Parameters: 
type – string - type of
infoLabels – dictionary - pairs of { label: value }
Available types

Command name    Description
video   Video information
music   Music information
pictures    Pictures informanion
game    Game information
To set pictures exif info, prepend exif: to the label. Exif values must be passed as strings, separate value pairs with a comma. (eg. ``{‘exif:resolution’: ‘720,480’}`` See kodi_pictures_infotag for valid strings.

You can use the above as keywords for arguments and skip certain optional arguments. Once you use a keyword, all following arguments require the keyword.

General Values (that apply to all types):

Info label  Description
count   integer (12) - can be used to store an id for later, or for sorting purposes
size    long (1024) - size in bytes
date    string (d.m.Y / 01.01.2009) - file date

Video Values:
Info label  Description
genre   string (Comedy) or list of strings ([“Comedy”, “Animation”, “Drama”])
country string (Germany) or list of strings ([“Germany”, “Italy”, “France”])
year    integer (2009)
episode integer (4)
season  integer (1)
sortepisode integer (4)
sortseason  integer (1)
episodeguide    string (Episode guide)
showlink    string (Battlestar Galactica) or list of strings ([“Battlestar Galactica”, “Caprica”])
top250  integer (192)
setid   integer (14)
tracknumber integer (3)
rating  float (6.4) - range is 0..10
userrating  integer (9) - range is 1..10 (0 to reset)
watched depreciated - use playcount instead
playcount   integer (2) - number of times this item has been played
overlay integer (2) - range is 0..7 . See Overlay icon types for values
cast    list ([“Michal C. Hall”,”Jennifer Carpenter”]) - if provided a list of tuples cast will be interpreted as castandrole
castandrole list of tuples ([(“Michael C. Hall”,”Dexter”), (“Jennifer Carpenter”,”Debra”)])
director    string (Dagur Kari) or list of strings ([“Dagur Kari”, “Quentin Tarantino”, “Chrstopher Nolan”])
mpaa    string (PG-13)
plot    string (Long Description)
plotoutline string (Short Description)
title   string (Big Fan)
originaltitle   string (Big Fan)
sorttitle   string (Big Fan)
duration    integer (245) - duration in seconds
studio  string (Warner Bros.) or list of strings ([“Warner Bros.”, “Disney”, “Paramount”])
tagline string (An awesome movie) - short description of movie
writer  string (Robert D. Siegel) or list of strings ([“Robert D. Siegel”, “Jonathan Nolan”, “J.K. Rowling”])
tvshowtitle string (Heroes)
premiered   string (2005-03-04)
status  string (Continuing) - status of a TVshow
set string (Batman Collection) - name of the collection
setoverview string (All Batman movies) - overview of the collection
tag string (cult) or list of strings ([“cult”, “documentary”, “best movies”]) - movie tag
imdbnumber  string (tt0110293) - IMDb code
code    string (101) - Production code
aired   string (2008-12-07)
credits string (Andy Kaufman) or list of strings ([“Dagur Kari”, “Quentin Tarantino”, “Chrstopher Nolan”]) - writing credits
lastplayed  string (Y-m-d h:m:s = 2009-04-05 23:16:04)
album   string (The Joshua Tree)
artist  list ([‘U2’])
votes   string (12345 votes)
path    string (/home/user/movie.avi)
trailer string (/home/user/trailer.avi)
dateadded   string (Y-m-d h:m:s = 2009-04-05 23:16:04)
mediatype   string - “video”, “movie”, “tvshow”, “season”, “episode” or “musicvideo”
dbid    integer (23) - Only add this for items which are part of the local db. You also need to set the correct ‘mediatype’!

Music Values:
Info label  Description
tracknumber integer (8)
discnumber  integer (2)
duration    integer (245) - duration in seconds
year    integer (1998)
genre   string (Rock)
album   string (Pulse)
artist  string (Muse)
title   string (American Pie)
rating  float - range is between 0 and 10
userrating  integer - range is 1..10
lyrics  string (On a dark desert highway…)
playcount   integer (2) - number of times this item has been played
lastplayed  string (Y-m-d h:m:s = 2009-04-05 23:16:04)
mediatype   string - “music”, “song”, “album”, “artist”
dbid    integer (23) - Only add this for items which are part of the local db. You also need to set the correct ‘mediatype’!
listeners   integer (25614)
musicbrainztrackid  string (cd1de9af-0b71-4503-9f96-9f5efe27923c)
musicbrainzartistid string (d87e52c5-bb8d-4da8-b941-9f4928627dc8)
musicbrainzalbumid  string (24944755-2f68-3778-974e-f572a9e30108)
musicbrainzalbumartistid    string (d87e52c5-bb8d-4da8-b941-9f4928627dc8)
comment string (This is a great song)

Picture Values:
Info label  Description
title   string (In the last summer-1)
picturepath string (/home/username/pictures/img001.jpg )
exif*   string (See kodi_pictures_infotag for valid strings)
                                           
"""
         
# below tells plugin about the views 
# mediatype string - “video”, “movie”, “tvshow”, “season”, “episode” or “musicvideo”               
def setView(content, viewType):
    xbmc.sleep(100)
    xbmcplugin.setContent(Handle, 'musicvideo')
    xbmc.sleep(100)
    xbmc.executebuiltin("Container.SetViewMode(%s)" % '57' )
    xbmc.sleep(100)
    xbmc.executebuiltin("Container.NextViewMode")    ### Some time the wiew is not shown. Seems to show view, as there are no next views ;-)
    if 1 == 0:
        mediatype = ['video', 'movie', 'tvshow', 'season', 'episode', 'musicvideo']
        i = -1
        for i in range(0,len(mediatype)):
            if content == mediatype[i]:
                break
        SelectedMediaType = xbmcgui.Dialog().select('Select Media Type', mediatype, preselect= i, autoclose=50000)
        if SelectedMediaType >= 0:
            content = mediatype[SelectedMediaType]
        else:
            content = ''
        xbmc.sleep(10)
        log('7805 error setView(content= %r, viewType= %r)' % (content, viewType))
        viewType = 'WideList'
        confluence_views = [[-1,'Next View Type'],[50,'List'],[52,'Tripanel'],[53,'TripanelSquare'],[57,'Shift'],[500,'Wall'],[501,'ShowcaseMovies'],[503,'Landscape'],[506,'LowlistMusic'],[508,'Banners'],[509,'showcaseSquare'],[510,'Posters'],[511,'Lowlist'],[512,'AddonWall'],[514,'Episode'],[516,'BigFan'],[517,'Stripshow'],[518,'InfoPanel'],[550,'Panel']]
        vtt = []
        vts = []
        for vt in confluence_views:
            vtt.append(vt[1])
            vts.append(vt[0])
        log('7807 error Container.SetViewMode(xxx)')
        SelectedView = xbmcgui.Dialog().select('Select View Type', vtt, preselect= 0, autoclose=50000)
        if SelectedView >= 0:
            viewType = vtt[SelectedView]
        else:
            viewType = -1
        utils.dialogShow('content= %r, viewType= %r' % (content, viewType))
        if content:
            xbmcplugin.setContent(Handle, content)
        ###ViewMode = confluence_views[3]
        ViewMode = viewType
        xbmc.sleep(100)
        if ViewMode == -1:
            xbmc.executebuiltin("Container.NextViewMode")
        else:
            xbmc.executebuiltin("Container.SetViewMode(%s)" % ViewMode )
        ###xbmc.sleep(100)
        ###xbmc.executebuiltin("Container.NextViewMode")
        """
        # set content type so library shows more views and info
        log('errsetView(content= %r, viewType= %r)' % (content, viewType))
        if content:
            xbmcplugin.setContent(Handle, content)
        if definition.ADDONgetSetting('auto-view') == 'true':#<<<----see here if auto-view is enabled(true) 
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            ViewMode = definition.ADDONgetSetting(viewType)
            if ViewMode == None or ViewMode == '' :
                ViewMode = 'main-view'
            xbmc.executebuiltin("Container.SetViewMode(%s)" % ViewMode )#<<<-----then get the view type
        """
params = []
try:
    params=utils.get_params(2)
    log('err params= %r' % params)
except Exception as e:
    log('err 7430 Except: %r' % e)
    pass
    log('get_params(2) ERROR: %r' % e)
url=None
name=''
mode=None
iconimage=None
date=None
description=None
cat=None
startDate=None
endDate=None
record=None
uri=None
playpath=None
app=None
recordname=''
auth=None
sourceApp=''
OrgTitle = ''
uriorg = ''

try:
    uriorg=urllibunquote_plus(params["uriorg"])  # uriorg
    log('err uriorg= %r' % uriorg)
    log('err uriorg.decoded= %r' % utils.decode64(uriorg))
except Exception as e:
    log('7456 Except: %r' % e)
    pass
    log('uriorg ERROR %r' % e)  

try:
    auth=urllibunquote_plus(params["auth"])  # auth
except Exception as e:
    log('err 7462 Except: %r' % e)
    pass
    log('auth ERROR %r' % e)  
try:
    url=urllibunquote_plus(params["url"])  # URL
except Exception as e:
    log('err 7467 Except: %r' % e)
    pass
    log('url ERROR %r' % e)
try:
    uri=urllibunquote_plus(params["uri"])  # URI
    log('2 uri= %r' % uri)
except Exception as e:
    log('err 7473 Except: %r' % e)
    pass
    log('uri ERROR %r' % e)
try:
    playpath=urllibunquote_plus(params["playpath"])  # playpath
except Exception as e:
    log('err 7478 Except: %r' % e)
    pass
    log('playpath ERROR %r' % e)
try:
    app=urllibunquote_plus(params["app"])  # app
except Exception as e:
    log('err 7483 Except: %r' % e)
    pass
    log('app ERROR %r' % e)
try:
    name = urllibunquote_plus(params["name"])
    name = name.replace('aBcDeF','&')     ### 2024-05-31
    log('err name from params= %r' % name)
    ###name = name.split('[/COLOR]')[1]  ###???
except Exception as e:
    log('err 7490 Except: %r' % e)
    pass
    log('name ERROR %r' % e)
try:
    iconimage=urllibunquote_plus(params["iconimage"])
except Exception as e:
    log('err 7495 Except: %r' % e)
    pass
    log('iconimage ERROR %r' % e)
try:        
    mode=int(params["mode"])
except Exception as e:
    log('err 7500 Except: %r' % e)
    pass
    log('mode ERROR %r' % e)
try:
    cat=urllibunquote_plus(params["cat"])
except Exception as e:
    log('err 7505 Except: %r' % e)
    pass
    log('cat ERROR %r' % e)
try:
    date=str(params["date"])
except Exception as e:
    log('err 7510 Except: %r' % e)
    pass
    log('date ERROR %r' % e)
try:
    ###description=(urllibunquote_plus(params["description"])).replace('NlNlNl','\n')
    description=(urllibunquote_plus(params["description"]))
except Exception as e:
    log('err 7516 Except: %r' % e)
    pass
    log('description ERROR %r' % e)
try:
    startDate=str(params["startDate"])
except Exception as e:
    log('err 7521 Except: %r' % e)
    pass
    log('startDate ERROR %r' % e)
try:
    endDate=str(params["endDate"])
except Exception as e:
    log('err 7526 Except: %r' % e)
    pass
    log('endDate ERROR %r' % e)
try:
    recordname=urllibunquote_plus(params["recordname"])
    if recordname == '' and not name == '':
        recordname = name
except Exception as e:
    log('err 7533 Except: %r' % e)
    pass
    log('recordname ERROR %r' % e)
try:
    sourceApp=str(params["source"])
except Exception as e:
    log('err 7538 Except: %r' % e)
    pass
    log('sourceApp ERROR %r' % e)

try:
    OrgTitle=str(params["OrgTitle"])
    OrgTitle = OrgTitle.replace('aBcDeF','&')     ### 2024-05-31
except Exception as e:
    log('err 7544 Except: %r' % e)
    pass
    log('OrgTitle ERROR %r' % e)

log('Exception Just before commands: (\nsys.argv= %r\n)' % sys.argv)

utils.get_free_space_gb(datapath,archive='/')   ### 2025-05-09

log('Exception Just before commands: (\n cat= %r\n mode= %r\n url= %r\n uri= %r\n startDate= %r\n endDate= %r\n name= %r\n recordname= %r\n description= %r\n sourceApp= %r\n OrgTitle= %r\n uriorg= %r)' % (cat, mode, url, uri, startDate, endDate, name, recordname, description, sourceApp, OrgTitle, uriorg), showlength = 5000)

if xbmc.Player().isPlayingVideo():   ### 2022-06-24
    utils.setDefaultVideoLevel()
    ###xbmc.executebuiltin("SetVolume(100,showvolumebar)")
    
if definition.ADDONgetSetting('fullscreen') == 'true' :
    if not xbmc.Player().isPlayingVideo():   ### 2022-04-08
        log('errXXX Player Not Playing Video')
        fullscreen = xbmc.getCondVisibility('System.IsFullscreen')   
        if fullscreen:
            xbmc.executebuiltin("Action(togglefullscreen)")
        log('errXXX 1 FullScreenOff= %r' % fullscreen)
    else:
        log('errXXX 2 FullScreen? Playing Video!')

definition.ADDONresetSetting('show_list_item','0')
log('err mode 0 or similar: %r' % mode)
#these are the modes which tells the plugin where to go
if mode==0 or mode=='' or mode==None:
    try:
        ###xbmc.executebuiltin("Container.Refresh")
        mode = 0
        modeidx = 0
        """
        Home - 0
        Favorites - 17 
        Planned Recordings - 3 
        My Account - 8
        Maintenance - 49
        Streams - 490
        """
        log('err mode is nothing - set to 0')
        modetable = [0,17,3,8,49,490,2065]
        try:
            StartView = definition.ADDONgetSetting('StartView')
            log('err StartView= %r' % StartView)
            modeidx = int(StartView)
            log('err 1 modeidx= %r' % modeidx)
        except Exception as e:
            log('err 7575 Except: %r' % e)
            pass
            log('modeidx set to 1. modeidx= %r/ERROR: %r' % (modeidx,e))
            modeidx = 0
        log('err 2 modeidx= %r' % (modeidx))
        mode = modetable[modeidx]
        log('err 2 mode= %r' % (mode))
        if url == None:
            url = 'url'
        log('1 mode= %r, url= %r' % (mode, url))
    except Exception as e:
        log('err 7585 Except: %r' % e)
        pass
        mode = 0
        log('mode set to 0. modeidx= %r/ERROR: %r' % (modeidx,e))
    log('err FINISHED: if mode==0 or mode=="" or mode==None')
    
    ###xbmc.executebuiltin("Container.Refresh")
log('err mode 1')
if mode==1:
    log('mode= %r' % mode)
    
if mode==49:
    log('mode= %r' % mode)
    log('mode 49 executed!')
    if url == None:
        url = 'url'
        
if mode==52:   ### Open settings
    log('mode= %r' % mode)
    log('mode 52 executed!')
    xbmcaddon.Addon(id=ADDONid).openSettings()

if mode==666:  ### Go To Last View ???
    views(name,cat,url,description)
log('err mode 6')
if mode==6:  ### Search recordings
    log('err 6 mode= %r' % mode)
    definition.ADDONresetSetting('LastView', 'DOWNLOADS')
    definition.ADDONresetSetting('record_display_path',recordPath)
    definition.ADDONresetSetting('sortalphabetic','true')
    DOWNLOADS('6')

elif mode==2060:   ### Search descriptions
    log('err 2060 mode= %r' % mode)
    definition.ADDONresetSetting('LastView', 'DOWNLOADS')
    definition.ADDONresetSetting('record_display_path',recordPath)
    DOWNLOADS('2060')

elif mode==2065:   ### Search database
    log('err 2065 mode= %r' % mode)
    definition.ADDONresetSetting('LastView', 'DOWNLOADS')
    definition.ADDONresetSetting('record_display_path',recordPath)
    if not xbmc.Player().isPlayingAudio():   ### 2022-06-24
        utils.setDefaultVideoLevel()
        ###xbmc.executebuiltin("SetVolume(100,showvolumebar)")
    
    DOWNLOADS('2065')
    
elif mode==2070:   ### Update file database
    log('err 2070 mode= %r' % mode)
    definition.ADDONresetSetting('LastView', 'ScanRecordings')
    updateepg.ScanRecordings('all')
    ###xbmc.executebuiltin("Container.Refresh")

elif mode==66:   
    log('err 66 mode= %r' % mode)
    definition.ADDONresetSetting('LastView', 'DOWNLOADS')
    definition.ADDONresetSetting('record_display_path',cat)
    definition.ADDONresetSetting('sortalphabetic','false')
    DOWNLOADS('66')
    
elif mode==67:   ### Search in description
    log('err 67 mode= %r' % mode)
    definition.ADDONresetSetting('LastView', 'DOWNLOADS')
    definition.ADDONresetSetting('record_display_path',cat)
    DOWNLOADS('67')
        
elif mode==8:
    log('err 8 mode= %r' % mode)
    definition.ADDONresetSetting('LastView', 'MYACCOUNT')
    MYACCOUNT()

elif mode==49:
    log('err 49 mode= %r' % mode)
    definition.ADDONresetSetting('LastView', 'Maintenance')
    Maintenance()
    
elif mode==490:
    log('err 490 mode= %r' % mode)
    definition.ADDONresetSetting('LastView', 'Streams')
    Streams()
    
elif mode==10:
    log('err 10 mode= %r' % mode)
    dialog = xbmcgui.Dialog()
    if dialog.yesno(ADDONname, "[COLOR red]Delete database and start all over?[/COLOR]" +'\n'+ "What Do You Want To Do","[COLOR red]Delete[/COLOR]","[COLOR green]Ignore[/COLOR]"):
        ### Ignore
        lockcause = 'ignore' ### Dummy command
    else:
        ### Stop recording and record new
        lockcause = 'change' ### Dummy command
        ### Backup Database and files
        recordings.backupSetupxml()
        recordings.backupDataBase()    ### 2019-08-31
        ### Clear Scanning
        locking.scanUnlock('EPG_update')
        ### Delete Database
        recordings.deleteDataBase()
        definition.ADDONresetSetting('BASEURL','')   ### Reset user
        ### Ask for: Your Connection Details in Text File or none
        basicuserinfo = Parameter(ADDON,'Your Connection Details Text File','basicuserinfofile')
        my_referral_name = Parameter(ADDON,'Addon Name','my_referral_name')
        log('error my_referral_name= %r' % my_referral_name)
        my_referral_registration = Parameter(ADDON,'Krogsbell IPTV Registration','my_referral_registration')
        log('error my_referral_registration= %r' % my_referral_registration)
        my_referral_init = Parameter(ADDON,'Addon 3 upper case initials','my_referral_init')
        my_referral_init = my_referral_init.upper()
        file = open(basicuserinfo,'r')
        desc = file.read()
        file.close()
        basicuserinfo = desc
        l=1
        log('152 %r' % l)
        if basicuserinfo:
            if basicuserinfo.lower().replace('\n','').replace('\r','').replace("'",'').replace('"','') == 'none':
                basicuserinfo = 'http://none.none:80/get.php?username=none&password=none&type=m3u_plus&output=ts'
            basicuserinfo = basicuserinfo.replace('&amp;','&').replace('\n','').replace('\r','').replace("'",'').replace('"','')
            l=2
            log('158 %r' % l)
            definition.ADDONsetSetting('AAA','basicuserinfo= %s' % basicuserinfo)
            if 'http://' in basicuserinfo.lower():
                l=3
                log('162 %r' % l)
                server = basicuserinfo.lower().split('http://',1)[1]
            else:
                l=4
                log('166 %r' % l)
                server = basicuserinfo.lower().split('https://',1)[1]
            l=5
            log('169 %r' % l)
            BASEURL = server.split('/')[0]
            l=6
            log('172 %r' % l)
            l=10
            log('227 %r' % l)
            command = server.replace(BASEURL,'',1)
            BASEURL = 'http://' + BASEURL
            COMMAND = command.split('username=',1)[0]
            l=11
            log('233 %r' % l)
            username = command.split('username=',1)[1].split('&',1)[0]
            l=12
            log('236 %r' % l)
            password = command.split('password=',1)[1].split('&',1)[0]
            l=13
            log('239 %r' % l)
            COMMANDEND = '&type=' + command.split('&type=',1)[1]
            definition.ADDONsetSetting('COMMAND',COMMAND)
            definition.ADDONsetSetting('COMMANDEND',COMMANDEND)
            if BASEURL != '' and username != '' and password != '':
                l=14
                log('245 %r' % l)
                definition.ADDONsetSetting('BASEURL',BASEURL)
                definition.ADDONsetSetting('user',str(username))
                definition.ADDONsetSetting('pass',str(password))
        recordings.EPGOnce()   ### Update Channels and EPG
        utils.notificationsend('New User Set and Update Channels and EPG Started for %s/%s with user= %r' % (my_referral_name,my_referral_init,username))

elif mode==5010:
    log('err 5010 mode= %r' % mode)
    searchtimemax = definition.ADDONgetSetting('searchtimemax')
    #searchtimemax = 20
    dialog = xbmcgui.Dialog()
    keyboard=dialog.numeric(0, 'Please Enter Search Time Maximum',searchtimemax)
    if keyboard:
        definition.ADDONresetSetting('searchtimemax',keyboard)
    setView('movies', 'main-view')
    #utils.notificationsend('Open Setting Finished')

elif mode==5011:
    log('err 5011 mode= %r' % mode)
    searchcountmax = definition.ADDONgetSetting('searchcountmax')
    dialog = xbmcgui.Dialog()
    keyboard=dialog.numeric(0, 'Please Enter Search Count Maximum',searchcountmax)
    if keyboard:
        definition.ADDONresetSetting('searchcountmax',keyboard)
    setView('movies', 'main-view')
    #utils.notificationsend('Open Setting Finished')
    
elif mode==5012:   ### Adjust archive offset
    log('err 5012 mode= %r' % mode)
    archiveoffsetminutes = definition.ADDONgetSetting('archiveoffsetminutes')
    dialog = xbmcgui.Dialog()
    keyboard=dialog.numeric(0, 'Please Enter Archive Offset in Minutes',archiveoffsetminutes)
    if keyboard:
        if keyboard[0:1] == '0':
            keyboard = str(0-int(keyboard))
        definition.ADDONresetSetting('archiveoffsetminutes',keyboard)
        setView('movies', 'main-view')
        utils.notificationsend('Refresh view to use new offset')
    
elif mode==9:
    log('err 9 mode= %r' % mode)
    definition.ADDONresetSetting('LastView', 'SUBS')
    SUBS()

elif mode==11:
    log('err 11 mode= %r' % mode)
    definition.ADDONresetSetting('LastView', 'STATUS')
    STATUS()

elif mode==12:
    log('err 12 mode= %r' % mode)
    STATUSsub(description)

elif mode==13:
    log('err 13 mode= %r' % mode)
    RecordingsPlannedDebug()

elif mode==14:
    log('err 14 mode= %r' % mode)
    SetUserAndPassword()
    
elif mode==15:
    log('err 15 mode= %r' % mode)
    SetupxmlFiles() 
    
elif mode==50:
    log('err 50 mode= %r' % mode)
    ### To Top  
    definition.ADDONresetSetting('scroll','top')
    views(name,cat,url,description)
    
elif mode==51:
    log('err 51 mode= %r' % mode)
    ### Buttom      
    definition.ADDONresetSetting('scroll','buttom')
    views(name,cat,url,description)
    
elif mode==102:
    log('err 102 mode= %r' % mode)
    try:    ### Delete information and subtitles if they are available
        url = url.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
        fileext = '.' + url.split('.')[-1]
        try:
            deleteFile(url.replace(fileext,'.txt'))
        except Exception as e:
            log('err 7757 Except: %r' % e)
            pass
        try:
            deleteFile(url.replace(fileext,'.srt'))
        except Exception as e:
            log('err 7762 Except: %r' % e)
            pass
        try:
            deleteFile(url.replace(fileext,'.en.srt'))
        except Exception as e:
            log('err 7767 Except: %r' % e)
            pass
        try:
            deleteFile(url.replace(fileext,'.da.srt'))
        except Exception as e:
            log('err 7772 Except: %r' % e)
            pass
        try:
            deleteFile(url.replace(fileext,'.nfo'))
        except Exception as e:
            log('err 7777 Except: %r' % e)
            pass
        try:
            deleteFile(url.replace(fileext,'.tit'))
        except Exception as e:
            log('err 7781 Except: %r' % e)
            pass
        try:
            deleteFile(url.replace(fileext,'.log'))
        except Exception as e:
            log('err 7775 Except: %r' % e)
            pass
    except Exception as e:
        log('err 7776 Except: %r' % e)
        pass
    deleteFile(url)
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin("Container.Refresh")

elif mode==1022:
    log('err 1022 mode= %r' % mode)
    try:    ### Rename information and subtitles if they are available
        url = url.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
        log('url= %r' % url)
        urldirectorypath = os.path.dirname(url) # relative directory path
        log('urldirectorypath= %r' % urldirectorypath)
        urlbasename = os.path.basename(url) # the file name only
        log('urlbasename= %r' % urlbasename)
        fileext = '.' + url.split('.')[-1]
        log('fileext= %r' % fileext)
        if '[' in urlbasename:
            log('urlbasename= %r' % urlbasename)
            urlbase = urlbasename.split('[')[0]
            urlbasefull = urlbasename.replace(fileext,'',-1)
        else:
            urlbasefull = urlbasename.replace(fileext,'',-1)  ### Remove extension
            urlbase     = urlbasefull
        log('urlbasefull= %r' % urlbasefull)
        log('8611 urlbase= %r' % urlbase)
        if urlbase != urlbasefull:
            urlbaselastpart = urlbasefull.replace(urlbase,'...',1)
        else:
            urlbaselastpart = urlbasefull
        urlbase = urlbase.replace('xxYYxx','&')
        urlbasefull = urlbasefull.replace('xxYYxx','&')
        dialog = xbmcgui.Dialog()
        urlnewi = dialog.input('Enter new filename for: \n' + urlbaselastpart, defaultt=urlbase, type=xbmcgui.INPUT_ALPHANUM, autoclose=120000)
        if urlnewi != '':
            urlnewi = recordings.latin1_to_ascii_force(urlnewi)   ### use only acceptable characters
            urlnew = os.path.join(urldirectorypath,urlbasefull.replace(urlbase,urlnewi))
            log('urlnew= %r' % urlnew)
            urlbase = os.path.join(urldirectorypath,urlbasefull)
            log('8625 urlbase= %r' % urlbase)
            os.rename(urlbase+fileext,urlnew+fileext)
            try:
                os.rename(urlbase+'.txt',urlnew+'.txt')
            except Exception as e:
                log('err 7819 Except: %r' % e)
                pass
                log('Rename error %r' % e)
            try:
                os.rename(urlbase+'.srt',urlnew+'.srt')
            except Exception as e:
                log('err 7824 Except: %r' % e)
                pass
                log('Rename error %r' % e)
            try:
                os.rename(urlbase+'.en.srt',urlnew+'.en.srt')
            except Exception as e:
                log('err 7829 Except: %r' % e)
                pass
                log('Rename error %r' % e)
            try:
                os.rename(urlbase+'.da.srt',urlnew+'.da.srt')
            except Exception as e:
                log('err 7834 Except: %r' % e)
                pass
                log('Rename error %r' % e)
            try:
                os.rename(urlbase+'.nfo',urlnew+'.nfo')
            except Exception as e:
                log('err 7839 Except: %r' % e)
                pass
                log('Rename error %r' % e)
            try:
                os.rename(urlbase+'.tit',urlnew+'.tit')
            except Exception as e:
                log('err 7844 Except: %r' % e)
                pass
                log('Rename error %r' % e)
            try:
                os.rename(urlbase+'.log',urlnew+'.log')
            except Exception as e:
                log('err 7849 Except: %r' % e)
                pass
                log('Rename error %r' % e)
    except Exception as e:
        log('err 7852 Except: %r' % e)
        pass
        log('Rename error %r' % e)
    
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin("Container.Refresh")

elif mode==1023:
    log('err 1023 mode= %r' % mode)
    try:    ### Set command in FilesDB to: Rename information and subtitles if they are available
        ### mode=1023&url=chan[0]&name=chan[6]&recordname=chan[1]&description=chan[2]
        ### 0 filename, 1 ext, 2 path, 3 video, 4 description, 5 size, 6 archive, 7 updated, 8 created, 9 updatedHuman, 10 command, 11 options
        definition.ADDONresetSetting('lastdatabaseaction','Rename')
        url = url.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
        log('url= %r' % url)
        archive = name 
        fileextt = recordname
        if fileextt != '':
            fileext = '.'+fileextt
        else:
            fileext = ''
        basePath = description
        urlbasename = url # the file name only
        log('urlbasename= %r' % urlbasename)
        log('fileext= %r' % fileext)
        if '[' in urlbasename:
            log('urlbasename= %r' % urlbasename)
            urlbase = urlbasename.split('[')[0]
            urlbasefull = urlbasename
        else:
            urlbasefull = urlbasename
            urlbase     = urlbasefull
        log('urlbasefull= %r' % urlbasefull)
        log('8703 urlbase= %r' % urlbase)
        if urlbase != urlbasefull:
            urlbaselastpart = urlbasefull.replace(urlbase,'...',1)
        else:
            urlbaselastpart = urlbasefull
        urlbase = urlbase.replace('xxYYxx','&')
        urlbasefull = urlbasefull.replace('xxYYxx','&')
        dialog = xbmcgui.Dialog()
        urlnewi = dialog.input('Enter new filename for: \n' + urlbaselastpart, defaultt=urlbase, type=xbmcgui.INPUT_ALPHANUM, autoclose=120000)
        if urlnewi != '':
            urlnewi = recordings.latin1_to_ascii_force(urlnewi)   ### use only acceptable characters
            log('urlbasefull= %r, urlbase= %r, urlnewi= %r' % (urlbasefull, urlbase, urlnewi))
            urlnew = urlbasefull.replace(urlbase,urlnewi)
            log('urlnew= %r' % urlnew)
            conf = recordings.getFilesConnection()
            recordings.createFileTable(conf)
            c = conf.cursor()
            command = 'rename'
            options = urlnew
            recordings.addFileCommand(c, url, fileextt, basePath, archive, command, options)
            conf.commit()
            c.close() 
    except Exception as e:
        log('err 7907 Except: %r' % e)
        pass
        log('Rename in DB error %r' % e)
    
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin("Container.Refresh")
    
elif mode==10234:  ### 'Audio Volumen %' 
    log('error 10234 mode= %r' % mode)
    try:  
        log('error Player.setAudioDelay .250')
        xbmc.executebuiltin("Player.setAudioDelay(0.250)")
    except Exception as e:
        pass
        log('error 4720 Player.setAudioDelay Except: %r' % e)
    lastAudioLevel = definition.ADDONgetSetting('lastAudioLevel')
    utils.setAudioLevel(name)

elif mode==10233:  ### 'Audio Volumen %' 
    log('error 10233 mode= %r' % mode)
    try:  
        log('error Player.setAudioDelay .250')
        xbmc.executebuiltin("Player.setAudioDelay(0.250)")
    except Exception as e:
        pass
        log('error 4720 Player.setAudioDelay Except: %r' % e)
    lastAudioLevel = definition.ADDONgetSetting('lastAudioLevel')
    levels = [lastAudioLevel,'0','10','30','50','75','80','85','90','95','100']
    level = xbmcgui.Dialog().select('Select Volumen Level', levels, preselect= 0, autoclose=25000)
    level = levels[level]
    if int(level) >= 0 :
        utils.setAudioLevel(level)
   
elif mode==10232:  ### Stop player and set volumen to default level
    log('error 10232 mode= %r' % mode)
    try:   ### Experimental 2023-11-08 - not working
        log('error Player.setAudioDelay .250')
        xbmc.executebuiltin("Player.setAudioDelay(0.250)")
    except Exception as e:
        pass
        log('error 4720 Player.setAudioDelay Except: %r' % e)
    utils.setDefaultVideoLevel()
    
elif mode==10231:  ### Change start time og videofile 2020-12-17
    log('err 10231 mode= %r' % mode)
    log('err Change start time ')
    startat = description
    ###starttime = NumericTime(startat,'Enter delayed start of video')
    starttime = TextTime(startat,'Enter delayed start of video as mm:ss')
    filename = url + '.' + recordname
    startmarker.setStartTime(starttime,filename)
    
elif mode==10230:
    log('err 10230 mode= %r' % mode)
    try:    ### Set command in FilesDB to: Change realtitle in db and .tit file
        ### mode=10230&url=chan[0]&name=chan[6]&recordname=chan[1]&description=chan[2]
        ### 0 filename, 1 ext, 2 path, 3 video, 4 description, 5 size, 6 archive, 7 updated, 8 created, 9 updatedHuman, 10 command, 11 options, 12 realtitle
        definition.ADDONresetSetting('lastdatabaseaction','Change Title')
        url = url.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
        log('url= %r' % url)
        archive = name 
        fileextt = recordname
        if fileextt != '':
            fileext = '.'+fileextt
        else:
            fileext = ''
        basePath = description
        urlbasename = url # the file name only
        log('err urlbasename= %r' % urlbasename)
        log('fileext= %r' % fileext)
        if '[' in urlbasename:
            log('urlbasename= %r' % urlbasename)
            urlbase = urlbasename.split('[')[0]
            urlbasefull = urlbasename
        else:
            urlbasefull = urlbasename
            urlbase     = urlbasefull
        log('err urlbasefull= %r' % urlbasefull)
        log('8785 urlbase= %r' % urlbase)
        if urlbase != urlbasefull:
            urlbaselastpart = urlbasefull.replace(urlbase,'...',1)
        else:
            urlbaselastpart = urlbasefull
        urlbase = urlbase.replace('xxYYxx','&')
        urlbasefull = urlbasefull.replace('xxYYxx','&')
        conf = recordings.getFilesConnection()
        c = conf.cursor()
        filename = url
        ext = recordname
        path = description
        archive = name
        log('err recordings.realTitle(c, filename= %r, ext= %r, path= %r, archive= %r)' % (filename, ext, path, archive))
        realtitle = recordings.realTitle(c, filename, ext, path, archive)
        log('err realtitle %r' % realtitle)
        dialog = xbmcgui.Dialog()
        urlnewi = dialog.input('Enter new title for: \n' + filename, defaultt=realtitle, type=xbmcgui.INPUT_ALPHANUM, autoclose=120000)
        if urlnewi != '':
            ###urlnewi = recordings.latin1_to_ascii_force(urlnewi)   ### use only acceptable characters
            log('urlbasefull= %r, urlbase= %r, urlnewi= %r' % (urlbasefull, urlbase, urlnewi))
            urlnew = urlnewi
            log('urlnew= %r' % urlnew)
            conf = recordings.getFilesConnection()
            recordings.createFileTable(conf)
            c = conf.cursor()
            command = 'changetitle'
            options = urlnew
            recordings.addFileCommand(c, url, fileextt, basePath, archive, command, options)
            conf.commit()
            c.close() 
    except Exception as e:
        log('err 7979 Except: %r' % e)
        pass
        log('Change Title in DB error %r' % e)
    
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin("Container.Refresh")

elif mode==1024:
    log('err 1024 mode= %r' % mode)
    try:    ### Set command in FilesDB to: Move information and subtitles if they are available
        ### mode=1023&url=chan[0]&name=chan[6]&recordname=chan[1]&description=chan[2]
        ### 0 filename, 1 ext, 2 path, 3 video, 4 description, 5 size, 6 archive, 7 updated, 8 created, 9 updatedHuman, 10 command, 11 options
        definition.ADDONresetSetting('lastdatabaseaction','Move')
        url = url.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
        log('url= %r' % url)
        archive = name 
        fileextt = recordname
        if fileextt != '':
            fileext = '.'+fileextt
        else:
            fileext = ''
        basePath = description
        urlbasename = url # the file name only
        log('urlbasename= %r' % urlbasename)
        log('fileext= %r' % fileext)
        if '[' in urlbasename:
            log('urlbasename= %r' % urlbasename)
            urlbase = urlbasename.split('[')[0]
            urlbasefull = urlbasename
        else:
            urlbasefull = urlbasename
            urlbase     = urlbasefull
        log('urlbasefull= %r' % urlbasefull)
        log('8850 urlbase= %r' % urlbase)
        if urlbase != urlbasefull:
            urlbaselastpart = urlbasefull.replace(urlbase,'...',1)
        else:
            urlbaselastpart = urlbasefull
        urlbase = urlbase.replace('xxYYxx','&')
        urlbasefull = urlbasefull.replace('xxYYxx','&')
        
        dialog = xbmcgui.Dialog()
        if archive == 'L':
            question = "[COLOR red]Move recording TO Archive?[/COLOR]"
        else:
            question = "[COLOR green]Move recording FROM Archive?[/COLOR]"
        if not dialog.yesno(ADDONname, question +'\n'+ 'Record: ' + urlbase +'\n'+ "What Do You Want To Do","[COLOR red]Move[/COLOR]","[COLOR green]Ignore[/COLOR]"):
            conf = recordings.getFilesConnection()
            recordings.createFileTable(conf)
            c = conf.cursor()
            command = 'move'
            options = url
            recordings.addFileCommand(c, url, fileextt, basePath, archive, command, options)
            conf.commit()
            c.close() 
    except Exception as e:
        log('err 8034 Except: %r' % e)
        pass
        log('Move in DB error %r' % e)
    
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin("Container.Refresh")

elif mode==1124:
    log('err XXXX 1124 mode= %r' % mode)
    try:    ### Set command in FilesDB to: Copy information and subtitles if they are available
        ### mode=1023&url=chan[0]&name=chan[6]&recordname=chan[1]&description=chan[2]
        ### 0 filename, 1 ext, 2 path, 3 video, 4 description, 5 size, 6 archive, 7 updated, 8 created, 9 updatedHuman, 10 command, 11 options
        definition.ADDONresetSetting('lastdatabaseaction','Copy')
        url = url.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
        log('url= %r' % url)
        archive = name 
        fileextt = recordname
        if fileextt != '':
            fileext = '.'+fileextt
        else:
            fileext = ''
        basePath = description
        urlbasename = url # the file name only
        log('urlbasename= %r' % urlbasename)
        log('fileext= %r' % fileext)
        if '[' in urlbasename:
            log('urlbasename= %r' % urlbasename)
            urlbase = urlbasename.split('[')[0]
            urlbasefull = urlbasename
        else:
            urlbasefull = urlbasename
            urlbase     = urlbasefull
        log('urlbasefull= %r' % urlbasefull)
        log('8906 urlbase= %r' % urlbase)
        if urlbase != urlbasefull:
            urlbaselastpart = urlbasefull.replace(urlbase,'...',1)
        else:
            urlbaselastpart = urlbasefull
        urlbase = urlbase.replace('xxYYxx','&')
        urlbasefull = urlbasefull.replace('xxYYxx','&')
        
        dialog = xbmcgui.Dialog()
        if archive == 'L':
            question = "[COLOR red]Copy recording TO Archive?[/COLOR]"
            path = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_path')))
            destination = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_archive_path')))
        else:
            question = "[COLOR green]Copy recording FROM Archive?[/COLOR]"
            path = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_archive_path')))
            destination = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_path')))
        if not dialog.yesno(ADDONname, question +'\n'+ 'Record: ' + urlbase +'\n'+ "What Do You Want To Do","[COLOR red]Copy[/COLOR]","[COLOR green]Ignore[/COLOR]"):
            source = path + urlbasefull + '.*'
            utils.copyFiles(source,destination)
            """
            conf = recordings.getFilesConnection()
            recordings.createFileTable(conf)
            c = conf.cursor()
            command = 'move'
            options = url
            recordings.addFileCommand(c, url, fileextt, basePath, archive, command, options)
            conf.commit()
            c.close()
            """            
    except Exception as e:
        log('err 8097 Except: %r' % e)
        pass
        log('Copy in DB error %r' % e)
    
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin("Container.Refresh")
    
elif mode==1025:
    log('Exception 1025 mode= %r' % mode)
    
    try:    ### Execute all commands and update db
        ### mode=1023&url=chan[0]&name=chan[6]&recordname=chan[1]&description=chan[2]
        ### 0 filename, 1 ext, 2 path, 3 video, 4 description, 5 size, 6 archive, 7 updated, 8 created, 9 updatedHuman, 10 command, 11 options
        definition.ADDONresetSetting('lastdatabaseaction','Execute Commands and Update')
        dialog = xbmcgui.Dialog()
        url = url.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
        log('Exception mode= %r, url= %r' % (mode,url))
        lockedscans = locking.isAnyFileScanLocked()
        if lockedscans != []:
            notetext = 'No File Scanning of L, A, B or F archives as %r is still running!'% lockedscans
            definition.ADDONresetSetting('filescanstatus',notetext)
            log('Exception mode=2 %r, url= %r' % (mode,url))
            utils.notificationforced('No File Scanning of L, A, B or F archives as %r is still running!'% lockedscans)
            log('Exception notetext 2 %r' % notetext)
            if not dialog.yesno(ADDONname, notetext,"[COLOR red]Ignore[/COLOR]","[COLOR green]Release Locks[/COLOR]", autoclose=25000):
                log('Exception Accept Scan Locks')
            else:
                log('Exception scanUnlockAll')
                locking.scanUnlockAll()
            log('Exception mode=3 %r, url= %r' % (mode,url))
        else:
            archives=['All Archives','Local/Recordings','Archive A','Archive B','Archive F']
            question = "[COLOR red]Execute commands in Files DB and update DB?[/COLOR] All, L, A, B, F"
            zx = 1
            SelectedFolder = dialog.select('Select Archive to Scan: ', archives, preselect = zx)
            log('Exception SelectedFolder= %r ==> %r' % (SelectedFolder,archives[SelectedFolder]))
            
            if SelectedFolder != -1:  
                if SelectedFolder == 0:
                        recordings.setAlarm('updatefilesall','updatefiles.py','all','00:00:00','silent')
                elif SelectedFolder == 1:
                        recordings.setAlarm('updatefileslocal','updatefiles.py','l','00:00:00','silent')
                elif SelectedFolder == 2:
                        recordings.setAlarm('updatefilesa','updatefiles.py','a','00:00:00','silent')
                elif SelectedFolder == 3:
                        recordings.setAlarm('updatefilesb','updatefiles.py','b','00:00:00','silent')
                elif SelectedFolder == 4:
                        recordings.setAlarm('updatefilesf','updatefiles.py','f','00:00:00','silent')
                
    except Exception as e:
        pass
        log('Execute commands in DB Exception %r' % e)

elif mode==1026:
    log('err 1026 mode= %r' % mode)
    try:    ### Delete file
        definition.ADDONresetSetting('lastdatabaseaction','Delete File')
        url = url.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
        log('url= %r' % url)
        archive = name 
        fileextt = recordname
        if fileextt != '':
            fileext = '.'+fileextt
        else:
            fileext = ''
        basePath = description
        urlbasename = url # the file name only
        log('urlbasename= %r' % urlbasename)
        log('fileext= %r' % fileext)
        if '[' in urlbasename:
            log('urlbasename= %r' % urlbasename)
            urlbase = urlbasename.split('[')[0]
            urlbasefull = urlbasename
        else:
            urlbasefull = urlbasename
            urlbase     = urlbasefull
        log('urlbasefull= %r' % urlbasefull)
        log('9004 urlbase= %r' % urlbase)
        if urlbase != urlbasefull:
            urlbaselastpart = urlbasefull.replace(urlbase,'...',1)
        else:
            urlbaselastpart = urlbasefull
        urlbase = urlbase.replace('xxYYxx','&')
        urlbasefull = urlbasefull.replace('xxYYxx','&')
        
        dialog = xbmcgui.Dialog()
        
        question = "[COLOR red]DELETE recording?[/COLOR]"
        
        if not dialog.yesno(ADDONname, question +'\n'+ 'Record: ' + urlbase +'\n'+ "What Do You Want To Do","[COLOR red]DELETE[/COLOR]","[COLOR green]Ignore[/COLOR]"):
            conf = recordings.getFilesConnection()
            recordings.createFileTable(conf)
            c = conf.cursor()
            command = 'delete'
            options = url
            recordings.addFileCommand(c, url, fileextt, basePath, archive, command, options)
            conf.commit()
            c.close() 
    except Exception as e:
        log('err 8171 Except: %r' % e)
        pass
        log('Delete File in DB error %r' % e)
        
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin("Container.Refresh")
 
elif mode==1027:
    log('err 1027 mode= %r' % mode)
    try:    ### Clear command
        definition.ADDONresetSetting('lastdatabaseaction','Clear Command')
        url = url.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename - Accept + in filename
        log('err url= %r' % url)
        archive = name 
        fileextt = recordname
        if fileextt != '':
            fileext = '.'+fileextt
        else:
            fileext = ''
        basePath = description
        urlbasename = url # the file name only
        log('err urlbasename= %r' % urlbasename)
        log('err fileext= %r' % fileext)
        if '[' in urlbasename:
            log('errr urlbasename= %r' % urlbasename)
            urlbase = urlbasename.split('[')[0]
            urlbasefull = urlbasename
        else:
            urlbasefull = urlbasename
            urlbase     = urlbasefull
        log('err urlbasefull= %r' % urlbasefull)
        log('9057 urlbase= %r' % urlbase)
        if urlbase != urlbasefull:
            urlbaselastpart = urlbasefull.replace(urlbase,'...',1)
        else:
            urlbaselastpart = urlbasefull
        urlbase = urlbase.replace('xxYYxx','&')
        urlbasefull = urlbasefull.replace('xxYYxx','&')
        
        dialog = xbmcgui.Dialog()
        
        question = "[COLOR red]Clear Command?[/COLOR]"
        ### xbmcgui.Dialog().yesno(heading, message, [nolabel, yeslabel, autoclose])
        if not dialog.yesno(ADDONname ,question + '\n' + 'Record: ' + urlbase + "\nWhat Do You Want To Do","[COLOR red]Clear[/COLOR]","[COLOR green]Ignore[/COLOR]"):
            conf = recordings.getFilesConnection()
            recordings.createFileTable(conf)
            c = conf.cursor()
            command = ''
            options = ''
            recordings.addFileCommand(c, url, fileextt, basePath, archive, command, options)
            conf.commit()
            c.close() 
    except Exception as e:
        log('err 8223 Except: %r' % e)
        pass
        log('1 Clear in DB error %r' % e)
    
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin("Container.Refresh")

elif mode==1028: 
    log('err 1028 mode= %r' % mode)
    try:    ### Set command to Move to folder
        ### mode=1023&url=chan[0]&name=chan[6]&recordname=chan[1]&description=chan[2]
        ### 0 filename, 1 ext, 2 path, 3 video, 4 description, 5 size, 6 archive, 7 updated, 8 created, 9 updatedHuman, 10 command, 11 options
        definition.ADDONresetSetting('lastdatabaseaction','Move to Folder')
        url = url.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
        log('1028 url= %r' % url)
        
        archive = name 
        fileextt = recordname
        
        if fileextt != '':
            fileext = '.'+fileextt
        else:
            fileext = ''
        basePath = description
        
        ### Select from all local or archive folders or create a new
        conf = recordings.getFilesConnection()
        recordings.createFileTable(conf)
        c = conf.cursor()
        c.execute("SELECT DISTINCT archive, path FROM files WHERE NOT path=?", ['']) 
        channels = c.fetchall()
        channels = sorted(channels, key=itemgetter('archive'))  ### , reverse=True if local first
        channels = sorted(channels, key=itemgetter('path'))
        folders = ['New Folder']
        
        for chan in channels:
            folders.append(chan[0].lower() + ':' + chan[1])
           
        try:
            urlbase = url.replace('.',':').split('[')[0].split(';')[0].split(':')[0].split('-')[0].split(' ')[0].split('\xe2\x80\x93')[0].strip()   ### 2024-01-01
            ###urlbase = url.split('[')[0].split(';')[0].split(':')[0].split('-')[0].split(' ')[0].split('\xe2\x80\x93')[0].strip()   ### 2024-01-01
            log('9119 urlbase= %r' % urlbase)
            if len(urlbase) < 5:
                urlbase = url.replace('[','').replace(':','').replace(';','').replace('-','').replace('\xe2\x80\x93','')
                log('9122 urlbase= %r' % urlbase)
                urlbase = urlbase[:5].strip()
                log('9124 urlbase= %r' % urlbase)
            
            log('9126 urlbase= %r' % urlbase)
            zx = 0
            for y in range(0, len(folders)):
                if urlbase in folders[y]:  ### Find first entry with match
                    zx = y
                    break
        except Exception as e:
            log('error 8276 Except: %r' % e)
            pass
            log('9135 urlbase= %r\nERROR: ' % (urlbase,e))
            urlbase = ''
            zx = 0
            
        SelectedFolder = xbmcgui.Dialog().select('Select Folder for: ' + url, folders,preselect = zx)
        log('SelectedFolder= %r ==> %r' % (SelectedFolder,folders[SelectedFolder]))
        dialog = xbmcgui.Dialog()
        if SelectedFolder == 0:   ### New Folder
            SetFolder = dialog.select('Select Local or Archive for: ' + url, places)
            if SetFolder != -1:
                place = places[SetFolder]
                ### Get folder and check if it exists
                log('error Selected Local or Archive for: %r ==> %r' % (url, place))
                try:
                    urlbase = place + url.split('[')[0].split(';')[0].split(':')[0].split('-')[0].split('-')[0].split('\xe2\x80\x93')[0].strip()
                except Exception as e:
                    log('err 8293 Except: %r' % e)
                    pass
                    log('9153 urlbase= %r\nERROR: ' % (urlbase,e))
                    urlbase = place
                urlnewi = dialog.input('Enter New Folder: \n' + url, defaultt=urlbase, type=xbmcgui.INPUT_ALPHANUM, autoclose=120000)
                log('NewFolder= %r' % (urlnewi))
                if 'l:' in urlnewi or 'a:' in urlnewi or 'b:' in urlnewi:
                    newfolder = urlnewi.replace('l:','').replace('a:','').replace('b:','')
                    archiveN = urlnewi[:1].upper()
                    c.execute("SELECT DISTINCT archive, path FROM files WHERE archive=? AND path=?", [archiveN,newfolder]) 
                    channels = c.fetchall()
                    log('channels= %r, len(channels)= %r' % (channels,len(channels)))
                    if len(channels) == 0:   ### New folder - create it in db
                        command = 'movetofolder'
                        options = urlnewi
                        log('recordings.addFileCommand(c, url= %r, fileextt= %r, basePath= %r, archive= %r, command= %r, options= %r)' % (url, fileextt, basePath, archive, command, options))
                        recordings.addFileCommand(c, url, fileextt, basePath, archive, command, options)
                        log('1: recordings.addFileCommand(c, url= %r, fileextt= %r, basePath= %r, archive= %r, command= %r, options= %r)' % (url, fileextt, basePath, archive, command, options))
                        conf.commit()
        elif SelectedFolder != -1:
            command = 'movetofolder'
            options = folders[SelectedFolder]
            recordings.addFileCommand(c, url, fileextt, basePath, archive, command, options)
            conf.commit()
        c.close() 
    except Exception as e:
        log('err 8318 Except: %r' % e)
        pass
        log('Move to Folder error %r' % e)
    
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin("Container.Refresh")

elif mode==1029:  ### Clear the File Database and start a new scan
    log('err 1029 mode= %r' % mode)
    dialog = xbmcgui.Dialog()
    if dialog.yesno(ADDONname, "[COLOR red]Delete File Database and start a new scan?[/COLOR]" +'\n'+ "What Do You Want To Do","[COLOR red]Delete[/COLOR]","[COLOR green]Ignore[/COLOR]"):
        ### Ignore
        lockcause = 'ignore' ### Dummy command
    else:
        ### Stop recording and record new
        lockcause = 'change' ### Dummy command
        recordings.deleteFileBase()
        sleep(1000)
        updateepg.ScanRecordings('all')
        
elif mode==1032:
    log('err 1032 mode= %r' % mode)
    try:    ### Delete share path - logs
        sharepathf = os.path.join(datapath,'sharepath.set')
        deleteFile(sharepathf)
    except Exception as e:
        log('err 8686 Except: %r' % e)
        pass
            
elif mode==1031:  ### Multiselect
    log('err 1031 mode= %r' % mode)
    """
    Function: xbmcgui.Dialog().multiselect(heading, options[, autoclose, preselect, useDetails])
    Show a multi-select dialog.
    Parameters
    heading string or unicode - dialog heading.
    options list of strings / xbmcgui.ListItems - options to choose from.
    autoclose   [opt] integer - milliseconds to autoclose dialog. (default=do not autoclose)
    preselect   [opt] list of int - indexes of items to preselect in list (default: do not preselect any item)
    useDetails  [opt] bool - use detailed list instead of a compact list. (default=false)
    Returns
    Returns the selected items as a list of indices, or None if cancelled.
    """
    dialog = xbmcgui.Dialog()
    actions = ['Rename','Move','Move to Folder','Delete','Clear Command']
    selected = dialog.select(ADDONname + ' [COLOR pink]Select Action[/COLOR]', actions)
    if selected >= 0:
        command = actions[selected]
        url = url.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
        commandline = command
        if command == actions[2]:            ###'Move to Folder':
            ### Select from all local or archive folders or create a new
            conf = recordings.getFilesConnection()
            recordings.createFileTable(conf)
            c = conf.cursor()
            c.execute("SELECT DISTINCT archive, path FROM files WHERE NOT path=?", ['']) 
            channels = c.fetchall()
            channels = sorted(channels, key=itemgetter('archive'))
            channels = sorted(channels, key=itemgetter('path'))
            ###channels = sorted(channels, key=itemgetter('archive'))  ### , reverse=True if local first - without this just sort path without archive letter
            folders = ['New Folder']
            for chan in channels:
                log('error chan= %r' % chan)
                folders.append(chan[0].lower() + ':' + chan[1])
                log('error folders= %r' % folders)
            try:
                urlbase = ''
                urlhash = url.split('#')
                zx = 0
                for z in range(1, len(urlhash)):
                    if urlhash[z].split(':')[4] == '':  ### Find first entry without command
                        """
                        urlbase = url.split('#')[z].split('[')[0].split(':')[0].split('-')[0].split('-')[0].split('\xe2\x80\x93')[0].strip()
                        if len(urlbase) < 5:
                            urlbase = url[:5]
                        """
                        urlbase = url.split('#')[z].split('[')[0].split(';')[0].split(':')[0].split('-')[0].split(' ')[0].split('\xe2\x80\x93')[0].strip()
                        log('9252 urlbase= %r' % urlbase)
                        if len(urlbase) < 5:
                            urlbase = url.split('#')[z].replace('[','').replace(':','').replace(';','').replace(';','').replace('-','').replace('\xe2\x80\x93','')
                            log('9255 urlbase= %r' % urlbase)
                            urlbase = urlbase[:5].strip()
                            log('9257 urlbase= %r' % urlbase)
                        break
                log('9259 urlbase= %r' % urlbase)
                for y in range(0, len(folders)):
                    if urlbase in folders[y]:  ### Find first entry with match
                        zx = y
                        break
            except Exception as e:
                log('err 8395 Except: %r' % e)
                pass
                log('ERROR= %r' % e)
                urlbase = ''
                zx = 0
            
            ### xbmcgui.Dialog().select(heading, list[, autoclose, preselect, useDetails])
            SelectedFolder = xbmcgui.Dialog().select('Select Folder for: ' + command + ' - ' + urlbase, folders,preselect = zx)
            log('error SelectedFolder= %r ==> %r' % (SelectedFolder,folders[SelectedFolder]))
            commandline = command + ': ' + folders[SelectedFolder]
            if SelectedFolder < 0:
                command = actions[1]
                commandline = command
                log('Command changed from Move to Folder to Move!')
            if SelectedFolder == 0:  ### New Folder
                dialog = xbmcgui.Dialog()
                SetFolder = dialog.select('Select Local or Archive for: ' + command, places)
                if SetFolder == -1:
                    commandline = 'ignore: '
                else:
                    place = places[SetFolder]
                    ### Get folder and check if it exists
                    log('error Selected Local or Archive for: %r ==> %r' % (url, place))
                    try:
                        urlbase = ''
                        urlhash = url.split('#')
                        for z in range(1, len(urlhash)):
                            if urlhash[z].split(':')[4] == '':  ### Find first entry without command
                                urlbase = place + url.split('#')[z].split('[')[0].split(';')[0].split(':')[0].split('-')[0].split('-')[0].split('\xe2\x80\x93')[0].strip()
                                break
                    except Exception as e:
                        log('err 8425 Except: %r' % e)
                        pass
                        urlbase = place
                    try:
                        urlnewi = dialog.input('Enter New Folder: \n' + url.split('#')[1], defaultt=urlbase, type=xbmcgui.INPUT_ALPHANUM, autoclose=120000)
                    except Exception as e:
                        log('err 8430 Except: %r' % e)
                        pass
                        urlnewi = dialog.input('Enter New Folder: \n' + url, defaultt=urlbase, type=xbmcgui.INPUT_ALPHANUM, autoclose=120000)
                    log('NewFolder= %r' % (urlnewi))
                    if 'l:' in urlnewi or 'a:' in urlnewi or 'b:' in urlnewi:
                        newfolder = urlnewi.replace('l:','').replace('a:','').replace('b:','')
                        archiveN = urlnewi[:1].upper()
                        c.execute("SELECT DISTINCT archive, path FROM files WHERE archive=? AND path=?", [archiveN,newfolder]) 
                        channels = c.fetchall()
                        log('channels= %r, len(channels)= %r' % (channels,len(channels)))
                        if len(channels) == 0:   ### New folder
                            commandX = 'movetofolder'
                            commandline = commandX + ': ' + urlnewi
                        else:
                            commandline = 'ignore: ' + urlnewi
        log('commandline= %r' % commandline)
        ### selectfrom = [commandline]
        if not 'ignore: ' in commandline:
            selectfrom = []
            i=0
            log('error url= %r' % url,showlength=5000)
            for x in url.split('#'): 
                ### '#'+chan[1][0] +'%'+chan[1][1] +'%'+chan[1][2] +'%'+chan[1][6]+'%'+chan[1][10]
                i +=1
                if i != 1:
                    try:
                        log('error i= %r, x= %r' % (i,x))
                        cmdx = x.split(':')
                        log('error i= %r, cmdx= %r' % (i,cmdx))
                        if len(cmdx) == 5:
                            cmd = x.split(':')[4]   ### Command from DB
                            log('error x.split() cmd= %r' % cmd)
                            if command == actions[4] and cmd != '':   ### Clear command
                                selectfrom.append(x)
                            elif command == actions[3] and cmd == '':  ### Delete command and no command
                                selectfrom.append(x)
                            elif command != actions[4] and cmd == '':  ### Not clear command and no command
                                selectfrom.append(x)
                            else:
                                log('error selectfrom not included= %r' % x)
                        else:
                            log('error selectfrom excluded= %r' % x)
                    except Exception as e:
                        log('err 8465 Except: %r' % e)
                        pass
                        selectfrom.append(x)
                        selectfrom.append(repr(e))
                        log('selectfrom x= %r\nERROR= %r' % (x,e))
            log('selectfrom= %r' % selectfrom)
            
            try:
                urlbase = ''
                urlhash = url.split('#')
                for z in range(1, len(urlhash)):
                    if urlhash[z].split(':')[4] == '':  ### Find first entry without command
                        urlbase = url.split('#')[z].split('[')[0].split(';')[0].split(':')[0].split('-')[0].split(' ')[0].split('\xe2\x80\x93')[0].strip()
                        log('9351 urlbase= %r' % urlbase)
                        if len(urlbase) < 5:
                            urlbase = url.split('#')[z].replace('[','').replace(':','').replace(';','').replace('-','').replace('\xe2\x80\x93','')
                            log('9354 urlbase= %r' % urlbase)
                            urlbase = urlbase[:5].strip()
                            log('9356 urlbase= %r' % urlbase)
                        break
                log('9358 urlbase= %r' % urlbase)
            except Exception as e:
                log('err 8486 Except: %r' % e)
                pass
                log('ERROR= %r' % e)
                urlbase = ''
            
            selection = dialog.multiselect(ADDONname + ' [COLOR pink]'+commandline+'[/COLOR]: ' + urlbase, selectfrom)
            log('selection= %r' % selection)
            if selection:
                for x in selection:
                    log('x= %r' % x)
                    if x >= 0:
                        y = selectfrom[x]
                        log('command= %r, y= %r' % (command,y))
                        selecteditem = y.split(':')
                        urlY = selecteditem[0]
                        fileextt = selecteditem[1]
                        basePath = selecteditem[2]
                        archive = selecteditem[3]
                        log('command= %r, selecteditem= %r' % (command,selecteditem))
                        if command == actions[4]:            ###'Clear Command':
                            log('err command= %r' % command)
                            try:    ### Clear command
                                definition.ADDONresetSetting('lastdatabaseaction','Clear Command')
                                urlY = urlY.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename - Accept + in filename
                                log('err urlY= %r' % urlY)
                                conf = recordings.getFilesConnection()
                                recordings.createFileTable(conf)
                                c = conf.cursor()
                                commandY = ''
                                options = ''
                                recordings.addFileCommand(c, urlY, fileextt, basePath, archive, commandY, options)
                                conf.commit()
                                c.close() 
                            except Exception as e:
                                log('err 8519 Except: %r' % e)
                                pass
                                log('Clear in DB error %r' % e)
                                
                        elif command == actions[3]:            ###'Delete':
                            log('command= %r' % command)
                            definition.ADDONresetSetting('lastdatabaseaction','Delete')
                            try:    ### Delete file
                                definition.ADDONresetSetting('lastdatabaseaction','Delete File')
                                urlY = urlY.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
                                log('urlY= %r' % urlY)
                                conf = recordings.getFilesConnection()
                                recordings.createFileTable(conf)
                                c = conf.cursor()
                                commandY = 'delete'
                                options = urlY
                                recordings.addFileCommand(c, urlY, fileextt, basePath, archive, commandY, options)
                                conf.commit()
                                c.close() 
                            except Exception as e:
                                log('err 8538 Except: %r' % e)
                                pass
                                log('Delete File in DB error %r' % e)
                            
                        elif command == actions[2]:            ###'Move to Folder':
                            log('command=XXX %r' % command)
                            definition.ADDONresetSetting('lastdatabaseaction','Move to Folder')
                            try:    ### Set command to Move to folder
                                ### mode=1023&url=chan[0]&name=chan[6]&recordname=chan[1]&description=chan[2]
                                ### 0 filename, 1 ext, 2 path, 3 video, 4 description, 5 size, 6 archive, 7 updated, 8 created, 9 updatedHuman, 10 command, 11 options
                                urlY = urlY.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
                                commandY = 'movetofolder'
                                ###options = folders[SelectedFolder]
                                options = commandline.split(': ')[1]
                                if options == 'New Folder' :
                                    dialog = xbmcgui.Dialog()
                                    dialog.ok("You can't use New Folder in Multi Selection!")
                                else:  
                                    conf = recordings.getFilesConnection()
                                    recordings.createFileTable(conf)
                                    c = conf.cursor()
                                    log('recordings.addFileCommand(c, urlY= %r, fileextt= %r, basePath= %r, archive= %r, commandY= %r, options= %r)' % (urlY, fileextt, basePath, archive, commandY, options))
                                    recordings.addFileCommand(c, urlY, fileextt, basePath, archive, commandY, options)
                                    conf.commit()
                                    c.close() 
                            except Exception as e:
                                log('err 8559 Except: %r' % e)
                                pass
                                log('Move to Folder error %r' % e)
                            
                        elif command == actions[1]:            ###'Move':
                            log('command= %r' % command)
                            try:    ### Set command in FilesDB to: Move information and subtitles if they are available
                                ### mode=1023&url=chan[0]&name=chan[6]&recordname=chan[1]&description=chan[2]
                                ### 0 filename, 1 ext, 2 path, 3 video, 4 description, 5 size, 6 archive, 7 updated, 8 created, 9 updatedHuman, 10 command, 11 options
                                log('command= %r' % command)
                                definition.ADDONresetSetting('lastdatabaseaction','Move')
                                urlY = urlY.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
                                log('urlY= %r' % urlY)
                                urlbasename = urlY # the file name only
                                log('urlbasename= %r' % urlbasename)
                                if '[' in urlbasename:
                                    log('urlbasename= %r' % urlbasename)
                                    urlbase = urlbasename.split('[')[0]
                                    urlbasefull = urlbasename
                                else:
                                    urlbasefull = urlbasename
                                    urlbase     = urlbasefull
                                log('urlbasefull= %r' % urlbasefull)
                                log('9463 urlbase= %r' % urlbase)
                                urlbase = urlbase.replace('xxYYxx','&')
                                urlbasefull = urlbasefull.replace('xxYYxx','&')
                                conf = recordings.getFilesConnection()
                                recordings.createFileTable(conf)
                                c = conf.cursor()
                                commandY = 'move'
                                options = urlY
                                recordings.addFileCommand(c, urlY, fileextt, basePath, archive, commandY, options)
                                conf.commit()
                                c.close() 
                            except Exception as e:
                                log('err 8593 Except: %r' % e)
                                pass
                                log('Move in DB error %r' % e)
                                
                        elif command == actions[0]:               ###'Rename':
                            log('command= %r' % command)
                            try:    ### Set command in FilesDB to: Rename information and subtitles if they are available
                                ### mode=1023&url=chan[0]&name=chan[6]&recordname=chan[1]&description=chan[2]
                                ### 0 filename, 1 ext, 2 path, 3 video, 4 description, 5 size, 6 archive, 7 updated, 8 created, 9 updatedHuman, 10 command, 11 options
                                definition.ADDONresetSetting('lastdatabaseaction','Rename')
                                urlY = urlY.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
                                log('urlY= %r' % urlY)
                                ###archive = name 
                                ###fileextt = recordname
                                if fileextt != '':
                                    fileext = '.'+fileextt
                                else:
                                    fileext = ''
                                ###basePath = description
                                ##urldirectorypath = os.path.dirname(url) # relative directory path
                                ##log('urldirectorypath= %r' % urldirectorypath)
                                urlbasename = urlY # the file name only
                                log('urlbasename= %r' % urlbasename)
                                log('fileext= %r' % fileext)
                                if '[' in urlbasename:
                                    log('urlbasename= %r' % urlbasename)
                                    urlbase = urlbasename.split('[')[0]
                                    urlbasefull = urlbasename
                                else:
                                    urlbasefull = urlbasename
                                    urlbase     = urlbasefull
                                log('urlbasefull= %r' % urlbasefull)
                                log('9507 urlbase= %r' % urlbase)
                                if urlbase != urlbasefull:
                                    urlbaselastpart = urlbasefull.replace(urlbase,'...',1)
                                else:
                                    urlbaselastpart = urlbasefull
                                urlbase = urlbase.replace('xxYYxx','&')
                                urlbasefull = urlbasefull.replace('xxYYxx','&')
                                dialog = xbmcgui.Dialog()
                                log('dialog.input %r' % x)
                                urlnewi = dialog.input('Enter new filename for: \n' + urlbaselastpart, defaultt=urlbase, type=xbmcgui.INPUT_ALPHANUM, autoclose=120000)
                                log('urlnewi= %r' % urlnewi)
                                if urlnewi != '':
                                    urlnewi = recordings.latin1_to_ascii_force(urlnewi)   ### use only acceptable characters
                                    log('urlbasefull= %r, urlbase= %r, urlnewi= %r' % (urlbasefull, urlbase, urlnewi))
                                    urlnew = urlbasefull.replace(urlbase,urlnewi)
                                    log('urlnew= %r' % urlnew)
                                    conf = recordings.getFilesConnection()
                                    recordings.createFileTable(conf)
                                    c = conf.cursor()
                                    commandX = 'rename'
                                    options = urlnew
                                    recordings.addFileCommand(c, urlY, fileextt, basePath, archive, commandX, options)
                                    conf.commit()
                                    c.close() 
                            except Exception as e:
                                log('err 8649 Except: %r' % e)
                                pass
                                log('Rename in DB error %r' % e)
        
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin("Container.Refresh")
                                   
elif mode==1030:   ### Switch Addon
    log('err 1030 mode= %r' % mode)
    dialog = xbmcgui.Dialog()
    log('Switch Addon!')
    addons = krogsbellAddons()
    addons = sorted(addons)
    log('sorted(addons)= %r' % sorted(addons))
    if len(addons) > 0:
        selected = dialog.select(ADDONname + ' - Select an Addon to switch to:', addons) 
        if selected != -1:
            log('selected Addon = %r' % addons[selected])
            ###IDdoADDON = addons[selected].split(': ')[1]
            IDdoADDON = addons[selected].split(':[/COLOR][/B] ')[1]
            log('err selected Addon to switch to= %r - %r' % (addons[selected],IDdoADDON))
            
            xbmc.executebuiltin("Container.Update(path,replace)")
            ###xbmc.executebuiltin("ActivateWindow(Home)")
            xbmc.executebuiltin("ActivateWindow('1000')")
            
            xbmc.executebuiltin('Dialog.Close(busydialog)')   ### 2019-09-03 needed to allow switch addon
            xbmc.executebuiltin('RunAddon(%s)' % (IDdoADDON))
            ###cmd = "Action(Back,%s)" % xbmcgui.getCurrentWindowId()
            ###response = xbmc.executebuiltin(cmd)
            ###log('err response= %r' % response)
            ###xbmc.executebuiltin('RunAddon(%s)' % (IDdoADDON))
    else:
        utils.notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] Switch NOT activated')

elif mode==1038:   ### Remove Switch Addon
    log('err 1038 mode= %r' % mode)
    dialog = xbmcgui.Dialog()
    log('Switch Addon List delete item!')
    addons = krogsbellAddons()
    addons = sorted(addons)
    log('sorted(addons)= %r' % sorted(addons))
    if len(addons) > 0:
        selected = dialog.select(ADDONname + ' - Select an Addon to remove from Switch list:', addons) 
        if selected != -1:
            log('selected Addon = %r' % addons[selected])
            ###IDdoADDON = addons[selected].split(': ')[1]
            IDdoADDON = addons[selected].split(':[/COLOR][/B] ')[1]
            removed = krogsbellAddonsDel(IDdoADDON)
            if removed:
                utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] Switch Addon removed')
            else:
                utils.notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] Switch Addon NOT removed')
        else:
            utils.notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] Switch Addon NOT removed')
    else:
        utils.notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] Switch Addon NOT removed')

elif mode==1050:   ### Calculate free space on drives
    log('err 1050 mode= %r' % mode)
    dialog = xbmcgui.Dialog()
    L = xbmcvfs.translatePath(definition.FileManagerPath('Recordings'))
    Log = xbmcvfs.translatePath(definition.FileManagerPath('log'))
    A = xbmcvfs.translatePath(definition.FileManagerPath('Videos'))
    B = xbmcvfs.translatePath(definition.FileManagerPath('VideosB'))
    F = xbmcvfs.translatePath(definition.FileManagerPath('VideosF'))
    system = xbmcvfs.translatePath('special://masterprofile')
    testdata = [[L,'L'],[A,'A'],[B,'B'],[F,'F'],[Log,'/'],[system,'/']]
    for dirname in testdata :
        log('error utils.get_free_space_gb(dirname[0]= %r,archive=dirname[1]= %r)' % (dirname[0],dirname[1]))
        result = utils.get_free_space_gb(dirname[0],dirname[1])
        dialog.ok('[B]' + ADDONname + '[/B]'+ ' - result dirname= %r, Archive= %r' % (dirname[0],dirname[1]),'[COLOR red]' +str(result)+'[/COLOR]')

elif mode==1039:   ### Add Switch Addon
    log('err 1039 mode= %r' % mode)
    ### progpath
    directory = xbmcvfs.translatePath(os.path.join('special://home/' , 'addons'))
    dirs = os.listdir(directory)
    ###log('err dirs= %r' % dirs)
    addons = []
    for dir in dirs:
        log('err 0 dir= %r' % dir)
        if os.path.isdir(os.path.join(directory,dir)):
            log('err 1 dir= %r' % dir)
            try:
                if 'plugin' in dir.lower() or 'pvr' in dir.lower():
                    targetADDON = xbmcaddon.Addon(id=dir)
                    name = targetADDON.getAddonInfo('name')
                    log('err dir= %r, name= %r' % (dir,name))
                    addons.append([name,dir])
            except Exception as e:
                log('err 8723 Except: %r' % e)
                pass
                log('Not Addon %r\nERROR: %r' % (dir,e))
    log('err addons= %r' %  addons)  
    addons = sorted(addons)
    log('err 1 addons= %r' %  addons) 
    addonsK = krogsbellAddons()
    switchaddons = []
    for addon in addonsK:
        addonA = addon.split(':[/COLOR][/B] ')[1]
        ###if addonA != ADDONid:
        switchaddons.append(addonA)
    log('err switchaddons= %r' %  switchaddons)
    newswitchaddons = []
    for addon in addons:
        if not addon[1] in switchaddons and not addon[1] == ADDONid:    
            newswitchaddons.append('[B][COLOR lightgreen]'+addon[0]+':[/COLOR][/B] '+addon[1])
    newswitchaddons = sorted(newswitchaddons)
    log('err newswitchaddons= %r' %  newswitchaddons) 
    newswitchaddon = ''
    if len(newswitchaddons) > 0:
        dialog = xbmcgui.Dialog()
        selected = dialog.select(ADDONname + ' - Select an Addon to add to Switch list:', newswitchaddons) 
        if selected != -1:
            log('err selected Addon = %r' % newswitchaddons[selected])
            newswitchaddon = newswitchaddons[selected].split(':[/COLOR][/B] ')[1]
    if newswitchaddon != '':
        krogsbellAddonsAdd(newswitchaddon)
        utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] Switch list updated')
    else:
        utils.notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] Switch list was NOT updated')
    
elif mode==1040:
    log('err 1040 mode= %r' % mode)
    try:    ### Convert video file to MP4  -c:v copy -c:a copy -c:s mov_text
        url = url.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
        log('url= %r' % url)
        urldirectorypath = os.path.dirname(url) # relative directory path
        log('urldirectorypath= %r' % urldirectorypath)
        urlbasename = os.path.basename(url) # the file name only
        log('urlbasename= %r' % urlbasename)
        fileext = '.' + url.split('.')[-1]
        log('fileext= %r' % fileext)
        if '[' in urlbasename:
            log('urlbasename= %r' % urlbasename)
            urlbase = urlbasename.split('[')[0]
            urlbasefull = urlbasename.replace(fileext,'',-1)
        else:
            urlbasefull = urlbasename.replace(fileext,'',-1)  ### Remove extension
            urlbase     = urlbasefull
        ###urlbasefull = os.path.basename(urlbasefull)
        log('urlbasefull= %r' % urlbasefull)
        ###urlbase = os.path.basename(urlbase)
        log('9661 urlbase= %r' % urlbase)
        if urlbase != urlbasefull:
            urlbaselastpart = urlbasefull.replace(urlbase,'...',1)
        else:
            urlbaselastpart = urlbasefull
        urlbase = urlbase.replace('xxYYxx','&')
        urlbasefull = urlbasefull.replace('xxYYxx','&')
        dialog = xbmcgui.Dialog()
        urlnewi = dialog.input('Enter new fileextension for: \n' + url, defaultt='mp4', type=xbmcgui.INPUT_ALPHANUM, autoclose=60000)
        if urlnewi != '':
            ### Run convert-ffmpeg.py <filename> <new extension>
            ### Embed (Burn) Subtitles to the Video
            ### ffmpeg -i video.avi -vf subtitles=subtitle.srt out.mp4
            LoopCount = 0
            log('Converting file= %s' % url)
            ##nowHM=datetime.datetime.today().strftime('%H:%M:%S')
            LibPath = utils.libPath()
            extension = '.'+url.split('.')[-1]
            basefile = url.replace(extension,'',-1)
            log('basefile= %s' % basefile)
            subtitle = basefile + '.da.srt'
            subtitleass = basefile.replace('[','').replace(']','') + '.da.srt.ass'
            subtitleen = basefile + '.en.srt'
            subtitleenass = basefile + '.en.srt.ass'
            log('subtitle da file= %s' % subtitle)
            log('subtitle en file= %s' % subtitleen)
            convlog = ' 2> "' + basefile + '_conv_' + urlnewi +'.log"'   ### Save FFMPEG log
            convlogass = ' 2> "' + basefile + '_conv_ass_' + urlnewi +'.log"'   ### Save FFMPEG log
            burn = dialog.yesno(ADDONname, "[COLOR red]Burn Subtitles into Video File?[/COLOR]" +'\n'+ "What Do You Want To Do","[COLOR green]Ignore[/COLOR]","[COLOR red]Burn[/COLOR]")
            log('burn subtitle into video file= %r' % burn)
            if os.path.exists(subtitle) and burn:
                ###log('burn subtitle file= %s' % subtitle)
                ###cmd = 'ffmpeg -i "' + subtitle + '" "' + basefile + '.ass"'
                ###utils.runCommand(cmd, LoopCount, LibPath)
                #cmd = 'ffmpeg -y -i "'+url+ '" -c copy "' + basefile +'.mp4' +'"' # Use seperately installed ffmpeg program ###
                #utils.runCommand(cmd, LoopCount, LibPath)
                ### ffmpeg -i subtitles.srt subtitles.ass
                cmdass = 'ffmpeg -y -i "' + subtitle + '" "' + subtitleass +'"'+ convlogass
                cmd = 'ffmpeg -y -i "' + url +'" -vf subtitles="' + subtitleass + '" "' + basefile + '_conv_da_srt.'+urlnewi+'"' + convlog
                ###cmd = 'ffmpeg -y -i "' + url +'" -i "' + subtitle + '" -c copy -c:s mov_text "' + basefile + '_conv_da_srt.'+urlnewi+'"' + convlog
                ### ffmpeg -i mymovie.mp4 -vf ass=subtitles.ass mysubtitledmovie.mp4
                cmd = 'ffmpeg -y -i "' + url +'" -vf ass="' + subtitleass + '" "' + basefile + '_conv_da_srt_ass.'+urlnewi+'"' + convlog
                utils.runCommand(cmdass, LoopCount, LibPath)
                utils.log(module,'Convert cmd 1= %r' % cmd)
                if os.path.exists(subtitleass):
                    utils.runCommand(cmd, LoopCount, LibPath)
            elif os.path.exists(subtitleen) and burn:
                cmd = 'ffmpeg -y -i "' + url +'" -vf subtitles="' + subtitleen + '" "' + basefile + '_conv_en_srt.'+urlnewi+'"' + convlog
                
                utils.log(module,'Convert cmd 2= %r' % cmd)
                utils.runCommand(cmd, LoopCount, LibPath)
            else:
                log('ignore subtitle file= %s' % subtitle)
                cmd = 'ffmpeg -y -i "'+url+ '" -c copy "' + url.replace(url.split('.')[-1],'_conv_.'+urlnewi,-1) +'"' + convlog # Use seperately installed ffmpeg program ###
                
                utils.log(module,'Convert cmd 3= %r' % cmd)
                utils.runCommand(cmd, LoopCount, LibPath)
            utils.notification('Converting %s [COLOR red]complete[/COLOR]' % url)
            ###xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        log('err 8835 Except: %r' % e)
        pass
        log('Convert video file FAILED ERROR: %r' % e)

    """
    ffmpeg -i infile.mp4 -i infile.srt -c copy -c:s mov_text outfile.mp4
    -vf subtitles=infile.srt will not work with -c copy

    The order of -c copy -c:s mov_text is important. You are telling FFmpeg:

    Video: copy, Audio: copy, Subtitle: copy
    Subtitle: mov_text
    If you reverse them, you are telling FFmpeg:

    Subtitle: mov_text
    Video: copy, Audio: copy, Subtitle: copy
    Alternatively you could just use -c:v copy -c:a copy -c:s mov_text in any order.
    """
### mkchromecast [-s] --video -i "Spise med Price- Nordisk Odysse Sverige (1-6) 2018 [0h44m][DR NU][2019-04-30 12-25 KRO ].ts" --subtitles "Spise med Price- Nordisk Odysse Sverige (1-6) 2018 [0h44m][DR NU][2019-04-30 12-25 KRO ].da.srt"
elif mode==1041:
    log('err 1041 mode= %r' % mode)
    try:    ### Play video file with mkchromecast if installed
      if chromecast:
        url = url.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
        log('url= %r' % url)
        if chromecast != 'Active':
            LoopCount = 0
            log('Casting file= %s' % url)
            ##nowHM=datetime.datetime.today().strftime('%H:%M:%S')
            LibPath = utils.libPath()
            extension = '.'+url.split('.')[-1]
            basefile = url.replace(extension,'',-1)
            log('basefile= %s' % basefile)
            subtitle = basefile + '.da.srt'
            subtitleen = basefile + '.en.srt'
            log('subtitle file= %s' % subtitle)
            dialog = xbmcgui.Dialog()
            if os.path.exists(subtitle) and dialog.yesno(ADDONname, "[COLOR red]Use Danish Subtitles into Video File?[/COLOR]" +'\n'+ "What Do You Want To Do","[COLOR red]Burn[/COLOR]","[COLOR green]Ignore[/COLOR]"):
                ### mkchromecast --video -i "xxx.ts" --subtitles "xxx.da.srt"
                cmd = 'mkchromecast --video -i "' + url +'" --subtitles "' + subtitle +'"'
                subpr = utils.runCommand(cmd, LoopCount, LibPath)
            elif os.path.exists(subtitleen) and dialog.yesno(ADDONname, "[COLOR red]Use English Subtitles into Video File?[/COLOR]" +'\n'+ "What Do You Want To Do","[COLOR red]Burn[/COLOR]","[COLOR green]Ignore[/COLOR]"):
                ### mkchromecast --video -i "xxx.ts" --subtitles "xxx.da.srt"
                cmd = 'mkchromecast --video -i "' + url +'" --subtitles "' + subtitleen +'"'
                subpr = utils.runCommand(cmd, LoopCount, LibPath)
            else:
                log('ignore subtitle file= %s' % subtitle)
                ### mkchromecast --video -i "xxx.ts"
                cmd = 'mkchromecast --video -i "' + url +'"'
                subpr = utils.runCommand(cmd, LoopCount, LibPath)
            definition.ADDONresetSetting('castsubprX',repr(subpr))
            utils.notification('Casting %s [COLOR red]complete[/COLOR]' % url)
            ###xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        log('err 8888 Except: %r' % e)
        pass
        log('Cast video file FAILED ERROR: %r' % e)

### terminateSubpr(subpr) fra cast!
elif mode==1042:
  log('err 1042 mode= %r' % mode)  
  try: 
    if chromecast == 'Active':
        subpr = str(utils.intADDONgetSetting('castsubpr') +1)
        #subpr = definition.ADDONgetSetting('castsubpr')
        subprcmd = definition.ADDONgetSetting('castsubprcmd')
        dialog = xbmcgui.Dialog()
        if dialog.yesno(ADDONname, "[COLOR red]Stop Carsting?[/COLOR]" +'\n'+ str(subpr)+': '+subprcmd +'\n'+ "What Do You Want To Do","[COLOR red]Stop Casting[/COLOR]","[COLOR green]Ignore[/COLOR]"):
            ### Ignore
            lockcause = 'ignore' ### Dummy command
        else:
            ### Stop casting
            lockcause = 'change' ### Dummy command
            definition.ADDONresetSetting('castsubpr','')
            definition.ADDONresetSetting('castsubprcmd','')
            utils.terminateSubpr(subpr)
  except Exception as e:
    log('err 8910 Except: %r' % e)
    pass

elif mode==1043:  ### Open URL in browser
  log('err 1043 mode= %r' % mode)
  try: 
    ###file = urlopen(url)
    data = utils.readlink(url,'',module)
    ###data = file.read()
    log('err url=%r\ndata= %r' % (url,data))
    ###file.close()
    log('Get .png in URL= %r\nContains: %r' % (url,data))
    ### src="/assets/images/logo_dark.png"
    logo = url + data.split('.png')[0].split('src="')[1] + '.png'
    log('Get .png in logo= %r' % (logo))
    ###m3ufile = urlopen(logo)
    ChannelFile2 = os.path.join(datapath,ADDONid) + '.logo.png'
    data = utils.readlink(logo,ChannelFile2,module)
    ###with open(ChannelFile2,'wb') as output:
    ###    output.write(m3ufile.read())
    log('Get .png in ChannelFile2= %r' % (ChannelFile2)) 
    logo = url + data.split('.jpg')[0].split('src="')[1] + '.jpg'
    log('Get .jpg in logo= %r' % (logo))
    ###m3ufile = urlopen(logo)
    ChannelFile2 = os.path.join(datapath,ADDONid) + '.logo.jpg'
    data = utils.readlink(logo,ChannelFile2,module)
    ###with open(ChannelFile2,'wb') as output:
    ###    output.write(m3ufile.read())
    log('Get .jpg in ChannelFile2= %r' % (ChannelFile2)) 
  except Exception as e:
    log('err 8939 Except: %r' % e)
    pass
    log('Get .png and .jpg in URL: %r\nFAILED ERROR: %r' % (url,e)) 
  try:    
    import webbrowser
    webbrowser.open(url)
    utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] Webbrowser was started with IPTV Home')
  except Exception as e:
    log('err 8946 Except: %r' % e)
    pass
    log('Open URL in browser %r\nFAILED ERROR: %r' % (url,e))
    utils.notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] Webbrowser start with IPTV Home failed: %r'% e)

elif mode==1044:  ### Open Web Client Portal in browser
  log('err 1044 mode= %r' % mode)
  try: 
    newurl = url
    WebClientPortal = definition.ADDONgetSetting('WebClientPortal')
    if WebClientPortal == '':
        newurl = url + '/client_area/index.php?username=' +IPTVuser+ '&password=' +definition.ADDONgetSetting('pass')
    else:
        newurl = WebClientPortal
    log('Open Web Client Portal in browser %r' % (newurl))
  except Exception as e:
    log('err 8961 Except: %r' % e)
    pass
    log('Get Web Client Portal in browser %r\nFAILED ERROR: %r' % (url,e))
  
  try: 
    ###file = urlopen(url)
    ###data = file.read()
    data = utils.readlink(url,'',module)
    log('err url=%r\ndata= %r' % (url,data))
    ###file.close()
    log('Get .png in URL= %r\nContains: %r' % (url,data))
    ### src="/assets/images/logo_dark.png"
    logo = url + data.split('.png')[0].split('src="')[1] + '.png'
    log('Get .png in logo= %r' % (logo))
    
    ###m3ufile = urlopen(logo)
    ChannelFile2 = os.path.join(datapath,ADDONid) + '.logo.png'
    
    ###with open(ChannelFile2,'wb') as output:
    ###    output.write(m3ufile.read())
    data = utils.readlink(logo,ChannelFile2,module)
    log('Get .png in ChannelFile2= %r' % (ChannelFile2)) 
    logo = url + data.split('.jpg')[0].split('src="')[1] + '.jpg'
    log('Get .jpg in logo= %r' % (logo))
    ###m3ufile = urlopen(logo)
    ChannelFile2 = os.path.join(datapath,ADDONid) + '.logo.jpg'
    data = utils.readlink(logo,ChannelFile2,module)
    ###with open(ChannelFile2,'wb') as output:
    ###    output.write(m3ufile.read())
    log('err Get .jpg in ChannelFile2= %r' % (ChannelFile2)) 
  except Exception as e:
    log('err 8991 Except: %r' % e)
    pass
    log('Get .png and .jpg in URL: %r\nFAILED ERROR: %r' % (url,e))
  
  try:   
    import webbrowser
    webbrowser.open(newurl)
    utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] Web Client Portal was started')
  except Exception as e:
    log('err 8999 Except: %r' % e)
    pass
    log('Open Web Client Portal in browser %r\nFAILED ERROR: %r' % (newurl,e))
    utils.notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] Web Client Portal failed: %r' % e)

elif mode==1045:  ### Open VLC with favorite channels
  log('err 1045 mode= %r' % mode)
  try: 
    vlcexecutive = utils.getvlcexecutive()
    log("error vlcexecutive= %r" % vlcexecutive)
    if vlcexecutive == '':
        utils.notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] VLC was not started')
    else:
        cmd = '"' + vlcexecutive + '" --fullscreen --play-and-stop "' + os.path.join(datapath,ADDONname) + ' Favorites.m3u"'
        log("error cmd= %r" % cmd)
        RunCmd('"' + cmd + '"')
        utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] VLC was started')
  except Exception as e:
    log('err 9010 Except: %r' % e)
    pass
    log('Open VLC with favorite channels %r\nFAILED ERROR: %r' % (url,e))
    utils.notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] VLC start failed: %r' % e)

elif mode==1046:  ### Open VLC with all channels
  log('err 1046 mode= %r' % mode)
  try: 
    vlcexecutive = utils.getvlcexecutive()
    log("error vlcexecutive= %r" % vlcexecutive)
    if vlcexecutive == '':
        utils.notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] VLC was not started')
    else:
        cmd = '"' + vlcexecutive + '" --fullscreen --play-and-stop "' + os.path.join(datapath,ADDONid) + '.m3u"'
        log("error cmd= %r" % cmd)
        RunCmd('"' + cmd + '"')
        utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] VLC All Channels was started')
  except Exception as e:
    log('err 9021 Except: %r' % e)
    pass
    log('Open VLC with all channels %r\nFAILED ERROR: %r' % (url,e))
    utils.notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] VLC All Channels start failed: %r'%e)
    
elif mode==1047:  ### Open VLC with all channels from basicuserinfofile
  log('err 1047 mode= %r' % mode)
  try: 
    vlcexecutive = utils.getvlcexecutive()
    log("1047 error vlcexecutive= %r" % vlcexecutive)
    if vlcexecutive == '':
        utils.notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] VLC was not started')
    else:
        cmd = '"' + vlcexecutive + '" --fullscreen --play-and-stop "' + definition.ADDONgetSetting('basicuserinfofile') + '"'
        log("error cmd= %r" % cmd)
        RunCmd('"' + cmd + '"')
        utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] VLC All Channels from basic user info was started')
  except Exception as e:
    log('err 9032 Except: %r' % e)
    pass
    log('Open VLC with all original channels %r\nFAILED ERROR: %r' % (url,e))
    utils.notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] VLC All Channels from basic user info start failed: %r'%e)

elif mode==200:
    log('errX 200 mode= %r cat= %r' % (mode,cat))
    if cat != '#':
        log('err Mode=200: name= %s,recordname= %s,cat= %s,url= %s,description= %s'% (name,recordname,cat,url,description))
        oldPlay = definition.ADDONgetSetting('oldPlay')
        try:
            oldPlayTime = utils.intADDONgetSetting('oldPlayTime')
        except Exception as e:
            log('err 9044 Except: %r' % e)
            pass
            log('oldPlayTime Except ERROR: %r' % e)
            oldPlayTime = 0
        nowTS = int(time.mktime(datetime.now().timetuple()))
        log('err nowTS= %r' % nowTS)
        log('err nowTS - oldPlayTime= %r' % (nowTS - oldPlayTime))
        log('err url= %r' % url)
        log('err oldPlay= %r' % oldPlay)
        log('err oldPlayTime= %r' % oldPlayTime)
        if 1==1 or(url != oldPlay and nowTS - oldPlayTime > 60):  ###Just play
            definition.ADDONresetSetting('oldPlay',url)
            definition.ADDONresetSetting('oldPlayTime',str(oldPlayTime))
            log('err PLAY_STREAM(name= %r,url= %r,iconimage= %r,cat= %r)' % (name,url,iconimage,cat))
            try:
                log('err before PLAY_STREAM(name= %r,url= %r,iconimage= %r,cat= %r)' % (name,url,iconimage,cat))
                PLAY_STREAM(name,url,iconimage,cat)
                log('err after PLAY_STREAM(name= %r,url= %r,iconimage= %r,cat= %r)' % (name,url,iconimage,cat))
            except Exception as e:
                pass
                log('9352 PLAY_STREAM(name= %r,url= %r,iconimage= %r,cat= %r) ERROR: %r' % (name,url,iconimage,cat,e))
        
    
elif mode==210:
    log('err 210 mode= %r' % mode)
    #playcmd='plugin://plugin.video.wozboxntv/?url=url&mode=200&name=IPTV&iconimage=http://www.ntv.mx/res/content/tv/240.png&cat=%s'% cat 
    
    startD = recordings.parseDate(datetime.now())
    endD = startD
    
    recordingsActive = []
    recordingsActiveAll = recordings.getRecordingsActive(startD,endD)
    log('recordingsActiveAll= %s' % repr(recordingsActiveAll))
    for x in recordingsActiveAll:
        log('x= %r' % x)
        if not '[COLOR orange]' in x and not '[COLOR violet]' in x :
            recordingsActive.append(x)
            log('recordingsActive= %s' % repr(recordingsActive))
    if (recordingsActive != []) and locking.isAnyRecordLocked():
        utils.notification('OVERLAPPING Recordings Warning: %s' % str(recordingsActive))
        #if (repr(recordingsActive) != "[]"):
        lockcause = repr(locking.RecordsLocked())
        #else:
        #   lockcause = repr(recordingsActive)
        dialog = xbmcgui.Dialog()
        if dialog.yesno(ADDONname, "[COLOR red]Stop recording?[/COLOR]" +'\n'+ repr(recordingsActive) +'\n'+ "What Do You Want To Do","[COLOR red]Stop recording[/COLOR]","[COLOR green]Ignore[/COLOR]"):
            ### Ignore and return
            try:
                xbmc.executebuiltin('Dialog.Close(busydialog)')
                xbmc.executebuiltin('RunAddon(' + recordname + ')')  ### Return
            except Exception as e:
                log('err 9087 Except: %r' % e)
                pass
                log('Return to caling addon failed ERROR: %r' % e)
        #else:
            ### Continue
    
    # Show menuentry 
    menuname= 'Get IPTV from ' + ADDONrefer + ' - %s (%s)' % (name,cat)
    liz=xbmcgui.ListItem(menuname)
    xbmcplugin.addDirectoryItem(handle = Handle, url='url',listitem = liz, isFolder = True) 
    playcmd='plugin://' + ADDONid + '/?url=url&mode=200&name=%s&cat=%s'% (name,cat)
    if definition.ADDONgetSetting('fullscreen') == 'true':
        fullscreen = xbmc.getCondVisibility('System.IsFullscreen')
        if not fullscreen:
            xbmc.executebuiltin("Action(togglefullscreen)")
    utils.setDefaultVideoLevel()
    ###xbmc.executebuiltin("SetVolume(100,showvolumebar)")
    
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin('PlayMedia(' + playcmd + ')')
    #PLAY_STREAM(name,url,iconimage,cat)
    try:
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin('RunAddon(' + recordname + ')')  ### Return
    except Exception as e:
        log('err 9104 Except: %r' % e)
        pass
        log('Return to caling addon failed ERROR: %r' % e)

elif mode==260:   #clear recording markerflag
    log('err 260 mode= %r' % mode)
    marker = locking.markLockedList()  ### definition.ADDONgetSetting('Recordings')
    if marker != '[]':
        dialog = xbmcgui.Dialog()
        if dialog.yesno(ADDONname, "[COLOR red]Clear Recording Marker?[/COLOR]" +'\n'+ marker.replace('/','/ ').replace('\\','\\ ').replace('.','. ').replace('-','- ').replace('_','_ ') +'\n'+ "What Do You Want To Do","[COLOR red]Clear Recording Marker[/COLOR]","[COLOR green]Ignore[/COLOR]"):
            ### Ignore 
            test = 1
        else:
            ### Execute
            try:
                ###definition.ADDONresetSetting('Recordings','')  ### Return
                locking.markUnlockAll()
            except Exception as e:
                log('err 9121 Except: %r' % e)
                pass
                log('Clear Recording Marker failed ERROR: %r' % e)

elif mode==261:    ### Clean Up the Recordings folder      
        utils.log(module,'repository mode= %r' % mode)
        try:
            recordings.setAlarm('cleanup','cleanup.py','manuel','00:00:00','')
            utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] Clean Up Started ;-)' )
        except Exception as e:
            pass
            log('TEST error: ' + repr(e))
            utils.notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] Clean Up Failed: %r' % e)
           
elif mode==210000:  ### Disabled
    log('err 210000 mode= %r' % mode)
    #playcmd='plugin://plugin.video.wozboxntv/?url=url&mode=200&name=IPTV&iconimage=http://www.ntv.mx/res/content/tv/240.png&cat=%s'% cat
    # Show menuentry 
    menuname= 'Get IPTV from ' + ADDONrefer + ' - %s (%s)' % (name,cat)
    liz=xbmcgui.ListItem(menuname)
    xbmcplugin.addDirectoryItem(handle = Handle, url='',listitem = liz, isFolder = True) 
    #playcmd='plugin://' + ADDON.getAddonInfo('id') + '/?url=url&mode=200&name=%s&cat=%s'% (name,cat)
    
    #xbmc.executebuiltin('PlayMedia(' + playcmd + ')')
    
    playcmd='plugin://' + ADDONid + '/?url=url&mode=200&name=%s&cat=%s'% (name,cat)
    
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin('PlayMedia(' + playcmd + ')')
    #PLAY_STREAM(name,url,iconimage,cat)
    try:
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin('RunAddon(' + recordname + ')')  ### Return
    except Exception as e:
        log('err 9144 Except: %r' % e)
        pass
        log('Return to caling addon failed ERROR: %r' % e)

elif mode==2009:  # Record or play link from FTVguide or TV Guide
    log('err 2009 mode= %r' % mode)
    if definition.ADDONgetSetting('RecordFromTVguide')=='true':
        try:
            recordduration = utils.intADDONgetSetting('RecordFromTVguideDurationMinutes')
        except Exception as e:
            log('err 9153 Except: %r' % e)
            pass
            recordduration = 120
        if recordduration < 10: recordduration = 120
        now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        startDate =  (datetime.today().replace(microsecond=0) + timedelta(minutes=1)).strftime('%Y-%m-%d %H:%M:%S')
        endDate = (datetime.today().replace(microsecond=0) + timedelta(minutes=recordduration)).strftime('%Y-%m-%d %H:%M:%S')
        log('scheduleRecording(cat= %s, startDate= %s, endDate= %s, name= %s, url= %s)' % (cat, startDate, endDate, name, url))
        scheduleRecording(cat, startDate, endDate, name, url)
    else:
        try:
            PLAY_STREAM(name,url,iconimage,cat)
        except Exception as e:
            pass
            log('9471 PLAY_STREAM(name= %r,url= %r,iconimage= %r,cat= %r) ERROR: %r' % (name,url,iconimage,cat,e))
        
elif mode==2010:  # Record link from dr bonanza
    log('err 2010 mode= %r' % mode)
    ###log('Record(name= %s, uri= %s,playpath= %s, app= %s)' % (name, uri, playpath, app))
    if definition.ADDONgetSetting('RecordFromTVguide')=='true':
        Record(name, uri, playpath, app)
        
elif mode==2011:  # Record link from drnu/itv/bbc
    log('err 2011 mode= %r' % mode)
    if definition.ADDONgetSetting('RecordFromTVguide')=='true':
        RecordFlag = RecordFlagGet(sourceApp)
        log('err RecordFlagGet(sourceApp= %r)= %r' % (sourceApp,RecordFlag))
        RecordFlagSet(sourceApp,'waiting')
        log('err RecordFlagGet(sourceApp= %r)= %r' % (sourceApp,'waiting'))
        log('err Record link from drnu/itv/bbc uriorg= %r, OrgTitle= %r)' % (uriorg,OrgTitle))
        if uriorg == '' and OrgTitle != '':
            uriorg = utils.decode64(uri) + '&OrgTitle=' + OrgTitle.replace('aBcDeF','&')     ### 2024-05-31 
        else:
            uriorg = utils.decode64(uriorg)
        log('error Recordffmpeg(\n name= %r\n OrgTitle= %r\n uri= %r\n playpath= %r\n app= %r\n description= %r\n auth= %r\n sourceApp= %r)' % (name, OrgTitle, uriorg, playpath, app, description, auth, sourceApp), showlength = 5000)
        Recordffmpeg(name, uriorg, playpath, app, description, auth, sourceApp)

elif mode==2012:  # Record link from unlim.tv
    log('err mode= %r' % mode)
    ###module = '2012'
    log('XXXX Record link from unlim.tv STARTED')
    """
    URI='plugin://plugin.video.unlimtv/?url=url&mode=210&source='+ADDONid+'&cat='+cat[3:] + '&description=b64'+ base64.b64encode('recordfromunlimcat='+cat+'recordfromunlimtitle='+title+'recordfromunlimduration='+duration+'recordfromunlimnameAlarm='+nameAlarm+'recordfromunlimdescription='+description)
    
    import base64                                                        

a = base64.b64encode(bytes(u'complex string: ñáéíóúÑ', "utf-8"))

# a: b'Y29tcGxleCBzdHJpbmc6IMOxw6HDqcOtw7PDusOR'

b = base64.b64decode(a).decode("utf-8", "ignore")                    

print(b)
# b :complex string: ñáéíóúÑ
    """
    try:
        log('err name= %r' % name)
        log('err url= %r' % url)
        log('err uri= %r' % uri)
        log('err OrgTitle= %r' % OrgTitle)
        log('err sourceApp= %r' % sourceApp)
        log('err description= %r' % description)
        description = utils.decode64(description)
        log('err description= %r' % description)
        description3 = description.split('recordfromunlim')
        """default.py: err description3= [
        0'', 
        1'cat=UNL967', 
        2'title=Rockshow [Musik. Programmer. Voksne]. (E3) (2018) [Danmark] (TV2 Charlie UNL-DK)', 
        3'duration=63', 
        4"description=TV2 Charlie UNL-DK (UNL967): \nStart 2020-10-04 04:35 \nDuration [00:45]. \nEPG Created 2020-10-04 02:45:24\n\nFra sin hjemby, Hiller\xc3\xb8d, byder v\xc3\xa6rt Anders Blichfeldt velkommen til et musikprogram sp\xc3\xa6kket med fantastiske toner fra S\xc3\xb8s Fenger og Billy Cross. Gl\xc3\xa6d dig til en hitparade fra S\xc3\xb8s Fenger, der ryster b\xc3\xa5de 'Inderst Inde' og 'Den Jeg Elsker' ud af \xc3\xa6rmet. Samtidig har Billy Cross taget guitaren med, for at g\xc3\xb8re det han er bedst til - og m\xc3\xa5ske best\xc3\xa5r han ogs\xc3\xa5 Anders Blichfeldts store guitarquiz. \n\nEPG Created 2020-10-04 02:45:24", 
        5'startDate=2020-10-04:01-32']
        """
        log('err description3= %r' % description3)
        cat = description3[1].split('=',1)[1]
        log('err cat= %r' % cat)
        name = description3[2].split('=',1)[1]
        log('err name= %r' % name)
        duration = description3[3].split('=',1)[1]
        log('err duration= %r' % duration)
        description = description3[4].split('=',1)[1]
        log('err description= %r' % description)
        description += '\n\n' + description3[5].split('=',1)[1]
        log('err nameAlarm=1 %r' % description)
        nameAlarm = cat+'-' + datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        log('err nameAlarm=2 %r' % nameAlarm)
        log('err Recordffmpeguri(name= %r, uri= %r, duration= %r, description= %r, nameAlarm= %r)' % (name, uri, duration, description, nameAlarm))
        ###Recordffmpeguri(name, uri, duration, description, nameAlarm = cat+'-'+nameAlarm)   ### 2020-10-04
        Recordffmpeguri(name, uri, duration, description.replace(',',';;'), nameAlarm = nameAlarm)   ### 2021-01-29
    except Exception as e:
        log('err 9237 Except: %r' % e)
        pass
        EpgError = 'Error in getting Record link from unlim.tv\n' + repr(e)
        log(EpgError)

elif mode==2013:  # Record Archive link from unlim.tv
    log('err 2013 mode= %r' % mode)
    log('mode==2013 uri= %r' % uri)
    cat = definition.ADDONgetSetting('recordfromunlim')[3:]
    name = definition.ADDONgetSetting('recordfromunlimtitle')
    duration = definition.ADDONgetSetting('recordfromunlimduration') 
    startDate = definition.ADDONgetSetting('recordfromunlimstartdate') 
    description = definition.ADDONgetSetting('recordfromunlimdescription') 
    ### 2017-05-21:16-00
    time_tuple = time.strptime(startDate, "%Y-%m-%d:%H-%M")
    startDateTS = int(time.mktime(time_tuple))
    ### Get url: '/channels/get-record/' + chId + '/' + evtStart + '/' + evtDuration
    ### https://www.unlim.tv:443/channels/get-record/949/1557407400/6000
    url = 'https://www.unlim.tv:443/channels/get-record/'+cat+'/'+str(startDateTS)+'/'+duration
    log('err Channel uri= %r' % uri)
    log('err Archive url= %r' % url)
    ###file = urlopen(url)
    ###data = file.read()
    ChannelFile = os.path.join(datapath,ADDONid) + '.UNL'
    data = utils.readlink(url,ChannelFile,module)
    log('err url=%r\ndata= %r' % (url,data))
    """
    file.close()
    
    with open(ChannelFile,'wb') as output:
        output.write(data)
    """
    d = json.loads(data)
    log('json.loads(data)= %r' % d)
    arcurl = d['body']
    log('arcurl= %r' % arcurl)
    Recordffmpeguri(name, arcurl, duration, description.replace(',',';;'))

elif mode==2222: ### Play url
    log('err 2222 mode= %r\nurl= %r' % (mode,url))
    playurl(url)
    """
    playcmd='plugin://' + ADDONid + '/?url=url&mode=2222&name=%s&cat=%s'% (name,cat)
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin('PlayMedia(' + playcmd + ')')
    #PLAY_STREAM(name,url,iconimage,cat)
    try:
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin('RunAddon(' + recordname + ')')  ### Return
    except Exception as e:
        log('err 9144 Except: %r' % e)
        pass
        log('Return to caling addon failed ERROR: %r' % e)
    """
    
elif mode==2020: ### Watch Archive
    log('err 2020 mode= %r' % mode)
    
    setComandMode('Watch Archive',mode)
    ###http://roq-tv.net:25461/streaming/timeshift.php?username=XXX&password=XXXX&stream=276&duration=120&start=2017-05-21:16-00
    ###duration = endDate - startDate  ### in minutes
    ###duration = '120'
    ###start    = startDate.strftime('%Y-%m-%d:%H-%M')
    ###url = 'http://roq-tv.net:25461/streaming/timeshift.php?username='+IPTVuser+'&password='+definition.ADDONgetSetting('password')+'&stream='+cat+'&duration='+duration+'&start='+start
    ###log('2020 url= ' + url)
    ###log('2020 description= ' + description)
    ###playmedia(url)
    name = recordname.replace('[COLOR salmon]','').replace('[/COLOR]','')
    ###log('2020 (name= %r \nurl= %r \niconimage= %r \ncat= %r \ndescription= %r )' % (recordname,url,iconimage,cat,description))
    PLAY_CATCHUP(recordname,url,iconimage,cat,description)
    ###PLAY_STREAM(name,url,iconimage,cat)
    ###liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    ###liz.setInfo( type="Video", infoLabels={ "Title": name} )
    ###liz.setProperty("IsPlayable","true")
    ###liz.setPath(url)
    ###xbmcplugin.setResolvedUrl(Handle, True, liz) 
    
elif mode==2001:   ### Record
    log('err 2001 mode= %r' % mode)
    setComandMode('Record',mode)
    if recordname == '' and not 'http' in cat:
        recordname = recordings.titleFromCat(cat)
        log('err 0 recordname= %r' % recordname)
    Vtoken= '[MOVIES]'   ### 2019-02-09 Remove Vtoken from recordname if it is in the start
    if Vtoken in recordname:
        recordnamenew = recordname.split(Vtoken)
        if recordnamenew[0] == '':
            recordname = recordname.replace(Vtoken,'',1)
    log('err 1 recordname= %r' % recordname)    
    if not ('Recursive' in recordname):
        ###log('record0 (name = %s, uri= %s, playpath= %s, cat= %s, startDate= %s, endDate= %s, recordname= %s, description= %s)' % (name, uri, playpath,cat,startDate, endDate, recordname, description))
        cathandled = False
        KrogsbellAddOns = definition.getKrogsbellAddOns()   ###<<<<<<< Needs update 2018-06-28
        log('KrogsbellAddOns= %r' % KrogsbellAddOns)
        for kaddon in KrogsbellAddOns:
            log('kaddon= %r' % kaddon)
            try:
                kaddonID = kaddon.split('.')[2][:3].upper()
                taddonID = ADDONid.split('.')[2][:3].upper()
            except Exception as e:
                log('err 9317 Except: %r' % e)
                pass
                EpgError = 'Error in getting AddOn ID\n' + repr(e) 
                kaddonID = ''
                taddonID = ''
            log('kaddonID= %r' % kaddonID)
            log('taddonID= %r' % taddonID)
            if kaddonID != '' and kaddonID != taddonID:
                try:
                    nADDON = xbmcaddon.Addon(id=kaddon)
                    naddon = nADDON.getAddonInfo('name')
                    NTVchannels = xbmcvfs.translatePath(nADDON.getAddonInfo('profile') + 'channels.csv')
                    NTVcat = cat.replace(kaddonID,'')   ###<<<<<<< Needs update 018-06-21
                    if kaddonID == cat[:3]:
                        ### 2012 at Wozboxntv ==> recordings.add(cat, startDate, endDate, recordname, description)
                        cathandled = True
                        cat = NTVcat
                        name = urllibquote_plus('Recording set by ' + ADDONrefer)
                        startDate = urllibquote_plus(startDate)
                        endDate = urllibquote_plus(endDate)
                        recordname = urllibquote_plus(recordname)
                        ### description = description.replace(' ','AAabBB').replace('?','aAabBb').replace('=','BBabAA').replace(',','###').replace('&','AaAaA').replace('\n','NlNlNl')
                        cmd = 'plugin://' + kaddon + '/?mode=210&cat='+cat+'&url=url&name=' + name + '&recordname='+ recordname +'&startDate='+ startDate +'&endDate='+ endDate +'&description='+ description
                        log('Record at %s cmd= %r' % (naddon,cmd))
                        xbmc.executebuiltin('Dialog.Close(busydialog)')
                        xbmc.executebuiltin("RunPlugin(" + cmd + ")")
                except Exception as e:
                    log('err 9343 Except: %r' % e)
                    pass
                    log('NTVchannels '+kaddon+' Error= %r' % e)
        if not cathandled :
            try:
                if recordname == '':
                    if not name == '':
                        recordname = name  ###
                    else:
                        recordname = 'recordname and name are empty' 
                ###log('record00 (name = %s, uri= %s, playpath= %s, cat= %s, startDate= %s, endDate= %s, recordname= %s, description= %s)' % (name, uri, playpath,cat,startDate, endDate, recordname, description))
                if '[COLOR lightgreen]' in recordname:
                    if '[/COLOR]' in recordname:
                        recordname = recordname.split('[/COLOR]',1)[1]
                if '[COLOR salmon]' in recordname:
                    recordname = recordname.split('[COLOR salmon]',1)[1]
                if '[COLOR yellow]' in recordname:
                    recordname = recordname.split('[COLOR yellow]',1)[1]
                if '[COLOR cyan]' in recordname:
                    recordname = recordname.split('[COLOR cyan]',1)[1]
            except Exception as e:
                log('err 9363 Except: %r' % e)
                pass
            try:
                if cat == '':
                    cat = recordings.catFromUrl(url)  ###
                uri=url 
            except Exception as e:
                log('err 8371 Except: %r' % e)
                pass
                uri = recordings.urlFromCat(cat)  ### 
            ext = uri.split('.')[-1].lower()
            reclock = locking.isAnyRecordLocked()
            if ('/movie/' in uri or ext == 'mp4' or ext == 'mkv' or ext == 'avi' or ext == 'm4v'):
                log('err /movie/ in uri or ext == mp4, mkv, avi or m4v')
                Recordffmpeg(recordname, uri, playpath, app, description, auth, sourceApp)
            else:
                utils.notificationforced('Schedule recording: cat= ' + cat+ ' \nTitle: '+recordname) 
                scheduleRecording(cat, startDate, endDate, recordname, description) 

log('err locking.isScanLocked(EPG_update)= %r' % locking.isScanLocked('EPG_update'))
log('err definition.ADDONgetSetting(blockduringepgimport) == true? %r' % definition.ADDONgetSetting('blockduringepgimport'))
if not (locking.isScanLocked('EPG_update') and definition.ADDONgetSetting('blockduringepgimport') == 'true'):  ### 2018-07-07
    log('err mode NOT locked. mode= %r, url= %r' % (mode,url))
    if mode==None or url==None or mode==0:
        ###try:
            log('err None,0 or url=None mode= %r' % mode)
            definition.ADDONresetSetting('LastView', 'CATEGORIES')
            CATEGORIES()
        ###except Exception as e:
        ### pass
            ###log('Error in showing Categories: ' + repr(e))
        ### utils.notification('[COLOR red]Error in showing Categories[/COLOR] - [COLOR green]Check your internet connection![/COLOR]')

    elif mode==200:    ### 2025-04-18 TEST to not get oops after failed 200 playURL
        log('err mode= %r' % mode)
        log('errY 200 mode= %r cat= %r' % (mode,cat))

    elif mode==2:
        ### if 1!=1:   ### 2019-09-02 IGNORE test
            log('err mode= %r' % mode)
            definition.ADDONresetSetting('LastView', 'CHANNELS')
            CHANNELS(name,cat)

    elif mode==3:
        log('err mode= %r' % mode)
        definition.ADDONresetSetting('LastView', 'RECORDINGSPLANNED')
        RecordingsPlanned()

    elif mode==4:
        log('err mode= %r' % mode)
        definition.ADDONresetSetting('LastView', 'TVGUIDE')
        TVGUIDE(name,cat)

    elif mode==5:
        log('err mode= %r' % mode)
        definition.ADDONresetSetting('LastView', 'GENRE')
        GENRE(name,cat)

    elif mode==7:
        log('err mode= %r' % mode)
        setComandMode('Add/Modify Favorite',mode)
        ###log('ADD_FAV cat= %r, \nurl= %r, \nuri= %r' % (cat, url, uri))
        ###if cat == '':    ###removed 2018-12-01
        ###    cat=recordings.catFromUrl(url)
        ADD_FAV(cat)
        ###xbmc.executebuiltin("Container.Refresh")
    
    elif mode==77:
        log('err mode= %r' % mode)
        setComandMode('Remove Favorite',mode)
        if cat == '':
            cat=recordings.catFromUrl(url)
        DEL_FAV(cat)
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin("Container.Refresh")
    
    elif mode==16:
        log('err mode= %r' % mode)
        definition.ADDONresetSetting('LastView', 'ntvCATEGORIES')
        ntvCATEGORIES()

    elif mode==17:
        log('err mode= %r' % mode)
        definition.ADDONresetSetting('LastView', 'FAVORITES')
        FAVORITES()
    
    elif mode==18:
        log('err mode= %r' % mode)
        definition.ADDONresetSetting('LastView', 'ARCHIVE')
        ARCHIVE()

    elif mode==19:
        log('err mode= %r' % mode)
        definition.ADDONresetSetting('LastView', 'MYSELECTEDCHANNELS')
        MYSELECTEDCHANNELS()

    elif mode==190:
        log('err mode= %r' % mode)
        definition.ADDONresetSetting('LastView', 'NTVCHANNELS')
        try:
            addonID = description.split('(')[1].split(')')[0].upper()
        except Exception as e:
            log('err 9458 Except: %r' % e)
            pass
            addonID = repr(e)
        definition.ADDONresetSetting('LastaddonID', addonID)
        NTVCHANNELS(addonID)
        
    elif mode==191:
        log('err mode= %r' % mode)
        definition.ADDONresetSetting('LastView', 'TVawayCHANNELS')
        TVawayCHANNELS()
        
    elif mode==192:
        log('err mode= %r' % mode)
        definition.ADDONresetSetting('LastView', 'TV Series')
        TVSeries()
        
    elif mode==20:
        log('err mode= %r' % mode)
        definition.ADDONresetSetting('LastView', 'HIDDENCHANNELS')
        HIDDENCHANNELS()

    elif mode==21:
        log('err mode= %r' % mode)
        definition.ADDONresetSetting('LastView', 'NEWCHANNELS')
        NEWCHANNELS()
    
    elif mode==211:
        log('err mode= %r' % mode)
        definition.ADDONresetSetting('LastView', 'NEWSERIES')
        NEWSERIES()

    elif mode==22:
        ###try:
            ###log('Mode=22: name= %s,recordname= %s,cat= %s,url= %s,description= %s'% (name,recordname,cat,url,description))
            log('err mode= %r' % mode)
            definition.ADDONresetSetting('LastView', 'CHANNELSROQOLD')
            CHANNELSROQOLD(name,cat,url,description)
        ###except Exception as e:
        ### pass
        ### ###log('Error in showing Channels: ' + repr(e))
        ### utils.notification('[COLOR red]Error in showing Channels[/COLOR] - [COLOR green]Check your internet connection![/COLOR]')

    elif mode==23:
        ###try:
            ###log('Mode=2: name= %s,recordname= %s,cat= %s,url= %s,description= %s'% (name,recordname,cat,url,description))
            log('err mode= %r' % mode)
            definition.ADDONresetSetting('LastView', 'CHANNELSROQ')
            CHANNELSROQ()
        ###except Exception as e:
        ### pass
        ### log('Error in showing Channels: ' + repr(e))
        ### utils.notification('[COLOR red]Error in showing Channels[/COLOR] - [COLOR green]Check your internet connection![/COLOR]')
            
    elif mode==24:  ### Set Hidden
        log('err mode= %r' % mode)
        setComandMode('Set Hidden',mode)
        if cat == '':
            cat=recordings.catFromUrl(url)
        ###log('elif mode==24:  ### Set Hidden cat= %r, url= %r' % (cat,url))
        SET_HIDE(cat)
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin("Container.Refresh")

    elif mode==25:  ### Remove Hidden
        log('err mode= %r' % mode)
        setComandMode('Remove Hidden',mode)
        ###log('elif mode==25:  ### Remove Hidden cat= %r, url= %r' % (cat,url))
        if cat == '':
            cat=recordings.catFromUrl(url)
        DEL_HIDE(cat)
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin("Container.Refresh")

    elif mode==26:  ### Recursive Search View
        log('err mode= %r' % mode)
        definition.ADDONresetSetting('LastView', 'RECURSIVECHANNELS')
        RECURSIVECHANNELS()

    elif mode==27:  ### Set Recursive
        log('err mode= %r' % mode)
        setComandMode('Set Recursive',mode)
        if cat == '':
            cat=recordings.catFromUrl(url)
        SET_RECURSIVE(cat)
        ###xbmc.executebuiltin("Container.Refresh")

    elif mode==28:  ### Remove Recursive
        log('err mode= %r' % mode)
        setComandMode('Remove Recursive',mode)
        if cat == '':
            cat=recordings.catFromUrl(url)
        DEL_RECURSIVE(cat)
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin("Container.Refresh")
        
    elif mode==29:  ### EXIT - Back to Kodi
        log('err mode= %r' % mode)
        stoptimeshift()
        exit()
    
    elif mode==30:  ### Stop Timeshift
        log('err mode= %r' % mode)
        stoptimeshift()
    
    elif mode==103:
        log('err mode= %r' % mode)
        deleteDir(url)
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin("Container.Refresh")
        
    elif mode==104:
        #recordPath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        #definition.ADDONresetSetting('record_display_path',recordPath)
        log('err mode= %r' % mode)
        DataBases()
        #xbmc.executebuiltin("Container.Refresh")
        
    elif mode==105:
        #recordPath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        log('err mode= %r' % mode)
        recordings.restoreBackupDataBase(url)

    elif mode==106:
        #recordPath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        log('err mode= %r' % mode)
        recordings.restoreSetupXml(url)
    
    elif mode==107:
        #recordPath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        log('err mode= %r' % mode)
        recordings.restoreRecursiveRecordings(url)
    
    elif mode==108:
        log('err mode= %r' % mode)
        recordings.delAllChannels()
        
    elif mode==109:
        log('err mode= %r' % mode)
        dialog = xbmcgui.Dialog()
        if dialog.yesno(ADDONname, "[COLOR red]Delete all planned recordings except Recursive?[/COLOR]" +'\n'+ "What Do You Want To Do","[COLOR red]Delete recordings[/COLOR]","[COLOR green]Ignore[/COLOR]"):
            lockcause = 'ignore' ### Dummy command
        else:
            lockcause = 'change' ### Dummy command
            recordings.delAllPlannedPrograms()
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            xbmc.executebuiltin("Container.Refresh")
        
    elif mode==1090:
        log('err mode= %r' % mode)
        recordings.delAllPlannedProgramsInclusiveRecursive()
    
    elif mode==110:
        log('err mode= %r' % mode)
        ###recordings.delNewEPGPrograms()
        recordings.delAllEPGPrograms()
    
    elif mode==111:
        log('err mode= %r' % mode)
        recordings.delOldEPGPrograms()
    
    elif mode==112:
        log('err mode= %r' % mode)
        recordings.ftvntvlist()

    elif mode==113:  ### Restore Channels
        log('err mode= %r' % mode)
        recordings.RestoreChannels(url)

    elif mode==114:  ### Restore EPG
        log('err mode= %r' % mode)
        recordings.RestoreEPG(url)  

    elif mode==115:  ### Update EPG
        log('err mode= %r' % mode)
        recordings.EPGOnce() 
        utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] Update EPG has started')

    elif mode==116:  ### Clear the Database. Stop all planned recordings, reset database and start a new EPG import
        log('err mode= %r' % mode)
        dialog = xbmcgui.Dialog()
        if dialog.yesno(ADDONname, "[COLOR red]Delete database and start all over?[/COLOR]" +'\n'+ "What Do You Want To Do","[COLOR red]Delete[/COLOR]","[COLOR green]Ignore[/COLOR]"):
            ### Ignore
            lockcause = 'ignore' ### Dummy command
        else:
            ### Stop recording and record new
            lockcause = 'change' ### Dummy command
            ### Backup Database and files
            recordings.backupSetupxml()
            recordings.backupDataBase()
            recordings.deleteDataBase()
            sleep(1000)
            recordings.EPGOnce()
    
    elif mode==117:  ### Restore Favorites
        log('err mode= %r' % mode)
        recordings.RestoreFavorites(url)  
    
    elif mode==118:  ### Restore Favorites
        log('err mode= %r' % mode)
        recordings.RestoreRecursiveChannels(url)  
    
    elif mode==1004:   ### Select TV Guide Channel
        ###log('Mode=200: name= %s,recordname= %s,cat= %s,url= %s,description= %s'% (name,recordname,cat,url,description))
        log('err mode= %r' % mode)
        SELECT_TV_GUIDE_CHANNEL(name,url,iconimage,cat)
    
    elif mode==2002:   ### delete record 2002
        log('err mode= %r' % mode)
        setComandMode('Delete Recording',mode)
        ###utils.logdev('delete record 2002', '(cat= %r, startDate= %r, endDate= %r, name= %r, recordname= %r, description= %r)' % (cat, startDate, endDate, name, recordname, description))
        delRecording(cat, startDate, endDate, recordname)
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin("Container.Refresh")

    elif mode==2003:         ### modifyRecording 2003
        log('err mode= %r' % mode)
        setComandMode('Modify Recording',mode)
        log('err modifyRecording 2003 (cat= %r, startDate= %r, endDate= %r, name= %r, recordname= %r, description= %r)' % (cat, startDate, endDate, name, recordname, description))
        modifyRecording(cat, startDate, endDate, recordname, description)
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin("Container.Refresh")
        
    elif mode==2004:  ### Create ini and other startupfiles in debug mode with refresh
        log('err mode= %r' % mode)
        if definition.ADDONgetSetting('DebugRecording')=='true': 
            recordings.ftvntvlist()
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin("Container.Refresh")

    elif mode==2005:   ### Set Recursive
        log('err mode= %r' % mode)
        setComandMode('Set Recursive',mode)
        recursiveRecordname = 'Recursive:' + recordname.split('[')[0].split(';')[0].split(':')[0].split('- ')[0].split(' -')[0].split('- ')[0].split('\xe2\x80\x93')[0].strip()
        log('recursiveRecordname= %r' % recursiveRecordname)
        if not ('Recursive' in recordname) and (recursiveRecordname != 'Recursive:'):
            if cat[0:4].lower() != 'http':
                scheduleRecording(cat, startDate, endDate, recursiveRecordname,description)
                if not recordings.isChannelRecursive(cat):
                    SET_RECURSIVE(cat)  ### 2019-01-06
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin("Container.Refresh")

    elif mode==2006:   ### DISABLE RECORD
        log('err mode= %r' % mode)
        setComandMode('Disable Record',mode)
        u = '#cat=' + cat + '#startDate=' + startDate +'#endDate=' + endDate + '#name=' + name + '#recordname=' + recordname + '#description=' + description + '#'
        if isHighlighted(u):
            for ux in higlights:
                catx        = param(u,'cat')
                startDatex  = param(u,'startDate')
                endDatex    = param(u,'endDate')
                namex       = param(u,'recordname')
                recordnamex = param(u,'name')
                descriptionx = param(u,'description')
                if not ('[COLOR orange]' in recordname):
                    delRecording(catx, startDatex, endDatex, recordnamex)
                    ###log('2006 scheduleRecording(cat= %r, startDate= %r, endDate= %r, * + recordname= %r, description= %r)' % (cat, startDate, endDate, '*' + recordname, description))
                    scheduleRecording(catx, startDatex, endDatex, '*' + recordnamex, descriptionx)
        else:
            if not ('[COLOR orange]' in recordname):
                delRecording(cat, startDate, endDate, recordname)
                ###log('2006 scheduleRecording(cat= %r, startDate= %r, endDate= %r, * + recordname= %r, description= %r)' % (cat, startDate, endDate, '*' + recordname, description))
                scheduleRecording(cat, startDate, endDate, '*' + recordname, description)
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin("Container.Refresh")
        
    elif mode==2007:
        log('err mode= %r' % mode)
        setComandMode('Find Recursive',mode)
        if ('Recursive' in recordname):
            locking.scanUnlockAll()
            findrecursive.RecursiveRecordingsPlanned('NotAllFavorites')
        ###xbmc.executebuiltin("Container.Refresh")
     
    elif mode==2008:  ### Search Channel, VOD or TV Series
        log('err mode= %r' % mode)
        utils.logdev('Search Channel, VOD or TV Series','Start')
        
        setComandMode('Search Channel, VOD or TV Series',mode)
        definition.ADDONresetSetting('LastView', 'CHANNELSSEARCH')
        CHANNELSSEARCH()
        
    elif mode==2059:  ### Backup Database and files
        log('err mode= %r' % mode)
        recordings.backupSetupxml()
        recordings.backupDataBase()
        utils.notificationsend('[COLOR lightgreen][B]' + ADDONrefer + '[/B][/COLOR] Backup Ended')
        
    elif mode==2050:  ### Search favorite programs
        log('err mode= %r' % mode)
        log('Search favorite programs: Start')
        definition.ADDONresetSetting('LastView', 'PROGRAMSEARCH')
        PROGRAMSEARCH()
      
    elif mode==2500:  ### Make a Clone of this Addon with default name
        definition.log('Make a Clone of this Addon with default name mode= %r' % mode)
        ### Get new ID
        ###newADDONid = GetText('ID of new AddOn',ADDONid)
        ###newADDONname = GetText('Name of new AddOn',ADDONname)
        today = datetime.today().strftime('%Y-%m-%d--%H-%M')
        todays = datetime.today().strftime('%Y-%m-%d %H:%M')
        definition.log('today= %r' % today)
        newADDONid = GetText('ID of new AddOn','plugin.video.krogsbelliptv-' + today)
        ###newADDONid = GetText('ID of new AddOn','plugin.video.iptv-' + today)
        ###newADDONname = GetText('Name of new AddOn','Krogsbell IPTV ' + today)
        newADDONname = 'Krogsbell IPTV ' + today
        ### Set Clone of and Cloned at 
        try:
            definition.ADDONsetSetting('cloneof',newADDONname)
            definition.ADDONsetSetting('clonedat','%s'%todays)
        
            psettingsxml = os.path.join(progpath, 'resources','settings.xml')
            file = open(psettingsxml,'r')
            desc = file.read()
            file.close()
  
            marker = '<setting id="cloneof" type="text" label="[COLOR orange][B]Cloned from[/B][/COLOR]" default="'
            markerend = '" visible="true" enable="false"/>'
            cloneofa = desc.split(marker)
            cloneofb = markerend + cloneofa[1].split(markerend,1)[1]
            desc = cloneofa[0] + marker + newADDONname + cloneofb
            
            ###<setting id="clonedat" type="text" label="[COLOR orange][B]Cloned at[/B][/COLOR]" default="" visible="true" enable="false"/>
            marker = '<setting id="clonedat" type="text" label="[COLOR orange][B]Cloned at[/B][/COLOR]" default="'
            markerend = '" visible="true" enable="false"/>'
            cloneofa = desc.split(marker)
            cloneofb = markerend + cloneofa[1].split(markerend,1)[1]
            desc = cloneofa[0] + marker + todays + cloneofb
            
            with open(psettingsxml,'w', encoding = 'utf-8') as output:
                output.write(desc)

        except Exception as e:
            pass
            definition.log('Clone data not updated in settings.xml\nError: %r' % e)
            
        
        ###newADDONname = 'IPTV ' + today
        addonxml = os.path.join(progpath, 'addon.xml')
        ###file = open(addonxml,'r', encoding = 'utf-8')
        file = open(addonxml,'r')
        desc = file.read()
        file.close()
        try:
            versiondate = desc.split('version="')[2].split('"')[0]
            versionactual = datetime.today().strftime('%Y.%m.%d~%H-%M')
            definition.log('Version number updated: versiondate= %r, versionactual= %r' % (versiondate, versionactual))
            desc = desc.replace(versiondate,versionactual)
        except Exception as e:
            pass
            definition.log('Version number not updated in addon.xml\nError: %r' % e)
        ###utils.makeOldFile(addonxml)
        with open(addonxml,'w', encoding = 'utf-8') as output:
            output.write(desc)
        if newADDONid and newADDONid != ADDONid and newADDONname and newADDONname != ADDONname:
            try:
                definition.log('ID of new AddOn= %r' % newADDONid)
                ### Copy all files to new folder
                progpathnew= progpath.replace(ADDONid,newADDONid)
                definition.log('progpathnew= %r' % progpathnew)
                if not os.path.isdir(progpathnew):
                    ### os.makedirs(progpathnew)   ### shutil creates foldersf
                    addonxml = os.path.join(progpathnew, 'addon.xml')
                    utils.makeOldFile(addonxml)
                    shutil.copytree(progpath,progpathnew)
                    ### Update addon.xml and definitions.py
                    file = open(addonxml,'r', encoding = 'utf-8')
                    desc = file.read()
                    file.close()
                    desc = desc.replace(ADDONid,newADDONid).replace(ADDONname,newADDONname)
                    with open(addonxml,'w',encoding='utf-8') as output:
                        output.write(desc)
                    definitionpy = os.path.join(progpathnew, 'definition.py')
                    file = open(definitionpy,'r', encoding = 'utf-8')
                    desc = file.read()
                    file.close()
                    desc = desc.replace(ADDONid,newADDONid).replace(ADDONname,newADDONname)
                    with open(definitionpy,'w',encoding='utf-8') as output:
                        output.write(desc)
                    settingsxml = os.path.join(progpathnew, 'resources','settings.xml')
                    file = open(settingsxml,'r', encoding = 'utf-8')
                    desc = file.read()
                    file.close()
                    desc = desc.replace(ADDONid,newADDONid).replace(ADDONname,newADDONname)
                    
                    with open(settingsxml,'w',encoding='utf-8') as output:
                        output.write(desc)
                    
                    ### Zipfolder to make installable file
                    shutil.copy(os.path.join(progpath,'IPTV.png'),os.path.join(progpathnew,'icon.png'))  ### Set default app icons
                    shutil.copy(os.path.join(progpath,'IPTV.jpg'),os.path.join(progpathnew,'icon.jpg'))
                    shutil.copy(os.path.join(progpath,'IPTV.jpg'),os.path.join(progpathnew,'fanart.jpg'))
                    
                    ### Remove all unwanted files in progpathnew: *~, __pycache__/*, *.pyo, skins/*
                    deleteMask(os.path.join(progpathnew,'*~'))
                    deleteMask(os.path.join(progpathnew,'*.pyo'))
                    deleteFolder(os.path.join(progpathnew,'__pycache__'))
                    deleteDir(os.path.join(progpathnew,'__pycache__'))
                    deleteFolder(os.path.join(progpathnew,'resources//skins'))
                    deleteDir(os.path.join(progpathnew,'resources//skins'))
                    keeptextfiles = ['changelog','directchannels.m3u','ffmpeghelpfull','LICENSE','readme','none']
                    textfiles = glob.glob(os.path.join(progpathnew,'*.txt'))
                    for txfile in  textfiles:
                        base=os.path.basename(txfile)
                        basefile = os.path.splitext(base)[0]
                        log('10379 error basefile= %r' % basefile)
                        if not basefile in keeptextfiles:
                            log('10381 error os.remove(txfile= %r)' % txfile)
                            os.remove(txfile)
                    addonfolder = progpathnew.replace(newADDONid,'')
                    definition.log('addonfolder= %r' % addonfolder)
                    archive_name = os.path.expanduser(os.path.join('~', (progpathnew+'.zip').replace(os.sep+'.zip','')))
                    ###cmd = 'zip -r -b '+archive_name+ ' '+ os.path.expanduser(os.path.join('~', progpathnew))
                    ###utils.runCommand(cmd, LoopCount=0, libpath=None, nameAlarm='zipnameAlarm')
                    
                    ###Zip 3.0 (July 5th 2008). Usage:
                    ###zip [-options] [-b path] [-t mmddyyyy] [-n suffixes] [zipfile list] [-xi list]
 
                    result = shutil.make_archive(archive_name,'zip', root_dir=addonfolder,base_dir=newADDONid)
                    definition.log('shutil.make_archive(archive_name= %r, result= %r' %(archive_name,result))
                    ###result = shutil.make_archive(progpathnew+'1', 'zip', addonfolder, newADDONid)
                    ###definition.log('shutil.make_archive(archive_name= %r, result= %r' %(archive_name,result))
                    ### Delete folder
                    shutil.rmtree(progpathnew) 
                    utils.notificationsend('[COLOR lightgreen][B]' + newADDONname + '[/B][/COLOR] Created zip to install clone of ' + ADDONname)
            except Exception as e:
                log('err 10500 Except: %r' % e)
                pass
                utils.notificationsend('[COLOR red][B]' + newADDONname + ' Failed[/B][/COLOR] Creating zip to install clone of ' + ADDONname + '\n%r'% e)
                
    elif mode==2502:  ### Make a Copy of this Addon with data
        log('err mode= %r' % mode)
        log('err Make a Copy of this Addon: Start')
        ### Get new ID
        ###newADDONid = GetText('ID of new AddOn',ADDONid)
        ###newADDONname = GetText('Name of new AddOn',ADDONname)
        today = datetime.today().strftime('%Y-%m-%d')
        newADDONid = GetText('ID of new AddOn','plugin.video.' + ADDONname.replace(' ','').lower())
        newADDONname = GetText('Name of new AddOn',ADDONname)
        log('err newADDONid= %r' % newADDONid)
        log('err newADDONid != ADDONid= %r' % (newADDONid != ADDONid))
        log('err newADDONname= %r' % newADDONname)
        
        if newADDONid and newADDONid != ADDONid and newADDONname:
            log('err ID of new AddOn= %r' % newADDONid)
            ### Copy all files to new folder
            progpathnew= progpath.replace(ADDONid,newADDONid)
            datapath   = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
            datapathnew= datapath.replace(ADDONid,newADDONid)
            log('err progpathnew= %r' % progpathnew)
            if not os.path.isdir(progpathnew) and not os.path.isdir(datapathnew):
                ### os.makedirs(progpathnew)   ### shutil creates foldersf
                shutil.copytree(progpath,progpathnew)
                ### In datafolder copy settings.xml, recordings_adc.db
                #shutil.copytree(datapath,datapathnew)
                os.makedirs(datapathnew) 
                src = ['settings.xml','recordings_adc.db']
                for file in src:
                    source = os.path.join(datapath, file)
                    copy2(source, datapathnew)
                    log('err copy2 source= %r ==> %r' % (source,datapathnew))
                ### Update addon.xml and definitions.py
                addonxml = os.path.join(progpathnew, 'addon.xml')
                file = open(addonxml,'r',encoding='utf-8')
                desc = file.read()
                file.close()
                desc = desc.replace(ADDONid,newADDONid).replace(ADDONname,newADDONname)
                ###utils.makeOldFile(addonxml)
                with open(addonxml,'w',encoding='utf-8') as output:
                    output.write(desc)
                log('err output.write(desc= %r)' % desc)
                
                settingsxml = os.path.join(progpathnew, 'resources','settings.xml')
                file = open(settingsxml,'r', encoding = 'utf-8')
                desc = file.read()
                file.close()
                desc = desc.replace(ADDONid,newADDONid).replace(ADDONname,newADDONname)
                
                with open(settingsxml,'w',encoding='utf-8') as output:
                    output.write(desc)
                
                definitionpy = os.path.join(progpathnew, 'definition.py')
                file = open(definitionpy,'r', encoding = 'utf-8')
                desc = file.read()
                file.close()
                desc = desc.replace(ADDONid,newADDONid).replace(ADDONname,newADDONname)
                ###utils.makeOldFile(definitionpy)
                with open(definitionpy,'w',encoding='utf-8') as output:
                    output.write(desc)
                settingsxml = os.path.join(datapathnew, 'settings.xml')
                file = open(settingsxml,'r', encoding = 'utf-8')
                desc = file.read()
                file.close()
                desc = desc.replace(datapath,datapathnew).replace(ADDONid,newADDONid).replace(ADDONname,newADDONname)
                with open(settingsxml,'w',encoding='utf-8') as output:
                    output.write(desc)
                ### Update database with new addon ID
                dbpathnew = os.path.join(datapathnew, 'recordings_adc.db')
                ###origin = ADDONid +' available_channels'
                originnew = origin.replace(ADDONid,newADDONid)
                try:
                    recordings.updateOrigin(dbpathnew,originnew)
                except Exception as e:
                    log('err 9850 Except: %r' % e)
                    pass
                    log( 'Update with new origin database failed! \nERROR= %r' % (e))
                ### Zipfolder to make installable file
                ###shutil.make_archive('/home/code/test_dicoms','zip','/home/code/',        'test_dicoms')
                ### Dont set default app icons
                ###shutil.copy(os.path.join(progpath,'IPTV.jpg'),os.path.join(progpathnew,'icon.jpg'))
                ###shutil.copy(os.path.join(progpath,'IPTV.jpg'),os.path.join(progpathnew,'fanart.jpg'))
                addonfolder = progpathnew.replace(newADDONid,'')
                shutil.make_archive(progpathnew, 'zip', addonfolder, newADDONid)
                ### Dont Delete folder
                ###shutil.rmtree(progpathnew)
                utils.notificationsend('[COLOR lightgreen][B]' + newADDONname + '[/B][/COLOR] Created zip to install copy of ' + ADDONname)
            else:
                utils.notificationsend('[COLOR red][B]' + newADDONname + '[/B][/COLOR] Did Not Create zip to install copy of ' + ADDONname)
        else:
            utils.notificationsend('[COLOR red][B]' + newADDONname + '[/B][/COLOR] Did Not Create zip to install copy of ' + ADDONname)
                
    elif mode==2501:  ### Update an addon with the design from this Addon
        log('mode= %r' % mode)
        log('Update an addon with the design from this Addon: Start')
        choisesall = krogsbellAddons()
        choises = []
        for choise in choisesall:
            try:
                log('0 choise= %r' % choise)
                newADDONid = choise.replace('[B][COLOR lightgreen]','').replace('[/COLOR][/B]','').replace(': ',':').split(':')[1]
                log('newADDONid= %r' % newADDONid)
                progpathnew= os.path.join(progpath.replace(ADDONid,newADDONid),'definition.py')
                log('progpathnew= %r' % progpathnew)
                if os.path.exists(progpathnew):
                    ### ...\addon_data\...\storage\channels.json
                    datapathnew= os.path.join(datapath.replace(ADDONid,newADDONid),'storage','channels.json')
                    log('datapathnew= %r' % datapathnew)
                    if not os.path.exists(datapathnew):
                        log('choises.append(choise)= %r' % choise)
                        choises.append(choise)
            except Exception as e:
                log('err 9887 Except: %r' % e)
                pass
                choises.append('Error: %r' % e)
        selected = -1
        if len(choises) > 0:
            dialog = xbmcgui.Dialog()
            selected = dialog.select(ADDONname + ' - Select an Addon to update:', choises) ####################
        if selected != -1:
            log('selected Addon = %r ' % choises[selected])
            xmlfile = os.path.join(progpath,'addon.xml')
            newversion = getVersion(xmlfile)
            ### version="2019.08.10"
            newADDON = choises[selected].replace('[B][COLOR lightgreen]','').replace('[/COLOR][/B]','').replace(': ',':').split(':')
            newADDONid = newADDON[1]
            ###newADDONname = newADDON[0]  ### Dont expect the right name in list
            targetADDON = xbmcaddon.Addon(id=newADDONid)
            newADDONname = targetADDON.getAddonInfo('name')
            log('err newADDONname= %r' % newADDONname)
            if newADDONid and newADDONid != ADDONid and newADDONname and newADDONname != ADDONname:
                log('ID of updated AddOn= %r' % newADDONid)
                ### Copy all files to new folder
                log('progpath= %r' % progpath)
                progpathnew= progpath.replace(ADDONid,newADDONid)
                log('progpathnew= %r' % progpathnew)
                datapath   = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
                log('datapath= %r' % datapath)
                datapathnew= datapath.replace(ADDONid,newADDONid)
                log('datapathnew= %r' % datapathnew)
                if not locking.isAnyThingLocked(datapathnew):  ### Is destination scanning or recording?
                    saveIcons(progpathnew,datapath)
                    log('progpathnew= %r' % progpathnew)
                    if os.path.isdir(progpathnew):
                        ### Make backup of old version
                        now= datetime.today().strftime('-old-%Y-%m-%dh%Hm%Ms%S')
                        addonfolder = progpathnew.replace(newADDONid,'')
                        if addonfolder[-1] == '/' or addonfolder[-1] == '\\':
                            addonfolder = addonfolder[:-1]
                        if progpathnew[-1] == '/' or progpathnew[-1] == '\\':
                            progpathnew = progpathnew[:-1]
                        log('shutil.make_archive(\nprogpathnew+now= %r, \nzip, \naddonfolder= %r, \nnewADDONid= %r)' % (progpathnew+now, addonfolder, newADDONid))
                        shutil.make_archive(progpathnew+now, 'zip', addonfolder, newADDONid)
                        log('shutil.rmtree(progpathnew= %r)' % progpathnew)
                        shutil.rmtree(progpathnew)
                        log('shutil.copytree(progpath= %r,progpathnew= %r)' % (progpath,progpathnew))
                        shutil.copytree(progpath,progpathnew)
                        ### Update addon.xml and definitions.py
                        addonxml = os.path.join(progpathnew, 'addon.xml')
                        oldversion = getVersion(addonxml)
                        setVersion(addonxml,newversion,oldversion)
                        file = open(addonxml,'r',encoding='utf-8')
                        desc = file.read()
                        file.close()
                        desc = desc.replace(ADDONid,newADDONid).replace(ADDONname,newADDONname)
                        ###utils.makeOldFile(addonxml)
                        with open(addonxml,'w',encoding='utf-8') as output:
                            output.write(desc)
                        definitionpy = os.path.join(progpathnew, 'definition.py')
                        file = open(definitionpy,'r',encoding='utf-8')
                        desc = file.read()
                        file.close()
                        desc = desc.replace(ADDONid,newADDONid).replace(ADDONname,newADDONname)
                        ###utils.makeOldFile(definitionpy)
                        with open(definitionpy,'w',encoding='utf-8') as output:
                            output.write(desc)
                        settingsxml = os.path.join(progpathnew, 'resources','settings.xml')
                        file = open(settingsxml,'r',encoding='utf-8')
                        desc = file.read()
                        file.close()
                        desc = desc.replace(ADDONid,newADDONid).replace(ADDONname,newADDONname)
                        
                        todays = datetime.today().strftime('%Y-%m-%d %H:%M')
                        newADDONp = xbmcaddon.Addon(id=newADDONid)
                        newADDONp.setSetting('cloneof',ADDONname)
                        newADDONp.setSetting('clonedat','%s'%todays)
                        
                        with open(settingsxml,'w',encoding='utf-8') as output:
                            output.write(desc)
                
                        restIcons(progpathnew,datapath)
                        
                        ### Make backup of new version
                        now= datetime.today().strftime('-new-%Y-%m-%dh%Hm%Ms%S')
                        addonfolder = progpathnew.replace(newADDONid,'')
                        if addonfolder[-1] == '/' or addonfolder[-1] == '\\':
                            addonfolder = addonfolder[:-1]
                        if progpathnew[-1] == '/' or progpathnew[-1] == '\\':
                            progpathnew = progpathnew[:-1]
                        log('shutil.make_archive(\nprogpathnew+now= %r, \nzip, \naddonfolder= %r, \nnewADDONid= %r)' % (progpathnew+now, addonfolder, newADDONid))
                        shutil.make_archive(progpathnew+now, 'zip', addonfolder, newADDONid)
                        
                        utils.notificationsend('[COLOR lightgreen][B]' + newADDONname + '[/B][/COLOR] Updated with design of ' + ADDONname)
                else:
                    utils.notificationsend('[COLOR red][B]' + newADDONname + '[/B][/COLOR] Was not updated with design of ' + ADDONname + '\nScanning or recording is active!')
    
    elif mode==2510:   ### Get new Direct Channels file and copy to data area - Update EPG
        log('err mode= %r' % mode)
        ChannelFile = definition.ADDONgetSetting('directchannelsfromextraXMLTVfile')
        if os.path.isfile(ChannelFile):
            directchannelsdef = ChannelFile
        else:
            directchannelsdef = os.path.join(progpath, 'directchannels.m3u.txt')
        directchannels    = getFile('Your Direct Channels m3u File or keep last',directchannelsdef)
        if os.path.isfile(directchannels) and directchannels != directchannelsdef:
            directchannelsdata = os.path.join(datapath,'directchannels.m3u')
            definition.ADDONresetSetting('directchannelsfromextraXMLTVfile',directchannelsdata)
            shutil.copyfile(directchannels, directchannelsdata)
            updateepg.ScanRecordings('all')
        else:
            try:
                definition.ADDONresetSetting('directchannelsfromextraXMLTVfile','')
                os.remove(os.path.join(datapath,'directchannels.m3u'))
            except Exception as e:
                log('err 9973 Except: %r' % e)
                pass
    
    elif mode==2550:    ###    Activate or Deactivate Channels      
        log('err mode= %r' % mode)
        try:
            ###result = recordings.addCategori('category', 'channelType', 'test')
            dialog = xbmcgui.Dialog()
            choises = ['Handle New Categories','Activate Categories','Deactivate Categories']
            resultDB = [recordings.getNewCategories(),recordings.getInActiveCategories(),recordings.getActiveCategories()]
            for i in range(0,len(choises)) :
                choises[i] += ' - ' + str(len(resultDB[i]))
            ###lenresultDB = len(resultDB)
            ###choises =  choises + lenresultDB
            headline = ADDONname + ' Select Categories Action'
            selected = dialog.select(headline, choises)
            log('10581 error selected= %r' % selected)
            if selected == 0:   ### Handle New Categories
                lockcause = 'New' ### Dummy command
                headline = ADDONname + ' Select New Categories to Activate (rest will be deactivated)'
                ###resultDB = recordings.getNewCategories()
            elif selected == 1: ### Activate Categories
                lockcause = 'Activate' ### Dummy command
                headline = ADDONname + ' Select Categories to Activate'
                ###resultDB = recordings.getInActiveCategories()
            elif selected == 2: ### Deactivate Categories
                lockcause = 'Deactivate' ### Dummy command
                headline = ADDONname + ' Select Categories to Deactivate'
                ###resultDB = recordings.getActiveCategories()
            if selected != -1:
                categories = []
                categoriesselected = []
                result = 'Not Found'
                ###log('10598 error mode==2550 resultDB= %r ' % resultDB)
                i = 1
                for chan in resultDB[selected]: 
                    ###log('10598 error mode==2550 chan= %r ' % chan)
                    channel = chan[0]
                    mtype   = chan[1]
                    shortchan = utils.untilD8(channel).strip()
                    log('10602 error shortchan= %r' % shortchan)
                    active  = chan[2]  ### Source
                    if active == 'new':
                        active  = '[B][COLOR red]---<*** New! ***>---[/COLOR][/B]'
                    else:
                        active  = ''
                    log('10599 error mtype= %r\n  chan[0]= %r\nshortchan= %r ' % (mtype,channel,shortchan))
                    categories.append(str(i) + ' ' + shortchan + ' [' + mtype + '] '+ active)
                    categoriesselected.append((chan[0],chan[1]))
                    i += 1
                
                selection = dialog.multiselect(headline, categories)
                log('10615 error selection= %r' % selection)
                result = []
               
                if selection :
                    for x in selection:
                        log('10619 error x= %r' % x)
                        if x >= 0:
                            y = categories[x]
                            ###setCategoriesInactive(categori,categoritype)
                            if lockcause == 'Activate' or lockcause == 'New' :
                                log('10623 error Activate or New y= %r' % y)
                                response = recordings.setCategoriesActive(categoriesselected[x][0],categoriesselected[x][1])
                            else:
                                log('10626 error Dectivate y= %r' % y)
                                response = recordings.setCategoriesInactive(categoriesselected[x][0],categoriesselected[x][1])
                            if response :
                                result.append(y)
                            else:
                                result.append(y+' FAILED')
                
                if lockcause == 'New' :
                    for x in range(0,len(categories)) :
                        log('10637 error New x= %r' % x)
                        if selection == None :
                            if x >= 0:
                                y = categories[x]
                                log('10639 error Dectivate y= %r' % y)
                                response = recordings.setCategoriesInactive(categoriesselected[x][0],categoriesselected[x][1])
                                if response :
                                    result.append(y)
                                else:
                                    result.append(y+' FAILED')
                                    
                        elif not x in selection :
                            log('10634 error not x in selection x= %r ' % x)
                            if x >= 0:
                                y = categories[x]
                                log('10639 error Dectivate y= %r' % y)
                                response = recordings.setCategoriesInactive(categoriesselected[x][0],categoriesselected[x][1])
                                if response :
                                    result.append(y)
                                else:
                                    result.append(y+' FAILED')
                        else:
                            log('10634 error not x in selection x= %r ' % x)
                            if x >= 0:
                                y = categories[x]
                                log('10639 error Dectivate y= %r' % y)
                                response = recordings.setCategoriesActive(categoriesselected[x][0],categoriesselected[x][1])
                                if response :
                                    result.append(y)
                                else:
                                    result.append(y+' FAILED')    
                
                lennowCategories = len(recordings.getAllCats())
                lenactiveCategories = len(recordings.getActiveCats())
                lennewCategories = len(recordings.getAllNewCats())
                if lenactiveCategories == 0:
                    lenactiveCategoriesT = '[B][COLOR red]' + str(lenactiveCategories) + '[/COLOR][/B]'
                else:
                    lenactiveCategoriesT = '[B][COLOR lightgreen]' + str(lenactiveCategories) + '[/COLOR][/B]'
                if lennewCategories >= 1:
                    lennewCategoriesT = '[B][COLOR red]' + str(lennewCategories) + '[/COLOR][/B]'
                else:
                    lennewCategoriesT = '0'
                definition.ADDONresetSetting('lastEPGimportCategories',str(lennowCategories)+' / '+lenactiveCategoriesT+' / '+lennewCategoriesT)
                utils.notificationsend('[COLOR lightgreen][B]' + headline+ '[/B][/COLOR] Succeded ;-)\nResult= %r' % result)
                log('error End Supplier Category Select cause= %r for following %r' % (lockcause,result))
                
                if result != [] and not locking.isScanLocked('EPG_update'):
                    ### action="RunScript(plugin.video.lioniptv, 2550, ?mode=2550&url=url&name=&recordname=&description=)"
                    recordings.EPGOnce() 
        except Exception as e:
            log('err 10625 Except: %r' % e)
            pass
            log('10627 Activate or Deactivate Channels ERROR: ' + repr(e))
            utils.notificationsend('[COLOR red][B]' + headline+ '[/B][/COLOR] Failed: %r' % e)
        
    elif mode==3000:  ### Grab from TV Guide
        log('err mode= %r' % mode)
        findtvguidenotifications.findtvguidenotifications()
        utils.logdev('findtvguidenotifications.py','Ended')
        ###xbmc.executebuiltin("Container.Refresh")  ### Do not work here
        
    elif mode==3010:  ### Delete all .set files - defaults to mounted drives
        try:
            log('err mode= %r' % mode)
            record_archive_path = definition.ADDONgetSetting('record_archive_path_default_mount')
            record_path = definition.ADDONgetSetting('record_path_default_mount')
            definition.ADDONresetSetting('record_archive_path',record_archive_path)
            definition.ADDONresetSetting('record_path',record_path)
            utils.deleteset()
            utils.notificationsend('[COLOR green][B]' + ADDONname + '[/B][/COLOR] Setting files deleted (*.set) and Recording Paths are now empty')
        except Exception as e:
            pass
            log('10391 err Delete all .set files Except: %r' % e)
    
    elif mode==3011:  ### Delete all .set files - defaults to samba drives
        try:
            log('err mode= %r' % mode)
            record_archive_path = definition.ADDONgetSetting('record_archive_path_default_samba')
            record_path = definition.ADDONgetSetting('record_path_default_samba')
            definition.ADDONresetSetting('record_archive_path',record_archive_path)
            definition.ADDONresetSetting('record_path',record_path)
            utils.deleteset()
            utils.notificationsend('[COLOR green][B]' + ADDONname + '[/B][/COLOR] Setting files deleted (*.set) and Recording Paths are now empty')
        except Exception as e:
            pass
            log('10391 err Delete all .set files Except: %r' % e)


    elif mode==4000:
        recordings.addAlarm('Mode4000', 'Reschedule', 'mode=4000', '00:00:00', 'options')   ### 2022-08-14
        log('err mode= %r' % mode)
        recordings.ftvntvlist() ### Force INI file
        recordings.delOldEPGPrograms()  ### 7 days old programs and 2 days old channels
       
        updatedrecordings = recordings.finddoubletes()  ### Find double programs
        ###if updatedrecordings >= 1:
        ###    recordings.reschedule() ### Set EPG program start
        recordings.reschedule() ### Set EPG program start
        
    elif mode==4400:    ### Mount Network Drive          
        log('err mode= %r' % mode)
        mount()
    
    elif mode==4440:    ### Create fullandfavoriteEPG  
        try:
            ###recordings.setAlarm('fullandfavoriteEPG','fullandfavoriteEPG.py','once','00:00:00','silent')
            recordings.setAlarm('fullandfavoriteEPG','fullandfavoriteEPG.py','just do it','00:00:00','silent')
            utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] fullandfavoriteEPG Started')
        except Exception as e:
            pass
            definition.log(module + ': fullandfavoriteEPG Except: %r' % e)
            utils.notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] fullandfavoriteEPG  failed: %r' % e)
    elif mode==4441:    ### Remove all favorites  
        try:
            recordings.removeallfavotites()
            utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] Remove all favorites Finished')
        except Exception as e:
            pass
            definition.log(module + ': Remove all favorites Exception: %r' % e)
            utils.notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] Remove all favorites  failed: %r' % e)
                    
    elif mode==4499:    ### Test function
        dns_servers = utils.showdns()
        headline = 'dns_servers'    
        defaultt = ''
        for dns in dns_servers:
            defaultt += dns + ' ' 
        dialog = xbmcgui.Dialog()
        newtext = dialog.input(headline, defaultt)
        try:
            EPGurl = 'http://line.dino.ws:80/xmltv.php?username=8dnebn9ii5&password=7jbq9bx6nt&prev_days=2&next_days=10'   ###/xmltv.php?username=8dnebn9ii5&password=7jbq9bx6nt'  ###&next_days=7'   ### 2026-04-16  Test new link
            
            headline = 'HTTP link to test: Result in datafile EPGFullTest.xml'
            
            defaultt = EPGurl
            dialog = xbmcgui.Dialog()
            newtext = dialog.input(headline, defaultt)
            if newtext != '':
                EPGurl = newtext
            
                log('exception Test function EPGurl= %r' % EPGurl)
                ChannelFileTest = os.path.join(datapath,'EPGfullTest.xml')  
                log('Exception ChannelFileTest= %r' % ChannelFileTest)                
                data = utils.readlink(EPGurl,ChannelFileTest,module)
                log('Exception data= %r' % data)
                if b'HTTPError' in data or b'URLError' in data:
                    utils.notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] Test function failed: %r' % data)
                else:
                    utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] Test Function Finished') 
            
        except Exception as e:
            pass
            log('File Actions error: ' + repr(e))
            utils.notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] Test function failed: %r' % e)
            
    elif mode==4500:    ### File Actions     
        try:
            utils.log(module,'File Actions  mode= %r' % mode)
            dbPath = xbmcvfs.translatePath('special://home/')
            log('error dbPath= %r' % dbPath,showlength=500000)   ### directories in kodi!
            while dbPath != 'Cancel' :
                log('error dbPath= %r' % dbPath)
                dbPath = filehandler(dbPath)  
            result = 'Cancel'
            utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] File Actions Finished')                                                            
        except Exception as e:
            pass
            log('File Actions error: ' + repr(e))
            utils.notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] File Actions failed: %r' % e)
            
    elif mode==4501:    ### Copy Database to/from Recordings Folder   
        utils.log(module,'File Actions  mode= %r' % mode)
        try:### fra service
            if definition.ADDONgetSetting('copyrecordingsdatabase')=='true':
                recordings.setRecordsBase()    ### Copy recordings database to recordings folder
            
            if definition.ADDONgetSetting('getrecordingsdatabase')=='true':
                recordings.getRecordsBase()    ### Copy recordings database from recordings folder
        
            utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] Copy Database to/from Recordings Folder Finished')                                                               
        except Exception as e:
            pass
            log('File Actions error: ' + repr(e))
            utils.notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] Copy Database to/from Recordings Folder failed: %r' % e)
            
    elif mode==5000:   ### SELECT
        log('err mode= %r' % mode)
        try:
            log('Select! activated on cat= %r, sys.argv[1]= %r ' % (cat,sys.argv[1]))
            log('10 higlights= %r' % higlights)
            ###ThisHighlight = '#cat=' + cat + '#startDate=' + startDate +'#endDate=' + endDate + '#name=' + name + '#recordname=' + recordname + '#'
            ThisHighlight = '#cat=' + cat + '#startDate=' + startDate +'#endDate=' + endDate + '#name=' + name + '#recordname=' + recordname + '#description=' + description + '#'
            ThisHighlight = ThisHighlight.replace(' [COLOR red][B]SELECTED[/B][/COLOR]','',1).replace('[COLOR red][B]¤[/B][/COLOR]','',1)
            RemoveHiglight = False
            if ThisHighlight in higlights:
                RemoveHiglight = True
            else:
                higlights.append(ThisHighlight)
            log('11 higlights= %r' % higlights)
            allhiglights = ''
            i = 0
            for x in higlights:
                i += 1
                log('12 i= %r, x= %r' % (i,x))
                if x == ThisHighlight and RemoveHiglight == True:
                    x = ''
                if allhiglights != '' and x != '':
                    allhiglights = x + '¤¤¤¤' + allhiglights
                elif x != '':
                    allhiglights = x
            definition.ADDONresetSetting('higlights',allhiglights)
            log('13 allhiglights= %r' % allhiglights)
            """
            apikeyS = Search('apikey')
            apikey = xbmcplugin.getSetting(Handle, id=apikeyS)
            xbmcgui.Dialog().ok( repr(apikeyS), repr(apikey))
            log('Select! before= %r, after= %r ' % (apikeyS,apikey))
            log('Select! liz= %r' % (liz))
            selected = liz.getSelectedItem().isSelected()
            liz.getSelectedItem().select(True)
            selected1 = liz.getSelectedItem().isSelected()
            log('Select! before= %r, after= %r ' % (selected,selected1))
            """
        except Exception as e:
            log('err 10061 Except: %r' % e)
            pass
            log('Select! activated on cat= %r, Except= %r ' % (cat,e))
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin("Container.Refresh")
        """
        isSelected(...)
        isSelected() --Returns the listitem's selected status.
        example:
            - is = self.list.getSelectedItem().isSelected()
        
        select(...)
        select(selected)--Sets the listitem's selected status.
        selected : bool - True=selected/False=not selected
        example:
        - self.list.getSelectedItem().select(True)
        
        getSetting(...)
        getSetting(handle, id)--Returns the value of a setting as a string.
         
        handle : integer - handle the plugin was started with.
        id : string - id of the setting that the module needs to access.
         
        *Note, You can use the above as a keyword.
         
        example:
            - apikey = xbmcplugin.getSetting(Handle, 'apikey')
        """
    elif mode==5001:   ### Deselect All
        log('err mode= %r' % mode)
        try:
            definition.ADDONresetSetting('higlights','')
            log('Deselect All! ')
            
        except Exception as e:
            log('err 10094 Except: %r' % e)
            pass
            log('Deselect all! activated on cat= %r, Except= %r ' % (cat,e))
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin("Container.Refresh")
        
    elif mode == 6000:     ### Delete EPG Program Entry
        log('err mode= %r' % mode)
        ### mode=6000&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s
        log( 'Delete EPG Program Entry: mode=6000&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s' % (url, cat, startDate, endDate, recordname, description))
        dialog = xbmcgui.Dialog()
        ###dialog.ok('[B]' + ADDONname + '[/B]','Delete EPG Program Entry?','url=%s\cat=%s\nstartDate=%s\nendDate=%s\nrecordname=%s\ndescription=%s' % (url, cat, startDate, endDate, recordname, description))
        try:
            channel = recordings.ChannelName(cat)
            time_tuple = time.strptime(startDate, "%Y-%m-%d %H:%M:%S")
            timestampSD = int(time.mktime(time_tuple))
            time_tuple = time.strptime(endDate, "%Y-%m-%d %H:%M:%S")
            timestampED = int(time.mktime(time_tuple))
            epgchannel= recordings.EPG_ChannelFromCat(cat)
        except Exception as e:
            log('err 10112 Except: %r' % e)
            pass
            channel = repr(e)
            timestampSD = ''
            timestampED = ''
            epgchannel = ''
        if dialog.yesno('[B]' + ADDONrefer + '[/B]', '[CR] [CR] [CR][COLOR red]Delete EPG Program Entry?[/COLOR]\nepgchannel=%r\nchannel=%s\nurl=%s\ncat=%s\nstartDate=%s = %r\nendDate=%s = %r\nrecordname=%s\ndescription=%s' % (epgchannel, channel, url, cat, startDate, timestampSD, endDate, timestampED, recordname, description),'[COLOR red]Delete[/COLOR]','[COLOR green]Ignore[/COLOR]'):
            ### Ignore
            lockcause = 'ignore' ### Dummy command
        else:
            ### Delete EPG Program Entry    
            success = recordings.delEPGProgram(epgchannel, timestampSD, timestampED)
            if success:
                dialog.ok('[B]' + ADDONrefer + '[/B]','Deletet EPG Program Entry')
    
    elif mode == 7001:   ### NTVCHANNELS --> GlowIPTV
        log('err mode= %r' % mode)
        ###dialog = xbmcgui.Dialog()
        try:
            count = int(description)
            definition.ADDONresetSetting('NTVCHANNELScount',str(count))
            ###dialog.ok('[B]' + ADDONname + '[/B]','Next/Previous GlowIPTV channel count: %r' % count,'')
            addonID = definition.ADDONgetSetting('LastaddonID')
            NTVCHANNELS(addonID)
        except Exception as e:
            log('err 10135 Except: %r' % e)
            pass
            dialog = xbmcgui.Dialog()
            dialog.ok('[B]' + ADDONrefer + '[/B]','Next/Previous GlowIPTV channel failed: %r' % e,'')
    elif mode == 7002:   ### TVawayCHANNELS
        log('err mode= %r' % mode)
        ###dialog = xbmcgui.Dialog()
        try:
            count = int(description)
            definition.ADDONresetSetting('TVawayCHANNELScount',str(count))
            ###dialog.ok('[B]' + ADDONname + '[/B]','Next/Previous NTV channel count: %r' % count,'')
            TVawayCHANNELS()
        except Exception as e:
            log('err 10146 Except: %r' % e)
            pass
            dialog = xbmcgui.Dialog()
            dialog.ok('[B]' + ADDONrefer + '[/B]','Next/Previous TVaway channel failed: %r' % e,'')
    elif mode == 7003:  ### NEWCHANNELS
        log('err mode= %r' % mode)
        ###dialog = xbmcgui.Dialog()
        try:
            count = int(description.split('[CR]')[0])
            definition.ADDONresetSetting('NEWCHANNELScount',str(count))
            ###dialog.ok('[B]' + ADDONname + '[/B]','Next/Previous NTV channel count: %r' % count,'')
            NEWCHANNELS()
        except Exception as e:
            log('err 10157 Except: %r' % e)
            pass
            dialog = xbmcgui.Dialog()
            dialog.ok('[B]' + ADDONrefer + '[/B]','Next/Previous New Channel or VOD failed: %r' % e,'')
    elif mode == 7007:  ### NEWSERIES
        log('err mode= %r' % mode)
        ###dialog = xbmcgui.Dialog()
        try:
            count = int(description.split('[CR]')[0])
            definition.ADDONresetSetting('NEWSERIEScount',str(count))
            ###dialog.ok('[B]' + ADDONname + '[/B]','Next/Previous NTV channel count: %r' % count,'')
            NEWSERIES()
        except Exception as e:
            log('err 10168 Except: %r' % e)
            pass
            dialog = xbmcgui.Dialog()
            dialog.ok('[B]' + ADDONrefer + '[/B]','Next/Previous New TV Series failed: %r' % e,'')
    elif mode == 7005:  ### TVSeries
        log('err mode= %r' % mode)
        ###dialog = xbmcgui.Dialog()
        try:
            count = int(description.split('[CR]')[0])
            definition.ADDONresetSetting('TVSeriescount',str(count))
            ###dialog.ok('[B]' + ADDONname + '[/B]','Next/Previous NTV channel count: %r' % count,'')
            TVSeries()
        except Exception as e:
            log('err 10179 Except: %r' % e)
            pass
            dialog = xbmcgui.Dialog()
            dialog.ok('[B]' + ADDONrefer + '[/B]','Next/Previous TV Series failed: %r' % e,'')
    elif mode == 7006:  ### TVEpisodes
        log('err mode= %r' % mode)
        ###dialog = xbmcgui.Dialog()
        try:
            seriey = url
            log('err 7006 seriey= %r' % seriey)
            count = int(description)
            definition.ADDONresetSetting('TVEpisodescount',str(count))
            ###dialog.ok('[B]' + ADDONname + '[/B]','Next/Previous NTV channel count: %r' % count,'')
            TVEpisodes(seriey)
        except Exception as e:
            log('err 10192 Except: %r' % e)
            pass
            dialog = xbmcgui.Dialog()
            dialog.ok('[B]' + ADDONrefer + '[/B]','Next/Previous TV Episodes failed: %r' % e,'')
    elif mode == 7004:  ### MYSELECTEDCHANNELS
        log('err mode= %r' % mode)
        ###dialog = xbmcgui.Dialog()
        try:
            count = int(description)
            definition.ADDONresetSetting('MYSELECTEDCHANNELScount',str(count))
            ###dialog.ok('[B]' + ADDONname + '[/B]','Next/Previous NTV channel count: %r' % count,'')
            MYSELECTEDCHANNELS()
        except Exception as e:
            log('err 10203 Except: %r' % e)
            pass
            dialog = xbmcgui.Dialog()
            dialog.ok('[B]' + ADDONrefer + '[/B]','Next/Previous Direct Channels failed: %r' % e,'')
    elif mode == 8000:  ### Clean up after Timezone or Daylight Saving Time shift
        log('err mode= %r' % mode)
        """
        1. Delete New EPG programs','url',110 recordings.delNewEPGPrograms()
        2. Delete All Planned Recordings ex Recursive','url',109 recordings.delAllPlannedPrograms()
        Always use actual timezone so not this 3. Update EPG offset +/- 1 Hour
        4. Update EPG now','url',115 recordings.EPGOnce() 

        utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] Update EPG has started')
        """
        try:
            """
            d = datetime.now()
            #get month number
            mo = int(d.strftime("%m"))
            NoDST = definition.ADDONgetSetting('AdjustTVguideTimeZoneOffsetExtraXMLNoDST')
            if NoDST == '':
                NoDST = 0
            else:
                NoDST = int(NoDST)
            DST = definition.ADDONgetSetting('AdjustTVguideTimeZoneOffsetExtraXML')
            if DST == '':
                DST = 0
            else:
                DST = int(DST)
            if mo < 6:
                EPGoffset = NoDST + 1
            else:
                EPGoffset = NoDST
            definition.ADDONresetSetting('AdjustTVguideTimeZoneOffsetExtraXML',str(EPGoffset)) 
            """
            recordings.delNewEPGPrograms()
            recordings.delAllPlannedPrograms()
            recordings.EPGOnce() 
            utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] Clean up after Timezone or Daylight Saving Time shift has started')
        except Exception as e:
            log('err 10203 Except: %r' % e)
            pass
            dialog = xbmcgui.Dialog()
            dialog.ok('[B]' + ADDONrefer + '[/B]','Clean up after Daylight Saving Time shift failed: %r' % e,'')
    else:
        log('err [B]' + ADDONrefer + '[/B][CR][COLOR red]11913 Oops - something went wrong![/COLOR][CR]mode= %r' % mode)
    
else:
    message = '[COLOR red]Wait - updating EPG![/COLOR]'
    utils.notification(message)
    findtvguidenotifications.findtvguidenotificationsend(message)
    sleep(1000)

"""
try:
    xbmcplugin.addSortMethod(Handle, xbmcplugin.SORT_METHOD_DATE)
    xbmcplugin.addSortMethod(Handle, xbmcplugin.SORT_METHOD_TITLE)
except Exception as e:
    pass
    utils.logdev('addSortMethod','ERROR: %r' % e)
"""    

try:
    show_list_item = utils.intADDONgetSetting('show_list_item')
    definition.ADDONresetSetting('show_list_item','0')
    log('show_list_item= %r' % show_list_item)
    if show_list_item != 0:
        win = xbmcgui.Window(xbmcgui.getCurrentWindowId())
        log('xbmcgui.Window= %r' % win)
        cid = win.getFocusId()
        log('win.getFocusId= %r' % cid)
        xbmc.executebuiltin('SetFocus(%s, %s)' % (cid, show_list_item))
except Exception as e:
    log('err 10236 Except: %r' % e)    
    log('ERROR in showEPGm SetFocus: %r' % e)
    pass

xbmcplugin.endOfDirectory(Handle)

