#!/usr/bin/python
# -*- coding: utf-8 -*-
import utils
import xbmcaddon, xbmc
import time

ADDON     = xbmcaddon.Addon()
ADDONname = ADDON.getAddonInfo('name')
ADDONid   = ADDON.getAddonInfo('id')
ADDONpath = xbmc.translatePath('special://home/addons/%s/' % ADDONid)
xbmc.log('service.py in %s' % ADDONname)
module= 'service.py'
utils.logdev(module,'Start')
utils.logdev(module,'service.py in %s' % ADDONname)

utils.logdevreset()

ADDON.setSetting('LastFindStation','')


utils.logdev(module,'Ended')

if __name__ == '__main__':
    monitor = xbmc.Monitor()
    
    while not monitor.abortRequested():
        # Sleep/wait for abort for 10 seconds
        if monitor.waitForAbort(10):
            # Abort was requested while waiting. We should exit
            break
        xbmc.log("hello addon! %s" % time.time(), level=xbmc.LOGNOTICE)
        utils.logdev(module,"hello addon! %r" % time.time())