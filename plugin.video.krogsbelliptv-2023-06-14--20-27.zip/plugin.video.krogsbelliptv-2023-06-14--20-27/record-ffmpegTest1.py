#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs,os
import datetime
import time
import utils, recordings
import net
from hashlib import md5  
import json  
import locking
import base64
# For Python 3.0 and later
from urllib.request import urlopen
import definition

module = 'record-ffmpeg.py'
###xbmc.log('%r: Module started' % module)   ### 2021-04-20

def log(infotext,showlength=500):
    debug = utils.ADDONgetSetting('debug').lower()
    if debug in infotext[0:100].lower() and not debug == '':
        utils.logdev('error',module + ': ' + infotext,showlength=showlength)
    else:
        nolog = True
        xbmc.log(utils.ADDONgetAddonInfo('name') + ' ' + module +': <*' + infotext[0:showlength]+'*>')

log('err Start module!')
try:
    ADDON      = definition.getADDON()
    log('29 errorZ ADDON= %r' % ADDON)
    ADDONname  = utils.ADDONgetAddonInfo('name')
    log('31 errorZ ADDONname= %r' % ADDONname)
    ADDONid    = utils.ADDONgetAddonInfo('id')
    log('33 errorZ ADDONid= %r' % ADDONid)
    datapath   = xbmcvfs.translatePath(utils.ADDONgetAddonInfo('profile'))
    log('35 errorZ datapath= %r' % datapath)
    log('36 errorZ  sys.argv= %r' % sys.argv)
    program  = sys.argv[0]
    log('38 errorZ program= %r' % program)
    cat      = recordings.argumenttostring(sys.argv[1])
    log('40 errorZ cat= %r' % cat)
    startTime= sys.argv[2]
    log('42 errorZ startTime= %r' % startTime)
    endTime  = sys.argv[3]
    log('44 errorZ endTime= %r' % endTime)
    duration = sys.argv[4]
    log('46 errorZ duration= %r' % duration)
    log('47 errorZ before title')
    log('46 errorZ sys.argv[5]= %r' % sys.argv[5])
    title    = utils.decode64(sys.argv[5])
    log('49 errorZ after title')
    log('50 errorZ title= %r' % title)
    log('51 errorZ before OrgTitle')
    OrgTitle = title
    log('53 errorZ after OrgTitle')
    log('50 errorZ OrgTitle= %r' % OrgTitle)
    title    = recordings.argumenttostring(title)
    log('51 errorZ title= %r' % title)
    argv6    = sys.argv[6]
    log('53 errorZ argv6= %r' % argv6)
    argv7    = sys.argv[7]
    log('55 errorZ argv7= %r' % argv7)
    nameAlarm= utils.decode64(sys.argv[8])
    log('57 errorZ nameAlarm= %r' % nameAlarm)
    nameAlarm= recordings.argumenttostring(nameAlarm)
    log('59 errorZ nameAlarm= %r' % nameAlarm)
    recordings.updateAlarm(nameAlarm)
    log('61 errorZ nameAlarm= %r' % nameAlarm)
except Exception as e:
    log('63 errorZ Exception: %r' % e)
    pass
    log('65 errorZ Basic parameters(cat= %r) Error %r' % (cat,e))

def FreeLine(cat):
    concurrentlines = 1
    usedlines       = 0
    
    ROQTVusername = utils.ADDONgetSetting('user')
    if ROQTVusername.lower() != 'none' and utils.ADDONgetSetting('panel_api') == 'true':
        try:
            link = definition.getBASEURL() + '/panel_api.php?username=' +utils.ADDONgetSetting('user')+ '&password=' +utils.ADDONgetSetting('pass')
            file = urlopen(link)
            data = file.read()
            file.close()
            
            ChannelFile = os.path.join(datapath,ADDONid) + '.info'
            with open(ChannelFile,'wb') as output:
                output.write(data)
            ###name= Status,url= url,mode= 11,iconimage= ,cat= ,date= ,description= {u'username': u'XXX', u'status': u'Active', u'is_trial': u'0', u'created_at': u'1493734688', u'auth': 1, u'allowed_output_formats': [u'm3u8', u'ts', u'rtmp'], u'exp_date': u'1499005088', u'active_cons': u'0', u'password': u'XXXX', u'max_connections': u'1'},startDate= ,endDate= ,recordname= )
            d = json.loads(data)
            d1 = d['user_info']
            concurrentlines = int(d1['max_connections'])
            usedlines       = int(d1['active_cons'])
        except Exception as e:
            log('err 68 Exception: %r' % e)
            pass
            log('FreeLine(cat= %r) Error %r' % (cat,e))
            concurrentlines = 1
            usedlines       = 0
    return concurrentlines - usedlines

try: 
    #get description 
    ###description= recordings.argumenttostring(sys.argv[9])
    description = sys.argv[9]
    description = utils.decode64(description)
    """
    try:
        if description[:3] == 'b64':
            decoded = base64.b64decode(description[3:])
        else:
            decoded = description
    except Exception as e:
        pass
        logdev(module,'base64.b64decode Error %r' % e)
        decoded = description
    description = decoded
    """
except Exception as e:
    log('err 92 Exception: %r' % e)
    pass
    description= 'Error getting description'
log('err description= %r' % description)

try: 
    #print os.environ
    log('os.environ= ' + os.environ['OS'])  #put in LOG
except Exception as e:
    log('err 100 Exception: %r' % e)
    pass

if 'UNL' in cat:
        URI='plugin://plugin.video.unlimtv/?mode=210&cat='+cat[3:]+'&url=plugin://'+ADDONid+'/&uri='+utils.decode64('recordfromunlimcat='+cat+'recordfromunlimtitle='+title+'recordfromunlimduration='+duration+'recordfromunlimnameAlarm='+nameAlarm+'recordfromunlimdescription='+utils.base64b64encode(description))   
        log('Get uri from unlimtv: URI= %r' % URI)
        maxSleep = 500
        try:
            log(repr(URI))
            xbmc.executebuiltin('RunPlugin(%s)' % URI) 
            xbmc.sleep(maxSleep)
        except Exception as e:
            log('err 115 Exception: %r' % e)
            pass
            log('Recording from UNL FAILED: %r' % e)
        
else:
    ###recorddrdirectly=utils.directprograms(cat)  ### Get direct links
    recorddrdirectly=recordings.directprograms(cat)  ### Get direct links
    log('recorddrdirectly= ' + repr(recorddrdirectly))  #put in LOG
    ###if recorddrdirectly == '':
    ###    PreTitle = ' ' + ADDONname+'-'
    ###else:
    ###    PreTitle = ' '
        
    try:
        ###utils.ADDONgetSetting('basicuserinfo')  ### 3 letter Addon get it from file name with user info
        ###source1 = ' ' + ADDONid.split('.')[2][:3].upper() + ' ' 
        ###source1 = ' ' + utils.ADDONgetSetting('basicuserinfo').split(os.sep)[-1][:3].upper() + ' ' 
        source1 = ' ' + utils.ADDONgetSetting('my_referral_init') + ' '
    except Exception as e:
        log('err 133 Exception: %r' % e)
        pass
        log('ADDONid.split(.)[2][:3].upper() ERROR: %r' % e)
        source1 = ''
    PreTitle = source1
    log('PreTitle= <' + repr(PreTitle) + '>')  #put in LOG

    LoopCountMax = int(utils.ADDONgetSetting('LoopCount'))

    log('162 errorZ Recording title= %r' % title)
    log('163 errorZ Start recording %r' % title)
    recordings.updateRecordingPlanned(nameAlarm, '[COLOR orange][record-ffmpeg]Start recording of [/COLOR] ' + title)
    ###Recordings = utils.ADDONgetSetting('Recordings') + nameAlarm
    locking.markLock(nameAlarm)
    ###utils.ADDONsetSetting('Recordings',Recordings)
    ###locking.recordLock('Start recording of ' + title) ### TEST
    RecordingDisabled = False
    #print 'record.py: nameAlarm= %s' % (str(repr(nameAlarm)))
    #log('LoopCountMax= %s' % (str(repr(LoopCountMax))))
    recordPath = xbmcvfs.translatePath(os.path.join(utils.ADDONgetSetting('record_path')))
    log('recordPath= %s' %recordPath)
    if not utils.folderwritable(recordPath):
        utils.notification('Recording %s [COLOR red]FAILED - You must set the recording path writable![/COLOR]' % title)
        log('You must set the recording path writable! ' + title)
        ###locking.recordLock('You must set the recording path writable! ' + title) ### TEST
    else:
        Retry = True
        LoopCount = 0
        try:
            nowHM=datetime.datetime.today().strftime('%H:%M:%S')
        except Exception as e:
            log('err 163 Exception: %r' % e)
            pass
        """
        try:
            #locking.recordUnlock(title)
            #A new recording unlocks all previous - otherwise the retry feature will make some fuzz
            locking.recordUnlockAll()   ### with multi stream record - this will not work! 2017-08-09
        except Exception as e:
            log('err 170 Exception: %r' % e)
            pass
        """
        try:
            if recorddrdirectly == '': ### 2017-08-24
                ### No free lines? wait for real start of program 2020-02-06
                freelines = FreeLine(cat)
                log('freelines= %r' % freelines)
                if freelines <= 0 :
                    try:
                        TimeBefore = int(utils.ADDONgetSetting('TimeBefore'))
                    except Exception as e:
                        log('err 181 Exception: %r' % e)
                        pass
                        TimeBefore = 1
                    try:
                        TimeBeforeOverlap = int(utils.ADDONgetSetting('TimeBeforeOverlap'))
                    except Exception as e:
                        log('err 186 Exception: %r' % e)
                        pass
                        TimeBeforeOverlap = 1
                    log('TimeBefore= %r' % TimeBefore)
                    log('TimeBeforeOverlap= %r' % TimeBeforeOverlap)
                    sleepmiliseconds = 1000 * 60 * (TimeBefore + TimeBeforeOverlap)
                    log('sleepmiliseconds= %r' % sleepmiliseconds)
                    if sleepmiliseconds > 0 :
                        xbmc.sleep(sleepmiliseconds)   ### time in miliseconds - wait 2 minutes extra
                log('recordLock(nameAlarm= %r )' % nameAlarm)
                locking.recordLock(nameAlarm)
        except Exception as  e:
            log('err 197 Exception: %r' % e)
            pass
            log('recordLock(nameAlarm= %r ERROR: %r)' % (nameAlarm,e))
            ###locking.recordLock('recordLock(nameAlarm= %r ERROR: %r)' % (nameAlarm,e))
        while (Retry == True) and (LoopCount < LoopCountMax) and (locking.isRecordLocked(nameAlarm) or recorddrdirectly != '' ) :   ### 2017-08-24
            try:
                nowHM=datetime.datetime.today().strftime('%H:%M:%S')
                playchannelName = recordings.ChannelName(cat)
                if playchannelName == '':
                    playchannel = str(cat) 
                else:
                    playchannel = playchannelName
                playchannel = playchannel.replace('+','Plus')  ### Replace + in filename
                playchannel = re.sub('[,:\\/*?\<>|"]+', '', playchannel)   ### 2017-09-30 Only chars allowed in filenames 
                if not recorddrdirectly == '':
                    Retry = True
                    ### cat='147'  DR1 http://dr01-lh.akamaihd.net/i/dr01_0@147054/master.m3u8?b=100-3000
                    rtmp     = recorddrdirectly
                else:
                    ###url      = definition.getBASEURL() + '/index.php?' + recordings.referral()+ 'c=6&a=0&mwAction=content&xbmc=1&mwData={"id":%s,"type":"tv"}' % cat
                    ###link     = net.http_GET(url,headers={"User-Agent":"NTV-XBMC-" + utils.ADDONgetAddonInfo('version')}).content
                    ###data     = json.loads(link)
                    try:
                        rtmp     = recordings.urlFromCat(cat)
                    except Exception as  e:
                        log('err 221 Exception: %r' % e)
                        pass
                        log('recordings.urlFromCat(cat= %r ERROR: %r)' % (cat,e))
                        rtmp     = recordings.catFromUrl(url)
            except Exception as  e:
                log('err 225 Exception: %r' % e)
                pass
                utils.notification('Recording [COLOR red]NOT possible! No data on channel[/COLOR] %s' % (playchannel))
                ###locking.recordLock('Recording [COLOR red]NOT possible! No data on channel[/COLOR] %s' % (playchannel))
                recordings.updateRecordingPlanned(nameAlarm, 'Recording [COLOR red]NOT possible! No data on channel[/COLOR] '+ playchannel + " - " + title + ' at ' + nowHM)
                log('Recording NOT possible! No data on channel ' + playchannel + ' - ' + title + '\nError: ' + repr(e))
                #nowHM=datetime.datetime.today().strftime('%H:%M:%S')
                #print 'record.py1: title= %s, LoopCount= %s at %s' % (repr(title),repr(LoopCount),nowHM)
                xbmc.sleep(10000)
                ###time.sleep(10)
                #nowHM=datetime.datetime.today().strftime('%H:%M:%S')
                #print 'record.py2: title= %s, LoopCount= %s at %s' % (repr(title),repr(LoopCount),nowHM)
                rtmp = ''
            #nowHM=datetime.datetime.today().strftime('%H:%M:%S')
            #print 'record.py3: title= %s, LoopCount= %s at %s' % (repr(title),repr(LoopCount),nowHM)
            #utils.notification('Recording %s [COLOR orange]LOOP %s[/COLOR]' % (title, nowHM))
            if rtmp == '' :
                Retry = True
                LoopCount += 1
                LoopCountMax = int(utils.ADDONgetSetting('LoopCount'))
                nowHM=datetime.datetime.today().strftime('%H:%M:%S')
                #print 'record.py4: title= %s, LoopCount= %s at %s' % (repr(title),repr(LoopCount),nowHM)
            else:
                nowHM=datetime.datetime.today().strftime('%H:%M:%S')
                #print 'record.py5: title= %s, LoopCount= %s at %s' % (repr(title),repr(LoopCount),nowHM)
                cmdoption = ''
                try:
                    #cmd += ' -V --stop ' + utils.ADDONgetSetting('RecordFromTVguideDurationMinutes')
                    cmdoption += ' -t ' + str(int(duration)) 
                except Exception as  e:
                    log('err 254 Exception: %r' % e)
                    pass
                    log('cmdoption += %r\nError: %r' % (cmdoption,e))
                    cmdoption += ' -t ' +str(120)
                if os.access('/system/vendor/bin/ffmpeg', os.X_OK):
                    cmd = '/system/vendor/bin/ffmpeg -y -listen_timeout 2000 -i '  # Use seperately installed ffmpeg program ###
                else:
                    cmd = 'ffmpeg -y -listen_timeout 2000 -i '  # Use seperately installed ffmpeg program with timeout one minute ###
                cmd += '"' + rtmp + '"'
                ffmpegoptions= utils.ADDONgetSetting('ffmpegoptions')
                log('ffmpegoptions= %r' % ffmpegoptions)
                if ffmpegoptions == '1':
                    cmd += ' -f flv  -c:v libx264 -c:a aac -ac 1 -strict -2 -crf 18 -profile:v baseline -maxrate 2000k -bufsize 18350K ' + cmdoption + ' ' ### For use with ffmpeg
                elif ffmpegoptions == '2':
                    cmd += ' -c copy ' + cmdoption + ' ' ### For use with ffmpeg and ac3 sound
                elif ffmpegoptions == '0':
                    cmd += ' -c copy -bsf:a aac_adtstoasc ' + cmdoption + ' ' ### For use with ffmpeg
                else:
                    ffmpegfreeoption = utils.ADDONgetSetting('ffmpegfreeoption')
                    cmd += ' ' + ffmpegfreeoption + ' ' + cmdoption + ' ' ### For use with ffmpeg free option
                filetitle = recordings.latin1_to_ascii_force(title)
                filetitle = filetitle.replace('?', '_')
                filetitle = filetitle.replace(':', ' -')
                filetitle = filetitle.replace('/', '-')
                filetitle = filetitle.replace('+', '_')
                filetitle = filetitle.replace('\\', '_')
                filetitle = re.sub('[,:\\/*?\<>|"]+', '', filetitle)
                filetitle = " ".join(filetitle.split())  # Remove extra spaces from filename
                log('310 errorZ filetitle= %r' % filetitle)
                ###filetitle = filetitle + ']'   ### Test 2023-05-31
                ###title = title + ']'           ### Test 2023-05-31
                log('313 errorZ filetitle= %r' % filetitle)
                log('314 errorZ title= %r' % title)
                recordstarttime = datetime.datetime.today().strftime('%Y-%m-%d %H-%M')
                durationH = 0
                durationM = 0
                orgduration = ''
                if b'uration [' in description and b']' in description:  ### 2021-05-02 use duration in description if it is suitable
                    orgduration = (description.split(b'uration [')[1].split(b']')[0] + b'm').replace(b':',b'h')
                    log('orgduration= %r' % orgduration)
                    if len(orgduration) >= 7:
                        orgduration = ''
                if orgduration == '':
                    durationH = int(int(duration)/3600)
                    durationM = (int(duration) - durationH*3600)//60  ### 2021-06-21
                    orgduration =  str(durationH) + 'h' + str(durationM).zfill(2) + 'm'
                if duration == '0':
                    cmd += '"' + recordPath + filetitle + ' ['+recordstarttime+ PreTitle + playchannel  + ']'
                else:
                    ###durationH = int(int(duration)/60)
                    ###durationM = int(duration) - durationH*60
                    orgduration = '[' + str(orgduration) +']'
                    if '[' in filetitle:   ### Put duration first on second line, if not in line
                        if orgduration in filetitle:
                            filename1 = recordPath + filetitle
                        else:
                            filetitle1 = filetitle.replace('[',orgduration +'[',1)
                            filename1 = recordPath + filetitle1 
                    else:
                        filename1 = recordPath + filetitle + orgduration
                        
                        
                    cmd += '"' + filename1 + ' ['+recordstarttime+ PreTitle + playchannel+ ']'
                log('duration= %s, durationH= %s, durationM= %s' %(repr(duration),repr(durationH),repr(durationM)))  
                ext = utils.ADDONgetSetting('ffmpegoutputtype')
                if ext == '' or ext == None:
                    ext = 'mp4'
                if LoopCount >0:
                    cmd += ' ' + str(LoopCount) + '.'+ext+'"'  
                else:
                    cmd += '.'+ext+'"' 
                log('err 349 LoopCount= %r' % LoopCount)
                if LoopCount > 0:
                    infofilename = filename1 + ' ['+recordstarttime+ PreTitle + playchannel + '] ' + str(LoopCount) + '.txt'
                else:
                    infofilename = filename1 + ' ['+recordstarttime+ PreTitle + playchannel + '].txt'
                log('err infofilename= %s' % (repr(infofilename)))
                filename1 = infofilename[:-4]+'.log'   ### 2022-11-05
                log('err 356 infofilename= %r' % infofilename)
                ###if LoopCount >0:
                ###    filename1 = infofilename.replace('.txt',' ' + str(LoopCount) +'.log',1)  
                ###else:
                ###    filename1 = infofilename.replace('.txt','.log',1)
                cmd += ' 2> "' + filename1 + '"'   ### Save FFMPEG log 2018-01-22
                nowHM=datetime.datetime.today().strftime('%H:%M')
                log('LoopCount= %r, RecordingDisabled= %r'% (LoopCount, RecordingDisabled))
                ### if LoopCount == 0 and not RecordingDisabled:   
                if not RecordingDisabled:    ### 2022-11-05
                    if LoopCount == 0 :
                        utils.notification('Recording %s [COLOR yellow]started %s[/COLOR]' % (title, nowHM))
                        recordings.updateRecordingPlanned(nameAlarm, '[COLOR yellow]Started ' + nowHM + '[/COLOR] ' + title)
                    else:
                        LoopNr = str(LoopCount)
                        if not RecordingDisabled:
                            utils.notification('Recording %s [COLOR orange]RESTARTED# %s %s[/COLOR]' % (title, LoopNr, nowHM))
                            recordings.updateRecordingPlanned(nameAlarm, '[COLOR orange]Restarted# %s %s[/COLOR] %s' % (LoopNr, nowHM, title))
                    log('374 errorZ Recording started. %r' % title)
                    try:
                        # Create file with info on recording 'infofilename' .tit, .txt and .nfo format
                        """ File format for .nfo file
                        <?xml version="1.0" encoding="utf-8"?>
                        <episodedetails>
                            <title>Title</title>
                            <rating>Rating</rating>
                            <season>Season</season>
                            <episode>Episode</episode>
                            <plot>Plot</plot>
                            <thumb>Thumb</thumb>
                            <playcount>Playcount</playcount>
                            <lastplayed>LastPlayed</lastplayed>
                            <credits>Credits</credits>
                            <director>Director</director>
                            <aired>Aired</aired>
                            <premiered>Premiered</premiered>
                            <studio>Studio</studio>
                            <mpaa>MPAA Certification</mpaa>
                            <epbookmark>Episode Bookmark</epbookmark>
                            <displayseason>Display Season</displayseason>
                            <displayepisode>Display Episode</displayepisode>
                        </episodedetails>
                        
                        Example:
                        <?xml version="1.0" encoding="utf-8"?>
                        <episodedetails>
                          <title>Broen IIII 2-8</title>
                          <season>4</season>
                          <episode>2</episode>
                          <plot> Description </plot>
                            <displayseason>4</displayseason>
                          <displayepisode>2</displayepisode>
                        </episodedetails>

                        """
                        ###LF = open(infofilename, 'a')
                        LF = open(infofilename, 'w')   ### 2017-08-09
                        crlf = '\r\n'
                        # Write to our text file the information we have provided and then goto next line in our file.
                        LF.write('Recorded using: ' + ADDONname+ crlf)
                        LF.write('Version= ' + utils.ADDONgetAddonInfo('version')+ crlf)
                        LF.write('Version Info= ' + utils.version()+ crlf)
                        ### LF.write('Version Date= ' + utils.versiondate()+ crlf)
                        program  = repr(sys.argv[0])
                        LF.write('Program Name= ' + program+ crlf)
                        LF.write('Platform= ' + utils.ADDONgetSetting('platform')+ crlf)
                        LF.write('Running on= ' + utils.ADDONgetSetting('runningon')+ crlf)
                        LF.write('OS= ' + utils.ADDONgetSetting('os')+ crlf)
                        LF.write('Record Path= ' + utils.ADDONgetSetting('record_path')+ crlf + crlf)
                        LF.write('Record Command:' + crlf + cmd+ crlf + crlf)
                        log('426 errorZ Record Command: %r' % cmd)
                        log('426a errorZ after Record Command')
                        try:
                            log('427 errorZ title: %r' %  title)
                            LF.write('Title= ' + title + crlf)
                            log('428 errorZ title: %r' %  title)
                        except Exception as  e:
                            pass
                            log('445 errorZ Failed to write infofilename title: %r' % e)
                        LF.write('PlayChannel= ' + playchannel + crlf)
                        log('430 errorZ playchannel: %r' %  playchannel)
                        LF.write('cat= ' + cat + crlf)
                        log('432 errorZ cat: %r' %  cat)
                        LF.write('StartTime= ' + repr(startTime) + crlf)
                        log('434 errorZ startTime: %r' %  startTime)
                        LF.write('EndTime= ' + repr(endTime) + crlf)
                        log('436 errorZ endTime: %r' %  endTime)
                        try:
                            LF.write('Duration= ' + str(int(round(int(str(duration))//60))) + ' minutes' + crlf)  ### 2021-06-21
                        except Exception as  e:
                            pass
                            log('458 errorZ Failed to write infofilename duration: %r' % e)
                        log('438 errorZ int(round(int(duration)//60)): %r' %  int(round(int(duration)//60)))
                        ### LF.write('Argv6= ' + argv6 + crlf)
                        ### LF.write('Argv7= ' + argv7 + crlf)
                        try:
                            LF.write('NameAlarm= ' + nameAlarm + crlf)
                        except Exception as  e:
                            pass
                            log('458 errorZ Failed to write infofilename nameAlarm: %r' % e)
                        try:
                            if not len(description) == 3 and not description == 'n a':
                                LF.write('Description:' + crlf + recordings.argumenttostring(str(description)).replace('AAabBB',' ').replace('aAabBb','?').replace('BBabAA','=').replace('xXx',' ').replace('###',',').replace('AaAaA','=') + crlf)
                            else:
                                LF.write('No description!' + crlf)
                        except Exception as  e:
                            pass
                            log('474 errorZ Failed to write infofilename description: %r' % e)
                        # Close our file so no further writing is posible.
                        LF.close()
                        try:
                            os.chmod(infofilename, 0o776 )
                            log('errorZ Infofilename permission set to 0776')
                        except Exception as  e:
                            log('errorZ 401 Exception: %r' % e)
                            pass
                            log('errorZ Failed to set infofilename permission to 0776: ' + repr(e))
                        ###infofilename = infofilename.replace('.txt','.tit')
                        infofilename = infofilename[:-4]+'.tit'   ### 2022-11-05
                        log('errorZ 458 infofilename= %r' % infofilename)
                        LF = open(infofilename, 'w')
                        if '[' in OrgTitle:   ### Put duration first on second line, if not in line
                            if not orgduration in OrgTitle:
                                OrgTitle = OrgTitle.replace('[',orgduration +'[',1)
                            else:
                                OrgTitle = OrgTitle.replace(orgduration,'',1).replace('[',orgduration +'[',1)
                        LF.write(OrgTitle + ' #' + str(LoopCount))
                        LF.close()
                        os.chmod(infofilename, 0o776 )
                        ####infofilename = infofilename.replace('.tit','.nfo')
                        infofilename = infofilename[:-4]+'.nfo'   ### 2022-11-05
                        log('errorZ 460 infofilename= %r' % infofilename)
                        LF = open(infofilename, 'w')   ### 2017-08-09
                        # Write to our text file the information we have provided and then goto next line in our file.
                        LF.write('<?xml version="1.0" encoding="utf-8"?>' + crlf)
                        LF.write('<episodedetails>'+ crlf)
                        LF.write('    <title>' + title + '</title>' + crlf)
                        if not len(description) == 3 and not description == 'n a':
                            LF.write('    <plot>' + recordings.argumenttostring(description).replace('AAabBB',' ').replace('aAabBb','?').replace('BBabAA','=').replace('xXx',' ').replace('###',',').replace('AaAaA','=') + '</plot>' + crlf)
                        LF.write('</episodedetails>'+ crlf)
                        # Close our file so no further writing is posible.
                        LF.close()
                        try:
                            os.chmod(infofilename, 0o776 )
                            log('Infofilename permission set to 0776')
                        except Exception as  e:
                            log('errorZ 428 Exception: %r' % e)
                            pass
                            log('errorZ Failed to set infofilename permission to 0776: ' + repr(e))
                        log('infofilename= %s written and closed' % (repr(infofilename))) # Add to log
                    except Exception as e:
                        log('errorZ 432 Exception: %r' % e)
                        pass
                        log('errorZ 484 infofilename= %r FAILED to be written and closed ERROR: %r' % (infofilename, e)) # Add to log
                        utils.notificationbox('[COLOR red]Writing info file failed - check permision on [/COLOR]%s' % (repr(infofilename)))
                """
                else:
                    LoopNr = str(LoopCount)
                    if not RecordingDisabled:
                        utils.notification('Recording %s [COLOR orange]RESTARTED# %s %s[/COLOR]' % (title, LoopNr, nowHM))
                        recordings.updateRecordingPlanned(nameAlarm, '[COLOR orange]Restarted# %s %s[/COLOR] %s' % (LoopNr, nowHM, title))
                """
                if utils.ADDONgetSetting('os')=='11':
                        #print 'libpath= None os=11'
                        utils.runCommand(cmd, LoopCount, libpath=None)
                else:
                        libpath = utils.libPath()
                        log('libpath= %s' % repr(libpath))
                        #print 'libpath= %s' % libpath
                        utils.runCommand(cmd, LoopCount, libpath=libpath)

                ### nowP = recordings.parseDate(datetime.datetime.today())  2017-09-12
                nowP = datetime.datetime.now()
                endTimeO =  recordings.parseDate(endTime)
                time_tuple = endTimeO.timetuple()
                ###timestamp = time.mktime(time_tuple) - 60 * int(utils.ADDONgetSetting('TimeAfter')) + 60 * 5
                try:
                    TimeAfter = int(utils.ADDONgetSetting('TimeAfter'))
                except Exception as e:
                    log('err 510 Exception: %r' % e)
                    pass
                    TimeAfter = 0
                timestamp = time.mktime(time_tuple) - 60 - 60 * TimeAfter   ### 2020-02-05 - dont restart if less than one minute left
                log('record-ffmpeg endTime= %r, timestamp= %r, Dif= %r' % (time_tuple,time.mktime(time_tuple),- 60 * TimeAfter))
                endTimeM = datetime.datetime.fromtimestamp(timestamp)
                endTimeP =  recordings.parseDate(endTimeM)
                ###timestampQ = time.mktime(time_tuple) + 120 + 60 * int(utils.ADDONgetSetting('TimeAfter'))
                timestampQ = time.mktime(time_tuple) + 120
                
                endTimeMQ = datetime.datetime.fromtimestamp(timestampQ)
                endTimePQ = recordings.parseDate(endTimeMQ)
                log('record-ffmpeg end timing: Now= %r, EndTime= %r, EarlyTime= %r, LateTime= %r' % (nowP,endTimeO,endTimeP,endTimePQ))
                log('record-ffmpeg end timing: Now= %r, EndTime= %r, EarlyTime= %r, LateTime= %r' % (utils.HT(nowP),utils.HT(endTimeO),utils.HT(endTimeP),utils.HT(endTimePQ)))
                nowHM=datetime.datetime.today().strftime('%H:%M')
                if LoopCount > 0:
                    nowHM += ' loopcount= ' + str(LoopCount)
                log('0:\n%r\nendTimeP= %r >? nowP= %r' % (title,utils.HT(endTimeP),utils.HT(nowP)))
                log('0:\n%r\nnowP= %r >? endTimePQ= %r' % (title,utils.HT(nowP),utils.HT(endTimePQ)))
                if  endTimeP > nowP and not RecordingDisabled:
                    log('1: endTimeP= %r > nowP= %r' % (utils.HT(endTimeP),utils.HT(nowP)))
                    recordings.updateRecordingPlanned(nameAlarm, '[COLOR red]Completed Early ' + nowHM + '[/COLOR] ' + title )
                    startTime = nowP
                    Retry = True
                    log(':0 loopcount= %r title= %r startTime= %r' % (LoopCount, title, utils.HT(nowP)))
                    if LoopCount < (LoopCountMax - 1):
                        xbmc.sleep(10000* LoopCount)   #### longer pause after each error 2017-12-23
                        ###time.sleep(10 * LoopCount)   #### longer pause after each error 2017-01-21
                    log(':1 loopcount= %r title= %r startTime= %r' % (LoopCount, title, utils.HT(nowP)))
                    #time.sleep(10)
                    LoopCount += 1
                    LoopCountMax = int(utils.ADDONgetSetting('LoopCount'))
                elif    nowP > endTimePQ and not RecordingDisabled:
                    log('1:\n%r\nnowP= %r > endTimePQ= %r' % (title,utils.HT(nowP),utils.HT(endTimePQ)))
                    recordings.updateRecordingPlanned(nameAlarm, '[COLOR red]Completed Late ' + nowHM + '[/COLOR] ' + title)
                    startTime = nowP
                    Retry = False
                else:
                    log(':2\n%r\nnowP= %r NOT > endTimePQ= %r' % (title,utils.HT(nowP),utils.HT(endTimePQ)))
                    if not RecordingDisabled:
                        recordings.addAlarm(nameAlarm, 'cancelAlarm', '[COLOR green]Complete ' + nowHM + '[/COLOR] ' + title, '00:00:00', 'options')   ### 2022-08-14
                        recordings.updateRecordingPlanned(nameAlarm, '[COLOR green]Complete ' + nowHM + '[/COLOR] ' + title)
                    Retry = False

        if not RecordingDisabled:
            utils.notification('Recording %s [COLOR red]complete[/COLOR]' % title)
        if recorddrdirectly == '':  ###2018-09-03  != changed to ==
            log('recordUnLock(nameAlarm= %r )' % nameAlarm)
            locking.recordUnlock(nameAlarm)
        ###Recordings = utils.ADDONgetSetting('Recordings').replace(nameAlarm,'')
        locking.markUnlock(nameAlarm)
        ###utils.ADDONsetSetting('Recordings',Recordings)
        ###utils.notification('Recording finished: ' + title)
        log('Recording finished: ' + title)
        ###Recordings = utils.ADDONgetSetting('Recordings').replace(nameAlarm,'')
        ###utils.ADDONsetSetting('Recordings',Recordings)
        log('Recording finished: ' + title)
        log('Recording finished nameAlarm: ' + nameAlarm)
        """try:
            Recordings = utils.ADDONgetSetting('Recordings')
            if nameAlarm in Recordings:
                Recordings = Recordings.split(nameAlarm)[1]
                utils.ADDONsetSetting('Recordings',Recordings)    ### only save later recordings
                log('Removing in recordings second time: %r' % nameAlarm)
        except Exception as e:
            pass
            log('Error in removing in recordings: %r' % e)
            ###utils.ADDONsetSetting('Recordings','')  ### Clear recordings if possible
            log('Removing in recordings third time: %r' % nameAlarm)
        """
