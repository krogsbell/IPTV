#!/usr/bin/python
# -*- coding: utf-8 -*-

import urllib2    ### krogsbell 2019-05-21
import xmltodict  ### pip install xmltodict (Ubuntu first: sudo apt install python-pip)
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import os
import xbmcgui, xbmcplugin
import utils
import simplejson
import xbmcvfs,xbmcaddon
import channelsDR

CHANNELS_URL = 'https://www.dr.dk/mu-online/api/1.0/channel/all-active-dr-radio-channels'
PATH = sys.argv[1]
idtext = PATH.replace('plugin:','').replace('/','').replace('special:homeaddons','')
ADDON = xbmcaddon.Addon(id=idtext)
ADDONname = ADDON.getAddonInfo('name')
ADDONid   = ADDON.getAddonInfo('id')
ADDONpath = xbmc.translatePath('special://home/addons/%s/' % ADDONid)
LOGO_PATH = os.path.join(PATH, 'resources', 'logos')
ICON = os.path.join(PATH, 'icon.png')
FANART = os.path.join(PATH, 'fanart.jpg')

def __log(text):
    utils.logdev(sys.argv[0]+' '+sys.argv[2],text)

    
def TS(timestr):
    ### time format 2019-05-21T22:05:00Z
    time_tuple = time.strptime(timestr, "%Y-%m-%dT%H:%M:%SZ")
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
   
def nowTS():   ### UTC time
    dt_obj= datetime.utcnow()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def nowS(format):   ### Now date string UTC time
    time_tuple = time.localtime(nowTS())
    date_str = time.strftime(format, time_tuple)
    return(date_str)
    
def datestr(timestamp,format):   ### Now date string UTC time %Y-%m-%dT%H:%M:%SZ
    time_tuple = time.localtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)

def datestrdelta(timestamp,format):   ### Now date string UTC time %Y-%m-%dT%H:%M:%SZ
    time_tuple = time.gmtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)
    
def takeSecond(elem): 
    return elem[1]
    
def direct_play(url):
    __log("direct_play ["+url+"]")

    title = ""

    try:
        xlistitem = xbmcgui.ListItem( title, iconImage="DefaultAudio.png", path=url)
    except:
        xlistitem = xbmcgui.ListItem( title, iconImage="DefaultAudio.png", )
    xlistitem.setInfo( "audio", { "Title": title } )

    playlist = xbmc.PlayList( xbmc.PLAYLIST_MUSIC )
    player_type = xbmc.PLAYER_CORE_AUTO
    xbmcPlayer = xbmc.Player( player_type )
    xbmcPlayer.play(playlist) 
    
def StartProgram(station_id,timestamp):
    try:
        __log('ADDON %r - %r' % (ADDONname,ADDONid))
        __log('station_id= %r Start @ %r' % (station_id,datestr(timestamp,'%H:%M:%S')))
        if not station_id:
            station_id = preferredstation
            __log('playEPG(DEFAULT station_id= %r)' % station_id)
        script = os.path.join(ADDONpath, 'startstation.py')    
        ###script = os.path.join(PATH, 'startstation.py')
        __log('script= %r' % script)
        nameAlarm = ADDONid + '-start-' + str(station_id) 
        __log('nameAlarm= %r' % nameAlarm)
        delay = timestamp - nowTS()
        if delay < 0:
            delay = 0
        __log('delay= %r' % delay)
        delayHMS = datestrdelta(delay,'%H:%M:%S')
        __log('delayHMS= %r' % delayHMS)
        if delay >= 0 and delay < 24*3600:
            cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),%s,silent)' % (nameAlarm, script, PATH,station_id,delayHMS)
            __log('cmd= %s' % cmd)
            __log('LastStartStation:' + station_id + ': '+datestr(timestamp,'d%dh%Hm%Ms%S'))
            ###ADDON.setSetting('LastStartStation',station_id + ': '+datestr(timestamp,'d%dh%Hm%Ms%S'))
            ADDON.setSetting('StartStation',station_id)
            xbmc.executebuiltin(cmd)  # Active
    except Exception,e:
        pass
        __log('StartProgram(station_id= %r,timestamp= %r) ERROR: %r' % (station_id,timestamp,e))
   
def playEPG(idx):
    __log('playEPG(idx= %r)'% idx)
    try:
        u = urllib2.urlopen(CHANNELS_URL)
        channelList = simplejson.loads(u.read())
        u.close()
    except Exception, ex:
        showError(str(ex))
        return
    try:
        for channel in channelList:
            title = channel['Title']
            slug  = channel['Slug']
            if title[0:3] == 'DR ':
                title = title[3:]
            __log('playEPG(title= %r slug= %r)'% (title,slug))
            if idx.lower() == slug:
                sourceUrl = channel['SourceUrl']
                logoImage = os.path.join(LOGO_PATH, sourceUrl[sourceUrl.rindex('/') + 1:] + '.png')
                if xbmcvfs.exists(logoImage):
                    item = xbmcgui.ListItem(title, iconImage=logoImage)
                else:
                    item = xbmcgui.ListItem(title, iconImage=ICON)

                item.setProperty('IsPlayable', 'true')
                item.setProperty('Fanart_Image', FANART)
                item.setInfo(type='music', infoLabels={
                    'title': title
                })

                url = None

                if 'StreamingServers' in channel:
                    for server in channel['StreamingServers']:
                        if 'LinkType' in server and server['LinkType'] == 'ICY' and 'Qualities' in server:
                            try:
                                url = server['Server'] + '/' + server['Qualities'][0]['Streams'][0]['Stream']
                                break
                            except:
                                pass
                __log('playEPG(url= %r)'% url)
                if url:
                    __log('play-ing-EPG(url= %r)'% url)
                    logoImage = os.path.join(LOGO_PATH, title + '.png')
                    item = xbmcgui.ListItem(path=url, thumbnailImage=logoImage)
                    item.setInfo(type='music', infoLabels={
                        'title': title
                    })
                    xbmc.Player().play(url, item, True)
                    __log('play-ing-EPG-started(url= %r)'% url)
                break   ### Stop at first match
    except Exception,e:
        pass
        __log('PlayEPG ERROR: %r' % e)
    
try:
    program    = sys.argv[0]
    PATH       = sys.argv[1]
    station_id = sys.argv[2]
    ADDON.setSetting('LastFindStation',datestr(nowTS(),'%Y-%m-%dT%H:%M:%SZ'))
    
except Exception,e:
    pass
    title = 'StartStation'
    PATH = repr(e)
    station_id = 'P4KBH'
    
try:
    __log('sys.argv= %r' % sys.argv)
    __log('os.environ= %s' % os.environ['OS'] ) #put in LOG
    __log('PATH= %r' % PATH)
    __log('LOGO_PATH= %r' % LOGO_PATH)
    __log('ICON= %r' % ICON)
    __log('FANART= %r' % FANART)

except Exception,e:
    pass
    __log('ERROR data: %r' % e)
try:
    __log('code part')
    programswanted = ADDON.getSetting('programswanted').split(',')
    __log('programswanted= %r' % programswanted)
    programsnogo   = ADDON.getSetting('programsnogo').split(',')
    __log('programsnogo= %r' % programsnogo)
    preferredstation = ADDON.getSetting('preferredstation') ### DR P4 København
    __log('preferredstation= %r' % preferredstation)
    backupstation    = ADDON.getSetting('backupstation') ### DR P5
    __log('backupstation= %r' % backupstation)
    
    try:
        items = []
        WantedPrograms = []
        NogoPrograms   = []
        for radioEPGi in channelsDR.CHANNELS:
            station_id = radioEPGi.name
            radioEPG  = radioEPGi.epg
            __log('station_id= %r ' % station_id)
            file = urllib2.urlopen(radioEPG)
            dataepg = file.read()
            file.close() 
            datadict = xmltodict.parse(dataepg)
            name = datadict['m_sch:message']['schedule']['channel']['name']
            type = datadict['m_sch:message']['schedule']['channel']['type']
            datadict1 = datadict['m_sch:message']['schedule']['programs']
            
            stationname = datadict['m_sch:message']['schedule']['channel']['name']
            
            i = 0
            for program in datadict1['program']:
                stop = program['pro_publish']['ppu_stop_timestamp_presentation_utc']
                start = program['pro_publish']['ppu_start_timestamp_announced_utc']
                startactual = program['pro_publish']['ppu_start_timestamp_presentation_utc']
                if TS(stop) > nowTS():
                    title = program['pro_publish']['ppu_title']  
                    punchline= program['pro_publish']['ppu_punchline']
                    if punchline:
                        title += ' - ' + punchline
                    description= program['pro_publish']['ppu_description']
                    channel= program['pro_publish']['ppu_channel']
                    for wanted in programswanted:
                        if wanted.lower() in title.lower():
                            WantedPrograms.append([station_id,startactual,stop,title,description,channel])
                    for notwanted in programsnogo:
                        if notwanted.lower() in title.lower():
                            NogoPrograms.append([station_id,startactual,stop,title,description,channel])
    except Exception,e:
        pass
        __log('radioEPG ERROR: %r' % e)
    
    Programs = []
    if WantedPrograms != []:
        __log('WantedPrograms= %r' % WantedPrograms)
        for prog in WantedPrograms:
            Programs.append(prog)
    if NogoPrograms != []:
        __log('NogoPrograms= %r' % NogoPrograms)
        for prog in NogoPrograms:
            if prog[0] == preferredstation:
                Programs.append((backupstation,prog[1],prog[2],prog[3],prog[4],prog[5]))
    __log('Programs= %r' % Programs)
    Programs = sorted(Programs, key=takeSecond)
    __log('Programs Sorted= %r' % Programs)
    ProgramPlaying = ADDON.getSetting('ProgramPlaying')
    __log('ProgramPlaying= %r' % ProgramPlaying)
    player = xbmc.Player()
    if not player.isPlaying():
        __log('Player is not playing')
        if ProgramPlaying == '':
            ProgramPlaying = preferredstation
        ADDON.setSetting('ProgramPlaying',ProgramPlaying)
        StartProgram(ProgramPlaying,nowTS())
    if Programs != []:
        try:
            if Programs[0][0] != ProgramPlaying:
                ProgramPlaying = Programs[0][0]
                StartProgram(preferredstation,TS(Programs[0][2]))
                ADDON.setSetting('LastEndStation',preferredstation+ ': '+Programs[0][3]+ ' at ' +datestr(TS(Programs[0][2]),'d%dh%Hm%Ms%S'))
                StartProgram(Programs[0][0],TS(Programs[0][1]))
                ADDON.setSetting('LastStartStation',Programs[0][0] + ': '+Programs[0][3]+ ' at ' +datestr(TS(Programs[0][1]),'d%dh%Hm%Ms%S'))
                
        except Exception,e:
            pass
            __log('Programs[0][0] ERROR: %r' % e)
            __log('No Program Change possible')
    else:
        __log('No Program Change needed')

except Exception,e:
    pass
    __log('ERROR: %r' % e)