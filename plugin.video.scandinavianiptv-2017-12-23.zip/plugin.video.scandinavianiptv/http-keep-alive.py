#!/usr/bin/python
# -*- coding: utf-8 -*-

import definition
import utils
import xbmc
import urllib2
import sys

ADDON     = definition.getADDON()
ADDONid   = ADDON.getAddonInfo('id')
ADDONname = ADDON.getAddonInfo('name')
datapath  = xbmc.translatePath(ADDON.getAddonInfo('profile'))
progpath  = ADDON.getAddonInfo('path')
module    = sys.argv[0]
###utils.notification('Http Keep Alive Started')
### SmartDNS Proxy servers: 46.166.189.68, 54.93.173.153, 81.17.17.188
### SmartDNS Proxy activation command: https://www.smartdnsproxy.com/api/IP/update/XXXXXXXXXXXXXXX (XXX.. Your direct link)

link = ADDON.getSetting('http-keep-alive')
user = ADDON.getSetting('user')
if user == 'krogsbell2015@gmail.com' and len(link) == 0:
	link = 'https://www.smartdnsproxy.com/api/IP/update/2be9908cbe2f446'
	ADDON.setSetting('http-keep-alive',link)
	utils.logdev(module,'Default link set up!')
		
data = 'Request not executed! - Less then 5 characters'

try:
	if len(link) > 5:
		file = urllib2.urlopen(link)
		deflink = 'https://www.smartdnsproxy.com/api/IP/update/'
		if deflink in link:
			link = deflink + '...'  ### Don't log full link
		data = file.read()
		file.close()
		utils.logdev(module,'Request: %r,\n Result: %r' % (link,data))
except Exception, e:
	pass
	utils.logdev(module, 'Error in http-keep-alive= %r ERROR= %r' % (link,e))

###utils.logdev(module,'Ended')

