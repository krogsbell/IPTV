import xbmc
import utils

class Log:

    @staticmethod
    def log(entry):
        utils.logdev('Original UnLim.tv APP',entry)
        ###xbmc.log(entry, xbmc.LOGNOTICE)
