from app import App

app = App()
app.run()


