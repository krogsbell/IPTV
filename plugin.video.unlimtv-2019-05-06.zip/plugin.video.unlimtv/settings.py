
class Settings:

    addon = None

    STREAM_TYPE = 'streamtype'
    EMAIL = 'email'
    PASSWORD = 'password'
    ENABLE_RECORD = 'enable_record'
    TVGUIDE = 'tvguide'

    def __init__(self, _addon):
        self.addon = _addon
        return


    def get(self, key):
        try:
            return self.addon.getSetting(key)
        except:
            return '';

    def set(self, key, value):
        self.addon.setSetting(key, value)

