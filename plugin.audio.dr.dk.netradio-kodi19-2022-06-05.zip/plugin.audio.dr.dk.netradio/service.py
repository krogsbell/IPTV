#!/usr/bin/python
# -*- coding: utf-8 -*-
import utils
import xbmcaddon, xbmc, xbmcvfs
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import _strptime
import os
import shutil

ADDON     = xbmcaddon.Addon()
ADDONname = ADDON.getAddonInfo('name')
ADDONid   = ADDON.getAddonInfo('id')
PATH      = 'special://home/addons/%s/' % ADDONid
ADDONpath = xbmcvfs.translatePath(PATH)
datapath  = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
module= 'service.py'
xbmc.log('%s in %s' % (module,ADDONname))  ###, level=xbmc.LOGNOTICE)
if ADDON.getSetting('noepg') == 'true':
    noepg = True
else:
    noepg = False

def __log(text):
    utils.logdev(module,text)

__log('Start')
__log('service.py in %s' % ADDONname)

utils.logdevreset()

ADDON.setSetting('LastFindStation','')
ADDON.setSetting('programplaying','')

settings    = os.path.join(datapath,'settings.xml')   ### 2020-11-24
settingsOLD = os.path.join(datapath,'settingsOLD.xml')
try:
    size = os.path.getsize(settings)
    ###maxsize = 10 * 1024 * 1024 # 10 MB
    if size == 0:
        shutil.copyfile(settingsOLD, settings)
    elif os.path.exists(settings) and size > 0:
        shutil.copyfile(settings, settingsOLD)
except Exception as e:
    pass
    xbmc.log('%r: Reset settings.xml failed: %r' % (ADDONname,e))


__log('Ended')

def TS(timestr):
    ### time format 2019-05-21T22:05:00Z
    time_tuple = time.strptime(timestr, "%Y-%m-%dT%H:%M:%S%z")
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
   
def nowTS():   ### UTC time
    dt_obj= datetime.utcnow()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def nowS(format):   ### Now date string UTC time
    time_tuple = time.localtime(nowTS())
    date_str = time.strftime(format, time_tuple)
    return(date_str)
    
def datestr(timestamp,format):   ### Now date string UTC time %Y-%m-%dT%H:%M:%SZ
    time_tuple = time.localtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)

def findprograms(delayHMS):
    """
    findP = ADDON.getSetting('LastFindStation')  ### datestr(nowTS(),'h%Hm%Ms%S'))
    if findP == '':
        delta = 800
    else:
        delta = nowTS() - TS(findP)
    __log('delta= %r' % delta)
    if delta > 700:
    """
    __log('Start findprograms:'+datestr(nowTS(),'d%dh%Hm%Ms%S'))
    ###ADDON.setSetting('findprograms','Start findprograms:'+datestr(nowTS(),'d%dh%Hm%Ms%S'))
    
    script = os.path.join(ADDONpath, 'findstation.py')
    __log('script= %r' % script)
    nameAlarm = ADDONid + '-findstations-'+delayHMS.replace(':','')
    __log('nameAlarm= %r' % nameAlarm)
    ###delayHMS = '00:10:00'   ### Run every 10 minutes
    ###delayHMS = '00:00:00'   ### Run once
    __log('delayHMS= %r' % delayHMS)
    ###cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),%s,loop,silent)' % (nameAlarm, script, PATH,delayHMS,delayHMS)
    if delayHMS == '00:00:00':
        cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),%s,silent)' % (nameAlarm, script, PATH,delayHMS,delayHMS)
    else:
        cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),%s,loop,silent)' % (nameAlarm, script, PATH,delayHMS,delayHMS)
    __log('cmd= %s' % cmd)
    xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
    xbmc.executebuiltin(cmd)  # Activate
        
if ADDON.getSetting('autorun').lower() == 'true':
    ADDON.setSetting('programplaying','')
    ADDON.setSetting('ProgramPlayingScheduled','')
    findprograms('00:00:00')
    if noepg:
        timebetweenupdates = ADDON.getSetting('timebetweenupdates')
        findprograms(timebetweenupdates)    ### Previous with EPG 00:10:00 now with schedule 00:01:00
    else:
        timebetweenupdates = '00:10:00'
    __log('timebetweenupdates= %s' % timebetweenupdates)
    findprograms(timebetweenupdates)    ### Previous with EPG 00:10:00 now with schedule 00:00:10
