#!/usr/bin/python
# -*- coding: utf-8 -*-
import utils
import definition

ADDON      = definition.getADDON()
ADDONname  = ADDON.getAddonInfo('name')
ADDONid    = ADDON.getAddonInfo('id')
module = 'runcmd.py'
utils.logdev(module,'sys.argv= %s' %(str(repr(sys.argv))))
program  = sys.argv[0]
cmd      = sys.argv[1]

def log(infotext):
    if 'err' in infotext.lower():
        utils.logdev('err',module + ': ' + infotext)
    else:
        utils.logdev(module,infotext)  ### log all if module selected

log('err cmd= %r' % cmd)  #put in LOG
try: 
    #print os.environ
    log('err os.environ= ' + os.environ['OS'])  #put in LOG
except: pass

try: 
    LoopCount = 0
    LibPath = utils.libPath()
    log('err utils.runCommand(\n cmd= %r,\n LoopCount= %r,\n LibPath= %r)' % (cmd, LoopCount, LibPath))
    subpr = utils.runCommand(cmd, LoopCount, LibPath)
    log('err subpr of runCommand= %r' % subpr)
except Exception as e:
    pass
    log('err cmd=  %r\nFAILED: %r' % (cmd,e))

