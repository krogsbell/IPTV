#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#      Copyright (C) 2014 Tommy Winther
#      http://tommy.winther.nu
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt. If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
"""
Import as a dependency in addon.xml
<import addon="script.module.infotagger" version="0.0.1" />

Then when you make your ListItem
python:
from infotagger.listitem import ListItemInfoTag

# Make your listitem as normal
li = xbmcgui.ListItem()

# Pass listitem to the infotagger module and specify tag type
info_tag = ListItemInfoTag(li, 'video')

# li.setInfo(infolabels)
info_tag.set_info(infolabels)

# li.setUniqueIDs(unique_ids)
info_tag.set_unique_ids(unique_ids)

# li.setCast(cast)
info_tag.set_cast(cast)

# li.addStreamInfo('video', videostream_values)
info_tag.add_stream_info('video', videostream_values)
"""
import os
import sys
import json as simplejson
###import urllib
import urllib.parse as urlparse
try:
    # For Python 3.0 and later
    from urllib.request import urlopen
except ImportError:
    # Fall back to Python 2's urllib2
    from urllib2 import urlopen
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import channels
import channelsDR   ### 2019-05-28
###import buggalo
import utils
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import _strptime
import xmltodict
import base64
import re

from infotagger.listitem import ListItemInfoTag

INFO_TAG = True     ### 2023-11-25 don't use info_tag

count = 0
count += 1
utils.ADDONsetSetting('count','addon.py Line# %r, %r' % (82,count))

ADDON     = xbmcaddon.Addon('plugin.audio.dr.dk.netradio')
###import urlquick

CHANNELS_URL = 'https://www.dr.dk/mu-online/api/1.4/channel/all-active-dr-radio-channels'
### CHANNELS_URL_EPG = 'https://www.dr.dk/Tjenester/epglive/epg.radio.%s.drxml' ###2021-03 - stopped working
###CHANNELS_URL_EPG = 'https://www.dr.dk/mu-online-radio/api/1.0/spots/schedule/all/2021-03-24?group=false'
###CHANNELS_URL_EPG = 'https://www.dr.dk/lyd/p4kbh'
### Link to EPG List: https://www.dr.dk/Tjenester/epglive/

###ADDON     = xbmcaddon.Addon('plugin.audio.dr.dk.netradio')
ADDONname = ADDON.getAddonInfo('name')
ADDONid   = ADDON.getAddonInfo('id')
ADDONpath = xbmcvfs.translatePath('special://home/addons/%s/' % ADDONid)
datapath  = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
ProgramPlaying = utils.ADDONgetSetting('programplaying')
programswanted = utils.ADDONgetSetting('programswanted').split(',')
programsnogo   = utils.ADDONgetSetting('programsnogo').split(',')
preferredstation = utils.ADDONgetSetting('preferredstation') ### P4 København
backupstation    = utils.ADDONgetSetting('backupstation') ### P5
backupbackupstation    = utils.ADDONgetSetting('backupbackupstation') ### P6 Beat
module = 'addon.py'
if utils.ADDONgetSetting('useepg') == 'true':
    useepg = True
else:
    useepg = False

DaysOfWeek = [ADDON.getLocalizedString(30510),ADDON.getLocalizedString(30511),ADDON.getLocalizedString(30512),ADDON.getLocalizedString(30513),ADDON.getLocalizedString(30514),ADDON.getLocalizedString(30515),ADDON.getLocalizedString(30516)]

###count += 1
###utils.ADDONsetSetting('count','addon.py Line# %r, %r' % (113,count))

def __log(text):
    utils.logdev(module,' '.join(text.split())[0:200])  ### Remove doublespaces etc
    
def TSl(timestr):
    ### time format 2019-05-21T22:05:00Z to date string i local
    ### 2022-06-04T03:00:00+00:00
    time_tuple = time.strptime(timestr, "%Y-%m-%dT%H:%M:%S%z")
    timestamp = time.mktime(time_tuple)
    TO = datetime.fromtimestamp(timestamp)
    TOTS = int(time.mktime(TO.timetuple()))
    utcTO = datetime.utcfromtimestamp(timestamp)
    utcTOTS = int(time.mktime(utcTO.timetuple()))
    timeoffset = TOTS-utcTOTS
    ###__log('timeoffset= %r' % timeoffset)
    return(timestamp+timeoffset) 
    
def TS(timestr):
    ### time format 2019-05-21T22:05:00Z
    ### 2022-06-04T03:00:00+00:00
    time_tuple = time.strptime(timestr, "%Y-%m-%dT%H:%M:%S%z")
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def now():   ### Local time
    dt_obj= datetime.now()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def ison(start,end,pendTS):   ### Local time
    if start == '' or end == '' or pendTS == '':
        return False
    start = int(start)-100
    end   = int(end)+100
    dt_obj= datetime.now()
    time_tuple = dt_obj.timetuple()
    now   = time_tuple[2]*10000 + time_tuple[3]*100 + time_tuple[4]
    pend  = int(datestr(pendTS,'%d%H%M'))
    __log('ison(start= %r, end= %r, time_tuple= %r)' %(start,end,now))
    __log('ison(pendTS= %r, pend= %r)' %(pendTS,pend))
    ###ison(start= '14m03', end= '16m04', time_tuple= time.struct_time(tm_year=2019, tm_mon=11, tm_mday=29, tm_hour=13, tm_min=58, tm_sec=18, tm_wday=4, tm_yday=333, tm_isdst=-1))
    if start <= now and now <= end and start <= pend and pend <= end:
        return True
    else:
        return False
   
def nowTS():   ### UTC time
    dt_obj= datetime.utcnow()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def nowS(format):   ### Now date string Local time
    time_tuple = time.localtime(nowTS())
    date_str = time.strftime(format, time_tuple)
    return(date_str)
    
def datestr(timestamp,format):   ### Date string UTC time %Y-%m-%dT%H:%M:%S%z
    time_tuple = time.localtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)

def datestrdelta(timestamp,format):   ### Now date string UTC time %Y-%m-%dT%H:%M:%S%z
    time_tuple = time.gmtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)

def highlight_many(text, keyword, fmark, emark):
    replacement = lambda match: fmark + match.group() + emark
    text = re.sub(re.escape(keyword), replacement, text, flags=re.I)
    return text
 
def highlight_many_multible_keywords(text, keywords, fmark, emark):
    replacement = lambda match: fmark + match.group() + emark
    text = re.sub("|".join(map(re.escape, keywords)), replacement, text, flags=re.I)  ### With many keywords or letters in keyword
    return text
 
def highlight(text,keyword,searchhighlightcolor = utils.ADDONgetSetting('searchhighlightcolor')):
    if keyword == '':
        return text
    keywords = keyword.split('%')
    keywords1 = []
    for keyw in keywords:
        if keyw != '':
           keywords1.append(keyw) 
    if len(keywords1) > 1:
        return highlight_many_multible_keywords(text, keywords, '[COLOR ' + searchhighlightcolor + ']', '[/COLOR]')
    elif len(keywords1) == 1:
        return highlight_many(text, keywords1[0], '[COLOR ' + searchhighlightcolor + ']', '[/COLOR]')
    elif len(keyword) > 0:
        return highlight_many(text, keyword, '[COLOR ' + searchhighlightcolor + ']', '[/COLOR]')
    else:
        return text

def takeSecond(elem): 
    return elem[1]

def testHTTP(url):  
    try:
        return True
        import socket
        if url[:4].lower() != 'http':
            __log('testHTTP(%r)=\n%r' % (url,'Play non http or https!'))
            return True
        # timeout in seconds
        timeout = 10
        socket.setdefaulttimeout(timeout)

        # this call to urlopen now uses the default timeout
        # we have set in the socket module
        req = urlparse.Request(url)
        response = urlopen(req)
        __log('testHTTP(%r)=\n%r' % (url,response))
        return response
    except Exception as e:
        pass
        __log('testHTTP(%r)\nERROR: %r' % (url,e))
        return False
   
def direct_play(url):
    __log("direct_play ["+url+"]")

    title = ""

    try:
        xlistitem = xbmcgui.ListItem( title, path=url)
        ###xlistitem.setArt({ 'icon': "DefaultAudio.png", 'thumb' : "DefaultAudio.png" })
    except:
        xlistitem = xbmcgui.ListItem( title)
        ###xlistitem.setArt({ 'icon': "DefaultAudio.png", 'thumb' : "DefaultAudio.png" })
    ###xlistitem.setInfo( "Music", { 'title': title } )
    # Pass listitem to the infotagger module and specify tag type
    if INFO_TAG:
        info_tag = ListItemInfoTag(xlistitem, 'music')
        infolabels = { 'title': title }
        # li.setInfo(infolabels)
        info_tag.set_info(infolabels)
        __log('217 infolabels= %r' % infolabels)
    playlist = xbmc.PlayList( xbmc.PLAYLIST_MUSIC )
    player_type = xbmc.PLAYER_CORE_AUTO
    xbmcPlayer = xbmc.Player( player_type )
    __log('259 xbmcPlayer.play playlist= %r' % playlist)
    xbmcPlayer.play(playlist) 
    station_id = channels.CHANNELS[0].name
    utils.setChannelVolumen(station_id, at='direct_play')

def StopAllStationAlarms():
    __log('StopAllStationAlarms()')
    try:
        for chan in channels.CHANNELS:
            station_id = chan.name
            nameAlarm = ADDONid + '-start-' + str(station_id)
            xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
        for radioEPGi in channelsDR.CHANNELS:
            station_id = radioEPGi.name
            stationurl = radioEPGi.url
            nameAlarm = ADDONid + '-start-' + str(station_id)
            xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
    except Exception as e:
        pass
        __log('StopAllStationAlarms() ERROR: %r' % e)
    
def StartProgram(station_id,timestamp):
    try:
        __log('ADDON %r - %r' % (ADDONname,ADDONid))
        __log('station_id= %r Start @ %r' % (station_id,datestr(timestamp,'%H:%M:%S')))
        if not station_id:
            station_id = preferredstation
            __log('playEPG(DEFAULT station_id= %r)' % station_id)
            
        script = os.path.join(ADDONpath, 'startstation.py')
        __log('script= %r' % script)
        ###nameAlarm = ADDONid + '-start-' + str(station_id) + '-' + datestr(timestamp,'d%dh%Hm%Ms%S')
        nameAlarm = ADDONid + '-start-' + str(station_id)
        __log('nameAlarm= %r' % nameAlarm)
        delay = timestamp - nowTS()
        __log('delay= %r' % delay)
        delayHMS = datestrdelta(delay,'%H:%M:%S')
        __log('delayHMS= %r' % delayHMS)
        if delay >= 0 and delay < 24*3600:
            cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),%s,silent)' % (nameAlarm, script, PATH,station_id,delayHMS)
            __log('cmd= %s' % cmd)
            __log('LastStartStation:' + station_id + ': '+datestr(timestamp,'d%dh%Hm%Ms%S'))
            utils.ADDONsetSetting('LastStartStation',station_id + ': '+datestr(timestamp,'d%dh%Hm%Ms%S'))
            utils.ADDONsetSetting('StartStation',station_id)
            xbmc.executebuiltin(cmd)  # Active
    except Exception as e:
        pass
        __log('StartProgram(station_id= %r,timestamp= %r) ERROR: %r' % (station_id,timestamp,e))
   
def EndProgram(station_id,timestamp):
    __log('ADDON %r - %r' % (ADDONname,ADDONid))
    __log('station_id= %r Start @ %r' % (station_id,datestr(timestamp,'%H:%M:%S')))
    __log('do not run this')
    """
    ###ADDONpath =  = xbmcvfs.translatePath('special://home/addons/%s/' % ADDONid)
    script = os.path.join(ADDONpath, 'startstation.py')
    __log('script= %r' % script)
    nameAlarm = ADDONid + '-startstation-' + str(timestamp)
    #delay = timestamp - now.....
    cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),00:00:00,silent)' % (nameAlarm, script, station_id, str(timestamp))
    __log('cmd= %s' % cmd)
    utils.ADDONsetSetting('StopStation',station_id)
    xbmc.executebuiltin(cmd)  # Active
    """
    #return
    
def TwoLines(name):  ### Use in menus to allow autoscroll and see all text on both lines
    name = name.replace('  ',' ').split('\n')
    line1 = name[0]
    lenline1 = len(line1)
    line2 = ''
    for i in range(1, len(name)):
        line2 += name[i] + ' '
    lenline2 = len(line2)
    if lenline1 < lenline2:
        line1 = line1 + '  ' * (lenline2 - lenline1)
    name = line1 +'\n' + line2
    return name
    
def menuappend(menu, ThisMenu):
    if krogsbellswitchavailable():
        menutext = ADDON.getLocalizedString(30405)   ### Switch Krogsbell Addons
        menu.append(('[COLOR blue][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?switch=other)'% (sys.argv[0]))) 
    ###showOverview,show=dr
    menu.append(('[COLOR blue][B]%s[/B][/COLOR]'% ADDON.getLocalizedString(30100),'RunPlugin(%s?show=dr)'% (sys.argv[0]))) 
    
    menu.append(('[COLOR blue][B]%s[/B][/COLOR]'% ADDON.getLocalizedString(30102),'RunPlugin(%s?show=epga&HANDLE=%s)'% (sys.argv[0],HANDLE))) 
    """
    if 'show' in PARAMS and PARAMS['show'][0] == 'dr':
        showDRChannels()
    elif 'show' in PARAMS and PARAMS['show'][0] == 'other':
        showOtherChannels()
    elif 'show' in PARAMS and PARAMS['show'][0] == 'epg':
        showEPG()
    elif 'show' in PARAMS and PARAMS['show'][0] == 'epga':
        showEPGa()
    elif 'show' in PARAMS and PARAMS['show'][0] == 'epgm':
        showEPGm()
    elif 'show' in PARAMS and PARAMS['show'][0] == 'drx':
        showDRxChannels()
    elif 'playEPG' in PARAMS:
        __log('playEPG= %r' % PARAMS['playEPG'][0])
        playEPG(PARAMS['playEPG'][0])
    elif 'playDR' in PARAMS:
        __log('playDR= %r' % PARAMS['playDR'][0])
        playDR(PARAMS['playDR'][0])
    elif 'playOther' in PARAMS:
        __log('playOther= %r' % PARAMS['playOther'][0])
        playOther(PARAMS['playOther'][0])
    elif 'setP4' in PARAMS:
        __log('setP4= %r' % PARAMS['setP4'][0])
        setP4Channel(PARAMS['setP4'][0])
    elif 'setPref' in PARAMS:
        __log('setPref= %r' % PARAMS['setPref'][0])
        setPref(PARAMS['setPref'][0])
    elif 'setBckup' in PARAMS:
        __log('setBckup= %r' % PARAMS['setBckup'][0])
        setBckup(PARAMS['setBckup'][0])
    elif 'setWanted' in PARAMS:
        __log('setWanted= %r' % PARAMS['setWanted'][0])
        setWanted(PARAMS['setWanted'][0])
    elif 'setNogop' in PARAMS:
        __log('setNogop= %r' % PARAMS['setNogop'][0])
        setNogop(PARAMS['setNogop'][0])
    elif 'switch' in PARAMS:
        __log('switch= %r' % PARAMS['switch'][0])
        switch(PARAMS['switch'][0])
    elif 'resetSet' in PARAMS:
        __log('resetSet= %r' % PARAMS['resetSet'][0])
    """

def showOverview():
    item = xbmcgui.ListItem(ADDON.getLocalizedString(30100))
    item.setArt({ 'icon': ICON, 'thumb' : ICON })
    item.setProperty('Fanart_Image', FANART)
    xbmcplugin.addDirectoryItem(HANDLE, PATH + '?show=dr', item, True)
    
    if useepg:
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30102))
        item.setArt({ 'icon': ICON, 'thumb' : ICON })
        item.setProperty('Fanart_Image', FANART)
        xbmcplugin.addDirectoryItem(HANDLE, PATH + '?show=epg', item, True)
    
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30104))
        item.setArt({ 'icon': ICON, 'thumb' : ICON })
        item.setProperty('Fanart_Image', FANART)
        xbmcplugin.addDirectoryItem(HANDLE, PATH + '?show=epga', item, True)
        
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30103))
        item.setArt({ 'icon': ICON, 'thumb' : ICON })
        item.setProperty('Fanart_Image', FANART)
        xbmcplugin.addDirectoryItem(HANDLE, PATH + '?show=epgm', item, True)                    

    if 1 == 0:  ### Disable:  Other Stations
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30101))
        item.setArt({ 'icon': ICON, 'thumb' : ICON })
        item.setProperty('Fanart_Image', FANART)
        xbmcplugin.addDirectoryItem(HANDLE, PATH + '?show=other', item, True)
    
    if 1 == 0:  ### Disable: Stop all and Update Next Program Now
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30406))
        item.setArt({ 'icon': ICON, 'thumb' : ICON })
        item.setProperty('Fanart_Image', FANART)
        xbmcplugin.addDirectoryItem(HANDLE, PATH + '?find=other', item, True)

    item = xbmcgui.ListItem(ADDON.getLocalizedString(30405))
    item.setArt({ 'icon': ICON, 'thumb' : ICON })
    item.setProperty('Fanart_Image', FANART)
    if krogsbellswitchavailable():
        xbmcplugin.addDirectoryItem(HANDLE, PATH + '?switch=other', item, True)
    
    """
    item = xbmcgui.ListItem('Test Start P6Beat', iconImage=ICON)
    item.setArt({ 'icon': logoImage, 'thumb' : logoImage })
    item.setProperty('Fanart_Image', FANART)
    xbmcplugin.addDirectoryItem(HANDLE, PATH + '?start=P6Beat', item, True)
    """
    
    xbmcplugin.endOfDirectory(HANDLE)

def getDRChannels():
    Channels = []
    for channel in channelsDR.CHANNELS:
        Channels.append(channel.name)
    return sorted(Channels, key=str.casefold)

def showDRChannels():
    ADDON.setSetting('autorun','false')
    utils.krogsbellNOTWatchingVideo()
    for channel in channelsDR.CHANNELS:
        __log('356 showDRChannels(channel= %r)'% channel)
        ### (id, name, epg, icon, url)
        logoImageP = xbmcvfs.translatePath(os.path.join(LOGO_PATH, str(channel.icon) + '.png'))
        """
        sourceUrl = channel.SourceUrl
        logoImage = xbmcvfs.translatePath(os.path.join(LOGO_PATH, sourceUrl[sourceUrl.rindex('/') + 1:] + '.png'))
        __log('4 logoImage= %r'% logoImage)
        if xbmcvfs.exists(logoImage):
            ###__log('logoImage EXISTS %r'% logoImage)
            item = xbmcgui.ListItem(title)
            item.setArt({ 'icon': logoImage, 'thumb' : logoImage })
        else:
            ###__log('logoImage DO NOT EXISTS %r'% logoImage)
        """
        item = xbmcgui.ListItem(channel.name)
        
        item.setArt({ 'icon': logoImageP, 'thumb' : logoImageP })
        menu=[]
        menuappend(menu,'showDRChannels')
        
        item.addContextMenuItems(items=menu, replaceItems=True)
        item.setProperty('IsPlayable', 'true')
        item.setProperty('Fanart_Image', FANART)
        if INFO_TAG:
            info_tag = ListItemInfoTag(item, 'music')
            infolabels = { 'title': channel.name }
            info_tag.set_info(infolabels)
            __log('432 infolabels= %r' % infolabels)
        """
        item.setInfo(type='music', infoLabels={
                    'title': channel.name,
                    'tracknumber': 12345679,
                    'discnumber': 13,
                    'duration': 245999,
                    'year': 1999,
                    ###'genre': 'genre',
                    'album': 'Pulse1',
                    'artist': 'Cat',
                    'rating': int(utils.ADDONgetSetting('setvolumen'))/10
                })
        """
        if channel.url:
            __log('379 channel.name= %r, channel.url= %r' % (channel.name, channel.url))
            xbmcplugin.addDirectoryItem(HANDLE, channel.url, listitem = item)

    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.endOfDirectory(HANDLE)

def getOtherChannels():
    Channels = []
    for channel in channels.CHANNELS:
        Channels.append(str(channel.name))
    return sorted(Channels, key=str.casefold)
   
def showOtherChannels():
    for channel in channels.CHANNELS:
        logoImage = xbmcvfs.translatePath(os.path.join(LOGO_PATH, str(channel.id) + '.png'))
        __log('3 logoImage= %r'% logoImage)
        if xbmcvfs.exists(logoImage):
            ###__log('logoImage EXISTS %r'% logoImage)
            item = xbmcgui.ListItem(channel.name)
            item.setArt({ 'icon': logoImage, 'thumb' : logoImage })
            limage = logoImage
        else:
            ###__log('logoImage DO NOT EXISTS %r'% logoImage)
            item = xbmcgui.ListItem(channel.name)
            item.setArt({ 'icon': ICON, 'thumb' : ICON })
            limage = ICON
        menu=[]
        if krogsbellswitchavailable():
            menutext = ADDON.getLocalizedString(30405)   ### Switch Krogsbell Addons
            menu.append(('[COLOR blue][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?switch=other)'% (sys.argv[0]))) 
        item.addContextMenuItems(items=menu, replaceItems=True)
        item.setProperty('IsPlayable', 'true')
        item.setProperty('Fanart_Image', FANART)
        if INFO_TAG:
            info_tag = ListItemInfoTag(item, 'music')
            infolabels = { 'title': channel.name}
            info_tag.set_info(infolabels)
            __log('481 infolabels= %r' % infolabels)
        """
        item.setInfo(type='music', infoLabels={
            'title': channel.name,
            ###'genre': 'genre395',
            'rating': int(utils.ADDONgetSetting('setvolumen'))/10
        })
        """
        xbmcplugin.addDirectoryItem(HANDLE, PATH + '?playOther=%s' % channel.id, listitem = item)

    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(HANDLE)

def showEPGm():   ### Select Prefered e.t.c.
    ###count += 1
    ADDON.setSetting('autorun','true')
    utils.krogsbellNOTWatchingVideo()
    utils.ADDONsetSetting('count','addon.py Line# %r, %r' % (505,'showEPGm()'))
    __log('showEPGm START')
    utils.TestInfoTag('showEPGm')
    default_list_item = 0
    show_list_item = 0
    PlayingFound = False
    preferredstation = utils.ADDONgetSetting('preferredstation') ### P4 København
    backupstation    = utils.ADDONgetSetting('backupstation') ### P5
    backupbackupstation    = utils.ADDONgetSetting('backupbackupstation') ### P6 Beat
    P4selected       = utils.ADDONgetSetting('selectedp4station')
    P5selected       = utils.ADDONgetSetting('selectedp5station')
    
    try:
        for radioEPGi in channelsDR.CHANNELS:
            ###count += 1
            ###utils.ADDONsetSetting('count','addon.py Line# %r, %r' % (520,count))
            menu=[]
            menuappend(menu,'showEPGm')
            station_id = radioEPGi.name
            stationurl = radioEPGi.url
            menutext = ADDON.getLocalizedString(30401) ### Preferred Station
            menu.append(('[COLOR lightgreen][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?setPref=%s)'% (sys.argv[0],radioEPGi.name)))   
            menutext = ADDON.getLocalizedString(30402)   ### Backup Station
            menu.append(('[COLOR yellow][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?setBckup=%s)'% (sys.argv[0],radioEPGi.name)))  
            menutext = ADDON.getLocalizedString(30437)   ### Backup Backup Station
            menu.append(('[COLOR lightblue][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?setBckupBckup=%s)'% (sys.argv[0],radioEPGi.name)))             
            if 'P4' in station_id and not station_id == P4selected:
                menutext = ADDON.getLocalizedString(30400)   ### Select P4 Station
                menu.append(('[COLOR red][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?setP4=%s)'% (sys.argv[0],radioEPGi.name)))   
            if 'P5' in station_id and not station_id == P5selected:
                menutext = ADDON.getLocalizedString(30432)   ### Select P5 Station
                menu.append(('[COLOR red][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?setP5=%s)'% (sys.argv[0],radioEPGi.name)))  
            if krogsbellswitchavailable() and 1 == 0: ###Disable
                menutext = ADDON.getLocalizedString(30405)   ### Switch Krogsbell Addons
                menu.append(('[COLOR blue][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?switch=other)'% (sys.argv[0]))) 
            logoImage = xbmcvfs.translatePath(os.path.join(LOGO_PATH, str(radioEPGi.icon) + '.png'))
            __log('2 logoImage= %r'% logoImage)
            if station_id == preferredstation:
                station_id = '[COLOR lightgreen][B]' + station_id + '[/B][/COLOR] ' +ADDON.getLocalizedString(30390)  
            if station_id == backupstation:
                station_id = '[COLOR yellow][B]' + station_id + '[/B][/COLOR] ' +ADDON.getLocalizedString(30391)
            if station_id == backupbackupstation:
                station_id = '[COLOR lightblue][B]' + station_id + '[/B][/COLOR] ' + ADDON.getLocalizedString(30436) ### 2023-11-01
            if P4selected in station_id:
                station_id = station_id + ' ' + '[COLOR red]' + ADDON.getLocalizedString(30399) + '[/COLOR]'
            if P5selected in station_id:
                station_id =  station_id + ' ' + '[COLOR red]' + ADDON.getLocalizedString(30433) + '[/COLOR]'
            if xbmcvfs.exists(logoImage):
                ###__log('logoImage EXISTS %r'% logoImage)
                item = xbmcgui.ListItem(station_id)
                item.setArt({ 'icon': logoImage, 'thumb' : logoImage })
                limage = logoImage
            else:
                ###__log('logoImage DO NOT EXISTS %r'% logoImage)
                item = xbmcgui.ListItem(station_id)
                item.setArt({ 'icon': ICON, 'thumb' : ICON })
                limage = ICON
            __log('station_id= %r ' % station_id)

            item.setProperty('IsPlayable', 'true')
            item.addContextMenuItems(items=menu, replaceItems=True)
            item.setProperty('Fanart_Image', FANART)
            __log('#446')
            if INFO_TAG:
                info_tag = ListItemInfoTag(item, 'music')
                infolabels = { 'title': station_id }
                info_tag.set_info(infolabels)
                __log('545 infolabels= %r' % infolabels)
            """
            item.setInfo(type='music', infoLabels={
                'title': station_id,
                ###'genre': 'genre444',
                'rating': int(utils.ADDONgetSetting('setvolumen'))/10
            })
            """
            ###xbmcplugin.addDirectoryItem(HANDLE, PATH + '?playEPG=%s' % station_id, item)
            xbmcplugin.addDirectoryItem(HANDLE, stationurl, item)
            __log('radioEPGi.name= %r' % radioEPGi.name)
            __log('ProgramPlaying= %r' % ProgramPlaying)
            if radioEPGi.name == ProgramPlaying and not PlayingFound:
                PlayingFound = True
                show_list_item = default_list_item + 2
            else:
                default_list_item += 1
            __log('PlayingFound= %r' % PlayingFound)
            __log('default_list_item= %r' % default_list_item)
            __log('show_list_item= %r' % show_list_item)
    except Exception as e:
        __log('ERROR in showEPGm: %r' % e)
        pass

    ### DO NOT SORT xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    try:
        __log('default_list_item= %r' % default_list_item)
        win = xbmcgui.Window(xbmcgui.getCurrentWindowId())
        __log('xbmcgui.Window= %r' % win)
        cid = win.getFocusId()
        __log('win.getFocusId= %r' % cid)
        xbmc.executebuiltin('SetFocus(%s, %s)' % (cid, show_list_item))
    except Exception as e:
        __log('ERROR in showEPGm SetFocus: %r' % e)
        pass
    xbmcplugin.endOfDirectory(HANDLE)
    
def getvolumenepg(station):
    laststop = utils.ADDONgetSetting('laststop')
    __log('1 laststop= %r' % laststop)
    laststopdate = laststop.replace("'","")[:10]
    __log('laststopdate= %r' % laststopdate)
    __log('now()= %r' % now())
    if laststopdate == '':
        return station
    __log('TS(laststopdate+T12:00:00+00:00= %r ' % TS(laststopdate+'T12:00:00+00:00'))
    if now() > TS(laststopdate+'T12:00:00+00:00') :
        laststop = '[COLOR red][B] ' + ADDON.getLocalizedString(30428) + ' ' + laststopdate + '[/B][/COLOR]'
    else:
        laststop = '[COLOR lightgreen] ' + ADDON.getLocalizedString(30429) + ' [/COLOR]'
    volum = utils.ADDONgetSetting('setvolumen') 
    __log('getvolumenepg(station= %r)= %r' % (station,volum))
    volum += laststop 
    if volum:
        station += ADDON.getLocalizedString(30390) + '\n[I]' + ADDON.getLocalizedString(30416) + volum + ' ' + utils.ADDONgetSetting('titleupdating') + '[/I]'
    elif utils.ADDONgetSetting('titleupdating'):
        station += ADDON.getLocalizedString(30390) + '\n[I]' + ' ' + utils.ADDONgetSetting('titleupdating') + '[/I]'
    else:
        station += ADDON.getLocalizedString(30390)
    return station
    
def getSchedule(dataepg,station_id):   ### returns channelTitle, channelSlug, [schedule]
    if dataepg != '':
        datadict = xmltodict.parse(dataepg)
        __log('538 len(datadict)= %r' % len(datadict))
        __log('539 datadict= %r' % datadict)
        Channelfile = os.path.join(datapath, station_id + '.dic')  ### filename here 2022-05-31
        __log('540 Channelfile= %r' % Channelfile)
        try:
            with open(Channelfile,'wb') as output:
                ###output.write('%r'% datadict)
                __log('575 datadict= %r' % datadict)
                output.write(b'%r'% datadict)
                
        except Exception as e:
            pass
            __log('552 write error Channelfile.dic= %r' % e)
        masterkey = '-html-body-script-0-'
        __log('554 masterkey= %r' % masterkey)
        
        scripts = datadict['html']['body']['script']

        if isinstance(scripts, dict):
            next_data = scripts
        else:
            next_data = next(
                x for x in scripts
                if isinstance(x, dict) and x.get('@id') == '__NEXT_DATA__'
            )

        json_text = next_data['#text']
        __log('703 json_text= %r' % json_text)
        ###return ['','','']
        """
        datadict = datadict['html']['body']###['script']  ### 2022-10-15 removed [0]  
        __log('692 datadict= %r' % datadict)
        dict_keys = list(datadict.keys())
        __log('694 dict_keys= %r' % dict_keys)
        datadict = datadict['script']  
        ###datadict = datadict['div']
        __log('696 datadict= %r' % datadict)
        try:
            dict_keys = list(datadict.keys())
            __log('698 dict_keys= %r' % dict_keys)
            Channelfile = os.path.join(datapath, station_id + masterkey + '.keys')
            __log('589 Channelfile= %r' % Channelfile)
        ###try:
            with open(Channelfile,'wb') as output:
                output.write(b'%r'% dict_keys)
        except Exception as e:
            pass
            __log('559 write error Channelfile.keys= %r' % e)
            ### Use old keys
            with open(Channelfile,'rb') as input:
                dict_keys= input.read()
            __log('706 read old dict_keys= %r' % dict_keys)
        
        for i in range(len(dict_keys)):
        
            key = dict_keys[i]
            name = datadict[key] 
            __log('563 datadict[key= %r]= %r' % (key,name))
            if isinstance(name, list):
                for j in range(len(name)):
                    Channelfile = os.path.join(datapath, station_id + masterkey + key + str(j) + '.dic')
                    __log('567 datadict[key= %r]= %r' % (key,j))
                    __log('568 datadict[key= %r] to %r' % (key,Channelfile))
                    try:
                        with open(Channelfile,'wb') as output:
                            output.write(b'%r'% name[j])
                    except Exception as e:
                        pass
                        __log('578 write error Channelfile.keys= %r' % e)
            else:
                Channelfile = os.path.join(datapath, station_id + masterkey + key + '.dic')
                __log('573 datadict[key= %r] to %r' % (key,Channelfile))
                try:
                    with open(Channelfile,'wb') as output:
                        output.write(b'%r'% name)
                except Exception as e:
                    pass
                    __log('587 write error Channelfile.keys= %r' % e)
            schedule = []
            __log('577 key= %r' % key)
            channelTitle = 'missing'
            channelSlug = 'missing'
            items = [] 
        """  
        ###if key == '#text' :
        #####   __log('579 key= %r' % key)
        key = '#text'
        schedule = []
        channelTitle = 'missing'
        channelSlug = 'missing'
        items = [] 
        name = json_text
        datapanel = simplejson.loads(name)
        __log('581 datapanel= %r' % datapanel)
        try:
            channelTitle= datapanel['props']['pageProps']['schedule']['channel']['title']
            __log('582 channelTitle= %r' % channelTitle)
            channelSlug = datapanel['props']['pageProps']['schedule']['channel']['slug']
            __log('624 channelSlug= %r' % channelSlug)
            items = datapanel['props']['pageProps']['schedule']['items']
        except Exception as e:
            pass
            __log('schedule Exception: %r' % e)
            channelTitle = 'missing'
            channelSlug = 'missing'
            items = []   ### 2023-09-28
        for j in range(len(items)):
            startTime = datapanel['props']['pageProps']['schedule']['items'][j]['startTime']
            __log('628 startTime= %r' % startTime)
            endTime = datapanel['props']['pageProps']['schedule']['items'][j]['endTime']
            __log('630 endTime= %r' % endTime)
            title = datapanel['props']['pageProps']['schedule']['items'][j]['title']
            __log('634 title= %r' % title)
            try:
                description = datapanel['props']['pageProps']['schedule']['items'][j]['description']
                __log('636 description= %r' % description)
            except Exception as e:
                pass
                description = ''
            schedule.append([channelTitle,channelSlug,startTime,endTime,title,description])
        
        __log('3 Schedule= %r' % schedule)
        Channelfile = os.path.join(datapath, station_id + masterkey + key + '.json')
        try:
            with open(Channelfile,'wb') as output:
                output.write(b'%r'% schedule)
        except Exception as e:
            pass
            __log('621 write error Channelfile.keys= %r' % e)
        
        return [channelTitle, channelSlug, schedule]
    else:
        return ['','','']

def shareLogs(change): ### Only change = True in this file only - 2023-10-12 moved to utils
    sharepath = utils.ADDONgetSetting('sharepath')
    __log('603 shareLogs sharepath= %r' % sharepath)
    
    dest = 'DestinationNotSetYet'
    try:
        if sharepath != '':
            destname = (str(xbmc.getInfoLabel('System.FriendlyName'))+'-'+ADDONname).replace(' ','')
            dest = os.path.join(sharepath,destname)
            __log('613 logs to= %r' % dest)
            
            utils.ADDONsetSetting('Excution 1', 'Before Copy Files')
            datapath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
            
            try:
                file = 'DRNU-favorites.txt'    ### Not used at the moment - Used in DR TV app!
                destf = os.path.join(sharepath,file)
                sourf = xbmcvfs.translatePath(os.path.join(datapath, 'favorites.txt'))
                copyOK = xbmcvfs.copy(destf, sourf)
                if not copyOK:
                    __log('Copy of favorites.txt failed')
                __log('619 favorites.txt to= %r' % sourf)
                __log('620 favorites.txt from= %r' % destf)
            except Exception as e:
                pass
                utils.ADDONsetSetting('Exception favorites.txt', repr(e))
            
            if not change :
                file = destname+'-kodi.log'
                destf = os.path.join(sharepath,file)
                sourf = xbmcvfs.translatePath(os.path.join('special://logpath', 'kodi.log'))
                ###xbmcvfs.copy(sourf, destf)
                if os.path.exists(sourf):
                    copyOK = xbmcvfs.copy(sourf, destf)
                    if not copyOK:
                        __log('Copy of kodi.log failed')
                __log('619 kodi.log from= %r' % sourf)
                __log('620 kodi.log to= %r' % destf)
                
                file = destname+'-addon.log'
                destf = os.path.join(sharepath,file)
                sourf = xbmcvfs.translatePath(os.path.join(datapath, 'addon.log'))
                if os.path.exists(sourf):
                    copyOK = xbmcvfs.copy(sourf, destf)
                    if not copyOK:
                        __log('Copy of addon.log failed')
                __log('627 addon.log from= %r' % sourf)
                __log('628 addon.log to= %r' % destf)
            ###settingUpdated = False    
            if change :
                file = destname+'-settingsCNG.xml'
                cngf = os.path.join(sharepath,file)
                localcngf = xbmcvfs.translatePath(os.path.join(datapath, 'settings.cng'))
                utils.ADDONsetSetting('Excution 2', 'cngf = %r' % cngf)
                try:
                    if xbmcvfs.exists(cngf):
                        copyOK = xbmcvfs.copy(cngf, localcngf)
                        if not copyOK:
                            __log('Copy of settings.cng failed')
                            utils.ADDONsetSetting('Exception 1', 'Copy of settings.cng failed')
                        if os.path.isfile(localcngf) :
                            utils.ADDONsetSetting('Excution 3', 'localcngf = %r' % localcngf)
                            file = open(localcngf,'r',encoding='utf-8')
                            desc = file.read()
                            utils.ADDONsetSetting('Excution 4', 'desc = %r' % desc)
                            file.close()
                            params = desc.split('<setting id="')[1]
                            utils.ADDONsetSetting('Excution 5', 'params = %r' % params)
                            param = params.split('"')[0]
                            utils.ADDONsetSetting('Excution 6', 'param = %r' % param)
                            values = params.split('>')[1].split('<')[0]
                            utils.ADDONsetSetting('Excution 7', 'values = %r' % values)
                            utils.ADDONsetSetting(param, values)
                            xbmcvfs.delete(cngf)
                            xbmcvfs.delete(localcngf)
                            ###settingUpdated = True
                    else:
                        __log('No settings.cng - No update')
                except Exception as e:
                    pass
                    utils.ADDONsetSetting('Exception', repr(e))
            
            utils.ADDONsetSetting('Excution 9', 'Before Copy settings.xml')
            if not change :
                file = destname+'-settings.xml'
                destf = os.path.join(sharepath,file)
                sourf = xbmcvfs.translatePath(os.path.join(datapath, 'settings.xml'))
                if os.path.exists(sourf):
                    copyOK = xbmcvfs.copy(sourf, destf)
                    ###if settingUpdated :
                    ###    copyOKreturn = xbmcvfs.copy(destf, sourf)
                    if not copyOK:
                        __log('Copy of settings.xml failed')
                    ###if not copyOKreturn:
                    ###    __log('Copy back of settings.xml failed')
                __log('653 settings.xml from= %r' % sourf)
                __log('654 settings.xml to= %r' % destf)
            
    except Exception as  e:
        pass 
        __log('Change setting or Copy shareLogs to sharepath= %r FAILED: %r' % (dest, e))
  
def showEPG():
    ###count += 1
    ADDON.setSetting('autorun','true')
    utils.krogsbellNOTWatchingVideo()
    utils.ADDONsetSetting('count','addon.py Line# %r, %r' % (834,'showEPG()'))
    __log('showEPG START')
    utils.TestInfoTag('showEPG')
    utils.shareLogs(True)
    default_list_item = 0
    show_list_item = 0
    program_list_item = 0
    PlayingFound = False
    EPGWindowId = repr(xbmcgui.getCurrentWindowId())
    utils.logdev('window','showEPG module= %r, CurrentWindowIdWindowId= %r' % (module, EPGWindowId))
    utils.ADDONsetSetting('EPGWindowId',EPGWindowId)
    
    try:
        ProgramPlaying   = utils.ADDONgetSetting('programplaying')
        __log('ProgramPlaying= %r' % ProgramPlaying)
        preferredstation = utils.ADDONgetSetting('preferredstation') 
        backupstation    = utils.ADDONgetSetting('backupstation')
        backupbackupstation    = utils.ADDONgetSetting('backupbackupstation')
        epglines         = int(utils.ADDONgetSetting('epglines'))
        items          = []
        WantedPrograms = []
        NogoPrograms   = []
        logoImageP = ''
        P4selected = utils.ADDONgetSetting('selectedp4station')
        P5selected = utils.ADDONgetSetting('selectedp5station')
        for radioEPGi in channelsDR.CHANNELS:
            if ProgramPlaying == radioEPGi.name:
                logoImageP = xbmcvfs.translatePath(os.path.join(LOGO_PATH, str(radioEPGi.icon) + '.png'))
                break
        ###count += 1
        ###utils.ADDONsetSetting('count','addon.py Line# %r, %r' % (863,count))
        for radioEPGi in channelsDR.CHANNELS:
            
            station_id = radioEPGi.name
            __log('station_id= %r' % station_id)
            stationurl = radioEPGi.url
            __log('stationurl= %r' % stationurl)
            station = ''
            
            if station_id == preferredstation:
                station = getvolumenepg(station)
            __log('1 station= %r' % station)
            if station_id == backupstation:
                station += ADDON.getLocalizedString(30391)
            __log('2 station= %r' % station)
            if station_id == backupbackupstation:
                station += ADDON.getLocalizedString(30436)

            ###station += ' ' + ADDON.getLocalizedString(30404) + ': ' + ProgramPlaying
            __log('3 station= %r' % station)
            descriptionP = ADDON.getLocalizedString(30404) + ': ' + ProgramPlaying + '\n[B]' + ADDON.getLocalizedString(30390) + '[/B] ' + preferredstation + '\n[B]' + ADDON.getLocalizedString(30391) + '[/B] ' + backupstation + ADDON.getLocalizedString(30436) + ' ' + backupbackupstation
            __log('station_id= %r\nP4selected= %r\nP5selected= %r' % (station_id, P4selected, P5selected))
            if 'P4' in station_id and not station_id == P4selected:
                __log('Ignore P4 Station: %r' % station_id)
            elif 'P5' in station_id and not station_id == P5selected:
                __log('Ignore P5 Station: %r' % station_id)
            else:
                maxage = utils.max_age()
                __log('817 maxage= %r' % maxage)
                radioEPG = radioEPGi.epg
                resp = utils.readChannelEPG(station_id,radioEPG,maxage)
                
                __log('803 resp= %r' % resp)
                
                try:
                    dataepg = resp
                    __log('showEPGa 1081')
                    Schedule = getSchedule(dataepg,station_id)   ### returns channelTitle, channelSlug, [schedule]
                except Exception as e:
                    pass
                    __log('903 radioEPG ERROR: %r' % e)  
                    ###Schedule = [channelTitle, channelSlug, [schedule]]
                    Schedule = [station_id, station_id, None]
                ###dataepg = resp
                
                ###Schedule = getSchedule(dataepg,station_id)   ### returns channelTitle, channelSlug, [schedule]
                
                nowLocal = datestr(now(),'%H:%M')

                title = Schedule[0]
                __log('654 channelTitle= %r' % title)
                if title[0:3] == 'DR ':
                    title = title[3:]
                ###if title[0:2] == 'P5':    ### 2023-11-01
                ###    title = title[:2]
                if station_id == ProgramPlaying:
                    __log('872 ProgramPlaying= %r' %ProgramPlaying)
                    titlename = '[COLOR lightgreen][B]' + title + '[/B][/COLOR]  ' + station
                else:
                    titlename = '[COLOR yellow][B]' + title + '[/B][/COLOR]  ' + station
                logoImage = xbmcvfs.translatePath(os.path.join(LOGO_PATH, str(radioEPGi.icon) + '.png'))
                __log('1 logoImage= %r' %logoImage)
                if xbmcvfs.exists(logoImageP):
                    ###__log('logoImage EXISTS %r'% logoImage)
                    item = xbmcgui.ListItem(titlename)  ### 2019-09-15 Allways show playing icon
                    item.setArt({ 'icon': logoImageP, 'thumb' : logoImageP })
                    limage = logoImageP
                else:
                    ###__log('logoImage DO NOT EXISTS %r'% logoImage)
                    item = xbmcgui.ListItem(titlename)
                    item.setArt({ 'icon': ICON, 'thumb' : ICON })
                    limage = ICON
                menu=[]
                if krogsbellswitchavailable():
                    menutext = ADDON.getLocalizedString(30405)   ### Switch Krogsbell Addons
                    menu.append(('[COLOR blue][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?switch=other)'% (sys.argv[0]))) 
                item.addContextMenuItems(items=menu, replaceItems=True)
                item.setProperty('IsPlayable', 'true')
                item.setProperty('Fanart_Image', FANART)
                titlenameX = '[COLOR lightgreen][B]' + ADDON.getLocalizedString(30404) + ': ' + ProgramPlaying + '[/B][/COLOR] (' + nowLocal + ')\n\n' + titlename
                __log('#577')
                if INFO_TAG:
                    info_tag = ListItemInfoTag(item, 'music')
                    infolabels = { 'title': station_id}   ###, 'genre': titlenameX }
                    info_tag.set_info(infolabels)
                    __log('898 infolabels= %r' % infolabels)
                """
                item.setInfo(type='music', infoLabels={
                    'title': station_id,
                    #'tracknumber': 12345679,
                    #'discnumber': 13,
                    #'duration': 245999,
                    #'year': 1999,
                    'genre': titlenameX   #,
                    #'album': 'Pulse1',
                    #'artist': 'Cat',
                    #'rating': int(utils.ADDONgetSetting('setvolumen'))/10
                })
                """
                __log('962 descriptionP= %r' % descriptionP)
                ###__log('getMusicInfoTag()= %r' % item.getMusicInfoTag())
                ###xbmcplugin.addDirectoryItem(HANDLE, PATH + '?playEPG=%s' % station_id, item)
                xbmcplugin.addDirectoryItem(HANDLE, stationurl, item)
                __log('xbmcplugin.addDirectoryItem station_id= %r' % station_id)
                if radioEPGi.name == ProgramPlaying and not PlayingFound:
                    PlayingFound = True
                    show_list_item = default_list_item + 2
                    ###show_list_item = program_list_item + 2
                    __log('show_list_item= %r' % show_list_item)
                else:
                    default_list_item += 1
                    program_list_item += 1
                    __log('default_list_item= %r' % default_list_item)
                i = 0
                try:
                    for program in Schedule[2]:
                        __log('946 program= %r' % program)
                        ### schedule.append([channelTitle 0,channelSlug 1,startTime 2,endTime 3,title 4,description 5])
                        stop = program[3]
                        laststop = repr(stop)
                        __log('2 laststop= %r' % laststop)
                        if laststop :
                            utils.ADDONsetSetting('laststop',laststop)
                        start = program[2]
                        startactual = program[2]
                        if TS(stop) > nowTS():
                            title = program[4]  
                            titleDesc = program[4]  + program[5]   ### 2023-05-24 Go/Nogo search in title and description
                            description= program[5]
                            menu=[]
                            menutext = ADDON.getLocalizedString(30392)   ### Wanted Programs
                            menu.append(('[COLOR lightgreen][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?setWanted=%s)'% (sys.argv[0],title.lower())))   
                            menutext = ADDON.getLocalizedString(30393)   ### Nogo Programs
                            menu.append(('[COLOR red][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?setNogop=%s)'% (sys.argv[0],title.lower()))) 
                            if krogsbellswitchavailable():
                                menutext = ADDON.getLocalizedString(30405)   ### Switch Krogsbell Addons
                                menu.append(('[COLOR blue][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?switch=other)'% (sys.argv[0]))) 
                            
                            programswantedASCII = []
                            for x in programswanted:
                                programswantedASCII.append(onlyAscii(x))
                            __log('programswantedASCII= %r' % programswantedASCII)
                            
                            programsnogoASCII = []
                            for x in programsnogo:
                                programsnogoASCII.append(onlyAscii(x))
                            __log('programsnogoASCII= %r' % programsnogoASCII) 
                            
                            for notwanted in programsnogoASCII:
                                __log('title.lower()= %r' % title.lower())
                                __log('1 onlyAscii(titleDesc.lower()= %r' % onlyAscii(titleDesc.lower()))
                                ###if notwanted in onlyAscii(title.lower()):
                                if notwanted in onlyAscii(titleDesc.lower()):
                                    __log('notwanted= %r' % notwanted)
                                    if notwanted != '':
                                        __log('[/I] in title= %r' % title)
                                        if '[/I]' in title:
                                            title = '[COLOR red]' + title + '[/COLOR]' 
                                        else:
                                            title = '[I][COLOR red]' + title + '[/COLOR][/I]'
                                        NogoPrograms.append([station_id,startactual,stop])
                            
                            for wanted in programswantedASCII:
                                __log('wanted= %r' % wanted)
                                __log('title.lower()= %r' % title.lower())
                                __log('2 onlyAscii(titleDesc.lower()= %r' % onlyAscii(titleDesc.lower()))
                                if wanted in onlyAscii(titleDesc.lower()):
                                    __log('wanted1= %r' % wanted)
                                    if wanted != '':
                                        title = '[COLOR lightgreen]' + title + '[/COLOR]'
                                        WantedPrograms.append([station_id,startactual,stop])

                            if 'genudsendelse' in description.lower():
                                title = '[B]' + title + '[/B] (genudsendelse)' ### 2023-09-14
                            elif 'sendt første gang' in description.lower():
                                title = '[B]' + title + '[/B] (sendt før)' ### 2023-10-01
                            elif '(sendes ogs' in description.lower():
                                title = '[B]' + title + '[/B] (sendes også)' ### 2023-10-01
                            else:
                                title = '[B]' + title + '[/B]' 
                            description= program[5]
                            
                            if description:
                                title += '\n' + description.replace('\n',' ').strip()
                            __log('X title= %r' % title)
                            for pw in programswanted:
                                title = highlight(title, pw, 'lightgreen')    ### 2023-01-22
                            for pw in programsnogo:
                                title = highlight(title, pw, 'red')    ### 2023-01-22
                            __log('highlight(title= %r)' % title)
                            title = TwoLines(title)
                            channel= program[0]
                            __log('channel= %r, title= %r' % (channel,title)) 
                            if start != startactual:
                                try:
                                    ### 2019-05-21T22:05:00Z
                                    timediff = repr(TS(startactual) - TS(start))
                                    __log('timediff= %r, startactual= %r, start= %r' % (timediff, startactual, start))
                                except Exception as e:
                                    pass
                                    timediff = repr(e)
                                title = '[COLOR blue]'+timediff+'[/COLOR] ' + title
                            if i < epglines * 20 or '[I][COLOR red]' in title or '[COLOR lightgreen]' in title:
                                i += 1
                                
                                ###startactualLocal = TSl(startactual)
                                startactualLocal = datestr(TSl(startactual),'%H:%M')
                                stopLocal = datestr(TSl(stop),'%H:%M')
                                ###titlename = startactual[11:-4] + ' - ' + stop[11:-4] + 'X' +startactualLocal+' - ' + stopLocal+ '  ' + title
                                titlename = startactualLocal+' - ' + stopLocal + '  ' + title
                                ###item = xbmcgui.ListItem(titlename, iconImage='x')  ### No icon on program lines
                                item = xbmcgui.ListItem(titlename)
                                item.setArt({ 'icon': logoImageP, 'thumb' : logoImageP })
                                item.addContextMenuItems(items=menu, replaceItems=True)
                                item.setProperty('IsPlayable', 'true')
                                item.setProperty('Fanart_Image', FANART)
                                __log('timediff= %r' %(TS(stop) - TS(start)))
                                titlename = '[COLOR lightgreen][B]' + ADDON.getLocalizedString(30404) + ': ' + ProgramPlaying + '[/B][/COLOR] (' + nowLocal + ')\n'+utils.ADDONgetSetting('titleupdating')+'\n[COLOR yellow][B]' + channel +'[/B][/COLOR]\n\n'+ title
                                __log('titlename= %r' %(titlename))
                                __log('#690')
                                if INFO_TAG:
                                    info_tag = ListItemInfoTag(item, 'music')
                                    infolabels = { 'title': title, 'duration': TS(stop) - TS(start)}   ###, 'genre': titlename }
                                    info_tag.set_info(infolabels)
                                    __log('898 infolabels= %r' % infolabels)
                                """
                                item.setInfo(type='music', infoLabels={
                                    'title': title,
                                    #'tracknumber': 12345678,
                                    #'discnumber': 12,
                                    'duration': TS(stop) - TS(start),
                                    #'year': 1998,
                                    'genre': titlename   #,
                                    #'album': 'Pulse',
                                    #'artist': descriptionP,
                                    #'rating': int(utils.ADDONgetSetting('setvolumen'))/10
                                })
                                """
                                xbmcplugin.addDirectoryItem(HANDLE, stationurl, item)
                                ###xbmcplugin.addDirectoryItem(HANDLE, PATH + '?playEPG=%s' % station_id, item)
                                default_list_item += 1
                                __log('default_list_item(epg entry)= %r' % default_list_item)
                except Exception as e:
                    pass
                    __log('1 radioEPG ERROR: %r' % e)
                    __log('station_id= %r 1== ProgramPlaying= %r' % (station_id, ProgramPlaying))
                    titlename = 'Intet kendt program\n...'
                    item = xbmcgui.ListItem(titlename)
                    item.setArt({ 'icon': logoImageP, 'thumb' : logoImageP })
                    item.addContextMenuItems(items=menu, replaceItems=True)
                    item.setProperty('IsPlayable', 'true')
                    item.setProperty('Fanart_Image', FANART)
                    if INFO_TAG:
                        info_tag = ListItemInfoTag(item, 'music')
                        infolabels = { 'title': title}  
                        info_tag.set_info(infolabels)
                        __log('1105 infolabels= %r' % infolabels)
                    xbmcplugin.addDirectoryItem(HANDLE, stationurl, item)
    except Exception as e:
        pass
        __log('2 radioEPG ERROR: %r' % e)
    try:
        __log('show_list_item= %r' % show_list_item)
        __log('default_list_item= %r' % default_list_item)
        win = xbmcgui.Window(xbmcgui.getCurrentWindowId())
        __log('xbmcgui.Window= %r' % win)
        cid = win.getFocusId()
        __log('win.getFocusId= %r' % cid)
        xbmc.executebuiltin('SetFocus(%s, %s)' % (cid, show_list_item))
    except Exception as e:
        __log('ERROR in showEPG SetFocus: %r' % e)
        pass
    try:
        ### DO NOT SORT xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
        skin_used = xbmc.getSkinDir()
        __log('skin_used= %r' % skin_used)
        utils.ADDONsetSetting('skin_used',skin_used)
        mediatype = ['','music','song','album','artist']
        content = mediatype[int(utils.ADDONgetSetting('mediatype'))]
        __log('mediatype= %r' % content)
        xbmcplugin.setContent(HANDLE, content)
    except Exception as e:
        pass
        __log('radioEPG Play ERROR: %r' % e)
    """
    mediatype	string - “music”, “song”, “album”, “artist”
    
    if skin_used == 'skin.estuary':
        viewmode = utils.ADDONgetSetting('wideview')
        xbmc.executebuiltin('Container.SetViewMode(%s)' % viewmode) 
    if skin_used == 'skin.confluence':
        xbmc.executebuiltin('Container.SetViewMode(500)') # "Thumbnail" view
    elif skin_used == 'skin.aeon.nox':
        xbmc.executebuiltin('Container.SetViewMode(512)') # "Info-wall" view. 
    """
   
    xbmcplugin.endOfDirectory(HANDLE)

def krogsbellswitchavailable():
    SwFileFolder = os.path.join(xbmcvfs.translatePath('special://masterprofile/'), 'addon_data','krogsbell.switchaddons')
    SwFile = os.path.join(SwFileFolder,'switchaddons.txt')
    if os.path.isfile(SwFile):
        return True
    else:
        return False

def showEPGa():   ### Active channel limited + Wanted and No Go Programs
    ###count += 1
    ADDON.setSetting('autorun','true')
    utils.krogsbellNOTWatchingVideo()
    utils.ADDONsetSetting('count','addon.py Line# %r, %r' % (1127,'showEPGa()'))
    __log('showEPGa START')
    utils.TestInfoTag('showEPGa')
    utils.shareLogs(True)
    default_list_item = 0
    show_list_item = 0
    PlayingFound = False
    EPGWindowId = repr(xbmcgui.getCurrentWindowId())
    __log('showEPGa CurrentWindowIdWindowId= %r' % EPGWindowId)
    utils.ADDONsetSetting('EPGWindowId',EPGWindowId)
    try:
        __log('showEPGa 1112')
        ProgramPlaying = utils.ADDONgetSetting('programplaying')
        epglines = int(utils.ADDONgetSetting('epglines'))
        preferredstation = utils.ADDONgetSetting('preferredstation') 
        backupstation    = utils.ADDONgetSetting('backupstation')
        backupbackupstation    = utils.ADDONgetSetting('backupbackupstation')
        items = []
        WantedPrograms = []
        NogoPrograms   = []
        logoImageP = ''
        P4selected = utils.ADDONgetSetting('selectedp4station')
        P5selected = utils.ADDONgetSetting('selectedp5station')
        laststartstation = utils.ADDONgetSetting('laststartstation')
        laststartstationID = laststartstation[:2]
        laststartstationTime = laststartstation[-8:].replace('d','').replace('h','').replace('m','')
        lastendstation = utils.ADDONgetSetting('lastendstation')
        lastendstationTime = lastendstation[-8:].replace('d','').replace('h','').replace('m','')
        __log('laststartstationID= %r, laststartstationTime= %r, lastendstationTime= %r' % (laststartstationID, laststartstationTime, lastendstationTime))
        resp = ''
        for radioEPGi in channelsDR.CHANNELS:
            if ProgramPlaying == radioEPGi.name:
                logoImageP = xbmcvfs.translatePath(os.path.join(LOGO_PATH, str(radioEPGi.icon) + '.png'))
                __log('showEPGa 1050')
                break
        for radioEPGi in channelsDR.CHANNELS:
            station_id = radioEPGi.name
            stationurl = radioEPGi.url
            __log('0 station_id= %r' % station_id)
            station = ''
            resp = ''
            if station_id == preferredstation:
                station = getvolumenepg(station)
            if station_id == backupstation:
                station += ADDON.getLocalizedString(30391)
            if station_id == backupbackupstation:
                station += ADDON.getLocalizedString(30436)    
            descriptionP = ADDON.getLocalizedString(30404) + ': ' + ProgramPlaying + '\n[B]' + ADDON.getLocalizedString(30390) + '[/B] ' + preferredstation + '\n[B]' + ADDON.getLocalizedString(30391) + '[/B] ' + backupstation + ADDON.getLocalizedString(30436) + ' ' + backupbackupstation
            if 'P4' in station_id and not station_id == P4selected:
                __log('Ignore P4 Station: %r' % station_id)
            elif 'P5' in station_id and not station_id == P5selected:
                __log('Ignore P5 Station: %r' % station_id)
            else:
                __log('showEPGa 1153')
                radioEPG = radioEPGi.epg
                __log('showEPGa 1155 radioEPG= %r' % radioEPG)
                ###radioEPG = radioEPG.upper()
                ###.replace('HTTPS://WWW.DR.DK','http://www.dr.dk')    ### 2023-09-28 to avoid on Windows 11: urlquick.get(radioEPG) EXCEPTION: TooManyRedirects('Exceeded 30 redirects.')
                ###radioEPG = 'HTTPS://WWW.DR.DK/LYD/OVERSIGT'
                __log('1147 station_id= %r, radioEPG= %r ' % (station_id,radioEPG))
                maxage = utils.max_age()
                __log('1149 maxage= %r' % maxage)
                resp = utils.readChannelEPG(station_id,radioEPG,maxage)
                
                __log('1154 resp= %r' % resp)
                try:
                    dataepg = resp
                    __log('showEPGa 1081')
                    Schedule = getSchedule(dataepg,station_id)   ### returns channelTitle, channelSlug, [schedule]
                except Exception as e:
                    pass
                    __log('1216 radioEPG ERROR: %r' % e)  
                    ###Schedule = [channelTitle, channelSlug, [schedule]]
                    Schedule = [station_id, station_id.lower(), None]
                    ###[['P8 JAZZ', 'p8jazz', '2024-01-20T04:00:00+00:00', '2024-01-20T04:03:00+00:00', 'Radioavisen', 'Bliv 
                if 1 == 1 :    
                    __log('showEPGa 1083')
                    ###datadict = xmltodict.parse(dataepg)
                    ### name = datadict['m_sch:message']['schedule']['channel']['name']
                    name = Schedule[0]
                    __log('name= %r' % name)
                    ### typeD = datadict['m_sch:message']['schedule']['channel']['type']   ###2021-09-23 type --> typeD
                    ### __log('type= %r' % typeD)
                    ### datadict1 = datadict['m_sch:message']['schedule']['programs']
                    nowLocal = datestr(now(),'%H:%M')
                    ### title = datadict['m_sch:message']['schedule']['channel']['name']
                    title = Schedule[0]
                    if title[0:3] == 'DR ':
                        title = title[3:]
                    ###if title[0:2] == 'P5':   ### 2023-11-01
                    ###    title = title[:2]
                    __log('showEPGa 1098')
                    if station_id == ProgramPlaying:
                        __log('1159 ProgramPlaying= %r' %ProgramPlaying)
                        titlename = '[COLOR lightgreen][B]' + title + '[/B][/COLOR]  ' + station
                    else:
                        titlename = '[COLOR yellow][B]' + title + '[/B][/COLOR]  ' + station
                    logoImage = xbmcvfs.translatePath(os.path.join(LOGO_PATH, str(radioEPGi.icon) + '.png'))
                    ###__log('logoImage= %r' %logoImage)
                    __log('showEPGa 1105')
                    if xbmcvfs.exists(logoImageP):
                        ###__log('logoImage EXISTS %r'% logoImage)
                        item = xbmcgui.ListItem(titlename)  ### 2019-09-15 Allways show playing icon
                        item.setArt({ 'icon': logoImageP, 'thumb' : logoImageP })
                        limage = logoImageP
                    else:
                        ###__log('logoImage DO NOT EXISTS %r'% logoImage)
                        item = xbmcgui.ListItem(titlename)
                        item.setArt({ 'icon': ICON, 'thumb' : ICON })
                        limage = ICON
                    __log('showEPGa 1114')
                    __log('1273 ProgramPlaying= %r' % ProgramPlaying)
                    menu=[]
                    if krogsbellswitchavailable():
                        menutext = ADDON.getLocalizedString(30405)   ### Switch Krogsbell Addons
                        menu.append(('[COLOR blue][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?switch=other)'% (sys.argv[0]))) 
                    item.addContextMenuItems(items=menu, replaceItems=True)
                    item.setProperty('IsPlayable', 'true')
                    item.setProperty('Fanart_Image', FANART)
                    titlenameX = '[COLOR lightgreen][B]' + ADDON.getLocalizedString(30404) + ': ' + ProgramPlaying + '[/B][/COLOR] (' + nowLocal + ')\n'+utils.ADDONgetSetting('titleupdating')+'\n' + titlename
                    __log('showEPGa 1123')
                    """
                    _tag_attr = {
        'size': {'skip': True},  # Currently no infoTag setter for this property
        'count': {'skip': True},  # Currently no infoTag setter for this property
        'date': {'skip': True},  # Currently no infoTag setter for this property
        'tracknumber': {'attr': 'setTrack', 'convert': int, 'classinfo': int},
        'discnumber': {'attr': 'setDisc', 'convert': int, 'classinfo': int},
        'duration': {'attr': 'setDuration', 'convert': int, 'classinfo': int},
        'year': {'attr': 'setYear', 'convert': int, 'classinfo': int},
        'genre': {'attr': 'setGenres', 'convert': lambda x: [x], 'classinfo': (list, tuple)},
        'album': {'attr': 'setAlbum', 'convert': str, 'classinfo': str},
        'artist': {'attr': 'setArtist', 'convert': str, 'classinfo': str},
        'title': {'attr': 'setTitle', 'convert': str, 'classinfo': str},
        'rating': {'attr': 'setRating', 'convert': float, 'classinfo': float},
        'userrating': {'attr': 'setUserRating', 'convert': int, 'classinfo': int},
        'lyrics': {'attr': 'setLyrics', 'convert': str, 'classinfo': str},
        'playcount': {'attr': 'setPlayCount', 'convert': int, 'classinfo': int},
        'lastplayed': {'attr': 'setLastPlayed', 'convert': str, 'classinfo': str},
        'mediatype': {'attr': 'setMediaType', 'convert': str, 'classinfo': str},
        'dbid': {'route': 'set_info_music_dbid'},
        'listeners': {'attr': 'setListeners', 'convert': int, 'classinfo': int},
        'musicbrainztrackid': {'attr': 'setMusicBrainzTrackID', 'convert': str, 'classinfo': str},
        'musicbrainzartistid': {'attr': 'setMusicBrainzArtistID', 'convert': lambda x: [x], 'classinfo': (list, tuple)},
        'musicbrainzalbumid': {'attr': 'setMusicBrainzAlbumID', 'convert': str, 'classinfo': str},
        'musicbrainzalbumartistid': {'attr': 'setMusicBrainzAlbumArtistID', 'convert': lambda x: [x], 'classinfo': (list, tuple)},
        'comment': {'attr': 'setComment', 'convert': str, 'classinfo': str},
        'albumartist': {'attr': 'setAlbumArtist', 'convert': str, 'classinfo': str},  # Not listed in setInfo docs but included for forward compatibility
    }
                    """
                    if INFO_TAG:
                        info_tag = ListItemInfoTag(item, 'music')
                        infolabels = { 'title': station_id} ###, 'genre': titlenameX }
                        info_tag.set_info(infolabels)
                        __log('1258 infolabels= %r' % infolabels)
                    """
                    item.setInfo(type='music', infoLabels={
                        'title': station_id,
                        #'tracknumber': 12345679,
                        #'discnumber': 13,
                        #'duration': 245999,
                        #'year': 1999,
                        'genre': titlenameX
                        #'album': 'Pulse1',
                        #'artist': 'Cat',
                        ###'rating': int(utils.ADDONgetSetting('setvolumen'))/10  ### 2023-08-16
                    })
                    """
                    __log('1329 descriptionP= %r' % descriptionP)
                    ###__log('getMusicInfoTag()= %r' % item.getMusicInfoTag())
                    __log('1 item url= %r' % (PATH + '?playEPG=%s' % station_id))
                    ###xbmcplugin.addDirectoryItem(HANDLE, PATH + '?playEPG=%s' % station_id, item)
                    __log('HANDLE= %r' % HANDLE)
                    xbmcplugin.addDirectoryItem(HANDLE, stationurl, item)
                    if radioEPGi.name == ProgramPlaying and not PlayingFound:
                        PlayingFound = True
                        show_list_item = default_list_item + 3   ### show actual program EPG
                    else:
                        default_list_item += 1
                    ###if  station_id == ProgramPlaying :
                    __log('showEPGa 1144')
                    if 1 == 1:
                        i = 0
                        
                        if Schedule[2] != None:
                            __log('Schedule[2]= %r' % Schedule[2])
                            for program in Schedule[2]:
                                ### schedule.append([channelTitle 0,channelSlug 1,startTime 2,endTime 3,title 4,description 5])
                                __log('1346 program= %r' % program)
                                stop = program[3]
                                laststop = repr(stop)
                                __log('3 laststop= %r' % laststop)
                                if laststop :
                                    utils.ADDONsetSetting('laststop',laststop)
                                ###stop = program['pro_publish']['ppu_stop_timestamp_presentation_utc']
                                start = program[2]
                                startactual = program[2]
                                if TS(stop) > nowTS():
                                    title = program[4]  
                                    titleDesc = program[4] + program[5]   ### 2023-05-24 Go/Nogo search in title and description
                                    menu=[]
                                    menutext = ADDON.getLocalizedString(30392)   ### Wanted Programs
                                    menu.append(('[COLOR lightgreen][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?setWanted=%s)'% (sys.argv[0],title.lower())))   
                                    menutext = ADDON.getLocalizedString(30393)   ### Nogo Programs
                                    menu.append(('[COLOR red][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?setNogop=%s)'% (sys.argv[0],title.lower()))) 
                                    
                                    if krogsbellswitchavailable():
                                        menutext = ADDON.getLocalizedString(30405)   ### Switch Krogsbell Addons
                                        menu.append(('[COLOR blue][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?switch=other)'% (sys.argv[0]))) 
                                    
                                    if station_id == laststartstationID:
                                        if ison(laststartstationTime,lastendstationTime,TSl(stop)):
                                            title = '[COLOR lightgreen]' + title + '[/COLOR]' 
                                    programswantedASCII = []
                                    for x in programswanted:
                                        programswantedASCII.append(onlyAscii(x).lower())
                                    __log('programswantedASCII= %r' % programswantedASCII)
                                    
                                    programsnogoASCII = []
                                    for x in programsnogo:
                                        programsnogoASCII.append(onlyAscii(x).lower())
                                    __log('programsnogoASCII= %r' % programsnogoASCII) 
                                    
                                    for notwanted in programsnogoASCII:
                                        __log('titleDesc.lower()= %r' % titleDesc.lower())
                                        __log('3 onlyAscii(titleDesc.lower()= %r' % onlyAscii(titleDesc.lower()))
                                        if notwanted in onlyAscii(titleDesc.lower()):
                                            __log('notwanted= %r' % notwanted)          
                                            if notwanted != '':
                                                __log('[/I] in title= %r' % title)
                                                if '[/I]' in title:
                                                    title = '[COLOR red]' + title + '[/COLOR]' 
                                                else:
                                                    title = '[I][COLOR red]' + title + '[/COLOR][/I]'
                                                NogoPrograms.append([station_id,startactual,stop])
                                    for wanted in programswantedASCII:
                                        __log('wanted= %r' % wanted)
                                        __log('titleDesc.lower()= %r' % titleDesc.lower())
                                        __log('4 onlyAscii(titleDesc.lower()= %r' % onlyAscii(titleDesc.lower()))
                                        if wanted in onlyAscii(title.lower()):
                                            __log('wanted1= %r' % wanted)
                                            if wanted != '':
                                                title = '[COLOR lightgreen]' + title + '[/COLOR]'
                                                WantedPrograms.append([station_id,startactual,stop])

                                    ###title = '[B]' + title + '[/B]'
                                    ### punchline= program[5]
                                    ### if punchline:
                                    ###    title += ' - ' + punchline.replace('\n',' ').strip()
                                    description= program[5]
                                    if 'genudsendelse' in description.lower():
                                        title = '[B]' + title + '[/B] (genudsendelse)' ### 2023-09-14
                                    elif 'sendt første gang' in description.lower():
                                        title = '[B]' + title + '[/B] (sendt før)' ### 2023-10-01
                                    elif '(sendes ogs' in description.lower():
                                        title = '[B]' + title + '[/B] (sendes også)' ### 2023-10-01
                                    else:
                                        title = '[B]' + title + '[/B]' 
                                    if description:
                                        title += '\n' + description.replace('\n',' ').strip()
                                    __log('X title= %r' % title)
                                    for pw in programswanted:
                                        title = highlight(title, pw, 'lightgreen')    ### 2023-01-22
                                    for pw in programsnogo:
                                        title = highlight(title, pw, 'red')    ### 2023-01-22
                                    __log('highlight(title= %r)' % title)
                                    title = TwoLines(title)
                                    channel= program[0]
                                    __log('channel= %r, title= %r' % (channel,title)) 
                                    if start != startactual:
                                        try:
                                            ### 2019-05-21T22:05:00Z
                                            timediff = repr(TS(startactual) - TS(start))
                                            __log('timediff= %r, startactual= %r, start= %r' % (timediff, startactual, start))
                                        except Exception as e:
                                            pass
                                            timediff = repr(e)
                                        title = '[COLOR blue]'+timediff+'[/COLOR] ' + title
                                    ###if i < epglines:
                                    if (i < epglines and station_id == ProgramPlaying) or '[I][COLOR red]' in title or '[COLOR lightgreen]' in title or '[COLOR lightblue]' in title:
                                        i += 1
                                        
                                        ###startactualLocal = TSl(startactual)
                                        startactualLocal = datestr(TSl(startactual),'%H:%M')
                                        stopLocal = datestr(TSl(stop),'%H:%M')
                                        ###titlename = startactual[11:-4] + ' - ' + stop[11:-4] + 'X' +startactualLocal+' - ' + stopLocal+ '  ' + title
                                        titlename = startactualLocal+' - ' + stopLocal + '  ' + title
                                        ###item = xbmcgui.ListItem(titlename, iconImage='x')  ### No icon on program lines
                                        item = xbmcgui.ListItem(titlename)
                                        item.setArt({ 'icon': logoImageP, 'thumb' : logoImageP })
                                        item.addContextMenuItems(items=menu, replaceItems=True)
                                        item.setProperty('IsPlayable', 'true')
                                        item.setProperty('Fanart_Image', FANART)
                                        __log('timediff= %r' %(TS(stop) - TS(start)))
                                        titlename = '[COLOR lightgreen][B]' + ADDON.getLocalizedString(30404) + ': ' + ProgramPlaying + '[/B][/COLOR] (' + nowLocal + ')\n'+utils.ADDONgetSetting('titleupdating')+'\n[COLOR yellow][B]' + channel +'[/B][/COLOR]\n\n'+ title
                                        __log('titlename= %r' %(titlename))
                                        __log('#958')
                                        if INFO_TAG:
                                            info_tag = ListItemInfoTag(item, 'music')
                                            infolabels = { 'title': title, 'duration': TS(stop) - TS(start)} ###,'genre': titlename }
                                            info_tag.set_info(infolabels)
                                            __log('1396 infolabels= %r' % infolabels)
                                        """
                                        item.setInfo(type='music', infoLabels={
                                            'title': title,
                                            #'tracknumber': 12345678,
                                            #'discnumber': 12,
                                            'duration': TS(stop) - TS(start),
                                            #'year': 1998,
                                            'genre': titlename,
                                            #'album': 'Pulse',
                                            #'artist': descriptionP,
                                            'rating': int(utils.ADDONgetSetting('setvolumen'))/10
                                        })
                                        """
                                        __log('2 item url= %r' % (PATH + '?playEPG=%s' % station_id))
                                        ###xbmcplugin.addDirectoryItem(HANDLE, PATH + '?playEPG=%s' % station_id, item)
                                        xbmcplugin.addDirectoryItem(HANDLE, stationurl, item)
                        else:
                            __log('station_id= %r 2== ProgramPlaying= %r' % (station_id, ProgramPlaying))
                            if (station_id == ProgramPlaying):
                                titlename = 'Intet kendt program\n...'
                                item = xbmcgui.ListItem(titlename)
                                item.setArt({ 'icon': logoImageP, 'thumb' : logoImageP })
                                item.addContextMenuItems(items=menu, replaceItems=True)
                                item.setProperty('IsPlayable', 'true')
                                item.setProperty('Fanart_Image', FANART)
                                if INFO_TAG:
                                    info_tag = ListItemInfoTag(item, 'music')
                                    infolabels = { 'title': title}  
                                    info_tag.set_info(infolabels)
                                    __log('1105 infolabels= %r' % infolabels)
                                xbmcplugin.addDirectoryItem(HANDLE, stationurl, item)
    except Exception as e:
        pass
        __log('3 radioEPG ERROR: %r' % e)
    
    try:
        ### DO NOT SORT xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
        skin_used = xbmc.getSkinDir()
        __log('skin_used= %r' % skin_used)
        utils.ADDONsetSetting('skin_used',skin_used)
        mediatype = ['','music','song','album','artist']
        content = mediatype[int(utils.ADDONgetSetting('mediatype'))]
        xbmcplugin.setContent(int(sys.argv[1]), content)
    except Exception as e:
        pass
        __log('radioEPG Play ERROR: %r' % e)
    """
    mediatype	string - “music”, “song”, “album”, “artist”
    
    if skin_used == 'skin.estuary':
        viewmode = utils.ADDONgetSetting('wideview')
        xbmc.executebuiltin('Container.SetViewMode(%s)' % viewmode) 
    if skin_used == 'skin.confluence':
        xbmc.executebuiltin('Container.SetViewMode(500)') # "Thumbnail" view
    elif skin_used == 'skin.aeon.nox':
        xbmc.executebuiltin('Container.SetViewMode(512)') # "Info-wall" view. 
    """
    try:
        __log('default_list_item= %r' % default_list_item)
        win = xbmcgui.Window(xbmcgui.getCurrentWindowId())
        __log('xbmcgui.Window= %r' % win)
        cid = win.getFocusId()
        __log('win.getFocusId= %r' % cid)
        xbmc.executebuiltin('SetFocus(%s, %s)' % (cid, show_list_item))
    except Exception as e:
        __log('ERROR in showEPGm SetFocus: %r' % e)
        pass
    xbmcplugin.endOfDirectory(HANDLE)

def playEPG(idx):
    __log('playEPG(idx= %r)'% idx)
    __log('ADDON= %r' % ADDON)
    __log('PATH= %r' % PATH)
    __log('HANDLE= %r' % HANDLE)
    __log('PARAMS= %r' % PARAMS)
    __log('LOGO_PATH= %r' % LOGO_PATH)
    __log('FANART= %r' % FANART)
    try:
        __log('CHANNELS_URL ready to read: %r' % CHANNELS_URL)
        u = urlopen(CHANNELS_URL)
        channelList = simplejson.loads(u.read())
        ###__log('CHANNELS_URL channelList= %r' % channelList)
        datapath   = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        ChannelFile2 = os.path.join(datapath,ADDONid) + '_CHANNELS_URL.txt'
        utils.makeOldFile(ChannelFile2)
        text_file = open(ChannelFile2, "w")
        text_file.write(repr(channelList))
        text_file.close()
        __log('CHANNELS_URL read and copyed: %r' % (CHANNELS_URL))
        u.close()
    except Exception as  ex:
        __log('CHANNELS_URL ERROR: %r' % ex)
        showError(str(ex))
        return
    try:
        for channel in channelList:
            title = channel['Title']
            slug  = channel['Slug']
            if title[0:3] == 'DR ':
                title = title[3:]
            if title[0:2] != 'P4' and title[0:2] != 'P5':  ### 2023-11-02
                title = title[:2]
            __log('playEPG(title= %r slug= %r)'% (title,slug))
            idxlower = idx.lower()
            if (('p4' in idxlower and idxlower == slug) or idxlower[:2] == slug[:2] and not 'p4' in idxlower) or (('p5' in idxlower and idxlower == slug) or idxlower[:2] == slug[:2] and not 'p5' in idxlower): ### 2023-11-01
                sourceUrl = channel['SourceUrl']
                logoImage = xbmcvfs.translatePath(os.path.join(LOGO_PATH, sourceUrl[sourceUrl.rindex('/') + 1:] + '.png'))
                if xbmcvfs.exists(logoImage):
                    ###__log('logoImage EXISTS %r'% logoImage)
                    item = xbmcgui.ListItem(title)
                    item.setArt({ 'icon': logoImage, 'thumb' : logoImage })
                    limage = logoImage
                else:
                    ###__log('logoImage DO NOT EXISTS %r'% logoImage)
                    item = xbmcgui.ListItem(title)
                    item.setArt({ 'icon': ICON, 'thumb' : ICON })
                    limage = ICON
                item.setProperty('IsPlayable', 'true')
                item.setProperty('Fanart_Image', FANART)
                if INFO_TAG:
                    info_tag = ListItemInfoTag(item, 'music')
                    infolabels = { 'title': title} ###, 'genre': 'Not Set' }
                    info_tag.set_info(infolabels)
                    __log('1505 infolabels= %r' % infolabels)
                """
                item.setInfo(type='music', infoLabels={
                    'title': title,
                    #'tracknumber': 12345679,
                    #'discnumber': 13,
                    #'duration': 245999,
                    #'year': 1999,
                    ###'genre': 'genre1057',
                    #'album': 'Pulse1',
                    #'artist': 'Cat',
                    'rating': int(utils.ADDONgetSetting('setvolumen'))/10
                })
                """
                url = None

                if 'StreamingServers' in channel:
                    for server in channel['StreamingServers']:
                        if 'LinkType' in server and server['LinkType'] == 'ICY' and 'Qualities' in server:
                            try:
                                url = server['Server'] + '/' + server['Qualities'][0]['Streams'][0]['Stream']
                                break
                            except:
                                pass
                __log('playEPG(url 503= %r)'% url)
                if url:
                    __log('play-ing-EPG(url= %r)'% url)
                    __log('url= %r' % url)
                    ### data-urn="urn:dr:mu:bundle:5db189f16187cd0b88fe35b7">P5 Fyn<
                    ### data-urn="urn:dr:mu:bundle:5db18a716187cd0b88fe35c7">P5 København
                    ###url = url.replace('https://live-icy.dr.dk/A/A02H.mp3','http://live-icy.gss.dr.dk/A/A25L.mp3') ### P5 Fyn
                    url = url.replace('https://live-icy.dr.dk/A/A02H.mp3','http://live-icy.dr.dk/A/A28L.mp3')  ### P5 København 2023-10-04
                    ### https://live-icy.dr.dk/A/A08H.mp3
                    ### NO more url = url.replace('https://live-icy.dr.dk/','http://live-icy.gss.dr.dk/')  ### 2023-08-16 LibreELEC
                    __log('url= %r' % url)
                    ###direct_play(url)
                    
                    logoImage = xbmcvfs.translatePath(os.path.join(LOGO_PATH, title + '.png'))
                    item = xbmcgui.ListItem(path=url)
                    item.setArt({ 'icon': logoImage, 'thumb' : logoImage })
                    if INFO_TAG:
                        info_tag = ListItemInfoTag(item, 'music')
                        infolabels = { 'title': title} ###, 'genre': 'Not Set' }
                        info_tag.set_info(infolabels)
                        __log('1548 infolabels= %r' % infolabels)
                    """
                    item.setInfo(type='music', infoLabels={
                        'title': title,
                        #'tracknumber': 12345678,
                        #'discnumber': 12,
                        #'duration': 245000,
                        #'year': 1998,
                        ###'genre': 'genre1092', ###2023-09-24
                        #'album': 'Pulse',
                        #'artist': 'Muse',
                        'rating': int(utils.ADDONgetSetting('setvolumen'))/10
                    })
                    """
                    __log('ADDON= %r' % ADDON)
                    __log('PATH= %r' % PATH)
                    __log('HANDLE= %r' % HANDLE)
                    __log('PARAMS= %r' % PARAMS)
                    __log('LOGO_PATH= %r' % LOGO_PATH)
                    __log('FANART= %r' % FANART)
                    ###__log('xbmc.Player().isPlaying(520): %r' % xbmc.Player().isPlaying())
                    __log('1460 setSetting(programplaying= %r' % idx)
                    utils.ADDONsetSetting('programplaying',idx)
                    xbmcplugin.setResolvedUrl(HANDLE, True, listitem = item)
                    xbmc.executebuiltin('Dialog.Close(busydialog)')
                    utils.logdev('window','PlayEPG module= %r, CurrentWindowIdWindowId= %r' % (module, xbmcgui.getCurrentWindowId()))
                    xbmc.executebuiltin("Container.Refresh")
                    ###__log('xbmc.Player().isPlaying(523): %r' % xbmc.Player().isPlaying())
                    __log('play-ing-EPG-started(url= %r)'% url)
                    break   ### Stop at first match
    except Exception as e:
        pass
        __log('PlayEPG idx: %r\nERROR: %r' % e)

"""
listitem.setInfo(type='Music', infoLabels={'title': a.get('title') or '',
                                           'artist': a.get('artist') or '',
                                           'album': a.get('artist') or '',
                                           'duration': a.get('duration') or 0,
                                           'genre': 'Karaoke',
                                           'lyrics': lyrics})
                                           
setInfo(type, infoLabels)[source]
Sets the listitem’s infoLabels.

Parameters:	
type – string - type of
infoLabels – dictionary - pairs of { label: value }
Available types

Command name	Description
video	Video information
music	Music information
pictures	Pictures informanion
game	Game information
To set pictures exif info, prepend exif: to the label. Exif values must be passed as strings, separate value pairs with a comma. (eg. ``{‘exif:resolution’: ‘720,480’}`` See kodi_pictures_infotag for valid strings.

You can use the above as keywords for arguments and skip certain optional arguments. Once you use a keyword, all following arguments require the keyword.

General Values (that apply to all types):

Info label	Description
count	integer (12) - can be used to store an id for later, or for sorting purposes
size	long (1024) - size in bytes
date	string (d.m.Y / 01.01.2009) - file date

Video Values:
Info label	Description
genre	string (Comedy) or list of strings ([“Comedy”, “Animation”, “Drama”])
country	string (Germany) or list of strings ([“Germany”, “Italy”, “France”])
year	integer (2009)
episode	integer (4)
season	integer (1)
sortepisode	integer (4)
sortseason	integer (1)
episodeguide	string (Episode guide)
showlink	string (Battlestar Galactica) or list of strings ([“Battlestar Galactica”, “Caprica”])
top250	integer (192)
setid	integer (14)
tracknumber	integer (3)
rating	float (6.4) - range is 0..10
userrating	integer (9) - range is 1..10 (0 to reset)
watched	depreciated - use playcount instead
playcount	integer (2) - number of times this item has been played
overlay	integer (2) - range is 0..7 . See Overlay icon types for values
cast	list ([“Michal C. Hall”,”Jennifer Carpenter”]) - if provided a list of tuples cast will be interpreted as castandrole
castandrole	list of tuples ([(“Michael C. Hall”,”Dexter”), (“Jennifer Carpenter”,”Debra”)])
director	string (Dagur Kari) or list of strings ([“Dagur Kari”, “Quentin Tarantino”, “Chrstopher Nolan”])
mpaa	string (PG-13)
plot	string (Long Description)
plotoutline	string (Short Description)
title	string (Big Fan)
originaltitle	string (Big Fan)
sorttitle	string (Big Fan)
duration	integer (245) - duration in seconds
studio	string (Warner Bros.) or list of strings ([“Warner Bros.”, “Disney”, “Paramount”])
tagline	string (An awesome movie) - short description of movie
writer	string (Robert D. Siegel) or list of strings ([“Robert D. Siegel”, “Jonathan Nolan”, “J.K. Rowling”])
tvshowtitle	string (Heroes)
premiered	string (2005-03-04)
status	string (Continuing) - status of a TVshow
set	string (Batman Collection) - name of the collection
setoverview	string (All Batman movies) - overview of the collection
tag	string (cult) or list of strings ([“cult”, “documentary”, “best movies”]) - movie tag
imdbnumber	string (tt0110293) - IMDb code
code	string (101) - Production code
aired	string (2008-12-07)
credits	string (Andy Kaufman) or list of strings ([“Dagur Kari”, “Quentin Tarantino”, “Chrstopher Nolan”]) - writing credits
lastplayed	string (Y-m-d h:m:s = 2009-04-05 23:16:04)
album	string (The Joshua Tree)
artist	list ([‘U2’])
votes	string (12345 votes)
path	string (/home/user/movie.avi)
trailer	string (/home/user/trailer.avi)
dateadded	string (Y-m-d h:m:s = 2009-04-05 23:16:04)
mediatype	string - “video”, “movie”, “tvshow”, “season”, “episode” or “musicvideo”
dbid	integer (23) - Only add this for items which are part of the local db. You also need to set the correct ‘mediatype’!

Music Values:
Info label	Description
tracknumber	integer (8)
discnumber	integer (2)
duration	integer (245) - duration in seconds
year	integer (1998)
genre	string (Rock)
album	string (Pulse)
artist	string (Muse)
title	string (American Pie)
rating	float - range is between 0 and 10
userrating	integer - range is 1..10
lyrics	string (On a dark desert highway…)
playcount	integer (2) - number of times this item has been played
lastplayed	string (Y-m-d h:m:s = 2009-04-05 23:16:04)
mediatype	string - “music”, “song”, “album”, “artist”
dbid	integer (23) - Only add this for items which are part of the local db. You also need to set the correct ‘mediatype’!
listeners	integer (25614)
musicbrainztrackid	string (cd1de9af-0b71-4503-9f96-9f5efe27923c)
musicbrainzartistid	string (d87e52c5-bb8d-4da8-b941-9f4928627dc8)
musicbrainzalbumid	string (24944755-2f68-3778-974e-f572a9e30108)
musicbrainzalbumartistid	string (d87e52c5-bb8d-4da8-b941-9f4928627dc8)
comment	string (This is a great song)

Picture Values:
Info label	Description
title	string (In the last summer-1)
picturepath	string (/home/username/pictures/img001.jpg )
exif*	string (See kodi_pictures_infotag for valid strings)
                                           
"""

def playDR(idx):
    try:
        channel = None
        for c in channelsDR.CHANNELS:
            if c.id == int(idx):
                channel = c
                break

        if channel is None:
            return

        logoImage = xbmcvfs.translatePath(os.path.join(LOGO_PATH, str(channel.id) + '.png'))
        item = xbmcgui.ListItem(path=channel.url)
        item.setArt({ 'icon': logoImage, 'thumb' : logoImage })
        if INFO_TAG:
            info_tag = ListItemInfoTag(item, 'music')
            infolabels = { 'title': channel.name} ###, 'genre': 'Not Set' }
            info_tag.set_info(infolabels)
            __log('1715 infolabels= %r' % infolabels)
        """
        item.setInfo(type='music', infoLabels={
            'title': channel.name,
			###'genre': 'genre1247',
            'rating': int(utils.ADDONgetSetting('setvolumen'))/10
        })
        """
        __log('play-ing-EPG(url= %r)'% channel.url)
        ###__log('xbmc.Player().isPlaying(546): %r' % xbmc.Player().isPlaying())
        __log('1610 setSetting(programplaying= %r' % idx)
        utils.ADDONsetSetting('programplaying',idx)
        xbmcplugin.setResolvedUrl(HANDLE, True, listitem = item)
        ###__log('xbmc.Player().isPlaying(549): %r' % xbmc.Player().isPlaying())
    except Exception as e:
        pass
        __log('playDR idx: %r\nERROR: %r' % (idx,e))
    
def playOther(idx):
    try:
        channel = None
        for c in channels.CHANNELS:
            if c.id == int(idx):
                channel = c
                break

        if channel is None:
            return

        logoImage = xbmcvfs.translatePath(os.path.join(LOGO_PATH, str(channel.id) + '.png'))
        item = xbmcgui.ListItem(path=channel.url)
        item.setArt({ 'icon': logoImage, 'thumb' : logoImage })
        if INFO_TAG:
            info_tag = ListItemInfoTag(item, 'music')
            infolabels = { 'title': channel.name} ###, 'genre': 'Not Set' }
            info_tag.set_info(infolabels)
            __log('1715 infolabels= %r' % infolabels)
        """
        item.setInfo(type='music', infoLabels={
            'title': channel.name,
            ###'genre': 'genre1272',
            'rating': int(utils.ADDONgetSetting('setvolumen'))/10
        })
        """
        __log('play-ing-EPG(url= %r)'% channel.url)
        if testHTTP(channel.url):
            ###__log('xbmc.Player().isPlaying(565): %r' % xbmc.Player().isPlaying())
            
            __log('1641 setSetting(programplaying= %r' % idx)
            utils.ADDONsetSetting('programplaying',idx)
            xbmcplugin.setResolvedUrl(HANDLE, True, listitem = item)
            ###__log('xbmc.Player().isPlaying(569): %r' % xbmc.Player().isPlaying())
        else:
            __log('NOT play-ing-EPG(url= %r)'% channel.url)
    except Exception as e:
        pass
        __log('playOther idx: %r\nERROR: %r' % (idx,e))
"""
preferredstation = utils.ADDONgetSetting('preferredstation') ### DR P4 København
backupstation    = utils.ADDONgetSetting('backupstation') ### DR P5
P4selected       = utils.ADDONgetSetting('selectedp4station')
"""
def setP4Channel(P4area):
    try:
        utils.ADDONsetSetting('selectedp4station',P4area)
        utils.logdev('window','setP4Channel module= %r, CurrentWindowIdWindowId= %r' % (module, xbmcgui.getCurrentWindowId()))
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        pass
        __log('setP4Channel ERROR: %r' % e) 
        
def setP5Channel(P4area):
    try:
        utils.ADDONsetSetting('selectedp5station',P4area)
        utils.logdev('window','setP5Channel module= %r, CurrentWindowIdWindowId= %r' % (module, xbmcgui.getCurrentWindowId()))
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        pass
        __log('setP5Channel ERROR: %r' % e)   

def setPref(P4area):
    try:
        utils.ADDONsetSetting('preferredstation',P4area)
        utils.logdev('window','setPref module= %r, CurrentWindowIdWindowId= %r' % (module, xbmcgui.getCurrentWindowId()))
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        pass
        __log('setPref ERROR: %r' % e)    
    
def setBckup(P4area):
    try:
        utils.ADDONsetSetting('backupstation',P4area)
        utils.logdev('window','setBckup module= %r, CurrentWindowIdWindowId= %r' % (module, xbmcgui.getCurrentWindowId()))
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        pass
        __log('setBckup ERROR: %r' % e)  
        
def setBckupBckup(P4area):
    try:
        utils.ADDONsetSetting('backupbackupstation',P4area)
        utils.logdev('window','setBckupBckup module= %r, CurrentWindowIdWindowId= %r' % (module, xbmcgui.getCurrentWindowId()))
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        pass
        __log('setBckupBckup ERROR: %r' % e)    
    
def setWanted(title):
    dummy = 'no selection'
    programswanted = [dummy,title]
    programswanted += utils.ADDONgetSetting('programswanted').split(',')
    programswanted = list(dict.fromkeys(programswanted))
    dialog = xbmcgui.Dialog()
    selection = dialog.multiselect(ADDON.getAddonInfo('name') + ' [COLOR red]' + ADDON.getLocalizedString(30403) + '[/COLOR]', programswanted)
    __log('Selection: %r\n%r' % (selection,programswanted))
    if selection != None:
        programsnow = []
        for prog in selection:
            programsnow.append(programswanted[prog])
        if programsnow == []:
            programsnow = programswanted
        programsnow = list(dict.fromkeys(programsnow))
        try:
            utils.ADDONsetSetting('programswanted',','.join(programsnow)) 
            utils.logdev('window','setWanted module= %r, CurrentWindowIdWindowId= %r' % (module, xbmcgui.getCurrentWindowId()))
            xbmc.executebuiltin("Container.Refresh")
        except Exception as e:
            pass
            __log('setWanted ERROR: %r' % e)    
    
def setNogop(title):
    programswanted = [title]
    programswanted += utils.ADDONgetSetting('programsnogo').split(',')
    programswanted = list(dict.fromkeys(programswanted))
    dialog = xbmcgui.Dialog()
    selection = dialog.multiselect(ADDON.getAddonInfo('name') + ' [COLOR red]' + ADDON.getLocalizedString(30403) + '[/COLOR]', programswanted)
    __log('Selection: %r\n%r' % (selection,programswanted))
    if selection != None:
        programsnow = []
        for prog in selection:
            programsnow.append(programswanted[prog])
        if programsnow == []:
            programsnow = programswanted
        programsnow = list(dict.fromkeys(programsnow))
        try:
            utils.ADDONsetSetting('programsnogo',','.join(programsnow))
            utils.logdev('window','setNogop module= %r, CurrentWindowIdWindowId= %r' % (module, xbmcgui.getCurrentWindowId()))            
            xbmc.executebuiltin("Container.Refresh")
        except Exception as e:
            pass
            __log('setNogopswitch ERROR: %r' % e)    
        
def switch(x):
    dialog = xbmcgui.Dialog()
    addons = []
    try:
        SwFileFolder = os.path.join(xbmcvfs.translatePath('special://masterprofile/'), 'addon_data','krogsbell.switchaddons')
        SwFile = os.path.join(SwFileFolder,'switchaddons.txt')
        if not os.path.exists(SwFileFolder):
            os.mkdir(SwFileFolder)
            open(SwFile, 'a').close()
        __log('SwFile= %r' % SwFile)
        switchfile = open(SwFile, 'r')
        addonsO = switchfile.read()
        switchfile.close() 
        if not ADDONid in addonsO:
            addonsO += '\n' + ADDONname + ':' + ADDONid
            addonsO = addonsO.replace('\n\n\n\n','\n').replace('\n\n\n','\n').replace('\n\n','\n')
            LF = open(SwFile, 'w')
            LF.write(addonsO)
            LF.close()
        utils.ADDONsetSetting('switchaddons',addonsO)
        if addonsO != '' :
            addonsO = addonsO.split('\n')
            for addon in addonsO:
                if addon != '':
                    __log('addon= %r' % addon)
                    newaddon = addon.split(':')
                    if newaddon[1] != ADDONid:
                        try:
                            testAddon = xbmcaddon.Addon(id=newaddon[1])
                            pathTOaddon = os.path.join(xbmcvfs.translatePath('special://home/addons'), newaddon[1])
                            if os.path.exists(pathTOaddon):
                                addons.append(newaddon)
                        except Exception as e:
                            pass
                            __log('testAddon FAILED= %r' % e)
    except Exception as e:
        pass
        addons.append(['ERROR',repr(e)])
    addons = sorted(addons)
    choises = []
    for choise in addons:
       choises.append(choise[0] + ': ' + choise[1])
    if len(choises) > 0:
        selected = dialog.select(ADDON.getAddonInfo('name') + ADDON.getLocalizedString(30418), choises)
        if selected != -1:
            __log('selected Addon= %r - %r' % (addons[selected][0],addons[selected][1]))
            IDdoADDON = addons[selected][1]
            __log('Start Addon= %r' % IDdoADDON)
            try:
                xbmc.executebuiltin('Dialog.Close(busydialog)')   ### 2019-09-03 needed to allow switch addon
                xbmc.executebuiltin('RunAddon(%s)' % IDdoADDON)   
            except Exception as e:
                pass
                __log('switch ERROR: %r' % e)            
            
def onlyAscii (unicrap):
    """This takes a UNICODE string and ignores all characters 128 (0x80) and higher
    """ 
    r = ''
    for i in unicrap:
        if ord(i) >= 0x80:
            pass
        else:
            r += str(i)
    return r

def showError(message):
    ###heading = buggalo.getRandomHeading()
    heading = ADDONname
    line1 = ADDON.getLocalizedString(30900)
    line2 = ADDON.getLocalizedString(30901)
    ###xbmcgui.Dialog().ok(heading, line1, line2, message)
    __log(heading+'\n'+line1+'\n'+line2+'\n'+message)
    
def findprogramsOLD():
    if utils.ADDONgetSetting('autorun').lower() == 'true':
        findP = utils.ADDONgetSetting('LastFindStation')  ### datestr(nowTS(),'h%Hm%Ms%S'))
        __log('findP= %r' % findP)
        if findP == '':
            delta = 800
        else:
            delta = nowTS() - TS(findP)
        __log('delta= %r' % delta)
        
        if delta > 700 or (not xbmc.Player().isPlaying() and delta > 60):
        ###if delta > 700:
            __log('Start findprograms OLD')
            findprograms('00:00:00')
        
def findprograms(delayHMS):
    ###count += 1
    utils.ADDONsetSetting('count','addon.py Line# %r, %r' % (2011,'findprograms(delayHMS= %r)'% delayHMS))
    StopAllStationAlarms()  ###Stop all previous alarms starting programs
    __log('Start findprograms:'+datestr(nowTS(),'d%dh%Hm%Ms%S'))
    utils.ADDONsetSetting('findprograms','Start findprograms:'+datestr(nowTS(),'d%dh%Hm%Ms%S'))
    script = os.path.join(ADDONpath, 'findstation.py')
    __log('script= %r' % script)
    nameAlarm = ADDONid + '-findstations-'+delayHMS.replace(':','')
    __log('nameAlarm= %r' % nameAlarm)
    ###delayHMS = '00:10:00'   ### Run every 10 minutes
    ###delayHMS = '00:00:00'   ### Run once
    __log('delayHMS= %r' % delayHMS)
    ###cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),%s,loop,silent)' % (nameAlarm, script, PATH,delayHMS,delayHMS)
    if delayHMS == '00:00:00':
        cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),%s,silent)' % (nameAlarm, script, PATH,delayHMS,delayHMS)
    else:
        cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),%s,loop,silent)' % (nameAlarm, script, PATH,delayHMS,delayHMS)
    __log('cmd= %s' % cmd)
    try:
        xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
        xbmc.executebuiltin(cmd)  # Activate
    except Exception as e:
        pass
        __log('findprograms ERROR: %r' % e)
    __log('FINISHED cmd= %s' % cmd)

if __name__ == '__main__':
    ADDON = xbmcaddon.Addon('plugin.audio.dr.dk.netradio')
    PATH = sys.argv[0]
    HANDLE = int(sys.argv[1])
    PARAMS = urlparse.parse_qs(sys.argv[2][1:])

    LOGO_PATH = xbmcvfs.translatePath(os.path.join(ADDON.getAddonInfo('path'), 'resources', 'logos'))
    ICON = xbmcvfs.translatePath(os.path.join(ADDON.getAddonInfo('path'), 'icon.png'))
    FANART = xbmcvfs.translatePath(os.path.join(ADDON.getAddonInfo('path'), 'fanart.jpg'))
    utils.ADDONsetSetting('PATH',str(PATH))
    __log('ADDON= %r' % ADDON)
    __log('sys.argv= %r' % sys.argv)
    __log('PATH= %r' % PATH)
    __log('HANDLE= %r' % HANDLE)
    __log('PARAMS= %r' % PARAMS)
    __log('LOGO_PATH= %r' % LOGO_PATH)
    __log('FANART= %r' % FANART)
    ###buggalo.SUBMIT_URL = 'http://tommy.winther.nu/exception/submit.php'
    try:
        utils.shareLogs(True)
        LastshareLogs = utils.ADDONgetSetting('LastshareLogs')
        utils.ADDONsetSetting('LastshareLogs',LastshareLogs)
        ###findprogramsOLD()    ### Check if findprograms are running - removed 2024-08-01
        if 'HANDLE' in PARAMS:
            HANDLE = PARAMS['HANDLE'][0] 
            __log('main HANDLE= %r' % HANDLE)
            HANDLE = int(HANDLE)
        if 'show' in PARAMS and PARAMS['show'][0] == 'dr':
            __log('showDRChannels X')
            showDRChannels()
        elif 'show' in PARAMS and PARAMS['show'][0] == 'other':
            __log('showOtherChannels X')
            showOtherChannels()
        elif 'show' in PARAMS and PARAMS['show'][0] == 'epg':
            __log('showEPG X')
            showEPG()
        elif 'show' in PARAMS and PARAMS['show'][0] == 'epga':
            __log('showEPGa X')
            showEPGa()
        elif 'show' in PARAMS and PARAMS['show'][0] == 'epgm':
            __log('showEPGm X')
            showEPGm()
        elif 'show' in PARAMS and PARAMS['show'][0] == 'drx':
            showDRxChannels()
        elif 'playEPG' in PARAMS:
            __log('playEPG= %r' % PARAMS['playEPG'][0])
            playEPG(PARAMS['playEPG'][0])
        elif 'playDR' in PARAMS:
            __log('playDR= %r' % PARAMS['playDR'][0])
            playDR(PARAMS['playDR'][0])
        elif 'playOther' in PARAMS:
            __log('playOther= %r' % PARAMS['playOther'][0])
            playOther(PARAMS['playOther'][0])
        elif 'setP4' in PARAMS:
            __log('setP4= %r' % PARAMS['setP4'][0])
            setP4Channel(PARAMS['setP4'][0])
        elif 'setP5' in PARAMS:
            __log('setP5= %r' % PARAMS['setP5'][0])
            setP5Channel(PARAMS['setP5'][0])
        elif 'setPref' in PARAMS:
            __log('setPref= %r' % PARAMS['setPref'][0])
            setPref(PARAMS['setPref'][0])
        elif 'setBckup' in PARAMS:
            __log('setBckup= %r' % PARAMS['setBckup'][0])
            setBckup(PARAMS['setBckup'][0])
        elif 'setBckupBckup' in PARAMS:
            __log('setBckupBckup= %r' % PARAMS['setBckupBckup'][0])
            setBckupBckup(PARAMS['setBckupBckup'][0])
        elif 'setWanted' in PARAMS:
            __log('setWanted= %r' % PARAMS['setWanted'][0])
            setWanted(PARAMS['setWanted'][0])
        elif 'setNogop' in PARAMS:
            __log('setNogop= %r' % PARAMS['setNogop'][0])
            setNogop(PARAMS['setNogop'][0])
        elif 'switch' in PARAMS:
            __log('switch= %r' % PARAMS['switch'][0])
            switch(PARAMS['switch'][0])
        elif 'resetSet' in PARAMS:
            __log('resetSet= %r' % PARAMS['resetSet'][0])
            utils.ADDONresetSettingsToIni()
        elif 'start' in PARAMS:   ### Debug
            __log('start= %r' % PARAMS['start'][0])
            StartProgram(PARAMS['start'][0],nowTS())
        ###elif 'find' in PARAMS:    ### Debug   ### 2024-07-31 removed
        ###    __log('find= %r' % PARAMS['find'][0])
        ###    findprograms('00:00:00')
        elif 'mode' in PARAMS:    ### Debug
            mode = PARAMS['mode'][0]
            __log('2197 mode= %r' % mode)
            __log('2198 PARAMS= %r' % PARAMS['mode'])
            __log('2199 sys.argv= %r' % sys.argv)
            if mode=='10234':  ### 'Audio Volumen %' 
                __log('error 10234 mode= %r' % mode)
                try:  
                    __log('error Player.setAudioDelay .250')
                    xbmc.executebuiltin("Player.setAudioDelay(0.250)")
                except Exception as e:
                    pass
                    __log('error 4720 Player.setAudioDelay Exception: %r' % e)
                lastAudioLevel = utils.ADDONgetSetting('lastAudioLevel')
                utils.setAudioLevel(sys.argv[3])

            elif mode=='10233':  ### 'Audio Volumen %' 
                __log('error 10233 mode= %r' % mode)
                try:  
                    __log('error Player.setAudioDelay .250')
                    xbmc.executebuiltin("Player.setAudioDelay(0.250)")
                except Exception as e:
                    pass
                    __log('error 4720 Player.setAudioDelay Exception: %r' % e)
                lastAudioLevel = utils.ADDONgetSetting('lastAudioLevel')
                defaultlevels = ['0','10','30','50','75','80','85','90','95','100']
                levels = ['Set']
                i = 0
                preselect = 0
                defaultset = False
                for lev in defaultlevels :
                    if int(lev) == int(lastAudioLevel):
                        preselect = i
                        levels.append(lev)
                        defaultset = True
                        i += 1
                    elif int(lev) > int(lastAudioLevel) and defaultset == False :
                        preselect = i
                        levels.append(lastAudioLevel)
                        defaultset = True
                        i += 1
                        levels.append(lev)
                        i += 1
                    else:
                        levels.append(lev)
                        i += 1
                ###levels = [lastAudioLevel,'0','10','30','50','75','80','85','90','95','100',lastAudioLevel]
                level = xbmcgui.Dialog().select('Select Volumen Level', levels, preselect= preselect+1, autoclose=25000)
                if level == 0:
                    ###xbmcgui.Dialog().numeric(type, heading[, defaultt, bHiddenInput])
                    newvol = xbmcgui.Dialog().numeric(0,'Set Volumen Level', lastAudioLevel)
                    __log('error level numeric newvol= %r' % newvol)
                    if int(newvol) >= 0 and int(newvol) <= 100:
                        utils.setAudioLevel(newvol)
                elif level != -1:
                    level = levels[level]
                    if int(level) >= 0 :
                        utils.setAudioLevel(level)
               
            elif mode=='10232':  ### Stop player and set volumen to default level
                __log('error 10232 mode= %r' % mode)
                try:   ### Experimental 2023-11-08 - not working
                    __log('error Player.setAudioDelay .250')
                    xbmc.executebuiltin("Player.setAudioDelay(0.250)")
                except Exception as e:
                    pass
                    __log('error 4720 Player.setAudioDelay Exception: %r' % e)
                utils.setDefaultVideoLevel()
            else:
                dialog = xbmcgui.Dialog()
                lastselectedchannel = utils.ADDONgetSetting('lastselectedchannel')
                __log('3010 lastselectedchannel= %r' % lastselectedchannel)
                AllChannels = getDRChannels() + getOtherChannels()
                lastselectedchannelnumber = 0
                j = 0
                for cha in AllChannels:
                    __log('3010 cha= %r\nlastselectedchannel= %r, j= %r' % (cha,lastselectedchannel,j))
                    if cha == lastselectedchannel:
                        __log('3010 cha= %r, j= %r' % (cha,j))
                        lastselectedchannelnumber = j
                        break
                    j+=1
                channel = AllChannels[dialog.select(ADDON.getAddonInfo('name') + ADDON.getLocalizedString(30419), AllChannels, False, lastselectedchannelnumber)]
                __log('3010 channel= %r' % channel)
                utils.ADDONsetSetting('lastselectedchannel',str(channel))
                dayofweek = str(dialog.select(ADDON.getAddonInfo('name') + ADDON.getLocalizedString(30418), DaysOfWeek))
                __log('3010-3= %r' % dayofweek)
                actualschedule = 'schedule' + dayofweek
                __log('actualschedule= %r' % actualschedule)      
                schedule = utils.ADDONgetSetting(actualschedule)
                __log('3010-1= %r' % schedule)
                __log('3010-2= %r' % channel)
                starttime= utils.ADDONgetSetting('starttime')
                newstarttime = utils.Numeric(starttime,ADDON.getLocalizedString(30505))
                utils.ADDONsetSetting('starttime',newstarttime)
                __log('3010-4= %r' % newstarttime)
                endtime  = utils.ADDONgetSetting('endtime')
                newendtime = utils.Numeric(endtime,ADDON.getLocalizedString(30506))
                utils.ADDONsetSetting('endtime',newendtime)
                __log('3010-5= %r' % newendtime)
                newschedule = channel + '@' + newstarttime + '-' + newendtime
                if not newschedule in schedule:
                    utils.ADDONsetSetting(actualschedule,newschedule + ',' + schedule)
                schedule = utils.ADDONgetSetting(actualschedule)
                __log('3010-6= %r' % schedule)
        else:
            showOverview()

    except Exception as e:
        ###buggalo.onExceptionRaised()
        __log('No buggalo - Error: %r' % e)
