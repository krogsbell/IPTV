#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmcaddon
import xbmc
import xbmcgui
import xbmcvfs
import gzip
import os
import base64
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import shutil
from StringIO import StringIO
import xml.etree.ElementTree as etree
import re
import datetime
import xmltodict
from operator import itemgetter


###id = 'service.rytecepgdownloader'
###addon = xbmcaddon.Addon(id=id)
addon = xbmcaddon.Addon()
IMAGE = os.path.join(addon.getAddonInfo('path'), 'icon.png')
status = ['','','']

def logX(message):
    xbmc.log('[Rytec EPG Downloader common.py]: '  + message)

def log(message):
    module = 'common.py'
    nowHMS=datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    datapath = xbmc.translatePath(addon.getAddonInfo('profile'))
    addonlog = os.path.join(datapath, 'addon.log')
    LogDev = open(addonlog, 'a')
    # Write to our text file the information we have provided and then goto next line in our file.
    LogDev.write(nowHMS + ' ' + module + ': ' + message + '\n')

"""def logbox(message):
    cmd  = 'XBMC.Notification(%s, %s, %d, %s)' % ('[Rytec EPG Downloader]', '<' + message + '>', 9999, IMAGE)
    log(message)
    addon.setSetting('status',message)
    if addon.getSetting('notification') == 'Yes':
        xbmc.executebuiltin(cmd)
"""        
def logbox(message):
    cmd  = 'XBMC.Notification(%s, %s, %d, %s)' % ('[Rytec EPG Downloader]: ', message, 9999, IMAGE)
    log('0. message= %r, status= %r' % (message,status))
    if message != status[0]:
        status[2] = status[1]
        status[1] = status[0]
        status[0] = message
        log('1. message= %r, status= %r' % (message,status))
        addon.setSetting('status',status[0])
        addon.setSetting('status1',status[1])
        addon.setSetting('status2',status[2])
        if addon.getSetting('notification') == 'Yes':
            xbmc.executebuiltin(cmd)

def makeOldFile(file):
    log('makeOldFile= %r' % file)
    # f is a file-like object. 
    #f.seek(0, os.SEEK_END)
    #size = f.tell()
    #statinfo = os.stat('somefile.txt')
    try:
        log('1makeOldFile= %r' % file)
        tst = xbmcvfs.exists(file)
        log('1amakeOldFile= %r' % file)
        if tst:
        ###if os.path.isfile(file):
            log('2makeOldFile= %r' % file)
            rtst = xbmcvfs.File(file,'r')
            log('3makeOldFile= %r' % file)
            size = rtst.read(100)
            log('size = rtst.read(100): %r' % size)
            log('4makeOldFile= %r' % file)
            if len(size) > 0:
                ext = '.' + file.split('.')[-1]
                new = 'OLD' + ext
                log('5makeOldFile= %r' % file)
                oldfile = file.replace(ext,new)
                log('6oldfile= %r' % oldfile)
                ###xbmcvfs.copy( os.path.join( temp_destination, filename ).replace( "\\\\", "\\"), os.path.join( trailer_settings[ "trailer_download_folder" ], filename ).replace( "\\\\", "\\" ) )
            
                log('makeOldFile= %r' % file)
                xbmcvfs.copy(file,oldfile)
                log('7makeOldFile= %r' % file)
                ###shutil.copyfile(file, oldfile)
            else:
                log('oldfile has size %r' % len(size))
        else:
            log('makeOldFile: Do not exist: %r' % file)
    except Exception, e:
        pass
        log('makeOldFile of %r FAILED: %r' % (file, e))
            
def parse_date_string(dateString):
    ###ValueError: time data '20170625070000 +0100' does not match format '%Y%m%d%H%M%S z'
    ###return time.mktime(time.strptime(dateString.encode('utf-8', 'replace'), '%Y%m%d%H%M%S Z'))  ### UTC time
    ###utils.logdev('resulttime0',repr(dateString))
    dt = dateString.split(' ')
    if int(dt[0]) < 0:
        dateStringOLD = dateString
        utils.logdev('resulttime0',repr(dateString))
        utils.logdev('parse_date_string0','dt[0]= %r' % dt[0])
        dateString = dateStringDummy
        dt = dateString.split(' ')
    resulttime = time.mktime(time.strptime(dt[0], '%Y%m%d%H%M%S'))
    resulttime =  int(resulttime) - (int(dt[1])/100 - TimeZone)*3600
    return str(resulttime)
    
def parse_date_stringXML(dateString):
    dt = dateString.split(' ')
    if int(dt[0]) < 0:
        dateStringOLD = dateString
        dateString = dateStringDummy
        dt = dateString.split(' ')
    resulttime = time.mktime(time.strptime(dt[0], '%Y%m%d%H%M%S'))
    resulttime =  int(resulttime) - (int(dt[1])/100 - TimeZoneXML)*3600
    return str(resulttime)     

def element_to_string(element):
    s = element.text or ""
    for sub_element in element:
        s += etree.tostring(sub_element)
    s += element.tail
    return s
    
def setchannels(sources_list):
    ###logbox('set Channels called with sources_list= %r' % sources_list)
    ### sources_list=rytec.get_sources_list()
    channelnocontent = [addon.getSetting('xmltv_1'), addon.getSetting('xmltv_2'), addon.getSetting('xmltv_3'), addon.getSetting('xmltv_4'), addon.getSetting('xmltv_5'), addon.getSetting('xmltv_6'), addon.getSetting('xmltv_7'), addon.getSetting('xmltv_8'), addon.getSetting('xmltv_9'), addon.getSetting('xmltv_10'), addon.getSetting('xmltv_11'), addon.getSetting('xmltv_12'), addon.getSetting('xmltv_13'), addon.getSetting('xmltv_14'), addon.getSetting('xmltv_15')]
    choises = ['None']
    for source in sources_list:
        channeldesc = element_to_string(source[0]).replace('\n\t','')
        if '\n' in channeldesc:
            channeldesc = channeldesc.split('\n')[0]
        log('channeldesc= %r' % channeldesc)
        choises.append(channeldesc)
    channelno = ['xmltv_1','xmltv_2','xmltv_3','xmltv_4','xmltv_5','xmltv_6','xmltv_7','xmltv_8','xmltv_9','xmltv_10','xmltv_11','xmltv_12','xmltv_13','xmltv_14','xmltv_15']
    ###logbox('channelno= %r' % channelno)
    
    keyboard = 0
    while keyboard != -1:
        
        log('channelnocontent= %r' % channelnocontent)
        channels = []
        i = 0
        for ch in channelno:
            channels.append(ch + '= ' + channelnocontent[i])
            i += 1
        log('channels= %r' % channels)
        dialog = xbmcgui.Dialog()
        keyboard=dialog.select('Channel to adjust (Cancel when no more changes - OK to save!',channels)
        if keyboard != -1:
            log('keyboard= %r' % keyboard)
            ###choises = ['Dansk 1', 'Dansk 2', 'Dansk 3']
            selected = dialog.select(channelno[keyboard] + '= ' + channelnocontent[keyboard], choises ) 
            log('selected= %r'% selected)
            if selected != -1:
                log('setSetting(channelno[keyboard]= %r, choises[selected]= %r)' % (channelno[keyboard],choises[selected]))
                addon.setSetting(channelno[keyboard],choises[selected])
                nowHMS=datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                addon.setSetting('version',nowHMS)
                addon.setSetting('bt','')
                channelnocontent[keyboard] = choises[selected]
    
def get_descriptions():
    descriptions = []
    set = [addon.getSetting('xmltv_1'), addon.getSetting('xmltv_2'), addon.getSetting('xmltv_3'), addon.getSetting('xmltv_4'), addon.getSetting('xmltv_5'), addon.getSetting('xmltv_6'), addon.getSetting('xmltv_7'), addon.getSetting('xmltv_8'), addon.getSetting('xmltv_9'), addon.getSetting('xmltv_10'), addon.getSetting('xmltv_11'), addon.getSetting('xmltv_12'), addon.getSetting('xmltv_13'), addon.getSetting('xmltv_14'), addon.getSetting('xmltv_15')]
    for s in set:
        if s:
            if not s == 'None' or s.startswith('http'):
                descriptions.append(s)
    return descriptions

def load_local_xml(epg_url):
    if addon.getSetting('manual') == 'True':
        return True
    ret = False
    name = epg_url.split('/')[-1]
    xml_file = get_xml_file(name)
    if os.path.exists(xml_file):
        ret = check_date(xml_file)
    return ret

def get_description_url(description):
    epg_url = None
    try:
        epg_url = bdecode(addon.getSetting(description))
    except:
        log('no epg url found in settings ' + description)
    return epg_url

def save_epg_url(epg_url, description):
    addon.setSetting(description, bencode(epg_url))

def get_xml_path():
    xml_path = addon.getSetting('path').decode('utf-8')
    if not xml_path:
        addon.openSettings()
        xml_path = addon.getSetting('path').decode('utf-8')
    return xml_path

def get_xml_file(name):
    xml_path = get_xml_path()
    xml_file = os.path.join(xml_path, name)
    return xml_file

def bencode(original_string):
    encoded_string = base64.b64encode(original_string)
    return encoded_string

def bdecode(encoded_string):
    decoded_string = base64.b64decode(encoded_string)
    return decoded_string

def check_date(file):
    #cache_days = 3  # Original: cache_days = 3
    cache_days = 1
    modified_time = round(os.stat(file).st_mtime)
    current_time = round(time.time())
    t = current_time - modified_time
    if (t / 3600) < 24*cache_days:
        return True

def download_allowed(a):
    if addon.getSetting('manual') == 'True':
        return True
    gmt = time.gmtime()
    if gmt.tm_hour > 2 and gmt.tm_hour < 7:
        if not a:
            logbox('epg download not allowed between 3 and 7 GMT')
        return False
    else:
        return True
        
def get_counter():
    counter = addon.getSetting('counter')
    if not counter:
        counter = '0'
    return counter

def blocked(a):
    if addon.getSetting('manual') == 'True':
        return False
    counter = int(get_counter())
    ct = round(time.time())
    #log('blocked: ct= %s' % repr(ct))
    if counter == 0:
        counter += 1
        addon.setSetting('counter', str(counter))
        addon.setSetting('bt', str(ct).split('.')[0])
        return False
    elif counter == 1:
        counter += 1
        addon.setSetting('counter', str(counter))
        return False
    elif counter > 1:
        #log('blocked: bt= %s' % repr(addon.getSetting('bt')))
        try:
            bt = int(addon.getSetting('bt'))
        except:
            bt = 0
        t = ct - bt
        #log('blocked: t= %s' % repr(t))
        if (t / 3600) > 23:
            addon.setSetting('counter', '0')
            return False
        else:
            if not a:
                logbox('%sh blocked' % round(24 - (t / 3600),1))
            return True
    else:
        return True

def get_activation_code():
    code= bdecode('MzAyNQ==')
    addon.setSetting('ac',code)
    ac = addon.getSetting('ac')
    if bencode(ac) == 'MzAyNQ==':
        return True
    else:
        addon.openSettings()
        ac = addon.getSetting('ac')
        if bencode(ac) == 'MzAyNQ==':
            return True
        else:    
            return False

def mergesubtitles(b,newline,pattern,newlineback,divclass,subtitle):
    b = newline.sub(r'<newline></newline>', b)
    b = divclass.sub(r'[other]', b)
    ###b = subtitle.sub(r'[subtitles]', b)
    ###b = pattern.sub(' -x- ', b)   ### Seperator put between title and subtitle
    b = pattern.sub(' ', b) 
    
    b = newlineback.sub(r'\n', b) 
    b = b.replace('</sub-title>','</title>')
    return b
    
def fixepgidname(b):
    """
    <channel id="TV2.dk">
    <display-name lang="da">TV2</display-name>
    </channel>
    
    <channel id="TV2.dk">
    <display-name lang="da">TV2 dk</display-name>
    </channel>
    
    tv2 = re.compile(r'(<display-name lang=?da?>TV2</display-name>)', flags=re.DOTALL+re.MULTILINE)
    dr3 = re.compile(r'(<display-name lang=?da?>DR 3</display-name>)', flags=re.DOTALL+re.MULTILINE)
    b = tv2.sub('<display-name>TV2 dk</display-name>',b)
    b = dr3.sub('<display-name>DR3</display-name>',b)
    """
    ##b = b.replace('>TV2<','>TV2 no<',1)
    b = b.replace('da">TV2<','da">TV2 dk<',1)
    b = b.replace('>DR 3<','>DR3<',1)
    
    return b

def getDict(dictA,name,ntype='',dtype=''):
    ###if ADDON.getSetting('KeyErrorStop') != '':
    ### return ''
    element = ''
    en = "KeyError('" + name + "',)"
    ex = "KeyError('" + ntype + "',)"
    ey = "KeyError('" + dtype + "',)"
    if name == 'sub_title':
        return repr(dictA) + ' \n' + en  ### Debug option
    try:
        if dtype != '' and ntype != '':
            elementd = dictA[name][dtype]
            element = dictA[name][ntype]
            ###if type(element) in (list, tuple, dict):
            ### for elem in element:
            ###     return elem
            ###else:
            ###return repr(element)
            return element
    except Exception, e:
        pass
        err = repr(e)
        if err==en:
            return ''
        if err==ey:
            return 'ey1'
        if err==ex:
            return 'ex1'
    try:
        if ntype != '':
            element = dictA[name][ntype]
            ###if type(element) in (list, tuple, dict):
            ### for elem in element:
            ###     return elem
            ###else:
            ###return repr(element)
            return element
    except Exception, e:
        pass
        err = repr(e)
        if err==en:
            return ''
        if err==ex:
            return 'ex2'
    try:
        element = dictA[name]
        ###if type(element) in (list, tuple, dict):
        ### for elem in element:
        ###     return elem
        ###else:
        ###return repr(element)
        return element
    except Exception, e:
        pass
        err = repr(e)
        if err==en:
            return 'en3'
    return 'nothing'

def logchannelandprogramtimes(xmlfile,outL):
    log('logchannelandprogramtimes(outL)= %r'% outL)
    xmlfile = xmlfile.replace('\\','/')
    text = '\n\n\nlogchannelandprogramtimes(xmlfile)= ' + str(xmlfile)
    chanls = []
    progs = []
    try:    
        log(text)
        outL.write(text)
        outL.write('\n')
        log('logchannelandprogramtimes(EXIST xmlfile= %r)' % xmlfile)
        epgfile = xbmcvfs.File(xmlfile, 'r')
        dataepg = epgfile.read()
        epgfile.close() 
        dataepg = xmltodict.parse(dataepg)
        ###channelsxml = xmlfile.replace('.xml','.dict')
        ###log('logchannelandprogramtimes(channelsxml= %r \n)' % channelsxml)
        ###LF = xbmcvfs.File(channelsxml, 'wb')
        ###LF.write(str(dataepg))    #######
        ###LF.close()
        #######################
        ChannelFile = xmlfile
        try:
            datapanelEPG1 = dataepg['tv']
            datapanelEPG2 = dataepg['tv']['@generator-info-name']
            datapanelEPG3 = dataepg['tv']['@generator-info-url']
            outL.write('\n\ndatapanelEPG2 = dataepg[tv][@generator-info-name]= %r\n' % datapanelEPG2)
        except Exception, e:
            pass
            outL.write('\n\nError in datapanelEPG '+ str(ChannelFile) + ' \n' + repr(e)+ ' \n\n')
        EPGgeneratorName = getDict(dataepg,'tv','@generator-info-name')
        EPGgeneratorURL  = getDict(dataepg,'tv','@generator-info-url')
        if EPGgeneratorName == '' or EPGgeneratorURL == '':
            EPGgenerator = EPGgeneratorName + EPGgeneratorURL
        else:
            EPGgenerator = EPGgeneratorName + ' - ' + EPGgeneratorURL
        outL.write('\n\nlastEPGimportInfo %r\n\n' % EPGgenerator)
        try:
            datapanelEPG3 = dataepg['tv']['channel']
        except Exception, e:
            pass
            outL.write('\n\nError in datapanelEPG3 '+ repr(ChannelFile) + ' \n' + repr(e) + ' \n')
            datapanelEPG3 = []
        started = datetime.datetime.now()
        i = 0
        channels = 1
        programs = 1
        for cid in datapanelEPG3:
            xbmc.sleep(10)
            ###time.sleep(1/100)
            i += 1
            name = getDict(cid,'display-name','#text','@lang')
            iconimage = getDict(cid,'icon','@src')
            
            ###def addChannel(name,url,iconimage,cat,origin,visible=True,weight=0,description=''):
            ###outL.write('# %r id= %r, name= %r\n' % (channels,cid['@id'],name))
            chanls.append([cid['@id'],name])
            channels += 1
        ended = datetime.datetime.now()
        chanls = sorted(chanls, key=itemgetter(0))
        ###outL.write('chanls=%r\n' % chanls)

        ### (u'programme', [OrderedDict([(u'@start', u'20170613130000 +0100'), (u'@stop', u'20170613133000 +0100'), (u'@channel', u'I46817.labs.zap2it.com'), (u'title', u'ESPNEWS'), (u'desc', u'Sports news round-the-clock: highlights, scores, updates.')]),
        ### OrderedDict([(u'@start', u'20170618060000 +0000'), (u'@stop', u'20170618070000 +0000'), (u'@channel', u'BET:BlackEntTv.uk'), (u'title', OrderedDict([(u'@lang', u'en'), ('#text', u'Soul Sessions')])), (u'desc', OrderedDict([(u'@lang', u'en'), ('#text', u"The best of Neo-Soul, R&B and classic hits, and features music videos from today's hottest artist and music legends")]))]),
        try:
            datapanelEPG4 = dataepg['tv']['programme']
        except Exception, e:
            pass
            outL.write('\n\nError in dataepg[tv][programme] '+ ChannelFile + '\n' + repr(e))
            datapanelEPG4 = ''
        for prog in datapanelEPG4:
            xbmc.sleep(10)
            ###time.sleep(1/100)
            i += 1
                
            ###if ADDON.getSetting('KeyErrorStop') == '':
            ###utils.logdev('datapanelEPG4: for prog in datapanelEPG4[@start]',repr(prog['@start']))
            ###utils.logdev('datapanelEPG4: for prog in datapanelEPG4[@channel]',repr(prog['@channel']))
            channel = getDict(prog,'@channel')
            ###title = getDict(prog,'title','#text','@lang')
            ###sub_title = getDict(prog,'sub_title','#text','@lang')
            ###description = getDict(prog,'desc','#text','@lang')
            
            ###descrpanelEPG = 'channel\n@id= %r \ndisplay-name= %r \nicon[src]= %r' %(dataepg['tv']['channel']['@id'],dataepg['tv']['channel']['display-name'],dataepg['tv']['channel']['icon']['@src'])
            ###utils.logdev(module+' Start EPG',descrpanelEPG)
            ###def addEPGProgram(channel, title, sub_title, start_date, end_date, description='', categories='', image_large='', image_small='', season= '', episode='', is_movie='', language='', source='')
            ###.datetime.strptime(thetime, "%Y-%m-%dT%H:%M:%S%z")
            try:
                progs.append([channel,'',prog['@start'],prog['@stop']])
                ###outL.write('\nchannel= %r,prog[@start]= %r,prog[@stop]= %r\n' % (channel, prog['@start'], prog['@stop']))
            except Exception, e:
                pass
                outL.write('\n\nError getting program: %r\n' % e)
            programs += 1
  
        ###outL.write('progs=%r\n' % progs)
        progs = sorted(progs, key=itemgetter(2), reverse=True)
        progs = sorted(progs, key=itemgetter(0))
        for ch in  chanls:
            channel= ch[0]
            name = ch[1]
            for prog in progs:
                if prog[0] == ch[0]:
                    outL.write('ID= %r, Name= %r, Start= %r\n' % (ch[0],ch[1],prog[2]))
                    break
        ended = datetime.datetime.today()
        outL.write('\n\nlastEPGimport %s' % ended.strftime('%Y-%m-%d %H:%M:%S'))
        
        #######################
        
    except Exception, e: 
        log('error in logchannelandprogramtimes: ' + repr(e))
        pass

def removeGzXz():
    xml_path = get_xml_path()
    log('Delete old .gz and .xz files in xml_path= %r' % xml_path)
    dirs, files = xbmcvfs.listdir(xml_path)
    for f in files:
        if f.endswith('.gz'):
            log(repr(f))
            out = os.path.join(xml_path,f)
            if xbmcvfs.exists(out):
                xbmcvfs.delete(out) 
        if f.endswith('.xz'):
            out = os.path.join(xml_path,f)
            log(repr(f))
            if xbmcvfs.exists(out):
                xbmcvfs.delete(out)
        if f.endswith('.txt'):
            out = os.path.join(xml_path,f)
            log(repr(f))
            if xbmcvfs.exists(out):
                xbmcvfs.delete(out)

def FindPath():
    # Find the actual path
    # special://masterprofile/ is mapped to: C:\Users\hans\AppData\Roaming\Kodi\userdata
    log('FindPath')
    Platform = ''
    try:
        kodilog = xbmc.translatePath(os.path.join('special://logpath' , 'kodi.log'))
        try: csvfile = open(kodilog,'r')
        except:
            pass
            kodilog = xbmc.translatePath(os.path.join('special://logpath' , 'xbmc.log'))
            try: csvfile = open(kodilog,'r')
            except:
                pass
                kodilog = xbmc.translatePath(os.path.join('special://logpath' , 'tvmc.log'))
                try: csvfile = open(kodilog,'r')
                except:
                    pass
                    kodilog = xbmc.translatePath(os.path.join('special://logpath' , 'spmc.log'))
                    try: csvfile = open(kodilog,'r')
                    except:
                        pass
                        log('FindPath: csvfile not found')
        log('kodilog= %r' % kodilog)
        log('csvfile= %r' % csvfile)
        lines = csvfile.read(2000)
        log('lines= %r' % lines)
        Path = lines.split('special://masterprofile/ is mapped to: ',1)[1]
        log('Path= %r' % Path)
        Path = Path.split('\n',1)[0]   
        log('Path= %r' % Path)
    except: 
        pass
        log ('FindPath FAILED')   # Put in LOG
        Path = ''
    finally:
        csvfile.close()
    return Path
                
def runCommandTest(cmd):
    """
    set PATH=%PATH%;C:\Program Files\7-Zip\
    echo %PATH%
    7z
    """
    log('runCommandTest cmd= %r' % cmd) # Put in LOG
    from subprocess import Popen, PIPE, STDOUT
    # subpr = Popen(cmd, shell=True, env=env, stdin=PIPE, stdout=PIPE, stderr=STDOUT) # original
    subpr = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT) 
    x = subpr.stdout.read()
    log('runCommandTest x= %r' % x) # Put in LOG
    expectedresult = 'copyright'   ### 2017-12-16
    if expectedresult.lower() in x.lower():
        return True
    else:
        return False  
        
def runCommand(cmd):
    """
    set PATH=%PATH%;C:\Program Files\7-Zip\
    echo %PATH%
    7z
    """
    log('runCommand cmd= %r' % cmd) # Put in LOG
    from subprocess import Popen, PIPE, STDOUT
    # subpr = Popen(cmd, shell=True, env=env, stdin=PIPE, stdout=PIPE, stderr=STDOUT) # original
    subpr = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT) 
    x = subpr.stdout.read()
    log('runCommand x= %r' % x) # Put in LOG
    return x
                
def merge_epgJIN():
    xml_path = get_xml_path()
    temp_merged = get_temp_merged()
    ltw = None
    
    log('[Rytec EPG Downloader]: start merging files')
    dirs, files = xbmcvfs.listdir(xml_path)
    i=1
    total = len(files)
    for xmltv in files:
        if (xmltv.endswith('.gz') or xmltv.endswith('.xmlXXX') or xmltv.endswith('.xz')) and not xmltv.startswith('merged_epg.xml'):
            try:
                if xmltv.endswith('.gz'):
                    log('gz file: %r' % xmltv)
                    inF = gzip.GzipFile(fileobj=StringIO(xbmcvfs.File(os.path.join(xml_path,xmltv)).read()))
                elif xmltv.endswith('.xz'):
                    try:
                        import lzma
                        log('import lzma OK')
                    except ImportError:
                        from backports import lzma
                        log('from backports import lzma OK')
                    log('xz file: %r' % xmltv)
                    inF = lzma.open(xbmcvfs.File(os.path.join(xml_path,xmltv)), 'rb')
                else:
                    log('xml file: %r' % xmltv)
                    inF = xbmcvfs.File(os.path.join(xml_path,xmltv))
                b = inF.read()
                log('File read OK')
                inF.close()
                b = b.replace('</tv>','')
                if i==1:
                    ltw = b.splitlines()
                else:
                    lines = b.splitlines()
                    li = 0
                    for line in lines:
                        if li == 0 or li == 1: 
                            pass
                        else: 
                            ltw.append(line)
                        li += 1
                i += 1
            except Exception as e:
                log('[Rytec EPG Downloader]: error in merge epg')
                log(xmltv)
                log(e)
    
    if ltw:
        f_in = '\n'.join(ltw)
        f_in = f_in+'</tv>'
        f_out = gzip.open(temp_merged, 'wb')
        f_out.write(f_in)
        f_out.close()

    log('[Rytec EPG Downloader]: merging files done')
                
def merge_epg():
    # code from enen92. thank you
    merged_epg = 'merged_epg.xml'
    master     = 'master.xml'
    masterOLD  = 'masterOLD.xml'
    ltw = None
    log('merge epg') 
    xml_path = get_xml_path()
    temp = os.path.join(xml_path,'temp')
    if not xbmcvfs.exists(temp):
        xbmcvfs.mkdir(temp)
    dirs, xmltv_list = xbmcvfs.listdir(temp)
    for xmltv in xmltv_list:
        logbox('Delete file: %r ' % xmltv)
        xbmcvfs.delete(os.path.join(temp,xmltv))  ### Empty temp folder before merge
    
    out = os.path.join(xml_path,merged_epg)
    makeOldFile(out)
    ###if xbmcvfs.exists(out):
    ###    xbmcvfs.delete(out)  
    logbox('start extracting files')
    xmlfilelog = os.path.join(xml_path,'xmlfile.log')
    log('0 Open in Overwrite mode: %r' % xmlfilelog)
    makeOldFile(xmlfilelog)
    outL = xbmcvfs.File(xmlfilelog,'w')
    log('merge_epg(outL)= %r'% outL)
    log('1 Open in Overwrite mode: %r' % xmlfilelog)
    # If you need to use the regex more than once it is suggested to compile it.
    #pattern = re.compile(r'(</title>\s<sub-title[\w ="]{0,}>)', flags=re.MULTILINE)
    pattern = re.compile(r'(</title><newline></newline>[ ]{0,}<sub-title[\w ="]{0,}>)', flags=re.DOTALL+re.MULTILINE)
    title = re.compile(r'(</title><newline></newline>)', flags=re.DOTALL+re.MULTILINE)
    tv = re.compile(r'(</tv>)', flags=re.DOTALL+re.MULTILINE)
    newline = re.compile('([\n\r]{1,})', flags=re.DOTALL+re.MULTILINE)
    newline1 = re.compile(r'(\r\n)', flags=re.DOTALL+re.MULTILINE)
    newlineback = re.compile(r'(<newline></newline>)', flags=re.DOTALL+re.MULTILINE)
    slash = re.compile(r'(<newline></newline>)', flags=re.DOTALL+re.MULTILINE)
    divclass = re.compile(r'(<newline></newline>[ ]{0,}&lt;div class="other"&gt;)', flags=re.DOTALL+re.MULTILINE) ### one nonprintable character and <div class="other">
    subtitle = re.compile(r'(<newline></newline>(Subtitles))', flags=re.DOTALL+re.MULTILINE) ### (Subtitles)
    #pattern = re.compile(r'(regexp -all -- {(</title>\s<sub-title[ a-zA-Z0-9="]{0,}>)} string match v1)')
    #pattern = re.compile(r'regexp -nocase -all -line -inline -- {(\</title\>\s\<sub-title\w\>)} string')
    log('pattern= ' + repr(pattern))
    # <\/{0,}\[\d+>
    # 
    # Match the character “<” literally «<»
    # Match the character “/” literally «\/{0,}»
    #    Between zero and unlimited times, as many times as possible, giving back as needed (greedy) «{0,}»
    # Match the character “[” literally «\[»
    # Match a single digit 0..9 «\d+»
    #    Between one and unlimited times, as many times as possible, giving back as needed (greedy) «+»
    # Match the character “>” literally «>»
    #<title lang="cs">A Beautiful Mind</title>
    #<sub-title lang="cs">(A Beautiful Mind (7))</sub-title>
    #subject = """this is a paragraph with<[1> in between</[1> and then there are cases ... where the<[99> number ranges from 1-100</[99>. 
    #and there are many other lines in the txt files
    #with<[3> such tags </[3>"""

    #result = pattern.sub("", subject)
    
    dirs, files = xbmcvfs.listdir(xml_path)
    
    log(repr(files))
    """
    ii=0
    try:
        import tarfile
        for f in files:
            if f.endswith('.xz'):   ### Handle .xz files like .gz files 2017-11-19
                log(repr(os.path.join(xml_path,f)))
                ii+=1
                log(str(ii))
                fxzf = 'C:\\Users\\hans\\AppData\\Roaming\\Kodi\\userdata\\addon_data\\service.rytecepg.downloader\\rytecDK_XXX.gz'
                ii+=1
                log(str(ii))
                log(repr(fxzf))
                res = tarfile.is_tarfile(fxzf)
                ii+=1
                log(str(ii))
                log(repr(res))
                fxz = tarfile.open(fxzf)
                ii+=1
                log(str(ii))
                log(repr(fxz))
                ii+=1
                log(str(ii))
                fxzex = fxz.extract()
                ii+=1
                log(str(ii))
                log(repr(fxzex))
                ii+=1
                log(str(ii))
                with tarfile.open(os.path.join(xml_path,f)) as fxz:
                    fxz.extractall('.')
                ii+=1
                log(str(ii))
    except Exception, e:
        pass
        log('tarfile FAILED ii= %r ERROR= %r' % (ii,e))
    """
    """
    for xmltv in files:
        validzip = False
        if (xmltv.endswith('.gz') or xmltv.endswith('.xmlXXX') or xmltv.endswith('.xz')) and not xmltv.startswith('merged_epg.xml'):
            try:
                if xmltv.endswith('.gz'):
                    log('gz file: %r' % xmltv)
                    inF = gzip.GzipFile(fileobj=StringIO(xbmcvfs.File(os.path.join(xml_path,xmltv)).read()))
                    validzip = True
                elif xmltv.endswith('.xz'):
                    try:
                        import lzma
                        log('import lzma OK')
                    except ImportError:
                        from backports import lzma
                        log('from backports import lzma OK')
                    log('xz file: %r' % xmltv)
                    inF = lzma.open(xbmcvfs.File(os.path.join(xml_path,xmltv)), 'rb')
                    validzip = True
                else:
                    log('xml file: %r' % xmltv)
                    inF = xbmcvfs.File(os.path.join(xml_path,xmltv))
                    validzip = True
                
            except Exception, e: 
                log('error in unzipping: %r \nERROR: %r' % ( xmltv,e))
                pass
        else:
            log('Not a valid file: %r' % xmltv)  
        if validzip:
            b = inF.read()
            log('File read OK')
            inF.close()
            b = b.replace('</tv>','')
            if i==1:
                ltw = b.splitlines()
            else:
                lines = b.splitlines()
                li = 0
                for line in lines:
                    if li == 0 or li == 1: 
                        pass
                    else: 
                        ltw.append(line)
                    li += 1
            i += 1
    
    if ltw:
        f_in = '\n'.join(ltw)
        f_in = f_in+'</tv>'
        f_out = gzip.open(temp_merged, 'wb')
        f_out.write(f_in)
        f_out.close()

    log('[Rytec EPG Downloader]: merging files done')
    
    except Exception as e:
                log('[Rytec EPG Downloader]: error in merge epg')
                log(xmltv)
                log(e)
    """
    Program7zAvailable = runCommandTest('7z')
    ProgramxarchiverAvailable = runCommandTest('xarchiver -v')
    userdata= FindPath()
    slash = '\\'
    if not slash in userdata:
    	slash = '/'
    log('slash= %r' % slash)
    userdata = userdata + slash
    log('userdata= %r' % userdata)
    for f in files:
        if f.endswith('.gz'):
            log(repr(f))
            inF = gzip.GzipFile(fileobj=StringIO(xbmcvfs.File(os.path.join(xml_path,f)).read()))
            s = inF.read()
            inF.close()
            outF = xbmcvfs.File(os.path.join(temp,f.replace('.gz','.xml')), 'wb')
            outF.write(s)
            outF.close()
        if f.endswith('.xz'):   ### Handle .xz files like .gz files 2017-11-19
            log(repr(f))
            try:
                import lzma
                log('lzma loaded')
            except ImportError:
                pass
                try:
                    import setup
                    log('backports setup loaded')
                    from backports import lzma
                    log('backports loaded')
                except ImportError:
                    pass
                    log('backports NOT loaded')
            try:
                ###print lzma.open('file.xz').read()
                
                ###inF = lzma.open(fileobj=StringIO(xbmcvfs.File(os.path.join(xml_path,f))), mode='rt', encoding='utf-8')
                log('xz file: %r' % os.path.join(xml_path,f))
                if Program7zAvailable:
                    ifile = os.path.join(xml_path,f).replace('special://masterprofile/',userdata).replace('/',slash)
                    log('ifile= %r' % ifile)
                    odir = (temp+slash).replace('special://masterprofile/',userdata).replace('/',slash)
                    log('odir= %r' % odir)
                    inF = runCommand('7z l '+ ifile)
                    inF = runCommand('7z e ' + ifile + ' -y -aoa -r -o' + odir)
                elif ProgramxarchiverAvailabe:                
                    ifile = os.path.join(xml_path,f).replace('special://masterprofile/',userdata).replace('/',slash)
                    odir = (temp+slash).replace('special://masterprofile/',userdata).replace('/',slash)
                    inF = runCommand('xarchiver -x ' + odir + ' ' + ifile)
                else:
                    inF = lzma.open(os.path.join(xml_path,f))
                    s = inF.read()
                    inF.close()
                    outF = xbmcvfs.File(os.path.join(temp,f.replace('.xz','.xml')), 'wb')
                    outF.write(s)
                    outF.close()
            except Exception:
                pass
                log('backports/lzma NOT loaded, 7z or xarchiver not available - xml file ignored: %r' % f)
  
    logbox('start merging files')
    #Save old file to masterOLD.xml
    try:
        makeOldFile(os.path.join(xml_path,master))
        ###source = os.path.join(xml_path,master) 
        ###dest = os.path.join(xml_path,masterOLD)
        ###if os.path.isfile(source) == True:
        ###    log('Make old file: \nsource= %r ==> \ndestination= %r' % (source, dest))
        ###    shutil.copy(source, dest)
    except Exception, e: 
        log('error in copy old master.xml: ' + repr(e))
        pass
    dirs, xmltv_list = xbmcvfs.listdir(temp)
    i=1
    total = len(xmltv_list)
    log('xmltv_list= %r' % xmltv_list)
    for xmltv in xmltv_list:
        ###if xmltv.endswith('.xml'):
        log('xmltv file ' + repr(i) + ': ' + repr(xmltv))
        xmlfile = os.path.join(temp,xmltv)
        ###xmlfilelog = xmlfile.replace('.xml','.txt')  ### Log channel and program times
        logchannelandprogramtimes(xmlfile,outL)
        
        if addon.getSetting('mergetitles') == 'Yes':
            mergetitles = True
            logbox('merging files and titles with sub-titles: ' + xmltv)
        else:
            mergetitles = False
            logbox('merging files: ' + xmltv)
                
        if i==1:
            f = xbmcvfs.File(os.path.join(temp,xmltv))
            b = f.read()
            b = tv.sub('', b)
            b = fixepgidname(b)
            if mergetitles:
                b = mergesubtitles(b,newline,pattern,newlineback,divclass,subtitle)
            f.close()
            ltw = b.splitlines()
        else:
            f = xbmcvfs.File(os.path.join(temp,xmltv),'r')
            b = f.read()
            b = tv.sub('', b)
            b = fixepgidname(b)
            if mergetitles:
                b = mergesubtitles(b,newline,pattern,newlineback,divclass,subtitle)
            lines = b.splitlines()
            f.close()
            li = 0
            for line in lines:
                if li == 0 or li == 1: pass
                else: ltw.append(line)
                li += 1
        xbmcvfs.delete(os.path.join(temp,xmltv)) ### Delete used xml files
        i += 1
    
    o = xbmcvfs.File(out,'wb')   ### 2017-11-06
    log('merge_epg(o)= %r'% o)
    j = 0
    for line in ltw:
        o.write(line.strip() + '\n')
        j += 1
    o.write('</tv>'+ '\n')
    if line: log('last writen line= ' + repr(j) + ': ' + repr(line))
    o.close()
    outL.close()
    logbox('merging files done')
    #Copy final file to master.xml
    source = os.path.join(xml_path,merged_epg)
    dest = os.path.join(xml_path,master)
    try:
        log('merged_epg: %r --> \nmaster: %r' % (source, dest))
        ###if os.path.isfile(source) == True:
        if xbmcvfs.exists(source):
            log('Copy final file to dest= %r' % dest)
            xbmcvfs.copy(source, dest)
            ### shutil.copy(source, dest)
    except Exception, e:
        pass 
        log('Copy final file to dest= %r FAILED: %r' % (dest, e))
   
    now= datetime.datetime.today().strftime('%Y-%m-%d %H:%M')
    addon.setSetting('lastupdate',now)
