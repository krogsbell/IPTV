#!/usr/bin/python
# -*- coding: utf-8 -*-
import recordings, utils, locking
import xbmcaddon, xbmc, datetime

import definition
ADDON      = definition.getADDON()
xbmc.log('service.py in %s' % ADDON.getAddonInfo('name'))
module= 'service.py'
utils.logdev(module,'Start')
utils.logdev('Version',utils.version())	
utils.logdev('VersionDate',utils.versiondate())

try:
	Platform = utils.rtmpdumpFilename()
	if not Platform == '':
		utils.notification('[COLOR green]Platform found and set[/COLOR]')
except:
	pass
	utils.logdev('FindPlatform','FAILED')  # Put in LOG
locking.recordUnlockAll()
locking.scanUnlockAll()
locking.markUnlockAll()
recordings.backupSetupxml()
recordings.restoreLastSetupXml()
utils.logdevreset()
recordings.ftvntvlist()  ### also made after EPG Update
###recordings.downloadicons()
ADDON.setSetting('allmessages','')
ADDON.setSetting('RecursiveSearch','false')
ADDON.setSetting('RecordingFromOtherAddon','0')
ADDON.setSetting('Recordings','')   ### Reset setting with recording names
ADDON.setSetting('castsubpr','')    ### Reset cast info
ADDON.setSetting('castsubprcmd','')
if ADDON.getSetting('enable_record')=='true':
	now = recordings.parseDate(datetime.datetime.now()) 
	startDate=now - datetime.timedelta(days = 10)
	endDate=now + datetime.timedelta(days = 100)
	recordingsActive=recordings.getRecordingsActive(startDate, endDate)
	utils.logdev('recordingsActive',repr(recordingsActive))
	try:
		recordings.backupDataBase()
		recordings.reschedule()
		utils.notification('[COLOR green]Reschedule Complete[/COLOR]')
		ADDON.setSetting('DebugRecording','false')
	except:
		pass
		utils.notification('[COLOR red]Reschedule failed:[/COLOR] Check your planned recordings! - Recording Debug has been set')
		ADDON.setSetting('DebugRecording','true')
		xbmc.sleep(5000)

