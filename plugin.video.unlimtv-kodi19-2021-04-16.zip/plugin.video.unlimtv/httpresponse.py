#!/usr/bin/python
# -*- coding: utf-8 -*-
import gzip
from io import StringIO
import re
from logger import Log
import utils

def log(message):
    module = 'httpresponse.py'
    utils.logdev(module,message)
    

class HttpResponse:
    '''
    This class represents a resoponse from an HTTP request.

    The content is examined and every attempt is made to properly encode it to
    Unicode.

    .. seealso::
        :meth:`Net.http_GET`, :meth:`Net.http_HEAD` and :meth:`Net.http_POST`
    '''

    content = ''
    '''Unicode encoded string containing the body of the reposne.'''

    def __init__(self, response):
        '''
        Args:
            response (:class:`mimetools.Message`): The object returned by a call
            to :func:`urllib2.urlopen`.
        '''
        self._response = response
        log('response= %r' % response)
        html = response.read()
        try:
            html = html.encode()
        except Exception as e:
            pass
            
        log('1 html= %r' % html)
        try:
            log('gzip?')
            if response.headers['content-encoding'].lower() == 'gzip':
                html = gzip.GzipFile(fileobj=StringIO.StringIO(html)).read()
                log('2 html= %r' % html)
        except Exception as e:
            pass
            log('1 Exception= %r' % e)
        try:
            content_type = response.headers['content-type']
            log('1 content_type= %r' % content_type)
            if 'charset=' in content_type:
                log('2 content_type= %r' % content_type)
                encoding = content_type.split('charset=')[-1]
                log('3 content_type= %r' % content_type)
        except Exception as e:
            pass
            log('2 Exception= %r' % e)
        log('Setup search')
        r = re.search(b'<meta\s+http-equiv="Content-Type"\s+content="(?:.+?);' +
                      b'\s+charset=(.+?)"', html, re.IGNORECASE)
        log('Use search')
        if r:
            encoding = r.group(1)

        try:
            log('3 html= %r' % html)
            ###html = unicode(html, encoding)
            log('4 html= %r' % html)
        except Exception as e:
            pass
            log('3 Exception= %r' % e)
        log('5 html= %r' % html)
        self.content = html

    def get_headers(self):
        '''Returns a List of headers returned by the server.'''
        return self._response.info().headers

    def get_url(self):
        '''
        Return the URL of the resource retrieved, commonly used to determine if
        a redirect was followed.
        '''
        return self._response.geturl()
