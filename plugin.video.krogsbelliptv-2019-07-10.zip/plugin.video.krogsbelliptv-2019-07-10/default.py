#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import calendar
import net
import json
import locking,utils
import recordings
import definition
import findrecursive
import shutil
import urllib2
import xmltodict
import base64
from operator import itemgetter
import updateepg
import findtvguidenotifications
import glob
import fnmatch

ADDON      = definition.getADDON()
ADDONname  = ADDON.getAddonInfo('name')
ADDONid    = ADDON.getAddonInfo('id')
module     = 'default.py'
datapath   = xbmc.translatePath(ADDON.getAddonInfo('profile'))
progpath   = ADDON.getAddonInfo('path')
origin     = ADDONid +' available_channels'
IPTVuser   = ADDON.getSetting('user')
if ADDON.getSetting('castsubpr') != '':
    chromecast = 'Active'
else:
    if utils.runCommandTest('mkchromecast -h'):
        chromecast = True
    else:
        chromecast = False

try:
    higlights = ADDON.getSetting('higlights')
    ###utils.logdev(module,'0 higlights= %r' % higlights)
    higlights = higlights.split('¤¤¤¤')
    if higlights == ['']:
        higlights = []
    utils.logdev(module,'1 higlights= %r' % higlights)
    if higlights != []:
        utils.logdev(module,'higlights= %r' % higlights)
    else:
        ###higlights = []
        utils.logdev(module,'Reset: higlights= %r' % higlights)
    highlightscmp = []
    for high in higlights:
        highlightscmp.append(high.split('#description=')[0] + '#')
except Exception,e:
    pass
    higlights = []
    utils.logdev(module,'higlights RESET= %r, ERROR %r' % (higlights,e))
highlightcount = len(higlights)
utils.logdev(module,'AT START higlights= %r' % higlights)
    
tz = ADDON.getSetting('AdjustTVguideTimeZoneOffset')
if tz == '':
    TimeZone = 0
else:
    TimeZone = int(tz)  
dataepg = []
data= []

def setComandMode(command,mode):
	modeT = str(mode)
	LastCommand= ADDON.getSetting('LastCommand')
	LastMode= ADDON.getSetting('LastMode')
	if LastCommand != command and LastMode != modeT:
		ADDON.setSetting('LastCommand',command)
		ADDON.setSetting('LastMode',modeT)
		ADDON.setSetting('LastCommand2',LastCommand)
		ADDON.setSetting('LastMode2',LastMode)

def GetText(name,search_entered):
    keyboard = xbmc.Keyboard(search_entered, '[COLOR lightgreen][B]Please Enter '+str(name)+'[/B][CR][COLOR grey][I]<ESC> or Cancel to clear[/I][/COLOR]')
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_entered = keyboard.getText()
        if search_entered == None:
            return False 
    else:
        return False
    return search_entered 


def RecordFlagSet(sourceApp,flag):   ### 2018-11-08
    if sourceApp == '':
        ADDONsource = xbmcaddon.Addon()
    else:
        ADDONsource = xbmcaddon.Addon(sourceApp)
    datapath = xbmc.translatePath(ADDONsource.getAddonInfo('profile'))
    recordflag = os.path.join(datapath, 'RecordFlag.txt')
    FlagFile = open(recordflag, 'w')
    # Write to our text file the information we have provided and then goto next line in our file.
    # LogDev.write(repr(module) + ': ' + repr(message) + '\n')
    FlagFile.write(flag)
    FlagFile.close()

def RecordFlagGet(sourceApp):   ### 2018-11-08
    if sourceApp == '':
        ADDONsource = xbmcaddon.Addon()
    else:
        ADDONsource = xbmcaddon.Addon(sourceApp)
    datapath = xbmc.translatePath(ADDONsource.getAddonInfo('profile'))
    recordflag = os.path.join(datapath, 'RecordFlag.txt')
    if os.path.isfile(recordflag):
        FlagFile = open(recordflag, 'r')
        # Write to our text file the information we have provided and then goto next line in our file.
        # LogDev.write(repr(module) + ': ' + repr(message) + '\n')
        flag = FlagFile.read()
    else:
        flag = ''
    return flag

def find_files(directory, pattern):
    for root, dirs, files in os.walk(directory):
        for basename in files:
            if fnmatch.fnmatch(basename, pattern):
                filename = os.path.join(root, basename)
                yield filename

def urllibquote_plus(cat):
    try:
        if cat == None:
            return '0'   ### 2018-02-24
        else:
            return urllib.quote_plus(cat)
    except Exception, e:
        pass
        utils.logdev(module,'Error in urllib.quote_plus(cat): ' + repr(e))
        return str(cat)
        
def parse_date(dateString):
    return datetime.fromtimestamp(time.mktime(time.strptime(dateString.encode('utf-8', 'replace'), "%Y-%m-%d %H:%M:%S")))

recordPath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_path')))
streamtype = ADDON.getSetting('streamtype').replace('0','m3u8').replace('1','ts').replace('2','rtmp')
###utils.logdev(module,'streamtype= %r' % streamtype)

try:
    recordDisplayPath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_display_path')))
    if ADDON.getSetting('record_archive_path_enable') == 'true':
        recordArchivePath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_archive_path')))
    else:
        recordArchivePath = ''
except Exception, e:
    pass
    utils.logdev(module,'error in start: ' + repr(e))
if not os.path.exists(recordDisplayPath):
    recordDisplayPath = recordPath
    ADDON.setSetting('record_display_path',recordDisplayPath)
if not os.path.exists(recordArchivePath):
    recordArchivePath = ''
    ADDON.setSetting('record_display_path','')

def LOGIN():
    utils.logdev(module,'LOGIN')
    username = ADDON.getSetting('user')
    password = ADDON.getSetting('pass')
    ###if '@' in username and not (username == '' or password == ''):
    if not (username == '' or password == ''):
        ADDON.setSetting('firstrun','true')
    else:
        utils.logdev(module,'Firstrun.Launch(1)')
        import firstrun
        
        ###restoreXml=recordings.restoreLastSetupXml()
        ###utils.logdev(module,'LOGIN restoreXml= %s' % repr(restoreXml))
        
def AUTH():
        utils.logdev(module,'AUTH')
        
def sessionExpired():
    return False         

def setLiveEPGchannel(ch):
    ###  ['The Vampire Diaries -x- [Serier] .  (E4)', 
    ##'I k\xc3\xb8lvandet p\xc3\xa5 Elena Gilbert\xc2\x92s afsked, begynder s\xc3\xa6son 7 med nogle personer, der kommer igen og andre, der begynder at vakle. Mens Lily fors\xc3\xb8ger at drive en kile ind mellem Salvatorebr\xc3\xb8drerne, kan vi stadig h\xc3\xa5be p\xc3\xa5 at Stefan og Carolines k\xc3\xa6rlighed er st\xc3\xa6rk nok til at overleve. Baseret p\xc3\xa5 L. J. Smiths bogserie: The Vampire Diaries.\nNina Dobrev, Paul Wesley, Ian Somerhalder, Steven R. McQueen, Kat Graham', 
    ###'Rytec - http://forums.openpli.org', 
    ###datetime.datetime(2017, 7, 15, 3, 45), 
    ###datetime.datetime(2017, 7, 15, 4, 30)]
    ###utils.logdev(module,'epg= <%r>, \nurl= %r' % (ch[9], ch[3]))
    """
    setLiveEPG: ch= [
        0'TV2Zulu.dk', 
        1'Dybvaaaaad! [Underholdning] .  (S8E9) [Danmark]', 
        2'OrderedDict([(u\'@start\', u\'20180217182500 +0000\'), (u\'@stop\', u\'20180217190000 +0000\'), (u\'@channel\', u\'TV2Zulu.dk\'), (u\'title\', OrderedDict([(u\'@lang\', u\'da\'), (\'#text\', u\'Dybvaaaaad! [Underholdning] .  (S8E9) [Danmark]\')])), (u\'desc\', OrderedDict([(u\'@lang\', u\'da\'), (\'#text\', u"\'Dybvaaaaad kigger endnu engang dybt i flasken af tvivlsomme tv-koncepter og fjogede bem\\xe6rkninger - denne gang fra Holstebro")]))]) \nKeyError(\'sub_title\',)', 
        3 1518891900, 
        4 1518894000, 
        5"'Dybvaaaaad kigger endnu engang dybt i flasken af tvivlsomme tv-koncepter og fjogede bem\xc3\xa6rkninger - denne gang fra Holstebro \n\nEPG Created 2018-02-13 22:10:39", 
        6'', 
        7'', 
        8'', 
        9'', 
        10'', 
        11'', 
        12'', 
        13'WebGrab+Plus/w MDB & REX Postprocess -- version V2.0.1 -- Jan van Straaten - http://www.webgrabplus.com', 
        14'']
        """
    try:
        ###utils.logdev('XYZxyz setLiveEPGchannel','ch= %r' % ch)
        cats = recordings.catsfromEPGid(ch[0])
        EPGnow = updateepg.getEPGnow(cats)
        show_tv_archive_duration = ''
        tv_archive = EPGnow[2]
        tv_archive_duration = EPGnow[3]
        if type(tv_archive_duration) == int : 
            if tv_archive == 1 and tv_archive_duration > 0:
                show_tv_archive_duration = 'Days in archive %r \n' % tv_archive_duration
        
        EPG = EPGnow[0]  ### Insert live EPG in description
        chx = ch[9] + ' \n XXXXX ' + show_tv_archive_duration
        for indexX in range(0, len(EPG)):
            title = str(EPG[indexX][0])
            description = str(EPG[indexX][1]).replace('(n)','')
            ###starttime = str(EPG[indexX][3].strftime('%H:%M'))
            ###endtime = str(EPG[indexX][4].strftime('%H:%M'))
            starttime = str(datetime.fromtimestamp(EPG[indexX][3]).strftime('%H:%M'))
            endtime = str(datetime.fromtimestamp(EPG[indexX][4]).strftime('%H:%M'))
            chx += ' \n[COLOR lightgreen]'+starttime + ' - ' + endtime + '[B][/COLOR] \n[COLOR blue]'+ title+ '[/COLOR][/B] \n'+ description +' \n'
    except Exception, e:
        pass
        utils.logdev(module,'error setLiveEPGchannel: ' + repr(e))
        chx = 'No EPG or info - ' + repr(e)
    return chx

    
def setLiveEPG(ch):
    ###  ['The Vampire Diaries -x- [Serier] .  (E4)', 
    ##'I k\xc3\xb8lvandet p\xc3\xa5 Elena Gilbert\xc2\x92s afsked, begynder s\xc3\xa6son 7 med nogle personer, der kommer igen og andre, der begynder at vakle. Mens Lily fors\xc3\xb8ger at drive en kile ind mellem Salvatorebr\xc3\xb8drerne, kan vi stadig h\xc3\xa5be p\xc3\xa5 at Stefan og Carolines k\xc3\xa6rlighed er st\xc3\xa6rk nok til at overleve. Baseret p\xc3\xa5 L. J. Smiths bogserie: The Vampire Diaries.\nNina Dobrev, Paul Wesley, Ian Somerhalder, Steven R. McQueen, Kat Graham', 
    ###'Rytec - http://forums.openpli.org', 
    ###datetime.datetime(2017, 7, 15, 3, 45), 
    ###datetime.datetime(2017, 7, 15, 4, 30)]
    ###utils.logdev(module,'epg= <%r>, \nurl= %r' % (ch[9], ch[3]))
    """
    setLiveEPG: ch= [
    0'tv2zulu', 
    1'TV2Zulu (D)', 
    2'https://danishbits.org/static/bitbucket/users/1480871336.0465.png', 
    3'http://tv2danmark-tv2zulu-live.hls.adaptive.level3.net/tv2danmark/tv2zulu/master.m3u8', 
    4'plugin.video.roqtvrec available_channels', 
    5 1, 
    6 11, 
    7'', 
    8'', 
    9'TV2Zulu.dk', 
    10' \n\rcat= tv2zulu \n\rtvg-id= TV2Zulu.dk \n\rtvg-name= TV2Zulu \n\rgroup-title= DANSK \n\rcatsinlink= ! live \n\rlink= http:/ / tv2danmark-tv2zulu-live.hls.adaptive.level3.net/ tv2danmark/ tv2zulu/ master.m3u8', 
    11 1518541841, 
    12 1480374635]
    """
    try:
        ###utils.logdev('XYZxyz setLiveEPG','ch= %r' % ch)
        if ch[9] == '':
            ch[9] = 'No EPG'
        ### if 'movie' in ch[3] or ch[9] == '':
        if 'movie' in ch[3]:
            chx = ch[10]
        else:
            
            EPGnow = updateepg.getEPGnow(ch[0])  ### Insert live EPG in description
            EPG = EPGnow[0]
            show_tv_archive_duration = ''
            tv_archive = EPGnow[2]
            tv_archive_duration = EPGnow[3]
            if type(tv_archive_duration) == int : 
                if tv_archive == 1 and tv_archive_duration > 0:
                    show_tv_archive_duration = 'Days in archive %d\n' % tv_archive_duration
            chx = ch[9] + ' \n' + show_tv_archive_duration
            for indexX in range(0, len(EPG)):
                title = str(EPG[indexX][0])
                description = str(EPG[indexX][1]).replace('(n)','')
                ###starttime = str(EPG[indexX][3].strftime('%H:%M'))
                ###endtime = str(EPG[indexX][4].strftime('%H:%M'))
                starttime = str(datetime.fromtimestamp(EPG[indexX][3]).strftime('%H:%M'))
                endtime = str(datetime.fromtimestamp(EPG[indexX][4]).strftime('%H:%M'))
                chx += ' \n[COLOR lightgreen]'+starttime + ' - ' + endtime + '[B][/COLOR] \n[COLOR blue]'+ title+ '[/COLOR][/B] \n'+ description +' \n'
    except Exception, e:
        pass
        utils.logdev(module,'error setLiveEPG: ' + repr(e))
        chx = 'No EPG or info - ' + repr(e)
    return chx

def GoHome(view):
    if not view is None and not view is '':
        
        ###
    
        ROQTVusername = ADDON.getSetting('user')
        userinfo = ''
        if ROQTVusername.lower() != 'none':
            try:
                link = definition.getBASEURL() + '/panel_api.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')
                file = urllib2.urlopen(link)
                data = file.read()
                file.close()
                
                ChannelFile = os.path.join(datapath,ADDONid) + '.info'
                with open(ChannelFile,'wb') as output:
                    output.write(data)
                ###name= Status,url= url,mode= 11,iconimage= ,cat= ,date= ,description= {u'username': u'XXX', u'status': u'Active', u'is_trial': u'0', u'created_at': u'1493734688', u'auth': 1, u'allowed_output_formats': [u'm3u8', u'ts', u'rtmp'], u'exp_date': u'1499005088', u'active_cons': u'0', u'password': u'XXXX', u'max_connections': u'1'},startDate= ,endDate= ,recordname= )
                d = json.loads(data)
                d1 = d['user_info']
                
                ###formats = d1['allowed_output_formats']
                ###allowedformats = AllowedFormats(formats)
                
                ###if d1['is_trial'] == '1':
                ###    is_trial = '\nThis is a trial '
                ###else:
                ###    is_trial = ''
                now = datetime.now()
                remainingdays = (recordings.parseDate(d1['exp_date'])-recordings.parseDate(now)).days
                if remainingdays < 7:
                    remainingdaysS = '[B][COLOR red] '+ str(remainingdays)  + '[/COLOR][/B]'
                else:
                    remainingdaysS = str(remainingdays)
                ###descr = 'Username= %s \nStatus= %s \nExpire= %s%s%s\nMax connections= %s \nConnections in use= %s \nAllowed formats= %s' %(d1['username'],d1['status'],recordings.parseDate(d1['exp_date']).strftime('%Y-%m-%d %H:%M'),remainingdaysS,is_trial,d1['max_connections'],d1['active_cons'],allowedformats)
                if ADDON.getSetting('enable_record')=='true':
                    PRC = getPlannedRecordingCounts()    
                    userinfo = d1['max_connections'] + '/' +d1['active_cons'] + ' ' + remainingdaysS + ' ' + PRC
                else:    
                    userinfo = d1['max_connections'] + '/' +d1['active_cons'] + ' ' + remainingdaysS
            
            except Exception, e:
                pass
                utils.notification('Error in getting '+ ADDONid + ' info! Check your User ID\n' + repr(e))
        ###
        
        
        try:
            RytecAddon = xbmcaddon.Addon(id='service.rytecepg.downloader')
            RytecAction = RytecAddon.getSetting('active')
        except Exception,e:
            pass
            RytecAction = ''
            utils.logdev(module,'Get Rytec Action - ERROR: %r' % e)
        if userinfo != '':
            EPG_update = [userinfo]
        else:
            EPG_update = []
        ###if ADDON.getSetting('Recordings') != '':
        ###    EPG_update.append('Recording')
        if locking.isAnymarkLocked():
            EPG_update.append('[COLOR red]Rec[/COLOR]')
        if locking.isScanLocked('EPG_update'):
            EPG_update.append('EPG updating')
        if ADDON.getSetting('RecursiveSearch') == 'true':
            EPG_update.append('Recursive Search')
        if RytecAction != '':
            EPG_update.append('Rytec: %s' % RytecAction)
        StatusCode = ''
        if len(EPG_update) > 0:
            Status = ', '.join(EPG_update)
            StatusCode = '\n[I][COLOR grey]'+ Status + '[/COLOR][/I]'
        addDir('[COLOR white][B]%s ==> Home[/B][/COLOR]%s' % (view,StatusCode),'',1,'','','','Go to Home menu from %s' % view)
    else:
        addDir('[COLOR white][B]Home[/B][/COLOR]','',1,'','','','Go to Home menu')

def FAVORITES():
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###now= datetime.today()
    ###utils.logdev(module,'FAVORITES')
    GoHome('Favorites')
    conn = recordings.getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE favorite=? and visible=? and source=?", ['True',1,origin])  ### WHERE id=? and source=?", [cat,origin])
    favorites = c.fetchall()
    favorites = sorted(favorites, key=itemgetter(1)) ### Sort by name
    favorites = sorted(favorites, key=itemgetter(9)) ### Sort by EPGname
    ###utils.logdevarray(module+'-favorite',favorites)
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        if ch[8] >= 1 and ch[8] != '' :   ### Channel with Archive/Catch up
            chname = ch[9] + ': ' + ch[1] + ' (A)'
        else:
            chname = ch[9] + ': ' + ch[1]
        addDir(chname,ch[3],200,ch[2],ch[0],'',setLiveEPG(ch))
    ###conn.commit()
    c.close()  
    setView('movies', 'main-view')  

def NEWCHANNELS():
    GoHome('New Channels, VOD and TV Series')
    now = int(time.mktime(datetime.now().timetuple()))
    missing = 0
    skip = 0
    searchcountmax = int(ADDON.getSetting('searchcountmax'))
    try:
        count = int(ADDON.getSetting('NEWCHANNELScount'))
    except:
        pass
        count = 0
        ADDON.setSetting('NEWCHANNELScount',str(count))
    utils.logdev(module,'NEWCHANNELS(count= %r)'% count)
    startcount = count
    if not startcount == 0:
        addDir('[COLOR red][B]First Channels[/B][/COLOR]','url',7003,'','','',str(0))
    ###now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###now= datetime.today()
    ###utils.logdev(module,'NEWCHANNELS')
    ftvntvini = os.path.join(datapath,'New Channels or VOD '+ADDONname) + '.txt'
    LF = open(ftvntvini, 'w')
    conn = recordings.getConnection()
    c = conn.cursor()
    ####c.execute("SELECT * FROM channels WHERE NOT created = ?", [None])   #####
    createdlimit =    int(now) - 5356800    ### 62 * 24 * 60 * 60  created-timedelta(days=62)
    c.execute("SELECT * FROM channels WHERE source=? and created < ? and created > ? ",[origin,now,createdlimit])
    favorites = c.fetchall()
    favorites = sorted(favorites, key=itemgetter(12), reverse=True) ### Sort by Created date
    j = 0
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        ###now = int(time.mktime(datetime.now().timetuple()))
        created = favorites[index][12]
        ### utils.logdev(module,'created= %r' % created)
        ### timestamp = time.mktime(dt_obj.timetuple())
        ### dt_obj = datetime.fromtimestamp(timestamp)
        
        if not created is None and created != '':
            createdplus =    int(created) + 5356800    ### 62 * 24 * 60 * 60  created-timedelta(days=62)
            if createdplus > now:
                created = str(datetime.fromtimestamp(created).strftime('%Y-%m-%d'))
                if ch[8] >= 1 and ch[8] != '' :   ### Channel with Archive/Catch up
                    chname = '[COLOR lightgreen]' + created + ': [/COLOR]' + ch[1] + ' (A)'
                else:
                    chname = '[COLOR lightgreen]' + created + ': [/COLOR]' + ch[1]
                j += 1
                LF.write(format(j, '04d') + ' ' + created + ': ' + ch[1] + '\n')
                ###LF.write(created + ': ' + ch[1] + '\n')
                if index >= startcount+searchcountmax:
                    missing += 1
                elif index < startcount:
                    skip +=1
                    if skip == 1 and not (startcount-searchcountmax) == 0:
                        addDir('[COLOR red][B]Previous Channels[/B][/COLOR]','url',7003,'','','',str(startcount-searchcountmax))
                elif startcount <= index and index < startcount+searchcountmax:
                    addDir(chname,ch[3],200,ch[2],ch[0],'','# ' + str(index) + '[CR]ID ' + ch[0]+ '[CR][CR]' +setLiveEPG(ch))
                else:
                    dialog = xbmcgui.Dialog()
                    dialog.ok('[B]' + ADDONname + '[/B]','[COLOR red]Oops - something went wrong![/COLOR]','')
    if missing > 0:
        addDir('[COLOR red][B]Next Channels[/COLOR][/B][CR][COLOR grey][I]Remaining %d[/I][/COLOR]' % missing,'url',7003,'','','',str(startcount+searchcountmax))
                
                ###addDir(chname,ch[3],200,ch[2],ch[0],'',setLiveEPG(ch))
    c.close()  
    LF.close()
    setView('movies', 'main-view')  

def RECURSIVECHANNELS():
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###now= datetime.today()
    ###utils.logdev(module,'RECURSIVECHANNELS')
    GoHome('Recursive Search Channels')
    conn = recordings.getConnection()
    c = conn.cursor()
    ####c.execute("SELECT * FROM channels WHERE NOT created = ?", [None])   #####
    ###c.execute("SELECT * FROM channels WHERE (epg_channel like '% (R)%' or favorite=?) and visible=? and source=?", ['True',1,origin])
    c.execute("SELECT * FROM channelsRecursive WHERE visible=? and source=?", [1,origin])
    favorites = c.fetchall()
    favorites = sorted(favorites, key=itemgetter(1)) ### Sort by name
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        ###created = favorites[index][11]
        ###if created + timedelta(days=62) > datetime.today():
        ###created = favorites[index][11].strftime('%Y-%m-%d')
        ##created = str(datetime.fromtimestamp(favorites[index][11]).strftime('%Y-%m-%d'))
        created = favorites[index][11]
        if ch[8] >= 1 and ch[8] != '' :   ### Channel with Archive/Catch up
            chname = ch[1] + ' (A)'
        else:
            chname = ch[1]
        addDir(chname,ch[3],200,ch[2],ch[0],'',setLiveEPG(ch))
    c.close()  
    setView('movies', 'main-view')  

def MYSELECTEDCHANNELS():
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###now= datetime.today()
    ###utils.logdev(module,'MYSELECTEDCHANNELS')
    GoHome('Direct Channels')
    nowTS = int(time.mktime(datetime.now().timetuple()))
    missing = 0
    skip = 0
    searchcountmax = int(ADDON.getSetting('searchcountmax'))
    try:
        count = int(ADDON.getSetting('MYSELECTEDCHANNELScount'))
    except:
        pass
        count = 0
        ADDON.setSetting('MYSELECTEDCHANNELScount',str(count))
    utils.logdev(module,'MYSELECTEDCHANNELS(count= %r)'% count)
    startcount = count
    if not startcount == 0:
        addDir('[COLOR red][B]First Channels[/B][/COLOR]','url',7004,'','','',str(0))
    conn = recordings.getConnection()
    c = conn.cursor()
    ###c.execute("SELECT * FROM channels WHERE weight > ? and weight <? and visible =?", [0,101,1])
    c.execute("SELECT * FROM channels WHERE title like '% (D)%' and visible=? and source=?", [1,origin])
    favorites = c.fetchall()
    ###favorites = sorted(favorites, key=itemgetter(6))   ### Sort by weight
    ###favorites = sorted(favorites, key=itemgetter(0))   ### Sort by id
    favorites = sorted(favorites, key=itemgetter(1))   ### Sort by title
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
        ###def addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
        ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
        if ch[8] >= 1 and ch[8] != '' :
            chname = ch[1] + ' (A)'
        else:
            chname = ch[1]
        """
        if ch[6] >= 1000:
            ch[6] -= 1000
        chname = '[COLOR lightgreen]' + str(ch[6]) +'[/COLOR]  ' + chname
        """
        if index >= startcount+searchcountmax:
            missing += 1
        elif index < startcount:
            skip +=1
            if skip == 1 and not (startcount-searchcountmax) == 0:
                addDir('[COLOR red][B]Previous Channels[/B][/COLOR]','url',7003,'','','',str(startcount-searchcountmax))
        elif startcount <= index and index < startcount+searchcountmax:
            addDir(chname,ch[3],200,ch[2],ch[0],'','# ' + str(index) + '[CR]ID ' + ch[0]+ '[CR][CR]' +setLiveEPG(ch))
        else:
            dialog = xbmcgui.Dialog()
            dialog.ok('[B]' + ADDONname + '[/B]','[COLOR red]Oops - something went wrong![/COLOR]','')
        ###addDir(chname,ch[3],200,ch[2],ch[0],'',setLiveEPG(ch))
    ###conn.commit()
    if missing > 0:
        addDir('[COLOR red][B]Next Channels[/COLOR][/B][CR][COLOR grey][I]Remaining %d[/I][/COLOR]' % missing,'url',7004,'','','',str(startcount+searchcountmax))
    c.close()  
    setView('movies', 'main-view')
 
def NTVCHANNELS(kaddonID):
    ###addonID = ADDON.getSetting('LastaddonID')
    GoHome('Channels '+kaddonID)
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    missing = 0
    skip = 0
    searchcountmax = int(ADDON.getSetting('searchcountmax'))
    try:
        count = int(ADDON.getSetting('NTVCHANNELScount'))
    except:
        pass
        count = 0
        ADDON.setSetting('NTVCHANNELScount',str(count))
    utils.logdev(module,'NTVCHANNELS(count= %r)'% count)
    startcount = count
    if not startcount == 0:
        addDir('[COLOR red][B]First Channels[/B][/COLOR]','url',7001,'','','',str(0))
    conn = recordings.getConnection()
    c = conn.cursor()
    kaddonIDmarker = '% ('+kaddonID+')%'
    c.execute("SELECT * FROM channels WHERE title like ? and visible=? and source=?", [kaddonIDmarker,1,origin])
    favorites = c.fetchall()
    ###favorites = sorted(favorites, key=itemgetter(6))   ### Sort by weight
    ###favorites = sorted(favorites, key=itemgetter(0))   ### Sort by id
    favorites = sorted(favorites, key=itemgetter(1))   ### Sort by title
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        if ch[8] >= 1 and ch[8] != '' :
            chname = ch[1] + ' (A)'
        else:
            chname = ch[1]
        if index >= startcount+searchcountmax:
            missing += 1
        elif index < startcount:
            skip +=1
            if skip == 1 and not (startcount-searchcountmax) == 0:
                addDir('[COLOR red][B]Previous Channels[/B][/COLOR]','url',7001,'','','',str(startcount-searchcountmax))
        elif startcount <= index and index < startcount+searchcountmax:
            addDir(chname,ch[3],200,ch[2],ch[0],'','# ' + str(index) + '[CR]ID ' + ch[0]+ '[CR][CR]' +setLiveEPG(ch))
        else:
            dialog = xbmcgui.Dialog()
            dialog.ok('[B]' + ADDONname + '[/B]','[COLOR red]Oops - something went wrong![/COLOR]','')
    if missing > 0:
        addDir('[COLOR red][B]Next Channels[/COLOR][/B][CR][COLOR grey][I]Remaining %d[/I][/COLOR]' % missing,'url',7001,'','','',str(startcount+searchcountmax))
    c.close()  
    setView('movies', 'main-view')

def TVawayCHANNELS():
    GoHome('TVaway Channels')
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    missing = 0
    skip = 0
    searchcountmax = int(ADDON.getSetting('searchcountmax'))
    try:
        count = int(ADDON.getSetting('TVawayCHANNELScount'))
    except:
        pass
        count = 0
        ADDON.setSetting('TVawayCHANNELScount',str(count))
    utils.logdev(module,'TVawayCHANNELS(count= %r)'% count)
    startcount = count
    if not startcount == 0:
        addDir('[COLOR red][B]First Channels[/B][/COLOR]','url',7002,'','','',str(0))
    conn = recordings.getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE title like '% (TVA)%' and visible=? and source=?", [1,origin])
    favorites = c.fetchall()
    ###favorites = sorted(favorites, key=itemgetter(6))   ### Sort by weight
    ###favorites = sorted(favorites, key=itemgetter(0))   ### Sort by id
    favorites = sorted(favorites, key=itemgetter(1))   ### Sort by title
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        if ch[8] >= 1 and ch[8] != '' :
            chname = ch[1] + ' (A)'
        else:
            chname = ch[1]
        if index >= startcount+searchcountmax:
            missing += 1
        elif index < startcount:
            skip +=1
            if skip == 1 and not (startcount-searchcountmax) == 0:
                addDir('[COLOR red][B]Previous Channels[/B][/COLOR]','url',7002,'','','',str(startcount-searchcountmax))
        elif startcount <= index and index < startcount+searchcountmax:
            addDir(chname,ch[3],200,ch[2],ch[0],'','# ' + str(index) + '[CR]ID ' + ch[0]+'[CR][CR]'+setLiveEPG(ch))
        else:
            dialog = xbmcgui.Dialog()
            dialog.ok('[B]' + ADDONname + '[/B]','[COLOR red]Oops - something went wrong![/COLOR]','')
    if missing > 0:
        addDir('[COLOR red][B]Next Channels[/COLOR][/B][CR][COLOR grey][I]Remaining %d[/I][/COLOR]' % missing,'url',7002,'','','',str(startcount+searchcountmax))
    c.close()  
    setView('movies', 'main-view')
    
def TVawayCHANNELS_OLD():
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###now= datetime.today()
    ###utils.logdev(module,'TVawayCHANNELS')
    GoHome('TVaway Channels')
    conn = recordings.getConnection()
    c = conn.cursor()
    ###c.execute("SELECT * FROM channels WHERE weight > ? and weight <? and visible =?", [0,101,1])
    c.execute("SELECT * FROM channels WHERE title like '% (TVA)%' and visible=? and source=?", [1,origin])
    favorites = c.fetchall()
    ###favorites = sorted(favorites, key=itemgetter(6))   ### Sort by weight
    ###favorites = sorted(favorites, key=itemgetter(0))   ### Sort by id
    favorites = sorted(favorites, key=itemgetter(1))   ### Sort by title
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
        ###def addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
        ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
        if ch[8] >= 1 and ch[8] != '' :
            chname = ch[1] + ' (A)'
        else:
            chname = ch[1]
        """
        if ch[6] >= 1000:
            ch[6] -= 1000
        chname = '[COLOR lightgreen]' + str(ch[6]) +'[/COLOR]  ' + chname
        """
        addDir(chname,ch[3],200,ch[2],ch[0],'',setLiveEPG(ch))
    ###conn.commit()
    c.close()  
    setView('movies', 'main-view')
    
def HIDDENCHANNELS():
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###now= datetime.today()
    ###utils.logdev(module,'HIDDENCHANNELS')
    GoHome('Hidden Channels')
    conn = recordings.getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE visible=? and source=?", [0,origin])
    favorites = c.fetchall()
    favorites = sorted(favorites, key=itemgetter(1)) ### Sort by name
    ###utils.logdevarray(module+'-favorite',favorites)
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
        ###def addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
        ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
        if ch[8] >= 1 and ch[8] != '' :
            chname = ch[1] + ' (A)'
        else:
            chname = ch[1]
        ###chname = '[COLOR lightgreen]' + str(ch[6]) +'[/COLOR]  ' + chname
        addDir(chname,ch[3],200,ch[2],ch[0],'',setLiveEPG(ch))
    ###conn.commit()
    c.close()  
    setView('movies', 'main-view')

def ARCHIVE():
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###now= datetime.today()
    ###utils.logdev(module,'ARCHIVE')
    GoHome('Archive')
    conn = recordings.getConnection()
    c = conn.cursor()
    ###c.execute("SELECT * FROM channels WHERE catchup>? and visible=?", ['0',1])
    c.execute("SELECT * FROM channels WHERE not catchup=? and catchup>? and visible=? and source=?", ['',0,1,origin])
    favorites = c.fetchall()
    favorites = sorted(favorites, key=itemgetter(1))
    ###utils.logdevarray(module+'-favorite',favorites)
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
        ###def addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
        ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
        if ch[8] >= 1 and ch[8] != '' :
            chname = ch[1] + ' (A)'
        else:
            chname = ch[1]
        addDir(chname,ch[3],200,ch[2],ch[0],'',setLiveEPG(ch))
    ###conn.commit()
    c.close()  
    setView('movies', 'main-view')
    
    """
    favorites = c.fetchall()
    favorites = sorted(favorites, key=itemgetter(1))
    ###utils.logdevarray(module+'-archive',favorites)
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
        ###def addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
        ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
        if ch[8] >= 1 and ch[8] != '' :
            chname = ch[1] + ' (A)'
        else:
            chname = ch[1]
        addDir(chname,ch[3],200,ch[2],ch[0],'',ch[9])
    ###conn.commit()
    c.close()  
    setView('movies', 'main-view')      
    """
def SearchEPG(name):
    search_entered = ADDON.getSetting('searchepgvodcha')
    dialog = xbmcgui.Dialog()
    keyboard = dialog.input('[COLOR lightgreen][B]Please Enter '+str(name)+'[/B][CR][COLOR grey][I]! to clear. Not case sensitive search. 10 seconds timeout[/I][/COLOR]',search_entered, type=xbmcgui.INPUT_ALPHANUM, autoclose=10000)
    utils.logdev(module,'keyboard= %r' % keyboard)
    if keyboard == '!':
        keyboard = ''
        search_entered = ''
        ADDON.setSetting('searchepgvodcha','')
    if keyboard != '':
        search_entered = keyboard
        ADDON.setSetting('searchepgvodcha',search_entered)
    return search_entered 

"""
        dialog = xbmcgui.Dialog()
        result = dialog.input(title, utils.to_unicode(default), type=xbmcgui.INPUT_ALPHANUM, autoclose=10000)
        if result:
            text = utils.to_unicode(result)
            return True, text

        return False, u'' 

def SearchEPG(name):
    search_entered = ADDON.getSetting('searchepgvodcha')
    keyboard = xbmc.Keyboard(search_entered, '[COLOR lightgreen][B]Please Enter '+str(name)+'[/B][CR][COLOR grey][I]<ESC> or Cancel to clear. Not case sensitive search[/I][/COLOR]')
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_entered = keyboard.getText()
        if search_entered == None:
            return False 
        else:
            ADDON.setSetting('searchepgvodcha',search_entered)   ### 2018-02-15
    else:
        ADDON.setSetting('searchepgvodcha','')
        return False
    return search_entered 

"""        
def PROGRAMSEARCH():
    """
    try:  ### Get Ritzau icons from dr.dk
        iconsatdr = 'https://www.dr.dk/assets/css/shared/ritzau-logos.css'
        file = urllib2.urlopen(iconsatdr)
        data = file.read()
        file.close()
        utils.logdev(module,'PROGRAMSEARCH iconsatdr= %r' % data)
        ### Example icon https://www.dr.dk/assets/img/ritzau-logos/ritzau-logo-dk4.png
        data = data.replace('\n','')  ### remove line feed/Carrige return
        data = data.split('../..')
        for i in range(1, len(data)):
            iconlink = data[i].split('"')[0]
            utils.logdev(module,'PROGRAMSEARCH iconlink= %r' % iconlink)
            addDir(iconlink,'url',0,'https://www.dr.dk/assets'+iconlink,'','','DR.DK ritzau-logo')
    except Exception,e:
        pass
        utils.logdev(module,'PROGRAMSEARCH iconsatdr Exception= %r' % e)
    """
    searchcount = 0
    searchcountmax = int(ADDON.getSetting('searchcountmax')) + 1
    searchtimemax = int(ADDON.getSetting('searchtimemax')) ### seconds
    searchtimereached = False
    
    GoHome('Search EPG Programs')
    
    searchText = SearchEPG('EPG Program to search for')
    if searchText:
        nowM = datetime.today()
        now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        nowDT= datetime.today()
        addDir('[COLOR lightgreen]Search EPG Programs:[/COLOR] [B]'+searchText+'[/B]','url',2050,'','','','Search all '+ADDONname +' channels EPG')
        searchText = '%' + searchText + '%'
        utils.logdev(module,'PROGRAMSEARCH searchText= %r' % searchText)
        conn = recordings.getConnection()
        c = conn.cursor()
        """
        setLiveEPG: ch= [
        0'tv2zulu', 
        1'TV2Zulu (D)', 
        2'https://danishbits.org/static/bitbucket/users/1480871336.0465.png', 
        3'http://tv2danmark-tv2zulu-live.hls.adaptive.level3.net/tv2danmark/tv2zulu/master.m3u8', 
        4'plugin.video.roqtvrec available_channels', 
        5 1, 
        6 11, 
        7'', 
        8'', 
        9'TV2Zulu.dk', 
        10' \n\rcat= tv2zulu \n\rtvg-id= TV2Zulu.dk \n\rtvg-name= TV2Zulu \n\rgroup-title= DANSK \n\rcatsinlink= ! live \n\rlink= http:/ / tv2danmark-tv2zulu-live.hls.adaptive.level3.net/ tv2danmark/ tv2zulu/ master.m3u8', 
        11 1518541841, 
        12 1480374635]
        
        setLiveEPG: ch= [
        0'TV2Zulu.dk', 
        1'Dybvaaaaad! [Underholdning] .  (S8E9) [Danmark]', 
        2'OrderedDict([(u\'@start\', u\'20180217182500 +0000\'), (u\'@stop\', u\'20180217190000 +0000\'), (u\'@channel\', u\'TV2Zulu.dk\'), (u\'title\', OrderedDict([(u\'@lang\', u\'da\'), (\'#text\', u\'Dybvaaaaad! [Underholdning] .  (S8E9) [Danmark]\')])), (u\'desc\', OrderedDict([(u\'@lang\', u\'da\'), (\'#text\', u"\'Dybvaaaaad kigger endnu engang dybt i flasken af tvivlsomme tv-koncepter og fjogede bem\\xe6rkninger - denne gang fra Holstebro")]))]) \nKeyError(\'sub_title\',)', 
        3 1518891900, 
        4 1518894000, 
        5"'Dybvaaaaad kigger endnu engang dybt i flasken af tvivlsomme tv-koncepter og fjogede bem\xc3\xa6rkninger - denne gang fra Holstebro \n\nEPG Created 2018-02-13 22:10:39", 
        6'', 
        7'', 
        8'', 
        9'', 
        10'', 
        11'', 
        12'', 
        13'WebGrab+Plus/w MDB & REX Postprocess -- version V2.0.1 -- Jan van Straaten - http://www.webgrabplus.com', 
        14'']
        """
        ###programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
        ###c.execute("SELECT DISTINCT p.*, c.epg_channel FROM channelsRecursive c, programs p WHERE p.channel = c.epg_channel AND p.title = ? AND p.start_date >= ?",[program, now])
        """
        ch= [
0'TV2.dk', 
1'Harry Potter og halvblodsprinsen [Film] .  (Harry Potter and the Half-Blood Prince) [England]', 2"OrderedDict([(u'@start', u'20180213133000 +0000'), (u'@stop', u'20180213160000 +0000'), (u'@channel', u'TV2.dk'), (u'title', OrderedDict([(u'@lang', u'da'), ('#text', u'Harry Potter og halvblodsprinsen [Film] .  (Harry Potter and the Half-Blood Prince) [England]')])), (u'desc', OrderedDict([(u'@lang', u'da'), ('#text', u'Lord Voldemort har strammet sit greb om b\\xe5de Mugglerne og troldmandsverdenen, og Hogwarts er ikke l\\xe6ngere sikker. Harry Potter (Daniel Radcliff) har en mistanke om, at faren allerede er indenfor skolens mure, men Dumbledore (Michael Gambon) skyder denne tanke v\\xe6k, og vil hellere forberede Harry Potter p\\xe5 den endelige kamp mod Voldemort. De ops\\xf8ger Dumbledores gamle ven og kollega, Professor Horace Slughorn (Jim Broadbent), som ligger inde med hemmelig viden om Voldemort. Mens de arbejder med dette, blomstrer romantikken ogs\\xe5 p\\xe5 Hogwarts, men det endelige slag n\\xe6rmer sig - og snart vil alt m\\xe5ske v\\xe6re forandret! nDen sjette Harry Potter-film, der baserer sig p\\xe5 J. K. Rowlings roman-serie.\\nDavid Yates\\nDaniel Radcliffe\\nRupert Grint\\nEmma Watson\\nMichael Gambon\\nAlan Rickman\\nJim Broadbent\\nHelen Bonham Carter\\nTomothy Spall')]))]) \nKeyError('sub_title',)", 
3 1518528600, 
4 1518537600, 
5 'Lord Voldemort har strammet sit greb om b\xc3\xa5de Mugglerne og troldmandsverdenen, og Hogwarts er ikke l\xc3\xa6ngere sikker. Harry Potter (Daniel Radcliff) har en mistanke om, at faren allerede er indenfor skolens mure, men Dumbledore (Michael Gambon) skyder denne tanke v\xc3\xa6k, og vil hellere forberede Harry Potter p\xc3\xa5 den endelige kamp mod Voldemort. De ops\xc3\xb8ger Dumbledores gamle ven og kollega, Professor Horace Slughorn (Jim Broadbent), som ligger inde med hemmelig viden om Voldemort. Mens de arbejder med dette, blomstrer romantikken ogs\xc3\xa5 p\xc3\xa5 Hogwarts, men det endelige slag n\xc3\xa6rmer sig - og snart vil alt m\xc3\xa5ske v\xc3\xa6re forandret! nDen sjette Harry Potter-film, der baserer sig p\xc3\xa5 J. K. Rowlings roman-serie.\nDavid Yates\nDaniel Radcliffe\nRupert Grint\nEmma Watson\nMichael Gambon\nAlan Rickman\nJim Broadbent\nHelen Bonham Carter\nTomothy Spall \n\nEPG Created 2018-02-14 10:10:40', 
6'', 
7'', 
8'', 
9'', 
10'', 
11'', 
12'', 
13'WebGrab+Plus/w MDB & REX Postprocess -- version V2.0.1 -- Jan van Straaten - http://www.webgrabplus.com', 
14'', 
15'TV2 dk (D)', 
16'https://danishbits.org/static/bitbucket/users/1485171091.8076.png', 
17'http://tv2danmark-tv2nord-live.hls.adaptive.level3.net/tv2danmark/tv2nord/master.m3u8', 
18'']
        """
        ###c.execute("SELECT p.*, c.title, c.logo, c.stream_url, c.catchup, c.id FROM programs p, channels c WHERE p.channel = c.epg_channel AND p.title LIKE ?  and (c.title like '% (D)%' or c.favorite=?) COLLATE NOCASE", [searchText,'True'])
        try:
            c.execute("SELECT p.*, c.title, c.logo, c.stream_url, c.catchup, c.id FROM programs p, channels c WHERE p.channel = c.epg_channel AND p.title LIKE ?  and (c.title like '% (D)%' or c.favorite=? or c.catchup>?) and c.visible=? and c.source=? COLLATE NOCASE", [searchText,'True',0,1,origin])
            ###c.execute("SELECT p.*, c.title, c.logo, c.stream_url, c.catchup, c.id FROM programs p, channels c WHERE (c.epg_channel = p.channel) AND p.title LIKE ? and (c.title like '% (D)%' or c.epg_channel like '% (R)%' or c.favorite=? or c.catchup=?) and c.visible=? COLLATE NOCASE", [searchText,'True',1,1])  
            utils.logdev(module,'PROGRAMSEARCH searchText= %r,origin= %r' % (searchText,origin))
            favorites = c.fetchall()
        
            utils.logdev(module,'PROGRAMSEARCH favorites= %r' % favorites)
            for fav in favorites:
                utils.logdev(module,'PROGRAMSEARCH fav= %r' % fav[0])
        except:
            pass
            favorites = []
        favorites = sorted(favorites, key=itemgetter(3)) ### Sort by start date
        utils.logdev(module,'PROGRAMSEARCH sorted favorites= %r' % favorites)
        for index in range(0, len(favorites)):
            ch = []
            for i in range(0, len(favorites[index])):
                if favorites[index][i] == None:
                    ch.append('')
                else:
                    ch.append(favorites[index][i])
            utils.logdev(module,'PROGRAMSEARCH ch= %r' % ch)
            """
            channels = recordings.catsfromEPGid(ch[0])
            utils.logdev('XYZxyz','channels= %r' % channels)
            utils.logdev('XYZxyz','type(channels)= %r' % type(channels))
            ###def addDir( name,url,mode,iconimage='',cat='',date='',description='',startDate='',endDate='',recordname='',whatsup=''):
            foundprograms = []
            if type(channels) not in [str, unicode]:
                for cha in channels:
                    if cha != '0':
                        foundprograms.append(cha)
            else:
                if channels != '0':
                    foundprograms.append(channels)
                
            for fprograms in foundprograms:
                guide = updateepg.getEPG(fprograms)
                try:
                    guideEPG = guide[0]
                except Exception, e:
                    pass
                    utils.logdev(module,'Error in getting TV Guide\n' + repr(e))
                    return
                nameEPG = guide[1]
                tv_archive = guide[2]
                tv_archive_duration= guide[3]
                epg_channel_id = guide[4]
                
                namech = nameEPG
                if namech == 'None' or namech == '':
                    namech = recordings.ChannelName(fprograms)
            addDir(namech +': '+ch[1],ch[3],200,ch[2],fprograms,'',ch[5])
            """
            try:
                startDate= ch[3]
                if type(startDate) == int:
                    startDate= datetime.fromtimestamp(float(ch[3]))
                    endDate= datetime.fromtimestamp(float(ch[4]))
                else:
                    startDate= ch[3]
                    endDate= ch[4]
                try:
                    ArchiveOffset = int(ADDON.getSetting('archiveoffset'))
                except:
                    pass
                    ArchiveOffset = 1
                startDateCU= startDate + timedelta(seconds = (ArchiveOffset - TimeZone)*3600 -60)  ### USE UK TimeZone and start 1 minutes early
            except Exception, e:
                pass
                startDate=''
                startDateCU=''
                endDate=''
                utils.logdev(module,'PROGRAMSEARCH Error in getting dates\n' + repr(e))
            name= ch[15] + ': [B]' + ch[1] + '[/B]'
            cat = ch[19]
            namech = name
            newiconurl = ch[16]
            channelurl = ch[17]
            tv_archive = ch[18]   ### Number of days in archive - 0 No archive on channel
            if type(tv_archive) != int:
                utils.logdev(module,'tv_archive= %r, type(tv_archive)= %r' % (tv_archive, type(tv_archive)))
                tv_archive = 0
            recordname= ch[1]
            StartDateTime = ''
            Duration = ''
            try:
                StartDateTime = ' \nStart ' + startDate.strftime('%Y-%m-%d %H:%M')
                dura = (endDate - startDate)/60
                Duration = ' \nDuration [' + str(dura)[-5:] +'] \n'  ###2018-03-08
                #Duration = ' \nDuration ' + str(dura) + ' \n'
                EPGtime = ''
                try:
                    if 'EPG Created ' in ch[5]:
                        EPGtime = 'EPG Created ' + ch[5].split('EPG Created ')[1][0:19]+'\n'
                except:
                    pass 
                description= (namech + ' (' +cat+'):'+StartDateTime+Duration + EPGtime +'\n'+ch[5])   ###.encode("utf-8")
                utils.logdev(module,'PROGRAMSEARCH Duration= %r' % Duration )
            except Exception, e:
                pass
                utils.logdev(module,'PROGRAMSEARCH Error in getting duration\n' + repr(e))
                description = (recordings.latin1_to_ascii_force(namech) + ' (' +recordings.latin1_to_ascii_force(cat)+'):' +StartDateTime+Duration+ recordings.latin1_to_ascii_force(ch[1]))
            description = description.replace('(n)','\n').replace('.n)','. \n') 
            try:
                ### change \" to " - it comes from master.xml
                recordname = recordname.replace('\\"','"')
                name = name.replace('\\"','"')
                
                archiveDateCU = nowDT - timedelta(days = tv_archive)
                if tv_archive > 0 and archiveDateCU < startDate and startDate < nowDT:  ### startDate <-- endDate
                    name='[COLOR salmon]%s[/COLOR]'%(name)
                    """
                    colondelimit = False
                    if ':' in recordname:
                        recordname = recordname.replace(':','[',1)
                        colondelimit = True
                    """
                    if '[' in recordname:   ### 2018-04-21
                        utils.logdev(module,'[ in recordname= %r' % recordname) 
                    ###xbmcgui.Dialog().ok( ADDON.getAddonInfo('name'), 'name= %r\nrecordname= %r' % (name,recordname))
                    utils.logdev(module,'xYzx name= %r\nrecordname= %r' % (name,recordname))
                    
                    if '[' in recordname:   ### 2018-07-15
                        namecolor='[B][COLOR salmon]'
                        name = ch[15] + ': '+ namecolor + recordname.replace('[','[/COLOR][/B]\n[COLOR lemonchiffon][I][',1) + '[/COLOR][/I]'
                        recordnamesizes = recordname.replace('[','aXaXa',1).split('aXaXa')
                        name = name.split('\n')
                        line1 = name[0]
                        lenline1 = len(recordnamesizes[0])
                        line2 = name[1]
                        lenline2 = len(recordnamesizes[1])
                        if lenline1 < lenline2:
                            line1 = line1 + ' ' * (lenline2 - lenline1 )
                        #dialog = xbmcgui.Dialog()
                        #dialog.ok('[COLOR white]ROQTV Test[/COLOR]',recordname,repr(recordnamesizes)+ ' 1= ' +repr(lenline1)+ ' 2= ' + repr(lenline2))

                        name = line1 +'\n' + line2  
                       
                    time=startDate.strftime('Arc %d.%m %H:%M  ')
                    ###addDir(name,url,mode,iconimage='',cat='',date='',description='',startDate='',endDate='',whatsup='')
                    ###duration = str(timedelta.total_seconds(endDate - startDate)/60 + 16)  ### duration plus 15 min
                    ###utils.logdev(module+'repr(endDate - startDate)=',repr(endDate - startDate))
                    ### ANDROID and Linux version
                    duration = str(int(repr(endDate - startDate).replace('datetime.timedelta(0, ','').split(')')[0].split(',')[0])/60 + 16) ### duration plus 15 min + 1 min ahead
                    start    = startDateCU.strftime('%Y-%m-%d:%H-%M')
                    ROQTVusername = ADDON.getSetting('user')
                    if ROQTVusername.lower() != 'none':
                        url = definition.getBASEURL() + '/streaming/timeshift.php?username='+ROQTVusername+'&password='+ADDON.getSetting('pass')+'&stream='+cat+'&duration='+duration+'&start='+start
                    else:
                        url = 'url'
                    ###utils.logdev(module,'2020 url= ' + url)
                    nowJust = datetime.today()
                    searchcount += 1
                    if searchcount >= searchcountmax and not searchtimereached:
                        if searchcount == searchcountmax:
                            usedtime = str(int((nowJust-nowM).total_seconds()))
                            addDir('[COLOR red][B]Search limit reached ('+str(searchcountmax-1)+') in '+usedtime+' seconds[/B][/COLOR]' ,'',5011,'','0','0','Limit your search!\n\nClick to change limit','0','0','')
                    else:
                        if nowJust > nowM + timedelta(seconds = searchtimemax):
                            if not searchtimereached:
                                addDir('[COLOR red][B]Search time reached ('+str(searchtimemax)+' seconds)[/B][/COLOR]' ,'',5010,'','0','0','Limit your search!\n\nClick to change limit','0','0','')
                                searchtimereached = True
                        else:
                            addDir(time+name,url,2020,newiconurl,cat,startDate,description,startDate,endDate,recordname) ### Watch or record Archive
                elif tv_archive < 1 and endDate < nowDT :  ### Show History (1 day)
                    try:
                        hourstoshow = int(ADDON.getSetting('showhistoryintvguide'))
                        ###utils.logdev(module,'H start= %r, end= %r' % (startDate, endDate))
                        name='[COLOR cyan]%s[/COLOR]'%(name)
                        
                        if '[' in recordname:   ### 2018-04-21
                            namecolor='[B][COLOR cyan]'
                            name = ch[15] + ': '+ namecolor + recordname.replace('[','[/COLOR][/B]\n[COLOR lemonchiffon][I][',1) + '[/COLOR][/I]'
                            recordnamesizes = recordname.replace('[','aXaXa',1).split('aXaXa')
                            name = name.split('\n')
                            line1 = name[0]
                            lenline1 = len(recordnamesizes[0])
                            line2 = name[1]
                            lenline2 = len(recordnamesizes[1])
                            if lenline1 < lenline2:
                                line1 = line1 + ' ' * (lenline2 - lenline1 )
                            #dialog = xbmcgui.Dialog()
                            #dialog.ok('[COLOR white]ROQTV Test[/COLOR]',recordname,repr(recordnamesizes)+ ' 1= ' +repr(lenline1)+ ' 2= ' + repr(lenline2))

                            name = line1 +'\n' + line2  
                        
                        time=startDate.strftime('His %d.%m %H:%M  ')
                        if endDate > nowDT - timedelta(hours = hourstoshow):
                            nowJust = datetime.today()
                            searchcount += 1
                            if searchcount >= searchcountmax and not searchtimereached:
                                if searchcount == searchcountmax:
                                    usedtime = str(int((nowJust-nowM).total_seconds()))
                                    addDir('[COLOR red][B]Search limit reached ('+str(searchcountmax-1)+') in '+usedtime+' seconds[/B][/COLOR]' ,'',5011,'','0','0','Limit your search!\n\nClick to change limit','0','0','')
                            else:
                                if nowJust > nowM + timedelta(seconds = searchtimemax):
                                    if not searchtimereached:
                                        addDir('[COLOR red][B]Search time reached ('+str(searchtimemax)+' seconds)[/B][/COLOR]' ,'',5010,'','0','0','Limit your search!\n\nClick to change limit','0','0','')
                                        searchtimereached = True
                                else:
                                    addDir(time+name,'url',200,newiconurl,cat,startDate,description,startDate,endDate,recordname)
                    except:
                        pass
                elif startDate <= nowDT and nowDT <= endDate:
                    name='[COLOR yellow]%s[/COLOR]'%(name)
                    
                    if '[' in recordname:   ### 2018-04-21
                        namecolor='[B][COLOR yellow]'
                        name = ch[15] + ': '+ namecolor + recordname.replace('[','[/COLOR][/B]\n[COLOR lemonchiffon][I][',1) + '[/COLOR][/I]'
                        recordnamesizes = recordname.replace('[','aXaXa',1).split('aXaXa')
                        name = name.split('\n')
                        line1 = name[0]
                        lenline1 = len(recordnamesizes[0])
                        line2 = name[1]
                        lenline2 = len(recordnamesizes[1])
                        if lenline1 < lenline2:
                            line1 = line1 + ' ' * (lenline2 - lenline1 )
                        #dialog = xbmcgui.Dialog()
                        #dialog.ok('[COLOR white]ROQTV Test[/COLOR]',recordname,repr(recordnamesizes)+ ' 1= ' +repr(lenline1)+ ' 2= ' + repr(lenline2))

                        name = line1 +'\n' + line2  
                    
                    time=startDate.strftime('Now %d.%m %H:%M  ')
                    url = channelurl
                    nowJust = datetime.today()
                    searchcount += 1
                    if searchcount >= searchcountmax and not searchtimereached:
                        if searchcount == searchcountmax:
                            usedtime = str(int((nowJust-nowM).total_seconds()))
                            addDir('[COLOR red][B]Search limit reached ('+str(searchcountmax-1)+') in '+usedtime+' seconds[/B][/COLOR]' ,'',5011,'','0','0','Limit your search!\n\nClick to change limit','0','0','')
                    else:
                        if nowJust > nowM + timedelta(seconds = searchtimemax):
                            if not searchtimereached:
                                addDir('[COLOR red][B]Search time reached ('+str(searchtimemax)+' seconds)[/B][/COLOR]' ,'',5010,'','0','0','Limit your search!\n\nClick to change limit','0','0','')
                                searchtimereached = True
                        else:
                            addDir(time+name,url,200,newiconurl,cat,startDate,description,startDate,endDate,recordname)
                elif startDate > nowDT and endDate > nowDT:
                    ### Find programs that are recording
                    recprograms = recordings.isRecording(cat,recordname,startDate,endDate)
                    utils.logdev(module,'PROGRAMSEARCH Is program: %r beeing recorded? SD= %r ED= %r ActivePrograms: %r' %(name,startDate,endDate,recprograms))
                    if recprograms:
                        name='[COLOR red]%s[/COLOR]'%(name)
                        namecolor='[B][COLOR red]'
                    else:
                        name='[COLOR lightgreen]%s[/COLOR]'%(name)
                        namecolor='[B][COLOR lightgreen]'
                    
                    time=startDate.strftime('Rec %d.%m %H:%M  ')
                    nowJust = datetime.today()
                    searchcount += 1
                    if searchcount >= searchcountmax and not searchtimereached:
                        if searchcount == searchcountmax:
                            usedtime = str(int((nowJust-nowM).total_seconds()))
                            addDir('[COLOR red][B]Search limit reached ('+str(searchcountmax-1)+') in '+usedtime+' seconds[/B][/COLOR]' ,'',5011,'','0','0','Limit your search!\n\nClick to change limit','0','0','')
                    else:
                        if nowJust > nowM + timedelta(seconds = searchtimemax):
                            if not searchtimereached:
                                addDir('[COLOR red][B]Search time reached ('+str(searchtimemax)+' seconds)[/B][/COLOR]' ,'',5010,'','0','0','Limit your search!\n\nClick to change limit','0','0','')
                                searchtimereached = True
                        else:  
                            if '[' in recordname:   ### 2018-04-21
                                name = ch[15] + ': '+ namecolor + recordname.replace('[','[/COLOR][/B]\n[COLOR lemonchiffon][I][',1) + '[/COLOR][/I]'
                                recordnamesizes = recordname.replace('[','aXaXa',1).split('aXaXa')
                                name = name.split('\n')
                                line1 = name[0]
                                lenline1 = len(recordnamesizes[0])
                                line2 = name[1]
                                lenline2 = len(recordnamesizes[1])
                                if lenline1 < lenline2:
                                    line1 = line1 + ' ' * (lenline2 - lenline1 )
                                #dialog = xbmcgui.Dialog()
                                #dialog.ok('[COLOR white]ROQTV Test[/COLOR]',recordname,repr(recordnamesizes)+ ' 1= ' +repr(lenline1)+ ' 2= ' + repr(lenline2))
        
                                name = line1 +'\n' + line2  
                            else:
                                name = '[B]' + name ### + '[/B]'
                            
                            addDir(time+name,'url',2001,newiconurl,cat,startDate.strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20'),description,startDate.strftime('%Y-%m-%d %H:%M:%S'),endDate.strftime('%Y-%m-%d %H:%M:%S'),recordname) ### Record
                else:
                    utils.logdev(module,'PROGRAMSEARCH Out of Range start= %r, end= %r' % (startDate, endDate))
            except Exception, e:
                pass
                utils.logdev(module,'PROGRAMSEARCH Error in setting menu\n' + repr(e))
        if searchcount == 0 and not searchtimereached:
            nowJust = datetime.today()
            usedtime = str(int((nowJust-nowM).total_seconds()))
            addDir('[COLOR lightgreen][B]Search finished in '+usedtime+' seconds, no EPG Programs found[/B][/COLOR]' ,'url',2050,'','0','0','Searched for: '+searchText.replace('%',''),'0','0','')
        if searchcount > 0 and searchcount < searchcountmax and not searchtimereached:
            usedtime = str(int((nowJust-nowM).total_seconds()))
            addDir('[COLOR lightgreen][B]Search finished in '+usedtime+' seconds, found '+str(searchcount)+' EPG Programs[/B][/COLOR]' ,'url',2050,'','0','0','Searched for: '+searchText.replace('%',''),'0','0','')    
        c.close()  
        setView('movies', 'main-view')      
              
def CHANNELSSEARCH():
    searchcount = 0
    searchcountmax = int(ADDON.getSetting('searchcountmax')) + 1
    searchtimemax = int(ADDON.getSetting('searchtimemax')) ### seconds
    searchtimereached = False
    
    GoHome('Search Channels')
    
    searchText = SearchEPG('Channel, VOD or TV Series to search for')
    ###dialog = xbmcgui.Dialog()
    ###dialog.ok('[COLOR white]ROQTV Test[/COLOR]','Channel or VOD to search for',repr(searchText))
    if searchText != '' and searchText != None and searchText != False:
        nowM = datetime.today()
        now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        addDir('[COLOR lightgreen]Search Channels, VOD and TV Series: [/COLOR][B]'+searchText+'[/B]','url',2008,'','','','Search all '+ADDONname +' Channels, VOD, TV Series and all direct channels')
        searchText = '%' + searchText + '%'
        
        conn = recordings.getConnection()
        c = conn.cursor()
        c.execute("SELECT * FROM channels WHERE stream_url <> ? and visible=? and title LIKE ?  and source=? COLLATE NOCASE", ['url',1,searchText,origin])   ### 2018-12-07
        favorites = c.fetchall()
        ###utils.logdev(module+'-archive',repr(len(favorites)))
        favorites = sorted(favorites, key=itemgetter(1))
        ###utils.logdev(module+'-archive',repr(len(favorites))) 
        for index in range(0, len(favorites)):
            ch = []
            for i in range(0, len(favorites[index])):
                if favorites[index][i] == None:
                    ch.append('')
                else:
                    ch.append(favorites[index][i])
            ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
            ###def addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
            ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
            if ch[8] >= 1 and ch[8] != '' :
                chname = ch[1] + ' (A)'
            else:
                chname = ch[1]
            ###chx = ch[10]    ### Don't insert live EPG in description
            ###utils.logdev(module,'cat= %r, description= %r' % (ch[0],setLiveEPG(ch)))  ### 2017-07-29
            nowJust = datetime.today()
            searchcount += 1
            if searchcount >= searchcountmax and not searchtimereached:
                if searchcount == searchcountmax:
                    usedtime = str(int((nowJust-nowM).total_seconds()))
                    addDir('[COLOR red][B]Search limit reached ('+str(searchcountmax-1)+') in '+usedtime+' seconds[/B][/COLOR]' ,'',5011,'','0','0','Limit your search!\n\nClick to change limit','0','0','')
            else:
                if nowJust > nowM + timedelta(seconds = searchtimemax):
                    if not searchtimereached:
                        addDir('[COLOR red][B]Search time reached ('+str(searchtimemax)+' seconds)[/B][/COLOR]' ,'',5010,'','0','0','Limit your search!\n\nClick to change limit','0','0','')
                        searchtimereached = True
                else:
                    addDir(chname,ch[3],200,ch[2],ch[0],'',setLiveEPG(ch))
        ###conn.commit()
        if searchcount == 0 and not searchtimereached:
            nowJust = datetime.today()
            usedtime = str(int((nowJust-nowM).total_seconds()))
            addDir('[COLOR lightgreen][B]Search finished in '+usedtime+' seconds, no Channels or VOD found[/B][/COLOR]' ,'url',2008,'','0','0','Searched for: '+searchText.replace('%',''),'0','0','')
        if searchcount > 0 and searchcount < searchcountmax and not searchtimereached:
            usedtime = str(int((nowJust-nowM).total_seconds()))
            addDir('[COLOR lightgreen][B]Search finished in '+usedtime+' seconds, found '+str(searchcount)+' Channels, VOD and TV Series[/B][/COLOR]' ,'url',2008,'','0','0','Searched for: '+searchText.replace('%',''),'0','0','')  
        c.close()  
        setView('movies', 'main-view')      
        
def CHANNELSROQ():
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###now= datetime.today()
    ###utils.logdev(module,'CHANNELSROQ')
    GoHome('Channels')
    conn = recordings.getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE stream_url <> ? and visible=?", ['url',1])
    favorites = c.fetchall()
    ###utils.logdev(module+'-archive',repr(len(favorites)))
    favorites = sorted(favorites, key=itemgetter(1))
    ###utils.logdev(module+'-archive',repr(len(favorites)))
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
        ###def addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
        ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
        if ch[8] >= 1 and ch[8] != '' :
            chname = ch[1] + ' (A)'
        else:
            chname = ch[1]
        ###chx = ch[10]    ### Don't insert live EPG in description
        ###utils.logdev(module,'cat= %r, description= %r' % (ch[0],setLiveEPG(ch)))  ### 2017-07-29
        addDir(chname,ch[3],200,ch[2],ch[0],'',setLiveEPG(ch))
    ###conn.commit()
    c.close()  
    setView('movies', 'main-view')      
"""

http://roq-tv.net:25461/live/XXX/XXXX!/631.ts

http://roq-tv.net:25461/streaming/timeshift.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass') +'&stream=628&duration=120&start=2017-05-03:15-00

import urllib2
mp3file = urllib2.urlopen("http://www.example.com/songs/mp3.mp3")
with open('test.mp3','wb') as output:
  output.write(mp3file.read())

def addDir(name,url,mode,iconimage,description,fanart,genre=''):
        u=sys.argv[0]+"?url="+urllibquote_plus(url)+"&mode="+str(mode)+"&name="+urllibquote_plus(name)+"&iconimage="+urllibquote_plus(iconimage)+"&description="+urllibquote_plus(description)+"&genre="+urllibquote_plus(genre)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description,"Genre": genre} )
        liz.setProperty('fanart_image',str(fanart))
        if mode ==200:
            liz.setProperty("IsPlayable","true")
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        .......
        try:
        kodilog = xbmc.translatePath(os.path.join('special://logpath' , 'kodi.log'))
        #print kodilog
        try: logfile = open(kodilog,'r')
        except:
            pass
            kodilog = xbmc.translatePath(os.path.join('special://logpath' , 'xbmc.log'))
            #print kodilog
            try: logfile = open(kodilog,'r')
            except:
                pass
                kodilog = xbmc.translatePath(os.path.join('special://logpath' , 'tvmc.log'))
                #print kodilog
                logfile = open(kodilog,'r')
        #print kodilog
        #print repr(logfile)
        line0 = logfile.readline()
        #print line0
        line1 = logfile.readline()
        
        ............
        
#EXTM3U
#EXTINF:-1 tvg-id="BBC One London" tvg-name="UK: BBC ONE HD" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/1/1a/BBC_One_2002.png" group-title="UK: ENTERTAINMENT",UK: BBC ONE HD
http://roq-tv.net:25461/live/XXX/XXXX!/281.ts
#EXTINF:-1 tvg-id="BBC 1 CI" tvg-name="UK: BBC ONE CI (VPN OR UK ONLY)" tvg-logo="http://www.tv-logo.com/pt-data/uploads/images/logo/bbc_one_channel_islands.jpg" group-title="UK: ENTERTAINMENT",UK: BBC ONE CI (VPN OR UK ONLY)
http://roq-tv.net:25461/live/XXX/XXXX!/1457.ts

"""
            
def CATEGORIES():
    ###utils.logdev(module,'CATEGORIES ADDON= ' + ADDONid)
    if ADDON.getSetting('internet') == 'true':
        LOGIN()
        ROQTVusername = ADDON.getSetting('user')
        if ROQTVusername.lower() != 'none':
            channeltxt = 'll '+ADDONname +' and direct channel '
        else:
            channeltxt = 'll direct channel '
        ROQTVusername = ADDON.getSetting('user')
        if ROQTVusername.lower() != 'none':
            addDir('[COLOR lightgreen]Favorites[/COLOR]','url',17,'','','','All '+ADDONname +' and direct channel favorites, you have selected on this box')
        else:
            addDir('[COLOR lightgreen]Favorites[/COLOR]','url',17,'','','','All direct channel favorites, you have selected on this box')
        if ADDON.getSetting('enable_record')=='true':
            addDir('[COLOR lightgreen]Planned Recordings[/COLOR]','url',3,'','','','Planned recordings, result of recordings and recursive recordings')
    
        ROQTVusername = ADDON.getSetting('user')
        if ROQTVusername.lower() != 'none':
            addDir('[COLOR lightgreen]Search Channels, VOD and TV Series[/COLOR]','url',2008,'','','','Search all '+ADDONname +' channels, VOD, TV Series and all direct channels')
        else:
            addDir('[COLOR lightgreen]Search Channels[/COLOR]','url',2008,'','','','Search all direct channels from XMLTV file ')
    
        ROQTVusername = ADDON.getSetting('user')
        if ROQTVusername.lower() != 'none':
            addDir('[COLOR lightgreen]Search EPG Programs[/COLOR]','url',2050,'','','','Search all '+ADDONname +' channels EPG')
        else:
            addDir('[COLOR lightgreen]Search EPG Programs[/COLOR]','url',2050,'','','','Search all direct channels EPG')
    if ADDON.getSetting('enable_record')=='true' or recordArchivePath != '' or recordPath != '' :
        ###addDir('[COLOR lightgreen]Search Channels and VOD[/COLOR]','url',2008,'','','','Search all '+ADDONname +' channels and all channels from extra XMLTV file ')
        SearchPath = 'All recorded items in[CR]' + recordPath
        SearchPathLocal = SearchPath
        if recordArchivePath != '':
            SearchPath += '[CR][CR]and all items in archive[CR]' + recordArchivePath
        SearchPath = SearchPath.replace('/','/ ').replace('\\','\\ ')
        SearchPathLocal = SearchPathLocal.replace('/','/ ').replace('\\','\\ ')
        addDir('[COLOR lightgreen]Search Recordings in Database[/COLOR]','url',2065,'','','','Search recording files and archive in Database')
        if ADDON.getSetting('sortalphabetic') == 'true':
            addDir('[COLOR lightgreen]Search Recordings Alphabetical[/COLOR]','url',6,'','','',SearchPath+'\n\nSorted alphabetically')
        else:
            addDir('[COLOR lightgreen]Search Recordings by Date[/COLOR]','url',66,'','','',SearchPath+'\n\nSorted by file date')
        ###addDir('[COLOR lightgreen]Search Recordings[/COLOR]','url',6,'','','',SearchPath+'\n\nSorted alphabetically')
        addDir('[COLOR lightgreen]Latest Recordings[/COLOR]','url',2060,'','','',SearchPathLocal+'\n\nSorted by file date')
        ###addDir('[COLOR lightgreen]Search Channels and VOD[/COLOR]','url',2008,'','','','Search all '+ADDONname +' channels and all channels from extra XMLTV file ')
        ###addDir('[COLOR lightgreen]Planned Recordings[/COLOR]','url',3,'','','','Planned recordings, result of recordings and recursive recordings')
    
    """###Try to access catchup START
    ### 738 5.104997131 192.168.20.6    109.236.84.104  HTTP    234 GET /panel_api.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass') HTTP/1.1 
    link = 'http://roq-tv.net:25461/streaming/timeshift.php?username=XXX&password=XXXX&stream=276&duration=120&start=2017-05-21:16-00'
    ###http://roq-tv.net:25461/streaming/timeshift.php?username=XXX&password=XXXX'
    file = urllib2.urlopen(link)
    data = file.read()
    file.close()
    for titem in ['title','description']:
        ###utils.logdev('Test Encoding','titem= ' + repr(titem) + ' - data= ' + repr(data))

        data = data.split('<'+titem+'>')
        ###utils.logdev('Test Encoding 1',repr(data))
        i=0
        newdata= ''
        for part in data:
            ###utils.logdev('Test Encoding 2',repr(part))
            if i==0:
                newdata+=part
                ###utils.logdev('Test Encoding 3',repr(newdata))
                i+=1
            else:
                part=part.split('</'+titem+'>',1)
                ###utils.logdev('Test Encoding 4',repr(part))
                ### newdata+='<'+titem+'>' + base64.b64decode(part[0]) +'</'+titem+'>' + part[1]
                newdata+='<'+titem+'>' + base64.b64decode(part[0], '-_') +'</'+titem+'>' + part[1]
                ###utils.logdev('Test Encoding 5',repr(newdata))
        ###utils.logdev('Test Encoding 6',repr(newdata))
        data = newdata
    data = xmltodict.parse(newdata)
    ###utils.logdev('Test Encoding x',repr(data))
    
    for i, (key, value) in enumerate(data.iteritems()):
        ###utils.logdev('Test Encoding y1','i= %s, key= %s, value= %s' % (repr(i), repr(key),repr(value)))
        for i1, (key1, value1) in enumerate(value.iteritems()):
            if key1 == 'channel':
                ###utils.logdev('Test Encoding y2','i1= %s, key1= %s, value1= %s' % (repr(i1), repr(key1),repr(value1)))
                for channelROQ in value1:
                    d=channelROQ

                    ###utils.logdev('Test Encoding y3','i1= %s, key1= %s, channelROQ= %s, url= %s' % (repr(d.items()[0]), repr(d.items()[1]),repr(d.items()[2]),repr(d.items()[3])))
                    ###utils.logdev('Test Encoding y4','\n\ntitle= %s,\n description= %s,\n category_id= %s,\n playlist_url= %s\n' % (repr(d['title']), repr(d['description']),repr(d['category_id']),repr(d['playlist_url'])))
                    addDir(d['title'],d['playlist_url'],22,d['category_id'],'','',d['description'])
    ###Try to access catchup END
    """
    
    ###addDir('Search Channels and VOD','url',2008,'','','','Search all '+ADDONname +' channels and all channels from extra XMLTV file ')
    ###if ADDON.getSetting('enable_record')=='true':
        ###addDir('Recordings','url',6,'','','','All recorded items in ' + recordPath)
        ###addDir('[COLOR lightgreen]Planned Recordings[/COLOR]','url',3,'','','','Planned recordings, result of recordings and recursive recordings')
        ###addDir('Recursive Search Channels','url',26,'','','','All channels used for recursive search')
        ###addDir('Restore Planned Recordings','url',104,'','','','Restore planned recordings or just recursive recordings')
        ###addDir('Delete New EPG programs','url',110,'','','','delNewEPGPrograms():   ### If to many programs have changed - update full afterwards')
        ###addDir('Delete All Channels','url',108,'','','','delAllChannels():   ### If user have changed - update full afterwards')
        ###addDir('Delete All Planned Recordings','url',109,'','','','delAllPlannedPrograms():   ### If recursive have made too many recordings - Stop all recordings and clear parts of database')
    if ADDON.getSetting('internet') == 'true':
        addDir('Streams','url',490,'','','',ADDONname + ' Streams')
    
    ###
    
    userinfo = ''
    ROQTVusername = ADDON.getSetting('user')
    if ROQTVusername.lower() != 'none' or ADDON.getSetting('internet') != 'true':
        try:
            link = definition.getBASEURL() + '/panel_api.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')
            file = urllib2.urlopen(link)
            data = file.read()
            file.close()
            
            ChannelFile = os.path.join(datapath,ADDONid) + '.info'
            with open(ChannelFile,'wb') as output:
                output.write(data)
            ###name= Status,url= url,mode= 11,iconimage= ,cat= ,date= ,description= {u'username': u'XXX', u'status': u'Active', u'is_trial': u'0', u'created_at': u'1493734688', u'auth': 1, u'allowed_output_formats': [u'm3u8', u'ts', u'rtmp'], u'exp_date': u'1499005088', u'active_cons': u'0', u'password': u'XXXX', u'max_connections': u'1'},startDate= ,endDate= ,recordname= )
            d = json.loads(data)
            d1 = d['user_info']
            
            formats = d1['allowed_output_formats']
            allowedformats = AllowedFormats(formats)
            
            if d1['is_trial'] == '1':
                is_trial = '\nThis is a trial '
            else:
                is_trial = ''
            now = datetime.now()
            remainingdays = (recordings.parseDate(d1['exp_date'])-recordings.parseDate(now)).days
            if remainingdays < 7:
                remainingdaysS = '[B][COLOR red] '+ str(remainingdays)  + '[/COLOR][/B]'
            else:
                remainingdaysS = str(remainingdays)
            ###descr = 'Username= %s \nStatus= %s \nExpire= %s%s%s\nMax connections= %s \nConnections in use= %s \nAllowed formats= %s' %(d1['username'],d1['status'],recordings.parseDate(d1['exp_date']).strftime('%Y-%m-%d %H:%M'),remainingdaysS,is_trial,d1['max_connections'],d1['active_cons'],allowedformats)
            if ADDON.getSetting('enable_record')=='true':
                PRC = getPlannedRecordingCounts()    
                userinfo = d1['max_connections'] + '/' +d1['active_cons'] + ' ' + remainingdaysS + ' ' + PRC
            else:    
                userinfo = d1['max_connections'] + '/' +d1['active_cons'] + ' ' + remainingdaysS
            
            ###userinfo = d1['max_connections'] + '/' +d1['active_cons'] + ' ' + remainingdaysS
        
            ###addDir('Basic Info','url',12,'','','',descr)
        except Exception, e:
            pass
            utils.notification('Error in getting '+ ADDONid + ' info! Check your User ID\n' + repr(e))
            ###addDir('Basic Info','url',0,'1','','','Error in getting '+ ADDONid + ' info! Check your User ID\n' + repr(e))
            ###d = []
    ###
    if ADDON.getSetting('internet') == 'true':
        try:   ### 2018-10-26
            RytecAddon = xbmcaddon.Addon(id='service.rytecepg.downloader')
            RytecAction = RytecAddon.getSetting('active')
        except Exception,e:
            pass
            RytecAction = ''
            utils.logdev(module,'Get Rytec Action - ERROR: %r' % e)
        if userinfo != '':
            EPG_update = [userinfo]
        else:
            EPG_update = []
        ###if ADDON.getSetting('Recordings') != '':
        ###    EPG_update.append('Recording')
        if locking.isAnymarkLocked():
            EPG_update.append('[COLOR red]Rec[/COLOR]')
        if locking.isScanLocked('EPG_update'):
            EPG_update.append('EPG updating')
        if ADDON.getSetting('RecursiveSearch') == 'true':
            EPG_update.append('Recursive Search')
        if RytecAction != '':
            EPG_update.append('Rytec: %s' % RytecAction)
        StatusCode = ''
        if len(EPG_update) > 0:
            Status = ', '.join(EPG_update)
            StatusCode = '\n[I][COLOR grey]'+ Status + '[/COLOR][/I]'
      
        addDir('Maintenance' + StatusCode,'url',49,'','','','Database Maintenance')
    ###addDir('My Account','url',8,'','','','Change your user name/email address and password or restore previous configurations. \n\nWatch your basic account information')
    ###addDir('Hidden Channels','url',20,'','','','All channels you have hidden from the other views')
    addDir('[COLOR red]Back to Kodi[/COLOR]','url',29,'','','','Back to Kodi from the %s addon' % ADDONname)
    
    try:
        ### httplink = 'http://roq-tv.net:25461/get.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')+ '&type=m3u_plus&output='+streamtype
        ROQTVusername = ADDON.getSetting('user')
        if ROQTVusername.lower() != 'none':
            httplink = definition.getBASEURL() + '/get.php?username='+ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')+ '&type=m3u_plus&output='+streamtype
            """
            httplinkEPG = definition.getBASEURL() +'/xmltv.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')
            ###utils.logdev(module,'roq-tv EPG link: ' + repr(httplinkEPG))
            m3ufile = urllib2.urlopen(httplinkEPG)
            ChannelFile = os.path.join(datapath,ADDONid) + 'EPG.xml'
            with open(ChannelFile,'wb') as output:
                output.write(m3ufile.read())
            ######utils.logdev(module,'roq-tv EPG file downloaded: ' + repr(ChannelFile))
            #########utils.logdev('Decoded XML file',repr(newdata))
            ###########2017-06-14
            epgfile = open(ChannelFile, 'r')
            dataepg = epgfile.read()
            epgfile.close() 
            dataepg = xmltodict.parse(dataepg)
            #########utils.logdev('Decoded Dict',repr(data))
            channelsxml = os.path.join(datapath, 'channelsdictEPG')  + '.dict'
            LF = open(channelsxml, 'w')
            LF.write(repr(dataepg))
            LF.close()
            
            """
            ### Save .m3u file with all channels!
            utils.logdev(module,'Categories link: ' + repr(httplink))
            m3ufile = urllib2.urlopen(httplink)
            ChannelFile = os.path.join(datapath,ADDONid) + '.m3u'
            with open(ChannelFile,'wb') as output:
                output.write(m3ufile.read())
            utils.logdev(module,'roq-tv m3u file downloaded: ' + repr(ChannelFile))
            
    except Exception, e:
        pass
        utils.logdev(module,'Error in get Categori: ' + repr(e))
    
    setView('movies', 'main-view')         

def CHANNELSROQOLD(cname,cat,link,description):
    """ Stream
    OrderedDict([
     (u'title', u'UK: SKY SPORTS ACTIVE 5'), 
     (u'description', None), 
     (u'desc_image', u'http://www.tv-logo.com/pt-data/uploads/images/logo/sky_uk_sports_active_hi_01.jpg'), 
     (u'category_id', u'38'), 
     (u'stream_url', u'http://roq-tv.net:25461/live/XXX/XXXX/2782.ts')]), 
     
     Category
     <channel>
     <title>All</title>
     <description>Live Streams Category [ ALL ]</description>
     <category_id>0</category_id>
     <playlist_url><![CDATA[http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass') + '&cat_id=0]]></playlist_url>
     </channel>
    """
    GoHome('Live Streams, Vod or TV series')
    ###link = 'http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')
    utils.logdev(module,'Live Streams, Vod or TV series link=\n%r' % link)
    file = urllib2.urlopen(link)
    data = file.read()
    file.close()
    data = data.replace('\n','').replace('<description/>','<description></description>')
    ###channelsxml = os.path.join(datapath, 'channelsxml-1')  + '.xml'
    ###LF = open(channelsxml, 'w')
    ###LF.write(data)
    ###LF.close()
    for titem in ['title','description']:
        #########utils.logdev('Test Encoding','titem= ' + repr(titem) + ' - data= ' + repr(data))
        data = data.split('<'+titem+'>')
        #########utils.logdev('Test Encoding 1',repr(data))
        #########utils.logdev(module,'Test Encoding 1')
        i=0
        newdata= ''
        for part in data:
            #########utils.logdev('Test Encoding 2',repr(part))
            #########utils.logdev(module,'Test Encoding 2')
            if i==0:
                newdata+=part
                #########utils.logdev('Test Encoding 3',repr(newdata))
                i+=1
                #########utils.logdev(module,'Test Encoding 3')
            else:
                part=part.split('</'+titem+'>',1)
                #########utils.logdev(module,'Test Encoding 4')
                #########utils.logdev('Test Encoding 4',repr(part))
                ### newdata+='<'+titem+'>' + base64.b64decode(part[0]) +'</'+titem+'>' + part[1]
                if not part[0] == None:
                    #########utils.logdev(module,'Test Encoding 5')
                    #########utils.logdev('Test Encoding 4a',repr(part))
                    if titem == 'title':
                        ###decodedtext = recordings.latin1_to_ascii_force(base64.b64decode(part[0], '-_').replace('&','&amp;').split('[',1)[0]).replace('<<','XX')
                        decodedtext = recordings.latin1_to_ascii_force(base64.b64decode(part[0], '-_').replace('&','&amp;')).replace('<<','XX')###.replace('[','|').replace(']','|')  ### 2019-02-11
                        #########utils.logdev(module,'Test Encoding 6')
                    else:
                        decodedtext = recordings.latin1_to_ascii_force(base64.b64decode(part[0], '-_').replace('&','&amp;')).replace('<<','XX')
                        #########utils.logdev(module,'Test Encoding 7')
                else:
                    utils.notification('Missing channel: ' + repr(part))
                    decodedtext=''
                    #########utils.logdev(module,'Test Encoding 8')
                newdata+='<'+titem+'>' + decodedtext +'</'+titem+'>' + part[1]
                #########utils.logdev(module,'Test Encoding 9')
                #########utils.logdev('Test Encoding 5',repr(newdata))
        #########utils.logdev('Test Encoding 6',repr(newdata))
        #########utils.logdev(module,'Test Encoding 10')
        data = newdata
    #########utils.logdev(module,'Test Encoding 11')
    channelsxml = os.path.join(datapath, 'channelsxml')  + '.xml'
    LF = open(channelsxml, 'w')
    LF.write(newdata)
    LF.close()
    #########utils.logdev('Decoded XML file',repr(newdata))
    try:
        data = xmltodict.parse(newdata)
    except Exception, e:
        pass
        utils.logdev(module,'Error in xmltodict.parse(newdata): ' + repr(e))
        data = ''
    #########utils.logdev('Decoded Dict',repr(data))
    channelsxml = os.path.join(datapath, 'channelsdict')  + '.dict'
    LF = open(channelsxml, 'w')
    LF.write(repr(data))
    LF.close()
    ###addDir('Favorites','url',17,'','','','All '+ADDONname +' favorites, you have selected on this box')
    try:
        utils.logdev(module,'Test Encoding 12')
        for i, (key, value) in enumerate(data.iteritems()):
            #########utils.logdev('Test Encoding y1','i= %s, key= %s, value= %s' % (repr(i), repr(key),repr(value)))
            #########utils.logdev(module,'Test Encoding 13')
            for i1, (key1, value1) in enumerate(value.iteritems()):
                ######utils.logdev(module,'Test Encoding 14')
                if key1 == 'channel':
                    ######utils.logdev(module,'Test Encoding 15')
                    ######utils.logdev('Test Encoding y2','i1= %s, key1= %s, value1= %s' % (repr(i1), repr(key1),repr(value1)))
                    for channelROQ in value1:
                        utils.logdev(module,'channelROQ= %r' % channelROQ)  ### 2017-12-29
                        d=channelROQ
                        
                        if 'stream_url' in d and not d['stream_url'] == None:
                            ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
                            utils.logdev(module,'stream_url in channelROQ')
                            StreamURL=d['stream_url'].replace('![CDATA[','',1).replace(']]','',1)
                        
                            if not d['desc_image'] == None:
                                DescURL=d['desc_image'].replace('![CDATA[','',1).replace(']]','',1)
                            else:
                                DescURL = ''
                            try:
                                Description=d['description']
                                utils.logdev(module,'Description= %r, type= %r' %(Description,type(Description)))
                                if isinstance(Description, dict):
                                    Description = Description['em']+'\n'+Description['#text']
                                elif not isinstance(Description, unicode):
                                    if not (Description == None or Description == ''):
                                        Description='Unknown description type: ' + repr(type(Description))
                                    else: 
                                        ######utils.logdev(module,'Description= %s, type= %s' %( repr(Description),repr(type(Description))))
                                        Description = ''
                            except Exception, e:
                                pass
                                utils.logdev(module,'Error in get Description: ' + repr(e))
                                Description= 'Error in get Description: ' + repr(e)    ### ''  2018-06-30
                            ###utils.logdev(module,'Test Encoding 18')
                            utils.logdev(module,'Test Encoding 18 Title= %s, Stream= %s, DescURL= %s, Category_ID= %s, Description= %s' % (d['title'],StreamURL,DescURL,d['category_id'],Description))
                            catThis = recordings.catFromUrl(StreamURL)
                            if ADDON.getSetting('user') in catThis :
                                catThis = '#'
                            utils.logdev(module,'catThis= %r' % catThis)
                            if recordings.isChannelVisible(catThis) or catThis == '#': ### 2019-02-11 Always visible
                                utils.logdev(module,'Visible catThis= %r' % catThis)
                                ###utils.logdev(module,'catThis = recordings.catFromUrl(StreamURL)= %r ' % catThis)
                                ##recordings.addChannel(d['title'].strip(),StreamURL,DescURL,catThis, ADDONid,description=Description)
                                ###def addDir(name,url,mode,iconimage='',cat='',date='',description='',startDate='',endDate='',recordname='',whatsup=''):
                                try:
                                    olddescription = recordings.getChannelDescription(catThis)
                                    ###utils.logdev(module,'get olddescription: ' + repr(olddescription))
                                    if catThis == '#' or 1 != 0: ### 2019-02-11 TEST
                                        Description = Description ### Always use original description
                                        if catThis != '#' :
                                            recordings.setChannelDescription(catThis,Description)   ### 2019-02-11 Save descriptions in onlinE DATABASE
                                    elif olddescription != '':    ### 2018-06-30 keep description
                                        Description = olddescription
                                    else:
                                        recordings.setChannelDescription(catThis,Description)
                                except Exception, e:
                                    pass
                                    utils.logdev(module,'Error in get olddescription: ' + repr(e))
                                ###utils.logdev(module,'cat= <%r>1 \nurl= %r' % (catThis,StreamURL))
                                if 'movie' in StreamURL or 'series' in StreamURL or catThis == '#':
                                    chx = Description  ### Description of Movies
                                    ###utils.logdev(module,'MOVIE cat= <%r>1 \nurl= %r' % (catThis,StreamURL))
                                else:
                                    EPGx = updateepg.getEPGnow(catThis)  ### Live EPG on channels
                                    EPG  = EPGx[0]
                                    ###utils.logdev(module,'LIVE cat= <%r>1 \nurl= %r' % (catThis,StreamURL))
                                    ###utils.logdev(module,'EPGx[4]= <%r> \nEPGx[0]= %r' % (EPGx[4],EPGx[0]))
                                    if EPGx[4] != '':
                                        ###utils.logdev(module,'LIVE EPG cat= <%r>1 \nurl= %r \nlen(EPG)= %r' % (catThis,StreamURL,len(EPG)))
                                        chx = EPGx[4]
                                        if EPGx[3] > 0:
                                            chx += ' \nArchive Duration ' + str(EPGx[3]) + '\n'   ### 2018-06-11
                                        for indexX in range(0, len(EPG)):
                                            title = str(EPG[indexX][0])
                                            description = str(EPG[indexX][1])
                                            ###starttime = str(EPG[indexX][3].strftime('%H:%M'))
                                            ###endtime = str(EPG[indexX][4].strftime('%H:%M'))
                                            starttime = str(datetime.fromtimestamp(EPG[indexX][3]).strftime('%H:%M'))
                                            endtime = str(datetime.fromtimestamp(EPG[indexX][4]).strftime('%H:%M'))
                                            chx += ' \n[COLOR lightgreen]'+starttime + ' - ' + endtime + '[/COLOR] \n[COLOR blue]'+ title+ '[/COLOR] \n'+ description +' \n'
                                    else:
                                        chx = Description
                                addDir(d['title'].strip(),StreamURL,200,DescURL,catThis,'',chx)
                                utils.logdev(module,'XXXX Test Encoding stream\n\ntitle= %s,\n description= %s,\n category_id= %s,\n stream_url= %s\n' % (repr(d['title']), repr(d['description']),repr(d['category_id']),repr(d['stream_url'])))
                                
                        elif 'playlist_url' in d and not d['playlist_url'] == None:
                            ######utils.logdev(module,'Test Encoding 19')
                            PlaylistURL=d['playlist_url'].replace('![CDATA[','',1).replace(']]','',1)
                            try:
                                Description=d['description']
                                ######utils.logdev(module,'Description= %s, type= %s' %( repr(Description),repr(type(Description))))
                                if isinstance(Description, dict):
                                    Description = Description['em']+'\n'+Description['#text']
                                elif not isinstance(Description, unicode):
                                    if not (Description == None or Description == ''):
                                        Description='Unknown description type: ' + repr(type(Description))
                                    else: 
                                        ######utils.logdev(module,'Description= %s, type= %s' %( repr(Description),repr(type(Description))))
                                        Description = 'Empty description'
                            except Exception, e:
                                pass
                                utils.logdev(module,'Error in get Description: ' + repr(e))
                                Description= 'Error in get Description: ' + repr(e) 
                            
                            addDir(d['title'].strip(),PlaylistURL,22,'','','',Description)
                        else:
                            utils.logdev(module,'No stream or playlist: ' + repr(d))
                            addDir('Error: '+repr(d),'url',22,'','','','No stream or playlist: ' + repr(d))  ### 2018-06-30
    except Exception, e:
        pass
        utils.logdev(module,'Error in showing Channels: ' + repr(e))
    utils.logdev(module,'Test Encoding 22')
    setView('movies', 'main-view')
    
def dictepgdata(date):
    try:
        ###utils.logdev(module,'dictepgdata(date)')
        for i, (key, value) in enumerate(data.iteritems()):
            #########utils.logdev('Test Encoding y1','i= %s, key= %s, value= %s' % (repr(i), repr(key),repr(value)))
            #########utils.logdev(module,'Test Encoding 13')
            for i1, (key1, value1) in enumerate(value.iteritems()):
                ######utils.logdev(module,'Test Encoding 14')
                if key1 == 'channel':
                    ######utils.logdev(module,'Test Encoding 15')
                    ######utils.logdev('Test Encoding y2','i1= %s, key1= %s, value1= %s' % (repr(i1), repr(key1),repr(value1)))
                    for channelROQ in value1:
                        ######utils.logdev(module,'Test Encoding 16')
                        d=channelROQ
                        
                        if 'stream_url' in d and not d['stream_url'] == None:
                            ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
                            ######utils.logdev(module,'Test Encoding 17')
                            StreamURL=d['stream_url'].replace('![CDATA[','',1).replace(']]','',1)
                        
                            if not d['desc_image'] == None:
                                DescURL=d['desc_image'].replace('![CDATA[','',1).replace(']]','',1)
                            else:
                                DescURL = ''
                            try:
                                Description=d['description']
                                ######utils.logdev(module,'Description= %s, type= %s' %( repr(Description),repr(type(Description))))
                                if isinstance(Description, dict):
                                    Description = Description['em']+'\n'+Description['#text']
                                elif not isinstance(Description, unicode):
                                    if not (Description == None or Description == ''):
                                        Description='Unknown description type: ' + repr(type(Description))
                                    else: 
                                        ######utils.logdev(module,'Description= %s, type= %s' %( repr(Description),repr(type(Description))))
                                        Description = ''
                            except Exception, e:
                                pass
                                ###utils.logdev(module,'Error in get Description: ' + repr(e))
                                Description=''
                            ######utils.logdev(module,'Test Encoding 18')
                            utils.logdev(module,'Test Encoding 18 Title= %s, Stream= %s, DescURL= %s, Category_ID= %s, Description= %s' % (d['title'],StreamURL,DescURL,d['category_id'],Description))
                            catThis = recordings.catFromUrl(StreamURL)
                            ###utils.logdev(module,'catThis = recordings.catFromUrl(StreamURL)= %r ' % catThis)
                            ##recordings.addChannel(d['title'].strip(),StreamURL,DescURL,catThis, ADDONid,description=Description)
                            addDir(d['title'].strip(),StreamURL,200,DescURL,'','',Description)
                            ######utils.logdev('Test Encoding stream','\n\ntitle= %s,\n description= %s,\n category_id= %s,\n stream_url= %s\n' % (repr(d['title']), repr(d['description']),repr(d['category_id']),repr(d['stream_url'])))
                        elif 'playlist_url' in d and not d['playlist_url'] == None:
                            ######utils.logdev(module,'Test Encoding 19')
                            PlaylistURL=d['playlist_url'].replace('![CDATA[','',1).replace(']]','',1)
                            try:
                                Description=d['description']
                                ######utils.logdev(module,'Description= %s, type= %s' %( repr(Description),repr(type(Description))))
                                if isinstance(Description, dict):
                                    Description = Description['em']+'\n'+Description['#text']
                                elif not isinstance(Description, unicode):
                                    if not (Description == None or Description == ''):
                                        Description='Unknown description type: ' + repr(type(Description))
                                    else: 
                                        ######utils.logdev(module,'Description= %s, type= %s' %( repr(Description),repr(type(Description))))
                                        Description = 'No description'
                            except Exception, e:
                                pass
                                utils.logdev(module,'Error in get Description: ' + repr(e))
                                Description='Error in get Description: ' + repr(e) ###''  2018-06-30
                            ######utils.logdev('Test Encoding playlist','\n\ntitle= %s,\n description= %s,\n category_id= %s,\n playlist_url= %s\n' % (repr(d['title']), repr(d['description']),repr(d['category_id']),repr(d['playlist_url'])))
                            ######utils.logdev(module,'Test Encoding 20')
                            ###def addChannel(name,url,iconimage,cat,origin,visible=True,weight=0,description='')
                            ##recordings.addChannel(d['title'].strip(),PlaylistURL,'','', ADDONid,description=Description)
                            addDir(d['title'].strip(),PlaylistURL,22,'','','',Description)
                        else:
                            ######utils.logdev(module,'Test Encoding 21')
                            utils.notification('No stream or playlist: ' + repr(d))
                            addDir('Error: '+repr(d),'url',22,'','','','No stream or playlist: ' + repr(d))  ### 2018-06-30
    except Exception, e:
        pass
        utils.logdev(module,'Error in showing Channels: ' + repr(e))
 
def CHANNELS(cname,cat):
    ###utils.logdev(module,'roq-tv CHANNELS(cname= %s, cat= %s)' % (repr(cname),repr(cat)))
    ###addDir('Favorites','url',17,'','','','All '+ADDONname +' favorites, you have selected on this box')
    #net.set_cookies(cookie_jar)
    #imageUrl=definition.getBASEURL() +'/res/content/tv/'
    #now= datetime.today().strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20')
        ## 3.4.6 now= datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20')
        #url='&mwAction=category&xbmc=1&mwData={"id":"%s","time":"%s","type":"tv"}'%(cat,now)
    #print 'default.py YYYY site+url= %s%s'  % (site,url)
    #link = net.http_GET(site+url, headers={'User-Agent' : UA}).content
    #print 'default.py YYYY Channels link= %s' % str(repr(link))
    #data = json.loads(link)
    GoHome('Categories')
    channeldescription = 'All '+ADDONname +' categories based on information in channel list. A channel may be member of several categoties.'
    i = 0
    categories= []
    channels= []
    utils.logdev(module,'CHANNELS(cname= %r, cat= %r) ' %(cname,cat))
    ###ChannelFile = os.path.join(datapath,ADDONid) + '.m3u.txt'
    ChannelFile = os.path.join(datapath,'directchannels') + '.m3u.txt'
    utils.logdev(module,'Use extra ChannelFile in data?: ' + repr(ChannelFile))
    if not os.path.isfile(ChannelFile):    ### If ChannelFile exist in Data directory use it
        ###ChannelFile = os.path.join(progpath,ADDONid) + '.m3u.txt'  ### Otherwise try program directory
        ChannelFile = os.path.join(progpath,'directchannels') + '.m3u.txt'  ### Otherwise try program directory
        utils.logdev(module,'Use extra ChannelFile in prog?: ' + repr(ChannelFile))
    utils.logdev(module,'Use extra ChannelFile in: ' + repr(ChannelFile))
    if not os.path.isfile(ChannelFile): 
        utils.logdev(module,'NOT found xtra ChannelFile in: ' + repr(ChannelFile))
    else:
        utils.logdev(module,'Use extra ChannelFile in: ' + repr(ChannelFile))
        for line in open(ChannelFile):  # opened in text-mode; all EOLs are converted to '\n'
            ######utils.logdev(module,'Line: ' + repr(i) + ' - ' + line)
            line = line.rstrip('\n').rstrip('\r').strip()
            if not line == '' and not line[:2] == '# ' :   # Ignore empty lines and comment lines
                if '#EXTM3U' in line :
                    i += 1
                    ######utils.logdev(module,'Skip EXTM3U in line: ' + repr(i))
                elif '#EXTINF' in line :
                    i += 1
                    ######utils.logdev(module,'Use EXTINF in line: ' + repr(i) + ' - ' + line)
                    ###if ',' in line:
                    ### utils.logdev(module,'Comma(,) in line: ' + repr(i) + ' - ' + line)
                    tvgid=''
                    tvgname=''
                    tvgnamecat = ''
                    tvglogo=''
                    grouptitl=''
                    name=''
                    try:
                        tvgid=line.split('tvg-id="',1)[1].split('"',1)[0]
                        ######utils.logdev(module,'Use tvg-id in line: ' + repr(tvgid) + ' - ' + line)
                    except:
                        pass
                    try:
                        tvgname=line.split('tvg-name="',1)[1].split('"',1)[0]
                        ######utils.logdev(module,'Use tvg-name in line: ' + repr(tvgname) + ' - ' + line)
                    except:
                        pass
                    try:
                        tvglogo=line.split('tvg-logo="',1)[1].split('"',1)[0]
                        ######utils.logdev(module,'Use tvg-logo in line: ' + repr(tvglogo) + ' - ' + line)
                    except:
                        pass
                    try:
                        grouptitle=line.split('group-title="',1)[1].split('"',1)[0]
                        ######utils.logdev(module,'Use group-title in line: ' + repr(grouptitle) + ' - ' + line)
                    except:
                        pass
                    try:
                        name=line.split(',')[-1]
                        ######utils.logdev(module,'Use name in line: ' + repr(name) + ' - ' + line)
                        grouptitle=grouptitle.split('SEASON')[0].strip()
                    except:
                        pass
                    try:
                        if ':' in tvgname:
                            tvgnamecat=tvgname.split(':')[0].strip()
                    except:
                        pass
                else:
                    i += 1
                    try:
                        cats=line.split('live/')[1].split('/')[0]
                    except:
                        pass
                        try:
                            cats=line.split('tv2danmark/')[1].split('/')[0]
                        except:
                            pass
                            try:
                                cats=line.split('i/')[1].split('/')[0]
                            except:
                                pass
                                cats=line.split('.')[-2].split('/')[-1]
                    if 'live' in line:
                        catsinlink='! live'
                    elif 'movie' in line:
                        catsinlink='! movie'
                    elif 'series' in line:
                        catsinlink='! series'
                    else:
                        catsinlink='! unknown'
                    
                    if '_' in cats:
                        if not 'bbc_' in cats:   ### 2017-08-28
                            if not 'cbeebies_' in cats:
                                utils.logdev(module,'cats no_= %r' % cats)
                                cats = cats.split('_')[0]
                                utils.logdev(module,'cats no_= %r' % cats)
                    
                    ######utils.logdev(module,'Use cname= ' + repr(cname) + ' - grouptitle= ' + repr(grouptitle))
                    if cname == grouptitle or cname == tvgnamecat or cname == catsinlink or cname == 'Channels':
                        channels.append([name.strip()+' (D)',line,grouptitle,tvglogo,tvgname,tvgid,cats,catsinlink])
                    elif  cname == 'Categories':
                        if not grouptitle in categories and grouptitle != None :
                            categories.append(grouptitle)
                        if not tvgnamecat == '' and not tvgnamecat in categories and tvgnamecat != None:
                            categories.append(tvgnamecat)
                        if not catsinlink == '' and not catsinlink in categories and catsinlink != None :
                            categories.append(catsinlink)
                    ######utils.logdev(module,'Use URL in line: ' + repr(repr(i)) + ' - ' + line)
                    ###addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
                    ###addDir(name,line,200,tvglogo,cat,'','cat= ' + cat + '\n\rtvg-id= ' + tvgid + '\n\rtvg-name= '+tvgname + '\n\rgroup-title= ' + grouptitle,'','',tvgname)
    ChannelFile = os.path.join(datapath,ADDONid) + '.m3u'
    utils.logdev(module,'Use ChannelFile ?: ' + repr(ChannelFile))
    if os.path.isfile(ChannelFile):
        utils.logdev(module,'Use ChannelFile: ' + repr(ChannelFile))
        for line in open(ChannelFile):  # opened in text-mode; all EOLs are converted to '\n'
            ####utils.logdev(module,'Line: ' + repr(i) + ' - ' + line)
            line = line.rstrip('\n').rstrip('\r')
            if not line == '' and not line[:2] == '# ' :   # Ignore empty lines and comment lines
                if '#EXTM3U' in line :
                    i += 1
                    ####utils.logdev(module,'Skip EXTM3U in line: ' + repr(i))
                elif '#EXTINF' in line :
                    i += 1
                    ###if ',' in line:
                    ### utils.logdev(module,'Comma(,) in line: ' + repr(i) + ' - ' + line)
                    tvgid=''
                    tvgname=''
                    tvgnamecat = ''
                    tvglogo=''
                    grouptitl=''
                    name=''
                    ####utils.logdev(module,'Use EXTINF in line: ' + repr(i) + ' - ' + line)
                    try:
                        tvgid=line.split('tvg-id="',1)[1].split('"',1)[0]
                    except:
                        pass
                        tvgid=''
                    ####utils.logdev(module,'Use tvg-id in line: ' + repr(tvgid) + ' - ' + line)
                    try:
                        tvgname=line.split('tvg-name="',1)[1].split('"',1)[0]
                    except:
                        pass
                        tvgname=''
                    ####utils.logdev(module,'Use tvg-name in line: ' + repr(tvgname) + ' - ' + line)
                    try:
                        tvglogo=line.split('tvg-logo="',1)[1].split('"',1)[0]
                    except:
                        pass 
                        tvglogo=''
                    ####utils.logdev(module,'Use tvg-logo in line: ' + repr(tvglogo) + ' - ' + line)
                    try:
                        grouptitle=line.split('group-title="',1)[1].split('"',1)[0]
                    except:
                        pass
                        grouptitle=''
                    ####utils.logdev(module,'Use group-title in line: ' + repr(grouptitle) + ' - ' + line)
                    try:
                        name=line.split(',')[-1]
                    except:
                        pass
                        name=''
                    ####utils.logdev(module,'Use name in line: ' + repr(name) + ' - ' + line)
                    try:
                        grouptitle=grouptitle.split('SEASON')[0].strip()
                    except:
                        pass
                    tvgnamecat = ''
                    if ':' in tvgname:
                        tvgnamecat=tvgname.split(':')[0].strip()
                else:
                    i += 1
                    cats=line.split('.')[-2].split('/')[-1]
                    catsinlink='! ' + line.split('/')[3]
                    
                    if ADDON.getSetting('user') in catsinlink :
                        catsinlink = '! live'
                    if  catsinlink == '! rt':
                        catsinlink = ''
                    ######utils.logdev(module,'Use cname= ' + repr(cname) + ' - grouptitle= ' + repr(grouptitle))
                    if cname == grouptitle or cname == tvgnamecat or cname == catsinlink or cname == 'Channels':
                        channels.append([name.strip(),line,grouptitle,tvglogo,tvgname,tvgid,cats,catsinlink])
                    elif  cname == 'Categories':
                        if not grouptitle in categories:
                            categories.append(grouptitle)
                        if not tvgnamecat == '' and not tvgnamecat in categories:
                            categories.append(tvgnamecat)
                        if not catsinlink == '' and not catsinlink in categories:
                            categories.append(catsinlink)
                    ######utils.logdev(module,'Use URL in line: ' + repr(repr(i)) + ' - ' + line)
                    ###addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
                    ###addDir(name,line,200,tvglogo,cat,'','cat= ' + cat + '\n\rtvg-id= ' + tvgid + '\n\rtvg-name= '+tvgname + '\n\rgroup-title= ' + grouptitle,'','',tvgname)
    channels = sorted(channels)
    ######utils.logdev(module,'Use channels: ' + repr(channels))
    categories = sorted(categories)
    ######utils.logdev(module,'Use categories: ' + repr(categories))
    for cat in categories:
        ######utils.logdev(module,'Use categories: ' + repr(cat))
        if cat != '':
            addDir(cat,'url',2,'','','',channeldescription)
    ###cEPG = recordings.getConnection()
    ###recordings.createEPGchannelsTable(cEPG)
    ###c = cEPG.cursor()
    for cat in channels:
        ######utils.logdev(module,'Use channels: ' + repr(cat))
        if cat[0] != '':
            ###if RecordActive :  ###
            ### addChannel(name,url,iconimage,cat,source)
            ###recordings.addChannel(cat[0],cat[1],cat[3],cat[6], ADDONid)
            description = ''
            if cat[6] != '':
                description += ' \n\rcat= ' + cat[6]
            if cat[5] != '':
                description += ' \n\rtvg-id= ' + cat[5]
            if cat[4] != '':
                description += ' \n\rtvg-name= '+cat[4]
            if cat[2] != '':
                description += ' \n\rgroup-title= ' + cat[2]
            if cat[7] != '':
                description += ' \n\rcatsinlink= '+cat[7]
            if cat[1] != '' and ADDON.getSetting('ShowLink') == 'true':
                description += ' \n\rlink= '+cat[1].replace('/','/ ').replace('\\','\\ ')
            ## 2017-07-12 recordings.addChannel(cat[0],cat[1],cat[3],cat[6], ADDONid+ ' available_channels',description=description)   ### Add channel during build of menus --> move to updateepg.py ###
            olddescription = recordings.getChannelDescription(cat[6])
            if olddescription != '':
                description = olddescription
            ##else:
            ##  recordings.setChannelDescription(cat[6],description)
            ### Add Live EPG
            ###utils.logdev(module,'cat= <%r>2 \nurl= %r' % (cat[6],cat[1]))
            if 'movie' in cat[1] or 'series' in cat[1]:  ### URL
                chx = description  ### Description of Movies
                ###utils.logdev(module,'MOVIE cat= <%r>3 \nurl= %r' % (cat[6],cat[1]))
            else:
                ###utils.logdev(module,'LIVE cat= <%r>4 \nurl= %r' % (cat[6],cat[1]))
                try:
                    EPGx = updateepg.getEPGnow(cat[6])  ### Live EPG on channels
                    EPG  = EPGx[0]
                    ###utils.logdev(module,'EPGx[0]= %r, EPGx[4]= %r' % (EPGx[0],EPGx[4]))
                    if EPGx[4] == '':
                        chx = description
                        ###utils.logdev(module,'LIVE no EPG cat= <%r>4 \nurl= %r' % (cat[6],cat[1]))
                    else:
                        chx = EPGx[4]
                        if EPGx[3] > 0:
                            chx += ' \nArchive Duration ' + str(EPGx[3]) + '\n'   ### 2018-06-11
                        for indexX in range(0, len(EPG)):
                            title = str(EPG[indexX][0])
                            description = str(EPG[indexX][1])
                            ###starttime = str(EPG[indexX][3].strftime('%H:%M'))
                            ###endtime = str(EPG[indexX][4].strftime('%H:%M'))
                            starttime = str(datetime.fromtimestamp(EPG[indexX][3]).strftime('%H:%M'))
                            endtime = str(datetime.fromtimestamp(EPG[indexX][4]).strftime('%H:%M'))
                            chx += ' \n[COLOR lightgreen]'+starttime + ' - ' + endtime + '[/COLOR] \n[COLOR blue]'+ title+ '[/COLOR] \n'+ description +' \n'
                except Exception, e:
                    pass
                    utils.logdev(module,'Error in getting EPG \n' + repr(e))
                    chx = 'No EPG!'
            ###addDir(cat[0],cat[1],200,cat[3],cat[6],'',chx,'','',cat[4])
            addDir(cat[0],cat[1],200,cat[3],cat[6],'',chx)
            
            ###ChannelFav = recordings.getChannelFav(c,cat[0])
            ###recordings.addEPGChannel(c,cat[0],name,url,stream_icon,epg_channel_id,EPGgenerator)
            ###recordings.setChannelCatchup(c,cat[0],'False')
            ###recordings.setChannelFav(c,cat[0],ChannelFav)
            
            ###addDir(cat[0],cat[1],200,cat[3],cat[6],'','cat= ' + cat[6] + '\n\rtvg-id= ' + cat[5] + '\n\rtvg-name= '+cat[4] + '\n\rgroup-title= ' + cat[2] + ' \n\rcatsinlink= '+cat[7]+ ' \n\rlink= '+cat[1].replace('/','/ '),'','',cat[4])
            ###addDir(cat[0]+'*',cat[1].replace('.ts','.txt').replace('.mp4','.txt'),200,cat[3],cat[6],'',cat[1].replace('.ts','.txt').replace('.mp4','.txt'),'','',cat[4])
    ###link = 'http://roq-tv.net:25461/enigma2.php?username=XXX&password=XXXX&type=get_vod_categories'
    """
    2017-05-17 18:49:21 Test Encoding z: 
    OrderedDict(
    [(u'items', OrderedDict([(u'playlist_name', u'Example'), 
    (u'category', OrderedDict([(u'category_id', u'1'), (u'category_title', u'Example')])), 
    (u'channel', 
    [OrderedDict([(u'title', u'Live Streams'), (u'description', u'Live Streams Category'), (u'category_id', u'0'), (u'playlist_url', u'http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass') + '&type=get_live_categories')]), 
    OrderedDict([(u'title', u'Vod'), (u'description', u'Video On Demand Category'), (u'category_id', u'1'), (u'playlist_url', u'http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass') + '&type=get_vod_categories')])])]))])
    
How to iterate from end to beginning over an OrderedDict ?
Either:

z = OrderedDict( ... )
for item in z.items()[::-1]:
   # operate on item
Or:

z = OrderedDict( ... )
for item in reversed(z.items()):
   # operate on item

dict = OrderedDict()
# ...

for i, (key, value) in enumerate(dict.iteritems()):
    # Do what you want here

    
    """
    ###link = definition.getBASEURL() + '/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')
    ROQTVusername = ADDON.getSetting('user')
    if ROQTVusername.lower() != 'none':
        try:
            link = definition.getBASEURL() + '/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')
            file = urllib2.urlopen(link)
            data = file.read()
            file.close()
            for titem in ['title','description']:
                ###utils.logdev('Test Encoding','titem= ' + repr(titem) + ' - data= ' + repr(data))
                data = data.split('<'+titem+'>')
                ###utils.logdev('Test Encoding 1',repr(data))
                i=0
                newdata= ''
                for part in data:
                    ###utils.logdev('Test Encoding 2',repr(part))
                    if i==0:
                        newdata+=part
                        ###utils.logdev('Test Encoding 3',repr(newdata))
                        i+=1
                    else:
                        part=part.split('</'+titem+'>',1)
                        ###utils.logdev('Test Encoding 4',repr(part))
                        ### newdata+='<'+titem+'>' + base64.b64decode(part[0]) +'</'+titem+'>' + part[1]
                        newdata+='<'+titem+'>' + base64.b64decode(part[0], '-_') +'</'+titem+'>' + part[1]
                        ###utils.logdev('Test Encoding 5',repr(newdata))
                ###utils.logdev('Test Encoding 6',repr(newdata))
                data = newdata
            
            ### Save file with all newdata!
            ChannelFile = os.path.join(datapath,ADDONid) + '.newdata'
            with open(ChannelFile,'wb') as output:
                output.write(newdata)
                
            utils.logdev(module,'roq-tv m3u file downloaded: ' + repr(ChannelFile))
            data = xmltodict.parse(newdata)
            ###utils.logdev('Test Encoding x',repr(data))
            
            ChannelFile = os.path.join(datapath,ADDONid) + '.data'
            with open(ChannelFile,'wb') as output:
                output.write('Data= %r' % data)
                
            for i, (key, value) in enumerate(data.iteritems()):
                ###utils.logdev('Test Encoding y1','i= %s, key= %s, value= %s' % (repr(i), repr(key),repr(value)))
                for i1, (key1, value1) in enumerate(value.iteritems()):
                    if key1 == 'channel':
                        ###utils.logdev('Test Encoding y2','i1= %s, key1= %s, value1= %s' % (repr(i1), repr(key1),repr(value1)))
                        for channelROQ in value1:
                            d=channelROQ
                            ###utils.logdev('Test Encoding y3','i1= %s, key1= %s, channelROQ= %s, url= %s' % (repr(d.items()[0]), repr(d.items()[1]),repr(d.items()[2]),repr(d.items()[3])))
                            ###utils.logdev('Test Encoding y4','\n\ntitle= %s,\n description= %s,\n category_id= %s,\n playlist_url= %s\n' % (repr(d['title']), repr(d['description']),repr(d['category_id']),repr(d['playlist_url'])))

            ###z = OrderedDict( ... )
            ###for item in data.items()[::-1]:
                # operate on item
            ### ###utils.logdev('Test Encoding y',repr(item))
                
            """
            Test Encoding 1: OrderedDict(
            [(u'items', OrderedDict(
                [(u'playlist_name', u'Movie [ Example ]'), (u'category', OrderedDict([(u'category_id', u'1'), (u'category_title', u'Movie [ Example ]')])), 
                (u'channel', 
                    [OrderedDict([(u'title', u'QWxs'), (u'description', u'TW92aWUgU3RyZWFtcyBDYXRlZ29yeSBbIEFMTCBd'), (u'category_id', u'0'), (u'playlist_url', u'http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass') + '&type=get_vod_streams&cat_id=0')]), 
                    OrderedDict([(u'title', u'Rk9SIEFEVUxUUw=='), (u'description', u'TW92aWUgU3RyZWFtcyBDYXRlZ29yeQ=='), (u'category_id', u'110'), (u'playlist_url', u'http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass') + '&type=get_vod_streams&cat_id=110')]), 
                    OrderedDict([(u'title', u'TkVXIE1PVklFUw=='), (u'description', u'TW92aWUgU3RyZWFtcyBDYXRlZ29yeQ=='), (u'category_id', u'111'), (u'playlist_url', u'http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')+'&type=get_vod_streams&cat_id=111')]), 
                    OrderedDict([(u'title', u'S0lEUyBNT1ZJRVM='), (u'description', u'TW92aWUgU3RyZWFtcyBDYXRlZ29yeQ=='), (u'category_id', u'112'), (u'playlist_url', u'http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass') + '&type=get_vod_streams&cat_id=112')]), 
                    OrderedDict([(u'title', u'Qk9YU0VUUw=='), (u'description', u'TW92aWUgU3RyZWFtcyBDYXRlZ29yeQ=='), (u'category_id', u'113'), (u'playlist_url', u'http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')+ '&type=get_vod_scategories&scat_id=113')]), 
                    OrderedDict([(u'title', u'VFZTRVJJRVM='), (u'description', u'TW92aWUgU3RyZWFtcyBDYXRlZ29yeQ=='), (u'category_id', u'77'), (u'playlist_url', u'http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')+'&type=get_vod_streams&cat_id=77')]), 
                    OrderedDict([(u'title', u'TU9WSUVT'), (u'description', u'TW92aWUgU3RyZWFtcyBDYXRlZ29yeQ=='), (u'category_id', u'60'), (u'playlist_url', u'http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')+'&type=get_vod_streams&cat_id=60')])])]))])
            http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')+'&type=get_catchup_categories
            http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')+'&type=get_catchup_streams&cat_id=14
            http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')+'&type=get_vod_categories
            http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')+'&type=get_vod_streams&cat_id=110
            import base64
            aircode = base64.b64decode('RElSRUNUT1I6IApQTE9UOiAKQ0FTVDogClJBVElORzogClJFTEVBU0VEQVRFOiAKR0VOUkU6IApJTURCX0lEOiAKRFVSQVRJT05fU0VDUzogMjIxNQpEVVJBVElPTjogMDA6MzY6NTUKVklERU86IEFycmF5CkFVRElPOiBBcnJheQpCSVRSQVRFOiA3NzQK')
            ###utils.logdev('Test Encoding',aircode)
            """
        except Exception, e:
            pass
            utils.logdev(module,'/enigma2.php? ERROR %r' % e)
    setView('movies', 'main-view')     
            
def MyChannels():
    cat='-2'
    net.set_cookies(cookie_jar)
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20')
    url='&mwAction=category&xbmc=1&mwData={"id":"%s","time":"%s","type":"tv"}'%(cat,now)
    link = net.http_GET(site+url, headers={'User-Agent' : UA}).content
    data = json.loads(link)
    channels=data['contents']
    from operator import itemgetter
    #Sort channels by name or id/cat
    if ADDON.getSetting('SortAlphabetically')=='true':
        channels = sorted(channels, key=itemgetter('id'))
    else:
        channels = sorted(channels, key=itemgetter('name'))
    AllMyChannels=[]
    
    for field in channels:
        name         =  field['name'].encode("utf-8")
        channel      =  field['id']
        displaychannelnumber = (name + ' (' +channel+'):\n' )
        AllMyChannels.append(displaychannelnumber)
    return AllMyChannels
        

def GENRE(name,cat):
    GoHome('GENRE')
    _GENRE_=name.lower()
    #now= datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20')
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20')
    ## 3.4.6 now= datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20')
    
    net.set_cookies(cookie_jar)
    url='&mwAction=category&xbmc=2&mwData={"id":"%s","time":"%s","type":"tv"}'%(cat,now)
    link = net.http_GET(site+url, headers={'User-Agent' : UA }).content
    data = json.loads(link)
    channels=data['contents']
    # Krogsbell 2014-09-18 3 lines
    from operator import itemgetter
    #Sort channels by name!
    if ADDON.getSetting('SortAlphabetically')=='true':
         channels = sorted(channels, key=itemgetter('name'))
    ###uniques=[] ###removed 2019-03-03 not used?
    
    offset= int(data['offset'])
    for field in channels:
        genre      =  field['genre']
        endTime      =  field['time_to']
        name         =  field['name'].encode("utf-8")
        channel      =  field['id']
        whatsup      =  field['whatsup'].encode("utf-8")
        displaychannelnumber = (name + ' (' +channel+'):\n' )
        description  =  (displaychannelnumber + field['descr']).encode("utf-8")
        #description  =  field['descr'].encode("utf-8")
        r=re.compile("(.+?)-(.+?)-(.+?) (.+?):(.+?):(.+?)")
        matchend     =  r.search(endTime)
        endyear      =  matchend.group(1)
        endmonth     =  matchend.group(2)
        endday       =  matchend.group(3)
        endhour      =  matchend.group(4)
        endminute    =  matchend.group(5)

        endDate  =  datetime(int(endyear),int(endmonth),int(endday),int(endhour),int(endminute)) + timedelta(seconds = offset)

        
        if ADDON.getSetting('tvguide')=='true':
            if not endDate  == '' and recordings.getRecordingsActiveAll(endDate,endDate): #################################################################
                name='%s - [COLOR red]%s[/COLOR]'%(name,whatsup)
            else:
                name='%s - [COLOR yellow]%s[/COLOR]'%(name,whatsup)
        if genre.lower() == _GENRE_:
            #newiconurl= recordings.imageUrlicon(imageUrl,channel,'.png')
            newiconurl= recordings.getIcon(name,channel)
            addDir(name,'url',200,newiconurl,channel,'',description,now,endDate,whatsup)
    setView('movies', 'channels-view')         
            
def MYACCOUNT():
    GoHome('My Account')
    username    =ADDON.getSetting('user')
    ###xbmcaddon.Addon(id=ADDONid).openSettings()
    addDir('Restart with New User','url',10,'','','','Resets the user, sets the time and resets the database')
    addDir('IPTV Home: [B]%s[/B]' % definition.getREGISTRATION(),definition.getREGISTRATION(),1043,'','','','Home page for your IPTV Supplier\nClick to open page in browser')
    addDir('Basic URL: [B]%s[/B]' % definition.getBASEURL(),'url',0,'','','','Basic URL for your IPTV')
    addDir('User: [B]%s[/B]' % username,'url',14,'','','','Change your username and password. Then all channels will be removed and the EPG starts to update. You will loose favorites, recursive and hidden channels')
    addDir('Past settings.xml','url',15,'','','','Change setting to a previous state and may be user')
    ROQTVusername = ADDON.getSetting('user')
    ###if ROQTVusername.lower() != 'none':
    ###    addDir('Status','url',11,'','','','Watch the basic status of your account')
        
    if ROQTVusername.lower() != 'none':
        try:
            link = definition.getBASEURL() + '/panel_api.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')
            file = urllib2.urlopen(link)
            data = file.read()
            file.close()
            
            ChannelFile = os.path.join(datapath,ADDONid) + '.info'
            with open(ChannelFile,'wb') as output:
                output.write(data)
            ###name= Status,url= url,mode= 11,iconimage= ,cat= ,date= ,description= {u'username': u'XXX', u'status': u'Active', u'is_trial': u'0', u'created_at': u'1493734688', u'auth': 1, u'allowed_output_formats': [u'm3u8', u'ts', u'rtmp'], u'exp_date': u'1499005088', u'active_cons': u'0', u'password': u'XXXX', u'max_connections': u'1'},startDate= ,endDate= ,recordname= )
            d = json.loads(data)
            d1 = d['user_info']
            formats = d1['allowed_output_formats']
            allowedformats = AllowedFormats(formats)
            """
            allowedformats = '['
            for f in formats:
                allowedformats += f + ', '
            allowedformats += ']'
            allowedformats = allowedformats.replace(', ]',']')
            """
            if d1['is_trial'] == '1':
                is_trial = '\nThis is a trial '
            else:
                is_trial = ''
            now = datetime.now()
            remainingdays = (recordings.parseDate(d1['exp_date'])-recordings.parseDate(now)).days
            if remainingdays < 7:
                remainingdaysS = '[B][COLOR red]\nRemaining days= '+ str(remainingdays)  + '[/COLOR][/B]'
            else:
                remainingdaysS = '[B][COLOR green]\nRemaining days= '+ str(remainingdays)  + '[/COLOR][/B]'
            descr = 'Username= %s \nStatus= %s \nExpire= %s%s%s\nMax connections= %s \nConnections in use= %s \nAllowed formats= %s' %(d1['username'],d1['status'],recordings.parseDate(d1['exp_date']).strftime('%Y-%m-%d %H:%M'),remainingdaysS,is_trial,d1['max_connections'],d1['active_cons'],allowedformats)
        
            addDir('Basic Info','url',12,'','','',descr)
        except Exception, e:
            pass
            utils.notification('Error in getting '+ ADDONid + ' info! Check your User ID\n' + repr(e))
            addDir('Basic Info','url',0,'1','','','Error in getting '+ ADDONid + ' info! Check your User ID\n' + repr(e))
            d = []
        
    #addDir('My Subscriptions','url',9,'','','','')
    #addDir('Past Orders','url',10,'','','','')
    setView('movies', 'main-view')

def Streams():
    GoHome('Streams')
    ROQTVusername = ADDON.getSetting('user')
    if ROQTVusername.lower() != 'none':
        addDir('[COLOR lightgreen]Archive/Catch up[/COLOR]','url',18,'','','','All '+ADDONname +' channels, that have archive/catch up. \n\nGo to TV Guide for the channel to watch or record catch up or comming events')
    xmltvfile = ADDON.getSetting('directchannelsfromextraXMLTVfile').replace('/','/ ').replace('\\','\\ ')
    if xmltvfile != '':
        xmltvfile = '\n\nYour Direct Channels are defined in:\n' + xmltvfile
    addDir('[COLOR lightgreen]Direct Channels[/COLOR]','url',19,'','','','All direct channels from extra XMLTV file. Channels you can watch if you just are in the right country'+xmltvfile)
    
    KrogsbellAddOns = definition.getKrogsbellAddOns()
    utils.logdev(module,'KrogsbellAddOns= %r' % KrogsbellAddOns)
    for kaddon in KrogsbellAddOns:
        utils.logdev(module,'kaddon= %r' % kaddon)
        try:
            kaddonID = kaddon.split('.')[2][:3].upper()
            taddonID = ADDONid.split('.')[2][:3].upper()
        except Exception, e:
            pass
            EpgError = 'Error in getting AddOn ID\n' + repr(e) 
            kaddonID = ''
            taddonID = ''
        utils.logdev(module,'kaddonID= %r' % kaddonID)
        utils.logdev(module,'taddonID= %r' % taddonID)
        if kaddonID != '' and kaddonID != taddonID:
            try:
                nADDON = xbmcaddon.Addon(id=kaddon)
                naddon = nADDON.getAddonInfo('name')
                NTVchannels = xbmc.translatePath(nADDON.getAddonInfo('profile') + 'channels.csv')
                if os.path.isfile(NTVchannels):
                    addDir('[COLOR lightgreen]'+naddon+' Channels ('+kaddonID+')[/COLOR]','url',190,'','','','All channels from '+naddon+' addon ('+kaddonID+')[CR][CR]Show in blocks of ' + ADDON.getSetting('searchcountmax'))
            except Exception,e:
                pass
                utils.logdev(module,'NTVchannels '+kaddon+' Error= %r' % e)
    """
    try:
        NTVchannels = xbmc.translatePath( xbmcaddon.Addon(id='plugin.video.tvawayrec').getAddonInfo('profile') + 'channels.csv')
        if os.path.isfile(NTVchannels):
            addDir('[COLOR lightgreen]TVaway Channels[/COLOR]','url',191,'','','','All channels from TVaway Rec addon[CR][CR]Show in blocks of ' + ADDON.getSetting('searchcountmax'))
    except Exception,e:
        pass
        utils.logdev(module,'NTVchannels TVaway Error= %r' % e)
    """
    ROQTVusername = ADDON.getSetting('user')
    if ROQTVusername.lower() != 'none':
        addDir('[COLOR lightgreen]New Channels, VOD and TV Series[/COLOR]','url',21,'','','','Newest '+ADDONname +' Channels, VOD and TV Series sorted by creation date. \n\nShowing New Channels, VOD and TV Series the last 2 months[CR][CR]Show in blocks of ' + ADDON.getSetting('searchcountmax'))
    if ADDON.getSetting('enable_record')=='true':
        addDir('[COLOR lightgreen]Recursive Search Channels[/COLOR]','url',26,'','','','All channels used for recursive search')
    try:
        ROQTVusername = ADDON.getSetting('user')
        if ROQTVusername.lower() != 'none':
            link = definition.getBASEURL() + '/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')
            utils.logdev(module,'CATEGORIES 0 link= %r' % link)
            file = urllib2.urlopen(link)
            data = file.read()
            file.close()
              
            ChannelFile = os.path.join(datapath,ADDONid) + '.enigma2'
            utils.makeOldFile(ChannelFile)
            with open(ChannelFile,'wb') as output:
                output.write(data)
            
            ###utils.logdev(module,'CATEGORIES 1 data= %r' % data)
            for titem in ['title','description']:
                ###utils.logdev('Test Encoding','titem= ' + repr(titem) + ' - data= ' + repr(data))

                data = data.split('<'+titem+'>')
                ###utils.logdev('Test Encoding 1',repr(data))
                i=0
                newdata= ''
                for part in data:
                    ###utils.logdev('Test Encoding 2',repr(part))
                    if i==0:
                        newdata+=part
                        ###utils.logdev('Test Encoding 3',repr(newdata))
                        i+=1
                    else:
                        part=part.split('</'+titem+'>',1)
                        ###utils.logdev('Test Encoding 4',repr(part))
                        ### newdata+='<'+titem+'>' + base64.b64decode(part[0]) +'</'+titem+'>' + part[1]
                        newdata+='<'+titem+'>' + base64.b64decode(part[0], '-_') +'</'+titem+'>' + part[1]
                        ###utils.logdev('Test Encoding 5',repr(newdata))
                ###utils.logdev(module,'CATEGORIES 2 data= %r' % data)
                data = newdata
            ChannelFile3 = os.path.join(datapath,ADDONid) + '.enigma3'
            utils.makeOldFile(ChannelFile3)
            with open(ChannelFile3,'wb') as output:
                output.write(data)
            data = xmltodict.parse(newdata)
            ###ChannelFile3 = os.path.join(datapath,ADDONid) + '.enigma4'
            ###utils.makeOldFile(ChannelFile3)
            ###with open(ChannelFile3,'wb') as output:
            ###    output.write(data)
            ###utils.logdev(module,'Test Encoding x(data)' + repr(data))
        
            for i, (key, value) in enumerate(data.iteritems()):
                ###utils.logdev('Test Encoding y1','i= %s, key= %s, value= %s' % (repr(i), repr(key),repr(value)))
                for i1, (key1, value1) in enumerate(value.iteritems()):
                    if key1 == 'channel':
                        ###utils.logdev('Test Encoding y2','i1= %s, key1= %s, value1= %s' % (repr(i1), repr(key1),repr(value1)))
                        for channelROQ in value1:
                            d=channelROQ
                            ###utils.logdev('Test Encoding y3','i1= %s, key1= %s, channelROQ= %s, url= %s' % (repr(d.items()[0]), repr(d.items()[1]),repr(d.items()[2]),repr(d.items()[3])))
                            ###utils.logdev('Test Encoding y4','\n\ntitle= %s,\n description= %s,\n category_id= %s,\n playlist_url= %s\n' % (repr(d['title']), repr(d['description']),repr(d['category_id']),repr(d['playlist_url'])))
                            addDir(d['title'],d['playlist_url'],22,d['category_id'],'','',ADDONname+' in original sorting and categorizing: \n' + d['description'])
                            ###addDir(d['title'],d['playlist_url'],22,d['category_id'],'','','description default line 366')
    except Exception, e:
        pass
        utils.notification('Error in get Categori from enigma2: ' + repr(e))
        utils.logdev(module,'Error in get Categori from enigma2: ' + repr(e))
    
    ROQTVusername = ADDON.getSetting('user')
    if ROQTVusername.lower() != 'none':
        addDir('Categories','url',2,'','','','All '+ADDONname +' categories based on information in channel list and all direct channels from extra XMLTV file. \n\nA channel may be member of several categoties. \n\nCategories are sorted alphabetically')
        addDir('Channels','url',23,'','','','All '+ADDONname +' channels and all direct channels from extra XMLTV file shown without categories. \n\nUse search to find your channel, VOD or TV series. \n\nChannels, Video on Demand and TV series are sorted alphabetically')
    else:
        addDir('Categories','url',2,'','','','All categories of all direct channels from extra XMLTV file. \n\nA channel may be member of several categoties. \n\nCategories are sorted alphabetically')
        addDir('Channels','url',23,'','','','All direct channels from extra XMLTV file shown without categories. \n\nUse search to find your channel. \n\nChannels are sorted alphabetically')
    setView('movies', 'main-view')

def getPlannedRecordingCounts():
    result =''
    try:
        c = recordings.getConnection().cursor()
        ###cutoffdate = (datetime.today() - timedelta(days = 1)).strftime('%Y-%m-%d')
        cutoffdate = CutOffDateTime()
        c.execute("SELECT * FROM recordings_adc WHERE start>? AND name NOT LIKE '%Recursive:%'", [cutoffdate])   ### 2018-09-11 use startdate against cutoff date
        recordingsC = c.fetchall()
        result =  'P' + str(len(recordingsC))
    except Exception, e:
        pass
        utils.logdev(module, 'c.execute(SELECT * FROM recordings_adc WHERE end>? AND name NOT LIKE Recursive:, [cutoffdate]) failed! \nERROR= %r' % e)
        result = repr(e)
    try:
        c = recordings.getConnection().cursor()
        c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE '%Recursive:%'")
        recordingsC = c.fetchall()
        result +=  '/R' + str(len(recordingsC))
    except Exception, e:
        pass
        utils.logdev(module, 'c.execute(SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE Recursive:) failed! \nERROR= %r' % e)
        result += repr(e)
    
    return result
      
        
def Maintenance():
    GoHome('Maintenance')
    addDir('Make a Clone of this Addon','url',2500,'1','1','1','Make a new addon as a clone of this one. \n\nYou set the name of the addon. The files of this addon is copied to this new addon and configuration files uptated. Then all the files are zipped to make a zipfile to install this new addon. You can personalise the addon, by changing .png and .jpg files in the addon')
    addDir('My Account','url',8,'','','','Change your user name/email address and password or restore previous configurations. \n\nWatch your basic account information')
    addDir('Backup Database and Settings','url',2059,'','','','Backup recordings_adc.db and settings.xml')
    addDir('Delete Database','url',116,'','','','Clear the Database. \nStop all planned recordings and start a new EPG import')
    addDir('Delete File Database','url',1029,'','','','Clear the File Database. \nStart a new scan')
    addDir('Restore from Database','url',104,'','','','Restore Database, Restore recursive recordings or EPG Data')
    addDir('Delete Old EPG programs','url',111,'','','','Delete 7 days old programs and 2 days old channels')
    addDir('Delete New EPG programs','url',110,'','','','Delete New EPG Programs. If to many programs have changed - update full afterwards')
    addDir('Delete All Channels','url',108,'','','','Delete All Channels. If user have changed - update full afterwards')
    if ADDON.getSetting('enable_record')=='true':
        addDir('Delete All Planned Recordings','url',109,'','','','Delete All Planned Programs. If recursive have made too many recordings - Stop all recordings and clear planned recording parts of database')
        addDir('Clear Record Marker','url',260,'','','','If status shows recording while no recording active - clear the flag')
    addDir('Update EPG now','url',115,'','','','Start to Update EPG now')
    ftvntvini = (os.path.join(datapath,'ftv'+ADDONname) + '.ini').replace('/','/ ').replace('\\','\\ ')
    addDir('Make new INI file','url',112,'','','','Create INI file \n' + ftvntvini +' \nfor use with external TV Guides')
    addDir('Force INI and Reschedule','url',4000,'','','','Create INI file \n' + ftvntvini +' \nfor use with external TV Guides, Test for overlapping  EPG programs, Update Planned recordings and Reschedule')
    addDir('Hidden Channels','url',20,'','','','All channels you have hidden from the other views - Here you can un-hide them')
    setView('movies', 'main-view')
      
def STATUS():
    GoHome('Status')
    ROQTVusername = ADDON.getSetting('user')
    if ROQTVusername.lower() != 'none':
        try:
            link = definition.getBASEURL() + '/panel_api.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')
            file = urllib2.urlopen(link)
            data = file.read()
            file.close()
            
            ChannelFile = os.path.join(datapath,ADDONid) + '.info'
            with open(ChannelFile,'wb') as output:
                output.write(data)
            ###name= Status,url= url,mode= 11,iconimage= ,cat= ,date= ,description= {u'username': u'XXX', u'status': u'Active', u'is_trial': u'0', u'created_at': u'1493734688', u'auth': 1, u'allowed_output_formats': [u'm3u8', u'ts', u'rtmp'], u'exp_date': u'1499005088', u'active_cons': u'0', u'password': u'XXXX', u'max_connections': u'1'},startDate= ,endDate= ,recordname= )
            d = json.loads(data)
            d1 = d['user_info']
            formats = d1['allowed_output_formats']
            allowedformats = AllowedFormats(formats)
            """
            allowedformats = '['
            for f in formats:
                allowedformats += f + ', '
            allowedformats += ']'
            allowedformats = allowedformats.replace(', ]',']')
            """
            if d1['is_trial'] == '1':
                is_trial = '\nThis is a trial '
            else:
                is_trial = ''
            now = datetime.now()
            remainingdays = (recordings.parseDate(d1['exp_date'])-recordings.parseDate(now)).days
            if remainingdays < 7:
                remainingdaysS = '[B][COLOR red]\nRemaining days= '+ str(remainingdays)  + '[/COLOR][/B]'
            else:
                remainingdaysS = '[B][COLOR green]\nRemaining days= '+ str(remainingdays)  + '[/COLOR][/B]'
            descr = 'Username= %s \nStatus= %s \nExpire= %s%s%s\nMax connections= %s \nConnections in use= %s \nAllowed formats= %s' %(d1['username'],d1['status'],recordings.parseDate(d1['exp_date']).strftime('%Y-%m-%d %H:%M'),remainingdaysS,is_trial,d1['max_connections'],d1['active_cons'],allowedformats)
        
            addDir('Basic Info','url',12,'','','',descr)
        except Exception, e:
            pass
            utils.notification('Error in getting '+ ADDONid + ' info! Check your User ID\n' + repr(e))
            addDir('Basic Info','url',0,'1','','','Error in getting '+ ADDONid + ' info! Check your User ID\n' + repr(e))
            d = []
        ###<<<   AddAtom('all',d)
        ###addDir('Test Info','url',12,'','','',d['server_info']['port'])
        """
        for field in d:
            ###utils.logdev(module,'params= %s' % repr(field))
            ###utils.logdev(module,'type(field)= %s' % repr(type(field)))
            if type(d[field]) == dict:
                da = d[field]
                for f in d[field]:
                    if type(d[field][f]) == dict:
                    for f in d[field]:
                        addDir(field +'/' +f,'url',12,'','','',repr(d[field][f]))
            else:
                
                addDir(field,'url',12,'','','',d[field])
        """     
    setView('movies', 'main-view') 

def AddAtom(level,data):
    if not type(data) == str:
        for field in data:
            if type(data[field]) == dict:
                AddAtom(level +'/'+ repr(field),data[field])
            else:
                if not field == 'movie' and not field == 'live':
                    ###utils.logdev(module,'addDir(level/field= %r,data[field]= %r)' % (level +'/'+ field,data[field]))
                    addDirBasic(level +'/'+ field,'url',12,'','','',data[field])

def AllowedFormats(formats):
    allowedformats = '['
    for f in formats:
        allowedformats += f + ', '
    allowedformats += ']'
    return allowedformats.replace(', ]',']')
    
def STATUSsub(data):
    GoHome('Status')
    ###utils.logdev(module,'STATUSsub data= %s' % repr(data))
    ###d = json.loads(data)
    for field in data:
        if len(field) > 2:
            ###utils.logdev(module,'STATUSsub params= %s' % repr(field))
            ###utils.logdev(module,'type(field)= %s' % repr(type(field)))
            if type(field) == dict:
                addDir(repr(field),'url',12,'','','',repr(data))
            else:
                addDir(field,'url',0,'','','',repr(data))
    setView('movies', 'main-view') 

def SUBS():
    GoHome('SUBS')
    net.set_cookies(cookie_jar)
    link = net.http_GET(definition.getBASEURL() +'/?' + recordings.referral() + 'c=1&a=18', headers={'User-Agent' : UA}).content
    data = json.loads(link)
    body = data['body']
    for field in body:
        title= field['title']
        platform= field['platforms'].encode("utf-8")
        status= field['status'].encode("utf-8")
        time_left= field['time_left'].encode("utf-8")
        name='%s-%s-(%s)[COLOR yellow] %s[/COLOR] '%(title,platform,time_left,status)
        addDir_STOP(name,'url','','','','')
    setView('movies', 'main-view') 
    
def ORDERS():
    GoHome('ORDERS')
    net.set_cookies(cookie_jar)
    link = net.http_GET(definition.getBASEURL() +'/?' + recordings.referral() + 'c=1&a=19', headers={'User-Agent' : UA}).content.encode('ascii', 'ignore')
    data = json.loads(link)
    body = data['body']
    for field in body:
        id= field['id'].encode("utf-8")
        price_total= field['price_total'].encode("utf-8")
        created= field['created'].encode("utf-8")
        status= field['status'].encode("utf-8")
        updated= field['updated'].encode("utf-8")
        name='%s-(%s)[COLOR yellow] %s-(%s)[/COLOR] '%(price_total, created, status, updated)
        addDir_STOP(name,'url','','','','')
    setView('movies', 'main-view') 

def Search(name):
    search_entered = ''
    ###search_entered = ADDON.getSetting('searchepgvodcha')
    keyboard = xbmc.Keyboard(search_entered, '[COLOR lightgreen][B]Please Enter '+str(name)+'[/B][CR][COLOR grey][I]<ESC> or Cancel to clear. Not case sensitive search[/I][/COLOR]')
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_entered = keyboard.getText()
        if search_entered == None:
            return False 
        ###else:
        ###    ADDON.setSetting('searchepgvodcha',search_entered)   ### 2018-02-15
    else:
        ###ADDON.setSetting('searchepgvodcha','')
        return False
    return search_entered 
    """    
        keyboard = xbmc.Keyboard(search_entered, '[COLOR lightgreen][B]Please Enter '+str(name)+'[/B][CR][COLOR grey][I](<ESC> or Cancel to clear)[/I][/COLOR]')
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText()
            if search_entered == None:
                return False          
        return search_entered  
    """
    
def Numeric(name):
        dialog = xbmcgui.Dialog()
        keyboard=dialog.numeric(0, 'Please Enter '+str(name))
        return keyboard  

def ADD_FAV(cat):
    recordings.addChannelFav(cat)
    return
    
def DEL_FAV(cat):
    recordings.delChannelFav(cat)
    return

def SET_HIDE(cat):
    recordings.setChannelHide(cat)
    return
    
def DEL_HIDE(cat):
    recordings.delChannelHide(cat)
    return

def SET_RECURSIVE(cat):
    recordings.setChannelRecursive(cat)
    return
    
def DEL_RECURSIVE(cat):
    recordings.delChannelRecursive(cat)
    return

def SELECT_TV_GUIDE_CHANNEL(name,url,iconimage,cat):
    try:
        channel = updateepg.getEPGChannel(cat)
        name = channel[0]
        EPGchannel = channel[1]
        source = channel[2]
        #print Platform
        dialog = xbmcgui.Dialog()
        lockcause = 'change' ### Dummy command
        if type(EPGchannel) == str:
            if dialog.yesno(ADDON.getAddonInfo('name'), "[COLOR red]Change TV Guide Channel?[/COLOR]", name + ' (' + cat + ') --> ' + EPGchannel + ' ('  + source + ')', "What Do You Want To Do","[COLOR red]Change channel[/COLOR]","[COLOR green]Ignore[/COLOR]"):
                ### Ignore
                lockcause = 'ignore' ### Dummy command
            else:
                ### Stop recording and record new
                lockcause = 'change' ### Dummy command
        else:
            EPGchannel = ''
        #########################
        utils.logdev(module, 'SelectedChannel Channel= %r' % (name))
        if lockcause == 'change' :
            mychannels = ['No EPG'] + findtvguidenotifications.MyChannels()
            ###mychannels.append(findtvguidenotifications.MyChannels())
            SelectedChannel = xbmcgui.Dialog().select(name + ' (' + cat + ') --> ' + EPGchannel, mychannels)
            utils.logdev(module, 'SelectedChannelNo= %r' % (SelectedChannel))
            if SelectedChannel <> -1:
                try:
                    utils.logdev(module, 'try SelectedChannel= %r' % (mychannels[SelectedChannel]))
                    EPGchannel = mychannels[SelectedChannel].split('(')[-1].split(' - ')[0].strip()
                    updateepg.setEPGChannel(cat,EPGchannel)
                    utils.notification(name + ' (' + cat + ') --> ' + EPGchannel)
                except Exception, e:
                    pass
                    utils.logdev(module, 'SelectedChannel FAILED Channel= %r \nERROR= %r' % (SelectedChannel,e))
    except Exception, e:
        pass
        utils.logdev(module,'Error in SELECT_TV_GUIDE_CHANNEL\n' + repr(e))

def TVGUIDE(namech,cat):
    ### [recordings.getEPGPrograms(epg_channel_id), name-1, tv_archive-2, tv_archive_duration-3, epg_channel_id-4]
    GoHome('TV guide')
    now= datetime.today()
    guide = updateepg.getEPG(cat)
    try:
        guideEPG = guide[0]
    except Exception, e:
        pass
        utils.logdev(module,'Error in getting TV Guide\n' + repr(e))
        return
    nameEPG = guide[1]
    tv_archive = guide[2]
    if type(tv_archive) != int:
        tv_archive = 0
    tv_archive_duration= guide[3]
    if type(tv_archive_duration) != int:
        tv_archive_duration = 0
    ###tv_archive_duration += 14   ### Test Add 14 days 2018-06-09
    epg_channel_id = guide[4]
    if tv_archive == 1:
        ###addDir('[COLOR red][B]Search limit reached ('+str(searchcountmax)+' in '+usedtime+' seconds)[/B][/COLOR]' ,'url',5011,'','0','0','Limit your search!\n\nClick to change limit[CR][CR]Searched for: '+searchText+'[CR][CR]'+searchPath+sortmethod,'0','0','')
        archiveoffsetminutes = ADDON.getSetting('archiveoffsetminutes')
        if archiveoffsetminutes != '0':
            addDir('Days in archive %r\n[COLOR grey][I]Offset %r minutes[/I][/COLOR]' % (tv_archive_duration,archiveoffsetminutes),'url',5012,'1','0','0','Days in archive %r\n\nOffset %r minutes\n\nClick on line to modify offset\nUse a leading zero to set a negative offset\nRefresh to see and use the new offset' % (tv_archive_duration,archiveoffsetminutes),'0','0','0')
        else:
            addDir('Days in archive %r' % tv_archive_duration,'url',5012,'1','0','0','Days in archive %r\n\nOffset %r minutes\n\nClick on line to modify offset\nUse a leading zero to set a negative offset\nRefresh to see and use the new offset' % (tv_archive_duration,archiveoffsetminutes),'0','0','0')
    if namech == 'None' or namech == '':
        namech = nameEPG
        if namech == 'None' or namech == '':
            if cat != '#':
                namech = recordings.ChannelName(cat)
            else:
                namech = ''
    utils.logdev(module,'TVguide name= %r, tv_archive= %r, tv_archive_duration= %r, epg_channel_id= %r' % ( namech, tv_archive, tv_archive_duration, epg_channel_id))
    newiconurl = recordings.getIcon(namech,cat)
    for index in range(0, len(guideEPG)):
        ch = []
        for i in range(0, len(guideEPG[index])):
            if guideEPG[index][i] == None:
                ch.append('')
            else:
                ch.append(guideEPG[index][i])
        ###SELECT DISTINCT title-0, description-1, source-2, start_date-3, end_date-4 FROM programs WHERE channel=?
        ###def addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
        ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
        ###addDir(ch[0],'url',200,'',cat,'',ch[1] + ' \nEPG from: \n' + ch[2],ch[3],ch[4],ch[1])
        ###datetime.fromtimestamp
        
        try:
            ###utils.logdev(module,'start= %r, end= %r' % (ch[3], ch[4] ))
            ###startDate= datetime.fromtimestamp(float(ch[3]))
            startDate= ch[3]
            ###utils.logdev(module,'Getting startDate\n' + repr(startDate) + ' of type ' + repr(type(startDate)))
            if type(startDate) == int:
                startDate= datetime.fromtimestamp(float(ch[3]))
                endDate= datetime.fromtimestamp(float(ch[4]))
            else:
                startDate= ch[3]
                endDate= ch[4]
            try:
                ArchiveOffset = int(ADDON.getSetting('archiveoffset'))
            except:
                pass
                ArchiveOffset = 1
            ###utils.logdev(module,'ArchiveOffset= %r' % (ArchiveOffset))
            try:
                archiveoffsetminutes = int(ADDON.getSetting('archiveoffsetminutes'))
            except Exception,e:
                pass
                utils.logdev(module,'Error in getting archiveoffsetminutes\n' + repr(e))
                archiveoffsetminutes = 0
            startDateCU= startDate + timedelta(seconds = (ArchiveOffset - TimeZone)*3600 - 60*3 + archiveoffsetminutes*60)  ### USE UK TimeZone and start 3 minutes early  2018-06-08
        except Exception, e:
            pass
            startDate=''
            startDateCU=''
            endDate=''
            utils.logdev(module,'Error in getting dates\n' + repr(e))
        name= ch[0] ###.encode("utf-8")
        recordname= ch[0] ###.encode("utf-8")
        ### change \" to " - it comes from master.xml
        recordname = recordname.replace('\\"','"')
        name = name.replace('\\"','"')
        
        StartDateTime = ''
        Duration = ''
        try:
            StartDateTime = ' \nStart ' + startDate.strftime('%Y-%m-%d %H:%M')
            ###t = int(ch[4]) - int(ch[3])
            dura = (endDate - startDate)/60
            ###if dura > 300:
            utils.logdev(module,'DurationArchive= %r, start= %r, end= %r' % (dura, startDate, endDate ))
            Duration = ' \nDuration [' + str(dura)[-5:] +']. \n'  ###2018-03-08
            #Duration = ' \nDuration ' + str(dura) + ' \n'
            ###Duration = ' \nDuration ' + str((dura)/60) + ' min \n\n'
            try:  ### When was EPG created?
                if 'EPG Created ' in ch[1]:
                    EPGtime = 'EPG Created ' + ch[1].split('EPG Created ')[1][0:19]+'\n'
            except:
                pass
                EPGtime = ''
            description= (namech + ' (' +cat+'):'+StartDateTime+Duration +EPGtime+ '\n' + ch[1])   ###.encode("utf-8")  ### 2018-02-17
            ###utils.logdev(module,'Duration= %r' % Duration )
        except Exception, e:
            pass
            utils.logdev(module,'Error in getting duration\n' + repr(e))
            ###recordings.latin1_to_ascii_force (unicrap)
            description = (recordings.latin1_to_ascii_force(namech) + ' (' +recordings.latin1_to_ascii_force(cat)+'):' +StartDateTime+Duration+ recordings.latin1_to_ascii_force(ch[1]))
        utils.logdev(module,'0 Description= %r' % description)
        description = description.replace('video.nordic','video.***nordic').replace('[CR]n','[CR]').replace('.nn','.[CR][CR]').replace('.n','.[CR]').replace('. n','.[CR]').replace('!n','![CR]').replace('?n','?[CR]').replace('(n)','[CR]').replace('video.***nordic','video.###nordic')  ### 2018-12-07
        utils.logdev(module,'1 Description= %r' % description)
        if '[' in name:
            name = '[B]' + name.replace('[','\n[COLOR lemonchiffon][/B][I][',1) + '[/I]'
            name = name.split('\n')
            line1 = name[0]
            lenline1 = len(line1)
            line2 = name[1]
            lenline2 = len(line2)
            if lenline1 < lenline2:
                line1 = line1 + ' ' * (lenline2 - lenline1 - 16)
            name = line1 +'\n' + line2    ### +'.'+ str(lenline1)+'.'+ str(lenline2)
        else:
            name = '[B]' + name + '[/B]'
        try:
            archiveCU = now - timedelta(days = tv_archive_duration) - timedelta(hours = 1)  ### first hours entries may not be visible
            if tv_archive == 1 and startDate < now and startDate > archiveCU:  ### startDate <-- endDate
                name='[COLOR salmon]%s[/COLOR]'%(name)
                time=startDate.strftime('Arc %d.%m %H:%M  ')
                
                ###addDir(name,url,mode,iconimage='',cat='',date='',description='',startDate='',endDate='',whatsup='')
                ###duration = str(timedelta.total_seconds(endDate - startDate)/60 + 16)  ### duration plus 15 min
                ###utils.logdev(module+'repr(endDate - startDate)=',repr(endDate - startDate))
                ### ANDROID and Linux version
                duration = str(int(repr(endDate - startDate).replace('datetime.timedelta(0, ','').split(')')[0].split(',')[0])/60 + 18) ### duration plus 15 min + 3 min ahead
                utils.logdev(module,'XXXduration= %r, Start= %r, End= %r' % (duration, startDate, endDate))
                start    = startDateCU.strftime('%Y-%m-%d:%H-%M')
                ROQTVusername = ADDON.getSetting('user')
                if ROQTVusername.lower() != 'none':
                    url = definition.getBASEURL() + '/streaming/timeshift.php?username='+ADDON.getSetting('user')+'&password='+ADDON.getSetting('pass')+'&stream='+cat+'&duration='+duration+'&start='+start
                    ###utils.logdev(module,'2020 url= ' + url)
                    addDir(time+name,url,2020,newiconurl,cat,startDate,description,startDate,endDate,recordname) ### Watch or record Archive
            elif tv_archive != 1 and endDate < now :  ### Show History (default 2 hours)
                try:
                    hourstoshow = int(ADDON.getSetting('showhistoryintvguide'))
                    ###utils.logdev(module,'H start= %r, end= %r' % (startDate, endDate))
                    name='[COLOR cyan]%s[/COLOR]'%(name)
                    time=startDate.strftime('His %d.%m %H:%M  ')
                    if endDate > now - timedelta(hours = hourstoshow):
                        addDir(time+name,'url',200,newiconurl,cat,startDate,description,startDate,endDate,recordname)
                except:
                    pass
            elif startDate <= now and now <= endDate:
                name='[COLOR yellow]%s[/COLOR]'%(name)
                time=startDate.strftime('Now %d.%m %H:%M  ')
                url = recordings.urlFromCat(cat)
                addDir(time+name,url,200,newiconurl,cat,startDate,description,startDate,endDate,recordname)
            elif startDate > now and endDate > now:
                ### Find programs that are recording
                recprograms = recordings.isRecording(cat,name,startDate,endDate)
                utils.logdev(module,'Is program: %r beeing recorded? SD= %r ED= %r ActivePrograms: %r' %(name,startDate,endDate,recprograms))
                if recprograms:
                    name='[COLOR red]%s[/COLOR]'%(name)
                else:
                    name='[COLOR lightgreen]%s[/COLOR]'%(name)
                
                time=startDate.strftime('Rec %d.%m %H:%M  ')
                addDir(time+name,'url',2001,newiconurl,cat,startDate.strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20'),description,startDate.strftime('%Y-%m-%d %H:%M:%S'),endDate.strftime('%Y-%m-%d %H:%M:%S'),recordname) ### Record
            else:
                utils.logdev(module,'ERROR start= %r, end= %r' % (startDate, endDate))
        except Exception, e:
            pass
            utils.logdev(module,'Error in setting menu\n' + repr(e))
    setView('movies', 'tvguide-view')

def CutOffDateTime():
    try:
        PlannedRecordingsHistoryHours = int(ADDON.getSetting('showhistoryinplannedrecordings'))
    except Exception,e:
        pass
        utils.logdev(module,'PlannedRecordingsHistoryHours Error\n' + repr(e))
        PlannedRecordingsHistoryHours = 24
    ###utils.logdev(module,'PlannedRecordingsHistoryHours= ' + repr(PlannedRecordingsHistoryHours))
    cutoffdate = (datetime.today() - timedelta(hours = PlannedRecordingsHistoryHours)).strftime('%Y-%m-%d %H:%M:%S')
    ###utils.logdev(module,'cutoffdate= ' + repr(cutoffdate))
    return cutoffdate
    
def RecordingsPlanned():
    GoHome('Planned Recordings')
    offset=0
    c = recordings.getConnection().cursor()
    #c.execute("SELECT * FROM recordings_adc WHERE end=?", [endDate])
    # SELECT * FROM COMPANY WHERE AGE >= 25 OR SALARY >= 65000;
    ## 3.4.6cutoffdate = (datetime.datetime.today() - datetime.timedelta(days = 1)).strftime('%Y-%m-%d')
    
    cutoffdate = CutOffDateTime()
    # 5) Retrieve all IDs of entries between that are older than 1 day and 12 hrs
    #c.execute("SELECT {idf} FROM {tn} WHERE DATE('now') - {dc} >= 1 AND DATE('now') - {tc} >= 12".\
    #    format(idf=id_field, tn=table_name, dc=date_col, tc=time_col))
    #all_1day12hrs_entries = c.fetchall()
    #c.execute("SELECT * FROM recordings_adc WHERE (DATETIME('now') - end) = 0 ")
    #all_1day12hrs_entries = c.fetchall()
    #print 'default.py: cutoffdate= %s' % repr(cutoffdate)
    #print 'default.py: SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE start > %s' % cutoffdate
    #c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE start > %s  AND name NOT CONTAINS 'Recursive' " % cutoffdate )
    try:
        c.execute("SELECT * FROM recordings_adc WHERE start>? AND name NOT LIKE '%Recursive:%'", [cutoffdate])   ### 2018-09-11 use startdate against cutoff date
        #c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc")
    except Exception, e:
        pass
        utils.logdev(module, 'c.execute(SELECT * FROM recordings_adc WHERE start>? AND name NOT LIKE Recursive:, [cutoffdate]) failed! \nERROR= %r' % e)
    recordingsC = c.fetchall()
    #Sort Planned Recordings by start date!
    recordingsD = sorted(recordingsC, key=itemgetter(2))
    # print 'default.py: RecordingsPlanned recordingsD= %s' % repr(recordingsD)
    addDir('[COLOR white][B]Planned Recordings (' + str(len(recordingsD)) + ')[/B][/COLOR]','url',104,'','','','Counter\n\nClick to restore from database','','','')
    for index in range(0, len(recordingsD)):
        if not 'Recursive:' in recordingsD[index][1]:
            showRecording(recordingsD,index)
    # Put recursive recordings last
    try:
        c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE '%Recursive:%'")
    except Exception, e:
        pass
        utils.logdev(module, 'c.execute(SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE Recursive:) failed! \nERROR= %r' % e)
    recordingsC = c.fetchall()
    #recordingsD = sorted(recordingsC, key=itemgetter(1))  # Sort by name
    #recordingsE = sorted(recordingsD, key=itemgetter(6))  # Sort by channel
    recordingsE = sorted(recordingsC, key=itemgetter(1)) # sort by last named
    # print 'default.py: RecordingsPlanned recordingsE= %s' % repr(recordingsE)
    addDir('[COLOR white][B]Recursive Recordings (' + str(len(recordingsE)) + ')[/B][/COLOR]','url',104,'','','','Counter\n\nClick to restore from database','','','')
    for index in range(0, len(recordingsE)):
        if 'Recursive:' in recordingsE[index][1]:
            showRecording(recordingsE,index)
    setView('movies', 'recordingsplanned-view')
    try: c.commit()
    except:
        pass
        #print 'recordings.py commit failed!'
    c.close()

def RecordingsPlannedDebug():
    import recordings
    import utils
    GoHome('Planned Recordings (Debug)')
    offset=0
    c = recordings.getConnection().cursor()
    c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc")
    recordingsC = c.fetchall()
    from operator import itemgetter
    
    #Sort Planned Recordings by start date!
    recordingsD = sorted(recordingsC, key=itemgetter(2))
    #RecordingsPlannedDebugIcons(recordingsD)
    for index in range(0, len(recordingsD)):
        if not 'Recursive:' in recordingsD[index][1]:
            showRecordingDebug(recordingsD,index)
    # Put recursive recordings last
    recordingsD = sorted(recordingsC, key=itemgetter(1))  # Sort by channel
    recordingsE = sorted(recordingsD, key=itemgetter(6))  # Sort by channel
    # recordingsE = sorted(recordingsC, key=itemgetter(2), reverse=True) # sort by last modified
    for index in range(0, len(recordingsE)):
        if 'Recursive:' in recordingsE[index][1]:
            showRecordingDebug(recordingsE,index)
    setView('movies', 'recordingsplanned-view')
    try: c.commit()
    except:
        pass
        #print 'recordings.py commit failed!'
    c.close()
    
def RecordingsPlannedDebugIcons(recordingsD):
    for index in range(0, 10):
        showRecordingDebug(recordingsD,str(index))
        #print 'showRecordingDebug index= %s' % str(index)
    setView('movies', 'recordingsplanned-view')
    
def concurrentrecordings(startDate):
    try:
        ccc= recordings.getRecordingsConcurrent(startDate,startDate)
        ###utils.logdev(module, 'concurrentrecordings(startDate= %r)= %r' % (startDate,ccc))
        ccc= len(ccc)
        if ccc > 0:
            ccc= '[COLOR red]' + str(ccc) + '[/COLOR] '
        else:
            ccc= ''
        ###utils.logdev(module, 'len(concurrentrecordings(startDate= %r))= %r' % (startDate,ccc))
    except Exception,e:
        pass
        utils.logdev(module, 'concurrentrecordings(startDate= %r) FAILED %r' % (startDate,e))
        ccc= ''
    return ccc

def showRecording(recordingsC,index):
        ###GoHome('Show Recordings')
        now = recordings.parseDate(datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
        ignoreRecording = False
    #for index in range(0, len(recordingsC)): 
        cat         = recordingsC[index][0]
        if 'http' in cat:  ### 2018-12-26
            cat = '#'
        #name        = recordings.latin1_to_ascii (recordingsC[index][1].encode("utf-8"))
        name        = recordingsC[index][1]
        startDate   = recordings.parseDate(recordingsC[index][2])
        endDate     = recordings.parseDate(recordingsC[index][3])
        alarmname   = recordingsC[index][4]
        description = recordingsC[index][5]
        utils.logdev(module,'0 Description= %r' % description)
        description = description.replace('video.nordic','video.###nordic').replace('[CR]n','[CR]').replace('.nn','.[CR][CR]').replace('.n','.[CR]').replace('. n','.[CR]').replace('!n','![CR]').replace('?n','?[CR]').replace('(n)','[CR]').replace('video.###nordic','video.nordic')  ### 2018-12-07
        utils.logdev(module,'1 Description= %r' % description)
        if cat != '#':
            playchannel = recordingsC[index][6] 
            try:
                playchannel = recordings.ChannelName(cat)
            except:
                pass
        else:
            playchannel = ''
        try:
            #timeShowStart= str(startDate).split(':')[0] + ":" + str(startDate).split(':')[1]
            timeShowStart=str(startDate).split(' ')[0] + ' (' + (str(startDate).split(' ')[1]).split(':')[0] + ":" + (str(startDate).split(' ')[1]).split(':')[1] 
        except:
            pass
            #print 'default.py: ERROR in startDate= %s' % repr(startDate)
            ignoreRecording = True
            startDate = now
            timeShowStart = now
        try:
            timeShowEnd=(str(endDate).split(' ')[1]).split(':')[0] + ":" + (str(endDate).split(' ')[1]).split(':')[1] +')'
        except:
            pass
            #print 'default.py: ERROR in endDate= %s' % repr(endDate)
            ignoreRecording = True
            endDate = now
            timeShowEnd = now
        nowY = now.strftime('%Y-')
        nowYM = now.strftime('%Y-%m-')
        nowYMD = now.strftime('%Y-%m-%d ')
        time='[COLOR yellow]%s - %s [/COLOR]'%(timeShowStart.replace(nowYMD,'').replace(nowYM,'').replace(nowY,''),timeShowEnd)
        timeOld='%s - %s '%(timeShowStart.replace(nowYMD,'').replace(nowYM,'').replace(nowY,''),timeShowEnd)
        if cat != '#':
            displaychannelnumber = playchannel + ' (' +cat+ '):\n'
            displaychannelnumberold = playchannel + '(' +cat+ '):'
        else:
            displaychannelnumber = ''
            displaychannelnumberold = ''

        displaydescription = description.replace(displaychannelnumber,'').replace(displaychannelnumberold,'').lstrip()
        if ('Recursive:' in name):
            timeRecursive = '%s - '%(timeShowStart)
            #nameRecursive = str(name.replace(':','xxx',1))
            #nameRecursive = str(playchannel) + ' - ' + str(nameRecursive.split('xxx')[1])
            nameRecursive = str(name.replace('Recursive:','',1))
            nameRecursive = nameRecursive + '¤' +  str(playchannel)
            if len(displaydescription) > 0:
                descriptionstrip =  (str(displaydescription).replace('[COLOR green]Example description of channel to record: [/COLOR]','')).lstrip()
                description = '[COLOR green]Example description of channel to record: [/COLOR]\n' + descriptionstrip
        recordname=name
        namecolor = ''
        namecolortest = '*'
        if '[COLOR' in name:
            namecolortest = name.split('[/COLOR]')
            if len(namecolortest) == 1 or len(namecolortest) == 3 or len(namecolortest) == 5:
                namecolor = '[/COLOR]'
        if ' [' in name:
            name = name.replace(' [',namecolor + '[/B]                                                   \n[I][COLOR lemonchiffon][',1)
        ###name = name.replace(' [','[/B]                                                   \n[I][COLOR blue][',1)         ### 2018-04-21
        if '\n[I]' in name:
            name = '[B]' + name +'[/COLOR][/I]'
        #now = recordings.parseDate(now)
        now = recordings.parseDate(datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
        startDate = recordings.parseDate(startDate)
        endDate = recordings.parseDate(endDate)
        #print 'endDateTest =  endDate= %s + datetime.timedelta(days = 1)' % repr(endDate)
        try:
            PlannedRecordingsHistoryHours = int(ADDON.getSetting('showhistoryinplannedrecordings'))
        except Exception,e:
            pass
            utils.logdev(module,'PlannedRecordingsHistoryHours Error\n' + repr(e))
            PlannedRecordingsHistoryHours = 24
        endDateTest =  endDate + timedelta(hours = PlannedRecordingsHistoryHours) # Number of previous days to show in view
        #print 'endDateTest = %s  endDate + datetime.timedelta(days = 1)' % repr(endDateTest)
        #newiconurl= recordings.imageUrlicon(imageUrl,cat,'.png')
        newiconurl= recordings.getIcon(name,cat)
        newurl    = recordings.urlFromCat(cat)
        ###displaydescription = displaychannelnumber + description.replace(displaychannelnumber,'').replace(displaychannelnumberold,'').lstrip().replace('. ','.\n').replace('AAabBB',' ').replace('aAabBb','?').replace('BBabAA','=').replace('xXx',' ').replace('###',',').replace('AaAaA','=')  ### 2017-06-04 
        displaydescription = displaychannelnumber + description.replace(displaychannelnumber,'').replace(displaychannelnumberold,'').lstrip().replace('AAabBB',' ').replace('aAabBb','?').replace('BBabAA','=').replace('xXx',' ').replace('###',',').replace('AaAaA','=')  ### 2018-04-28             
        if (not ignoreRecording and ((recordings.parseDate(endDateTest) > recordings.parseDate(datetime.today().strftime('%Y-%m-%d %H:%M:%S'))) or ('Recursive:' in name))):
            if (startDate < now and now < endDate) and (not ('Recursive:' in name)):
                #http://www.dk4.dk/templates/dk4/images/dk4Logo.png
                #addDir(time+'[COLOR red]'+name+'[/COLOR]','url',200,'http://www.dk4.dk/templates/dk4/images/dk4Logo.png',cat,startDate,playchannel + ': ' + description,startDate,endDate,recordname)
                addDir(time+'[COLOR red]'+name+'[/COLOR]',newurl,200,newiconurl,cat,startDate,displaydescription,startDate,endDate,recordname)
            else:
                if (endDate < now) or ('Recursive:' in name):
                    if ('Recursive:' in name):
                        nameRecursive = nameRecursive.split('¤')
                        if recordings.directprograms(cat) == '':
                            addDir(nameRecursive[0] + '\n[COLOR gray][I]' + nameRecursive[1] + " (" + str(cat) + ")[/I][/COLOR]",newurl,200,newiconurl,cat,startDate,displaydescription,startDate,endDate,recordname)
                        else:
                            addDir('[COLOR lightgreen]' + nameRecursive[0] + '\n[COLOR gray][I]' + nameRecursive[1] + " (" + str(cat) + ")[/I][/COLOR]",newurl,200,newiconurl,cat,startDate,displaydescription,startDate,endDate,recordname)
                    else:
                        addDir(timeOld+name,newurl,200,newiconurl,cat,startDate,displaydescription,startDate,endDate,recordname)
                else:
                    if '[COLOR orange]' in name:  ### 2018-10-05
                        ccc = ''
                    elif '[COLOR blue]' in name:
                        ccc = ''
                    else:
                        ccc = concurrentrecordings(startDate) ###+ ' ' ###+ str(len(name)) + ' '   ### 2018-09-24
                    if recordings.directprograms(cat) == '':
                        addDir(time+ccc+name,newurl,200,newiconurl,cat,startDate,displaydescription,startDate,endDate,recordname)
                    else:
                        addDir(time+ccc +'[COLOR lightgreen]' + name + '[/COLOR]', 'url', 200, newiconurl, cat, startDate, displaydescription, startDate, endDate, recordname)
            #setView('movies', 'recordingsplanned-view')

def showRecordingDebug(recordingsC,index):
        import recordings
        ###GoHome('Show Recordings (Debug)')
        now = recordings.parseDate(datetime.today().strftime('%Y-%m-%d %H:%M:%S'))

    #for index in range(0, len(recordingsC)): 
        cat         = recordingsC[index][0]
        name        = recordingsC[index][1].encode("utf-8")
        startDate   = recordingsC[index][2]
        endDate     = recordingsC[index][3]
        alarmname   = recordingsC[index][4]
        description = recordingsC[index][5]
        playchannel = recordingsC[index][6]
        #cat            = str(index)
        #name        = str(index)
        #startDate   = now
        #endDate     = now
        #alarmname   = str(index)
        #description = str(index)
        #playchannel = str(index)       #description = '\nind=%s \ncat=%s \nnam=%s \nsta=%s \nend=%s \nala=%s \npla=%s' %(repr(index),repr(cat),repr(name),repr(startDate),repr(endDate),repr(alarmname),repr(playchannel))
        #print str(index)
        #print imageUrl+cat+'.png'
        #newiconurl= recordings.imageUrlicon(imageUrl,cat,'.png')
        newiconurl= recordings.getIcon(name,cat)
        try:
            #print repr(OPEN_URL(imageUrl+cat+'.png')) 
            addDir('[COLOR red]'+name+'[/COLOR]','url',200,newiconurl,cat,startDate,playchannel + ': '  + repr(startDate) + ' - ' + repr(startDate) + ' # ' + description,startDate,endDate,name)
        except:
            pass
        #setView('movies', 'recordingsplanned-view')

def playmediaORG(media_url):
    try:
        import traceback
        import  CustomPlayer
        player = CustomPlayer.MyXBMCPlayer()
        listitem = xbmcgui.ListItem( label = str(name), iconImage = "DefaultVideo.png", thumbnailImage = xbmc.getInfoImage( "ListItem.Thumb" ), path=media_url )
        player.play( media_url,listitem)
        xbmc.sleep(1000)
        while player.is_active:
            xbmc.sleep(200)
    except:
        traceback.print_exc()
    return ''
    
def playmedia(media_url):
    try:
        import traceback
        import  CustomPlayer
        player = CustomPlayer.MyXBMCPlayer()
        listitem = xbmcgui.ListItem( label = str(name), iconImage = "DefaultVideo.png", thumbnailImage = xbmc.getInfoImage( "ListItem.Thumb" ), path=media_url )
        utils.logdev(module,'player.play( media_url= %r,\nlistitem= %r)' % ( media_url,listitem))
        ###listitem.setInfo('video', { 'duration': 120*60 })  ### Default Video 2 hours  2019-01-09
        player.play( media_url,listitem)
        xbmc.sleep(1000)
        i = 0
        ###while player.is_active and i < 30:
        while player.is_active:
            ###time.sleep(1)
            xbmc.sleep(1000)
            i += 1
            ###utils.logdev(module,'player.play( media_url= %r, i= %r)' % ( media_url,i))
    except:
        pass
        utils.logdev(module,'traceback.print_exc()' )
        traceback.print_exc()
    ###return ''
    
def RECORD_CATCHUP(name,url,iconimage,cat,description): 
    ###utils.logdev(module,'RECORD_CATCHUP url= ' + url)
    utils.logdev(module,'RECORD_CATCHUP (name= %r \nurl= %r \niconimage= %r \ncat= %r \ndescription= %r )' % (name,url,iconimage,cat,description))
    ### url= 'http://e900x.com:8000/streaming/timeshift.php?username=xxx&password=yyy&stream=UNL967&duration=73&start=2019-05-09:19-37' 
    if 'UNL' in cat:
        url += '&'
        cat = param(url,'stream')
        duration = param(url,'duration')
        startDate = param(url,'start')
        ### 2017-05-21:16-00
        time_tuple = time.strptime(startDate, "%Y-%m-%d:%H-%M")
        startDateTS = int(time.mktime(time_tuple))
        ### Get url: '/channels/get-record/' + chId + '/' + evtStart + '/' + evtDuration
        ### https://www.unlim.tv:443/channels/get-record/949/1557407400/6000
        ###url = 'https://www.unlim.tv:443/channels/get-record/'+cat+'/'+str(startDateTS)+'/'+duration
        URI='plugin://plugin.video.unlimtv/?url=url#startdate=' + str(startDateTS) +'#duration='+ duration + '&mode=211&cat=' + cat[3:] + '#startdate=' + str(startDateTS) +'#duration='+ duration + '&source='+ADDONid
        
        ADDON.setSetting('recordfromunlim',cat) 
        ADDON.setSetting('recordfromunlimtitle',name)
        ADDON.setSetting('recordfromunlimduration',duration) 
        ADDON.setSetting('recordfromunlimstartdate',startDate) 
        ADDON.setSetting('recordfromunlimdescription',description) 
        utils.logdev(module,'Get uri from unlimtv: URI= %r' % URI)
        maxSleep = 500
        try:
            utils.logdev(module,repr(URI))
            xbmc.executebuiltin('XBMC.RunPlugin(%s)' % URI) 
            xbmc.sleep(maxSleep)
        except Exception,e:
            pass
            utils.logdev(module,'Recording from UNL FAILED: %r' % e)
    else:    
        startD = recordings.parseDate(datetime.now())
        endD = startD

        recordingsActive = []
        recordingsActiveAll = recordings.getRecordingsActive(startD,endD)
        utils.logdev(module,'recordingsActiveAll= %r' % recordingsActiveAll)
        for x in recordingsActiveAll:
            utils.logdev(module,'x= %s' % repr(x))
            if not '[COLOR orange]' in x and not '[COLOR violet]' in x :
                utils.logdev(module,'recordingsActive= %s' % repr(recordingsActive))
                recordingsActive.append(x)
                utils.logdev(module,'recordingsActive= %s' % repr(recordingsActive))
        if (recordingsActive != []) or locking.isAnyRecordLocked():
            utils.notification('OVERLAPPING Recordings Warning: %s' % str(recordingsActive))
            #if (repr(recordingsActive) != "[]"):
            lockcause = repr(locking.RecordsLocked())
            #else:
            #   lockcause = repr(recordingsActive)
            dialog = xbmcgui.Dialog()
            if dialog.yesno(ADDON.getAddonInfo('name'), "[COLOR red]Stop recording?[/COLOR]", repr(recordingsActive), "What Do You Want To Do","[COLOR red]Stop recording[/COLOR]","[COLOR green]Ignore[/COLOR]"):
                ### Ignore
                lockcause = 'Ignore' ### Dummy command
            else:
                ### Stop recording and record new
                Recordffmpeg(name, url, '', '', description.replace(' ','AAabBB').replace('?','aAabBb').replace('=','BBabAA').replace(',','###').replace('&','AaAaA').replace('\n','NlNlNl'), auth, sourceApp)
        else:
            Recordffmpeg(name, url, '', '', description.replace(' ','AAabBB').replace('?','aAabBb').replace('=','BBabAA').replace(',','###').replace('&','AaAaA').replace('\n','NlNlNl'), auth, sourceApp)
        
def PLAY_CATCHUP(name,url,iconimage,cat,description):    ### Watch Archive 2020
    ###http://roq-tv.net:25461/streaming/timeshift.php?username=XXX&password=XXXX&stream=276&duration=120&start=2017-05-21:16-00
    ###duration = endDate - startDate  ### in minutes
    ###start    = startDate.strftime('%Y-%m-%d:%H-%M')
    ###url = 'http://roq-tv.net:25461/streaming/timeshift.php?username='+ADDON.getSetting('user')+'&password='+ADDON.getSetting('password')+'&stream='+cat+'&duration='+duration+'&start='+start
    utils.logdev(module,'PLAY_CATCHUP 2020 (name= %r \nurl= %r \niconimage= %r \ncat= %r \ndescription= %r )' % (name,url,iconimage,cat,description))
    ###PLAY_STREAM(name,url,iconimage,cat)
    startD = recordings.parseDate(datetime.now())
    endD = startD + timedelta(hours = 2)

    recordingsActive = []
    recordingsActiveAll = recordings.getRecordingsActive(startD,startD)  ### 2019-01-08 test at start
    utils.logdev(module,'recordingsActiveAll= %r' % recordingsActiveAll)
    for x in recordingsActiveAll:
        utils.logdev(module,'x= %s' % repr(x))
        if not '[COLOR orange]' in x and not '[COLOR violet]' in x :
            utils.logdev(module,'recordingsActive= %s' % repr(recordingsActive))
            recordingsActive.append(x)
            utils.logdev(module,'recordingsActive= %s' % repr(recordingsActive))
    if (recordingsActive != []) or locking.isAnyRecordLocked():
        utils.notification('OVERLAPPING Recordings Warning: %s' % str(recordingsActive))
        #if (repr(recordingsActive) != "[]"):
        lockcause = repr(locking.RecordsLocked())
        #else:
        #   lockcause = repr(recordingsActive)
        dialog = xbmcgui.Dialog()
        if dialog.yesno(ADDON.getAddonInfo('name'), "[COLOR red]Stop recording?[/COLOR]", repr(recordingsActive), "What Do You Want To Do","[COLOR red]Stop recording[/COLOR]","[COLOR green]Record this later[/COLOR]"):
            ### Code to record/download
            playchannel = recordings.ChannelName(cat)
            RECORD_CATCHUP(name+' ('+playchannel+')',url,iconimage,cat,description)
            return
    """
    #print 'default.py: locking.recordUnlockAll()'
    locking.recordUnlockAll()
    # Test locking and unlock
    testX = 'TEST'
    locking.recordLock(testX)
    if locking.isRecordLocked(testX):
        locking.recordUnlock(testX)
    else:
        recordingLock = os.path.join(ADDON.getAddonInfo('path'),'rtmpdump', 'recordingLock') +  testX + '.txt'
        utils.notification('Record Locking fails at %s' % str(recordingLock))
    """
    try:
        _name=name.split(' -')[0].replace('[/COLOR]','').replace('[COLOR salmon]','')
        playername=name.split('- ')[1].replace('[/COLOR]','').replace('[COLOR salmon]','')
    except:
        _name=name.replace('[/COLOR]','')
        playername=name.replace('[/COLOR]','')
    dialog = xbmcgui.Dialog()
    if dialog.yesno(ADDON.getAddonInfo('name'), "[COLOR red]Record from archive?[/COLOR]", playername, "What Do You Want To Do","[COLOR red]Record[/COLOR]","[COLOR green]Watch[/COLOR]"):
        playmedia(url)
    else:
        ### Code to record/download
        playchannel = recordings.ChannelName(cat)
        RECORD_CATCHUP(name+' ('+playchannel+')',url,iconimage,cat,description)
        ###RECORD_CATCHUP(name,url,iconimage,cat,description)

def FreeLine(cat):
    concurrentlines = 1
    usedlines       = 0
    ROQTVusername = ADDON.getSetting('user')
    if ROQTVusername.lower() != 'none':
        try:
            link = definition.getBASEURL() + '/panel_api.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')
            file = urllib2.urlopen(link)
            data = file.read()
            file.close()
            
            ChannelFile = os.path.join(datapath,ADDONid) + '.info'
            with open(ChannelFile,'wb') as output:
                output.write(data)
            ###name= Status,url= url,mode= 11,iconimage= ,cat= ,date= ,description= {u'username': u'XXX', u'status': u'Active', u'is_trial': u'0', u'created_at': u'1493734688', u'auth': 1, u'allowed_output_formats': [u'm3u8', u'ts', u'rtmp'], u'exp_date': u'1499005088', u'active_cons': u'0', u'password': u'XXXX', u'max_connections': u'1'},startDate= ,endDate= ,recordname= )
            d = json.loads(data)
            d1 = d['user_info']
            concurrentlines = int(d1['max_connections'])
            usedlines       = int(d1['active_cons'])
        except Exception,e:
            pass
            utils.logdev(module,'FreeLine(cat= %r) Error %r' % (cat,e))
            concurrentlines = 1
            usedlines       = 0
    return concurrentlines - usedlines
        
def PLAY_STREAM(name,url,iconimage,cat):
    """
2019-05-07 11:29:13 default.py: PLAY_STREAM(name= 'TV2 Charlie DK (A)',url= 'plugin.video.unlimtv',iconimage= 'TV2_Charlie.png',cat= 'UNL967')
2019-05-07 11:29:13 recordings.py: directprograms(cat= 'UNL967') channelname= 'TV2 Charlie DK', last 4= 'e DK'
2019-05-07 11:29:13 default.py: PLAY_STREAM(playchannel= 'TV2 Charlie DK (A) (UNL967)',recorddrdirectly= '')
2019-05-07 11:29:15 default.py: PLAY_STREAM(cat= 'UNL967',freeline= 1)

        URI='plugin://plugin.video.unlimtv/?url=url&mode=210&source='+ADDONid+'&cat=967' 
        ADDON.setSetting('recordfromunlim','967') 
        ADDON.setSetting('recordfromunlimtitle','Titel på optagelsen')
        ADDON.setSetting('recordfromunlimduration','3600') 
        ADDON.setSetting('recordfromunlimdescription','Her er så beskrivelsen af optagelsen') 
        utils.logdev(module,'Get uri from unlimtv: URI= %r' % URI)
        tries    = 0
        maxTries = 10
        maxSleep = 500
        try:
            utils.logdev(module,repr(URI))
            xbmc.executebuiltin('XBMC.RunPlugin(%s)' % URI) 
            xbmc.sleep(maxSleep)
        except:
            pass 
    """
    utils.logdev(module,'PLAY_STREAM(name= %r,url= %r,iconimage= %r,cat= %r)' % (name,url,iconimage,cat))
    if cat == '':
        cat=recordings.catFromUrl(url)
    if 'plugin.video' in url:
	URI='plugin://'+url+'/?mode=200&cat=' + cat[3:]
        try:  ### Get the set webport
            webport = utils.getGuiSetting('webserverport','8080')
        except:
            pass
            webport = '8080'
        url = 'http://127.0.0.1:' + webport + '/jsonrpc?request={"jsonrpc":"2.0","method":"Addons.ExecuteAddon","params":{"wait":false,"addonid":"' +url + '","params":["cat=' + cat[3:] + '","mode=200","name=' + name + '","recordname='+ADDONid+'"]},"id":200}'
        utils.logdev(module,repr(URI))
        utils.logdev(module,repr(url))
        ###xbmc.executebuiltin('XBMC.RunPlugin(%s)' % URI)
        try: 
          import webbrowser
          webbrowser.open(url)
        except Exception,e:
          pass
          utils.logdev(module,'Open URL in browser %r\nFAILED: %r' % (url,e))

    else:
        recorddrdirectly=recordings.directprograms(cat)  ### Get direct links
        playchannel = name + ' (' + cat + ')'
        utils.logdev(module,'PLAY_STREAM(playchannel= %r,recorddrdirectly= %r)' % (playchannel,recorddrdirectly))
        PlayDefaultStream = True
        if recorddrdirectly == '':
            freeline = FreeLine(cat)
            utils.logdev(module,'PLAY_STREAM(cat= %r,freeline= %r)' % (cat,freeline))
            if freeline < 1 :
                dialog = xbmcgui.Dialog()
                if dialog.yesno(ADDON.getAddonInfo('name'), "[COLOR red]No free lines[/COLOR]", '', "What Do You Want To Do","[COLOR red]Use line anyhow[/COLOR]","[COLOR green]Ignore[/COLOR]"):
                    return
            LastPlayedStreamname = ADDON.getSetting('LastPlayedStreamname')
            LastPlayedStreamurl = ADDON.getSetting('LastPlayedStreamurl')
            LastPlayedStreamiconimage = ADDON.getSetting('LastPlayedStreamiconimage')
            LastPlayedStreamcat = ADDON.getSetting('LastPlayedStreamcat')
            if cat != '':
                ADDON.setSetting('LastPlayedStreamname', name)
                ADDON.setSetting('LastPlayedStreamurl', url)
                ADDON.setSetting('LastPlayedStreamiconimage', iconimage)
                ADDON.setSetting('LastPlayedStreamcat', cat)
                PlayDefaultStream = False
            else:
                name = LastPlayedStreamname
                url = LastPlayedStreamurl
                iconimage = LastPlayedStreamiconimage
            cat = LastPlayedStreamcat
            PlayDefaultStream = True
        startD = recordings.parseDate(datetime.now())
        endD = startD
        utils.logdev(module,'PlayDefaultStream= %s' % repr(PlayDefaultStream))
        if PlayDefaultStream:
            recordingsActive = []
        else:
            recordingsActive = []
            recordingsActiveAll = recordings.getRecordingsActive(startD,endD)
            utils.logdev(module,'recordingsActiveAll= %r' % (recordingsActiveAll))
            for x in recordingsActiveAll:
                utils.logdev(module,'x= %r' % (x))
                if not '[COLOR orange]' in x and not '[COLOR violet]' in x :
                    utils.logdev(module,'recordingsActive= %r' % (recordingsActive))
                    recordingsActive.append(x)
                    utils.logdev(module,'recordingsActive= %r' % (recordingsActive))
        if (recordingsActive != []) or locking.isAnyRecordLocked():
            utils.notification('OVERLAPPING Recordings Warning: %r' % (recordingsActive))
            lockcause = repr(locking.RecordsLocked())
            dialog = xbmcgui.Dialog()
            if dialog.yesno(ADDON.getAddonInfo('name'), "[COLOR red]Stop recording?[/COLOR]", repr(recordingsActive), "What Do You Want To Do","[COLOR red]Stop recording[/COLOR]","[COLOR green]Ignore[/COLOR]"):
                return
        else:
            utils.logdev('play direct channel',repr(name))
        try:
            _name=name.split(' -')[0].replace('[/COLOR]','').replace('[COLOR yellow]','')
            playername=name.split('- ')[1].replace('[/COLOR]','').replace('[COLOR yellow]','')
        except:
            _name=name.replace('[/COLOR]','')
            playername=name.replace('[/COLOR]','')
        utils.logdev('TIMESHIFT','Start TimeShift')
        timeshiftsetting = ADDON.getSetting('timeshift')
        if timeshiftsetting == '1':
            ask = xbmcgui.Dialog().yesno( ADDON.getAddonInfo('name'), name + '\n\nUse TimeShift?')
            #utils.notificationbox(repr(ask))
            if repr(ask) == '1':
                timeshiftsetting = '2'
            else:
                timeshiftsetting = '0'
        if timeshiftsetting == '2':
            ###utils.logdev('default.py','RecordTimeShift(timeshift, url= %s, playpath= %s, app= %s)' % (url, playpath,app))
        
            ###timeshiftfileold = timeshiftfile.replace('.ts','OLD.ts')
            ###utils.logdev('default.py','shutil.copyfile(timeshiftfile= %s,timeshiftfileold= %s)' % (timeshiftfile,timeshiftfileold))
            ###deleteFile(timeshiftfileold)
            ###try:
            ###    shutil.copyfile(timeshiftfile,timeshiftfileold)  ###
            ###utils.logdev('default.py','shutil.copyfile(timeshiftfile,timeshiftfileold) EXECUTED')
            ###except:
            ###    pass
            """if os.path.isfile(timeshiftfile) == True: 
                deleteFile(timeshiftfile)
                count = 0
                test = os.path.isfile(timeshiftfile)
                while not test == True and count < 10:
                    ###time.sleep(1)
                    xbmc.sleep(1000)
                    count += 1
                    test = os.path.isfile(timeshiftfile)
                    ###utils.logdev('default.py','RecordTimeShift test delete count= %s' % repr(count))
            """
            ADDON.setSetting('timeshiftfile','')  ### Clear Filename
            count = 0
            timeshiftfile = ADDON.getSetting('timeshiftfile')
            while timeshiftfile != '' and count < 10:
                xbmc.sleep(100)
                timeshiftfile = ADDON.getSetting('timeshiftfile')
                count += 1
            utils.logdev(module,'RecordTimeShift 1 #%r file= %r' % (count,timeshiftfile))
            stoptimeshift()
            """
            subprpid = xbmcgui.Window(10000).getProperty(ADDONname + 'subprpid')
            subprcmd = xbmcgui.Window(10000).getProperty(ADDONname + 'subprcmd')
            utils.logdev('runCommand','OldTimeShift subprpid= %r, subprcmd= %r' % (subprpid, subprcmd))
            if subprpid != '' and ADDON.getSetting('timeshiftbase') in subprcmd:
                utils.terminateSubpr(subprpid)
            try:
                xbmcgui.Window(10000).setProperty(ADDONname + 'subprpid', '')
                xbmcgui.Window(10000).setProperty(ADDONname + 'subprcmd', '')
            except Exception,e:
                pass
                utils.logdev('runCommand','Error reset \ncmd= %r\nError= %r' % (cmd,e))
            """
        
            RecordTimeShift(name, url, playpath, app, cat)  #### TimeShift record  ##########################
        
            try:
                timeshiftPID = xbmcgui.Window(10000).getProperty(ADDONname + 'subprpid')
                timeshiftCMD = xbmcgui.Window(10000).getProperty(ADDONname + 'subprcmd')
            except Exception,e:
                pass
                utils.logdev('runCommand','Error get \ncmd= %r\nError= %r' % (cmd,e))
                timeshiftPID = '*'
                timeshiftCMD = '*'
        
            utils.logdev('runCommand','0 timeshiftPID= %r, timeshiftCMD= %r' % (timeshiftPID, timeshiftCMD))
            recordPath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_path')))
            timeshiftbase = ADDON.getSetting('timeshiftbase')
            timeshiftfileexpected = recordPath + timeshiftbase + '_' + datetime.today().strftime('%Y-%m-%d_%H-%M') + '.ts'
        
            count = 0
            timeshiftfile = ADDON.getSetting('timeshiftfile')
            while timeshiftfile == '' and count < 10:
                utils.logdev(module,'RecordTimeShift 2 #%r file= %r' % (count,timeshiftfile))
                xbmc.sleep(100)
                timeshiftfile = ADDON.getSetting('timeshiftfile')
                count += 1
            utils.logdev(module,'RecordTimeShift 3 #%r file= %r' % (count,timeshiftfile))
        
            try:
                timeshiftPID = xbmcgui.Window(10000).getProperty(ADDONname + 'subprpid')
                timeshiftCMD = xbmcgui.Window(10000).getProperty(ADDONname + 'subprcmd')
            except Exception,e:
                pass
                logdev('runCommand','Error get \ncmd= %r\npid= %r' % (cmd,e))
                timeshiftPID = '*'
                timeshiftCMD = '*'
        
            utils.logdev('runCommand','1 timeshiftPID= %r, timeshiftCMD= %r' % (timeshiftPID, timeshiftCMD))
        
            title = name
            playername = title
            channel = cat
        
            timeshiftfile = ADDON.getSetting('timeshiftfile')
            count = 0
            while timeshiftfile == '' and count < 10:
                utils.logdev(module,'RecordTimeShift 4 #%r file= %r' % (count,timeshiftfile))
                xbmc.sleep(100)
                count += 1
                timeshiftfile = ADDON.getSetting('timeshiftfile')
            utils.logdev(module,'RecordTimeShift 5 #%r file= %r' % (count,timeshiftfile))
        
            try:
                timeshiftPID = xbmcgui.Window(10000).getProperty(ADDONname + 'subprpid')
                timeshiftCMD = xbmcgui.Window(10000).getProperty(ADDONname + 'subprcmd')
            except Exception,e:
                pass
                logdev('runCommand','Error get \ncmd= %r\npid= %r' % (cmd,e))
                timeshiftPID = '*'
                timeshiftCMD = '*'
        
            utils.logdev('runCommand','2 timeshiftPID= %r, timeshiftCMD= %r' % (timeshiftPID, timeshiftCMD))
        
            count = 0
            timeshiftrunning = os.path.isfile(timeshiftfile)
            while timeshiftrunning == False and count < 10: 
                utils.logdev(module,'RecordTimeShift 6 #%r running= %r' % (count,timeshiftrunning))
                xbmc.sleep(100)
                count += 1
                timeshiftrunning = os.path.isfile(timeshiftfile)
            if count == 10:   ### Set default filename
                timeshiftfile = timeshiftfileexpected
                utils.logdev(module,'RecordTimeShift 7 #%r running= %r file= %r' % (count,timeshiftrunning,timeshiftfile))
        
            try:
                timeshiftPID = xbmcgui.Window(10000).getProperty(ADDONname + 'subprpid')
                timeshiftCMD = xbmcgui.Window(10000).getProperty(ADDONname + 'subprcmd')
            except Exception,e:
                pass
                logdev('runCommand','Error get \ncmd= %r\npid= %r' % (cmd,e))
                timeshiftPID = '*'
                timeshiftCMD = '*'
        
            utils.logdev('runCommand','3 timeshiftPID= %r, timeshiftCMD= %r' % (timeshiftPID, timeshiftCMD))
        
            utils.logdev(module,'RecordTimeShift 8 #%r running= %r file= %r' % (count,timeshiftrunning,timeshiftfile))   
            #liz=xbmcgui.ListItem(title, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
            liz=xbmcgui.ListItem(playername)
            liz.setInfo( type="Video", infoLabels={ "Title": playername} )
            liz.setProperty("IsPlayable","true")
            ###utils.logdev(module,'timeshiftfile= %s' % (timeshiftfile))
            liz.setPath(timeshiftfile)
            ###utils.logdev(module,'RecordTimeShift 0++++ file= %s liz= %s' % (repr(timeshiftfile), repr(liz)))
            ##xbmc.sleep(5000) ## Shows only theese 5 sec?
            utils.logdev('runCommand','1 timeshiftPID= %r, timeshiftCMD= %r' % (timeshiftPID, timeshiftCMD))
            count = 0
            countmax = int(ADDON.getSetting('timeshiftbuffer'))
            while count < countmax: 
                xbmc.sleep(1000)
                count += 1
                utils.notification('Record TimeShift filling buffer: #%s %s (%s)' % (str(count),recordname,channel))
            ###playmedia(timeshiftfile)
            ###xbmc.executebuiltin("PlayMedia("+timeshiftfile+")")
            utils.logdev('runCommand','2 timeshiftPID= %r, timeshiftCMD= %r' % (timeshiftPID, timeshiftCMD))
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz) 
    
    
        if timeshiftsetting == '0':
            utils.logdev('default.py: PLAY_STREAM ',repr(recorddrdirectly))
            liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
            liz.setInfo( type="Video", infoLabels={ "Title": name} )
            #liz.setInfo('video', { 'duration': 120*60 })  ### Default Video 2 hours 2019-01-09
            #lizVideoInfo = liz.getInfo('video')
            BASEURL = definition.getBASEURL()
            ###PLAYURL = definition.getPLAYURL()
            ### "server_info_https_port" 25463 "server_info_port" 8000 "server_info_protocol" http "server_info_url" e900x.com
            if ADDON.getSetting('server_info_protocol').lower() == 'http':
                PLAYURL = 'http://' + ADDON.getSetting('server_info_url') + ':' + ADDON.getSetting('server_info_port')
            else:
                PLAYURL = 'https://' + ADDON.getSetting('server_info_url') + ':' + ADDON.getSetting('server_info_https_port')

            utils.logdev(module,'BASEURL= %r' % BASEURL)
            utils.logdev(module,'PLAYURL= %r' % PLAYURL)
            utils.logdev(module,'url= %r' % url)        
            if (PLAYURL != '' or PLAYURL != 'http://:' or PLAYURL != 'https://:') and BASEURL.split(':')[1] in url:
                ### Ignore port from url if it is there
                try:             
                    url = url.split('/',3)
                    url = PLAYURL + '/' + url[3]
                except:
                    pass
                utils.logdev(module,'url= %r' % url)
            utils.logdev(module, 'PLAY_STREAM Path= %r' % url)

            liz.setProperty("IsPlayable","true")
            liz.setPath(url)
            ###listitem.setInfo('video', { 'genre': 'Comedy' })
            ###duration integer (245) - duration in seconds
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz) 


"""
def PLAY_STREAM_NTV_TimeShift(name,url,iconimage,cat):
    #print 'default.py PLAY_STREAM(name,url,iconimage,cat) %s %s %s %s' % (repr(name), repr(url), repr(iconimage), repr(cat))
    recorddrdirectly=utils.directprograms(cat)  ### Get direct links
    dialog = xbmcgui.Dialog()
    playchannel = recordings.ChannelName(cat) + ' (' + cat + ')'
    # Play Direct if cat has Direct url and recording is active otherwise ask
    if not recorddrdirectly == '' and not locking.isAnyRecordLocked() and dialog.yesno(ADDON.getAddonInfo('name'), "Play Direct or NTV?", playchannel, "What Do You Want To Do","[COLOR red]NTV[/COLOR]","[COLOR green]Direct[/COLOR]"):
        # Play stream directly
        ###utils.logdev('default.py: PLAY_STREAM Directly',repr(recorddrdirectly))
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name} )
        liz.setProperty("IsPlayable","true")
        liz.setPath(recorddrdirectly)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz) 
    else:   
        LastPlayedStreamname = ADDON.getSetting('LastPlayedStreamname')
        LastPlayedStreamurl = ADDON.getSetting('LastPlayedStreamurl')
        LastPlayedStreamiconimage = ADDON.getSetting('LastPlayedStreamiconimage')
        LastPlayedStreamcat = ADDON.getSetting('LastPlayedStreamcat')
        if cat != 0:
            ADDON.setSetting('LastPlayedStreamname', name)
            ADDON.setSetting('LastPlayedStreamurl', url)
            ADDON.setSetting('LastPlayedStreamiconimage', iconimage)
            ADDON.setSetting('LastPlayedStreamcat', cat)
            PlayDefaultStream = False
        else:
            name = LastPlayedStreamname
            url = LastPlayedStreamurl
            iconimage = LastPlayedStreamiconimage
            cat = LastPlayedStreamcat
            PlayDefaultStream = True
        #startD = recordings.parseDate(datetime.now())
        startD = recordings.parseDate(datetime.now())
        endD = startD
        ###utils.logdev('default.py','PlayDefaultStream= %s' % repr(PlayDefaultStream))
        if PlayDefaultStream:
            recordingsActive = []
        else:
            recordingsActive = []
            recordingsActiveAll = recordings.getRecordingsActive(startD,endD)
            ###utils.logdev('default.py','recordingsActiveAll= %s' % repr(recordingsActiveAll))
            for x in recordingsActiveAll:
                ###utils.logdev('default.py','x= %s' % repr(x))
                if not '[COLOR orange]' in x:
                    ###utils.logdev('default.py','recordingsActive= %s' % repr(recordingsActive))
                    recordingsActive.append(x)
                    ###utils.logdev('default.py','recordingsActive= %s' % repr(recordingsActive))
        if (recordingsActive != []) and locking.isAnyRecordLocked():
            utils.notification('OVERLAPPING Recordings NOT allowed: %s' % str(recordingsActive))
            #if (repr(recordingsActive) != "[]"):
            lockcause = repr(locking.RecordsLocked())
            #else:
            #   lockcause = repr(recordingsActive)
            dialog = xbmcgui.Dialog()
            if dialog.yesno(ADDON.getAddonInfo('name'), "[COLOR red]Stop recording?[/COLOR]", repr(recordingsActive), "What Do You Want To Do","[COLOR red]Stop recording[/COLOR]","[COLOR green]Ignore[/COLOR]"):
                return
        #print 'default.py: locking.recordUnlockAll()'
        locking.recordUnlockAll()
        # Test locking and unlock
        testX = 'TEST'
        locking.recordLock(testX)
        if locking.isRecordLocked(testX):
            locking.recordUnlock(testX)
        else:
            recordingLock = os.path.join(ADDON.getAddonInfo('path'),'rtmpdump', 'recordingLock') +  testX + '.txt'
            utils.notification('Record Locking fails at %s' % str(recordingLock))
        try:
            _name=name.split(' -')[0].replace('[/COLOR]','').replace('[COLOR yellow]','')
            playername=name.split('- ')[1].replace('[/COLOR]','').replace('[COLOR yellow]','')
        except:
            _name=name.replace('[/COLOR]','')
            playername=name.replace('[/COLOR]','')
        net.set_cookies(cookie_jar)
        url = '&mwAction=content&xbmc=1&mwData={"id":%s,"type":"tv"}'%cat
        link = net.http_GET(site+url, headers={'User-Agent' : UA}).content
        errorname = recordings.ChannelName(cat)
        if '"allown":false' in link:
            try:
                match=re.compile('"message":"(.+?)"').findall(link)
                dialog = xbmcgui.Dialog()
                dialog.ok(ADDON.getAddonInfo('name'), errorname + ' (' + cat +') ', match[0].replace('\/','/'))
            except:
                dialog = xbmcgui.Dialog()
                dialog.ok(ADDON.getAddonInfo('name'), errorname + ' (' + cat +') ', 'Please Sign Up To Watch The Streams')
        else:
            match=re.compile('"src":"(.+?)","type":"rtmp"').findall(link)
            if match:
                url=match[0].replace('\/','/')
                # NOT in 3.4.1 rtmp=match[0].replace('\/','/')
                # NOT in 3.4.1 playpath=rtmp.split('live/')[1]
                # NOT in 3.4.1 app='live?'+rtmp.split('?')[1]
                # NOT in 3.4.1 url='%s swfUrl=http://ntv.mx/inc/strobe/StrobeMediaPlayback.swf app=%s playPath=%s pageUrl=http://ntv.mx/?c=2&a=0&p=50 timeout=10'%(rtmp,app,playpath)
            else:
                match=re.compile('"src":"(.+?)","type":"hls"').findall(link)
                hls=match[0].replace('\/','/')
                url=hls
            timeshiftsetting = ADDON.getSetting('timeshift')
            if timeshiftsetting == '1':
                ask = xbmcgui.Dialog().yesno( ADDON.getAddonInfo('name'), name + '\n\nUse TimeShift?')
                #utils.notificationbox(repr(ask))
                if repr(ask) == '1':
                    timeshiftsetting = '2'
                else:
                    timeshiftsetting = '0'
            if timeshiftsetting == '2':
                ###utils.logdev('default.py','RecordTimeShift(timeshift, url= %s, playpath= %s, app= %s)' % (url, playpath,app))
                timeshiftfile = ADDON.getSetting('timeshiftfile')
                timeshiftfileold = timeshiftfile.replace('.ts','OLD.ts')
                ###utils.logdev('default.py','shutil.copyfile(timeshiftfile= %s,timeshiftfileold= %s)' % (timeshiftfile,timeshiftfileold))
                deleteFile(timeshiftfileold)
                try:
                    shutil.copyfile(timeshiftfile,timeshiftfileold)  ###
                    ###utils.logdev('default.py','shutil.copyfile(timeshiftfile,timeshiftfileold) EXECUTED')
                except:
                    pass
                if os.path.isfile(timeshiftfile) == True: 
                    deleteFile(timeshiftfile)
                    count = 0
                    test = os.path.isfile(timeshiftfile)
                    while not test == True and count < 10:
                        time.sleep(1)
                        count += 1
                        test = os.path.isfile(timeshiftfile)
                        ###utils.logdev('default.py','RecordTimeShift test delete count= %s' % repr(count))
                RecordTimeShift(name, url, playpath, app, cat)  #### TimeShift record
            
                timeshiftfile = ADDON.getSetting('timeshiftfile')
                ###utils.logdev(module,'RecordTimeShift 0+ file= %s' % repr(timeshiftfile))
            
                title = name
                playername = title
                channel = cat
            
                count = 0
                while timeshiftfile == '' and count < 100:
                    ###utils.logdev(module,'RecordTimeShift 0++ file= %s' % repr(timeshiftfile))
                    xbmc.sleep(250)
                    count += 1
                    timeshiftfile = ADDON.getSetting('timeshiftfile')
                    ###utils.logdev(module,'RecordTimeShift count= %s' % repr(count))
                    ###utils.logdev(module,'RecordTimeShift 0+++ file= %s' % repr(timeshiftfile))
                    #utils.notification('Record TimeShift Waiting for Agent: #%s %s (%s)' % (str(count),recordname,channel))
                ###utils.logdev(module,'RecordTimeShift count= %s' % repr(count))
                count = 0
                timeshiftrunning = os.path.isfile(timeshiftfile)
                while timeshiftrunning == False and count < 100: 
                    xbmc.sleep(250)
                    count += 1
                    timeshiftrunning = os.path.isfile(timeshiftfile)
                    ###utils.logdev(module,'RecordTimeShiftRunning count= %s - %s (%s)' % (repr(count),recordname,channel))
                    #utils.notification('Record TimeShift Waiting for File: #%s %s (%s)' % (str(count),recordname,channel))
                ###utils.logdev(module,'RecordTimeShiftRunning count= %s - %s (%s)' % (repr(count),recordname,channel))
                #liz=xbmcgui.ListItem(title, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
                liz=xbmcgui.ListItem(playername)
                liz.setInfo( type="Video", infoLabels={ "Title": playername} )
                liz.setProperty("IsPlayable","true")
                ###utils.logdev(module,'timeshiftfile= %s' % (timeshiftfile))
                liz.setPath(timeshiftfile)
                ###utils.logdev(module,'RecordTimeShift 0++++ file= %s liz= %s' % (repr(timeshiftfile), repr(liz)))
                ##xbmc.sleep(5000) ## Shows only theese 5 sec?
                count = 0
                countmax = int(ADDON.getSetting('timeshiftbuffer'))
                while count < countmax: 
                    xbmc.sleep(1000)
                    count += 1
                    utils.notification('Record TimeShift filling buffer: #%s %s (%s)' % (str(count),recordname,channel))
                ###playmedia(timeshiftfile)
            
            
                ##player = xbmc.Player()
                #for retry in range(0, 10):
                #       if player.isPlaying():
                #           break
                #       utils.notification('Record TimeShift Waiting: #%s %s (%s)' % (str(retry),recordname,channel))
                #       time.sleep( 1 )
                #       #xbmc.sleep(250)
                #xbmc.sleep(5000)
                ### int(sys.argv[1]) -- HANDLE
            
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
            
                #xbmc.executebuiltin("xbmc.PlayMedia("+timeshiftfile+")",True)
                ##while (xbmc.Player().isPlayingVideo() == True) and (not xbmc.abortRequested):
                ##  count += 1
                ##  #utils.notification('Record TimeShift Running: #%s %s (%s)' % (str(count),recordname,channel))
                ##  time.sleep( 1 )
                #utils.notification('Record TimeShift Ended: #%s %s (%s)' % (str(count),recordname,channel))
            
                ###utils.logdev('default.py: PLAY_STREAM','RecordTimeShift')
                liz=xbmcgui.ListItem(playername, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
                liz.setInfo( type="Video", infoLabels={ "Title": playername} )
                liz.setProperty("IsPlayable","true")
                liz.setPath(timeshiftfile)
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)  ### TimeShift - show timeshift recording
                
                ###utils.logdev('default.py','RecordTimeShift 0 file= %s' % repr(timeshiftfile))
                timeshiftfile = ADDON.getSetting('timeshiftfile')
                ###utils.logdev('default.py','RecordTimeShift 0+ file= %s' % repr(timeshiftfile))
                count = 0
                while timeshiftfile == '' and count < 10:
                    ###utils.logdev('default.py','RecordTimeShift 0++ file= %s' % repr(timeshiftfile))
                    time.sleep(1)
                    count += 1
                    timeshiftfile = ADDON.getSetting('timeshiftfile')
                    ###utils.logdev('default.py','RecordTimeShift count= %s' % repr(count))
                    ###utils.logdev('default.py','RecordTimeShift 0+++ file= %s' % repr(timeshiftfile))
                ###utils.logdev('default.py','RecordTimeShift count= %s' % repr(count))
                liz=xbmcgui.ListItem(playername, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
                liz.setInfo( type="Video", infoLabels={ "Title": playername} )
                liz.setProperty("IsPlayable","true")
                ###utils.logdev('default.py','timeshiftfile= %s' % (timeshiftfile))
                liz.setPath(timeshiftfile)
                ###utils.logdev('default.py','RecordTimeShift 0++++ file= %s' % repr(timeshiftfile))
            
                ##########################################################
                #item = xbmcgui.ListItem(path=timeshiftfile)
                datapath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
                playlist = os.path.join(datapath, 'TimeShift') + '.m3u'
                if os.path.isfile(playlist ) == False: 
                    LF = open(playlist , 'a')
                    LF.write('#EXTM3U \n')
                    LF.write(timeshiftfile + '\n')
                else:
                    LF = open(playlist , 'a')
                    LF.write(timeshiftfile + '\n')
                #printL('Play Video')
                #xbmcplugin.setResolvedUrl(HANDLE, timeshiftfile is not None, item)
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), timeshiftfile is not None, liz)
                
                if ADDON.getSetting('enable.subtitles') == 'true':
                    if video['SubtitlesUri']:
                    player = xbmc.Player()
                    for retry in range(0, 20):
                        if player.isPlaying():
                        break
                        xbmc.sleep(250)
                    xbmc.Player().setSubtitles(video['SubtitlesUri'])
                
                if os.path.isfile(timeshiftfile) == True: 
                    ###utils.logdev('default.py','RecordTimeShift 1')
                    ###xbmc.Player().play(timeshiftfile)
                    xbmc.executebuiltin("PlayMedia("+timeshiftfile+")")
                    ###xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)  ### TimeShift - show timeshift recording
                else:
                    ###utils.logdev('default.py','RecordTimeShift 2-')
                    time.sleep(1)
                    ###utils.logdev('default.py','RecordTimeShift 2')
                    ###xbmc.Player().play(timeshiftfile)
                    xbmc.executebuiltin("PlayMedia("+timeshiftfile+")")
                    ###xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)  ### TimeShift - show timeshift recording
                    #################################################################
                
            else:
                ###utils.logdev('default.py: PLAY_STREAM','No RecordTimeShift')
                liz=xbmcgui.ListItem(playername, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
                liz.setInfo( type="Video", infoLabels={ "Title": playername} )
                liz.setProperty("IsPlayable","true")
                liz.setPath(url)
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)  ### TimeShift - show timeshift recording
"""

def stoptimeshift():
        subprpid = xbmcgui.Window(10000).getProperty(ADDONname + 'subprpid')
        subprcmd = xbmcgui.Window(10000).getProperty(ADDONname + 'subprcmd')
        utils.logdev(module,'OldTimeShift to stop and reset subprpid= %r, subprcmd= %r' % (subprpid, subprcmd))
        if subprpid != '' and ADDON.getSetting('timeshiftbase') in subprcmd:
            utils.terminateSubpr(subprpid)
        try:
            xbmcgui.Window(10000).setProperty(ADDONname + 'subprpid', '')
            xbmcgui.Window(10000).setProperty(ADDONname + 'subprcmd', '')
        except Exception,e:
            pass
            utils.logdev(module,'OldTimeShift to stop and reset - Error \ncmd= %r\nError= %r' % (subprcmd,e))
def exit():
        xbmc.executebuiltin("Container.Update(path,replace)")
        xbmc.executebuiltin("ActivateWindow(Home)")

def EXIT():
    recordings.backupSetupxml()
    if locking.isAnyRecordLocked():
        locking.recordUnlockAll()
    if locking.isAnyScanLocked():
        locking.scanUnlockAll()
    if locking.isAnymarkLocked():
        locking.markUnlockAll()
    recordings.backupDataBase()
    ###recordings.stopAllRecordings()
        
def Record(recordname, uri, playpath,app):
    script   = os.path.join(ADDON.getAddonInfo('path'), 'recorduri.py')
    nameAlarm = ADDONid + '-Record-' + recordname
    try:
        if playpath == None:
            print 'No playpath'
        else:
            uri = uri + ' playpath=' + playpath
            print 'With playpath: uri= %s' % uri
    except:
        pass
    try:
        if app == None:
            print 'No app'
        else:
            uri = uri + ' app=' + app
            print 'With app: uri= %s' % uri
    except:
        pass
    cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),00:00:00,silent)' % (recordname.replace(',','####'), script, uri,recordname.replace(',','####'))
    print 'default.py: cmd= %s' % cmd
    xbmc.executebuiltin(cmd)  # Active
    
def Recordffmpeg(recordname, uri, playpath, app, description, auth, sourceApp):
    try:
        timeintervalbetweenrecordings = int(ADDON.getSetting('RecordingFromOtherAddonTimeInterval'))*60 
    except:
        pass
        timeintervalbetweenrecordings = 30 * 60  # Default 30 min
    utils.logdev(module, 'Recordffmpeg(recordname= %r, uri= %r, playpath= %r, app= %r, description= %r, auth= %r, sourceApp= %r)' % (recordname, uri, playpath, app, description, auth, sourceApp))
    script   = os.path.join(ADDON.getAddonInfo('path'), 'recorduriffmpeg.py') 
    ### Conversion at script!
    ### uri= sys.argv[1].replace('AAabBB',' ').replace('aAabBb','?').replace('BBabAA','=').replace('xXx',' ').replace('###',',').replace('AaAaA','=').replace('NlNlNl','\n')
    nowTS = int(time.mktime(datetime.now().timetuple()))
    utils.logdev(module,'nowTS= %r - %r' % (nowTS,time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(nowTS))))
    try:
        RecordingFromOtherAddon = recordings.ts(ADDON.getSetting('RecordingFromOtherAddon'))
    except:
        pass
        RecordingFromOtherAddon = nowTS - timeintervalbetweenrecordings  ### One hour ago
    utils.logdev(module,'RecordingFromOtherAddon= %r - %r' % (RecordingFromOtherAddon,time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(RecordingFromOtherAddon))))
    timesincelast = nowTS - RecordingFromOtherAddon
    if timesincelast > 0:
        utils.logdev(module,'timesincelast= %r - %r' % (timesincelast,time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(timesincelast))))
    else:
        utils.logdev(module,'timesincelast= %r' % (timesincelast))
    if timesincelast < timeintervalbetweenrecordings :
        RecordingFromOtherAddon += timeintervalbetweenrecordings
        ###ADDON.setSetting('RecordingFromOtherAddon',str(RecordingFromOtherAddon))
    else:
        RecordingFromOtherAddon = nowTS
        ###ADDON.setSetting('RecordingFromOtherAddon',str(nowTS))
    utils.logdev(module,'RecordingFromOtherAddon= %r - %r' % (RecordingFromOtherAddon,time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(RecordingFromOtherAddon))))
    #timestamp = 1226527167.595983
    #time_tuple = time.localtime(timestamp)
    #date_str = time.strftime("%Y-%m-%d %H:%M:%S", time_tuple)
    #timestamp = 1226527167.595983
    #dt_obj = datetime.datetime.utcfromtimestamp(timestamp)
    timedif = RecordingFromOtherAddon - nowTS
    utils.logdev(module,'timedif= %r, timedif/3600= %r, timedif/60= %r' % (timedif,timedif/3600,(timedif/60)%60))
    #StartRecordAt = time.strftime("%H:%M:%S",time.localtime(RecordingFromOtherAddon - nowTS))
    #str(starttimedelta/60) + ':' + str(starttimedelta%60) + ':00'
    StartRecordAt = '%02d:%02d:00' % (timedif/3600,(timedif/60)%60)   ### Ignore seconds
    utils.logdev(module,'StartRecordAt= %r' % StartRecordAt)
    qrecord = xbmcgui.Dialog()
    ###utils.notification('RecordFrom?: %r' % (sourceApp))
    if timedif > 0:
        arecord = qrecord.yesno(ADDON.getAddonInfo('name'),'Do you want to record? '+sourceApp, '[COLOR red]Start after: '+ StartRecordAt+ '[/COLOR]',recordname)
    else:
        arecord = qrecord.yesno(ADDON.getAddonInfo('name'),'Do you want to record? '+sourceApp, recordname, ' ')
    utils.logdev(module,'answer= %s' % repr(arecord))
    ###utils.notification('RecordFrom: %r' % (sourceApp))
    if not arecord:
        ### Recording not set - play 2018-11-06
        if sourceApp != '':
            try:
                RecordFlagSet(sourceApp,'False')
                utils.logdev(module,'RecordFlagSet False: %r' % (sourceApp))
                utils.notification('RecordFlagSet False: %r' % (sourceApp))
            except Exception,e:
                pass
                utils.notification('RecordFlagSet Failed: %r\n%r' % (sourceApp,e))
                utils.logdev(module,'RecordFlagSet Failed: %r\n%r' % (sourceApp,e))
    if arecord:
        ### Recording set - dont play 2018-11-06
        if sourceApp != '':
            try:
                RecordFlagSet(sourceApp,'True')
                utils.logdev(module,'RecordFlagSet True: %r' % (sourceApp))
                utils.notification('RecordFlagSet True: %r' % (sourceApp))
            except Exception,e:
                pass
                utils.notification('RecordFlagSet Failed: %r\n%r' % (sourceApp,e))
                utils.logdev(module,'RecordFlagSet Failed: %r\n%r' % (sourceApp,e))
        ADDON.setSetting('RecordingFromOtherAddon',recordings.humantime(RecordingFromOtherAddon))
        ###StartRecordAt = '00:00:00'   ### Ignore delay until it works 2018-05-22
        try:
            recordname50 = re.sub('[(,:\\/*?\<>|")]+', '', recordname)  ### Remove unwanted characters 2019-01-05
            recordname50 = recordname50[0:100].replace('[','').replace(']','')
            nameAlarm = ADDONid + '-Recordffmpeg-' + recordname50 ### 2019-01-05 limit length of nameAlarm
        except:
            pass
            nameAlarm = ADDONid+'-Recordffmpeg-missing-name'
        nameAlarm = recordings.latin1_to_ascii_force(nameAlarm) ### 2019-01-03
        ###nameAlarm = nameAlarm.replace(':','.').replace('/','').replace('[','').replace(']','').replace('&','.')
        nameAlarm = re.sub('[(,:\\/*?\<>|")]+', '', nameAlarm).replace('[','').replace(']','')   ### Remove unwanted characters 2019-01-05
        try:
            if not auth == None:
                uri += '?auth=' + auth
        except:
            pass
        Description = ''
        try:
            if description != None and description != '':
                uri += '&description=' + description
                Description = description.replace('AAabBB',' ').replace('aAabBb','?').replace('BBabAA','=').replace('###',',').replace('AaAaA','&').replace('NlNlNl','\n')
        except:
            pass
        try:
            if playpath != None and playpath != '':
                uri += ' playpath=' + playpath
        except:
            pass
        try:
            if app != None and app != '':
                uri += ' app=' + app
        except:
            pass
        startrecording = time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(RecordingFromOtherAddon))
        try:
            stoprecording = datetime.fromtimestamp(RecordingFromOtherAddon) + timedelta(minutes= int(ADDON.getSetting('RecordingFromOtherAddonTimeInterval')))
            ##stoprecording = time.strftime("%Y-%m-%d %H:%M:%S",stoprecording)
        except Exception,e:
            pass
            utils.logdev(module,'stoprecording Error: %r' % e)
            ### File "C:\Users\hans\AppData\Roaming\Kodi\addons\plugin.video.roqtv.rec\default.py", line 3516, in Recordffmpeg
            ### stoprecording = time.localtime(RecordingFromOtherAddon) + timedelta(minutes= 30)
            ### TypeError: can only concatenate tuple (not "datetime.timedelta") to tuple
            stoprecording = datetime.fromtimestamp(RecordingFromOtherAddon) + timedelta(minutes= 30)
            ##stoprecording = time.strftime("%Y-%m-%d %H:%M:%S",stoprecording)
        ### def addRecordingPlanned(cat, startDate, endDate, recordname, alarmname, description, playchannel, DB='default',uri='url')
        recordings.addRecordingPlanned(uri, startrecording, stoprecording, '[COLOR violet]' + recordname.replace(',','') + '[/COLOR]', nameAlarm, 'Record from VOD/Series or from other AddOn\n\n' + recordname + '\n\n' + Description, '', DB='default')
        ###recordings.add(cat, startDate, endDate, recordname, description)
        cmd = 'AlarmClock(%s,RunScript(%s,%s,%s,%s),%s,silent)' % (nameAlarm, script, uri, recordname.replace(',',''),nameAlarm,StartRecordAt)  ### 2017-08-05 + 2018-05-22
        utils.logdev(module, 'cmd= %s' % cmd)
        xbmc.executebuiltin(cmd)  # Active
    
def Recordffmpeguri(recordname, uri, duration, description):
    script   = os.path.join(ADDON.getAddonInfo('path'), 'recorduriffmpeg.py')
    utils.logdev(module,'Recordffmpeguri(recordname= %r\nuri= %r\nduration= %r\ndescription= %r' % (recordname, uri, duration, description))
    description = recordings.argumenttostring(description)  ### Remove ..NewLine.. etc
    ### Conversion at script!
    ### uri= sys.argv[1].replace('AAabBB',' ').replace('aAabBb','?').replace('BBabAA','=').replace('xXx',' ').replace('###',',').replace('AaAaA','=').replace('NlNlNl','\n')
    nowTS = int(time.mktime(datetime.now().timetuple()))
    utils.logdev(module,'nowTS= %r - %r' % (nowTS,time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(nowTS))))
    try:
        recordname50 = re.sub('[(,:\\/*?\<>|")]+', '', recordname) 
        recordname50 = recordname50[0:100].replace('[','').replace(']','')
        nameAlarm = ADDONid + '-Recordffmpeguri-' + recordname50 ### 2019-01-05 limit length of nameAlarm
    except:
        pass
        nameAlarm = ADDONid+'-Recordffmpeguri-missing-name'
    nameAlarm = recordings.latin1_to_ascii_force(nameAlarm) 
    nameAlarm = re.sub('[(,:\\/*?\<>|")]+', '', nameAlarm).replace('[','').replace(']','')   ### Remove unwanted characters 2019-01-05
    try:
        uri += '&duration=' + str(int(duration)/60)
    except Exception,e:
        pass
        uri += '&duration=120'  ### Default 2 hours
    Description = ''
    try:
        if description != None and description != '':
            uri += '&description=' + description
            Description = description.replace('AAabBB',' ').replace('aAabBb','?').replace('BBabAA','=').replace('###',',').replace('AaAaA','&').replace('NlNlNl','\n')
    except:
        pass
    startrecording = nowTS
    stoprecording = nowTS + int(duration)
    recordings.addRecordingPlanned(uri, startrecording, stoprecording, '[COLOR violet]' + recordname.replace(',','') + '[/COLOR]', nameAlarm, 'Record from AddOn\n\n' + recordname + '\n\n' + Description, '', DB='default')
    ###recordings.add(cat, startDate, endDate, recordname, description)
    cmd = 'AlarmClock(%s,RunScript(%s,%s,%s,%s),00:00:00,silent)' % (nameAlarm, script, uri, recordname.replace(',',''),nameAlarm)  
    utils.logdev(module, 'cmd= %s' % cmd)
    xbmc.executebuiltin(cmd)  # Active
        
def RecordTimeShift(name, uri, playpath,app,cat):
    utils.logdev(module, 'RecordTimeShift(name= %r, uri= %r, playpath= %r, app= %r, cat= %r)' % (name, uri, playpath,app,cat))
    script   = os.path.join(ADDON.getAddonInfo('path'), 'recordtimeshift.py')
    nameAlarm = ADDONid + '-record-timeshift-' + name
    try:
        if not playpath == None:
            uri = uri + ' playpath=' + playpath
    except:
        pass
    try:
        if not app == None:
            uri = uri + ' app=' + app
    except:
        pass
    cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),00:00:00,silent)' % (nameAlarm, script, uri, name)
    utils.logdev(module, 'cmd= %s' % cmd)
    xbmc.executebuiltin(cmd)  # Active
    
    #script   = os.path.join(ADDON.getAddonInfo('path'), 'recordtimeshiftshow.py')
    #nameAlarm = 'record-timeshift-show' + name
    #
    #cmd = 'AlarmClock(%s,RunScript(%s,%s,%s,%s,%s,%s),00:00:00,silent)' % (nameAlarm, script, uri, nameAlarm, sys.argv[1],name,cat)
    #print 'default.py: cmd= %s' % cmd
    #utils.logdev(module, 'cmd= %s' % cmd)
    #xbmc.executebuiltin(cmd)  # Active
    
def scheduleRecording(cat, startDate, endDate, recordname, description):
    if cat != 0 and cat != '0' and cat != '' and cat != None:   
        recordings.add(cat, startDate, endDate, recordname, description)

def delRecording(cat, startDate, endDate, recordname):
    recordings.delRecordingPlanned(cat, startDate, endDate, recordname)
    
def modifyRecording(cat, startDate, endDate, recordname, description):
    recordings.modifyRecordingPlanned(cat, startDate, endDate, recordname, description)

def getCaseInsensitivePath(path, RET_FOUND=False):
    '''
    Get a case insensitive path on a case sensitive system
    
    RET_FOUND is for internal use only, to avoid too many calls to os.path.exists
    # Example usage
    getCaseInsensitivePath('/hOmE/mE/sOmEpAtH.tXt')
    '''
    import os
    
    if path=='' or os.path.exists(path):
        if RET_FOUND:   ret = path, True
        else:           ret = path
        return ret
    
    f = os.path.basename(path) # f may be a directory or a file
    d = os.path.dirname(path)
    
    suffix = ''
    if not f: # dir ends with a slash?
        if len(d) < len(path):
            suffix = path[:len(path)-len(d)]

        f = os.path.basename(d)
        d = os.path.dirname(d)
    
    if not os.path.exists(d):
        d, found = getCaseInsensitivePath(d, True)
        
        if not found:
            if RET_FOUND:   ret = path, False
            else:           ret = path
            return ret
    
    # at this point, the directory exists but not the file
    
    try: # we are expecting 'd' to be a directory, but it could be a file
        files = os.listdir(d)
    except:
        if RET_FOUND:   ret = path, False
        else:           ret = path
        return ret
    
    f_low = f.lower()
    
    try:    f_nocase = [fl for fl in files if fl.lower() == f_low][0]
    except: f_nocase = None
    
    if f_nocase:
        if RET_FOUND:   ret = os.path.join(d, f_nocase) + suffix, True
        else:           ret = os.path.join(d, f_nocase) + suffix
        return ret
    else:
        if RET_FOUND:   ret = path, False
        else:           ret = path
        return ret # cant find the right one, just return the path as is.
    
def isExtKnown(infile):
    ffmpegoutputtype = ADDON.getSetting('ffmpegoutputtype').lower()
    infileext = infile.lower().rsplit('.',1)[-1]
    utils.logdev(module,'infileext= %r, ffmpegoutputtype= %r' % (infileext, ffmpegoutputtype))
    if infileext == ffmpegoutputtype:
        return True
    extorgcollection = ADDON.getSetting('extorgcollection').lower().split(',')
    if infileext in extorgcollection:
    ###if infile[-3:].lower()=='.ts' or infile[-4:].lower()=='.mp4' or infile[-4:].lower()=='.mkv' or infile[-4:].lower()== '.avi' or infile[-4:].lower() == '.m4v' or infile[-4:].lower()=='.flv' or infile[-ffmpegoutputtypelen:].lower()==ffmpegoutputtype:
        return True
    else:
        return False

def ScanFiles(c,folderPath,Archive):
    for infile in find_files(folderPath, '*'):
        try:
            fileext = ''
            fileextt = ''
            if '.' in infile:
                fileext = infile.split('.')[-1]
                fileextt = '.' + fileext
        except Exception,e:
            pass
            fileext = repr(e)
            fileextt = fileext
        infilebasename = os.path.basename(infile).replace(fileextt,'',-1) # the file name only
        if len(folderPath)>0:
            pathoffile = os.path.dirname(infile).replace(folderPath[:-1],'',1)
            if len(pathoffile) >0:
                pathoffile = pathoffile[1:]
        else:
            pathoffile = ''
        video = repr(isExtKnown(infile))
        descriptionfilename = infile.replace(fileextt,'.txt',-1)
        if video == 'True' and os.path.isfile(descriptionfilename):
            try:               ### Description:
                descf = open(descriptionfilename,'r')
                desc = descf.read()
                descf.close()
                description = 'Description:\n' + desc.split('Description:')[1]
                ###utils.logdev(module,'desc= ' + repr(desc))
            except Exception,e: 
                pass
                description = ''
                utils.logdev(module,'description ERROR= ' + repr(e))
        else:
            description = ''
        utils.logdev(module,'infile= %r, infilebasename= %r' % (infile, infilebasename))
        utils.logdev(module,'pathoffile= %r, folderPath= %r,  os.path.dirname(infile)= %r' % (pathoffile, folderPath, os.path.dirname(infile)))
        recordings.addFile(c, infilebasename, fileext, pathoffile, video, description, repr(os.stat(infile).st_size), Archive)  ### Archive/Local
        
def ScanRecordings():
    GoHome('Scan Recordings')
    conf = recordings.getFilesConnection()
    recordings.createFileTable(conf)
    c = conf.cursor()
    recordPath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_path')))
    ScanFiles(c,recordPath,'L')
    conf.commit()
    if ADDON.getSetting('record_archive_path_enable') == 'true':
        recordArchivePath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_archive_path')))
        ScanFiles(c,recordArchivePath,'A')
        conf.commit()
    c.close()  

def DOWNLOADS(view):
    GoHome('Recordings')
    path = recordDisplayPath
    searchcount = 0
    searchcountmax = int(ADDON.getSetting('searchcountmax'))
    searchtimemax = int(ADDON.getSetting('searchtimemax')) ### seconds
    searchtimereached = False
    
    ##name = 'Local Video Archive'
    ##addDir('Recordings searched: '+searchText,'url',6,'','','','All recorded items in ' + recordPath)
    ##addDir(name,'url',66,'',recordArchivePath,'','Local Video Archive in ' + recordArchivePath)
    ###liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage="DefaultFolder.png")
    ###liz.setInfo( type="Folder", infoLabels={ "Title": str(name), "Plot":"PLOT", "Category":"CATEGORY" } )
    ###liz.setProperty("IsPlayable","false")
    ###contextMenu = []
    ###liz.addContextMenuItems(contextMenu,replaceItems=True)
    ###xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url=infile,listitem = liz, isFolder = True)
    if view == '2060':
        sortmethod = ': Sorted by file date '
    elif view == '2065':
        sortmethod = ': Search in Database '
    elif view == '66' or view == '6':
        if ADDON.getSetting('sortalphabetic') == 'true':
            sortmethod = ': Sorted alphabetically '
        else:
            sortmethod = ': Sorted by file date '
    elif view == '67':
        sortmethod = ': Search in Descriptions '
    else:
        sortmethod = ': ' + view
    
    searchText = SearchEPG('Recording to search for'+sortmethod)   ### 2018-10-03 Search starts empty - SearchEPG search same as last
    if not searchText == False :
        nowM = datetime.today()
        nowJust = nowM
        searchPath = 'All recorded items in[CR]' + path
        searchPath2060 = searchPath
        searchPathLocal = searchPath
        if recordArchivePath != '' and not view == '2060':
            searchPath += '[CR][CR]and[CR]' + recordArchivePath
        if recordArchivePath != '':
            searchPath2060 += '[CR][CR]and[CR]' + recordArchivePath
        searchPath = searchPath.replace('/','/ ').replace('\\','\\ ')
        searchPath2060 = searchPath2060.replace('/','/ ').replace('\\','\\ ')
        if view == '2060' or view == '66':
            sortmethod = '[CR][CR]Sorted by file date '
        if view == '6':
            sortmethod = '[CR][CR]Sorted alphabetically '
        if view == '67':
            sortmethod = '[CR][CR]Search in Descriptions '
        if view == '2065':
            sortmethod = '[CR][CR]Search in Database '
        if view == '2060' or view == '67' or view == '66' or view == '2065':
            addDir('Change sort method to: Sorted alphabetically','url',6,'','','',searchPath2060 + '[CR][CR]If you want episode 98 of Midsomer Murders, you can seek: midsom%98[CR][CR]Note! Search is NOT case sensitive')
        if view == '67' or view == '6' or view == '2065':
            addDir('Change sort method to: Sorted by file date','url',66,'','','',searchPath + '[CR][CR]If you want episode 98 of Midsomer Murders, you can seek: midsom%98[CR][CR]Note! Search is NOT case sensitive')
        if view == '2060' or view == '67' or view == '66' or view == '6':
            addDir('Change sort method to: Search in Database','url',2065,'','','','Search in local database with local and archive files' + '[CR][CR]If you want episode 98 of Midsomer Murders, you can seek: midsom%98[CR][CR]To search in local recordings include l:[CR]To search in archive recordings include a:[CR]To search in recordings with pending commands include c:[CR]To sort by duration include d:[CR]To sort by series/episode include s:[CR][CR]Note! Search is NOT case sensitive')
        addDir('Execute Commands and Update File Database','url',2070,'','','','[I][COLOR grey]Execute Commands and then Scan through Recorded files and the Archive [/COLOR][/I]\n\nPlease wait')
        if view == '67':
            addDir('Recordings searched: [B]'+searchText+'[/B]\n[I][COLOR grey]'+sortmethod.replace('[CR]','')+'[/COLOR][/I]','url',int(view),'','','',searchPath + '[CR][CR]Note! Search is NOT case sensitive'+sortmethod)
        else:
            if view == '2065':
                searchPathDB = 'Search in local database with local and archive files[CR][CR]To search in local recordings include l:[CR]To search in archive recordings include a:[CR]To search in recordings with pending commands include c:[CR]To sort by duration include d:[CR]To sort by series/episode include s:[CR]To sort by description include t:'
            else:
                searchPathDB = searchPath
            addDir('Search in Descriptions','url',67,'','','',searchPath2060 + '[CR][CR]Note! Search is NOT case sensitive')
            addDir('Recordings searched: [B]'+searchText+'[/B]\n[I][COLOR grey]'+sortmethod.replace('[CR]','')+'[/COLOR][/I]','url',int(view),'','','',searchPathDB + '[CR][CR]If you want episode 98 of Midsomer Murders, you can seek: midsom%98[CR][CR]Note! Search is NOT case sensitive'+sortmethod)
        
        files = []
        filecount = 0
        filecountmax = int(ADDON.getSetting('searchcountmax'))
        filesallA = []
        
        if view == '2065': ### Search in database
            utils.logdev(module,'View 2065')
            archive = ''
            command = ''
            duration= ''
            if 'archive:' in searchText or 'a:' in searchText or 'A:' in searchText:
                archive = 'A'
                searchText = searchText.replace('archive:','').replace('a:','').replace('A:','')
            if 'local:' in searchText or 'l:' in searchText or 'L:' in searchText:
                archive = 'L'
                searchText = searchText.replace('local:','').replace('l:','').replace('L:','')
            if 'command:' in searchText or 'c:' in searchText or 'C:' in searchText:
                command = 'C'
                searchText = searchText.replace('command:','').replace('c:','').replace('C:','')
            if 'duration:' in searchText or 'd:' in searchText or 'D:' in searchText:
                duration = 'D'
                searchText = searchText.replace('duration:','').replace('d:','').replace('D:','')
            if 'series:' in searchText or 's:' in searchText or 'S:' in searchText:
                duration = 'S'
                searchText = searchText.replace('series:','').replace('s:','').replace('S:','')
            if 'text:' in searchText or 't:' in searchText or 'T:' in searchText:
                duration = 'T'
                searchText = searchText.replace('text:','').replace('t:','').replace('T:','')
            conf = recordings.getFilesConnection()
            recordings.createFileTable(conf)
            c = conf.cursor()
            if duration == 'T':
                c.execute("SELECT * FROM files WHERE description like ? AND video = 'True' COLLATE NOCASE", ['%'+searchText+'%'])              
            elif archive != '' and command != '':
                c.execute("SELECT * FROM files WHERE filename like ? AND video = 'True' AND archive=? AND NOT command=? COLLATE NOCASE", ['%'+searchText+'%',archive,''])  
            elif archive == '' and command != '':
                c.execute("SELECT * FROM files WHERE filename like ? AND video = 'True' AND NOT command=? COLLATE NOCASE", ['%'+searchText+'%',''])  
            elif archive != '' and command == '':
                c.execute("SELECT * FROM files WHERE filename like ? AND video = 'True' AND archive=? COLLATE NOCASE", ['%'+searchText+'%',archive])  
            else:
                c.execute("SELECT * FROM files WHERE filename like ? AND video = 'True' COLLATE NOCASE", ['%'+searchText+'%']) 
            channels = c.fetchall()
            if duration == 'D':
                utils.logdev(module,'Duration Mode')
                channelsarray = []
                for chan in channels:
                    size = chan[5].split('\n')[-1].split(' ')[-1]
                    if 'm' in size:
                        Length = int(size.split('m')[0])
                    else:
                        Length = 0
                    if Length != 0:
                        channelsarray.append([Length,chan])
                channelsarray = sorted(channelsarray, key=itemgetter(0))
                utils.logdev(module,'channelsarray= %r' % channelsarray)
            elif duration == 'S':
                utils.logdev(module,'SeriesEppisode Mode')
                channelsarray = []
                for chan in channels:
                    try:
                        utils.logdev(module,'chan[0]= %r' % chan[0])
                        SE = re.findall(r'S(\d+)E(\d+)', chan[0])
                        utils.logdev(module,'SE= %r' % SE)
                        ### chan[0]= 'Kriminalkommissaer-Barnaby S0E113[DR NU] [2018-01-20 23-02 ROQ TV Rec]'
                        ### SE= [('0', '113')]
                        Length = int(SE[0][0])*1000 + int(SE[0][1])
                        utils.logdev(module,'Length= %r' % Length)
                        channelsarray.append([Length,chan])
                    except Exception,e:
                        pass
                        utils.logdev(module,'SeriesEppisode Error: %r' % e)
                channelsarray = sorted(channelsarray, key=itemgetter(0))
                utils.logdev(module,'channelsarray= %r' % channelsarray)
            else:
                channels = sorted(channels, key=itemgetter(7), reverse=True)
                channels = sorted(channels, key=itemgetter(0))
                channelsarray = []
                Length = 0
                for chan in channels:
                    channelsarray.append([Length,chan])
                utils.logdev(module,'channelsarray= %r' % channelsarray)
            
            ### 0 filename, 1 ext, 2 path, 3 video, 4 description, 5 size, 6 archive, 7 updated, 8 created, 9 updatedHumanTime, 10 command, 11 options
            channelsarrayList = 'Last Action Performed: ' + ADDON.getSetting('lastdatabaseaction')
            utils.logdev(module,'channelsarrayList= %r' % channelsarrayList)
            for chan in channelsarray:
                channelsarrayList +=  '#'+chan[1][0] +'%'+chan[1][1] +'%'+chan[1][2] +'%'+chan[1][6]
                utils.logdev(module,'channelsarrayList= %r' % channelsarrayList)
            for chan in channelsarray:
                ### chan[y] --> chan[1][y]
            ###channels = channelsarray[1]
            ###for chan in channels:
                name = chan[1][0]
                
                utils.logdev(module,'name[:1]=1 %r' % name[:1])
                if name[:1] == '[':   ### 2019-03-09
                    nameparts = name.split(']',1)
                    name = nameparts[1] + ' ' + nameparts[0] + ']'
                    name = name.strip()
                Duration = chan[0]
                if Duration > 0 and duration == 'D':
                    Duration = ' ' + str(Duration) + 'm'
                elif Duration > 0 and duration == 'S':
                    Duration = ' S' + str(Duration/1000) + 'E' + str(Duration%1000)
                else:
                    Duration = ''
                """
                try:
                    Duration = name.split('[',1)[1].split(']',1)[0]
                    if not 'h' in Duration or not 'm' in Duration:
                        Duration = name.split(']')[-2].split('[')[-1].split(' ')[-1]
                        if not 'h' in Duration or not 'm' in Duration:
                            Duration = ''
                except Exception,e:
                    pass
                    utils.logdev(module,'Duration ERROR: %r' % e)
                    Duration = ''
                Length = 0
                if Duration != '':
                    Length = int(Duration.split('h')[0])*60 + int(Duration.split('h')[1].split('m')[0])
                """
                if chan[1][11] != '' and '[' in name:
                    if '[' in chan[1][11]:
                        name = chan[1][11]  ### Show pending command
                    name = '[B]' + name.replace('[','[/B]'+Duration+'\n[COLOR lightcoral][I]'+ 'Pending: ' + chan[1][10] +' ' +chan[1][6]+' [',1) + '[/I][/COLOR]'
                    name = name.split('\n')
                    line1 = name[0]
                    lenline1 = len(line1)
                    line2 = name[1]
                    lenline2 = len(line2)
                    if lenline1 < lenline2:
                        line1 = line1 + ' ' * (lenline2 - lenline1 - 16)
                    name = line1 +'\n' + line2    ### +'.'+ str(lenline1)+'.'+ str(lenline2)
                elif chan[1][11] != '' and not '[' in name:
                    name = chan[1][11]  ### Show pending command
                    name = '[B]' + chan[1][11] +'[/B]'+Duration+'\n[COLOR lightcoral][I]'+ 'Pending: ' + chan[1][10] +' ' +chan[1][6]+'[/I][/COLOR]'
                    name = name.split('\n')
                    line1 = name[0]
                    lenline1 = len(line1)
                    line2 = name[1]
                    lenline2 = len(line2)
                    if lenline1 < lenline2:
                        line1 = line1 + ' ' * (lenline2 - lenline1 - 16)
                    name = line1 +'\n' + line2    ### +'.'+ str(lenline1)+'.'+ str(lenline2)
                elif chan[1][11] == '' and '[' in name:
                    name = '[B]' + name.replace('[','[/B]'+Duration+'\n[COLOR lemonchiffon][I]' +chan[1][6]+' [',1) + '[/I][/COLOR]'
                    name = name.split('\n')
                    line1 = name[0]
                    lenline1 = len(line1)
                    line2 = name[1]
                    lenline2 = len(line2)
                    if lenline1 < lenline2:
                        line1 = line1 + ' ' * (lenline2 - lenline1 - 16)
                    name = line1 +'\n' + line2    ### +'.'+ str(lenline1)+'.'+ str(lenline2)
                else:
                    name = '[B]' + chan[1][0] + '[/B]'+Duration+'\n[COLOR lemonchiffon][I]' +chan[1][6]+'[/I][/COLOR]'
                liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage="DefaultVideo.png")
                liz.setInfo( type="Video", infoLabels={ "Title": chan[1][0], "Plot":"Last updated: " + chan[1][9]+"\nArchive: " + chan[1][6]+"\nPath: "  +chan[1][2]+"\nExtension: " +chan[1][1]+"\n"+chan[1][5]+'\n\n'+chan[1][4], "Category":chan[1][3]})
                liz.setProperty("IsPlayable","true")
                contextMenu = []
                contextMenu.append(('[COLOR yellow][B]Home[/B][/COLOR]','XBMC.Container.Update(%s?name=Home&mode=None&url=None&iconimage=None&cat=None)'% (sys.argv[0])))
                contextMenu.append(('[COLOR orange][B]Rename[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=1023&url=%s&name=%s&recordname=%s&description=%s)'% (sys.argv[0], chan[1][0], chan[1][6], chan[1][1], chan[1][2])))
                if chan[1][6] == 'A':
                    contextMenu.append(('[COLOR orange][B]Move from Archive[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=1024&url=%s&name=%s&recordname=%s&description=%s)'% (sys.argv[0], chan[1][0], chan[1][6], chan[1][1], chan[1][2])))
                else:
                    contextMenu.append(('[COLOR orange][B]Move to Archive[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=1024&url=%s&name=%s&recordname=%s&description=%s)'% (sys.argv[0], chan[1][0], chan[1][6], chan[1][1], chan[1][2])))
                contextMenu.append(('[COLOR orange][B]Move to Folder[/B][/COLOR]', 
                'XBMC.RunPlugin(%s?mode=1028&url=%s&name=%s&recordname=%s&description=%s)'% (sys.argv[0], chan[1][0], chan[1][6], chan[1][1], chan[1][2])))
                contextMenu.append(('[COLOR orange][B]Delete[/B][/COLOR]', 
                'XBMC.RunPlugin(%s?mode=1026&url=%s&name=%s&recordname=%s&description=%s)'% (sys.argv[0], chan[1][0], chan[1][6], chan[1][1], chan[1][2])))
                contextMenu.append(('[COLOR orange][B]Clear Command[/B][/COLOR]', 
                'XBMC.RunPlugin(%s?mode=1027&url=%s&name=%s&recordname=%s&description=%s)'% (sys.argv[0], chan[1][0], chan[1][6], chan[1][1], chan[1][2])))
                contextMenu.append(('[COLOR orange][B]Multiselect[/B][/COLOR]', 
                'XBMC.RunPlugin(%s?mode=1031&url=%s&name=%s&recordname=%s&description=%s)'% (sys.argv[0], channelsarrayList, chan[1][6], chan[1][1], chan[1][2])))
                contextMenu.append(('[COLOR orange][B]Execute/Update Database[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=1025&url=%s&name=%s&recordname=%s&description=%s)'% (sys.argv[0], chan[1][0], chan[1][6], chan[1][1], chan[1][2])))
                ###default.py: Just before commands: (cat= None, mode= 1023, url= 'Kriminalkommissaer Barnaby XVIII [1h30m][TV-Serie. Programmer] . (Midsomer Murders) (S0E108) (2016) [2019-02-27 15-19 DR1 (D)]', startDate= None, endDate= None, name= 'A', recordname= '', description= None)
                if chromecast: 
                    if chan[1][6] == 'A':
                        infile = os.path.join(os.path.join(recordArchivePath,chan[1][2]),chan[1][0]+'.'+chan[1][1])
                    else:
                        infile = os.path.join(os.path.join(path,chan[1][2]),chan[1][0]+'.'+chan[1][1])
                    contextMenu.append(('[COLOR orange][B]Cast to first ChromeCast[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=1041&url=%s)'% (sys.argv[0], infile)))
                    contextMenu.append(('[COLOR orange][B]Stop Cast[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=1042&url=%s)'% (sys.argv[0], infile)))
                contextMenu.append(('[COLOR lightgreen][B]Search Again[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=%s&url=url&iconimage=None&cat=0)'% (sys.argv[0],view)))
                contextMenu.append(('[COLOR lightgreen][B]Search Channels/VOD[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=2008&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                contextMenu.append(('[COLOR lightgreen][B]Search EPG Programs[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=2050&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                contextMenu.append(('[COLOR lightgreen][B]Search Recorded[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=%s&url=None&iconimage=None&cat=%s)'% (sys.argv[0],view,cat)))
                contextMenu.append(('[COLOR red][B]Planned Recordings[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=3&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                contextMenu.append(('[COLOR orange][B]Favorites[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=17&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                liz.addContextMenuItems(contextMenu,replaceItems=True)
                if chan[1][6] == 'A':
                    url = os.path.join(os.path.join(recordArchivePath,chan[1][2]),chan[1][0]+'.'+chan[1][1])
                else:
                    url = os.path.join(os.path.join(path,chan[1][2]),chan[1][0]+'.'+chan[1][1])
                utils.logdev(module,'Database Search url= %r' % url)
                xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url=url,listitem = liz, isFolder = False)
            c.close()
            
        elif view == '67': ### search descriptions
            for descfile in find_files(path,'*.txt'):
                if os.path.isfile(descfile):
                    try:               ### Description:
                        descf = open(descfile,'r')
                        desc = descf.read()
                        descf.close()
                        desc = desc.split('Description:')[1]
                        ###utils.logdev(module,'desc= ' + repr(desc))
                    except Exception,e: 
                        pass
                        desc = ''
                        utils.logdev(module,'desc ERROR= ' + repr(e))
                if searchText.lower() in desc.lower():
                    ###addDir(descfile,'url',67,'','','',desc)
                    ###descfilename = os.path.basename(descfile).replace('.txt','.*').replace('[','*').replace(']','*').replace('(','*').replace(')','*')
                    descfilename = descfile.replace('.txt','.*').replace('[','*').replace(']','*').replace('(','*').replace(')','*')
                    ###dialog = xbmcgui.Dialog()
                    ###dialog.ok(ADDON.getAddonInfo('name'), 'Fundet i description:', descfilename)
                    vodfiles = glob.glob(descfilename)
                    ###dialog.ok(ADDON.getAddonInfo('name'), 'Fundet i description:', repr(vodfiles))
                    for vodfile in vodfiles:
                        if isExtKnown(vodfile):
                            ###addDir(os.path.basename(vodfile),'url',67,'','','',desc)
                            liz=xbmcgui.ListItem(os.path.basename(vodfile), iconImage="DefaultVideo.png", thumbnailImage="DefaultVideo.png")
                            liz.setInfo( type="Video", infoLabels={ "Title": os.path.basename(vodfile).replace('/','/ ').replace('\\','\\ '), "Plot":desc, "Category":desc})
                            liz.setProperty("IsPlayable","true")
                            contextMenu = []
                            contextMenu.append(('[COLOR yellow][B]Home[/B][/COLOR]','XBMC.Container.Update(%s?name=Home&mode=None&url=None&iconimage=None&cat=None)'% (sys.argv[0])))
                            ###contextMenu.append(('[COLOR orange][B]Rename[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=1023&url=%s&name=%s)'% (sys.argv[0], vodfile,'L')))
                            contextMenu.append(('[COLOR lightgreen][B]Search Again[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=%s&url=url&iconimage=None&cat=0)'% (sys.argv[0],view)))
                            contextMenu.append(('[COLOR lightgreen][B]Search Channels/VOD[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=2008&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                            contextMenu.append(('[COLOR lightgreen][B]Search EPG Programs[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=2050&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                            contextMenu.append(('[COLOR lightgreen][B]Search Recorded[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=%s&url=None&iconimage=None&cat=%s)'% (sys.argv[0],view,cat)))
                            contextMenu.append(('[COLOR red][B]Planned Recordings[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=3&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                            contextMenu.append(('[COLOR orange][B]Favorites[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=17&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                            liz.addContextMenuItems(contextMenu,replaceItems=True)
                            xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url=vodfile,listitem = liz, isFolder = False)
            
            for descfile in find_files(recordArchivePath, '*.txt'):
                if os.path.isfile(descfile):
                    try:               ### Description:
                        descf = open(descfile,'r')
                        desc = descf.read()
                        descf.close()
                        desc = desc.split('Description:')[1]
                        ###utils.logdev(module,'desc= ' + repr(desc))
                    except Exception,e: 
                        pass
                        desc = ''
                        utils.logdev(module,'desc ERROR= ' + repr(e))
                if searchText.lower() in desc.lower():
                    ###addDir(descfile,'url',67,'','','',desc)
                    ###descfilename = os.path.basename(descfile).replace('.txt','.*').replace('[','*').replace(']','*').replace('(','*').replace(')','*')
                    descfilename = descfile.replace('.txt','.*').replace('[','*').replace(']','*').replace('(','*').replace(')','*')
                    ###dialog = xbmcgui.Dialog()
                    ###dialog.ok(ADDON.getAddonInfo('name'), 'Fundet i description:', descfilename)
                    vodfiles = glob.glob(descfilename)
                    ###dialog.ok(ADDON.getAddonInfo('name'), 'Fundet i description:', repr(vodfiles))
                    for vodfile in vodfiles:
                        if isExtKnown(vodfile):
                            ###addDir(os.path.basename(vodfile),'url',67,'','','',desc)
                            liz=xbmcgui.ListItem(os.path.basename(vodfile), iconImage="DefaultVideo.png", thumbnailImage="DefaultVideo.png")
                            liz.setInfo( type="Video", infoLabels={ "Title": os.path.basename(vodfile).replace('/','/ ').replace('\\','\\ '), "Plot":desc, "Category":desc})
                            liz.setProperty("IsPlayable","true")
                            contextMenu = []
                            contextMenu.append(('[COLOR yellow][B]Home[/B][/COLOR]','XBMC.Container.Update(%s?name=Home&mode=None&url=None&iconimage=None&cat=None)'% (sys.argv[0])))
                            ###contextMenu.append(('[COLOR orange][B]Rename[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=1023&url=%s&name=%s)'% (sys.argv[0], vodfile,'A')))
                            contextMenu.append(('[COLOR lightgreen][B]Search Again[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=%s&url=url&iconimage=None&cat=0)'% (sys.argv[0],view)))
                            contextMenu.append(('[COLOR lightgreen][B]Search Channels/VOD[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=2008&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                            contextMenu.append(('[COLOR lightgreen][B]Search EPG Programs[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=2050&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                            contextMenu.append(('[COLOR lightgreen][B]Search Recorded[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=%s&url=None&iconimage=None&cat=%s)'% (sys.argv[0],view,cat)))
                            contextMenu.append(('[COLOR red][B]Planned Recordings[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=3&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                            contextMenu.append(('[COLOR orange][B]Favorites[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=17&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                            
                            liz.addContextMenuItems(contextMenu,replaceItems=True)
                            xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url=vodfile,listitem = liz, isFolder = False)
            
        else:
            ###conf = recordings.getFilesConnection()
            ###recordings.createFileTable(conf)
            ###c = conf.cursor()
            for infile in find_files(path, '*'):
                filesallA.append([infile,infile.lower()])
            """
                try:
                    fileext = ''
                    fileextt = ''
                    if '.' in infile:
                        fileext = infile.split('.')[-1]
                        fileextt = '.' + fileext
                except Exception,e:
                    pass
                    fileext = repr(e)
                    fileextt = fileext
                infilebasename = os.path.basename(infile).replace(fileextt,'',-1) # the file name only
                pathoffile = os.path.dirname(infile).replace(path[:-1],'',1)
                if len(path)>0:
                    pathoffile = os.path.dirname(infile).replace(path[:-1],'',1)
                    if len(pathoffile) >0:
                        pathoffile = pathoffile[1:]
                else:
                    pathoffile = ''
                video = repr(isExtKnown(infile))
                descriptionfilename = infile.replace(fileextt,'.txt',-1)
                if video == 'True' and os.path.isfile(descriptionfilename):
                    try:               ### Description:
                        descf = open(descriptionfilename,'r')
                        desc = descf.read()
                        descf.close()
                        description = 'Description:\n' + desc.split('Description:')[1]
                        ###utils.logdev(module,'desc= ' + repr(desc))
                    except Exception,e: 
                        pass
                        description = ''
                        utils.logdev(module,'description ERROR= ' + repr(e))
                else:
                    description = ''
                utils.logdev(module,'infile= %r, infilebasename= %r' % (infile, infilebasename))
                utils.logdev(module,'pathoffile= %r, path= %r,  os.path.dirname(infile)= %r' % (pathoffile, path, os.path.dirname(infile)))
                recordings.addFile(c, infilebasename, fileext, pathoffile, video, description, repr(os.stat(infile).st_size), 'L')  ### No archive
            conf.commit()
            c.close()
            """
            for infileA in filesallA:
                infile = infileA[0]
                if isExtKnown(infile):
                    searchTextA = searchText.lower().split('%')
                    ###utils.logdev(module,'searchTextA= %r' % searchTextA)
                    hit    = 0
                    hits   = 0
                    hitall = len(searchTextA)
                    ###utils.logdev(module,'***hitall= %r' % (hitall))
                    for searchTextB in searchTextA:
                        ###utils.logdev(module,'searchTextB= %r' % searchTextB)
                        hits += 1
                        if searchTextB in infileA[1]:
                            hit += 1
                            ###utils.logdev(module,'hit= %r, hits= %r' % (hit,hits))
                    if hit == hitall and hit > 0 and not searchtimereached:
                        nowJust = datetime.today()
                        if nowJust > nowM + timedelta(seconds = searchtimemax):
                            if not searchtimereached:
                                ###addDir('[COLOR red][B]Search time reached ('+str(searchtimemax)+' seconds)[/B][/COLOR]' ,'',0,'','0','0','Limit your search!\n\nClick to change limit','0','0','')
                                searchtimereached = True
                        if filecount < filecountmax and not searchtimereached:
                            utils.logdev(module,'Search filename= %r' % infile)
                            ###name = infile.replace(recordPath,'',1).replace(recordArchivePath,'',1)
                            try:
                                name = infile.replace('/','¤').replace('\\','¤').split('¤')[-1]
                            except Exception,e:
                                pass
                                name = repr(e)
                            filecount += 1
                            usedtime = str(int((nowJust-nowM).total_seconds()))
                            utils.logdev(module, 'filecount= %r, nowM= %r, nowJust= %r, usedtime= %r, searchtimereached= %r' % (filecount, nowM, nowJust, usedtime, searchtimereached))
                            files.append([name,infile,int(os.path.getmtime(infile))])
            
            ###if filecount < filecountmax and not searchtimereached:
            if filecount < filecountmax and not searchtimereached and not view == '2060':  ### Latest recordings only from local store
                #filesA =  glob.glob(os.path.join(recordArchivePath, '*'))
                filesallA = []
                #for infile in filesA:
                ###conf = recordings.getFilesConnection()
                ###recordings.createFileTable(conf)
                ###c = conf.cursor()
                for infile in find_files(recordArchivePath, '*'):
                    filesallA.append([infile,infile.lower()])
                """    try:
                        fileext = ''
                        fileextt = ''
                        if '.' in infile:
                            fileext = infile.split('.')[-1]
                            fileextt = '.' + fileext
                    except Exception,e:
                        pass
                        fileext = repr(e)
                        fileextt = fileext
                    infilebasename = os.path.basename(infile).replace(fileextt,'',-1) # the file name only
                    if len(recordArchivePath)>0:
                        pathoffile = os.path.dirname(infile).replace(recordArchivePath[:-1],'',1)
                        if len(pathoffile) >0:
                            pathoffile = pathoffile[1:]
                    else:
                        pathoffile = ''
                    utils.logdev(module,'infile= %r, infilebasename= %r' % (infile, infilebasename))
                    utils.logdev(module,'pathoffile= %r, recordArchivePath= %r' % (pathoffile, recordArchivePath))
                    video = repr(isExtKnown(infile))
                    descriptionfilename = infile.replace(fileextt,'.txt',-1)
                    if video == 'True' and os.path.isfile(descriptionfilename):
                        try:               ### Description:
                            descf = open(descriptionfilename,'r')
                            desc = descf.read()
                            descf.close()
                            description = 'Description:\n' + desc.split('Description:')[1]
                            ###utils.logdev(module,'desc= ' + repr(desc))
                        except Exception,e: 
                            pass
                            description = ''
                            utils.logdev(module,'description ERROR= ' + repr(e))
                    else:
                        description = ''
                    recordings.addFile(c, infilebasename, fileext, pathoffile, video, description, repr(os.stat(infile).st_size), 'A')  ### archive
                conf.commit()
                c.close()
                """
                ###for infile in find_files(recordArchivePath, '*'):
                ###    filesallA.append([infile,infile.lower()])
                for infileA in filesallA:
                    infile = infileA[0]
                    ###if not infile[-4:].lower()=='.zip' and not infile[-4:].lower()=='.txt' and not infile[-4:].lower()=='.srt' and not infile[-4:].lower()=='.ini' and not infile[-4:].lower()=='.nfo' and not infile[-4:].lower()=='.log':
                    if isExtKnown(infile):
                    ###if infile[-3:].lower()=='.ts' or infile[-4:].lower()=='.mp4'  or infile[-4:].lower()=='.mkv' or infile[-4:].lower()== '.avi' or infile[-4:].lower() == '.m4v' or infile[-4:].lower()=='.flv' or infile[-ffmpegoutputtypelen:].lower()==ffmpegoutputtype:
                        searchTextA = searchText.lower().split('%')
                        ###utils.logdev(module,'searchTextA= %r' % searchTextA)
                        hit    = 0
                        hits   = 0
                        hitall = len(searchTextA)
                        ###utils.logdev(module,'***hitall= %r' % (hitall))
                        for searchTextB in searchTextA:
                            ###utils.logdev(module,'searchTextB= %r' % searchTextB)
                            hits += 1
                            if searchTextB in infileA[1]:
                                hit += 1
                                ###utils.logdev(module,'hit= %r, hits= %r' % (hit,hits))
                        if hit == hitall and hit > 0 and not searchtimereached:
                            nowJust = datetime.today()
                            if nowJust > nowM + timedelta(seconds = searchtimemax):
                                if not searchtimereached:
                                    ###addDir('[COLOR red][B]Search time reached ('+str(searchtimemax)+' seconds)[/B][/COLOR]' ,'',0,'','0','0','Limit your search!\n\nClick to change limit','0','0','')
                                    searchtimereached = True
                            if filecount < filecountmax and not searchtimereached:
                                utils.logdev(module,'Search filename= %r' % infile)
                                ###name = infile.replace(recordPath,'',1).replace(recordArchivePath,'',1)
                                try:
                                    name = infile.replace('/','¤').replace('\\','¤').split('¤')[-1]
                                except Exception,e:
                                    pass
                                    name = repr(e)
                                filecount += 1
                                usedtime = str(int((nowJust-nowM).total_seconds()))
                                utils.logdev(module, 'filecount= %r, nowM= %r, nowJust= %r, usedtime= %r, searchtimereached= %r' % (filecount, nowM, nowJust, usedtime, searchtimereached))
                                files.append([name,infile,int(os.path.getmtime(infile))])
            
            if filecount > 0 and filecount < filecountmax and not searchtimereached:
                usedtime = str(int((nowJust-nowM).total_seconds()))
                addDir('[COLOR lightgreen][B]Search finished in '+usedtime+' seconds, found '+str(filecount)+' files[/B][/COLOR]' ,'url',int(view),'','0','0','Searched for: '+searchText+'[CR][CR]'+searchPath+sortmethod,'0','0','')
            if filecount >= filecountmax:
                ###addDir('[COLOR red]Search limit reached: '+str(filecountmax-1)+'[/COLOR]','url',6,'','','','Refine your search to reduce number of hits')
                usedtime = str(int((nowJust-nowM).total_seconds()))
                addDir('[COLOR red][B]Search limit reached ('+str(searchcountmax)+' in '+usedtime+' seconds)[/B][/COLOR]' ,'url',5011,'','0','0','Limit your search!\n\nClick to change limit[CR][CR]Searched for: '+searchText+'[CR][CR]'+searchPath+sortmethod,'0','0','')
            if searchtimereached:
                ###addDir('[COLOR red]Search time limit reached: ('+str(searchtimemax)+' secondes)[/COLOR]','url',6,'','','','Refine your search to reduce number of hits')
                addDir('[COLOR red][B]Search time reached ('+str(searchtimemax)+' seconds - Found '+str(filecount)+' files)[/B][/COLOR]' ,'url',5010,'','0','0','Limit your search!\n\nClick to change limit[CR][CR]Searched for: '+searchText+'[CR][CR]'+searchPath+sortmethod,'0','0','')
            ###files1 = sorted(files, reverse=False)
            utils.logdev(module,'files= %r' % files)
            if view == '2060' or view == '66':
                files1 = sorted(files, key=itemgetter(2), reverse=True)
                utils.logdev(module,'files1(2060)= %r' % files1)
            else:
                files1 = sorted(files)
                utils.logdev(module,'files1= %r' % files1)
            for inxfile in files1:
                name   = inxfile[0]
                utils.logdev(module,'name[:1]=2 %r' % name[:1])
                if name[:1] == '[':    ### 2019-03-09
                    nameparts = name.split(']',1)
                    name = nameparts[1] + ' ' + nameparts[0] + ']'
                    name = name.strip()
                infile = inxfile[1]
                infilecreated = inxfile[2]
                if os.path.isdir(infile):
                    ###name = infile.replace(recordPath,'',1).replace(recordArchivePath,'',1)
                    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage="DefaultFolder.png")
                    ###addDir('Recordings','url',6,'','','','All recorded items in ' + recordPath)
                    liz.setInfo( type="Folder", infoLabels={ "Title": str(name).replace('/','/ ').replace('\\','\\ ')})
                    liz.setProperty("IsPlayable","false")
                    contextMenu = []
                    ###contextMenu.append(('[COLOR red][B]Grab from %s[/B][/COLOR]'% (activetvguide),'XBMC.Container.Update(%s?name=None&mode=3000&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                    contextMenu.append(('[COLOR yellow][B]Home[/B][/COLOR]','XBMC.Container.Update(%s?name=Home&mode=None&url=None&iconimage=None&cat=None)'% (sys.argv[0])))
                    contextMenu.append(('[COLOR lightgreen][B]Search Channels/VOD[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=2008&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                    contextMenu.append(('[COLOR lightgreen][B]Search EPG Programs[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=2050&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                    contextMenu.append(('[COLOR lightgreen][B]Search Recorded[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=%s&url=None&iconimage=None&cat=%s)'% (sys.argv[0],view,cat)))
                    contextMenu.append(('[COLOR red][B]Planned Recordings[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=3&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                    contextMenu.append(('[COLOR orange][B]Favorites[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=17&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                    contextMenu.append(('[COLOR orange][B]Refresh[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=2004&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
                    if isTimeShiftActive():
                        contextMenu.append(('[COLOR red][B]Stop Timeshift Recording[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=30&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
                    contextMenu.append(('[COLOR red][B]Back to Kodi[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=29&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
                    contextMenu.append(('[COLOR orange][B]Delete Folder (if empty)[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=103&url=%s)'% (sys.argv[0], infile)))
                    liz.addContextMenuItems(contextMenu,replaceItems=True)
                    xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url=infile,listitem = liz, isFolder = True)
                else:
                    if isExtKnown(infile):
                        descfile = infile.replace('.flv','.txt').replace('.mp4','.txt').replace('.mkv','.txt').replace('.avi','.txt').replace('.m4v','.txt').replace('.ts','.txt')
                        utils.logdev(module,'descfile= ' + repr(descfile))
                        desc = ''
                        if os.path.isfile(descfile):
                            try:               ### Description:
                                descf = open(descfile,'r')
                                desc = descf.read()
                                descf.close()
                                desc = desc.split('Description:')[1]
                                utils.logdev(module,'desc= ' + repr(desc))
                            except Exception,e: 
                                pass
                                utils.logdev(module,'desc ERROR= ' + repr(e))
                        createdtime = datetime.fromtimestamp(infilecreated).strftime("%Y-%m-%d %H:%M")
                        desc =  'Created: ' + createdtime + '\n' + infile + '\n\n' + desc + '\n\n' + infile
                        desc = desc.replace('/B','¤B').replace('/C','¤C').replace('/I','¤I').replace('/','/ ').replace('\\','\\ ').replace('¤B','/B').replace('¤C','/C').replace('¤I','/I')
                        displayname = name.replace('[',' '*80 + '\n[COLOR lemonchiffon][I][',1)
                        if '\n[COLOR lemonchiffon][I][' in displayname:
                            displayname += '[/COLOR][/I]'
                        liz=xbmcgui.ListItem(displayname, iconImage="DefaultVideo.png", thumbnailImage="DefaultVideo.png")
                        liz.setInfo( type="Video", infoLabels={ "Title": str(name).replace('/','/ ').replace('\\','\\ '), "Plot":desc, "Category":desc})
                        liz.setProperty("IsPlayable","true")
                        contextMenu = []
                        contextMenu.append(('[COLOR yellow][B]Home[/B][/COLOR]','XBMC.Container.Update(%s?name=Home&mode=None&url=None&iconimage=None&cat=None)'% (sys.argv[0])))
                        contextMenu.append(('[COLOR lightgreen][B]Search Channels/VOD[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=2008&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                        contextMenu.append(('[COLOR lightgreen][B]Search EPG Programs[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=2050&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                        contextMenu.append(('[COLOR lightgreen][B]Search Recorded[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=%s&url=None&iconimage=None&cat=%s)'% (sys.argv[0],view,cat)))
                        contextMenu.append(('[COLOR red][B]Planned Recordings[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=3&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                        contextMenu.append(('[COLOR orange][B]Favorites[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=17&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                        contextMenu.append(('[COLOR orange][B]Refresh[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=2004&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
                        if isTimeShiftActive():
                            contextMenu.append(('[COLOR red][B]Stop Timeshift Recording[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=30&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
                        contextMenu.append(('[COLOR red][B]Back to Kodi[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=29&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
                        contextMenu.append(('[COLOR orange][B]Rename[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=1022&url=%s)'% (sys.argv[0], infile)))
                        contextMenu.append(('[COLOR orange][B]Convert[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=1040&url=%s)'% (sys.argv[0], infile)))
                        if chromecast: 
                            contextMenu.append(('[COLOR orange][B]Cast to first ChromeCast[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=1041&url=%s)'% (sys.argv[0], infile)))
                            contextMenu.append(('[COLOR orange][B]Stop Cast[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=1042&url=%s)'% (sys.argv[0], infile)))
                        contextMenu.append(('[COLOR orange][B]Delete[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=102&url=%s)'% (sys.argv[0], infile)))
                        liz.addContextMenuItems(contextMenu,replaceItems=True)
                        ###utils.logdev(module,'xbmcplugin.addDirectoryItem(handle = int(sys.argv[1])= %s, url=infile= %s,listitem = liz= %s, isFolder = False)' % (repr(int(sys.argv[1])),repr(infile),repr(liz)))
                        xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url=infile,listitem = liz, isFolder = False)
            
            if filecount == 0 and not searchtimereached:
                nowJust = datetime.today()
                usedtime = str(int((nowJust-nowM).total_seconds()))
                addDir('[COLOR lightgreen][B]Search finished in '+usedtime+' seconds, no files found[/B][/COLOR]' ,'url',int(view),'','0','0','Searched for: '+searchText+'[CR][CR]'+searchPath+sortmethod,'0','0','')
            if filecount > 0 and filecount < filecountmax and not searchtimereached:
                usedtime = str(int((nowJust-nowM).total_seconds()))
                addDir('[COLOR lightgreen][B]Search finished in '+usedtime+' seconds, found '+str(filecount)+' files[/B][/COLOR]' ,'url',int(view),'','0','0','Searched for: '+searchText+'[CR][CR]'+searchPath+sortmethod,'0','0','')
            if filecount >= filecountmax:
                usedtime = str(int((nowJust-nowM).total_seconds()))
                addDir('[COLOR red][B]Search limit reached ('+str(searchcountmax)+' in '+usedtime+' seconds)[/B][/COLOR]' ,'url',5011,'','0','0','Limit your search!\n\nClick to change limit[CR][CR]Searched for: '+searchText+'[CR][CR]'+searchPath+sortmethod,'0','0','')
            if searchtimereached:
                addDir('[COLOR red][B]Search time reached ('+str(searchtimemax)+' seconds - Found '+str(filecount)+' files)[/B][/COLOR]' ,'url',5010,'','0','0','Limit your search!\n\nClick to change limit[CR][CR]Searched for: '+searchText+'[CR][CR]'+searchPath+sortmethod,'0','0','')
    setView('movies', 'movies')

def DataBases():
    GoHome('Restore Planned Recordings')
    path = xbmc.translatePath(ADDON.getAddonInfo('profile'))
    files =  glob.glob(os.path.join(path, '*'))
    #print 'DOWNLOADS: files= %s' % repr(files)
    files1 = sorted(files, reverse=True)
    #print 'DOWNLOADS: files1= %s' % repr(files1)
    index = 0
    for infile in files1:
        if index < 50:
            index += 1
            try:
                #print infile
                #print infile[-3:]
                #print infile[-3:].lower()
                if infile[-3:].lower()=='.db':
                    name = infile.replace(path,'').replace('.db','')
                    ############################# How many records/recursive?
                    count = recordings.RecursiveRecordingsCount(infile)
                    user  = name.split('-')[1]
                    X = name.split('-')[0]
                    date  = X[:4]+'-'+X[4]+X[5]+'-'+X[6]+X[7]+' '+X[8]+X[9]+':'+X[10]+X[11]+':'+X[12]+X[13]
                    desc  = 'Date: ' + date + '\nUser: ' + user + '\n' +count.replace(' (P','Programs: ').replace('/R','\nRecursive programs: ').replace(')','')
                    ###liz=xbmcgui.ListItem(name + count, iconImage="DefaultFile.png", thumbnailImage="DefaultFile.png")
                    liz=xbmcgui.ListItem(date + ' ' + user + count, iconImage="DefaultFile.png", thumbnailImage="DefaultFile.png")
                    liz.setInfo( type="Video", infoLabels={ "Title": str(name).replace('/','/ ').replace('\\','\\ '), "Plot": desc})   ### TEST 2018-01-25
                    liz.setProperty("IsPlayable","false")
                    contextMenu = []
                    activeDB = recordings.RECORDS_DB.split('.')[0]
                    #print activeDB
                    if not name == activeDB: 
                        contextMenu.append(('[COLOR orange][B]Restore Backup[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=105&url=%s)'% (sys.argv[0], infile)))
                        contextMenu.append(('[COLOR orange][B]Restore Channels[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=113&url=%s)'% (sys.argv[0], infile)))
                        contextMenu.append(('[COLOR orange][B]Restore Recursive Channels[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=118&url=%s)'% (sys.argv[0], infile)))
                        contextMenu.append(('[COLOR orange][B]Restore Favorites[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=117&url=%s)'% (sys.argv[0], infile)))
                        contextMenu.append(('[COLOR orange][B]Restore EPG[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=114&url=%s)'% (sys.argv[0], infile)))
                        contextMenu.append(('[COLOR orange][B]Restore Recursive Records[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=107&url=%s)'% (sys.argv[0], infile)))
                        contextMenu.append(('[COLOR orange][B]Rename[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=1022&url=%s)'% (sys.argv[0], infile)))
                        contextMenu.append(('[COLOR orange][B]Delete[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=102&url=%s)'% (sys.argv[0], infile)))
                        liz.addContextMenuItems(contextMenu,replaceItems=True)
                        xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url=infile,listitem = liz, isFolder = False)
            except:
                pass
                #print 'Failed: %s' % repr(infile)
    setView('movies', 'main-view')

def SetupxmlFiles():
    GoHome('Past setting.xml')
    path = xbmc.translatePath(ADDON.getAddonInfo('profile'))
    files =  glob.glob(os.path.join(path, '*'))
    defaultfile = os.path.join(path, recordings.SETTINGSXML)
    #print 'DOWNLOADS: files= %s' % repr(files)
    files1 = sorted(files, reverse=True)
    #print 'DOWNLOADS: files1= %s' % repr(files1)
    activeDB = recordings.SETTINGSXML.split('.')[0]+ ' - ' + utils.username(defaultfile)
    index = 0
    for infile in files1:
        if index < 50:
            utils.logdev(module,'infile= %r' % infile)
            index += 1
            try:
                #print infile
                #print infile[-3:]
                #print infile[-3:].lower()
                if infile[-4:].lower()=='.xml':
                    utils.logdev(module,'infile(.xml)= %r' % infile)
                    mail = utils.username(infile)
                    utils.logdev(module,'mail= %r' % mail)
                    ###folder = utils.folder(defaultfile)
                    ###utils.logdev(module,'folder= %r' % folder)
                    if mail != '':
                        name = infile.replace(path,'').replace('.xml','') + ' - ' + mail 
                        liz=xbmcgui.ListItem(name, iconImage="DefaultFile.png", thumbnailImage="DefaultFile.png")
                        liz.setInfo( type="File", infoLabels={ "Title": str(name).replace('/','/ ').replace('\\','\\ ')})
                        liz.setProperty("IsPlayable","false")
                        contextMenu = []
                        ###if not name == activeDB and '@' in mail:
                        if not name == activeDB: 
                            contextMenu.append(('[COLOR orange][B]Restore settings.xml[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=106&url=%s)'% (sys.argv[0], infile)))
                            contextMenu.append(('[COLOR orange][B]Rename[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=1022&url=%s)'% (sys.argv[0], infile)))
                            contextMenu.append(('[COLOR orange][B]Convert[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=1040&url=%s)'% (sys.argv[0], infile)))
                            if chromecast: 
                                contextMenu.append(('[COLOR orange][B]Cast to first ChromeCast[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=1041&url=%s)'% (sys.argv[0], infile))) 
                                contextMenu.append(('[COLOR orange][B]Stop Cast[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=1042&url=%s)'% (sys.argv[0], infile)))
                            contextMenu.append(('[COLOR orange][B]Delete[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=102&url=%s)'% (sys.argv[0], infile)))
                            liz.addContextMenuItems(contextMenu,replaceItems=True)
                            xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url=infile,listitem = liz, isFolder = False)
            except Exception,e:
                pass
                utils.logdev(module,'SetupxmlFiles %r  Failed: %r' % (infile,e))
                #print 'Failed: %s' % repr(infile)
    setView('movies', 'main-view')


def deleteFile(file):
    tries    = 0
    maxTries = 2
    while os.path.exists(file) and tries < maxTries:
        try:
            utils.logdev(module, 'removeFile: %s' % file ) # Put in LOG
            os.remove(file)
            break
        except:
            utils.logdev(module, 'Failed #= %d' % tries)  # Put in LOG
            xbmc.sleep(500)
            tries = tries + 1

def deleteDir(file):
    tries    = 0
    maxTries = 10
    while os.path.exists(file) and tries < maxTries:
        try:
            print 'removeDir: %s' % file  # Put in LOG
            os.rmdir(file)
            break
        except:
            print 'Failed #= %d' % tries  # Put in LOG
            xbmc.sleep(500)
            tries = tries + 1
            
def get_params():
        param=[]
        #print 'default.py get_params= %s' % repr(sys.argv)
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','').replace('& ','aMp ')   ### 2019-02-23 Accept &<space> in filename
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
"""
xbmcplugin.setContent(int(sys.argv[1]), 'movies')
xbmcplugin.setPluginCategory(int(sys.argv[1]), 'Comedy')
xbmcplugin.setPluginFanart(int(sys.argv[1]), 'special://home/addons/plugins/video/Apple movie trailers II/fanart.png', color2='0xFFFF3300')
xbmcplugin.setProperty(int(sys.argv[1]), 'Emulator', 'M.A.M.E.')
"""
def param(u,match):
    try:
        u = urllib.unquote_plus(u)
        x = u.split('&'+match+'=')[1].split('&')[0]
    except:
        pass
        try:
            x = u.split('?'+match+'=')[1].split('&')[0]
        except:
            pass
            x = ''
    return x

def isHighlighted(u):
    try:
        utils.logdev(module,'isHighlighted u= %r' % u)
        cat        = param(u,'cat')
        startDate  = param(u,'startDate')
        endDate    = param(u,'endDate')
        name       = '' ### param(u,'name')
        recordname = param(u,'name')
        
        ThisHighlight = '#cat=' + cat + '#startDate=' + startDate +'#endDate=' + endDate + '#name=' + name + '#recordname=' + recordname + '#'  
        utils.logdev(module,'HIGHLIGHT ThisHighlight= %r' % ThisHighlight)
        
        if ThisHighlight in highlightscmp:
            utils.logdev(module,'HIGHLIGHT set in URL u= %r' % u)
            return True
            """
            if not 'name=%5BCOLOR+red%5DHighLight%5B%2FCOLOR%5D' in u:
                u=u.replace('name=','name=%5BCOLOR+red%5DHighLight%5B%2FCOLOR%5D').replace('recordname=','recordname=%5BCOLOR+red%5DHighLight%5B%2FCOLOR%5D')
                utils.logdev(module,'HIGHLIGHT set in URL u= %r' % u)
            """
    except Exception,e:
        pass
        utils.logdev(module,'HIGHLIGHT failed u= %r, ERROR= %r' % (u,e))
    return False

def addDir(name,url,mode,iconimage='',cat='',date='',description='',startDate='',endDate='',recordname='',whatsup=''):
    ###def addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
    ###utils.logdev(module,'0 addDir(name= %s,url= %s,mode= %s,iconimage= %s,cat= %s,date= %s,description= %s)' % (name,url,mode,iconimage,cat,date,description))
    if cat == '' and not url == '':
        cat = recordings.catFromUrl(url)
    if not type(str(iconimage)) == str:
        iconimage = ''
    if not type(str(description)) == str:
        description = ''
    ###if not type(str(cat)) == str:
    ### cat = ''
    ###utils.logdev(module,'1 addDir(name= %s,url= %s,mode= %s,iconimage= %s,cat= %s,date= %s,description= %s)' % (name,url,mode,iconimage,cat,date,description))
    try:
        u=sys.argv[0]+"?url="+urllibquote_plus(url)+"&mode="+str(mode)+"&name="+urllibquote_plus(name)+"&iconimage="+urllibquote_plus(iconimage)+"&cat="+urllibquote_plus(cat)+"&date="+urllibquote_plus(str(date))+"&description="+urllibquote_plus(recordings.latin1_to_ascii(description))+"&startDate="+urllibquote_plus(str(startDate))+"&endDate="+urllibquote_plus(str(endDate))+"&recordname="+urllibquote_plus(recordings.latin1_to_ascii(recordname)) 
    except Exception, e:
        pass
        utils.logdev(module,'Error in setting u\n' + repr(e))
        u=str(sys.argv[0])+"?url="+str(urllibquote_plus(url))+"&mode="+str(mode)+"&name="+str(name)+"&iconimage="+str(iconimage)+"&cat="+str(cat)+"&date="+str(date)+"&description="+str(recordings.latin1_to_ascii(description))
    if startDate != '':
        u += "&startDate="+str(startDate)
    if endDate != '':
        u += "&endDate="+str(endDate)
    if whatsup != '':
        u += "&whatsup="+whatsup
    if isHighlighted(u):
        name = '[COLOR red][B]¤[/B][/COLOR]' + name + ' [COLOR red][B]SELECTED[/B][/COLOR]'
    ##### Dates added urllibquote_plus() Krogsbell 2016-03-11
    ###return addDirBasic(name,url,mode,iconimage,cat,date,description,startDate,endDate,recordname,u)
    ################ Suggested code to avoid: WARNING: CreateLoader - unsupported protocol(plugin) in plugin://plugin.video.wozboxntv/
    #url="http://www.sample-videos.com/video/mp4/480/big_buck_bunny_480p_10mb.mp4"

    #URI=url
    #item = xbmcgui.ListItem(title, thumbnailImage=image)

    #item.setInfo(type='video', infoLabels={'genre': 'genre', 'plot': 'desc' })
    #item.setProperty('IsPlayable', 'true')

    #xbmcplugin.addDirectoryItem(pluginhandle, URI, item, False)
    ################
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name,"Plot":description, "Category":description } )
    try: # Find the mode on entry = the actual view '3' = Palnned Recordings
        view= sys.argv[2].split('mode=',1)[1].split('&')[0]
        #print view
    except:
        pass
        view= '0'
    TVguide= utils.TVguide()
    activetvguide= ADDON.getSetting('activetvguide')
    menu=[]
    #if ADDON.getSetting('enable_record')=='true':
    #   menu.append(('[COLOR red][B]RECORD...[/B][/COLOR]','XBMC.RunPlugin(%s?mode=2001&url=url&cat=%s&startDate=%s&endDate=%s&recordname=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)))))
    ###if mode==200 or mode==12 or mode == 2020 or mode == 2001 or mode == 0:
    if mode==200 or mode==12 or mode == 2020 or mode == 2001:
        defaultdocmenu = True
    else:
        defaultdocmenu = False
    KodiVersion = int(xbmc.getInfoLabel('System.BuildVersion')[:2])
    ###utils.logdev(module,'xbmc.getInfoLabel(System.BuildVersion)[:2]= %r' % KodiVersion)
    if KodiVersion < 17:  ### 2017-08-02 
        ###utils.logdev(module,'Use menu scroll!')
        try:
            scroll = ADDON.getSetting('scroll')
            if scroll == '' or (scroll != 'top' and scroll != 'buttom'):
                scroll = 'top'
                ADDON.setSetting('scroll',scroll)
        except:
            pass
            scroll = 'top'
            ADDON.setSetting('scroll',scroll)
    else:
        scroll = 'noscroll'
    ###utils.notification('scroll= ' + repr(scroll))
    
    if scroll == 'buttom':
        menu.append(('[COLOR yellow][B]Top[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=50&url=None&iconimage=None&cat=%s)'% (sys.argv[0],scroll)))
    menu.append(('[COLOR red][B]Back to Kodi[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=29&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
    menu.append(('[COLOR blue][B]Switch Addon[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=1030&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
    menu.append(('[COLOR yellow][B]Home[/B][/COLOR]','XBMC.Container.Update(%s?name=Home&mode=None&url=None&iconimage=None&cat=None)'% (sys.argv[0])))
    menu.append(('[COLOR orange][B]Refresh[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=2004&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
    
    
    if ADDON.getSetting('LastView') != 'FAVORITES':
        menu.append(('[COLOR lightgreen][B]Favorites[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=17&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    
    LastCommand= ADDON.getSetting('LastCommand')
    LastMode= ADDON.getSetting('LastMode')
    ### 2018-12-25
    if LastCommand != '' and LastMode != '' and defaultdocmenu:       
        menu.append(('[COLOR lightblue][B]Repeat: %r[/B][/COLOR]' % (LastCommand),'XBMC.RunPlugin(%s?mode=%s&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],LastMode,urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
	LastCommand2= ADDON.getSetting('LastCommand2') 
	LastMode2= ADDON.getSetting('LastMode2') 
	if LastCommand2 != '' and LastMode2 != '' and defaultdocmenu:     
		menu.append(('[COLOR lightblue][B]Repeat2: %r[/B][/COLOR]' % (LastCommand2),'XBMC.RunPlugin(%s?mode=%s&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],LastMode2,urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
		                
        ###menu.append(('[COLOR lightblue][B]Repeat: %r Mode= %s[/B][/COLOR]' % (LastCommand,LastMode),'XBMC.Container.Update(%s?name=None&mode=%s&url=None&iconimage=None&cat=%s)'% (sys.argv[0],LastMode, cat)))
    if ADDON.getSetting('enable_record')=='true' and not view == '3':
    ###if not view == '3':
        if scroll == 'top' or scroll == 'noscroll':
            menu.append(('[COLOR red][B]Planned Recordings[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=3&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    if ADDON.getSetting('tvguide')=='true' and defaultdocmenu:
        menu.append(('[COLOR yellow][B]TV Guide[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=4&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        if scroll == 'top' or scroll == 'noscroll' and defaultdocmenu:
            menu.append(('[COLOR yellow][B]Select TV Guide Channel[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=1004&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        if scroll == 'top' or scroll == 'noscroll' and (view == '4' or view == '2050'):
            menu.append(('[COLOR red][B]Delete EPG Entry[/B][/COLOR]','XBMC.RunPlugin(%s?mode=6000&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(name)),urllibquote_plus(recordings.latin1_to_ascii(description))))) 
        utils.logdev(module,'len(higlights)= %r \nhiglights= %r' % (len(higlights),higlights))
        if scroll == 'top' or scroll == 'noscroll' and defaultdocmenu and highlightcount > 0 and(IPTVuser == 'test1' or 'krogsbell' in IPTVuser): 
            menu.append(('[COLOR red][B]Deselect All (' + str(highlightcount) + ')[/B][/COLOR]','XBMC.RunPlugin(%s?mode=5001&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(name)),urllibquote_plus(recordings.latin1_to_ascii(description))))) 
        if scroll == 'top' or scroll == 'noscroll' and defaultdocmenu and (IPTVuser == 'test1' or 'krogsbell' in IPTVuser): 
            menu.append(('[COLOR red][B]Select[/B][/COLOR]','XBMC.RunPlugin(%s?mode=5000&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(name)),urllibquote_plus(recordings.latin1_to_ascii(description))))) 
    if scroll == 'top' or scroll == 'noscroll':
        ###menu.append(('[COLOR red][B]Test[/B][/COLOR]','XBMC.RunPlugin(%s?mode=4500&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(name)),urllibquote_plus(recordings.latin1_to_ascii(description))))) 
        if activetvguide.replace('plugin.video.','') == 'none':
            menu.append(('[COLOR red][B]No EPG grab[/B][/COLOR]',''))  ### Do nothing
        else:
            menu.append(('[COLOR green][B]Grab from %s[/B][/COLOR]'% (activetvguide.replace('plugin.video.','')),'XBMC.Container.Update(%s?name=None&mode=3000&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        menu.append(('[COLOR lightgreen][B]Search Channels/VOD[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=2008&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        menu.append(('[COLOR lightgreen][B]Search EPG Programs[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=2050&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        menu.append(('[COLOR lightgreen][B]Search Recordings in Database[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=2065&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        if ADDON.getSetting('sortalphabetic') == 'true':
            menu.append(('[COLOR lightgreen][B]Search Recordings Alphabetic[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=6&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        else:
            menu.append(('[COLOR lightgreen][B]Search Recordings by Date[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=66&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        menu.append(('[COLOR lightgreen][B]Latest Recordings[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=2060&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    ###if scroll == 'buttom' or scroll == 'noscroll':
        ###menu.append(('[COLOR red][B]Force INI and Reschedule EPG[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=4000&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    if ADDON.getSetting('enable_record')=='true':
        if not name[0:9] =='Recursive':
            if scroll == 'top' or scroll == 'noscroll' and defaultdocmenu:
                menu.append(('[COLOR red][B]RECORD[/B][/COLOR]','XBMC.RunPlugin(%s?mode=2001&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(name)),urllibquote_plus(recordings.latin1_to_ascii(description))))) ###
                
            if scroll == 'top' or scroll == 'noscroll' and defaultdocmenu:
                menu.append(('[COLOR red][B]RECORD RECURSIVE[/B][/COLOR]','XBMC.RunPlugin(%s?mode=2005&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
        if view == '3':
            if scroll == 'top' or scroll == 'noscroll' and defaultdocmenu:
                menu.append(('[COLOR red][B]MODIFY RECORD[/B][/COLOR]','XBMC.RunPlugin(%s?mode=2003&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s)'% (sys.argv[0],urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)))))
            if scroll == 'top' or scroll == 'noscroll' and defaultdocmenu:
                menu.append(('[COLOR orange][B]DISABLE RECORD[/B][/COLOR]','XBMC.RunPlugin(%s?mode=2006&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))  
            if scroll == 'top' or scroll == 'noscroll' and defaultdocmenu:
                menu.append(('[COLOR red][B]DELETE RECORD[/B][/COLOR]','XBMC.RunPlugin(%s?mode=2002&url=%s&cat=%s&startDate=%s&endDate=%s&name=%s&recordname=%s)'% (sys.argv[0],urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(name)),urllibquote_plus(recordings.latin1_to_ascii(recordname)))))
        ###if not view == '3':
        ###    if scroll == 'top' or scroll == 'noscroll':
        ###        menu.append(('[COLOR red][B]Planned Recordings[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=3&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        if ADDON.getSetting('DebugRecording')=='true':
            if scroll == 'top' or scroll == 'noscroll':
                menu.append(('[COLOR green][B]Planned Recordings Debug[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=13&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        ###menu.append(('[COLOR green][B]Recorded[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=6&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    if ADDON.getSetting('LastView') == 'FAVORITES':
        if scroll == 'buttom' or scroll == 'noscroll' and defaultdocmenu:
            menu.append(('[COLOR orange][B]Remove '+ADDONname+' Favourite[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=77&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    else:
        if scroll == 'buttom' or scroll == 'noscroll' and defaultdocmenu:
            menu.append(('[COLOR orange][B]Set '+ADDONname+' Favourite[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=7&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        ###if scroll == 'buttom' or scroll == 'noscroll':
        ###menu.append(('[COLOR orange][B]Favorites[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=17&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    if ADDON.getSetting('LastView') == 'RECURSIVECHANNELS':
        if scroll == 'buttom' or scroll == 'noscroll' and defaultdocmenu:
            menu.append(('[COLOR orange][B]Remove '+ADDONname+' Recursive Channel[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=28&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    else:
        if scroll == 'buttom' or scroll == 'noscroll' and defaultdocmenu:
            menu.append(('[COLOR orange][B]Set '+ADDONname+' Recursive Channel[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=27&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    if ADDON.getSetting('LastView') == 'HIDDENCHANNELS':
        if scroll == 'buttom' or scroll == 'noscroll' and defaultdocmenu:
            menu.append(('[COLOR orange][B]Remove '+ADDONname+' Hidden Channel[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=25&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    else:
        if scroll == 'buttom' or scroll == 'noscroll' and defaultdocmenu:
            menu.append(('[COLOR orange][B]Set '+ADDONname+' Hidden Channel[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=24&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
            
    #try:
    #   if name[0:9] =='Recursive' and not locking.isAnyRecordLocked():
    #       menu.append(('[COLOR orange][B]Refresh Recursive[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=2007&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
    #except:
    #   pass
    if ADDON.getSetting('enable_record')=='true':
        menu.append(('[COLOR orange][B]Restore from Database[/B][/COLOR]','XBMC.RunPlugin(%s?name=&mode=104&url=url&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    ###menu.append(('[COLOR orange][B]Refresh[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=2004&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
    if isTimeShiftActive():
        menu.append(('[COLOR red][B]Stop Timeshift Recording[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=30&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
    ###menu.append(('[COLOR red][B]Back to Kodi[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=29&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
    ###menu.append(('[COLOR yellow][B]Home[/B][/COLOR]','XBMC.Container.Update(%s?name=Home&mode=None&url=None&iconimage=None&cat=None)'% (sys.argv[0])))
    if scroll == 'top':
        menu.append(('[COLOR yellow][B]Buttom[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=51&url=None&iconimage=None&cat=%s)'% (sys.argv[0],scroll)))
    if mode==200: ### NEW in 3.3.9
        liz.setProperty("IsPlayable","true")
    liz.addContextMenuItems(items=menu, replaceItems=True)
    if mode==200 or mode==12 or mode == 2020 or mode == 2001 or mode == 0:
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    else:
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def isTimeShiftActive():
    subprpid = xbmcgui.Window(10000).getProperty(ADDONname + 'subprpid')
    subprcmd = xbmcgui.Window(10000).getProperty(ADDONname + 'subprcmd')
    utils.logdev(module,'OldTimeShift to stop and reset subprpid= %r, subprcmd= %r' % (subprpid, subprcmd))
    if subprpid != '' and ADDON.getSetting('timeshiftbase') in subprcmd:
        return True
    else:
        return False
    
def addDirBasic(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='',u=''):
    u=sys.argv[0]+"?url="+str(url)+"&mode="+str(mode)+"&name="+str(name)+"&iconimage="+str(iconimage)+"&cat="+str(cat)+"&date="+str(date)+"&description="+str(description)+"&startDate="+str(startDate)+"&endDate="+str(endDate)+"&recordname="+str(recordname)
    
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name,"Plot":description, "Category":description } )
    try: # Find the mode on entry = the actual view '3' = Planned Recordings
        view= sys.argv[2].split('mode=',1)[1].split('&')[0]
        #print view
    except:
        pass
        view= '0'
    
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok


def addDir_STOP(name,url,iconimage,cat,date,description,startDate='',endDate='',recordname=''):
        u=sys.argv[0]+"?url="+urllibquote_plus(url)+"&name="+urllibquote_plus(name)+"&iconimage="+urllibquote_plus(iconimage)+"&cat="+urllibquote_plus(cat)+"&date="+str(date)+"&description="+urllibquote_plus(description)+"&startDate="+str(startDate)+"&endDate="+str(endDate)+"&recordname="+recordings.latin1_to_ascii(recordname)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name,"Premiered":date,"Plot":description} )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        
def SetUserAndPasswordNew():
    dialog = xbmcgui.Dialog()
    ##Dialog.radiolist(text, height=None, width=None, list_height=None, choices=[], **kwargs)
    ##choices – an iterable of (tag, item, status) tuples where status specifies the initial selected/unselected state of each entry; can be True or False, 1 or 0, "on" or "off" (True, 1 and "on" meaning selected), or any case variation of these two strings. No more than one entry should be set to True.
    choises = []
    selected = dialog.select(ADDON.getAddonInfo('name') + ' - Select a previous login:', choises ) ####################
    if selected == 'newmail':
        email=Search('Email')
    else:
        email = choises[selected]
    #email=Search('Email')
    ###utils.logdev(module,'email= %s' % repr(email))
    email = str(email)
    ###utils.logdev(module,'str(email)= %s' % repr(email))
    if not email == "":
        password=Search('Password')
        if not email == "" and not password == "":
            ADDON.setSetting('user',email)
            ADDON.setSetting('pass',password)
            AUTH()
            utils.notification('[COLOR green]Email and password updated[/COLOR]')
    MYACCOUNT()
    
def SetUserAndPassword():
    email=Search('Email')
    ###utils.logdev(module,'email= %s' % repr(email))
    email = str(email)
    ###utils.logdev(module,'str(email)= %s' % repr(email))
    if not email == "":
        password=Search('Password')
        if not email == "" and not password == "":
            ADDON.setSetting('user',email)
            ADDON.setSetting('pass',password)
            AUTH()
            utils.notification('[COLOR green]Email and password updated[/COLOR]')
            ### Delete all chanels
            recordings.delAllChannels()
            ### Start update of EPG
            recordings.EPGOnce()
    MYACCOUNT()

def views(name,cat,url,description):
    lastview = ADDON.getSetting('LastView')
    ###utils.logdev(module,'lastview= %r, name= %r, cat= %r' % (lastview, name, cat))
    if lastview == 'TVGUIDE':
        TVGUIDE(name,cat)
    elif lastview == 'CHANNELS': 
        CHANNELS(name,cat)
    
    elif lastview == 'STATUS':
        STATUS()
    
    elif lastview == 'MYACCOUNT':
        MYACCOUNT()

    elif lastview == 'DOWNLOADS':
        DOWNLOADS('6')
    
    elif lastview == 'CATEGORIES':
        CATEGORIES()

    elif lastview == 'RECORDINGSPLANNED':
        RecordingsPlanned()

    elif lastview == 'ntvCATEGORIES':
        ntvCATEGORIES()

    elif lastview == 'FAVORITES':
        FAVORITES()
    
    elif lastview == 'ARCHIVE':
        ARCHIVE()

    elif lastview == 'MYSELECTEDCHANNELS':
        MYSELECTEDCHANNELS()

    elif lastview == 'HIDDENCHANNELS':
        HIDDENCHANNELS()

    elif lastview == 'NEWCHANNELS':
        NEWCHANNELS()

    elif lastview == 'CHANNELSROQOLD':
        CHANNELSROQOLD(name,cat,url,description)

    elif lastview == 'CHANNELSROQ':
        CHANNELSROQ()
        
    elif lastview == 'CHANNELSSEARCH':
        CHANNELSSEARCH()
        
    elif lastview == 'PROGRAMSEARCH':
        PROGRAMSEARCH()
              
    elif lastview == 'RECURSIVECHANNELS':
        RECURSIVECHANNELS()
    
    elif lastview == 'SUBS':
        SUBS()
    ###xbmc.executebuiltin("Container.Refresh")

#below tells plugin about the views                
def setView(content, viewType):
        # set content type so library shows more views and info
        utils.logdev(module,'setView(content= %r, viewType= %r)' % (content, viewType))
        if content:
                xbmcplugin.setContent(int(sys.argv[1]), content)
        if ADDON.getSetting('auto-view') == 'true':#<<<----see here if auto-view is enabled(true) 
                xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )#<<<-----then get the view type

###recordings.ftvntvlist()  ### Debug
params=get_params()
###utils.logdev(module+'-params',repr(params))
###utils.logdevarray(module+'-params',params)
url=None
name=''
mode=None
iconimage=None
date=None
description=None
cat=None
startDate=None
endDate=None
record=None
uri=None
playpath=None
app=None
recordname=''
auth=None
sourceApp=''
###slist=None
###aifp=None
###utils.logdev('default.py params',repr(params))
"""try:
    aifp=urllib.unquote_plus(params["aifp"])  # URL
    ###utils.logdev('default.py aifp',aifp)
except:
    pass
try:
    slist=urllib.unquote_plus(params["slist"])  # URL
    ###utils.logdev('default.py slist',slist)
except:
    pass
"""
try:
    auth=urllib.unquote_plus(params["auth"])  # URL
    ###utils.logdev('default.py auth',auth)
except:
    pass    
try:
    url=urllib.unquote_plus(params["url"])  # URL
    ###utils.logdev('default.py url',url)
except:
    pass
try:
    #utils.logdev(module,'URI= %s' % repr(params["uri"]))
    uri=urllib.unquote_plus(params["uri"])  # URI
    ### Conversion at script!
    ###uri=uri.replace('###',',').replace('AaAaA','=')
    ###utils.logdev('default.py uri',uri)
except:
    pass
try:
    playpath=urllib.unquote_plus(params["playpath"])  # playpath
except:
    pass
try:
    app=urllib.unquote_plus(params["app"])  # app
except:
    pass
try:
    name=urllib.unquote_plus(params["name"])
    name = name.split('[/COLOR]')[1]
    ###utils.logdev('default.py name',repr(name))
except:
    pass
try:
    iconimage=urllib.unquote_plus(params["iconimage"])
except:
    pass
try:        
    mode=int(params["mode"])
except:
    pass
try:
    cat=urllib.unquote_plus(params["cat"])
except:
    pass
try:
    date=str(params["date"])
except:
    pass
try:
    description=(urllib.unquote_plus(params["description"])).replace('NlNlNl','\n')
    ###utils.logdev('default.py description',description)
except:
    pass
try:
    startDate=str(params["startDate"])
except:
    pass
try:
    endDate=str(params["endDate"])
except:
    pass
try:
    ###utils.logdev('default.py 00 recordname',recordname)
    recordname=urllib.unquote_plus(params["recordname"])
    ###utils.logdev('default.py 0 recordname',recordname)
    if recordname == '' and not name == '':
        recordname = name
    ###utils.logdev('default.py 1 recordname',recordname)
except:
    pass
try:
    sourceApp=str(params["source"])
except:
    pass

utils.logdev(module, 'Just before commands: (cat= %r, mode= %r, url= %r, startDate= %r, endDate= %r, name= %r, recordname= %r, description= %r)' % (cat, mode, url, startDate, endDate, name, recordname, description))

#these are the modes which tells the plugin where to go
###if mode==None or url==None or len(url)<1:

if mode==6:  ### Search recordings
    ADDON.setSetting('LastView', 'DOWNLOADS')
    ADDON.setSetting('record_display_path',recordPath)
    ADDON.setSetting('sortalphabetic','true')
    DOWNLOADS('6')

elif mode==2060:   ### Search descriptions
    ADDON.setSetting('LastView', 'DOWNLOADS')
    ADDON.setSetting('record_display_path',recordPath)
    DOWNLOADS('2060')

elif mode==2065:   ### Search database
    ADDON.setSetting('LastView', 'DOWNLOADS')
    ADDON.setSetting('record_display_path',recordPath)
    DOWNLOADS('2065')
    
elif mode==2070:   ### Update file database
    ADDON.setSetting('LastView', 'ScanRecordings')
    updateepg.ScanRecordings()
    ###xbmc.executebuiltin("Container.Refresh")
    """
    try:
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_DATE)
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_TITLE)
    except Exception,e:
        pass
        utils.logdev('addSortMethod','ERROR: %r' % e)
    """
elif mode==66:   
    ADDON.setSetting('LastView', 'DOWNLOADS')
    ADDON.setSetting('record_display_path',cat)
    ADDON.setSetting('sortalphabetic','false')
    DOWNLOADS('66')
    
elif mode==67:   ### Search in description - not implemented
    ADDON.setSetting('LastView', 'DOWNLOADS')
    ADDON.setSetting('record_display_path',cat)
    DOWNLOADS('67')
        
elif mode==1:  ### free
    utils.logdev(module,'mode 1 executed!')
    
elif mode==8:
    ADDON.setSetting('LastView', 'MYACCOUNT')
    MYACCOUNT()

elif mode==49:
    ADDON.setSetting('LastView', 'Maintenance')
    Maintenance()
    
elif mode==490:
    ADDON.setSetting('LastView', 'Streams')
    Streams()
    
    
elif mode==10:
    dialog = xbmcgui.Dialog()
    if dialog.yesno(ADDON.getAddonInfo('name'), "[COLOR red]Delete database and start all over?[/COLOR]", '', "What Do You Want To Do","[COLOR red]Delete[/COLOR]","[COLOR green]Ignore[/COLOR]"):
        ### Ignore
        lockcause = 'ignore' ### Dummy command
    else:
        ### Stop recording and record new
        lockcause = 'change' ### Dummy command
        ### Backup Database and files
        recordings.backupSetupxml()
        recordings.backupDataBase
        ### Clear Scanning
        locking.scanUnlock('EPG_update')
        ### Delete Database
        recordings.deleteDataBase()
        ADDON.setSetting('BASEURL','')   ### Reset user
        recordings.EPGOnce()   ### Update Channels and EPG
    
    ###xbmcaddon.Addon(id=ADDONid).openSettings()
    ###setView('movies', 'main-view')
    ###utils.notificationsend('Open Setting Finished')

elif mode==5010:
    searchtimemax = ADDON.getSetting('searchtimemax')
    #searchtimemax = 20
    dialog = xbmcgui.Dialog()
    keyboard=dialog.numeric(0, 'Please Enter Search Time Maximum',searchtimemax)
    if keyboard:
        ADDON.setSetting('searchtimemax',keyboard)
    setView('movies', 'main-view')
    #utils.notificationsend('Open Setting Finished')

elif mode==5011:
        
    #searchcountmax = 100
    searchcountmax = ADDON.getSetting('searchcountmax')
    dialog = xbmcgui.Dialog()
    keyboard=dialog.numeric(0, 'Please Enter Search Count Maximum',searchcountmax)
    if keyboard:
        ADDON.setSetting('searchcountmax',keyboard)
    setView('movies', 'main-view')
    #utils.notificationsend('Open Setting Finished')
    
elif mode==5012:   ### Adjust archive offset
    archiveoffsetminutes = ADDON.getSetting('archiveoffsetminutes')
    dialog = xbmcgui.Dialog()
    keyboard=dialog.numeric(0, 'Please Enter Archive Offset in Minutes',archiveoffsetminutes)
    if keyboard:
        if keyboard[0:1] == '0':
            keyboard = str(0-int(keyboard))
        ADDON.setSetting('archiveoffsetminutes',keyboard)
        setView('movies', 'main-view')
        utils.notificationsend('Refresh view to use new offset')
    
elif mode==9:
    ADDON.setSetting('LastView', 'SUBS')
    SUBS()

elif mode==11:
    ADDON.setSetting('LastView', 'STATUS')
    STATUS()

elif mode==12:
    STATUSsub(description)

elif mode==13:
    RecordingsPlannedDebug()

elif mode==14:
    SetUserAndPassword()
    
elif mode==15:
    SetupxmlFiles() 
    
elif mode==50:
    ### To Top  
    ADDON.setSetting('scroll','top')
    views(name,cat,url,description)
    
elif mode==51:
    ### Buttom      
    ADDON.setSetting('scroll','buttom')
    views(name,cat,url,description)
    
elif mode==102:
    try:    ### Delete information and subtitles if they are available
        url = url.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
        fileext = '.' + url.split('.')[-1]
        try:
            deleteFile(url.replace(fileext,'.txt'))
        except:   pass  
        try:
            deleteFile(url.replace(fileext,'.srt'))
        except:   pass
        try:
            deleteFile(url.replace(fileext,'.en.srt'))
        except:   pass
        try:
            deleteFile(url.replace(fileext,'.da.srt'))
        except:   pass
        try:
            deleteFile(url.replace(fileext,'.nfo'))
        except:   pass
        try:
            deleteFile(url.replace(fileext,'.log'))
        except:   pass
    except:
        pass
    deleteFile(url)
    xbmc.executebuiltin("Container.Refresh")

elif mode==1022:
    try:    ### Rename information and subtitles if they are available
        url = url.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
        utils.logdev(module,'url= %r' % url)
        urldirectorypath = os.path.dirname(url) # relative directory path
        utils.logdev(module,'urldirectorypath= %r' % urldirectorypath)
        urlbasename = os.path.basename(url) # the file name only
        utils.logdev(module,'urlbasename= %r' % urlbasename)
        fileext = '.' + url.split('.')[-1]
        utils.logdev(module,'fileext= %r' % fileext)
        if '[' in urlbasename:
            utils.logdev(module,'urlbasename= %r' % urlbasename)
            urlbase = urlbasename.split('[')[0]
            urlbasefull = urlbasename.replace(fileext,'',-1)
        else:
            urlbasefull = urlbasename.replace(fileext,'',-1)  ### Remove extension
            urlbase     = urlbasefull
        ###urlbasefull = os.path.basename(urlbasefull)
        utils.logdev(module,'urlbasefull= %r' % urlbasefull)
        ###urlbase = os.path.basename(urlbase)
        utils.logdev(module,'urlbase= %r' % urlbase)
        if urlbase != urlbasefull:
            urlbaselastpart = urlbasefull.replace(urlbase,'...',1)
        else:
            urlbaselastpart = urlbasefull
        urlbase = urlbase.replace('xxYYxx','&')
        urlbasefull = urlbasefull.replace('xxYYxx','&')
        dialog = xbmcgui.Dialog()
        urlnewi = dialog.input('Enter new filename for: \n' + urlbaselastpart, defaultt=urlbase, type=xbmcgui.INPUT_ALPHANUM)
        if urlnewi != '':
            urlnewi = recordings.latin1_to_ascii_force(urlnewi)   ### use only acceptable characters
            urlnew = os.path.join(urldirectorypath,urlbasefull.replace(urlbase,urlnewi))
            utils.logdev(module,'urlnew= %r' % urlnew)
            urlbase = os.path.join(urldirectorypath,urlbasefull)
            utils.logdev(module,'urlbase= %r' % urlbase)
            os.rename(urlbase+fileext,urlnew+fileext)
            try:
                os.rename(urlbase+'.txt',urlnew+'.txt')
            except Exception,e:
                pass
                utils.logdev(module,'Rename error %r' % e)
            try:
                os.rename(urlbase+'.srt',urlnew+'.srt')
            except Exception,e:
                pass
                utils.logdev(module,'Rename error %r' % e)
            try:
                os.rename(urlbase+'.en.srt',urlnew+'.en.srt')
            except Exception,e:
                pass
                utils.logdev(module,'Rename error %r' % e)
            try:
                os.rename(urlbase+'.da.srt',urlnew+'.da.srt')
            except Exception,e:
                pass
                utils.logdev(module,'Rename error %r' % e)
            try:
                os.rename(urlbase+'.nfo',urlnew+'.nfo')
            except Exception,e:
                pass
                utils.logdev(module,'Rename error %r' % e)
            try:
                os.rename(urlbase+'.log',urlnew+'.log')
            except Exception,e:
                pass
                utils.logdev(module,'Rename error %r' % e)
    except Exception,e:
        pass
        utils.logdev(module,'Rename error %r' % e)
    
    xbmc.executebuiltin("Container.Refresh")

elif mode==1023:
    try:    ### Set command in FilesDB to: Rename information and subtitles if they are available
        ### mode=1023&url=chan[0]&name=chan[6]&recordname=chan[1]&description=chan[2]
        ### 0 filename, 1 ext, 2 path, 3 video, 4 description, 5 size, 6 archive, 7 updated, 8 created, 9 updatedHuman, 10 command, 11 options
        ADDON.setSetting('lastdatabaseaction','Rename')
        url = url.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
        utils.logdev(module,'url= %r' % url)
        archive = name 
        fileextt = recordname
        if fileextt != '':
            fileext = '.'+fileextt
        else:
            fileext = ''
        basePath = description
        ##urldirectorypath = os.path.dirname(url) # relative directory path
        ##utils.logdev(module,'urldirectorypath= %r' % urldirectorypath)
        urlbasename = url # the file name only
        utils.logdev(module,'urlbasename= %r' % urlbasename)
        utils.logdev(module,'fileext= %r' % fileext)
        if '[' in urlbasename:
            utils.logdev(module,'urlbasename= %r' % urlbasename)
            urlbase = urlbasename.split('[')[0]
            urlbasefull = urlbasename
        else:
            urlbasefull = urlbasename
            urlbase     = urlbasefull
        utils.logdev(module,'urlbasefull= %r' % urlbasefull)
        utils.logdev(module,'urlbase= %r' % urlbase)
        if urlbase != urlbasefull:
            urlbaselastpart = urlbasefull.replace(urlbase,'...',1)
        else:
            urlbaselastpart = urlbasefull
        urlbase = urlbase.replace('xxYYxx','&')
        urlbasefull = urlbasefull.replace('xxYYxx','&')
        dialog = xbmcgui.Dialog()
        urlnewi = dialog.input('Enter new filename for: \n' + urlbaselastpart, defaultt=urlbase, type=xbmcgui.INPUT_ALPHANUM)
        if urlnewi != '':
            urlnewi = recordings.latin1_to_ascii_force(urlnewi)   ### use only acceptable characters
            utils.logdev(module,'urlbasefull= %r, urlbase= %r, urlnewi= %r' % (urlbasefull, urlbase, urlnewi))
            urlnew = urlbasefull.replace(urlbase,urlnewi)
            utils.logdev(module,'urlnew= %r' % urlnew)
            conf = recordings.getFilesConnection()
            recordings.createFileTable(conf)
            c = conf.cursor()
            command = 'rename'
            options = urlnew
            recordings.addFileCommand(c, url, fileextt, basePath, archive, command, options)
            conf.commit()
            c.close() 
    except Exception,e:
        pass
        utils.logdev(module,'Rename in DB error %r' % e)
    
    xbmc.executebuiltin("Container.Refresh")

elif mode==1024:
    try:    ### Set command in FilesDB to: Move information and subtitles if they are available
        ### mode=1023&url=chan[0]&name=chan[6]&recordname=chan[1]&description=chan[2]
        ### 0 filename, 1 ext, 2 path, 3 video, 4 description, 5 size, 6 archive, 7 updated, 8 created, 9 updatedHuman, 10 command, 11 options
        ADDON.setSetting('lastdatabaseaction','Move')
        url = url.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
        utils.logdev(module,'url= %r' % url)
        archive = name 
        fileextt = recordname
        if fileextt != '':
            fileext = '.'+fileextt
        else:
            fileext = ''
        basePath = description
        urlbasename = url # the file name only
        utils.logdev(module,'urlbasename= %r' % urlbasename)
        utils.logdev(module,'fileext= %r' % fileext)
        if '[' in urlbasename:
            utils.logdev(module,'urlbasename= %r' % urlbasename)
            urlbase = urlbasename.split('[')[0]
            urlbasefull = urlbasename
        else:
            urlbasefull = urlbasename
            urlbase     = urlbasefull
        utils.logdev(module,'urlbasefull= %r' % urlbasefull)
        utils.logdev(module,'urlbase= %r' % urlbase)
        if urlbase != urlbasefull:
            urlbaselastpart = urlbasefull.replace(urlbase,'...',1)
        else:
            urlbaselastpart = urlbasefull
        urlbase = urlbase.replace('xxYYxx','&')
        urlbasefull = urlbasefull.replace('xxYYxx','&')
        
        dialog = xbmcgui.Dialog()
        if archive == 'L':
            question = "[COLOR red]Move recording TO Archive?[/COLOR]"
        else:
            question = "[COLOR green]Move recording FROM Archive?[/COLOR]"
        if not dialog.yesno(ADDON.getAddonInfo('name'), question, 'Record: ' + urlbase, "What Do You Want To Do","[COLOR red]Move[/COLOR]","[COLOR green]Ignore[/COLOR]"):
            conf = recordings.getFilesConnection()
            recordings.createFileTable(conf)
            c = conf.cursor()
            command = 'move'
            options = url
            recordings.addFileCommand(c, url, fileextt, basePath, archive, command, options)
            conf.commit()
            c.close() 
    except Exception,e:
        pass
        utils.logdev(module,'Move in DB error %r' % e)
    
    xbmc.executebuiltin("Container.Refresh")
    
elif mode==1025:
    try:    ### Execute all commands and update db
        ### mode=1023&url=chan[0]&name=chan[6]&recordname=chan[1]&description=chan[2]
        ### 0 filename, 1 ext, 2 path, 3 video, 4 description, 5 size, 6 archive, 7 updated, 8 created, 9 updatedHuman, 10 command, 11 options
        ADDON.setSetting('lastdatabaseaction','Execute Commands and Update')
        url = url.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
        utils.logdev(module,'mode= %r, url= %r' % (mode,url))
        
        dialog = xbmcgui.Dialog()
        question = "[COLOR red]Execute commands in Files DB and update DB?[/COLOR]"
        if not dialog.yesno(ADDON.getAddonInfo('name'), question, 'May take a while', "What Do You Want To Do","[COLOR red]Execute Commands[/COLOR]","[COLOR green]Ignore[/COLOR]"):
            updateepg.ScanRecordings()
    except Exception,e:
        pass
        utils.logdev(module,'Execute commands in DB error %r' % e)
    
    ###xbmc.executebuiltin("Container.Refresh")  - No need it comes long time after

elif mode==1026:
    try:    ### Delete file
        ADDON.setSetting('lastdatabaseaction','Delete File')
        url = url.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
        utils.logdev(module,'url= %r' % url)
        archive = name 
        fileextt = recordname
        if fileextt != '':
            fileext = '.'+fileextt
        else:
            fileext = ''
        basePath = description
        urlbasename = url # the file name only
        utils.logdev(module,'urlbasename= %r' % urlbasename)
        utils.logdev(module,'fileext= %r' % fileext)
        if '[' in urlbasename:
            utils.logdev(module,'urlbasename= %r' % urlbasename)
            urlbase = urlbasename.split('[')[0]
            urlbasefull = urlbasename
        else:
            urlbasefull = urlbasename
            urlbase     = urlbasefull
        utils.logdev(module,'urlbasefull= %r' % urlbasefull)
        utils.logdev(module,'urlbase= %r' % urlbase)
        if urlbase != urlbasefull:
            urlbaselastpart = urlbasefull.replace(urlbase,'...',1)
        else:
            urlbaselastpart = urlbasefull
        urlbase = urlbase.replace('xxYYxx','&')
        urlbasefull = urlbasefull.replace('xxYYxx','&')
        
        dialog = xbmcgui.Dialog()
        
        question = "[COLOR red]DELETE recording?[/COLOR]"
        
        if not dialog.yesno(ADDON.getAddonInfo('name'), question, 'Record: ' + urlbase, "What Do You Want To Do","[COLOR red]DELETE[/COLOR]","[COLOR green]Ignore[/COLOR]"):
            conf = recordings.getFilesConnection()
            recordings.createFileTable(conf)
            c = conf.cursor()
            command = 'delete'
            options = url
            recordings.addFileCommand(c, url, fileextt, basePath, archive, command, options)
            conf.commit()
            c.close() 
    except Exception,e:
        pass
        utils.logdev(module,'Delete File in DB error %r' % e)
    
    xbmc.executebuiltin("Container.Refresh")
 
elif mode==1027:
    try:    ### Clear command
        ADDON.setSetting('lastdatabaseaction','Clear Command')
        url = url.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename - Accept + in filename
        utils.logdev(module,'url= %r' % url)
        archive = name 
        fileextt = recordname
        if fileextt != '':
            fileext = '.'+fileextt
        else:
            fileext = ''
        basePath = description
        urlbasename = url # the file name only
        utils.logdev(module,'urlbasename= %r' % urlbasename)
        utils.logdev(module,'fileext= %r' % fileext)
        if '[' in urlbasename:
            utils.logdev(module,'urlbasename= %r' % urlbasename)
            urlbase = urlbasename.split('[')[0]
            urlbasefull = urlbasename
        else:
            urlbasefull = urlbasename
            urlbase     = urlbasefull
        utils.logdev(module,'urlbasefull= %r' % urlbasefull)
        utils.logdev(module,'urlbase= %r' % urlbase)
        if urlbase != urlbasefull:
            urlbaselastpart = urlbasefull.replace(urlbase,'...',1)
        else:
            urlbaselastpart = urlbasefull
        urlbase = urlbase.replace('xxYYxx','&')
        urlbasefull = urlbasefull.replace('xxYYxx','&')
        
        dialog = xbmcgui.Dialog()
        
        question = "[COLOR red]Clear Command?[/COLOR]"
        
        if not dialog.yesno(ADDON.getAddonInfo('name'), question, 'Record: ' + urlbase, "What Do You Want To Do","[COLOR red]Clear[/COLOR]","[COLOR green]Ignore[/COLOR]"):
            conf = recordings.getFilesConnection()
            recordings.createFileTable(conf)
            c = conf.cursor()
            command = ''
            options = ''
            recordings.addFileCommand(c, url, fileextt, basePath, archive, command, options)
            conf.commit()
            c.close() 
    except Exception,e:
        pass
        utils.logdev(module,'Clear in DB error %r' % e)
    
    xbmc.executebuiltin("Container.Refresh")

elif mode==1028:   
    try:    ### Set command to Move to folder
        ### mode=1023&url=chan[0]&name=chan[6]&recordname=chan[1]&description=chan[2]
        ### 0 filename, 1 ext, 2 path, 3 video, 4 description, 5 size, 6 archive, 7 updated, 8 created, 9 updatedHuman, 10 command, 11 options
        ADDON.setSetting('lastdatabaseaction','Move to Folder')
        url = url.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
        utils.logdev(module,'1028 url= %r' % url)
        archive = name 
        fileextt = recordname
        if fileextt != '':
            fileext = '.'+fileextt
        else:
            fileext = ''
        basePath = description
        ### Select from all local or archive folders or create a new
        conf = recordings.getFilesConnection()
        recordings.createFileTable(conf)
        c = conf.cursor()
        c.execute("SELECT DISTINCT archive, path FROM files WHERE NOT path=?", ['']) 
        channels = c.fetchall()
        channels = sorted(channels, key=itemgetter('path'))
        channels = sorted(channels, key=itemgetter('archive'), reverse=True)
        folders = []
        for chan in channels:
            folders.append(chan[0].lower() + ':' + chan[1])
        SelectedFolder = xbmcgui.Dialog().select('Select Folder for: ' + url, folders)
        utils.logdev(module,'SelectedFolder= %r ==> %r' % (SelectedFolder,folders[SelectedFolder]))
        if SelectedFolder != -1:
            command = 'movetofolder'
            options = folders[SelectedFolder]
            recordings.addFileCommand(c, url, fileextt, basePath, archive, command, options)
            conf.commit()
        c.close() 
    except Exception,e:
        pass
        utils.logdev(module,'Move to Folder error %r' % e)
    
    xbmc.executebuiltin("Container.Refresh")

elif mode==1029:  ### Clear the File Database and start a new scan
    dialog = xbmcgui.Dialog()
    if dialog.yesno(ADDON.getAddonInfo('name'), "[COLOR red]Delete File Database and start a new scan?[/COLOR]", '', "What Do You Want To Do","[COLOR red]Delete[/COLOR]","[COLOR green]Ignore[/COLOR]"):
        ### Ignore
        lockcause = 'ignore' ### Dummy command
    else:
        ### Stop recording and record new
        lockcause = 'change' ### Dummy command
        recordings.deleteFileBase()
        xbmc.sleep(1000)
        updateepg.ScanRecordings()
            
elif mode==1031:  ### Multiselect
    """
    Function: xbmcgui.Dialog().multiselect(heading, options[, autoclose, preselect, useDetails])
    Show a multi-select dialog.
    Parameters
    heading	string or unicode - dialog heading.
    options	list of strings / xbmcgui.ListItems - options to choose from.
    autoclose	[opt] integer - milliseconds to autoclose dialog. (default=do not autoclose)
    preselect	[opt] list of int - indexes of items to preselect in list (default: do not preselect any item)
    useDetails	[opt] bool - use detailed list instead of a compact list. (default=false)
    Returns
    Returns the selected items as a list of indices, or None if cancelled.
    """
    dialog = xbmcgui.Dialog()
    actions = ['Rename','Move','Move to Folder','Delete','Clear Command']
    selected = dialog.select(ADDON.getAddonInfo('name') + ' [COLOR red]Select Action[/COLOR]', actions)
    if selected >= 0:
        command = actions[selected]
        url = url.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
        if command == actions[2]:            ###'Move to Folder':
            ### Select from all local or archive folders or create a new
            conf = recordings.getFilesConnection()
            recordings.createFileTable(conf)
            c = conf.cursor()
            c.execute("SELECT DISTINCT archive, path FROM files WHERE NOT path=?", ['']) 
            channels = c.fetchall()
            channels = sorted(channels, key=itemgetter('path'))
            channels = sorted(channels, key=itemgetter('archive'), reverse=True)
            folders = []
            for chan in channels:
                folders.append(chan[0].lower() + ':' + chan[1])
            SelectedFolder = xbmcgui.Dialog().select('Select Folder for: ' + url, folders)
            utils.logdev(module,'SelectedFolder= %r ==> %r' % (SelectedFolder,folders[SelectedFolder]))
            if SelectedFolder < 0:
                command = actions[1]
                utils.logdev(module,'Command changed from Move to Folder to Move!')
        selectfrom = [command]
        for x in url.split('#'):
            selectfrom.append(x)
        utils.logdev(module,'selectfrom= %r' % selectfrom)
        selection = dialog.multiselect(ADDON.getAddonInfo('name') + ' [COLOR red]Select Items to act on![/COLOR]', selectfrom)
        utils.logdev(module,'selection= %r' % selection)
        if selection:
            for x in selection:
                utils.logdev(module,'x= %r' % x)
                if x > 1:
                    y = selectfrom[x]
                    utils.logdev(module,'command= %r, y= %r' % (command,y))
                    selecteditem = y.split('%')
                    urlY = selecteditem[0]
                    fileextt = selecteditem[1]
                    basePath = selecteditem[2]
                    archive = selecteditem[3]
                    utils.logdev(module,'command= %r, selecteditem= %r' % (command,selecteditem))
                    if command == actions[4]:            ###'Clear Command':
                        try:    ### Clear command
                            ADDON.setSetting('lastdatabaseaction','Clear Command')
                            urlY = urlY.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename - Accept + in filename
                            utils.logdev(module,'urlY= %r' % urlY)
                            conf = recordings.getFilesConnection()
                            recordings.createFileTable(conf)
                            c = conf.cursor()
                            commandY = ''
                            options = ''
                            recordings.addFileCommand(c, urlY, fileextt, basePath, archive, commandY, options)
                            conf.commit()
                            c.close() 
                        except Exception,e:
                            pass
                            utils.logdev(module,'Clear in DB error %r' % e)
                            
                    elif command == actions[3]:            ###'Delete':
                        ADDON.setSetting('lastdatabaseaction','Delete')
                        try:    ### Delete file
                            ADDON.setSetting('lastdatabaseaction','Delete File')
                            urlY = urlY.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
                            utils.logdev(module,'urlY= %r' % urlY)
                            conf = recordings.getFilesConnection()
                            recordings.createFileTable(conf)
                            c = conf.cursor()
                            commandY = 'delete'
                            options = urlY
                            recordings.addFileCommand(c, urlY, fileextt, basePath, archive, commandY, options)
                            conf.commit()
                            c.close() 
                        except Exception,e:
                            pass
                            utils.logdev(module,'Delete File in DB error %r' % e)
                        
                    elif command == actions[2]:            ###'Move to Folder':
                        ADDON.setSetting('lastdatabaseaction','Move to Folder')
                        try:    ### Set command to Move to folder
                            ### mode=1023&url=chan[0]&name=chan[6]&recordname=chan[1]&description=chan[2]
                            ### 0 filename, 1 ext, 2 path, 3 video, 4 description, 5 size, 6 archive, 7 updated, 8 created, 9 updatedHuman, 10 command, 11 options
                            urlY = urlY.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
                            commandY = 'movetofolder'
                            options = folders[SelectedFolder]
                            conf = recordings.getFilesConnection()
                            recordings.createFileTable(conf)
                            c = conf.cursor()
                            recordings.addFileCommand(c, urlY, fileextt, basePath, archive, commandY, options)
                            conf.commit()
                            c.close() 
                        except Exception,e:
                            pass
                            utils.logdev(module,'Move to Folder error %r' % e)
                        
                    elif command == actions[1]:            ###'Move':
                        try:    ### Set command in FilesDB to: Move information and subtitles if they are available
                            ### mode=1023&url=chan[0]&name=chan[6]&recordname=chan[1]&description=chan[2]
                            ### 0 filename, 1 ext, 2 path, 3 video, 4 description, 5 size, 6 archive, 7 updated, 8 created, 9 updatedHuman, 10 command, 11 options
                            ADDON.setSetting('lastdatabaseaction','Move')
                            urlY = urlY.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
                            utils.logdev(module,'urlY= %r' % urlY)
                            urlbasename = urlY # the file name only
                            utils.logdev(module,'urlbasename= %r' % urlbasename)
                            utils.logdev(module,'fileext= %r' % fileext)
                            if '[' in urlbasename:
                                utils.logdev(module,'urlbasename= %r' % urlbasename)
                                urlbase = urlbasename.split('[')[0]
                                urlbasefull = urlbasename
                            else:
                                urlbasefull = urlbasename
                                urlbase     = urlbasefull
                            utils.logdev(module,'urlbasefull= %r' % urlbasefull)
                            utils.logdev(module,'urlbase= %r' % urlbase)
                            urlbase = urlbase.replace('xxYYxx','&')
                            urlbasefull = urlbasefull.replace('xxYYxx','&')
                            conf = recordings.getFilesConnection()
                            recordings.createFileTable(conf)
                            c = conf.cursor()
                            commandY = 'move'
                            options = urlY
                            recordings.addFileCommand(c, urlY, fileextt, basePath, archive, commandY, options)
                            conf.commit()
                            c.close() 
                        except Exception,e:
                            pass
                            utils.logdev(module,'Move in DB error %r' % e)
                            
                    elif command == actions[0]:               ###'Rename':
                        try:    ### Set command in FilesDB to: Rename information and subtitles if they are available
                            ### mode=1023&url=chan[0]&name=chan[6]&recordname=chan[1]&description=chan[2]
                            ### 0 filename, 1 ext, 2 path, 3 video, 4 description, 5 size, 6 archive, 7 updated, 8 created, 9 updatedHuman, 10 command, 11 options
                            ADDON.setSetting('lastdatabaseaction','Rename')
                            urlY = urlY.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
                            utils.logdev(module,'urlY= %r' % urlY)
                            ###archive = name 
                            ###fileextt = recordname
                            if fileextt != '':
                                fileext = '.'+fileextt
                            else:
                                fileext = ''
                            ###basePath = description
                            ##urldirectorypath = os.path.dirname(url) # relative directory path
                            ##utils.logdev(module,'urldirectorypath= %r' % urldirectorypath)
                            urlbasename = urlY # the file name only
                            utils.logdev(module,'urlbasename= %r' % urlbasename)
                            utils.logdev(module,'fileext= %r' % fileext)
                            if '[' in urlbasename:
                                utils.logdev(module,'urlbasename= %r' % urlbasename)
                                urlbase = urlbasename.split('[')[0]
                                urlbasefull = urlbasename
                            else:
                                urlbasefull = urlbasename
                                urlbase     = urlbasefull
                            utils.logdev(module,'urlbasefull= %r' % urlbasefull)
                            utils.logdev(module,'urlbase= %r' % urlbase)
                            if urlbase != urlbasefull:
                                urlbaselastpart = urlbasefull.replace(urlbase,'...',1)
                            else:
                                urlbaselastpart = urlbasefull
                            urlbase = urlbase.replace('xxYYxx','&')
                            urlbasefull = urlbasefull.replace('xxYYxx','&')
                            dialog = xbmcgui.Dialog()
                            utils.logdev(module,'dialog.input %r' % x)
                            urlnewi = dialog.input('Enter new filename for: \n' + urlbaselastpart, defaultt=urlbase, type=xbmcgui.INPUT_ALPHANUM)
                            utils.logdev(module,'urlnewi= %r' % urlnewi)
                            if urlnewi != '':
                                urlnewi = recordings.latin1_to_ascii_force(urlnewi)   ### use only acceptable characters
                                utils.logdev(module,'urlbasefull= %r, urlbase= %r, urlnewi= %r' % (urlbasefull, urlbase, urlnewi))
                                urlnew = urlbasefull.replace(urlbase,urlnewi)
                                utils.logdev(module,'urlnew= %r' % urlnew)
                                conf = recordings.getFilesConnection()
                                recordings.createFileTable(conf)
                                c = conf.cursor()
                                commandX = 'rename'
                                options = urlnew
                                recordings.addFileCommand(c, urlY, fileextt, basePath, archive, commandX, options)
                                conf.commit()
                                c.close() 
                        except Exception,e:
                            pass
                            utils.logdev(module,'Rename in DB error %r' % e)
        xbmc.executebuiltin("Container.Refresh")
                                   
elif mode==1030:   ### Switch Addon
    dialog = xbmcgui.Dialog()
    addons = []
    try:
        SwFileFolder = os.path.join(xbmc.translatePath('special://masterprofile/'), 'addon_data','krogsbell.switchaddons')
        SwFile = os.path.join(SwFileFolder,'switchaddons.txt')
        if not os.path.exists(SwFileFolder):
            os.mkdir(SwFileFolder)
            open(SwFile, 'a').close()
        utils.logdev(module,'SwFile= %r' % SwFile)
        switchfile = open(SwFile, 'r')
        addonsO = switchfile.read()
        switchfile.close() 
        if not ADDONid in addonsO:
            addonsO += '\n' + ADDONname + ':' + ADDONid
            addonsO = addonsO.replace('\n\n\n\n','\n').replace('\n\n\n','\n').replace('\n\n','\n')
            LF = open(SwFile, 'w')
            LF.write(addonsO)
            LF.close()
        ADDON.setSetting('switchaddons',addonsO)
        if addonsO != '' :
            addonsO = addonsO.split('\n')
            for addon in addonsO:
                if addon != '':
                    utils.logdev(module,'addon= %r' % addon)
                    newaddon = addon.split(':')
                    if newaddon[1] != ADDONid:
                        pathTOaddon = os.path.join(xbmc.translatePath('special://home/addons'), newaddon[1])
                        if os.path.exists(pathTOaddon):
                            addons.append(newaddon)
    except Exception,e:
        pass
        addons.append(['ERROR',repr(e)])
    ###[['GlowIPTV','plugin.video.glowiptv.rec'],['DR NU','plugin.video.drnu'],['BBC iPlayer','plugin.video.iplayerwww'],['ITV Player','plugin.video.itv']]
    addons = sorted(addons)
    choises = []
    for choise in addons:
       choises.append(choise[0] + ': ' + choise[1])
    if len(choises) > 0:
        selected = dialog.select(ADDON.getAddonInfo('name') + ' - Select an Addon to switch to:', choises) ####################
        if selected != -1:
            utils.logdev(module,'selected Addon = %r - %r' % (addons[selected][0],addons[selected][1]))
            IDdoADDON = addons[selected][1]
            ###pathTOaddon = os.path.join(xbmc.translatePath('special://home/addons'), IDdoADDON)
            xbmc.executebuiltin('RunAddon(%s)' % (IDdoADDON))
            ###xbmc.executebuiltin('XBMC.RunPlugin(' +addons[selected][1] +')')
    """
    def installOPENaddon(IDdoADDON):    
        pathTOaddon = os.path.join(xbmc.translatePath('special://home/addons'), IDdoADDON)

        if not os.path.exists(pathTOaddon)==True:
            xbmc.executebuiltin('InstallAddon(%s)' % (IDdoADDON))
            xbmc.executebuiltin('SendClick(11)'), time.sleep(2), xbmcgui.Dialog().ok("Add-on Install", "The addon was not present. Please wait for installation to finish.")
        else:
            pass
        if os.path.exists(pathTOaddon)==True:
            xbmc.executebuiltin('RunAddon(%s)' % (IDdoADDON))
        else:
            xbmcgui.Dialog().ok("Add-on Error", "Could not install or open add-on. Please try again...")

    installOPENaddon("my.addon.id")
    """

elif mode==1040:
    try:    ### Convert video file to MP4  -c:v copy -c:a copy -c:s mov_text
        url = url.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
        utils.logdev(module,'url= %r' % url)
        urldirectorypath = os.path.dirname(url) # relative directory path
        utils.logdev(module,'urldirectorypath= %r' % urldirectorypath)
        urlbasename = os.path.basename(url) # the file name only
        utils.logdev(module,'urlbasename= %r' % urlbasename)
        fileext = '.' + url.split('.')[-1]
        utils.logdev(module,'fileext= %r' % fileext)
        if '[' in urlbasename:
            utils.logdev(module,'urlbasename= %r' % urlbasename)
            urlbase = urlbasename.split('[')[0]
            urlbasefull = urlbasename.replace(fileext,'',-1)
        else:
            urlbasefull = urlbasename.replace(fileext,'',-1)  ### Remove extension
            urlbase     = urlbasefull
        ###urlbasefull = os.path.basename(urlbasefull)
        utils.logdev(module,'urlbasefull= %r' % urlbasefull)
        ###urlbase = os.path.basename(urlbase)
        utils.logdev(module,'urlbase= %r' % urlbase)
        if urlbase != urlbasefull:
            urlbaselastpart = urlbasefull.replace(urlbase,'...',1)
        else:
            urlbaselastpart = urlbasefull
        urlbase = urlbase.replace('xxYYxx','&')
        urlbasefull = urlbasefull.replace('xxYYxx','&')
        dialog = xbmcgui.Dialog()
        urlnewi = dialog.input('Enter new fileextension for: \n' + url, defaultt='mp4', type=xbmcgui.INPUT_ALPHANUM)
        if urlnewi != '':
            ### Run convert-ffmpeg.py <filename> <new extension>
            ### Embed (Burn) Subtitles to the Video
            ### ffmpeg -i video.avi -vf subtitles=subtitle.srt out.mp4
            LoopCount = 0
            utils.logdev(module,'Converting file= %s' % url)
            ##nowHM=datetime.datetime.today().strftime('%H:%M:%S')
            LibPath = utils.libPath()
            extension = '.'+url.split('.')[-1]
            basefile = url.replace(extension,'',-1)
            utils.logdev(module,'basefile= %s' % basefile)
            subtitle = basefile + '.da.srt'
            subtitleen = basefile + '.en.srt'
            utils.logdev(module,'subtitle da file= %s' % subtitle)
            utils.logdev(module,'subtitle en file= %s' % subtitleen)
            burn = dialog.yesno(ADDON.getAddonInfo('name'), "[COLOR red]Burn Subtitles into Video File?[/COLOR]", '', "What Do You Want To Do","[COLOR red]Burn[/COLOR]","[COLOR green]Ignore[/COLOR]")
            utils.logdev(module,'burn subtitle into video file= %r' % burn)
            if os.path.exists(subtitle) and burn:
                ###utils.logdev(module,'burn subtitle file= %s' % subtitle)
                ###cmd = 'ffmpeg -i "' + subtitle + '" "' + basefile + '.ass"'
                ###utils.runCommand(cmd, LoopCount, LibPath)
                #cmd = 'ffmpeg -y -i "'+url+ '" -c copy "' + basefile +'.mp4' +'"' # Use seperately installed ffmpeg program ###
                #utils.runCommand(cmd, LoopCount, LibPath)
                cmd = 'ffmpeg -i "' + url +'" -vf subtitles="' + subtitle + '" "' + basefile + '_da_srt.'+urlnewi+'"'
                utils.runCommand(cmd, LoopCount, LibPath)
            elif os.path.exists(subtitleen) and burn:
                cmd = 'ffmpeg -i "' + url +'" -vf subtitles="' + subtitleen + '" "' + basefile + '_en_srt.'+urlnewi+'"'
                utils.runCommand(cmd, LoopCount, LibPath)
            else:
                utils.logdev(module,'ignore subtitle file= %s' % subtitle)
                cmd = 'ffmpeg -y -i "'+url+ '" -c copy "' + url.replace(url.split('.')[-1],urlnewi,-1) +'"' # Use seperately installed ffmpeg program ###
                utils.runCommand(cmd, LoopCount, LibPath)
            utils.notification('Converting %s [COLOR red]complete[/COLOR]' % url)
            ###xbmc.executebuiltin("Container.Refresh")
    except Exception,e:
        pass
        utils.logdev(module,'Convert video file FAILED %r' % e)

### mkchromecast [-s] --video -i "Spise med Price- Nordisk Odysse Sverige (1-6) 2018 [0h44m][DR NU][2019-04-30 12-25 KRO ].ts" --subtitles "Spise med Price- Nordisk Odysse Sverige (1-6) 2018 [0h44m][DR NU][2019-04-30 12-25 KRO ].da.srt"
elif mode==1041:
    try:    ### Play video file with mkchromecast if installed
      if chromecast:
        url = url.replace('aMp ','& ').replace('xXx','+') ### Accept &<space> in filename
        utils.logdev(module,'url= %r' % url)
        if chromecast != 'Active':
            LoopCount = 0
            utils.logdev(module,'Casting file= %s' % url)
            ##nowHM=datetime.datetime.today().strftime('%H:%M:%S')
            LibPath = utils.libPath()
            extension = '.'+url.split('.')[-1]
            basefile = url.replace(extension,'',-1)
            utils.logdev(module,'basefile= %s' % basefile)
            subtitle = basefile + '.da.srt'
            subtitleen = basefile + '.en.srt'
            utils.logdev(module,'subtitle file= %s' % subtitle)
            dialog = xbmcgui.Dialog()
            if os.path.exists(subtitle) and dialog.yesno(ADDON.getAddonInfo('name'), "[COLOR red]Use Danish Subtitles into Video File?[/COLOR]", '', "What Do You Want To Do","[COLOR red]Burn[/COLOR]","[COLOR green]Ignore[/COLOR]"):
                ### mkchromecast --video -i "xxx.ts" --subtitles "xxx.da.srt"
                cmd = 'mkchromecast --video -i "' + url +'" --subtitles "' + subtitle +'"'
                subpr = utils.runCommand(cmd, LoopCount, LibPath)
            elif os.path.exists(subtitleen) and dialog.yesno(ADDON.getAddonInfo('name'), "[COLOR red]Use English Subtitles into Video File?[/COLOR]", '', "What Do You Want To Do","[COLOR red]Burn[/COLOR]","[COLOR green]Ignore[/COLOR]"):
                ### mkchromecast --video -i "xxx.ts" --subtitles "xxx.da.srt"
                cmd = 'mkchromecast --video -i "' + url +'" --subtitles "' + subtitleen +'"'
                subpr = utils.runCommand(cmd, LoopCount, LibPath)
            else:
                utils.logdev(module,'ignore subtitle file= %s' % subtitle)
                ### mkchromecast --video -i "xxx.ts"
                cmd = 'mkchromecast --video -i "' + url +'"'
                subpr = utils.runCommand(cmd, LoopCount, LibPath)
            ADDON.setSetting('castsubprX',repr(subpr))
            utils.notification('Casting %s [COLOR red]complete[/COLOR]' % url)
            ###xbmc.executebuiltin("Container.Refresh")
    except Exception,e:
        pass
        utils.logdev(module,'Cast video file FAILED %r' % e)

### terminateSubpr(subpr) fra cast!
elif mode==1042:
  try: 
    if chromecast == 'Active':
        subpr = str(int(ADDON.getSetting('castsubpr')) +1)
        #subpr = ADDON.getSetting('castsubpr')
        subprcmd = ADDON.getSetting('castsubprcmd')
        dialog = xbmcgui.Dialog()
        if dialog.yesno(ADDON.getAddonInfo('name'), "[COLOR red]Stop Carsting?[/COLOR]", str(subpr)+': '+subprcmd, "What Do You Want To Do","[COLOR red]Stop Casting[/COLOR]","[COLOR green]Ignore[/COLOR]"):
            ### Ignore
            lockcause = 'ignore' ### Dummy command
        else:
            ### Stop casting
            lockcause = 'change' ### Dummy command
            ADDON.setSetting('castsubpr','')
            ADDON.setSetting('castsubprcmd','')
            utils.terminateSubpr(subpr)
  except:
    pass

elif mode==1043:  ### Open URL in browser
  try: 
    import webbrowser
    webbrowser.open(url)
  except Exception,e:
    pass
    utils.logdev(module,'Open URL in browser %r\nFAILED: %r' % (url,e))



elif mode==200:
    ###utils.logdev(module,'Mode=200: name= %s,recordname= %s,cat= %s,url= %s,description= %s'% (name,recordname,cat,url,description))
    PLAY_STREAM(name,url,iconimage,cat)
    
elif mode==210:
    #playcmd='plugin://plugin.video.wozboxntv/?url=url&mode=200&name=IPTV&iconimage=http://www.ntv.mx/res/content/tv/240.png&cat=%s'% cat
    # Show menuentry 
    ###menuname= 'Get IPTV from NTV - %s (%s)' % (name,cat)
    ###liz=xbmcgui.ListItem(menuname)
    ###xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url='',listitem = liz, isFolder = True) 
    
    startD = recordings.parseDate(datetime.now())
    endD = startD
    ###utils.logdev('default.py','PlayDefaultStream= %s' % repr(PlayDefaultStream))
    recordingsActive = []
    recordingsActiveAll = recordings.getRecordingsActive(startD,endD)
    ###utils.logdev('default.py','recordingsActiveAll= %s' % repr(recordingsActiveAll))
    for x in recordingsActiveAll:
        ###utils.logdev('default.py','x= %s' % repr(x))
        if not '[COLOR orange]' in x and not '[COLOR violet]' in x :
            ###utils.logdev('default.py','recordingsActive= %s' % repr(recordingsActive))
            recordingsActive.append(x)
            ###utils.logdev('default.py','recordingsActive= %s' % repr(recordingsActive))
    if (recordingsActive != []) and locking.isAnyRecordLocked():
        utils.notification('OVERLAPPING Recordings Warning: %s' % str(recordingsActive))
        #if (repr(recordingsActive) != "[]"):
        lockcause = repr(locking.RecordsLocked())
        #else:
        #   lockcause = repr(recordingsActive)
        dialog = xbmcgui.Dialog()
        if dialog.yesno(ADDON.getAddonInfo('name'), "[COLOR red]Stop recording?[/COLOR]", repr(recordingsActive), "What Do You Want To Do","[COLOR red]Stop recording[/COLOR]","[COLOR green]Ignore[/COLOR]"):
            ### Ignore and return
            try:
                xbmc.executebuiltin('RunAddon(' + recordname + ')')  ### Return
            except Exception,e:
                pass
                utils.logdev('PlayIPTV','Return to caling addon failed: %r' % e)
        #else:
            ### Continue
    
    # Show menuentry 
    menuname= 'Get IPTV from ' + ADDONname + ' - %s (%s)' % (name,cat)
    liz=xbmcgui.ListItem(menuname)
    xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url='url',listitem = liz, isFolder = True) 
    playcmd='plugin://' + ADDON.getAddonInfo('id') + '/?url=url&mode=200&name=%s&cat=%s'% (name,cat)
    ###utils.logdev('PlayIPTV',playcmd)
    xbmc.executebuiltin('PlayMedia(' + playcmd + ')')
    #PLAY_STREAM(name,url,iconimage,cat)
    try:
        xbmc.executebuiltin('RunAddon(' + recordname + ')')  ### Return
    except Exception,e:
        pass
        utils.logdev('PlayIPTV','Return to caling addon failed: %r' % e)

elif mode==260:   #clear recording markerflag
    marker = locking.markLockedList()  ### ADDON.getSetting('Recordings')
    if marker != '[]':
        dialog = xbmcgui.Dialog()
        if dialog.yesno(ADDON.getAddonInfo('name'), "[COLOR red]Clear Recording Marker?[/COLOR]", marker, "What Do You Want To Do","[COLOR red]Clear Recording Marker[/COLOR]","[COLOR green]Ignore[/COLOR]"):
            ### Ignore 
            test = 1
        else:
            ### Execute
            try:
                ###ADDON.setSetting('Recordings','')  ### Return
                locking.markUnlockAll()
            except Exception,e:
                pass
                utils.logdev(module,'Clear Recording Marker failed: %r' % e)
        
elif mode==210000:  ### Disabled
    #playcmd='plugin://plugin.video.wozboxntv/?url=url&mode=200&name=IPTV&iconimage=http://www.ntv.mx/res/content/tv/240.png&cat=%s'% cat
    # Show menuentry 
    menuname= 'Get IPTV from ' + ADDONname + ' - %s (%s)' % (name,cat)
    liz=xbmcgui.ListItem(menuname)
    xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url='',listitem = liz, isFolder = True) 
    #playcmd='plugin://' + ADDON.getAddonInfo('id') + '/?url=url&mode=200&name=%s&cat=%s'% (name,cat)
    #utils.logdev('PlayIPTV','PlayMedia(' + playcmd + ')')
    #xbmc.executebuiltin('PlayMedia(' + playcmd + ')')
    
    playcmd='plugin://' + ADDON.getAddonInfo('id') + '/?url=url&mode=200&name=%s&cat=%s'% (name,cat)
    ###utils.logdev('PlayIPTV',playcmd)
    xbmc.executebuiltin('PlayMedia(' + playcmd + ')')
    #PLAY_STREAM(name,url,iconimage,cat)
    try:
        xbmc.executebuiltin('RunAddon(' + recordname + ')')  ### Return
    except Exception,e:
        pass
        utils.logdev('PlayIPTV','Return to caling addon failed: %r' % e)

elif mode==2009:  # Record or play link from FTVguide or TV Guide
    if ADDON.getSetting('RecordFromTVguide')=='true':
        try:
            recordduration = int(ADDON.getSetting('RecordFromTVguideDurationMinutes'))
        except:
            pass
            recordduration = 120
        if recordduration < 10: recordduration = 120
        now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        startDate =  (datetime.today() + timedelta(minutes=1)).strftime('%Y-%m-%d %H:%M:%S')
        endDate = (datetime.today() + timedelta(minutes=recordduration)).strftime('%Y-%m-%d %H:%M:%S')
        print 'scheduleRecording(cat= %s, startDate= %s, endDate= %s, name= %s, url= %s)' % (cat, startDate, endDate, name, url)
        scheduleRecording(cat, startDate, endDate, name, url)
    else:
        PLAY_STREAM(name,url,iconimage,cat)
        
elif mode==2010:  # Record link from dr bonanza
    ###utils.logdev(module,'Record(name= %s, uri= %s,playpath= %s, app= %s)' % (name, uri, playpath, app))
    if ADDON.getSetting('RecordFromTVguide')=='true':
        Record(name, uri, playpath, app)
        
elif mode==2011:  # Record link from drnu/filmon
    if ADDON.getSetting('RecordFromTVguide')=='true':
        Recordffmpeg(name, uri, playpath, app, description, auth, sourceApp)

elif mode==2012:  # Record link from unlim.tv
    cat = ADDON.getSetting('recordfromunlim') 
    name = ADDON.getSetting('recordfromunlimtitle')
    duration = ADDON.getSetting('recordfromunlimduration') 
    description = ADDON.getSetting('recordfromunlimdescription') 
    Recordffmpeguri(name, uri, duration, description)

elif mode==2013:  # Record Archive link from unlim.tv
    utils.logdev(module,'mode==2013 rri= %r' % uri)
    cat = ADDON.getSetting('recordfromunlim')[3:]
    name = ADDON.getSetting('recordfromunlimtitle')
    duration = ADDON.getSetting('recordfromunlimduration') 
    startDate = ADDON.getSetting('recordfromunlimstartdate') 
    description = ADDON.getSetting('recordfromunlimdescription') 
    ### 2017-05-21:16-00
    time_tuple = time.strptime(startDate, "%Y-%m-%d:%H-%M")
    startDateTS = int(time.mktime(time_tuple))
    ### Get url: '/channels/get-record/' + chId + '/' + evtStart + '/' + evtDuration
    ### https://www.unlim.tv:443/channels/get-record/949/1557407400/6000
    url = 'https://www.unlim.tv:443/channels/get-record/'+cat+'/'+str(startDateTS)+'/'+duration
    utils.logdev(module,'Channel uri= %r' % uri)
    utils.logdev(module,'Archive url= %r' % url)
    file = urllib2.urlopen(url)
    data = file.read()
    file.close()
    ChannelFile = os.path.join(datapath,ADDONid) + '.UNL'
    with open(ChannelFile,'wb') as output:
        output.write(data)
    d = json.loads(data)
    utils.logdev(module,'json.loads(data)= %r' % d)
    arcurl = d['body']
    utils.logdev(module,'arcurl= %r' % arcurl)
    Recordffmpeguri(name, arcurl, duration, description)
        
elif mode==2020: ### Watch Archive
    setComandMode('Watch Archive',mode)
    ###http://roq-tv.net:25461/streaming/timeshift.php?username=XXX&password=XXXX&stream=276&duration=120&start=2017-05-21:16-00
    ###duration = endDate - startDate  ### in minutes
    ###duration = '120'
    ###start    = startDate.strftime('%Y-%m-%d:%H-%M')
    ###url = 'http://roq-tv.net:25461/streaming/timeshift.php?username='+ADDON.getSetting('user')+'&password='+ADDON.getSetting('password')+'&stream='+cat+'&duration='+duration+'&start='+start
    ###utils.logdev(module,'2020 url= ' + url)
    ###utils.logdev(module,'2020 description= ' + description)
    ###playmedia(url)
    name = recordname.replace('[COLOR salmon]','').replace('[/COLOR]','')
    ###utils.logdev(module,'2020 (name= %r \nurl= %r \niconimage= %r \ncat= %r \ndescription= %r )' % (recordname,url,iconimage,cat,description))
    PLAY_CATCHUP(recordname,url,iconimage,cat,description)
    ###PLAY_STREAM(name,url,iconimage,cat)
    ###liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    ###liz.setInfo( type="Video", infoLabels={ "Title": name} )
    ###liz.setProperty("IsPlayable","true")
    ###liz.setPath(url)
    ###xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz) 
    
elif mode==2001:   ### Record
    setComandMode('Record',mode)
    if recordname == '' and not 'http' in cat:
        recordname = recordings.titleFromCat(cat)
    Vtoken= '[MOVIES]'   ### 2019-02-09 Remove Vtoken from recordname if it is in the start
    if Vtoken in recordname:
        recordnamenew = recordname.split(Vtoken)
        if recordnamenew[0] == '':
            recordname = recordname.replace(Vtoken,'',1)
        
    if not ('Recursive' in recordname):
        ###utils.logdev(module,'record0 (name = %s, uri= %s, playpath= %s, cat= %s, startDate= %s, endDate= %s, recordname= %s, description= %s)' % (name, uri, playpath,cat,startDate, endDate, recordname, description))
        cathandled = False
        KrogsbellAddOns = definition.getKrogsbellAddOns()   ###<<<<<<< Needs update 2018-06-28
        utils.logdev(module,'KrogsbellAddOns= %r' % KrogsbellAddOns)
        for kaddon in KrogsbellAddOns:
            utils.logdev(module,'kaddon= %r' % kaddon)
            try:
                kaddonID = kaddon.split('.')[2][:3].upper()
                taddonID = ADDONid.split('.')[2][:3].upper()
            except Exception, e:
                pass
                EpgError = 'Error in getting AddOn ID\n' + repr(e) 
                kaddonID = ''
                taddonID = ''
            utils.logdev(module,'kaddonID= %r' % kaddonID)
            utils.logdev(module,'taddonID= %r' % taddonID)
            if kaddonID != '' and kaddonID != taddonID:
                try:
                    nADDON = xbmcaddon.Addon(id=kaddon)
                    naddon = nADDON.getAddonInfo('name')
                    NTVchannels = xbmc.translatePath(nADDON.getAddonInfo('profile') + 'channels.csv')
                    NTVcat = cat.replace(kaddonID,'')   ###<<<<<<< Needs update 018-06-21
                    if kaddonID == cat[:3]:
                        ### 2012 at Wozboxntv ==> recordings.add(cat, startDate, endDate, recordname, description)
                        cathandled = True
                        cat = NTVcat
                        name = urllibquote_plus('Recording set by ' + ADDONname)
                        startDate = urllibquote_plus(startDate)
                        endDate = urllibquote_plus(endDate)
                        recordname = urllibquote_plus(recordname)
                        description = description.replace(' ','AAabBB').replace('?','aAabBb').replace('=','BBabAA').replace(',','###').replace('&','AaAaA').replace('\n','NlNlNl')
                        cmd = 'plugin://' + kaddon + '/?mode=210&cat='+cat+'&url=url&name=' + name + '&recordname='+ recordname +'&startDate='+ startDate +'&endDate='+ endDate +'&description='+ description
                        utils.logdev(module,'Record at %s cmd= %r' % (naddon,cmd))
                        xbmc.executebuiltin("RunPlugin(" + cmd + ")")
                except Exception,e:
                    pass
                    utils.logdev(module,'NTVchannels '+kaddon+' Error= %r' % e)
        if not cathandled :
            try:
                if recordname == '':
                    if not name == '':
                        recordname = name  ###
                    else:
                        recordname = 'recordname and name are empty' 
                ###utils.logdev(module,'record00 (name = %s, uri= %s, playpath= %s, cat= %s, startDate= %s, endDate= %s, recordname= %s, description= %s)' % (name, uri, playpath,cat,startDate, endDate, recordname, description))
                if '[COLOR lightgreen]' in recordname:
                    if '[/COLOR]' in recordname:
                        recordname = recordname.split('[/COLOR]',1)[1]
                if '[COLOR salmon]' in recordname:
                    recordname = recordname.split('[COLOR salmon]',1)[1]
                if '[COLOR yellow]' in recordname:
                    recordname = recordname.split('[COLOR yellow]',1)[1]
                if '[COLOR cyan]' in recordname:
                    recordname = recordname.split('[COLOR cyan]',1)[1]
            except:
                pass
                ###utils.logdev(module,'record01 (name = %s, uri= %s, playpath= %s, cat= %s, startDate= %s, endDate= %s, recordname= %s, description= %s)' % (name, uri, playpath,cat,startDate, endDate, recordname, description))
            try:
                if cat == '':
                    cat = recordings.catFromUrl(url)  ###
                uri=url 
                ###utils.logdev(module,'record02 (name = %s, uri= %s, playpath= %s, cat= %s, startDate= %s, endDate= %s, recordname= %s, description= %s)' % (name, uri, playpath,cat,startDate, endDate, recordname, description))
            except:
                pass
                uri = recordings.urlFromCat(cat)  ### 
                ###utils.logdev(module,'record03 (name = %s, uri= %s, playpath= %s, cat= %s, startDate= %s, endDate= %s, recordname= %s, description= %s)' % (name, uri, playpath,cat,startDate, endDate, recordname, description))
            ###utils.logdev(module,'record1 (name = %s, uri= %s, playpath= %s, cat= %s, startDate= %s, endDate= %s, recordname= %s, description= %s)' % (name, uri, playpath,cat,startDate, endDate, recordname, description))
            ext = uri.split('.')[-1].lower()
            reclock = locking.isAnyRecordLocked()
            ###if ('/movie/' in uri or ext == 'mp4' or ext == 'mkv' or ext == 'avi' or ext == 'm4v') and not reclock:
            if ('/movie/' in uri or ext == 'mp4' or ext == 'mkv' or ext == 'avi' or ext == 'm4v'):
                Recordffmpeg(recordname, uri, playpath, app, description.replace(' ','AAabBB').replace('?','aAabBb').replace('=','BBabAA').replace(',','###').replace('&','AaAaA').replace('\n','NlNlNl'), auth,sourceApp)
            ###elif ('/movie/' in uri or ext == 'mp4' or ext == 'mkv' or ext == 'avi' or ext == 'm4v') and reclock:
            ###    utils.notification('Recording something already \nTry later')
            else:
                utils.notification('Schedule recording: cat= ' + cat+ ' \nTitle: '+recordname)  ### 2017-09-21
                scheduleRecording(cat, startDate, endDate, recordname, description.replace(' ','AAabBB').replace('?','aAabBb').replace('=','BBabAA').replace(',','###').replace('&','AaAaA'))   ###.replace('\n','NlNlNl'))
    ###xbmc.executebuiltin("Container.Refresh")
utils.logdev(module,'locking.isScanLocked(EPG_update)= %r' % locking.isScanLocked('EPG_update'))
utils.logdev(module,'ADDON.getSetting(blockduringepgimport) == true %r' % ADDON.getSetting('blockduringepgimport'))
if not (locking.isScanLocked('EPG_update') and ADDON.getSetting('blockduringepgimport') == 'true'):  ### 2018-07-07
    if mode==None or url==None:
        ###try:
            ADDON.setSetting('LastView', 'CATEGORIES')
            CATEGORIES()
        ###except Exception, e:
        ### pass
            ###utils.logdev(module,'Error in showing Categories: ' + repr(e))
        ### utils.notification('[COLOR red]Error in showing Categories[/COLOR] - [COLOR green]Check your internet connection![/COLOR]')

    elif mode==2:
        ###try:
            ###utils.logdev(module,'Mode=2: name= %s,recordname= %s,cat= %s,url= %s,description= %s'% (name,recordname,cat,url,description))
            ADDON.setSetting('LastView', 'CHANNELS')
            CHANNELS(name,cat)
        ###except Exception, e:
        ### pass
        ### utils.logdev(module,'Error in showing Channels: ' + repr(e))
        ### utils.notification('[COLOR red]Error in showing Channels[/COLOR] - [COLOR green]Check your internet connection![/COLOR]')

    elif mode==3:
        ADDON.setSetting('LastView', 'RECORDINGSPLANNED')
        RecordingsPlanned()

    elif mode==4:
        ADDON.setSetting('LastView', 'TVGUIDE')
        TVGUIDE(name,cat)

    elif mode==5:
        ADDON.setSetting('LastView', 'GENRE')
        GENRE(name,cat)

    elif mode==7:
        
        setComandMode('Add Favorite',mode)
        ###utils.logdev(module,'ADD_FAV cat= %r, \nurl= %r, \nuri= %r' % (cat, url, uri))
        ###if cat == '':    ###removed 2018-12-01
        ###    cat=recordings.catFromUrl(url)
        ADD_FAV(cat)
        ###xbmc.executebuiltin("Container.Refresh")
    
    elif mode==77:
        
        setComandMode('Remove Favorite',mode)
        if cat == '':
            cat=recordings.catFromUrl(url)
        DEL_FAV(cat)
        xbmc.executebuiltin("Container.Refresh")
    
    elif mode==16:
        ADDON.setSetting('LastView', 'ntvCATEGORIES')
        ntvCATEGORIES()

    elif mode==17:
        ADDON.setSetting('LastView', 'FAVORITES')
        FAVORITES()
    
    elif mode==18:
        ADDON.setSetting('LastView', 'ARCHIVE')
        ARCHIVE()

    elif mode==19:
        ADDON.setSetting('LastView', 'MYSELECTEDCHANNELS')
        MYSELECTEDCHANNELS()

    elif mode==190:
        ADDON.setSetting('LastView', 'NTVCHANNELS')
        try:
            addonID = description.split('(')[1].split(')')[0].upper()
        except Exception,e:
            pass
            addonID = repr(e)
        ADDON.setSetting('LastaddonID', addonID)
        NTVCHANNELS(addonID)
        
    elif mode==191:
        ADDON.setSetting('LastView', 'TVawayCHANNELS')
        TVawayCHANNELS()
        
    elif mode==20:
        ADDON.setSetting('LastView', 'HIDDENCHANNELS')
        HIDDENCHANNELS()

    elif mode==21:
        ADDON.setSetting('LastView', 'NEWCHANNELS')
        NEWCHANNELS()

    elif mode==22:
        ###try:
            ###utils.logdev(module,'Mode=22: name= %s,recordname= %s,cat= %s,url= %s,description= %s'% (name,recordname,cat,url,description))
            ADDON.setSetting('LastView', 'CHANNELSROQOLD')
            CHANNELSROQOLD(name,cat,url,description)
        ###except Exception, e:
        ### pass
        ### ###utils.logdev(module,'Error in showing Channels: ' + repr(e))
        ### utils.notification('[COLOR red]Error in showing Channels[/COLOR] - [COLOR green]Check your internet connection![/COLOR]')

    elif mode==23:
        ###try:
            ###utils.logdev(module,'Mode=2: name= %s,recordname= %s,cat= %s,url= %s,description= %s'% (name,recordname,cat,url,description))
            ADDON.setSetting('LastView', 'CHANNELSROQ')
            CHANNELSROQ()
        ###except Exception, e:
        ### pass
        ### utils.logdev(module,'Error in showing Channels: ' + repr(e))
        ### utils.notification('[COLOR red]Error in showing Channels[/COLOR] - [COLOR green]Check your internet connection![/COLOR]')
            
    elif mode==24:  ### Set Hidden
        
        setComandMode('Set Hidden',mode)
        if cat == '':
            cat=recordings.catFromUrl(url)
        ###utils.logdev(module,'elif mode==24:  ### Set Hidden cat= %r, url= %r' % (cat,url))
        SET_HIDE(cat)
        xbmc.executebuiltin("Container.Refresh")

    elif mode==25:  ### Remove Hidden
        
        setComandMode('Remove Hidden',mode)
        ###utils.logdev(module,'elif mode==25:  ### Remove Hidden cat= %r, url= %r' % (cat,url))
        if cat == '':
            cat=recordings.catFromUrl(url)
        DEL_HIDE(cat)
        xbmc.executebuiltin("Container.Refresh")

    elif mode==26:  ### Recursive Search View
        ADDON.setSetting('LastView', 'RECURSIVECHANNELS')
        RECURSIVECHANNELS()

    elif mode==27:  ### Set Recursive
        
        setComandMode('Set Recursive',mode)
        if cat == '':
            cat=recordings.catFromUrl(url)
        SET_RECURSIVE(cat)
        ###xbmc.executebuiltin("Container.Refresh")

    elif mode==28:  ### Remove Recursive
        
        setComandMode('Remove Recursive',mode)
        if cat == '':
            cat=recordings.catFromUrl(url)
        DEL_RECURSIVE(cat)
        xbmc.executebuiltin("Container.Refresh")
        
    elif mode==29:  ### EXIT - Back to Kodi
        stoptimeshift()
        exit()
    
    elif mode==30:  ### Stop Timeshift
        stoptimeshift()
    
    elif mode==103:
        deleteDir(url)
        xbmc.executebuiltin("Container.Refresh")
        
    elif mode==104:
        #recordPath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
        #ADDON.setSetting('record_display_path',recordPath)
        DataBases()
        #xbmc.executebuiltin("Container.Refresh")
        
    elif mode==105:
        #recordPath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
        #print 'restoreBackupFile(url)= %s' % (repr(url))
        recordings.restoreBackupDataBase(url)

    elif mode==106:
        #recordPath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
        #print 'restoreBackupFile(url)= %s' % (repr(url))
        recordings.restoreSetupXml(url)
    
    elif mode==107:
        #recordPath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
        #print 'restoreBackupFile(url)= %s' % (repr(url))
        recordings.restoreRecursiveRecordings(url)
    
    elif mode==108:
        recordings.delAllChannels()
        
    elif mode==109:
        recordings.delAllPlannedPrograms()
    
    elif mode==110:
        recordings.delNewEPGPrograms()
    
    elif mode==111:
        recordings.delOldEPGPrograms()
    
    elif mode==112:
        recordings.ftvntvlist()

    elif mode==113:  ### Restore Channels
        recordings.RestoreChannels(url)

    elif mode==114:  ### Restore EPG
        recordings.RestoreEPG(url)  

    elif mode==115:  ### Update EPG now
        recordings.EPGOnce() 

    elif mode==116:  ### Clear the Database. Stop all planned recordings, reset database and start a new EPG import
        dialog = xbmcgui.Dialog()
        if dialog.yesno(ADDON.getAddonInfo('name'), "[COLOR red]Delete database and start all over?[/COLOR]", '', "What Do You Want To Do","[COLOR red]Delete[/COLOR]","[COLOR green]Ignore[/COLOR]"):
            ### Ignore
            lockcause = 'ignore' ### Dummy command
        else:
            ### Stop recording and record new
            lockcause = 'change' ### Dummy command
            recordings.deleteDataBase()
            xbmc.sleep(1000)
            recordings.EPGOnce()
    
    elif mode==117:  ### Restore Favorites
        recordings.RestoreFavorites(url)  
    
    elif mode==118:  ### Restore Favorites
        recordings.RestoreRecursiveChannels(url)  
    
    elif mode==1004:   ### Select TV Guide Channel
        ###utils.logdev(module,'Mode=200: name= %s,recordname= %s,cat= %s,url= %s,description= %s'% (name,recordname,cat,url,description))
        SELECT_TV_GUIDE_CHANNEL(name,url,iconimage,cat)
    
    
    elif mode==2002:   ### delete record 2002
        
        setComandMode('Delete Recording',mode)
        ###utils.logdev('delete record 2002', '(cat= %r, startDate= %r, endDate= %r, name= %r, recordname= %r, description= %r)' % (cat, startDate, endDate, name, recordname, description))
        delRecording(cat, startDate, endDate, recordname)
        xbmc.executebuiltin("Container.Refresh")

    elif mode==2003:         ### modifyRecording 2003
        
        setComandMode('Modify Recording',mode)
        ###utils.logdev('modifyRecording 2003', '(cat= %r, startDate= %r, endDate= %r, name= %r, recordname= %r, description= %r)' % (cat, startDate, endDate, name, recordname, description))
        modifyRecording(cat, startDate, endDate, recordname, description)
        xbmc.executebuiltin("Container.Refresh")
        
    elif mode==2004:  ### Create ini and other startupfiles in debug mode with refresh
        if ADDON.getSetting('DebugRecording')=='true': 
            recordings.ftvntvlist()
        xbmc.executebuiltin("Container.Refresh")

    elif mode==2005:   ### Set Recursive
        
        setComandMode('Set Recursive',mode)
        recursiveRecordname = 'Recursive:' + recordname.split('[')[0].split(':')[0]
        if not ('Recursive' in recordname) and (recursiveRecordname != 'Recursive:'):
            if cat[0:4].lower() != 'http':
                scheduleRecording(cat, startDate, endDate, 'Recursive:' + recordname.split('[')[0].split(':')[0],description)
                if not recordings.isChannelRecursive(cat):
                    SET_RECURSIVE(cat)  ### 2019-01-06
        xbmc.executebuiltin("Container.Refresh")

    elif mode==2006:   ### DISABLE RECORD
       
        setComandMode('Disable Record',mode)
        u = '#cat=' + cat + '#startDate=' + startDate +'#endDate=' + endDate + '#name=' + name + '#recordname=' + recordname + '#description=' + description + '#'
        if isHighlighted(u):
            for ux in higlights:
                catx        = param(u,'cat')
                startDatex  = param(u,'startDate')
                endDatex    = param(u,'endDate')
                namex       = param(u,'recordname')
                recordnamex = param(u,'name')
                descriptionx = param(u,'description')
                if not ('[COLOR orange]' in recordname):
                    delRecording(catx, startDatex, endDatex, recordnamex)
                    ###utils.logdev(module,'2006 scheduleRecording(cat= %r, startDate= %r, endDate= %r, * + recordname= %r, description= %r)' % (cat, startDate, endDate, '*' + recordname, description))
                    scheduleRecording(catx, startDatex, endDatex, '*' + recordnamex, descriptionx)
        else:
            if not ('[COLOR orange]' in recordname):
                delRecording(cat, startDate, endDate, recordname)
                ###utils.logdev(module,'2006 scheduleRecording(cat= %r, startDate= %r, endDate= %r, * + recordname= %r, description= %r)' % (cat, startDate, endDate, '*' + recordname, description))
                scheduleRecording(cat, startDate, endDate, '*' + recordname, description)
        xbmc.executebuiltin("Container.Refresh")
        
    elif mode==2007:

        setComandMode('Find Recursive',mode)
        if ('Recursive' in recordname):
            locking.scanUnlockAll()
            findrecursive.RecursiveRecordingsPlanned('NotAllFavorites')
        ###xbmc.executebuiltin("Container.Refresh")
     
    elif mode==2008:  ### Search Channel, VOD or TV Series
        utils.logdev('Search Channel, VOD or TV Series','Start')
        
        setComandMode('Search Channel, VOD or TV Series',mode)
        ADDON.setSetting('LastView', 'CHANNELSSEARCH')
        CHANNELSSEARCH()
        
    elif mode==2059:  ### Backup Database and files
        recordings.backupSetupxml()
        recordings.backupDataBase()
        utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] Backup Ended')
        
    elif mode==2050:  ### Search favorite programs
        utils.logdev(module,'Search favorite programs: Start')
        ADDON.setSetting('LastView', 'PROGRAMSEARCH')
        PROGRAMSEARCH()
      
    elif mode==2500:  ### Make a Clone of this Addon
        utils.logdev(module,'Make a Clone of this Addon: Start')
        ### Get new ID
        newADDONid = GetText('ID of new AddOn',ADDONid)
        newADDONname = GetText('Name of new AddOn',ADDONname)
        if newADDONid and newADDONid != ADDONid and newADDONname and newADDONname != ADDONname:
            utils.logdev(module,'ID of new AddOn= %r' % newADDONid)
            ### Copy all files to new folder
            progpath   = ADDON.getAddonInfo('path')
            progpathnew= progpath.replace(ADDONid,newADDONid)
            utils.logdev(module,'progpathnew= %r' % progpathnew)
            if not os.path.isdir(progpathnew):
                ### os.makedirs(progpathnew)   ### shutil creates foldersf
                shutil.copytree(progpath,progpathnew)
                ### Update addon.xml and definitions.py
                addonxml = os.path.join(progpathnew, 'addon.xml')
                file = open(addonxml,'r')
                desc = file.read()
                file.close()
                desc = desc.replace(ADDONid,newADDONid).replace(ADDONname,newADDONname)
                ###utils.makeOldFile(addonxml)
                with open(addonxml,'wb') as output:
                    output.write(desc)
                definitionpy = os.path.join(progpathnew, 'definition.py')
                file = open(definitionpy,'r')
                desc = file.read()
                file.close()
                desc = desc.replace(ADDONid,newADDONid).replace(ADDONname,newADDONname)
                ###utils.makeOldFile(definitionpy)
                with open(definitionpy,'wb') as output:
                    output.write(desc)
                ### Zipfolder to make installable file
                ###shutil.make_archive('/home/code/test_dicoms','zip','/home/code/',        'test_dicoms')
                addonfolder = progpathnew.replace(newADDONid,'')
                shutil.make_archive(progpathnew, 'zip', addonfolder, newADDONid)
                ### Delete folder
                shutil.rmtree(progpathnew)
                utils.notificationsend('[COLOR lightgreen][B]' + newADDONname + '[/B][/COLOR] Created zip to install clone of ' + ADDONname)
                
    elif mode==3000:  ### Grab from TV Guide
        findtvguidenotifications.findtvguidenotifications()
        utils.logdev('findtvguidenotifications.py','Ended')
        ###xbmc.executebuiltin("Container.Refresh")  ### Do not work here

    elif mode==4000:

        recordings.ftvntvlist() ### Force INI file
        recordings.delOldEPGPrograms()  ### 7 days old programs and 2 days old channels
        """ Force EPG Update
        locking.scanUnlock('EPG_update')
        nameAlarmEPGonce = ADDONname +'updateepgonce' 
        scriptEPG   = os.path.join(ADDON.getAddonInfo('path'), 'updateepg.py')
    
        cmdEPGonce = 'AlarmClock(%s,RunScript(%s,%s),00:00:00,silent)' % (nameAlarmEPGonce.encode('utf-8', 'replace'), scriptEPG.encode('utf-8', 'replace'), 'once')
        xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmEPGonce)
        xbmc.executebuiltin(cmdEPGonce)
        """
       
        updatedrecordings = recordings.finddoubletes()  ### Find double programs
        if updatedrecordings >= 1:
            recordings.reschedule() ### Set EPG program start
        
        
    elif mode==4500:    ### Test
        URI='plugin://plugin.video.unlimtv/?url=url&mode=210&source='+ADDONid+'&cat=967' 
        ADDON.setSetting('recordfromunlim','967') 
        ADDON.setSetting('recordfromunlimtitle','Titel på optagelsen')
        ADDON.setSetting('recordfromunlimduration','3600') 
        ADDON.setSetting('recordfromunlimdescription','Her er så beskrivelsen af optagelsen') 
        utils.logdev(module,'Get uri from unlimtv: URI= %r' % URI)
        tries    = 0
        maxTries = 10
        maxSleep = 500
        try:
            utils.logdev(module,repr(URI))
            xbmc.executebuiltin('XBMC.RunPlugin(%s)' % URI) 
            xbmc.sleep(maxSleep)
        except:
            pass 
    
    elif mode==5000:   ### SELECT
        try:
            utils.logdev(module,'Select! activated on cat= %r, sys.argv[1]= %r ' % (cat,sys.argv[1]))
            utils.logdev(module,'10 higlights= %r' % higlights)
            ###ThisHighlight = '#cat=' + cat + '#startDate=' + startDate +'#endDate=' + endDate + '#name=' + name + '#recordname=' + recordname + '#'
            ThisHighlight = '#cat=' + cat + '#startDate=' + startDate +'#endDate=' + endDate + '#name=' + name + '#recordname=' + recordname + '#description=' + description + '#'
            ThisHighlight = ThisHighlight.replace(' [COLOR red][B]SELECTED[/B][/COLOR]','',1).replace('[COLOR red][B]¤[/B][/COLOR]','',1)
            RemoveHiglight = False
            if ThisHighlight in higlights:
                RemoveHiglight = True
            else:
                higlights.append(ThisHighlight)
            utils.logdev(module,'11 higlights= %r' % higlights)
            allhiglights = ''
            i = 0
            for x in higlights:
                i += 1
                utils.logdev(module,'12 i= %r, x= %r' % (i,x))
                if x == ThisHighlight and RemoveHiglight == True:
                    x = ''
                if allhiglights != '' and x != '':
                    allhiglights = x + '¤¤¤¤' + allhiglights
                elif x != '':
                    allhiglights = x
            ADDON.setSetting('higlights',allhiglights)
            utils.logdev(module,'13 allhiglights= %r' % allhiglights)
            """
            apikeyS = Search('apikey')
            apikey = xbmcplugin.getSetting(int(sys.argv[1]), id=apikeyS)
            xbmcgui.Dialog().ok( repr(apikeyS), repr(apikey))
            utils.logdev(module,'Select! before= %r, after= %r ' % (apikeyS,apikey))
            utils.logdev(module,'Select! liz= %r' % (liz))
            selected = liz.getSelectedItem().isSelected()
            liz.getSelectedItem().select(True)
            selected1 = liz.getSelectedItem().isSelected()
            utils.logdev(module,'Select! before= %r, after= %r ' % (selected,selected1))
            """
        except Exception,e:
            pass
            utils.logdev(module,'Select! activated on cat= %r, Exception= %r ' % (cat,e))
        xbmc.executebuiltin("Container.Refresh")
        """
        isSelected(...)
        isSelected() --Returns the listitem's selected status.
        example:
            - is = self.list.getSelectedItem().isSelected()
        
        select(...)
        select(selected)--Sets the listitem's selected status.
        selected : bool - True=selected/False=not selected
        example:
        - self.list.getSelectedItem().select(True)
        
        getSetting(...)
        getSetting(handle, id)--Returns the value of a setting as a string.
         
        handle : integer - handle the plugin was started with.
        id : string - id of the setting that the module needs to access.
         
        *Note, You can use the above as a keyword.
         
        example:
            - apikey = xbmcplugin.getSetting(int(sys.argv[1]), 'apikey')
        """
    elif mode==5001:   ### Deselect All
        try:
            ADDON.setSetting('higlights','')
            utils.logdev(module,'Deselect All! ')
            
        except Exception,e:
            pass
            utils.logdev(module,'Deselect all! activated on cat= %r, Exception= %r ' % (cat,e))
        xbmc.executebuiltin("Container.Refresh")
        
    elif mode == 6000:     ### Delete EPG Program Entry
        ### mode=6000&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s
        utils.logdev(module, 'Delete EPG Program Entry: mode=6000&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s' % (url, cat, startDate, endDate, recordname, description))
        dialog = xbmcgui.Dialog()
        ###dialog.ok('[B]' + ADDONname + '[/B]','Delete EPG Program Entry?','url=%s\cat=%s\nstartDate=%s\nendDate=%s\nrecordname=%s\ndescription=%s' % (url, cat, startDate, endDate, recordname, description))
        try:
            channel = recordings.ChannelName(cat)
            time_tuple = time.strptime(startDate, "%Y-%m-%d %H:%M:%S")
            timestampSD = int(time.mktime(time_tuple))
            time_tuple = time.strptime(endDate, "%Y-%m-%d %H:%M:%S")
            timestampED = int(time.mktime(time_tuple))
            epgchannel= recordings.EPG_ChannelFromCat(cat)
        except Exception,e:
            pass
            channel = repr(e)
            timestampSD = ''
            timestampED = ''
            epgchannel = ''
        if dialog.yesno('[B]' + ADDONname + '[/B]', '[CR] [CR] [CR][COLOR red]Delete EPG Program Entry?[/COLOR]','\nepgchannel=%r\nchannel=%s\nurl=%s\ncat=%s\nstartDate=%s = %r\nendDate=%s = %r\nrecordname=%s\ndescription=%s' % (epgchannel, channel, url, cat, startDate, timestampSD, endDate, timestampED, recordname, description),'','[COLOR red]Delete[/COLOR]','[COLOR green]Ignore[/COLOR]'):
            ### Ignore
            lockcause = 'ignore' ### Dummy command
        else:
            ### Delete EPG Program Entry    
            success = recordings.delEPGProgram(epgchannel, timestampSD, timestampED)
            if success:
                dialog.ok('[B]' + ADDONname + '[/B]','Deletet EPG Program Entry','')
    
    elif mode == 7001:   ### NTVCHANNELS --> GlowIPTV
        ###dialog = xbmcgui.Dialog()
        try:
            count = int(description)
            ADDON.setSetting('NTVCHANNELScount',str(count))
            ###dialog.ok('[B]' + ADDONname + '[/B]','Next/Previous GlowIPTV channel count: %r' % count,'')
            addonID = ADDON.getSetting('LastaddonID')
            NTVCHANNELS(addonID)
        except Exception,e:
            pass
            dialog = xbmcgui.Dialog()
            dialog.ok('[B]' + ADDONname + '[/B]','Next/Previous GlowIPTV channel failed: %r' % e,'')
    elif mode == 7002:   ### TVawayCHANNELS
        ###dialog = xbmcgui.Dialog()
        try:
            count = int(description)
            ADDON.setSetting('TVawayCHANNELScount',str(count))
            ###dialog.ok('[B]' + ADDONname + '[/B]','Next/Previous NTV channel count: %r' % count,'')
            TVawayCHANNELS()
        except Exception,e:
            pass
            dialog = xbmcgui.Dialog()
            dialog.ok('[B]' + ADDONname + '[/B]','Next/Previous TVaway channel failed: %r' % e,'')
    elif mode == 7003:  ### NEWCHANNELS
        ###dialog = xbmcgui.Dialog()
        try:
            count = int(description)
            ADDON.setSetting('NEWCHANNELScount',str(count))
            ###dialog.ok('[B]' + ADDONname + '[/B]','Next/Previous NTV channel count: %r' % count,'')
            NEWCHANNELS()
        except Exception,e:
            pass
            dialog = xbmcgui.Dialog()
            dialog.ok('[B]' + ADDONname + '[/B]','Next/Previous New Channel, VOD or TV Series failed: %r' % e,'')
    elif mode == 7004:  ### MYSELECTEDCHANNELS
        ###dialog = xbmcgui.Dialog()
        try:
            count = int(description)
            ADDON.setSetting('MYSELECTEDCHANNELScount',str(count))
            ###dialog.ok('[B]' + ADDONname + '[/B]','Next/Previous NTV channel count: %r' % count,'')
            MYSELECTEDCHANNELS()
        except Exception,e:
            pass
            dialog = xbmcgui.Dialog()
            dialog.ok('[B]' + ADDONname + '[/B]','Next/Previous Direct Channels failed: %r' % e,'')
    else:
        utils.logdev(module,'[B]' + ADDONname + '[/B][CR][COLOR red]Oops - something went wrong![/COLOR][CR]mode= '+str(mode))
    ###    dialog = xbmcgui.Dialog()
    ###    dialog.ok('[B]' + ADDONname + '[/B]','[COLOR red]Oops - something went wrong![/COLOR][CR][CR]mode= '+str(mode),'')

else:
    message = '[COLOR red]Wait - updating EPG![/COLOR]'
    utils.notification(message)
    findtvguidenotifications.findtvguidenotificationsend(message)
    xbmc.sleep(1000)

"""
try:
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_DATE)
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_TITLE)
except Exception,e:
    pass
    utils.logdev('addSortMethod','ERROR: %r' % e)
"""    
xbmcplugin.endOfDirectory(int(sys.argv[1]))

