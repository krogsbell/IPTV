#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
import utils
import definition

ADDON      = definition.getADDON()
ADDONname  = definition.ADDONgetAddonInfo('name')
ADDONid    = definition.ADDONgetAddonInfo('id')
module = 'runcmd.py'
utils.logdev(module,'sys.argv= %s' %(str(repr(sys.argv))))
program  = sys.argv[0]
cmd      = sys.argv[1]

def log(infotext,showlength=1024):
    definition.log(infotext,showlength,module)

log('cmd= %r' % cmd)  #put in LOG
try: 
    #print os.environ
    osenviron= os.environ['OS']
    log('os.environ= %r' % osenviron)  #put in LOG
except Exception as e:
    pass
    log('os.environ=  %r\nExcept: %r' % (cmd,e))
try: 
    LoopCount = 0
    LibPath = utils.libPath()
    log('utils.runCommand(\n cmd= %r,\n LoopCount= %r,\n LibPath= %r)' % (cmd, LoopCount, LibPath))
    subpr = utils.runCommand(cmd, LoopCount, LibPath)
    log('subpr of runCommand= %r' % subpr)
except Exception as e:
    pass
    log('cmd=  %r\nExcept: %r' % (cmd,e))

