#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmc
import urllib2
import sys
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)

try:
    import definition
    import utils
    
    ADDON     = definition.getADDON()
    ADDONid   = ADDON.getAddonInfo('id')
    ADDONname = ADDON.getAddonInfo('name')
    datapath  = xbmc.translatePath(ADDON.getAddonInfo('profile'))
    progpath  = ADDON.getAddonInfo('path')
    module    = 'http-keep-alive.py'
    utils.logdev(module,'Http Keep Alive Started')
    ###utils.notification('Http Keep Alive Started')
    ### SmartDNS Proxy servers: 46.166.189.68, 54.93.173.153, 81.17.17.188
    ### SmartDNS Proxy activation command: https://www.smartdnsproxy.com/api/IP/update/XXXXXXXXXXXXXXX (XXX.. Your direct link)

    link = ADDON.getSetting('http-keep-alive')
    data = 'Request not executed! - Less then 5 characters'

    try:
        if len(link) > 5:
            file = urllib2.urlopen(link)
            deflink = 'https://www.smartdnsproxy.com/api/IP/update/'
            if deflink in link:
                link = deflink + '...'  ### Don't log full link
            data = file.read(500)
            file.close()
            ADDON.setSetting('http-keep-alive-result',repr(data))
            ADDON.setSetting('http-keep-alive-time',repr(datetime.today().strftime('%Y-%m-%d %H:%M:%S')))
            utils.logdev(module,'Request: %s,\n Result: %s' % (repr(link),repr(data)))
    except Exception, e:
        pass
        utils.logdev(module, 'Error in http-keep-alive= %s ERROR= %s' % (repr(link),repr(e)))
        
except:
    pass

###utils.logdev(module,'Ended')

