import os
import json
import time
import sys
from platform import Platform
from logger import Log

class Middleware:

    app = None
    api = None
    storage_file = None

    channels = {}
    categories = {}
    timestamp = 0
    message = ''
    status = 0

    def __init__(self, _app, _api):
        self.api = _api
        self.app = _app

        storage_path = os.path.join(_app.data_path, Platform.STORAGE_PATH)
        if os.path.exists(storage_path) == False:
                os.makedirs(storage_path)
        self.storage_file = os.path.join(storage_path, Platform.STORAGE_FILE)
        self.timestamp = 0
        self.message = ''
        self.status = 0


    def save_to_file(self):
        data = {'status': 1, 'message': self.message, 'timestamp': self.timestamp}
        data['body'] = list(self.channels.values())
        f = open(self.storage_file, "w")
        f.write(json.dumps(data))
        f.close()

    def update(self):
        Log.log('------ mw.update ------')

        now = time.time()

        if len(self.channels) > 0 and now - self.timestamp < Platform.CHANNELS_TTL:
            return

        data = {'timestamp': 0}

        if os.path.exists(self.storage_file):
            Log.log('------ mw.update file found ------')
            f = open(self.storage_file, "r")
            data = f.read()
            f.close()
            data = json.loads(data)

        # too old, reload and save
        need_save = False
        if now - data['timestamp'] > Platform.CHANNELS_TTL:
            Log.log('------ mw.update too old, asking api ------')
            data = self.api.channels()

            if data['status'] == 0:
                Log.log('------ mw.update api failure ------')
                self.app.remove_auth()
                self.app.exit_with_message(data['message'])
                return

            data['timestamp'] = now
            need_save = True


        Log.log('------ mw.update regenerating cache ------')
        self.categories = {}
        self.channels = {}
        self.timestamp = data['timestamp']
        self.message = data['message']
        self.status = data['status']
        for channel in data['body']:
            try:
                category = channel['category']
                name = channel['category_name'].encode("utf-8")
                self.categories[category] = name
                self.channels[channel['id']] = channel
            except Exception,e:
                pass
                Log.log('Update Channel failed: %r' % e)

        if need_save:
            self.save_to_file()

    def get_categories(self):
        Log.log('------ mw.get_categories ------')
        self.update()
        return self.categories

    def get_channels(self, category = None):
        self.update()
        filtered = {}
        if category is not None:
            Log.log('------- filtering channels --------')
            for k in self.channels:
                channel = self.channels[k]
                if channel['category'] == int(category):
                    filtered[channel['id']] = channel
                    #Log.log('--- filtered channel ' + channel['name'])
        else:
            filtered = self.channels

        return filtered

    def get_favs(self):
        self.update()
        filtered = {}
        for k in self.channels:
            channel = self.channels[k]
            if channel['favorite'] == 1:
                filtered[channel['id']] = channel
        return filtered


    def search_channel(self, name):
        self.update()
        filtered = {}
        for k in self.channels:
            channel = self.channels[k]
            if name.lower() in channel['name'].lower():
                filtered[channel['id']] = channel
        return filtered


    def get_channel(self, channel_id):
        # cache is not good
        self.update()
        return self.channels[int(channel_id)]

    def fav_add(self, channel_id):
        self.update()
        channel = self.channels[int(channel_id)]
        if channel['favorite'] == 1:
            return
        data = self.api.fav_add(channel_id)
        if data['status'] == 0:
            self.app.remove_auth()
            self.app.exit_with_message(data['message'])
        self.channels[int(channel_id)]['favorite'] = 1
        self.save_to_file()

    def fav_remove(self, channel_id):
        self.update()
        channel = self.channels[int(channel_id)]
        if channel['favorite'] == 0:
            return
        data = self.api.fav_remove(channel_id)
        if data['status'] == 0:
            self.app.remove_auth()
            self.app.exit_with_message(data['message'])
        self.channels[int(channel_id)]['favorite'] = 0
        self.save_to_file()

    def get_channel_link(self, channel_id):
        data = self.api.get_channel_link(channel_id)
        #if data['status'] == 0:
        #    self.app.remove_auth()
        #    self.app.exit_with_message(data['message'])
        return data
        
    def get_archive_link(self, channel_id, evtStart, evtDuration):
        data = self.api.get_archive_link(channel_id, evtStart, evtDuration)
        #if data['status'] == 0:
        #    self.app.remove_auth()
        #    self.app.exit_with_message(data['message'])
        return data