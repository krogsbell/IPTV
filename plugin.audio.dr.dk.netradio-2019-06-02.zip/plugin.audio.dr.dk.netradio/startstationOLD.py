#!/usr/bin/python
# -*- coding: utf-8 -*-

import urllib2    ### krogsbell 2019-05-21
import xmltodict  ### pip install xmltodict (Ubuntu first: sudo apt install python-pip)
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import os
import xbmcgui, xbmcplugin
import utils
import simplejson
import xbmcvfs

CHANNELS_URL = 'https://www.dr.dk/mu-online/api/1.0/channel/all-active-dr-radio-channels'
PATH = sys.argv[0]
LOGO_PATH = os.path.join(PATH, 'resources', 'logos')
ICON = os.path.join(PATH, 'icon.png')
FANART = os.path.join(PATH, 'fanart.jpg')

def __log(text):
    utils.logdev(PATH,text)

def playEPG(idx):
    __log('playEPG(idx= %r)'% idx)
    try:
        u = urllib2.urlopen(CHANNELS_URL)
        channelList = simplejson.loads(u.read())
        u.close()
    except Exception, ex:
        showError(str(ex))
        return
    try:
        for channel in channelList:
            title = channel['Title']
            slug  = channel['Slug']
            if title[0:3] == 'DR ':
                title = title[3:]
            __log('playEPG(title= %r slug= %r)'% (title,slug))
            if idx.lower() == slug:
                sourceUrl = channel['SourceUrl']
                logoImage = os.path.join(LOGO_PATH, sourceUrl[sourceUrl.rindex('/') + 1:] + '.png')
                if xbmcvfs.exists(logoImage):
                    item = xbmcgui.ListItem(title, iconImage=logoImage)
                else:
                    item = xbmcgui.ListItem(title, iconImage=ICON)

                item.setProperty('IsPlayable', 'true')
                item.setProperty('Fanart_Image', FANART)
                item.setInfo(type='music', infoLabels={
                    'title': title
                })

                url = None

                if 'StreamingServers' in channel:
                    for server in channel['StreamingServers']:
                        if 'LinkType' in server and server['LinkType'] == 'ICY' and 'Qualities' in server:
                            try:
                                url = server['Server'] + '/' + server['Qualities'][0]['Streams'][0]['Stream']
                                break
                            except:
                                pass
                __log('playEPG(url= %r)'% url)
                if url:
                    __log('play-ing-EPG(url= %r)'% url)
                    logoImage = os.path.join(LOGO_PATH, title + '.png')
                    item = xbmcgui.ListItem(path=url, thumbnailImage=logoImage)
                    item.setInfo(type='music', infoLabels={
                        'title': title
                    })
                    xbmc.Player().play(url, item, True)
                    ###xbmcplugin.setResolvedUrl(HANDLE, True, listitem = item)
                    __log('play-ing-EPG-started(url= %r)'% url)
                    break   ### Stop at first match
    except Exception,e:
        pass
        __log('PlayEPG ERROR: %r' % e)
    
try:
    program    = sys.argv[0]
    HANDLE     = int(sys.argv[1])
    station_id = sys.argv[2]
    ###timestamp  = sys.argv[3]
except:
    pass
    title = 'StartStation'
    HANDLE = -1
    station_id = 'P4KBH'
    timestamp = ''
try:
    __log('sys.argv= %r' % sys.argv)
    __log('os.environ= %s' % os.environ['OS'] ) #put in LOG
    __log('PATH= %r' % PATH)
    __log('LOGO_PATH= %r' % LOGO_PATH)
    __log('ICON= %r' % ICON)
    __log('FANART= %r' % FANART)

except Exception,e:
    pass
    __log('ERROR data: %r' % e)
try:
    __log('code part')
    playEPG(station_id)
    """
    ###url = 'plugin://plugin.audio.dr.dk.netradio?playEPG=%s)' % (station_id)
    url = 'https://live-icy.dr.dk/A/A25H.mp3'
    __log('url= %r' % url)
    listitem = xbmcgui.ListItem('Auto Radio')
    listitem.setInfo('music', {'Title': 'Auto Radio', 'Genre': 'On Air'})
    __log('listitem= %r' % listitem)
    xbmc.Player().play(url, listitem, True)
    __log('Playing url= %r' % url)
    
    ###xbmc.Player().play(playlist, listitem, windowed, startpos)
    
    cmd = 'XBMC.RunPlugin(plugin://plugin.audio.dr.dk.netradio?HANDLE=%d&playEPG=%s)' % (HANDLE,station_id)
    __log('cmd= %s' % cmd)
    
    xbmc.executebuiltin(cmd)  # Active
    xbmc.sleep(1000)
    cmd = 'XBMC.RunPlugin(plugin://plugin.audio.dr.dk.netradio?HANDLE=%d&playEPG=%s)' % (HANDLE+1,'P5')
    xbmc.executebuiltin(cmd)  # Active
    """
except Exception,e:
    pass
    __log('ERROR: %r' % e)