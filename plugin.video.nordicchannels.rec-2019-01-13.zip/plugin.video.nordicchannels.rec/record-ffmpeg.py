#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os
import datetime
import time
import utils, recordings
import net
from hashlib import md5  
import json  
import locking

import definition
ADDON      = definition.getADDON()
ADDONname  = ADDON.getAddonInfo('name')
ADDONid    = ADDON.getAddonInfo('id')
module = 'record-ffmpeg.py'
utils.logdev(module,'sys.argv= %s' %(str(repr(sys.argv))))
program  = sys.argv[0]
cat      = sys.argv[1]
startTime= sys.argv[2]
endTime  = sys.argv[3]
duration = sys.argv[4]
title    = sys.argv[5]
argv6    = sys.argv[6]
argv7    = sys.argv[7]
nameAlarm= sys.argv[8]
try: 
    #get description
    description= sys.argv[9]
except:
    pass
    description= 'Error getting description'

try: 
    #print os.environ
    utils.logdev(module,'os.environ= ' + os.environ['OS'])  #put in LOG
except: pass

###recorddrdirectly=utils.directprograms(cat)  ### Get direct links
recorddrdirectly=recordings.directprograms(cat)  ### Get direct links
utils.logdev(module,'recorddrdirectly= ' + repr(recorddrdirectly))  #put in LOG
if recorddrdirectly == '':
    PreTitle = ' ' + ADDONname+'-'
else:
    PreTitle = ' '
utils.logdev(module,'PreTitle= <' + repr(PreTitle) + '>')  #put in LOG

LoopCountMax = int(ADDON.getSetting('LoopCount'))

utils.logdev(module,'Recording title= %s' % title)
utils.logdev(module,'Start recording ' + title)
recordings.updateRecordingPlanned(nameAlarm, '[COLOR orange]Start recording of [/COLOR] ' + title)
Recordings = ADDON.getSetting('Recordings') + nameAlarm
ADDON.setSetting('Recordings',Recordings)
###locking.recordLock('Start recording of ' + title) ### TEST
RecordingDisabled = False
#print 'record.py: nameAlarm= %s' % (str(repr(nameAlarm)))
#utils.logdev(module,'LoopCountMax= %s' % (str(repr(LoopCountMax))))
recordPath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_path')))
utils.logdev(module,'recordPath= %s' %recordPath)
if not utils.folderwritable(recordPath):
    utils.notification('Recording %s [COLOR red]FAILED - You must set the recording path writable![/COLOR]' % title)
    utils.logdev(module,'You must set the recording path writable! ' + title)
    ###locking.recordLock('You must set the recording path writable! ' + title) ### TEST
else:
    Retry = True
    LoopCount = 0
    try:
        nowHM=datetime.datetime.today().strftime('%H:%M:%S')
    except:
        pass
    """
    try:
        #locking.recordUnlock(title)
        #A new recording unlocks all previous - otherwise the retry feature will make some fuzz
        locking.recordUnlockAll()   ### with multi stream record - this will not work! 2017-08-09
    except:
        pass
    """
    try:
        if recorddrdirectly == '': ### 2017-08-24
            utils.logdev(module,'recordLock(nameAlarm= %r )' % nameAlarm)
            locking.recordLock(nameAlarm)
    except Exception, e:
        pass
        utils.logdev(module,'recordLock(nameAlarm= %r ERROR: %r)' % (nameAlarm,e))
        ###locking.recordLock('recordLock(nameAlarm= %r ERROR: %r)' % (nameAlarm,e))
    while (Retry == True) and (LoopCount < LoopCountMax) and (locking.isRecordLocked(nameAlarm) or recorddrdirectly != '' ) :   ### 2017-08-24
        try:
            nowHM=datetime.datetime.today().strftime('%H:%M:%S')
            playchannelName = recordings.ChannelName(cat)
            if playchannelName == '':
                playchannel = str(cat) 
            else:
                playchannel = playchannelName
            playchannel = re.sub('[,:\\/*?\<>|"]+', '', playchannel)   ### 2017-09-30 Only chars allowed in filenames 
            if not recorddrdirectly == '':
                Retry = True
                ### cat='147'  DR1 http://dr01-lh.akamaihd.net/i/dr01_0@147054/master.m3u8?b=100-3000
                rtmp     = recorddrdirectly
            else:
                ###url      = definition.getBASEURL() + '/index.php?' + recordings.referral()+ 'c=6&a=0&mwAction=content&xbmc=1&mwData={"id":%s,"type":"tv"}' % cat
                ###link     = net.http_GET(url,headers={"User-Agent":"NTV-XBMC-" + ADDON.getAddonInfo('version')}).content
                ###data     = json.loads(link)
                try:
                    rtmp     = recordings.urlFromCat(cat)
                except Exception, e:
                    pass
                    utils.logdev(module,'recordings.urlFromCat(cat= %r ERROR: %r)' % (cat,e))
                    rtmp     = recordings.catFromUrl(url)
        except Exception, e:
            pass
            utils.notification('Recording [COLOR red]NOT possible! No data on channel[/COLOR] %s' % (playchannel))
            ###locking.recordLock('Recording [COLOR red]NOT possible! No data on channel[/COLOR] %s' % (playchannel))
            recordings.updateRecordingPlanned(nameAlarm, 'Recording [COLOR red]NOT possible! No data on channel[/COLOR] '+ playchannel + " - " + title + ' at ' + nowHM)
            utils.logdev(module,'Recording NOT possible! No data on channel ' + playchannel + ' - ' + title + '\nError: ' + repr(e))
            #nowHM=datetime.datetime.today().strftime('%H:%M:%S')
            #print 'record.py1: title= %s, LoopCount= %s at %s' % (repr(title),repr(LoopCount),nowHM)
            xbmc.sleep(10000)
            ###time.sleep(10)
            #nowHM=datetime.datetime.today().strftime('%H:%M:%S')
            #print 'record.py2: title= %s, LoopCount= %s at %s' % (repr(title),repr(LoopCount),nowHM)
            rtmp = ''
        #nowHM=datetime.datetime.today().strftime('%H:%M:%S')
        #print 'record.py3: title= %s, LoopCount= %s at %s' % (repr(title),repr(LoopCount),nowHM)
        #utils.notification('Recording %s [COLOR orange]LOOP %s[/COLOR]' % (title, nowHM))
        if rtmp == '' :
            Retry = True
            LoopCount += 1
            LoopCountMax = int(ADDON.getSetting('LoopCount'))
            nowHM=datetime.datetime.today().strftime('%H:%M:%S')
            #print 'record.py4: title= %s, LoopCount= %s at %s' % (repr(title),repr(LoopCount),nowHM)
        else:
            nowHM=datetime.datetime.today().strftime('%H:%M:%S')
            #print 'record.py5: title= %s, LoopCount= %s at %s' % (repr(title),repr(LoopCount),nowHM)
            cmdoption = ''
            try:
                #cmd += ' -V --stop ' + ADDON.getSetting('RecordFromTVguideDurationMinutes')
                cmdoption += ' -t ' + str(int(duration)) 
            except Exception, e:
                pass
                utils.logdev(module,'cmdoption += %r\nError: %r' % (cmdoption,e))
                cmdoption += ' -t ' +str(120)
            if os.access('/system/vendor/bin/ffmpeg', os.X_OK):
                cmd = '/system/vendor/bin/ffmpeg -y -listen_timeout 2000 -i '  # Use seperately installed ffmpeg program ###
            else:
                cmd = 'ffmpeg -y -listen_timeout 2000 -i '  # Use seperately installed ffmpeg program with timeout one minute ###
            cmd += '"' + rtmp + '"'
            ffmpegoptions= ADDON.getSetting('ffmpegoptions')
            utils.logdev('ffmpegoptions',repr(ffmpegoptions))
            if ffmpegoptions == '1':
                cmd += ' -f flv  -c:v libx264 -c:a aac -ac 1 -strict -2 -crf 18 -profile:v baseline -maxrate 2000k -bufsize 18350K ' + cmdoption + ' ' ### For use with ffmpeg
            elif ffmpegoptions == '2':
                cmd += ' -c copy ' + cmdoption + ' ' ### For use with ffmpeg and ac3 sound
            elif ffmpegoptions == '0':
                cmd += ' -c copy -bsf:a aac_adtstoasc ' + cmdoption + ' ' ### For use with ffmpeg
            else:
                ffmpegfreeoption = ADDON.getSetting('ffmpegfreeoption')
                cmd += ' ' + ffmpegfreeoption + ' ' + cmdoption + ' ' ### For use with ffmpeg free option
            filetitle = recordings.latin1_to_ascii_force(title)
            filetitle = filetitle.replace('?', '_')
            filetitle = filetitle.replace(':', ' -')
            filetitle = filetitle.replace('/', '-')
            filetitle = filetitle.replace('+', '_')
            filetitle = filetitle.replace('\\', '_')
            filetitle = re.sub('[,:\\/*?\<>|"]+', '', filetitle)
            filetitle = " ".join(filetitle.split())  # Remove extra spaces from filename
            utils.logdev(module,'filetitle= %r' % filetitle)
            recordstarttime = datetime.datetime.today().strftime('%Y-%m-%d %H-%M')
            durationH = 0
            durationM = 0
            if 'Duration [' in description and '].' in description:
                orgduration = (description.split('uration [')[1].split('].')[0] + 'm').replace(':','h')
            else:
                durationH = int(int(duration)/3600)
                durationM = (int(duration) - durationH*3600)/60
                orgduration =  str(durationH) + 'h' + str(durationM).zfill(2) + 'm'
            if duration == '0':
                cmd += '"' + recordPath + filetitle + ' ['+recordstarttime+ PreTitle + playchannel  + ']'
            else:
                ###durationH = int(int(duration)/60)
                ###durationM = int(duration) - durationH*60
                orgduration = '[' + orgduration +']'
                if '[' in filetitle:   ### Put duration first on second line, if not in line
                    if orgduration in filetitle:
                        filename1 = recordPath + filetitle
                    else:
                        filetitle1 = filetitle.replace('[',orgduration +'[',1)
                        filename1 = recordPath + filetitle1 
                else:
                    filename1 = recordPath + filetitle + orgduration
                    
                    
                cmd += '"' + filename1 + ' ['+recordstarttime+ PreTitle + playchannel+ ']'
            utils.logdev(module,'duration= %s, durationH= %s, durationM= %s' %(repr(duration),repr(durationH),repr(durationM)))  
            ext = ADDON.getSetting('ffmpegoutputtype')
            if LoopCount >0:
                cmd += ' ' + str(LoopCount) + '.'+ext+'"'  
            else:
                cmd += '.'+ext+'"' 
            infofilename = filename1 + ' ['+recordstarttime+ PreTitle + playchannel + '].txt'
            utils.logdev(module,'infofilename= %s' % (repr(infofilename)))
            
            filename1 = infofilename.replace('.txt','.log',1)
            if LoopCount >0:
                filename1 = filename1 = infofilename.replace('.txt',' ' + str(LoopCount) +'.log',1)  
            else:
                filename1 = infofilename.replace('.txt','.log',1)
            cmd += ' 2> "' + filename1 + '"'   ### Save FFMPEG log 2018-01-22
            nowHM=datetime.datetime.today().strftime('%H:%M')
            utils.logdev(module,'LoopCount= %r, RecordingDisabled= %r'% (LoopCount, RecordingDisabled))
            if LoopCount == 0 and not RecordingDisabled:
                utils.notification('Recording %s [COLOR yellow]started %s[/COLOR]' % (title, nowHM))
                recordings.updateRecordingPlanned(nameAlarm, '[COLOR yellow]Started ' + nowHM + '[/COLOR] ' + title)
                utils.logdev(module,'Recording started ' + title)
                try:
                    # Create file with info on recording 'infofilename' .txt and .nfo format
                    """ File format for .nfo file
                    <?xml version="1.0" encoding="utf-8"?>
                    <episodedetails>
                        <title>Title</title>
                        <rating>Rating</rating>
                        <season>Season</season>
                        <episode>Episode</episode>
                        <plot>Plot</plot>
                        <thumb>Thumb</thumb>
                        <playcount>Playcount</playcount>
                        <lastplayed>LastPlayed</lastplayed>
                        <credits>Credits</credits>
                        <director>Director</director>
                        <aired>Aired</aired>
                        <premiered>Premiered</premiered>
                        <studio>Studio</studio>
                        <mpaa>MPAA Certification</mpaa>
                        <epbookmark>Episode Bookmark</epbookmark>
                        <displayseason>Display Season</displayseason>
                        <displayepisode>Display Episode</displayepisode>
                    </episodedetails>
                    
                    Example:
                    <?xml version="1.0" encoding="utf-8"?>
                    <episodedetails>
                      <title>Broen IIII 2-8</title>
                      <season>4</season>
                      <episode>2</episode>
                      <plot> Description </plot>
                        <displayseason>4</displayseason>
                      <displayepisode>2</displayepisode>
                    </episodedetails>

                    """
                    ###LF = open(infofilename, 'a')
                    LF = open(infofilename, 'w')   ### 2017-08-09
                    crlf = '\r\n'
                    # Write to our text file the information we have provided and then goto next line in our file.
                    LF.write('Recorded using: ' + ADDON.getAddonInfo('name')+ crlf)
                    LF.write('Version= ' + ADDON.getAddonInfo('version')+ crlf)
                    LF.write('Version Info= ' + utils.version()+ crlf)
                    ### LF.write('Version Date= ' + utils.versiondate()+ crlf)
                    program  = sys.argv[0]
                    LF.write('Program Name= ' + program+ crlf)
                    LF.write('Platform= ' + ADDON.getSetting('platform')+ crlf)
                    LF.write('Running on= ' + ADDON.getSetting('runningon')+ crlf)
                    LF.write('OS= ' + ADDON.getSetting('os')+ crlf)
                    LF.write('Record Path= ' + ADDON.getSetting('record_path')+ crlf + crlf)
                    LF.write('Record Command:' + crlf + cmd+ crlf + crlf)
                    LF.write('Title= ' + title + crlf)
                    LF.write('PlayChannel= ' + playchannel + crlf)
                    LF.write('cat= ' + cat + crlf)
                    LF.write('StartTime= ' + startTime + crlf)
                    LF.write('EndTime= ' + endTime + crlf)
                    LF.write('Duration= ' + str(int(round(int(duration)/60))) + ' minutes' + crlf)
                    ### LF.write('Argv6= ' + argv6 + crlf)
                    ### LF.write('Argv7= ' + argv7 + crlf)
                    LF.write('NameAlarm= ' + nameAlarm + crlf)
                    if not len(description) == 3 and not description == 'n a':
                        LF.write('Description:' + crlf + recordings.argumenttostring(description).replace('AAabBB',' ').replace('aAabBb','?').replace('BBabAA','=').replace('xXx',' ').replace('###',',').replace('AaAaA','=') + crlf)
                    else:
                        LF.write('No description!' + crlf)
                    # Close our file so no further writing is posible.
                    LF.close()
                    try:
                        os.chmod(infofilename, 0776)
                        utils.logdev(module,'Infofilename permission set to 0776')
                    except Exception, e:
                        pass
                        utils.logdev(module,'Failed to set infofilename permission to 0776: ' + repr(e))
                    infofilename = infofilename.replace('.txt','.nfo')
                    LF = open(infofilename.replace('.txt','.nfo'), 'w')   ### 2017-08-09
                    # Write to our text file the information we have provided and then goto next line in our file.
                    LF.write('<?xml version="1.0" encoding="utf-8"?>' + crlf)
                    LF.write('<episodedetails>'+ crlf)
                    LF.write('    <title>' + title + '</title>' + crlf)
                    if not len(description) == 3 and not description == 'n a':
                        LF.write('    <plot>' + recordings.argumenttostring(description).replace('AAabBB',' ').replace('aAabBb','?').replace('BBabAA','=').replace('xXx',' ').replace('###',',').replace('AaAaA','=') + '</plot>' + crlf)
                    LF.write('</episodedetails>'+ crlf)
                    # Close our file so no further writing is posible.
                    LF.close()
                    try:
                        os.chmod(infofilename, 0776)
                        utils.logdev(module,'Infofilename permission set to 0776')
                    except Exception, e:
                        pass
                        utils.logdev(module,'Failed to set infofilename permission to 0776: ' + repr(e))
                    utils.logdev(module,'infofilename= %s written and closed' % (repr(infofilename))) # Add to log
                except:
                    pass
                    utils.logdev(module,'infofilename= %s FAILED to be written and closed' % (repr(infofilename))) # Add to log
                    utils.notificationbox('[COLOR red]Writing info file failed - check permision on [/COLOR]%s' % (repr(infofilename)))
            else:
                LoopNr = str(LoopCount)
                if not RecordingDisabled:
                    utils.notification('Recording %s [COLOR orange]RESTARTED# %s %s[/COLOR]' % (title, LoopNr, nowHM))
                    recordings.updateRecordingPlanned(nameAlarm, '[COLOR orange]Restarted# %s %s[/COLOR] %s' % (LoopNr, nowHM, title))

            if ADDON.getSetting('os')=='11':
                    #print 'libpath= None os=11'
                    utils.runCommand(cmd, LoopCount, libpath=None)
            else:
                    libpath = utils.libPath()
                    utils.logdev(module,'libpath= %s' % repr(libpath))
                    #print 'libpath= %s' % libpath
                    utils.runCommand(cmd, LoopCount, libpath=libpath)

            ### nowP = recordings.parseDate(datetime.datetime.today())  2017-09-12
            nowP = datetime.datetime.now()
            endTimeO =  recordings.parseDate(endTime)
            time_tuple = endTimeO.timetuple()
            timestamp = time.mktime(time_tuple) - 60 * int(ADDON.getSetting('TimeAfter')) + 60 * 5
            endTimeM = datetime.datetime.fromtimestamp(timestamp)
            endTimeP =  recordings.parseDate(endTimeM)
            ###timestampQ = time.mktime(time_tuple) + 120 + 60 * int(ADDON.getSetting('TimeAfter'))
            timestampQ = time.mktime(time_tuple) + 120
            
            endTimeMQ = datetime.datetime.fromtimestamp(timestampQ)
            endTimePQ =  recordings.parseDate(endTimeMQ)
            utils.logdev(module,'record-ffmpeg end timing: Now= %s, EndTime= %s, EarlyTime= %s, LateTime= %s' % (repr(nowP),repr(endTimeO),repr(endTimeP),repr(endTimePQ)))
            nowHM=datetime.datetime.today().strftime('%H:%M')
            if LoopCount > 0:
                nowHM += ' loopcount= ' + str(LoopCount)
            utils.logdev(module,'endTimeP= %r > nowP= %r' % (endTimeP, nowP))
            utils.logdev(module,'nowP= %r > endTimePQ= %r' % (nowP, endTimePQ))
            if  endTimeP > nowP and not RecordingDisabled:
                recordings.updateRecordingPlanned(nameAlarm, '[COLOR red]Completed Early ' + nowHM + '[/COLOR] ' + title )
                startTime = nowP
                Retry = True
                utils.logdev(module,':0 loopcount= ' + str(LoopCount) + ' ' + title)
                if LoopCount < (LoopCountMax - 1):
                    xbmc.sleep(10000* LoopCount)   #### longer pause after each error 2017-12-23
                    ###time.sleep(10 * LoopCount)   #### longer pause after each error 2017-01-21
                utils.logdev(module,':1 loopcount= ' + str(LoopCount) + ' ' + title)
                #time.sleep(10)
                LoopCount += 1
                LoopCountMax = int(ADDON.getSetting('LoopCount'))
            elif    nowP > endTimePQ and not RecordingDisabled:
                recordings.updateRecordingPlanned(nameAlarm, '[COLOR red]Completed Late ' + nowHM + '[/COLOR] ' + title)
                startTime = nowP
                Retry = False
            else:
                if not RecordingDisabled:
                    recordings.updateRecordingPlanned(nameAlarm, '[COLOR green]Complete ' + nowHM + '[/COLOR] ' + title)
                Retry = False

    if not RecordingDisabled:
        utils.notification('Recording %s [COLOR red]complete[/COLOR]' % title)
    if recorddrdirectly == '':  ###2018-09-03  != changed to ==
        utils.logdev(module,'recordUnLock(nameAlarm= %r )' % nameAlarm)
        locking.recordUnlock(nameAlarm)
    Recordings = ADDON.getSetting('Recordings').replace(nameAlarm,'')
    ADDON.setSetting('Recordings',Recordings)
    utils.notification('Recording finished: ' + title)
    utils.logdev(module,'Recording finished: ' + title)
    Recordings = ADDON.getSetting('Recordings').replace(nameAlarm,'')
    ADDON.setSetting('Recordings',Recordings)
    utils.logdev(module,'Recording finished: ' + title)
    utils.logdev(module,'Recording finished nameAlarm: ' + nameAlarm)
    try:
        Recordings = ADDON.getSetting('Recordings')
        if nameAlarm in Recordings:
            Recordings = Recordings.split(nameAlarm)[1]
            ADDON.setSetting('Recordings',Recordings)    ### only save later recordings
            utils.logdev(module,'Removing in recordings second time: %r' % nameAlarm)
    except Exception,e:
        pass
        utils.logdev(module,'Error in removing in recordings: %r' % e)
        ADDON.setSetting('Recordings','')  ### Clear recordings if possible
        utils.logdev(module,'Removing in recordings third time: %r' % nameAlarm)