#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copy the addon folder to the name of the id to copy addon to, update addon.xml and add the fanart.jpg, icon.jpg and icon.png to be used with the addon then make a zip file and install from zip!

referral= 0     ##########################<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
###values="NTV|WOZBOX (www.wozboxtv.com)|My Indian TV|White Label Spain (http://www.wliptv.com)|ROQ TV Rec|ACE TV Rec|ACE TV Rec Experimental|Premium IPTV (Premiumiptv.co)
import xbmcaddon,xbmc
try:
    BASEURL = 'http://www.roq-tv.net:80'
    COMMAND = ''
    COMMANDEND = ''
    REGISTRATION = 'http://roq-tv.com'
    REFERRALNAME = 'ROQ TV Rec Dummy'
    REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'

    if referral==0:
        ADDON = xbmcaddon.Addon(id='plugin.video.roqtv.rec')
        ###BASEURL = 'http://roq-tv.net:25461'
        BASEURL = 'http://www.roq-tv.net:80'
        COMMAND = '/panel_api.php?'
        COMMANDEND = ''
        REGISTRATION = 'http://roq-tv.com'
        REFERRALNAME = 'Roq TV Rec'
        REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'

    elif referral==1:
        ADDON = xbmcaddon.Addon(id='plugin.video.acetvrec')
        BASEURL = 'http://ace-tv.xyz:25461'
        REGISTRATION = 'http://www.ace-tv.co.uk'
        REFERRALNAME = 'ACE TV Rec'

    elif referral==2:
        ###http://tv.premium.iptv.uno:8080/get.php?username=xxxx&password=xxxx&type=m3u_plus&output=m3u8
        ADDON = xbmcaddon.Addon(id='plugin.video.premiumiptv.rec')
        BASEURL = 'http://tv.premium.iptv.uno:8080'
        COMMAND = 'get.php?'
        COMMANDEND = '&type=m3u_plus&output=m3u8'
        REGISTRATION = 'http://www.premiumiptv.co'
        REFERRALNAME = 'Premium IPTV (Premiumiptvco.com)'
        REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'

    elif referral==3:
        ###http://tv.glowiptv.iptv.uno:8080/get.php?username=xxx&password=xxxx&type=m3u_plus&output=m3u8
        ADDON = xbmcaddon.Addon(id='plugin.video.glowiptv.rec')
        BASEURL = 'http://tv.glowiptv.iptv.uno:8080'
        COMMAND = 'get.php?'
        COMMANDEND = '&type=m3u_plus&output=m3u8'
        REGISTRATION = 'http://glowiptv.com'
        REFERRALNAME = 'GlowIPTV (glowiptv.com)'
        REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'

    elif referral==9:    
        ADDON = xbmcaddon.Addon(id='plugin.video.roqtv.rec')
        BASEURL = 'http://iptv.thetvcompanys.net:25461'
        COMMAND = 'get.php?'
        COMMANDEND = '&type=m3u_plus&output=m3u8'
        REGISTRATION = 'http://www.flashiptv.com'
        REFERRALNAME = 'FlashIPTV'  
        REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'
    
    else:
        ADDON = xbmcaddon.Addon(id='plugin.video.roqtv.rec')
        BASEURL = 'http://www.roq-tv.net:80'
        COMMAND = '/panel_api.php?'
        COMMANDEND = ''
        REGISTRATION = 'http://roq-tv.com'
        REFERRALNAME = 'Dummy Roq TV Rec'
        REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'

    ADDON.setSetting('my_referral_link',str(referral))
    ADDON.setSetting('my_referral_name',REFERRALNAME)
    ADDON.setSetting('my_referral_registration',REGISTRATION)
except Exception,e:
    pass
    ADDON = 0
    BASEURL = 'http://www.roq-tv.net:80'
    COMMAND = '/panel_api.php?'
    COMMANDEND = ''
    REGISTRATION = 'http://roq-tv.com'
    REFERRALNAME = repr(e)
    
def getADDON():
    return ADDON

def getBASEURL():
    return BASEURL  
    
def getCOMMAND():
    return COMMAND 
    
def getCOMMANDEND():
    return COMMANDEND  
    
def getREGISTRATION():
    return REGISTRATION 

def getTITLE():
    return REFERRALTITLE 
    
def getKrogsbellAddOns():
    return ['plugin.video.glowiptv.rec','plugin.video.premiumiptv.rec','plugin.video.roqtv.rec']
    
def getKrogsbellAddOnsTEST():
    return []
