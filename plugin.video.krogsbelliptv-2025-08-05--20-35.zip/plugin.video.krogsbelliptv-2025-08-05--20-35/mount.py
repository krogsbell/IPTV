#!/usr/bin/python
# -*- coding: utf-8 -*-
import recordings, utils, locking
import xbmcaddon, xbmc, xbmcgui, datetime, os

import definition
ADDON	   = definition.getADDON()
ADDONname  = definition.ADDONgetAddonInfo('name')
xbmc.log('mount.py in %s' % ADDONname)
module= 'mount.py'
utils.logdev(module,'err Start on %r' % ADDONname)

def log(infotext,showlength=1024):
    definition.log(module + ': '+infotext,showlength)

def logd1(infotext):
    log('err: ' + infotext)

def logarray(Name,Array,nelements=1):
    i = 0
    for rec in Array:
        try:
            if nelements==1:
                log('logarray in %s= %r %r' % (Name,i,rec))
                i += 1
            else:
                records = []
                for index in range(0, nelements):
                    records.append(rec[index])
                log('logarray in %s= %r %r' % (Name,i,records))
                i += 1
        except Exception as e:
            pass
            log('ERROR: logarray in %s= %r' % (Name,e))

def mount():
    try:
        ###reload(sys)	
        ###sys.setdefaultencoding('utf8')
        utils.logdev(module,'defaultencoding= %r' % sys.getdefaultencoding())
        Platform = utils.rtmpdumpFilename()
        
    except Exception as e:
        pass
        utils.logdev(module,'FindPlatform ERROR: %r' % e)  # Put in LOG
        
    e = ''
            
    try:
        """
        In Python you would do basically the same routine as you would in Bash mounting shares:

        #!/usr/bin/python

        import os

        home = os.path.expanduser("~")
        mnt = home + "/mnt"

        if not os.path.exists(mnt): os.makedirs(mnt)
        os.chdir(mnt)

        os.system("mount_smbfs //username@server._smb._tcp.local/share " + mnt)
        What this does is sets the mount point to mnt in the users home directory; if the folder doesn't exist then it creates it. Then the command changes into that directory and mounts thesmb. You'll need to enter your password, or if you want to have a really non-secure way, then you can always include the password in the command (eg. username:password).

        Once your share is mounted you can check if the file exists with:

        os.path.exists(mnt + "/path/to/file")
        """
        dialog = xbmcgui.Dialog()
        #TS = '\\\\Thinkpad\\Holt5TB'
        #TS = 'smb://192.168.20.6:445/Holt5TB/Videos/'
        TS = definition.ADDONgetSetting('record_archive_path')
        if TS[-1] == '/':
            TS = TS[:-1]
        logd1('record_archive_path= %r' % TS)
        if TS[0:2] == 'W:':  
            logd1('Network Drive set to W:')
        if 1 == 1: ### Just run this
            logd1('test TS= %r' % (TS))
            keyboard = str(TS)
            
            keyboard = dialog.input('[COLOR lightgreen][B]Please Enter NetworkPath[/B][CR][COLOR grey][I]Cancel or 25 seconds timeout = Ignore input[/I][/COLOR]',str(keyboard), type=xbmcgui.INPUT_ALPHANUM, autoclose=25000)
                
            recordArchivePath = keyboard
            logd1('1. recordArchivePath= %r' % (recordArchivePath))
            
            home = os.path.expanduser("~")
            logd1('home= %r' % home)
            mnt = home + os.sep + 'mnt'
            logd1('mnt= %r' % mnt)
            
            if not os.path.exists(mnt): 
                logd1('os.path.exists(mnt)= %r' % os.path.exists(mnt))
                os.makedirs(mnt)
                os.chdir(mnt)
                
            OS = definition.ADDONgetSetting('OS')  ### Windows = '11'
            logd1('OS= %r' % OS)
            
            if OS == '11':  ### Windows = '11'
                import subprocess
                shell = True
                recordArchivePath = recordArchivePath.replace('smb://','//').replace('/','\\').replace(':445','')
                if TS[0:2] != 'W:':
                    subprocess.call('NET USE W: /d > mnt.log 2> error.log', shell=shell) ### Dont delete W if is beeing used
                else:
                    #os.system('NET USE > mnt.log 2> error.log') 
                    subprocess.call('NET USE >> mnt.log 2>> error.log', shell=shell)
                subprocess.call('NET USE W: ' + recordArchivePath + ' >> mnt.log 2>> error.log', shell=shell)
                
                subprocess.call('NET USE >> mnt.log 2>> error.log', shell=shell)
                
                recordArchivePath = 'W:'
                subprocess.call('dir W: >> mnt.log 2>> error.log', shell=shell)
                if TS[0:2] != 'W:':
                    definition.ADDONresetSetting('record_archive_path','W:')
                    
                    
                
            else:
                logd1('2. recordArchivePath= %r' % (recordArchivePath))
                result = os.system("mount_smbfs " + recordArchivePath + " " + mnt)
                logd1('result= %r' % result)
                recordArchivePath = (mnt + '/' + recordArchivePath.replace('smb:/','').replace(':','_')).replace('/','_')

            logd1('3. recordArchivePath= %r' % (recordArchivePath))
            
            if not os.path.exists(recordArchivePath):
                log('not os.path.exists(recordArchivePath= %r)' % recordArchivePath)
                recordArchivePath = ''
                definition.ADDONresetSetting('record_archive_path','')
    except Exception as  e:
        pass
        log('recordArchivePath error: ' + repr(e))
        
    if e == '':
        markc = 'lightgreen'
    else:
        markc = 'red'
    notificationsend= '[COLOR %s][B]*%s*[/B][/COLOR] Mount Ended with %s\n%r' % (markc,ADDONname,recordArchivePath,e)
    logd1('notificationsend= %s' % notificationsend)
    utils.notificationsend('[COLOR %s][B]*%s*[/B][/COLOR] Mount Ended with %r\n%r' % (markc,ADDONname,recordArchivePath,e)) 


