#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs,os
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import calendar
import net
import json
import locking,utils
import recordings
import glob
import fnmatch
import definition
import shutil
import xmltodict
import base64
from operator import itemgetter
from urllib.request import urlopen
import io
import findtvguidenotifications
from sqlite3 import dbapi2 as sqlite3

ADDON      = definition.getADDON()
ADDONname  = utils.ADDONgetAddonInfo('name')
ADDONid    = utils.ADDONgetAddonInfo('id')
ADDONrefer = utils.ADDONgetSetting('my_referral_name')
if 'true' == utils.ADDONgetSetting('enigma2'): 
    enigma2 = True
else:
    enigma2 = False
args = sys.argv  ### args[1] == 'once' or 'hourly'
module = 'updateepg.py'
origin = ADDONid +' available_channels'
utils.logdev(module,'errX Start')
utils.logdev(module,'errX args: '+ repr(args))
datapath   = xbmcvfs.translatePath(utils.ADDONgetAddonInfo('profile'))
progpath   = utils.ADDONgetAddonInfo('path')
referral = utils.ADDONgetSetting('my_referral_link')
dateStringDummy = '20200625070000 +0100'

notify = utils.ADDONgetSetting('notifyduringepgupdate')
if notify == 'true':
    notifyduringepgupdate = True
else:
    notifyduringepgupdate = False
       
###ActiveCategories = recordings.getAllCategories()

def notnone(cat):
    if cat == None:
        return ''
    else:
        return cat

def log(infotext,showlength=500):
    debug = utils.ADDONgetSetting('debug').lower()
    if debug in infotext.lower() and not debug == '':
        utils.logdev('error',module + ': ' + infotext,showlength=showlength)
    else:
        nolog = True
"""       
def log(infotext,showlength=500):
    try:
        if 'error' in infotext[0:showlength].lower():
            utils.logdev('error',module + ': ' + infotext,showlength=showlength)
        elif 'err' in infotext.lower():
            nolog = True
            ###utils.logdev(module,infotext,showlength=showlength)
        else:
            nolog = True
            ###utils.logdev(module,infotext,showlength=showlength)
    except Exception as  e:
        pass
        utils.logdev('error',module + ': ' + infotext,showlength=showlength)
"""       
def sleep(sleeptime):
    log('errYYY sleep(sleeptime= %r)' % (sleeptime))
    xbmc.sleep(sleeptime)

def notification(infotext):  
    if notifyduringepgupdate:
        utils.notification(repr(infotext)) 

def krogsbellAddons():
    ### Krogsbell IPTV addons have the file 'definition.py'
    addons    = []
    addonsAll = []
    try:
        SwFileFolder = os.path.join(xbmcvfs.translatePath('special://masterprofile/'), 'addon_data','krogsbell.switchaddons')
        SwFile = os.path.join(SwFileFolder,'switchaddons.txt')
        if not os.path.exists(SwFileFolder):
            os.mkdir(SwFileFolder)
            open(SwFile, 'a').close()
        log('SwFile= %r' % SwFile)
        switchfile = open(SwFile, 'r')
        addonsO = switchfile.read()
        switchfile.close() 
        
        if not ADDONid in addonsO:
            targetADDON = xbmcaddon.Addon(id=ADDONid)
            newADDONname = targetADDON.getAddonInfo('name')
            log('err newADDONname= %r' % newADDONname)
            ###addonsO += '\n' + ADDONrefer + ':' + ADDONid
            addonsO += '\n' + newADDONname + ':' + ADDONid
        if addonsO != '' :
            addonsO = addonsO.split('\n')
            for addon in addonsO:
                if addon != '':
                    newaddon = addon.split(':')
                    targetADDON = xbmcaddon.Addon(id=newaddon[1])
                    newaddon[0] = targetADDON.getAddonInfo('name')
                    if newaddon[1] != ADDONid:
                        try:
                            testAddon = xbmcaddon.Addon(id=newaddon[1])
                            pathTOaddon = os.path.join(xbmcvfs.translatePath('special://home/addons'), newaddon[1])
                            if os.path.exists(pathTOaddon):
                                addons.append(newaddon)
                                addonsAll.append(newaddon)
                        except Exception as e:
                            log('err 7186 Exception: %r' % e)
                            pass
                            log('testAddon FAILED ERROR: %r' % e)
                    else:
                        addonsAll.append(newaddon)
    except Exception as e:
        log('err 7191 Exception: %r' % e)
        pass
        addons.append(['ERROR',repr(e)])
    ###[['GlowIPTV','plugin.video.glowiptv.rec'],['DR NU','plugin.video.drnu'],['BBC iPlayer','plugin.video.iplayerwww'],['ITV Player','plugin.video.itv']]
    addonsAll = sorted(addonsAll)
    log('err krogsbellAddons addonsAll= %r' % addonsAll)
    addonsO = ''
    for addon in addonsAll:
        addonsO += addon[0] + ':' + addon[1] + '\n'
    utils.ADDONsetSetting('switchaddons',addonsO)
    LF = open(SwFile, 'w')
    LF.write(addonsO)
    LF.close()
            
    addons = sorted(addons)
    choises = []
    for choise in addons:
       choises.append('[B][COLOR lightgreen]'+ choise[0] + ':[/COLOR][/B] ' + choise[1])
    return choises
      
def testPrograms():
    try:  ### Get system timezone
        timezone = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Settings.GetSettingValue", "params": {"setting": "locale.timezone"}, "id": 1}')
        log('errYYY Kodi timezone= %r' % timezone)
    except Exception as e:
            pass
            log('errYYY Get timezone error= %r' % e)
    try:   ### Test if ffmpeg is installed
        if utils.runCommandTest('ffmpeg'):
            log('errYYY FFMPEG installed!')
    except Exception as e:
            pass
            log('errYYY Get ffmpeg error= %r' % e)
    try:   ### Test if rtmpdump is installed
        if utils.runCommandTest('rtmpdump'):
            log('errYYY RTMPDUMP installed!')
    except Exception as e:
            pass
            log('errYYY Get rtmpdump error= %r' % e)
    try:   ### Test if 7zip is installed
        if utils.runCommandTest('7z'):
            log('errYYY 7z installed!')
        else:
            log('errYYY 7z NOT installed!')
    except Exception as e:
            pass
            log('errYYY Get 7z error= %r' % e)
    ### xarchiver -v
    try:   ### Test if xarchiver -v is installed
        if utils.runCommandTest('xarchiver -v'):
            log('errYYY xarchiver -v installed!')
        else:
            log('errYYY xarchiver -v NOT installed!')
    except Exception as e:
            pass
            log('errYYY Get xarchiver -v error= %r' % e)
            
def GetFromDict(link,number=0):           
    try:  ### Get original descriptions from enigma2 link
        log('errYYY Read enigma2 link= %r, number= %r'% (link, number))
        """
        ###link = 'http://roq-tv.net:25461/enigma2.php?username=' +utils.ADDONgetSetting('user')+ '&password=' +utils.ADDONgetSetting('pass')
        enigma2 i, (key= u'items', value= OrderedDict([(u'playlist_name', u'My_Bouquet_Name'), (u'category', OrderedDict([(u'category_id', u'1'), (u'category_title', u'My_Bouquet_Name')])), (u'channel', [OrderedDict([(u'title', u'Live Streams'), (u'description', u'Live Streams Category'), (u'category_id', u'0'), (u'playlist_url', u'http://www.e900x.com:8000/enigma2.php?username=xxx&password=yyy&type=get_live_categories')]), OrderedDict([(u'title', u'Vod'), (u'description', u'Video On Demand Category'), (u'category_id', u'1'), (u'playlist_url', u'http://www.e900x.com:8000/enigma2.php?username=xxx&password=yyy&type=get_vod_categories')]), OrderedDict([(u'title', u'TV Series'), (u'description', u'TV Series Category'), (u'category_id', u'2'), (u'playlist_url', u'http://www.e900x.com:8000/enigma2.php?username=xxx&password=yyy&type=get_series_categories')])])])): 
        """
        ### ROQTVusername = utils.ADDONgetSetting('user')
        if link != '' :
            
            log('errYYY GetFromDict(link)= %r' % link)
            
            ###file = urllib.parse.urlopen(link)
            ###data = file.read()
            ###file.close()
            data = utils.readlink(link,'',module)
            data = data.replace('\n','').replace('<description/>','<description></description>')
            
            for titem in ['title','description']:
                
                data = data.split('<'+titem+'>')
                
                i=0
                newdata= ''
                for part in data:
                    
                    if i==0:
                        newdata+=part
                        
                        i+=1
                        
                    else:
                        part=part.split('</'+titem+'>',1)
                        
                        if not part[0] == None:
                            
                            if titem == 'title':
                                
                                decodedtext = recordings.latin1_to_ascii_force(base64.b64decode(part[0], '-_').replace('&','&amp;')).replace('<<','XX')
                            else:
                                decodedtext = recordings.latin1_to_ascii_force(base64.b64decode(part[0], '-_').replace('&','&amp;')).replace('<<','XX')
                                
                        else:
                            log('errYYY Missing channel: ' + repr(part))
                            decodedtext=''
                        try:   
                            if not part[1] == None:
                                newdata+='<'+titem+'>' + decodedtext +'</'+titem+'>' + part[1]
                            else:
                                newdata+='<'+titem+'>' + decodedtext +'</'+titem+'>'
                        except Exception as e:
                            pass
                            log('errYYY if not part[1] == None ERROR: %r' % e)
                            newdata+='<'+titem+'>' + decodedtext +'</'+titem+'>'
                        
                data = newdata
            
            channelsxml = os.path.join(datapath, 'channelsxml')+ str(number)  + '.xml'
            
            LF = open(channelsxml, 'w')
            LF.write(newdata)
            LF.close()
            
            try:
                newdata = newdata.replace('*#*>','*#*').replace('<*#*','*#*')  ### SPORT BEIN ARABIA fix
                data = xmltodict.parse(newdata)
            except Exception as e:
                pass
                log('errYYY Error in enigma2 xmltodict.parse(newdata)1: #%r\n%r'% (number,e))
                data = ''
            
            channelsdict = os.path.join(datapath, 'channelsdict')  + str(number)+ '.dict'
            LF = open(channelsdict, 'w')
            LF.write(repr(data))
            LF.close()
    except Exception as e:
        pass
        log('errYYY Error in enigma2 xmltodict.parse(newdata)2: #%r\n%r'% (number,e))
        data = ''    
    log('errYYY channelsdict.dict transformed: %r' % data)
    return data

def scandata(data1,number,label):
    log('errYYY scandata(number= %r\nlabel= %r\ndata1= %r)' % (number,label,data1))
    label += '@'
    log('errYYY scandata(number= %r\nlabel= %r)' % (number,label))
    for j, (key2, value2) in enumerate(data1.iteritems()):
        log('errYYY enigma2 j= %r, (key2= %r, number= %r, label= %r, value2= %r)' % (j, key2, number, label, value2))
        for j1, (key3, value3) in enumerate(value2.iteritems()):
            log('errYYY key3?channel %r, type(value3)= %r, value3= %r' % (key3,type(value3),value3))
            """
            type(value3)= <class 'collections.OrderedDict'>
            
            if repr(type(value3)) == "<class 'collections.OrderedDict'>":
                log('key3?channel-type-list %r, type(value3)= %r' % (key3,type(value3)))
                scandata(value3,number,label+'#')
            """
            if key3 == 'channel':
                if repr(type(value3)) == "<class 'collections.OrderedDict'>":
                    log('errYYY key3?channel-type-list %r, type(value3)= %r' % (key3,type(value3)))
                    scandata(value3,number,label+'#')
                else:
                    for d3 in value3:
                        log('errYYY 0 value3= %r' % value3)
                        log('errYYY type(d3)= %r' % type(d3))
                        log('errYYY d3= %r' % d3)
                        if repr(type(d3)) == "<class 'collections.OrderedDict'>":
                            log('errYYY key3?d3 %r, type(d3)= %r' % (key3,type(d3)))
                            scandata(d3,number,label+'!')
                        else:
                            if 'playlist_name' in d3 :
                                log('errYYY playlist_name')
                                try:
                                    playlist_name3 = d3['playlist_name']
                                    log('errYYY enigma2 d3-3-0, (key3= %r, value3= %r, number= %r)' % (key3, playlist_name3, number))
                                    label += playlist_name3 + '¤'
                                    log('errYYY enigma2 d3-3-0, (key3= %r, value3= %r, label= %r)' % (key3, playlist_name3, label))
                                except Exception as e:
                                    pass
                                    log('errYYY playlist_name ERROR: %r' % e)
                                log('errYYY 1 value3= %r' % value3)
                            elif 'playlist_url' in d3 : ### and not d3['playlist_url'] == None:
                                log('errYYY playlist_url')
                                try:
                                    log('errYYY d3-playlist_url= %r' % d3)
                                    playlist_url3 = d3['playlist_url']
                                    log('errYYY enigma2 d3-3, (key3= %r, value3= %r, number= %r)' % (key3, playlist_url3, number))
                                    data2 = GetFromDict(playlist_url3,number=number)
                                    log('errYYY enigma2 d3-2, (data2= %r, number= %r)' % (data2, number))
                                    number += 1
                                    scandata(data2,number,label)
                                    log('errYYY after scandata(data2,number)')
                                except Exception as e:
                                    pass
                                    log('errYYY playlist_url ERROR: %r' % e)
                                log('errYYY 2 value3= %r' % value3)
                            elif 'stream_url' in d3 : ###and not d3['stream_url'] == None:
                                log('errYYY d3-stream_url= %r' % d3)
                                log('errYYY stream_url')
                                try:
                                    StreamURL=d3['stream_url'].replace('![CDATA[','',1).replace(']]','',1)
                                    log('errYYY enigma2 d3-1, (StreamURL= %r)' % (StreamURL))
                                    if not d3['desc_image'] == None:
                                        DescURL=d3['desc_image'].replace('![CDATA[','',1).replace(']]','',1)
                                    else:
                                        DescURL = ''
                                    try:
                                        Description=d3['description']
                                        if isinstance(Description, dict):
                                            try:
                                                Description = Description['em']+'\n'+Description['#text']
                                            except Exception as e:
                                                ###pass
                                                Description = repr(Description) + repr(e)  ### 2019-03-31
                                        elif not isinstance(Description, unicode):
                                            if not (Description == None or Description == ''):
                                                Description='Unknown description type: ' + repr(type(Description))
                                            else: 
                                                Description = repr(Description)
                                    except Exception as e:
                                        pass
                                        log('errYYY Error in get enigma2 Description: ' + repr(e))
                                        EPGimportERRORS('266 Error in get enigma2 Description: ' + repr(e))
                                        Description= 'Error in get enigma2 Description: ' + repr(e)
                                except Exception as e:
                                    pass    
                                    log('errYYY Error in get enigma2 stream_url: ' + repr(e))
                                log('errYYY 1 label= %r, d3title= %r' % (label,d3['title']))
                                log('errYYY Test enigma2 Title= %r, Stream= %r, DescURL= %r, Category_ID= %r, Description= %r' % (label+d3['title'],StreamURL,DescURL,d3['category_id'],Description))
                                catThis = recordings.catFromUrl(StreamURL)
                                log('errYYY recordings.catFromUrl= %r from\nStreamURL= %r' %(catThis,StreamURL))
                                try:
                                    if utils.ADDONgetSetting('user') in catThis :
                                        catThis = '#'
                                except Exception as e:
                                    pass
                                    log('errYYY utils.ADDONgetSetting(user) in catThis= %r ERROR: %r' % (catThis,e))
                                log('errYYY catThis= %r' % catThis)
                                if recordings.isChannelVisible(catThis) or catThis == '#' or 1==1:  ### 2020-04-06
                                    log('errYYY Visible catThis= %r' % catThis)
                                    try:
                                        if catThis != '#' : 
                                            category_name = d3['category_name']
                                            if category_name != '':
                                                category_name = ' [' + category_name + ']' 
                                            name = label+d3['title'] + category_name  ### 2023-03-19
                                            name = ' '.join(name.split())  ## Remove doublespaces etc
                                            log('errYYY addChannel(d3[title]= %r, StreamURL= %r, DescURL= %r, catThis= %r, origin= %r,description= %r)' % 
                                            (name, StreamURL, DescURL, catThis, origin, Description))
                                            log('errYYY 0 label= %r, d3title= %r' % (label,d3['title']))             
                                            recordings.addChannel(name,StreamURL,DescURL,catThis,origin,description=Description)
                                            log('errYYY after recordings.addChannel')
                                    except Exception as e:
                                        pass
                                        log('errYYY series/  Error in get enigma2: ' + repr(e))
                                        EPGimportERRORS('296 Error in get enigma2: ' + repr(e))
                                        log('errYYY 297')
                            else:
                                log('errYYY ERROR:  Not playlist_name, playlist_url or stream_url: %r' % d3)
                
def GetOriginalDescriptionsFromDict(): 
    """
    ###link = 'http://roq-tv.net:25461/enigma2.php?username=' +utils.ADDONgetSetting('user')+ '&password=' +utils.ADDONgetSetting('pass')
    enigma2 i, (key= u'items', value= OrderedDict([(u'playlist_name', u'My_Bouquet_Name'), (u'category', OrderedDict([(u'category_id', u'1'), (u'category_title', u'My_Bouquet_Name')])), (u'channel', [OrderedDict([(u'title', u'Live Streams'), (u'description', u'Live Streams Category'), (u'category_id', u'0'), (u'playlist_url', u'http://www.e900x.com:8000/enigma2.php?username=xxx&password=yyy&type=get_live_categories')]), OrderedDict([(u'title', u'Vod'), (u'description', u'Video On Demand Category'), (u'category_id', u'1'), (u'playlist_url', u'http://www.e900x.com:8000/enigma2.php?username=xxx&password=yyy&type=get_vod_categories')]), OrderedDict([(u'title', u'TV Series'), (u'description', u'TV Series Category'), (u'category_id', u'2'), (u'playlist_url', u'http://www.e900x.com:8000/enigma2.php?username=xxx&password=yyy&type=get_series_categories')])])]))

    OrderedDict([(u'items', OrderedDict([(u'playlist_name', u'SubCategory [ My_Bouquet_Name ]'), (u'category', OrderedDict([(u'category_id', u'1'), (u'category_title', u'SubCategory [ My_Bouquet_Name ]')])), (u'channel', [OrderedDict([(u'title', u'All'), (u'description', u'TV Series Category [ ALL ]'), (u'category_id', u'0'), (u'playlist_url', u'http://www.e900x.com:8000/enigma2.php?username=xxx&password=yyy&type=get_series&cat_id=0')]), OrderedDict([(u'title', u'English Series'), (u'description', u'TV Series Category'), (u'category_id', u'45'), (u'playlist_url', u'http://www.e900x.com:8000/enigma2.php?username=xxx&password=yyy&type=get_series&cat_id=45')])])]))])
    """          
    try:  ### Get original descriptions from enigma2 link
        log('errYYY Read enigma2 link')
        number=0
        ###link = 'http://roq-tv.net:25461/enigma2.php?username=' +utils.ADDONgetSetting('user')+ '&password=' +utils.ADDONgetSetting('pass')
        ROQTVusername = utils.ADDONgetSetting('user')
        if ROQTVusername.lower() != 'none' and enigma2 :
            link = definition.getBASEURL() + '/enigma2.php?username=' +utils.ADDONgetSetting('user')+ '&password=' +utils.ADDONgetSetting('pass')
            log('errYYY enigma2 link= %r' % link)
            data = GetFromDict(link,number=number)
            number += 1
            
            channelsdict = os.path.join(datapath, 'channelsdict')  + '.dict'
            LF = open(channelsdict, 'w')
            LF.write(repr(data))
            LF.close()
        
            log('errYYY err channelsdict.dict transformed: %r' % data)
            for i, (key, value) in enumerate(data.iteritems()):
                log('errYYY enigma2 i, (key= %r, value= %r): ' % (key, value))
                for i1, (key1, value1) in enumerate(value.iteritems()):
                    log('errYYY enigma2 i1= %r, (key1= %r, value1= %r): ' % (i1, key1, value1))
                    if key1 == 'channel':
                        for d in value1:
                            log('errYYY d in value1= %r' % d)
                            ### dict: d in value1= OrderedDict([(u'title', u'TV Series'), (u'description', u'TV Series Category'), (u'category_id', u'2'), (u'playlist_url', u'http://portal.stiptv.com:8080/enigma2.php?username=sfg7jILXn6&password=PItYZEeXir&type=get_series_categories')])
                            if 'playlist_url' in d and not d['playlist_url'] == None:
                                playlist_url=d['playlist_url']
                                log('errYYY playlist_url= %r' % playlist_url)
                                data4 = GetFromDict(playlist_url,number=number)
                                log('errYYY GetFromDict(number= %r, playlist_url= %r)' % (number,playlist_url))
                                number += 1
                                for k, (key4, value4) in enumerate(data4.iteritems()):
                                    log('errYYY enigma2 k= %r, (key4= %r, value4= %r): ' % (k, key4, value4))
                                    for k1, (key5, value5) in enumerate(value4.iteritems()):
                                        log('errYYY enigma2 k1= %r, (key5= %r, value5= %r): ' % (k1, key5, value5))
                                        log('errYYY key5?channel %r, value5= %r' % (key5,value5))
                                        if key5 == 'channel':
                                            log('errYYY key5==channel %r'% key5)
                                            for d5 in value5:
                                                log('errYYY d5= %r'% d5)
                                                if d5['title'] == 'All':
                                                    playlist_url5=d5['playlist_url']
                                                    log('errYYY enigma2 d5, (key5= %r, value5= %r, number= %r)' % (key5, playlist_url5, number))
                                                    data1 = GetFromDict(playlist_url5,number=number)
                                                    number += 1
                                                    scandata(data1,number,'')
                                                    """
                                                    for j, (key2, value2) in enumerate(data1.iteritems()):
                                                        log('enigma2 j= %r, (key2= %r, value2= %r)' % (j, key2, value2))
                                                        for j1, (key3, value3) in enumerate(value2.iteritems()):
                                                            ###log('enigma2 j1, (key3= %r, value3= %r)' % (key3, value3))
                                                            log('key3?channel %r, value3= %r' % (key3,value3))
                                                            if key3 == 'channel':
                                                                for d3 in value3:
                                                                    if 'playlist_url' in d3 and not d3['playlist_url'] == None:
                                                                        log('d3-playlist_url= %r' % d3)
                                                                        playlist_url3 = d3['playlist_url']
                                                                        log('enigma2 d3, (key3= %r, value3= %r, number= %r)' % (key3, playlist_url3, number))
                                                                        data2 = GetFromDict(playlist_url3,number=number)
                                                                        number += 1
                                                                    elif 'stream_url' in d3 and not d3['stream_url'] == None:
                                                                        StreamURL=d3['stream_url'].replace('![CDATA[','',1).replace(']]','',1)
                                                                        log('enigma2 d3, (StreamURL= %r)' % (StreamURL))
                                                                        if not d3['desc_image'] == None:
                                                                            DescURL=d3['desc_image'].replace('![CDATA[','',1).replace(']]','',1)
                                                                        else:
                                                                            DescURL = ''
                                                                        try:
                                                                            Description=d3['description']
                                                                            if isinstance(Description, dict):
                                                                                try:
                                                                                    Description = Description['em']+'\n'+Description['#text']
                                                                                except Exception as e:
                                                                                    pass
                                                                                    Description = repr(Description) + repr(e)  ### 2019-03-31
                                                                            elif not isinstance(Description, unicode):
                                                                                if not (Description == None or Description == ''):
                                                                                    Description='Unknown description type: ' + repr(type(Description))
                                                                                else: 
                                                                                    Description = repr(Description)
                                                                            
                                                                        except Exception as e:
                                                                            pass
                                                                            log('Error in get enigma2 Description: ' + repr(e))
                                                                            EPGimportERRORS('Error in get enigma2 Description: ' + repr(e))
                                                                            Description= 'Error in get enigma2 Description: ' + repr(e)
                                                                            
                                                                        log('Test enigma2 Title= %s, Stream= %s, DescURL= %s, Category_ID= %s, Description= %s' % (d3['title'],StreamURL,DescURL,d3['category_id'],Description))
                                                                        catThis = recordings.catFromUrl(StreamURL)
                                                                        if utils.ADDONgetSetting('user') in catThis :
                                                                            catThis = '#'
                                                                        log('catThis= %r' % catThis)
                                                                        if recordings.isChannelVisible(catThis) or catThis == '#':
                                                                            log('Visible catThis= %r' % catThis)
                                                                            
                                                                            try:
                                                                                
                                                                                if catThis != '#' :
                                                                                    recordings.setChannelDescription(catThis,Description)   ### 2019-02-11 Save descriptions in onlinE DATABASE
                                                                            except Exception as e:
                                                                                pass
                                                                                log('Error in get enigma2: ' + repr(e))
                                                                                EPGimportERRORS('Error in get enigma2: ' + repr(e))
                                                    """    
    except Exception as e:
        pass
        log('errYYY Error in getting enigma2 Channels: ' + repr(e))
        EPGimportERRORS('414 Error in getting enigma2 Channels: ' + repr(e))
        log('errYYY 415')
    log('errYYY Test enigma2  22')
    ### END INSERT setView('movies', 'main-view')             

def updateseriesOLD():
    try:
        conn = recordings.getConnection()
        recordings.createTable(conn)
        c = conn.cursor()
        
        ftvntvini = os.path.join(datapath,'TVSeries_'+ADDONrefer) + '.txt'
        LF = open(ftvntvini, 'w')
        LF.write('TV Series '+ADDONrefer + '\n\n')
        
        seriesmark = '%series%'
        c.execute("SELECT * FROM channels WHERE source=? and (stream_url like ? or weight > 0) COLLATE NOCASE",[origin,seriesmark]) ### 2021-01-15
        favorites = c.fetchall()
        favorites = sorted(favorites, key=itemgetter(1), reverse=False) ### Sort by Title
        j = 0
        seriesz = []   ### names of series
        serieszize = []   ### number of episodes for series
        for index in range(0, len(favorites)):
            created = favorites[index][12]
            seriexx = favorites[index][1].lower().split('series')
            if len(seriexx) == 2:
                seriex = seriexx[0]
            elif len(seriexx) == 3:
                seriex = seriexx[0] + 'series' + seriexx[1]
            elif len(seriexx) == 4:
                seriex = seriexx[0] + 'series' + seriexx[1]+ 'series' + seriexx[2]
            else:
                seriex = favorites[index][1].lower().split(' s0')
            seriey = favorites[index][1][:len(seriex)].strip()
            if not seriey in seriesz:
                seriesz.append(seriey)
                seriestitle = seriey + ' s%'
                c.execute("SELECT id FROM channels WHERE source=? and title like ? and (stream_url like ? or weight >0 ) COLLATE NOCASE",[origin,seriestitle,seriesmark])
                episodes = c.fetchall()
                serieszize.append(len(episodes))
                created = str(datetime.fromtimestamp(created).strftime('%Y-%m-%d'))
                chname = seriey + ' (' + str(len(episodes)) + ')'
                j += 1
                LF.write(format(j, '04d') + ' ' + chname + ' Created: '+ created + '\n')
                log('errYYY addTVSeries(c= %r, seriey= %r, len(episodes)= %r)' % (c, seriey, len(episodes)))
                recordings.addTVSeries(c, seriey, len(episodes))
        c.close()  
        LF.close()
    except Exception as e:
        pass
        log('errYYY Update TV Series ERROR: %r' % e)
        try:
            c.close()  
        except :
            pass 
        try:
            LF.close()
        except :
            pass 

def updateseries():   ### TV Series based on weight = S * 1000 + E
    try:
        conn = recordings.getConnection()
        recordings.createTable(conn)
        c = conn.cursor()
        
        ftvntvini = os.path.join(datapath,'TVSeries_'+ADDONrefer) + '.txt'
        LF = open(ftvntvini, 'w')
        LF.write('TV Series '+ADDONrefer + '\n\n')
        
        ###seriesmark = '%series%'
        c.execute("SELECT * FROM channels WHERE source=? and weight > 0 COLLATE NOCASE",[origin]) ### 2021-01-16
        favorites = c.fetchall()
        favorites = sorted(favorites, key=itemgetter(1), reverse=False) ### Sort by Title
        j = 0
        seriesz = []   ### names of series
        serieszize = []   ### number of episodes for series
        for index in range(0, len(favorites)):
            created = favorites[index][12]
            if 'series' in favorites[index][1].lower() and 1 == 0:   ### 2021-01-18 Only use TV Series based on weight = S * 1000 + E
                seriexx = favorites[index][1].lower().split('series')
                if len(seriexx) == 2:
                    seriex = seriexx[0]
                elif len(seriexx) == 3:
                    seriex = seriexx[0] + 'series' + seriexx[1]
                elif len(seriexx) == 4:
                    seriex = seriexx[0] + 'series' + seriexx[1]+ 'series' + seriexx[2]
                else:
                    seriex = favorites[index][1].lower().split(' s0')
                seriey = favorites[index][1][:len(seriex)].strip()
            else:
                seriey = utils.SeriesEpisodeVOD(favorites[index][1])[1]
                
            log('errYYY seriey= %r' % seriey)
            if not seriey in seriesz:
                seriesz.append(seriey)
                seriestitle = '%' + seriey + '%'
                c.execute("SELECT id FROM channels WHERE source=? and title like ? and weight >0 COLLATE NOCASE",[origin,seriestitle])
                episodes = c.fetchall()
                serieszize.append(len(episodes))
                created = str(datetime.fromtimestamp(created).strftime('%Y-%m-%d'))
                chname = seriey + ' (' + str(len(episodes)) + ')'
                j += 1
                LF.write(format(j, '04d') + ' ' + chname + ' Created: '+ created + '\n')
                log('errYYY addTVSeries(c= %r, seriey= %r, len(episodes)= %r)' % (c, seriey, len(episodes)))
                recordings.addTVSeries(c, seriey, len(episodes))
        c.close()  
        LF.close()
    except Exception as e:
        pass
        log('errYYY Update TV Series ERROR: %r' % e)
        try:
            c.close()  
        except :
            pass 
        try:
            LF.close()
        except :
            pass 

def updateiconsfromEPG():
    try:
        log('errYYY err #534 updateiconsfromEPG START')
        conn = recordings.getConnection()
        recordings.createTable(conn)
        c = conn.cursor()
        c.execute("SELECT * FROM channels WHERE source=? COLLATE NOCASE",[origin]) 
        favorites = c.fetchall()
        favorites = sorted(favorites, key=itemgetter(1), reverse=False) ### Sort by Title
        log('errYYY err #534 updateiconsfromEPG number of channels= %r' % len(favorites))
        for index in range(0, len(favorites)):
            log('errYYY err #543 updateiconsfromEPG index= %r' % index)
            cat  = favorites[index][0]
            Icon = favorites[index][2]
            EPG  = favorites[index][9]
            if Icon == '' and EPG != '' :   ### No Icon, but EPG
                log('errYYY err #542 updateiconsfromEPG cat= %r, EPG= %r, IconURL= %r' % (cat,Icon,EPG))
                Icon = recordings.getIconfromEPG(EPG)
                log('errYYY err #547 updateiconsfromEPG cat= %r, EPG= %r, IconURL= %r' % (cat,Icon,EPG))
                recordings.setChannelIcon(c,cat,Icon)
        c.close()  
    except Exception as e:
        pass
        log('errYYY updateiconsfromEPG ERROR: %r' % e)
        try:
            c.close()  
        except :
            pass 
            
tz = utils.ADDONgetSetting('AdjustTVguideTimeZoneOffset')
if tz == '':
    TimeZone = 0
else:
    TimeZone = int(tz)  
tzx = utils.ADDONgetSetting('AdjustTVguideTimeZoneOffsetExtraXML')

if tzx == '':
    tzx = utils.ADDONgetSetting('AdjustTVguideTimeZoneOffsetExtraXML')  ### read an extra time 2022-04-06
    if tzx == '':
        TimeZoneXML = 0
    else:
        TimeZoneXML = int(tzx) 
else:
    TimeZoneXML = int(tzx)  
log('errXXXY \n  TimeZone= %r, tz= %r, \n  TimeZoneXML= %r, tzx= %r' % (TimeZone,tz,TimeZoneXML,tzx))   
datapanel = []
dataepg = []
data= []
EPGgenerator = ''
ChannelFile = ''
channels = 0
programs = 0

def EPGimportERRORS(ERROR):
    log('errYYY 1 EPGimportERRORS= %r' % ERROR)
    NoERROR = '[B][COLOR lightgreen]No Errors[/COLOR][/B]'
    ERRORS  = '[B][COLOR red]Error(s)[/COLOR][/B]'
    if ERROR == '':
        ERROR = NoERROR
        log('errYYY 2 EPGimportERRORS= %r' % ERROR)
    else:
        ERROR = repr(ERROR)
        ERROR = (ERROR + ', ' + utils.ADDONgetSetting('lastEPGimportERRORS')).replace(NoERROR,ERRORS)
        log('errYYY 3 EPGimportERRORS= %r' % ERROR)
        ERROR = ERROR[0:1000]
    utils.ADDONsetSetting('lastEPGimportERRORS',ERROR)
    log('errYYY 4 EPGimportERRORS= %r' % ERROR)

def parse_date(dateString):
    if dateString != '':
        return datetime.fromtimestamp(time.mktime(time.strptime(dateString, "%Y-%m-%d %H:%M:%S")))
    else:
        log('ERROR parse_date(dateString= %r)' % dateString)
        return None
    
def parse_date_string(dateString):
    try:
        ###ValueError: time data '20170625070000 +0100' does not match format '%Y%m%d%H%M%S z'
        ###return time.mktime(time.strptime(dateString, '%Y%m%d%H%M%S Z'))  ### UTC time
        ###logdev('resulttime0',repr(dateString))
        dt = dateString.split(' ')
        if int(dt[0]) < 0:
            dateStringOLD = dateString
            log('resulttime0'+repr(dateString))
            log('parse_date_string0 dt[0]= %r' % dt[0])
            dateString = dateStringDummy
            dt = dateString.split(' ')
            resulttime = time.mktime(time.strptime(dt[0], '%Y%m%d%H%M%S'))
            log('parse_date_string1a dt= %r' % dt)
            EPGimportERRORS('ERROR in date HTML: %r using dummy time: %r' % (dateStringOLD,dateString))
            log('623')
        resulttime = time.mktime(time.strptime(dt[0], '%Y%m%d%H%M%S'))
        ###logdev('resulttime1',repr(resulttime))
        resulttime =  int(resulttime) - (int(dt[1])/100 - TimeZone)*3600
        ###logdev('resulttime2',repr(resulttime))
        ###logdev('resulttime3',repr(datetime.fromtimestamp(resulttime)))
        return str(resulttime)
    except Exception as e:
        pass
        return 'parse_date_string(%r)\n ERROR: %r' % (dateString,e)
    
def parse_date_stringXML(dateString):
    dt = dateString.split(' ')
    if int(dt[0]) < 0:
        dateStringOLD = dateString
        log('resulttime0'+repr(dateString))
        log('parse_date_string0 dt[0]= %r' % dt[0])
        dateString = dateStringDummy
        dt = dateString.split(' ')
        resulttime = time.mktime(time.strptime(dt[0], '%Y%m%d%H%M%S'))
        log('parse_date_string1a dt= %r' % dt)
        EPGimportERRORS('ERROR in date XML: %r using dummy time: %r' % (dateStringOLD,dateString))
        log('644')
    resulttime = time.mktime(time.strptime(dt[0], '%Y%m%d%H%M%S'))
    resulttime =  int(resulttime) - (int(dt[1])/100 - TimeZoneXML)*3600
    return str(resulttime)

def getDict(dictA,name,ntype='',dtype=''):
    ###if utils.ADDONgetSetting('KeyErrorStop') != '':
    ### return ''
    element = ''
    en = "KeyError('" + name + "',)"
    ex = "KeyError('" + ntype + "',)"
    ey = "KeyError('" + dtype + "',)"
    if name == 'sub_title':
        return repr(dictA) + ' \n' + en  ### Debug option
    try:
        if dtype != '' and ntype != '':
            elementd = dictA[name][dtype]
            element = dictA[name][ntype]
            ###if type(element) in (list, tuple, dict):
            ### for elem in element:
            ###     return elem
            ###else:
            ###return repr(element)
            return element
    except Exception as e:
        pass
        err = repr(e)
        if err==en:
            return ''
        if err==ey:
            return 'ey1'
        if err==ex:
            return 'ex1'
    try:
        if ntype != '':
            element = dictA[name][ntype]
            ###if type(element) in (list, tuple, dict):
            ### for elem in element:
            ###     return elem
            ###else:
            ###return repr(element)
            return element
    except Exception as e:
        pass
        err = repr(e)
        if err==en:
            return ''
        if err==ex:
            return 'ex2'
    try:
        element = dictA[name]
        ###if type(element) in (list, tuple, dict):
        ### for elem in element:
        ###     return elem
        ###else:
        ###return repr(element)
        return element
    except Exception as e:
        pass
        err = repr(e)
        if err==en:
            return 'en3'
    return ''

def getEPGChannel(cat):
    try:
        log('getEPGChannel(cat)')
        conn = recordings.getConnection()
        c = conn.cursor()
        c.execute("SELECT DISTINCT title, epg_channel, source FROM channels WHERE id=?", [cat])
        favorites = c.fetchall()
        if len(favorites) > 0:
            result = [favorites[0][0],favorites[0][1],favorites[0][2]]  ### Title, EPG Channel
        else:
            result = ''
        c.close() 
        return result
    except Exception as e:
        pass
        notification('Error in getEPGChannel(cat) '+ cat + ' \n' + repr(e))
    
def setEPGChannel(cat,channel):
    try:
        log('setEPGChannel(cat)')
        conn = recordings.getConnection()
        c = conn.cursor()
        c.execute("SELECT * FROM channels WHERE id=?", [cat])
        favorites = c.fetchall()
        result = []

        for index in range(0, len(favorites)):
            ch = []
            for i in range(0, len(favorites[index])):
                if favorites[index][i] == None:
                    ch.append('')
                else:
                    ch.append(favorites[index][i])
            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [ch[0], ch[1], ch[2], ch[3], ch[4], ch[5], ch[6], ch[7], ch[8], channel,ch[10],ch[11],ch[12]])
        if result == []:
            log('EPG not found for cat= %r' % cat)
        conn.commit()
        
        c.execute("SELECT * FROM channelsRecursive WHERE id=?", [cat])
        favorites = c.fetchall()
        result = []

        for index in range(0, len(favorites)):
            ch = []
            for i in range(0, len(favorites[index])):
                if favorites[index][i] == None:
                    ch.append('')
                else:
                    ch.append(favorites[index][i])
            c.execute("INSERT OR REPLACE INTO channelsRecursive(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [ch[0], ch[1], ch[2], ch[3], ch[4], ch[5], ch[6], ch[7], ch[8], channel,ch[10],ch[11],ch[12]])
        if result == []:
            log('EPG not found for cat= %r' % cat)
        conn.commit()
        
        c.close() 
    except Exception as e:
        pass
        notification('Error in setEPGChannel(cat) '+ cat + ' \n' + repr(e))
    log('setEPGChannel(cat= %r)-->Channel/Epgid= %r' % (cat,channel))

def getEPGnow(cat):
    ###now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###now= datetime.today()
    ###log('getEPGnow(cat)')
    conn = recordings.getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE id=?", [cat])
    favorites = c.fetchall()
    result = []
    for index in range(0, len(favorites)):
        if result == []:
            ch = []
            for i in range(0, len(favorites[index])):
                if favorites[index][i] == None:
                    ch.append('')
                else:
                    ch.append(favorites[index][i])
            ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
            name = ch[1]
            tv_archive = ch[8]  ### Holds duration in days - 0 means no archive
            try:
                if type(tv_archive) != int:
                    tv_archive = 0
                default_tv_archive_duration = int(utils.ADDONgetSetting('tv_archive_duration'))
                if type(default_tv_archive_duration) != int:
                    default_tv_archive_duration = 2
                tv_archive_duration = tv_archive
            except:
                pass
                tv_archive = 0
                default_tv_archive_duration = 2
                tv_archive_duration = default_tv_archive_duration
            if tv_archive_duration > default_tv_archive_duration:
                utils.ADDONsetSetting('tv_archive_duration',str(tv_archive_duration))
            if tv_archive > 0:
                tv_archive = 1
            epg_channel_id = ch[9].replace(' (R)','')  ### Ignore Recursive marker
            result = [recordings.getEPGProgramsNow(epg_channel_id), name, tv_archive, tv_archive_duration, epg_channel_id]
    if result == []:
        log('EPG not found for cat= %r' % cat)
    c.close() 
    return result
    
def getEPG(cat):
    try:
        ###now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        ###now= datetime.today()
        ###log('getEPG(cat)')
        conn = recordings.getConnection()
        c = conn.cursor()
        c.execute("SELECT * FROM channels WHERE id=? AND visible=1", [cat])
        favorites = c.fetchall()
        result = []
        for index in range(0, len(favorites)):
            if result == []:
                ch = []
                for i in range(0, len(favorites[index])):
                    if favorites[index][i] == None:
                        ch.append('')
                    else:
                        ch.append(favorites[index][i])
                ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
                name = ch[1]
                tv_archive = ch[8]  ### Holds duration in days - 0 means no archive
                if type(tv_archive) != int:
                    tv_archive = 0
                try:
                    default_tv_archive_duration = int(utils.ADDONgetSetting('tv_archive_duration'))
                    if type(default_tv_archive_duration) != int:
                        default_tv_archive_duration = 2
                except:
                    pass
                    default_tv_archive_duration = 2
                tv_archive_duration = tv_archive
                if tv_archive_duration > default_tv_archive_duration:
                    utils.ADDONsetSetting('tv_archive_duration',str(tv_archive_duration))
                if tv_archive > 0:
                    tv_archive = 1
                epg_channel_id = ch[9].replace(' (R)','')  ### Ignore Recursive marker
                result = [recordings.getEPGPrograms(epg_channel_id), name, tv_archive, tv_archive_duration, epg_channel_id]
                log('errYYY epg_channel_id= %r, name= %r, tv_archive= %r, tv_archive_duration= %r'   % (epg_channel_id, name, tv_archive, tv_archive_duration))
        if result == []:
            log('EPG not found for cat= %r' % cat)
        c.close() 
        return result
    except Exception as e:
        pass
        log('Error in getEPG!\n' + repr(e))
    return []
    """
    ### Find name, tv_archive, tv_archive_duration, epg_channel_id in database... 2017-07-14
    linkpanel = 'http://roq-tv.net:25461/panel_api.php?username=' +ROQuser+ '&password=' +ROQpass
    file = urllib.parse.urlopen(linkpanel)
    datapanel = file.read()
    file.close()
    try:
        datapanel = json.loads(datapanel)
        name = datapanel['available_channels'][cat]['name']
        tv_archive = datapanel['available_channels'][cat]['tv_archive']
        tv_archive_duration = datapanel['available_channels'][cat]['tv_archive_duration']
        epg_channel_id = datapanel['available_channels'][cat]['epg_channel_id']
    except Exception as e:
        pass
        ### or Find epg_channel_id based on cat....
        notification('Error in getting '+ ADDONid + ' info or your channel is from XML file!\n' + repr(e))
        return ''
    
    return [recordings.getEPGPrograms(epg_channel_id), name, tv_archive, tv_archive_duration, epg_channel_id]
    """
    """
    httplinkEPG = 'http://roq-tv.net:25461/xmltv.php?username=' +ROQuser+ '&password=' +ROQpass
    file = urllib.parse.urlopen(httplinkEPG)
    dataepg = file.read()
    file.close()
    try:
        dataepg = xmltodict.parse(dataepg)
    except Exception as e:
        pass
        notification('Error 848 in EPG file '+ httplinkEPG + ' \n' + repr(e))
        return ''
    try:
        epg = dataepg['tv']['programme']
        logdev(module,repr(dataepg['tv']['programme']))
    except Exception as e:
        pass
        notification('Error in EPG programme '+ httplinkEPG + ' \n' + repr(e))
        return ''
    return
    """
    
def isExtKnown(infile):
    ffmpegoutputtype = utils.ADDONgetSetting('ffmpegoutputtype').lower()
    infileext = infile.lower().rsplit('.',1)[-1]
    ###log('infileext= %r, ffmpegoutputtype= %r' % (infileext, ffmpegoutputtype))
    if infileext == ffmpegoutputtype:
        return True
    extorgcollection = utils.ADDONgetSetting('extorgcollection').lower().split(',')
    if infileext in extorgcollection:
    ###if infile[-3:].lower()=='.ts' or infile[-4:].lower()=='.mp4' or infile[-4:].lower()=='.mkv' or infile[-4:].lower()== '.avi' or infile[-4:].lower() == '.m4v' or infile[-4:].lower()=='.flv' or infile[-ffmpegoutputtypelen:].lower()==ffmpegoutputtype:
        return True
    else:
        return False
    
def find_files(directory, pattern):
    for root, dirs, files in os.walk(directory):
        for basename in files:
            if fnmatch.fnmatch(basename, pattern):
                filename = os.path.join(root, basename)
                yield filename
"""
def geturldirectorypath(archive):
    try:
        archive = archive.upper()
        if archive == 'L':
            urldirectorypath = xbmcvfs.translatePath(os.path.join(utils.ADDONgetSetting('record_path')))
        elif archive == 'A':
            if utils.ADDONgetSetting('record_archive_path_enable') == 'true':
                urldirectorypath = xbmcvfs.translatePath(os.path.join(utils.ADDONgetSetting('record_archive_path')))
            else:
                urldirectorypath = ''
        elif archive == 'B':
            if utils.ADDONgetSetting('record_archiveb_path_enable') == 'true':
                urldirectorypath = xbmcvfs.translatePath(os.path.join(utils.ADDONgetSetting('record_archiveb_path')))
            else:
                urldirectorypath = ''
        else:
            urldirectorypath = ''
        log('error OK geturldirectorypath archive= %r\nurldirectorypath= %r' % (archive,urldirectorypath))
        return urldirectorypath
    except Exception as e:
        pass
        log('error geturldirectorypath archive= %r\nurldirectorypath= %r\n%r' % (archive,urldirectorypath,e))
        return ''
"""        
def geturldirectorydestinationpath(options):
    try:
        if options[:2] == 'l:':
            urldirectorydestinationpath = xbmcvfs.translatePath(os.path.join(utils.ADDONgetSetting('record_path')))
        elif options[:2] == 'a:':
            if utils.ADDONgetSetting('record_archive_path_enable') == 'true':
                urldirectorydestinationpath = xbmcvfs.translatePath(os.path.join(utils.ADDONgetSetting('record_archive_path')))
            else:
                urldirectorydestinationpath = ''
        elif options[:2] == 'b:':
            if utils.ADDONgetSetting('record_archiveb_path_enable') == 'true':
                urldirectorydestinationpath = xbmcvfs.translatePath(os.path.join(utils.ADDONgetSetting('record_archiveb_path')))
            else:
                urldirectorydestinationpath = ''
        else:
            urldirectorydestinationpath = ''
        log('error OK geturldirectorydestinationpath options= %r\nurldirectorydestinationpath= %r' % (options,urldirectorydestinationpath))
        return urldirectorydestinationpath
    except Exception as e:
        pass
        log('error geturldirectorydestinationpath options= %r\nurldirectorydestinationpath= %r\n%r' % (options,urldirectorydestinationpath,e))
        return ''
    
def FindCommands(c,folderpath,archive):
    commands = ['rename','move','movetofolder','delete','changetitle']
    try:
        ### CHANGE TITLE command
        c.execute("SELECT * FROM files WHERE archive=? AND command=?" , [archive,'changetitle'])
        channels = c.fetchall()
        log('FindCommands changetitle archive= %r, count= %r' % (archive,len(channels)))
        x = len(channels)
        if x > 0:
            utils.notificationforced('Change Title ' + str(x) + ' records in '+archive.lower()+': ', time = 1)
            for chan in channels:
                ###c.execute("INSERT OR REPLACE INTO files(filename, ext, path, video, description, size, archive, updated, created, updatedHuman, command, options, realtitle, startmark) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [filename, chan[1], chan[2], chan[3], chan[4], chan[5], archive, nowTS, chan[8], humantime(nowTS), command, options, realtitle, startmark])
                try:    ### changetitle
                    log('changetitle')
                    urlbase = chan[0] 
                    if chan[1] != '':
                        fileext = '.' + chan[1]
                    else:
                        fileext = ''
                    urldirectorypath = utils.geturldirectorypath(archive)
                    path = chan[2]
                    if path != '':
                        urldirectorypath = os.path.join(urldirectorypath,path)   
                    if not os.path.exists(urldirectorypath):
                        log('os.makedirs(urldirectorypath= %r' % urldirectorypath)
                        os.makedirs(urldirectorypath)    
                    log('error FindCommands changetitle archive= %r, urldirectorypath= %r' % (archive, urldirectorypath))
                    urlnewi = chan[11]   ### options
                    if urlnewi != '':
                        urlnewi = ' '.join(urlnewi.split())  ## Remove doublespaces etc
                        urlbase = os.path.join(urldirectorypath,urlbase)
                        log('urlbase= %r' % urlbase)
                        urlbase = urlbase.replace('aMp ','& ').replace('xXx','+')   ### 2019-03-17
                        ###write options to .tit file
                        try:
                            titleFile = urlbase + '.tit'
                            if urlnewi != '':
                                LF = open(titleFile, 'w')  ### 2020-11-03
                                LF.write(urlnewi)
                                if chan[13] != '':
                                    LF.write('\n'+chan[13])
                            # Close our file so no further writing is posible.
                            LF.close()
                            ###def addFile(c, filename, ext, path, video, description, size, archive, realtitle='', startmark='', duration= '')
                            recordings.addFile(c, chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[11], chan[13], chan[14], chan[15])  ### change real title
                            recordings.addFileCommand(c, chan[0], chan[1], chan[2], chan[6], '', '')  ### Clear command
                            """
                            try:
                                ###os.chmod(titleFile, 0o776 )
                                log('err NOT titleFile permission set to 0776')
                            except Exception as e:
                                pass
                                log('Failed to set titleFile permission to 0776: ' + repr(e))
                            """
                        except Exception as e:
                            pass
                            log('error writing titleFile= %r\n%r' % (titleFile,e))
                except Exception as e:
                    pass
                    log('changetitle error %r' % e)
        else:
            log('error FindCommands changetitle - no records found!')        
        ### RENAME command
        c.execute("SELECT * FROM files WHERE archive=? AND command=?" , [archive,'rename'])
        channels = c.fetchall()
        log('FindCommands rename archive= %r, count= %r' % (archive,len(channels)))
        x = len(channels)
        if x > 0:
            utils.notificationforced('Rename ' + str(x) + ' records in '+archive.lower()+': ', time = 1)
            for chan in channels:
                ###c.execute("INSERT OR REPLACE INTO files(filename, ext, path, video, description, size, archive, updated, created, updatedHuman, command, options) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [filename, chan[1], chan[2], chan[3], chan[4], chan[5], archive, nowTS, chan[8], humantime(nowTS), command, options])
                try:    ### Rename information and subtitles if they are available
                    urlbase = chan[0] 
                    if chan[1] != '':
                        fileext = '.' + chan[1]
                    else:
                        fileext = ''
                    urldirectorypath = utils.geturldirectorypath(archive)     
                    path = chan[2]
                    if path != '':
                        urldirectorypath = os.path.join(urldirectorypath,path)   
                    if not os.path.exists(urldirectorypath):
                        log('os.makedirs(urldirectorypath= %r' % urldirectorypath)
                        os.makedirs(urldirectorypath)    
                    log('FindCommands rename archive= %r, urldirectorypath= %r' % (archive, urldirectorypath))
                    urlnewi = chan[11]
                    if urlnewi != '':
                        urlnewi = recordings.latin1_to_ascii_force(urlnewi)   ### use only acceptable characters
                        urlnewi = ' '.join(urlnewi.split())  ## Remove doublespaces etc
                        urlnew = os.path.join(urldirectorypath,urlnewi)
                        pathofdestination = os.path.dirname(urlnew)
                        log('pathofdestination= %r' % pathofdestination)
                        if not os.path.exists(pathofdestination):
                            log('os.makedirs(pathofdestination= %r'  % pathofdestination)
                            os.makedirs(pathofdestination)  
                        log('urlnew= %r' % urlnew)
                        urlbase = os.path.join(urldirectorypath,urlbase)
                        log('urlbase= %r' % urlbase)
                        log('rename urlbase+fileext= %s, urlnew+fileext= %s' % (urlbase+fileext, urlnew+fileext))
                        urlbase = urlbase.replace('aMp ','& ').replace('xXx','+')   ### 2019-03-17
                        ###os.rename(urlbase+fileext,urlnew+fileext)
                        shutil.move(urlbase+fileext,urlnew+fileext)
                        try:
                            shutil.move(urlbase+'.txt',urlnew+'.txt')
                        except Exception as e:
                            pass
                            log('Rename error %r' % e)
                        try:
                            shutil.move(urlbase+'.srt',urlnew+'.srt')
                        except Exception as e:
                            pass
                            log('Rename error %r' % e)
                        try:
                            shutil.move(urlbase+'.en.srt',urlnew+'.en.srt')
                        except Exception as e:
                            pass
                            log('Rename error %r' % e)
                        try:
                            shutil.move(urlbase+'.da.srt',urlnew+'.da.srt')
                        except Exception as e:
                            pass
                            log('Rename error %r' % e)
                        try:
                            shutil.move(urlbase+'.xml',urlnew+'.xml')
                        except Exception as e:
                            pass
                            log('Rename error %r' % e)
                        try:
                            shutil.move(urlbase+'.en.xml',urlnew+'.en.xml')
                        except Exception as e:
                            pass
                            log('Rename error %r' % e)
                        try:
                            shutil.move(urlbase+'.da.xml',urlnew+'.da.xml')
                        except Exception as e:
                            pass
                            log('Rename error %r' % e)
                        try:
                            shutil.move(urlbase+'.nfo',urlnew+'.nfo')
                        except Exception as e:
                            pass
                            log('Rename error %r' % e)
                        try:
                            shutil.move(urlbase+'.tit',urlnew+'.tit')
                        except Exception as e:
                            pass
                            log('Rename error %r' % e)
                        try:
                            shutil.move(urlbase+'.log',urlnew+'.log')
                        except Exception as e:
                            pass
                            log('Rename error %r' % e)
                except Exception as e:
                    pass
                    log('Rename error %r' % e)
        else:
            log('FindCommands rename - no records found!')
        
        ### MOVE command
        c.execute("SELECT * FROM files WHERE archive=? AND command=?" , [archive,'move'])
        channels = c.fetchall()
        log('FindCommands move to/from archive= %r, count= %r' % (archive,len(channels)))
        x = len(channels)
        if x > 0:
            utils.notificationforced('Move ' + str(x) + ' records in '+archive.lower()+': ', time = 1)
            for chan in channels:
                ###c.execute("INSERT OR REPLACE INTO files(filename, ext, path, video, description, size, archive, updated, created, updatedHuman, command, options) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [filename, chan[1], chan[2], chan[3], chan[4], chan[5], archive, nowTS, chan[8], humantime(nowTS), command, options])
                try:    ### Rename information and subtitles if they are available
                    urlbase = chan[0] 
                    if chan[1] != '':
                        fileext = '.' + chan[1]
                    else:
                        fileext = ''
                    urldirectorypath = utils.geturldirectorypath(archive)
                    options = chan[11]
                    urldirectorydestinationpath = geturldirectorydestinationpath(options)
                    path = chan[2]
                    if path != '':
                        urldirectorypath = os.path.join(urldirectorypath,path)   
                        urldirectorydestinationpath = os.path.join(urldirectorydestinationpath,path)   
                    if not os.path.exists(urldirectorypath):
                        log('os.makedirs(urldirectorypath= %r' % urldirectorypath)
                        os.makedirs(urldirectorypath)   
                    if not os.path.exists(urldirectorydestinationpath):
                        log('1. os.makedirs(urldirectorydestinationpath= %r' % urldirectorydestinationpath)
                        os.makedirs(urldirectorydestinationpath)   
                    log('FindCommands move to/from archive= %r, urldirectorypath= %r' % (archive, urldirectorypath))
                    log('FindCommands move to/from archive= %r, urldirectorydestinationpath= %r' % (archive, urldirectorydestinationpath))
                    urlnewi = chan[11]
                    if urlnewi != '':
                        urlnewi = recordings.latin1_to_ascii_force(urlnewi)   ### use only acceptable characters
                        urlnewi = ' '.join(urlnewi.split())  ## Remove doublespaces etc
                        urlnew = os.path.join(urldirectorydestinationpath,urlnewi)
                        log('urlnew= %r' % urlnew)
                        urlbase = os.path.join(urldirectorypath,urlbase)
                        log('urlbase= %r' % urlbase)
                        log('move urlbase+fileext= %s, urlnew+fileext= %s' % (urlbase+fileext, urlnew+fileext))
                        shutil.move(urlbase+fileext,urlnew+fileext)
                        try:
                            shutil.move(urlbase+'.txt',urlnew+'.txt')
                        except Exception as e:
                            pass
                            log('move error %r' % e)
                        try:
                            shutil.move(urlbase+'.tit',urlnew+'.tit')
                        except Exception as e:
                            pass
                            log('move error %r' % e)    
                        try:
                            shutil.move(urlbase+'.srt',urlnew+'.srt')
                        except Exception as e:
                            pass
                            log('move error %r' % e)
                        try:
                            shutil.move(urlbase+'.en.srt',urlnew+'.en.srt')
                        except Exception as e:
                            pass
                            log('move error %r' % e)
                        try:
                            shutil.move(urlbase+'.da.srt',urlnew+'.da.srt')
                        except Exception as e:
                            pass
                            log('move error %r' % e)
                        try:
                            shutil.move(urlbase+'.xml',urlnew+'.xml')
                        except Exception as e:
                            pass
                            log('move error %r' % e)
                        try:
                            shutil.move(urlbase+'.en.xml',urlnew+'.en.xml')
                        except Exception as e:
                            pass
                            log('move error %r' % e)
                        try:
                            shutil.move(urlbase+'.da.xml',urlnew+'.da.xml')
                        except Exception as e:
                            pass
                            log('move error %r' % e)
                        try:
                            shutil.move(urlbase+'.nfo',urlnew+'.nfo')
                        except Exception as e:
                            pass
                            log('move error %r' % e)
                        try:
                            shutil.move(urlbase+'.log',urlnew+'.log')
                        except Exception as e:
                            pass
                            log('move error %r' % e)
                except Exception as e:
                    pass
                    log('move error %r' % e)
                
        else:
            log('FindCommands move - no records found!')
        
        ### MOVE to FOLDER command
        c.execute("SELECT * FROM files WHERE archive=? AND command=?" , [archive,'movetofolder'])
        channels = c.fetchall()
        log('FindCommands movetofolder= %r, count= %r' % (archive,len(channels)))
        x = len(channels)
        if x > 0:
            utils.notificationforced('Move to folder: ' + str(x) + ' records in '+archive.lower()+': ', time = 1)
            for chan in channels:
                ###c.execute("INSERT OR REPLACE INTO files(filename, ext, path, video, description, size, archive, updated, created, updatedHuman, command, options) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [filename, chan[1], chan[2], chan[3], chan[4], chan[5], archive, nowTS, chan[8], humantime(nowTS), command, options])
                try:    
                    options = chan[11]
                    log('1250 error options= %r' % options)
                    urldirectorydestinationpath = geturldirectorydestinationpath(options)
                    urlbase = chan[0] 
                    archive = chan[6] 
                    urldirectorypath = utils.geturldirectorypath(archive)
                    if chan[1] != '':
                        fileext = '.' + chan[1]
                    else:
                        fileext = ''
                    path = chan[2]
                    if path != '':
                        urldirectorypath = os.path.join(urldirectorypath,path)   
                        ###urldirectorydestinationpath = os.path.join(urldirectorydestinationpath,path)   ### Don't keep source directory
                    if not os.path.exists(urldirectorypath):
                        log('os.makedirs(urldirectorypath= %r' % urldirectorypath)
                        os.makedirs(urldirectorypath)      
                    log('1289 error FindCommands move to folder src= %r, urldirectorypath= %r' % (archive, urldirectorypath))
                    log('1290 error FindCommands move to folder dst= %r, urldirectorydestinationpath= %r' % (archive, urldirectorydestinationpath))
                    urlnewi = options
                    log('FindCommands move to folder urlnewi= %r, urlnewi[:2]= %r, urlnewi[2:]= %r' % (urlnewi, urlnewi[:2], urlnewi[2:]))
                    
                    log('1297 error FindCommands move to folder dst= %r, urldirectorydestinationpath= %r' % (options, urldirectorydestinationpath))
                    pathnew = urlnewi[2:]
                    if '\\' in urldirectorydestinationpath:
                        pathnew = pathnew.replace('/','\\')
                    urldirectorydestinationpath = os.path.join(urldirectorydestinationpath,pathnew)
                    log('urldirectorydestinationpath= %r' % urldirectorydestinationpath)
                    if not os.path.exists(urldirectorydestinationpath):
                        os.makedirs(urldirectorydestinationpath) 
                        log('Greate new folder if necessary: urldirectorydestinationpath= %r'% urldirectorydestinationpath)
                        ### 2019-09-11 Greate new folder if necessary
                    if urlnewi != '':
                        urlnew = os.path.join(urldirectorydestinationpath,urlbase)
                        log('urlnew= %r' % urlnew)
                        urlbase = os.path.join(urldirectorypath,urlbase)
                        log('movetofolder urlbase+fileext= %s, urlnew+fileext= %s' % (urlbase+fileext, urlnew+fileext))
                        shutil.move(urlbase+fileext,urlnew+fileext)
                        try:
                            shutil.move(urlbase+'.txt',urlnew+'.txt')
                        except Exception as e:
                            pass
                            log('998 move to folder error %r' % e)
                        try:
                            shutil.move(urlbase+'.tit',urlnew+'.tit')
                        except Exception as e:
                            pass
                            log('998 move to folder error %r' % e)
                        try:
                            shutil.move(urlbase+'.srt',urlnew+'.srt')
                        except Exception as e:
                            pass
                            log('1003 move to folder error %r' % e)
                        try:
                            shutil.move(urlbase+'.en.srt',urlnew+'.en.srt')
                        except Exception as e:
                            pass
                            log('1008 move to folder error %r' % e)
                        try:
                            shutil.move(urlbase+'.da.srt',urlnew+'.da.srt')
                        except Exception as e:
                            pass
                            log('1013 move to folder error %r' % e)
                        try:
                            shutil.move(urlbase+'.xml',urlnew+'.xml')
                        except Exception as e:
                            pass
                            log('1003 move to folder error %r' % e)
                        try:
                            shutil.move(urlbase+'.en.xml',urlnew+'.en.xml')
                        except Exception as e:
                            pass
                            log('1008 move to folder error %r' % e)
                        try:
                            shutil.move(urlbase+'.da.xml',urlnew+'.da.xml')
                        except Exception as e:
                            pass
                            log('1013 move to folder error %r' % e)
                        try:
                            shutil.move(urlbase+'.nfo',urlnew+'.nfo')
                        except Exception as e:
                            pass
                            log('1018 move to folder error %r' % e)
                        try:
                            shutil.move(urlbase+'.log',urlnew+'.log')
                        except Exception as e:
                            pass
                            log('1023 move to folder error %r' % e)
                except Exception as e:
                    pass
                    log('1026 move to folder error %r' % e)
                
        else:
            log('FindCommands move to folder - no records found!')
        
        ### DELETE command
        c.execute("SELECT * FROM files WHERE archive=? AND command=?" , [archive,'delete'])
        channels = c.fetchall()
        log('FindCommands rename archive= %r, count= %r' % (archive,len(channels)))
        x = len(channels)
        if x > 0:
            utils.notificationforced('DELETE ' + str(x) + ' records in '+archive.lower()+': ', time = 1)
            for chan in channels:
                ###c.execute("INSERT OR REPLACE INTO files(filename, ext, path, video, description, size, archive, updated, created, updatedHuman, command, options) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [filename, chan[1], chan[2], chan[3], chan[4], chan[5], archive, nowTS, chan[8], humantime(nowTS), command, options])
                try:    ### Rename information and subtitles if they are available
                    urlbase = chan[0] 
                    if chan[1] != '':
                        fileext = '.' + chan[1]
                    else:
                        fileext = ''
                    urldirectorypath = utils.geturldirectorypath(archive)
                    path = chan[2]
                    if path != '':
                        urldirectorypath = os.path.join(urldirectorypath,path)     
                    log('FindCommands delete archive= %r, urldirectorypath= %r' % (archive, urldirectorypath))
                    urlnewi = chan[11]
                    if urlbase != '':
                        urlbase = os.path.join(urldirectorypath,urlbase)
                        log('urlbase= %r' % urlbase)
                        log('delete urlbase+fileext= %s' % (urlbase+fileext))
                        os.remove(urlbase+fileext)
                        try:
                            os.remove(urlbase+'.txt')
                        except Exception as e:
                            pass
                            log('Delete error %r' % e)
                        try:
                            os.remove(urlbase+'.tit')
                        except Exception as e:
                            pass
                            log('Delete error %r' % e)
                        try:
                            os.remove(urlbase+'.srt')
                        except Exception as e:
                            pass
                            log('Delete error %r' % e)
                        try:
                            os.remove(urlbase+'.en.srt')
                        except Exception as e:
                            pass
                            log('Delete error %r' % e)
                        try:
                            os.remove(urlbase+'.da.srt')
                        except Exception as e:
                            pass
                            log('Delete error %r' % e)
                        try:
                            os.remove(urlbase+'.xml')
                        except Exception as e:
                            pass
                            log('Delete error %r' % e)
                        try:
                            os.remove(urlbase+'.en.xml')
                        except Exception as e:
                            pass
                            log('Delete error %r' % e)
                        try:
                            os.remove(urlbase+'.da.xml')
                        except Exception as e:
                            pass
                            log('Delete error %r' % e)
                        try:
                            os.remove(urlbase+'.nfo')
                        except Exception as e:
                            pass
                            log('Delete error %r' % e)
                        try:
                            os.remove(urlbase+'.log')
                        except Exception as e:
                            pass
                            log('Delete error %r' % e)
                except Exception as e:
                    pass
                    log('Delete error %r' % e)
        else:
            log('FindCommands Delete - no records found!')
    except Exception as e:
        pass
        log('FindCommands ERROR: %r' % e)

def setFileDuration(filename,archive,duration):
    try:
        archive = archive.upper()
        log('error setFileDuration filename= %r, duration= %r' % (filename,duration) )
        conf = recordings.getFilesConnection()
        c = conf.cursor()
        if '.' in filename:
            ext = filename.split('.')[-1]
            filename = filename.split('.'+ext)[0]
        else:
            ext = ''
        c.execute("SELECT * FROM files WHERE filename=? AND ext=? AND archive = ?", [filename,ext,archive]) 
        selected = c.fetchall()
        log('error setFileDuration selected count= %r' % len(selected) )
        for chan in selected:
            ###c.execute("INSERT OR REPLACE INTO files(filename, ext, path, video, description, size, archive, updated, created, updatedHuman, command, options, realtitle, startmark) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [filename, chan[1], chan[2], chan[3], chan[4], chan[5], archive, nowTS, chan[8], humantime(nowTS), command, options, realtitle, startmark])
            log('error addFile setFileDuration filename= %r, duration= %r' % (chan[0],duration) )
            recordings.addFile(c, chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[12], chan[13], chan[14], duration)  
            
        conf.commit()
        c.close() 
    except Exception as e:
        pass
        log('setFileDuration ERROR: %r' % e )

def getMyVideosConnection():    
    MyVideos_DB = utils.MyVideos_DB()
    dbPath = xbmcvfs.translatePath('special://masterprofile/')
    log('err MyVideos dbPath= %r' % dbPath)
    log('err MyVideos os.path.join(dbPath, MyVideos_DB)= %r' % os.path.join(dbPath, 'Database', MyVideos_DB))
    conn   = sqlite3.connect(os.path.join(dbPath, 'Database', MyVideos_DB), timeout = 20, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    return conn

def getDurationFromDatabase(file,archive):
    log('errorY 1525 getDurationFromDatabase file= %r, archive= %r' % (file,archive))
    dfile = os.path.dirname(file) + os.sep
    idPath = 0
    bfile = os.path.basename(file)
    conn = getMyVideosConnection()
    c = conn.cursor()
    log('errorY 1531 getDurationFromDatabase dfile= %r' % dfile)    
    c.execute("SELECT * FROM path WHERE strPath=?",[dfile])
    idPaths = c.fetchall()
    log('errorY 1533 getDurationFromDatabase len(idPaths)= %r' % len(idPaths))   
    if len(idPaths) == 1:
        for idPathi in idPaths:
            idPath = idPathi[0]
            log('errorY 1536 getDurationFromDatabase idPath= %r' % idPath)    
            c.execute("SELECT * FROM files WHERE strFilename = ? AND idPath=?",[bfile,idPath])
            filematch = c.fetchall()
            log('error 1540 file= %r, len(filematch)= %r' % (bfile, len(filematch)))
            for ifile in filematch:
                idFile  = ifile[0]
                log('errorY 1536 getDurationFromDatabase idFile= %r' % idFile) 
                c.execute("SELECT iVideoDuration FROM streamdetails WHERE idFile = ? AND iStreamType = 0",[idFile])
                durationl = c.fetchall()
                log('error 1546 file= %r, len(durationl)= %r' % (bfile, len(durationl)))
                for durationi in durationl:
                    duration = durationi[0]
                    log('error 1549 file= %r, duration= %r' % (bfile, duration))
                    if duration != None and duration > 0:
                        hmduration = utils.hmduration(duration/60 + 1)
                        setFileDuration(bfile,archive,hmduration)
                        log('error 1513 getDurationFromDatabase hmduration= %r' % hmduration)
                        return hmduration
    return ''
   
def addDuration(TotalDuration,Duration):
    try:
        if 'h' in Duration and 'm' in Duration:
            dura = Duration.split('m')[0].split('h')
            TotalDuration += 60 * int(dura[0]) + int(dura[1])
    except Exception as e:
        pass
        log('addDuration (TotalDuration= %r, Duration= %r) Error: %r '% (TotalDuration,Duration,e))
    log('addDuration (TotalDuration= %r, Duration= %r)'% (TotalDuration,Duration))
    return TotalDuration
    
def ScanFiles(c,folderPath,archive,excommand=True):
    log('errorY ScanFiles(folderPath= %r, archive= %r)'% (folderPath,archive))
    freespace = utils.get_free_space_gb(folderPath,archive)
    log('error utils.get_free_space_gb(folderPath= %r)= %r' % (folderPath,freespace))
    folderPathScan = folderPath.replace(':','').replace(' ','')
    Length = -2
    if freespace == 0:
        notetext = 'No File Scanning of '+archive+' as it reports no room/access!'
        utils.ADDONsetSetting('filescanstatus',notetext)
        utils.notificationforced('No File Scanning of '+archive+' as it reports no room/access!')
        log('error notetext 2 %r' % notetext)
    elif locking.isScanLocked('ScanFiles'+folderPathScan):
        notetext = 'No File Scanning of '+archive+' as it is still running!'
        utils.ADDONsetSetting('filescanstatus',notetext)
        utils.notificationforced('No File Scanning of '+archive+' as it is still running!')
        log('error notetext 2 %r' % notetext)
    else:
        notetext = 'File Scanning Started of '+archive+'!'
        utils.ADDONsetSetting('filescanstatus',notetext)
        utils.notificationforced('File Scanning Started of '+archive+'!')
        log('error notetext 1 %r' % notetext)
        locking.scanLock('ScanFiles'+folderPathScan)
        log('error ScanFiles %r' % folderPathScan)
        now = datetime.now()
        i = 0
        j = 0
        TotalDuration = 0  ### Minutes
        cutoffnowTS = int(datetime.timestamp(now))
        tstart = datetime.today()
        if excommand == True:
            FindCommands(c,folderPath,archive)
        for infile in find_files(folderPath, '*'):
            Duration = ''
            if j%25 == 0 and j > 0:
                notetext = 'Scanning videos in '+archive.lower()+': '+str(j)+ '# ' + str(TotalDuration//60).split('.')[0]+'h'  ### 2021-06-21
                utils.ADDONsetSetting('filescanstatus',notetext)
                utils.notification('Scanning videos in '+archive.lower()+': '+str(j)+ '# ' + str(TotalDuration//60).split('.')[0]+'h', time = 1)  ### 2021-06-21
            i +=1
            try:
                fileext = ''
                fileextt = ''
                if '.' in infile:
                    fileext = infile.split('.')[-1]
                    log('1282 infile= %r, fileext= %r' % (infile, fileext))
                    fileextt = '.' + fileext
            except Exception as e:
                pass
                notetext = 'ERROR in find_files. infile= %r\nERROR: %r' % (infile,e)
                utils.ADDONsetSetting('filescanstatus',notetext)
                log('ERROR in find_files. infile= %r\nERROR: %r' % (infile,e))
                fileext = repr(e)
                fileextt = fileext
            infilebasename = os.path.basename(infile).replace(fileextt,'',-1) # the file name only
            if len(folderPath)>0:
                pathoffile = os.path.dirname(infile).replace(folderPath[:-1],'',1)
                if len(pathoffile) >0:
                    pathoffile = pathoffile[1:]
            else:
                pathoffile = ''
            video = repr(isExtKnown(infile))
            log('1. video= %r\n%r' % (video,infile))
            titlefilename = infile.replace(fileextt,'.tit',-1)
            
            descriptionfilename = infile.replace(fileextt,'.txt',-1)
            description = ''
            realtitle = infilebasename
            log('0 realtitle= %r' % realtitle)
            startmark = ''
            if not os.path.isfile(titlefilename):
                if os.path.isfile(descriptionfilename):
                    try:
                        descf = io.open(descriptionfilename,'r') ###, encoding="utf-8")   ###io.open(infile, 'r', encoding="utf-8")
                        desc = descf.read()
                        descf.close()
                        desc = desc.split('Title= ')
                        realtitle = desc[1].split('\n')[0]
                        if realtitle != '':
                            LF = open(titlefilename, 'w')  ### 2021-02-01
                            LF.write(realtitle)
                            LF.close()
                    except Exception as e:
                        pass
                        log('realtitle/tit= %r\nERROR: %r ' % (titlefilename,e))        
            else:
                try:               ### Description:
                    bom = utils.bomType(titlefilename)
                    log('err bom= %r\n titlefilename= %r' % (bom, titlefilename))
                    descf = io.open(titlefilename,'r', encoding="utf-8")   ###io.open(infile, 'r', encoding="utf-8")
                    desc = descf.read()
                    descf.close()
                    desc = desc.split('\n')
                    realtitle = desc[0]
                    log('err realtitle= ' + repr(realtitle))
                    try:
                        startmark = desc[1]
                        log('startmark= ' + repr(startmark))
                    except Exception as e:
                        pass
                        log('startmark ERROR 0 ' + repr(e))
                except Exception as e: 
                    pass
                    try:               ### Description:
                        descf = io.open(titlefilename,'r', encoding="cp1252")   ###io.open(infile, 'r', encoding="utf-8")
                        desc = descf.read()
                        descf.close()
                        desc = desc.split('\n')
                        realtitle = desc[0]
                        log('err realtitle= ' + repr(realtitle))
                        try:
                            startmark = desc[1]
                            log('startmark= ' + repr(startmark))
                        except Exception as e:
                            pass
                            log('startmark ERROR 1 ' + repr(e))
                    except Exception as e: 
                        pass
                        realtitle = 'Title Error: ' + repr(e)
                        log('realtitle= %r\nERROR= %r' % (titlefilename,e))
            log('error realtitle= %r' % realtitle)
            log('errorY 1686 ScanFiles(folderPath= %r, archive= %r)'% (folderPath,archive))
            if video == 'True':
                j +=1
                desc = ' NOT SET '
                if os.path.isfile(descriptionfilename):
                    try:               ### Description:
                        ###stats = os.stat(descriptionfilename)
                        ###log('1554 errorX os.stat(descriptionfilename)= %r\n%r' % (descriptionfilename,stats))  ###2023-03-15
                        bom = utils.bomType(descriptionfilename)
                        log('err bom= %r\n descriptionfilename= %r' % (bom, descriptionfilename))
                        log('err 1423 descriptionfilename= %r' % descriptionfilename, showlength=100000)
                        ###descf = io.open(descriptionfilename,'r', encoding="utf-8")   ###io.open(infile, 'r', encoding="utf-8")
                        ###xbmcvfs.File.read
                        from contextlib import closing
                        from xbmcvfs import File

                        with closing(File(descriptionfilename)) as fo:
                            desc = fo.read()
                        ###descf = open(descriptionfilename,'r')   #, encoding="utf-8")   ###io.open(infile, 'r', encoding="utf-8")
                        ###log('err 1425 descf= %r' % descf, showlength=100000)
                        ###desc = descf.read()
                        log('err 1427 desc= %r' % desc, showlength=100000)
                        descf.close()
                        description = 'Description:\n' + desc.split('Description:')[1]
                        ###log('desc= ' + repr(desc))
                    except Exception as e: 
                        pass
                        description = repr(descriptionfilename) +' Error: ' + repr(e)
                        log('1441 ERROR= %r\ndescription= %r' % (e,desc),showlength=100000)
                        try:
                            with open(descriptionfilename, 'r', encoding='cp1252') as f1:
                                lines = f1.read()
                                log('err 445 lines= %r' % lines, showlength=100000)
                                ###f2 = open(descriptionfilename, 'w', encoding='utf-8')
                                ###f2.write(lines)
                                ###f2.close()
                                description = 'Description:\n' + lines.split('Description:')[1]
                        except Exception as e: 
                            pass  
                            log('1450 ERROR= %r\ndescription= %r' % (e,desc),showlength=100000)
                            description = repr(descriptionfilename) +' cp1252 Error: ' + repr(e)
            log('errorY 1727 ScanFiles(folderPath= %r, archive= %r)'% (folderPath,archive))
            subtitlefilename = infile.replace(fileextt,'.en.srt',-1)
            if os.path.isfile(subtitlefilename):
                st = xbmcvfs.Stat(subtitlefilename)
                subtitlefilensize = st.st_size()
            else:
                subtitlefilensize = 0
            if video == 'True' and subtitlefilensize > 0 :
                subtitlesavailable = True
            else:
                subtitlesavailable = False
            if subtitlesavailable:
                description = 'English subtitles available\n\n' + description
                noensubtitles = False
            else:
                noensubtitles = True
            subtitlefilename = infile.replace(fileextt,'.da.srt',-1)
            if os.path.isfile(subtitlefilename):
                st = xbmcvfs.Stat(subtitlefilename)
                subtitlefilensize = st.st_size()
            else:
                subtitlefilensize = 0
            if video == 'True' and subtitlefilensize > 0 :
                subtitlesavailable = True
            else:
                subtitlesavailable = False
            if subtitlesavailable:
                description = 'Danish subtitles available\n\n' + description
            else:
                if noensubtitles:
                    description = 'No subtitles available\n\n' + description    
            
            try:
                FileData = ''
                ###FileSize = repr(float(int(long(os.stat(infile).st_size)/long(1024*1024)))/1000)
                FileSz    = float(os.stat(infile).st_size)
                FileSzGB  = FileSz/(1024*1024*1024)
                log('Has size %r size in GB %r' % (FileSz,FileSzGB))
                FileSize = format(FileSzGB, '.3f')
                log('FileSize %r' % (FileSize))
                try:
                    filetime = recordings.humantime(int(os.path.getmtime(infile)))
                except Exception as e:
                    pass
                    filetime = 'ERROR in filetime: ' + repr(e)
                FileData = 'Size: '+ FileSize + ' GB\nDate: ' + filetime
                log('1. FileData= %r' % FileData)
                log('errorY 1774 ScanFiles(folderPath= %r, archive= %r)'% (folderPath,archive))
                if video == 'True':
                    fDuration = getDurationFromDatabase(infile,archive)
                    log('error getDurationFromDatabase filename= %r, fileduration= %r' % (infile,fDuration) )
                    if infile[:1] == '[':   ### 2019-03-11
                        nameparts = infile.split(']',1)
                        name = nameparts[1] + ' ' + nameparts[0] + ']'
                        name = name.strip()
                    else:
                        name = infile
                    log('errorY 1784 ScanFiles(folderPath= %r, archive= %r)'% (folderPath,archive))
                    try:
                        Duration = name.split('[',1)[1].split(']',1)[0]
                        log('error Duration 1= %r' % Duration)
                        if '2h00m' in Duration or '4h00m' in Duration or Duration == '':
                            Duration = fDuration
                        elif not 'h' in Duration or not 'm' in Duration:
                            log('error Duration 2= %r' % Duration)
                            Duration = name.split(']')[-2].split('[')[-1].split(' ')[-1]
                            log('error Duration 3= %r' % Duration)
                            if not 'h' in Duration or not 'm' in Duration or Duration == '' or len(Duration) > 6:
                                Duration = fDuration
                                log('error Duration 4= %r' % Duration)
                    except Exception as e:
                        pass
                        log('infile= %r\nDuration ERROR: %r' % (infile,e))
                        Duration = fDuration
                    log('error Duration 5= %r' % Duration)
                    TotalDuration = addDuration(TotalDuration,Duration)
                    Length = 0
                    try:
                        if Duration != '':
                            Length = int(Duration.split('h')[0])*60 + int(Duration.split('h')[1].split('m')[0])
                            FileData += '\nDuration: '+Duration+' '+str(Length)+'m'
                            log('2. FileData= %r' % FileData)
                    except Exception as e:
                        pass
                        log('Duration2 ERROR: %r' % e)
                        FileData += '\n\n' + repr(e)
                    filename = infile
                    if '/' in filename:
                        filename = filename.split('/')[-1]
                    elif '\\' in filename: 
                        filename = filename.split('\\')[-1]
                    Length = utils.SeriesEpisode(realtitle,module)   
                    if Length == 0:
                        Length = utils.SeriesEpisode(filename,module)    
                    try:
                        log('7. Length= %r' % Length)
                        ###if Length != -1:
                        if Length > 0:
                            SeriesEpisode = '\nSeries/Episode: S' + str(Length//1000) + 'E' + str(Length%1000)
                            log('1. SeriesEpisode= %r' % SeriesEpisode)
                            ###utils.logdev('SeriesEpisode','Length= %r' % Length)
                            FileData += SeriesEpisode
                            log('3. FileData= %r' % FileData)
                    except Exception as e:
                        pass
                        log('SeriesEpisode Error 1: %r' % e)
                        FileData += '\n\n' + repr(e)
                
            except Exception as e:
                pass
                log('SeriesEpisode Error2: %r' % e)
                FileData += '\n\n' + repr(e)
                log('4. FileData= %r' % FileData)
            log('8. Length= %r' % Length)
            recordings.addFile(c, infilebasename, fileext, pathoffile, video, description, FileData, archive, realtitle, startmark, Duration)  ### Archive/Local
        tend = datetime.today()
        notetext = TimeUsed(tend,tstart) + ' @ ' + datetime.today().strftime('%Y-%m-%d %H:%M:%S') + ' with : '+str(j)+ '# ' + str(TotalDuration//60)+'h'  ### 2021-06-21
        utils.ADDONsetSetting('filescanstatus',notetext)
        utils.notification('Scanning videos ended in '+archive.lower()+': '+str(j)+ '# ' + str(TotalDuration//60)+'h', time = 10)  
        if archive.lower() == 'l':
            utils.ADDONsetSetting('filescanlocal',notetext)
        elif archive.lower() == 'a':
            utils.ADDONsetSetting('filescanarchive',notetext)
        elif archive.lower() == 'b':
            utils.ADDONsetSetting('filescanarchiveb',notetext)
        else:
            utils.ADDONsetSetting('filescanarchive',notetext)
        ### 2021-06-21
        ### Find outdated records
        recordings.addFileCleanup(c,folderPath,archive,cutoffnowTS)
        notetext = 'File Scanning of '+archive+' Finished!'
        utils.ADDONsetSetting('filescanstatus',notetext)
        utils.notificationforced('File Scanning of '+archive+' Finished!')
        locking.scanUnlock('ScanFiles'+folderPathScan)
      
def ScanRecordings():
    log('error ScanRecordings Start')
    try:
        conf = recordings.getFilesConnection()
        recordings.createFileTable(conf)
        c = conf.cursor()
        recordPathBasic = utils.ADDONgetSetting('record_path')
        if recordPathBasic == '':
            recordPathBasic = utils.ADDONgetSetting('record_path')
        recordPath = xbmcvfs.translatePath(os.path.join(recordPathBasic))
        ScanFiles(c,recordPath,'L')
        conf.commit()
           
        if utils.ADDONgetSetting('record_archive_path_enable') == 'true':
            recordPathBasic = utils.ADDONgetSetting('record_archive_path')
            if recordPathBasic == '':
                recordPathBasic = utils.ADDONgetSetting('record_archive_path')
            recordArchivePath = xbmcvfs.translatePath(os.path.join(recordPathBasic))
            ScanFiles(c,recordArchivePath,'A')
            conf.commit()
            ScanFiles(c,recordPath,'L')  ###Scan local again
        
        if utils.ADDONgetSetting('record_archiveb_path_enable') == 'true':
            recordPathBasic = utils.ADDONgetSetting('record_archiveb_path')
            if recordPathBasic == '':
                recordPathBasic = utils.ADDONgetSetting('record_archiveb_path')
            recordArchivePath = xbmcvfs.translatePath(os.path.join(recordPathBasic))
            ScanFiles(c,recordArchivePath,'B')
            conf.commit()
            ScanFiles(c,recordPath,'L')  ###Scan local again
         
        conf.commit()
        c.close() 
        recordings.copyFileBase()
    except Exception as e:
        pass
        log('ScanRecordings ERROR: %r' % e )
        
def ScanLocalRecordings():
    try:
        log('error ScanLocalRecordings')
        conf = recordings.getFilesConnection()
        recordings.createFileTable(conf)
        c = conf.cursor()
        recordPathBasic = utils.ADDONgetSetting('record_path')
        if recordPathBasic == '':
            recordPathBasic = utils.ADDONgetSetting('record_path')
        recordPath = xbmcvfs.translatePath(os.path.join(recordPathBasic))
        ScanFiles(c,recordPath,'L')
        conf.commit()
        c.close() 
        recordings.copyFileBase()
    except Exception as e:
        pass
        log('ScanRecordings Local ERROR: %r' % e )
    
def TimeUsed(ended,now):
    try:
        log('err TimeUsed(ended= %r, now= %r)' % (ended,now))
        log('err TimeUsed(ended-now)= %r)' % (ended-now))
        timeused1 = repr(ended-now)
        if 'datetime.timedelta(seconds=' in timeused1:
            timeused = int(timeused1.replace('datetime.timedelta(seconds=','').split(',')[0])
            log('err TimeUsed(seconds)= %r)' % timeused)
        else:
            timeused = 0
            log('err TimeUsed(timeused1)= %r)' % timeused1)
        log('err timeused= %r' % timeused)
        timeusedM = int(timeused//60)
        timeusedS = (timeused - timeusedM*60)
        timeusedMS = str(timeusedM) + 'm' + str(timeusedS).zfill(2) + 's'
        log('err timeusedMS= %r' % timeusedMS)
    except Exception as e:
        pass
        timeusedMS = 'timeused ERROR %r' % e
        log('timeusedMS ERROR %r' % e)
    return timeusedMS
    
def limitChannels(name,categoritype,categori):
    if categori != '':
        try:
            if not recordings.isCategoriAvailable(categori, categoritype) :
                recordings.addCategori(categori, categoritype, 'updateepg')
        except Exception as e:
            pass
            log('1979 recordings.addCategori %r\nERROR %r' % (categori,e))    
        try:
            if recordings.isCategoriActive(categori, categoritype) :
                return True 
            else:
                return False
        except Exception as e:
            pass
            log('1979 recordings.addCategori %r\nERROR %r' % (categori,e))   
    return True        
    """
    ###namecharset = utils.bomTypeText(name)
    ###log('errorX utils.bomTypeText(name= %r), namecharset= %r' % (name,namecharset))
    name = name.lower()
    category = category.lower()
    channelType = channelType.lower()
    if channelType != 'live':
        log('errorX channelType not live: name= %r,channelType= %r' % (name,channelType))
        acceptcategory = utils.ADDONgetSetting('acceptvodcategory').lower()
        acceptchannelswith = utils.ADDONgetSetting('acceptvodswith').lower()
        acceptchannelswithout = utils.ADDONgetSetting('acceptvodswithout').lower()
    else:
        log('errorX channelType live: name= %r,channelType= %r' % (name,channelType))
        acceptcategory = utils.ADDONgetSetting('acceptcategory').lower()
        acceptchannelswith = utils.ADDONgetSetting('acceptchannelswith').lower()
        acceptchannelswithout = utils.ADDONgetSetting('acceptchannelswithout').lower()
    acceptcategory = acceptcategory.split(',')
    acceptchannelswith = acceptchannelswith.split(',')
    acceptchannelswithout = acceptchannelswithout.split(',')
    log('1967 errorZ limitChannels(name= %r, channelType= %r, category= %r Before test) ' % (name,channelType,category))
    if category != '' and acceptcategory != '':
        for chanc in acceptcategory:
            if chanc == category :
                log('1970 errorZ limitChannels(name= %r, channelType= %r, category= %r  KEPT from category) ' % (name,channelType,category))
                return True
    elif category != '':
        try:
            ###recordings.addCategori(categori, categoritype, source)
            recordings.addCategori(category, channelType, 'updateepg')
        except Exception as e:
            pass
            log('1979 recordings.addCategori %r\nERROR %r' % (category,e))    
            
    log('1972 errorZ limitChannels(name= %r, channelType= %r, category= %r  Ignored from category) ' % (name,channelType,category))
    if acceptchannelswith == '' :
        for chanx in acceptchannelswithout:
            if chanx != '' and chanx in name:
                log('errorZ limitChannels(acceptchannelswith= %r, name= %r, channelType= %r SKIPPED 1)' % (acceptchannelswith,name,channelType))
                return False
        log('errorZ limitChannels(acceptchannelswithout= %r, name= %r, channelType= %r Kept)' % (acceptchannelswithout,name,channelType))
        return True
    for chan in acceptchannelswith:
        if chan != '' and chan in name:
            for chanx in acceptchannelswithout:
                if chanx != '' and chanx in name:
                    log('errorZ limitChannels(acceptchannelswithout= %r, name= %r, channelType= %r SKIPPED 2)' % (acceptchannelswithout,name,channelType))
                    return False
            log('errorZ limitChannels(acceptchannelswith= %r, name= %r, channelType= %r Kept)' % (acceptchannelswith,name,channelType))
            return True
    log('errorZ limitChannels(acceptchannelswith= %r, name= %r, channelType= %r SKIPPED 3)' % (acceptchannelswith,name,channelType))
    return False
    """
 
def adjustCategoryName(category_name) :
    try:
        category_name = category_name.replace('\u27be','->').replace('âž¾','->')   ### 2023-03-20 change unicode arrow
        if 'English series -' in category_name :
            category_name = category_name.split('English series -')[0]+'English series'  ### ignore text after English series
        category_name = ' '.join(category_name.split())  ## Remove doublespaces etc
        return category_name
    except Exception as e:
        pass
        return 'Category Name Error: %r' % e

if args[1] == 'once' or args[1] == 'hourly':    
    log('err args= %r' % args)
    if args[1] == 'hourly':
        recordings.updateAlarm('nameEPGt')
    log('err #1700 ScanRecordings started')
    ###recordings.updateAlarm('nameEPGfirst'
    ###recordings.updateAlarm('nameEPGt'
    updateiconsfromEPG()  ### 2022-05-09
    log('err #1709 after updateiconsfromEPG()')
    nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    utils.ADDONsetSetting('lastEPGimportInfo','Set Krogsbell Addons to switch to ' + nowS)
    krogsbellAddons()
    nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    utils.ADDONsetSetting('lastEPGimportInfo','Scan Recordings Started ' + nowS)
    ###ScanRecordings()
    if args[1] == 'hourly':  
        ScanRecordings()
    EPGimportERRORS('')
    log('err 1711')
    ### Reset Errors
    log('err Version: '+utils.version()) 
    ### log('err VersionDate: '+utils.versiondate())
    ROQuser = utils.ADDONgetSetting('user')
    ROQpass = utils.ADDONgetSetting('pass')
    log('errYYY 1724 Test recordingprograms')
    utils.testPrograms()   ### Test recordingprograms
    log('errYYY 1726 after Test recordingprograms')
    now= datetime.today()
    if locking.isScanLocked('EPG_update'):
        log('No EPG update as it is still running!')
        notification('No EPG update as it is still running!')
    else:
        notification('EPG Import Started!')
        prevEPGimportInfoData = utils.ADDONgetSetting('lastEPGimportInfoData')
        utils.ADDONsetSetting('prevEPGimportInfoData',prevEPGimportInfoData)
        log('datetime.today()'+repr(datetime.today()))
        nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        utils.ADDONsetSetting('lastEPGimportInfo','New EPG Import Started ' + nowS)
        locking.scanLock('EPG_update')
        if utils.ADDONgetSetting('enable_record')=='true':
            RecordActive = True
        else:
            RecordActive = False
        lastEPGimport = utils.ADDONgetSetting('lastEPGimport')
        if lastEPGimport == '':
            lastEPGimport = now - timedelta(hours = 24)  ### dummy lastEPGimport
            utils.ADDONsetSetting('lastEPGimport',lastEPGimport.strftime('%Y-%m-%d %H:%M:%S using'))
        log('utils.ADDONgetSetting(lastEPGimport)'+repr(lastEPGimport))
        
        try:
            lastEPGimport = parse_date(utils.ADDONgetSetting('lastEPGimport').split(' using',1)[0])
        except:
            pass
            lastEPGimport = parse_date(utils.ADDONgetSetting('lastEPGimport'))
        log('datetime.datetime(utils.ADDONgetSetting(lastEPGimport))' + repr(lastEPGimport))   
        
        cEPG = recordings.getConnection()
        recordings.createEPGchannelsTable(cEPG)
        recordings.createEPGProgramsTable(cEPG)
        c = cEPG.cursor()
        try:
            c.execute("PRAGMA journal_mode = WAL")  ### 2018-01-07 Try to speed up on Windows (1700 sec down to 700 sec)
        except Exception as e:
            pass
            log('PRAGMA journal_mode = WAL ERROR %r' % e)
        KrogsbellAddOns = definition.getKrogsbellAddOns()
        log('KrogsbellAddOns= %r' % KrogsbellAddOns)
        for kaddon in KrogsbellAddOns:
            log('kaddon= %r' % kaddon)
            try:
                kaddonID = kaddon.split('.')[2][:3].upper()
                taddonID = ADDONid.split('.')[2][:3].upper()
            except Exception as e:
                pass
                EpgError = 'Error in getting AddOn ID\n' + repr(e) 
                kaddonID = ''
                taddonID = ''
            log('kaddonID= %r' % kaddonID)
            log('taddonID= %r' % taddonID)
            if kaddonID != '' and kaddonID != taddonID:
                try:
                    NTVchannels = xbmcvfs.translatePath( xbmcaddon.Addon(id=kaddon).getAddonInfo('profile') + 'channels.csv')
                    log('NTVchannels= %r' % NTVchannels)
                except Exception as e:
                    pass
                    EpgError = 'Error in getting ' + kaddonID + ' Channels\n' + repr(e)
                    log(EpgError)
                    NTVchannels = ''
                try:  ### Get the set webport
                    webport = utils.getGuiSetting('webserverport','8080')
                except:
                    pass
                    webport = '8080'
                
                if os.path.isfile(NTVchannels):
                    log('Use ChannelFile in: ' + repr(NTVchannels))
                    nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                    utils.ADDONsetSetting('lastEPGimportInfo','Import ' + kaddonID + ' @ ' + nowS)
                    ended = datetime.today()
                    notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ###+' Src= ' + kaddonID) 
                    utils.ADDONsetSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))### +' Src= ' + kaddonID)
                    for line in open(NTVchannels):  # opened in text-mode; all EOLs are converted to '\n'
                        ###log('Line: ' + repr(i) + ' - ' + line)
                        line = line.rstrip('\n').rstrip('\r')
                        if not line == '' and not line[:2] == '# ' :   # Ignore empty lines and comment lines
                            channels += 1
                            line=line.split(',')
                            stream_id = kaddonID + line[0]
                            name = line[1] + ' (' + kaddonID + ')'
                            url = 'http://127.0.0.1:' + webport + '/jsonrpc?request={"jsonrpc":"2.0","method":"Addons.ExecuteAddon","params":{"wait":false,"addonid":"' +kaddon + '","params":["url=url","cat=' + line[0] + '","mode=210","name=' + line[1] + '","recordname='+ADDONid+'"]},"id":200}'
                            epg_channel_id = line[2]
                            stream_icon = line[3]
                            ###EPGgenerator = 'NTV Available Channels'
                            EPGgenerator = ADDONid +' available_channels'
                            displaydescription = ''
                            ChannelFav = recordings.getChannelFav(c,stream_id)
                            ChannelEpg = recordings.getChannelEpgid(c,stream_id)
                            if ChannelEpg != '':
                                epg_channel_id = ChannelEpg
                            name = ' '.join(name.split())  ## Remove doublespaces etc
                            log('1779 errXX errXX addEPGChannel(\n  c= %r, \n  stream_id= %r, \n  name= %r)' % (c, stream_id, name))
                            recordings.addEPGChannel(c, stream_id, name, url, stream_icon, epg_channel_id, EPGgenerator, epg_channel=epg_channel_id, description=displaydescription)
                            recordings.setChannelFav(c,stream_id,ChannelFav)
                            if ChannelEpg != '':
                                recordings.setChannelEpgid(c,stream_id,ChannelEpg)
                                recordings.setChannelIcon(c,stream_id,recordings.getIconfromEPG(ChannelEpg))
        if utils.ADDONgetSetting('unlim_api').lower() == 'true':
            KrogsbellAddOns = definition.getNTVAddOns()    ###  NTV addons like unlim.tv
            log('NTVAddOns= %r' % KrogsbellAddOns)
            streamtype = utils.ADDONgetSetting('streamtype').replace('0','m3u8').replace('1','ts').replace('2','rtmp')
            EPGgenerator = ADDONid +' available_channels'
            for kaddon in KrogsbellAddOns:
                log('kaddon= %r' % kaddon)
                try:
                    kaddonID = kaddon.split('.')[2][:3].upper()
                    taddonID = ADDONid.split('.')[2][:3].upper()
                except Exception as e:
                    pass
                    EpgError = 'Error in getting AddOn ID\n' + repr(e) 
                    kaddonID = ''
                    taddonID = ''
                log('kaddonID= %r' % kaddonID)
                log('taddonID= %r' % taddonID)
                if kaddonID != '' and kaddonID != taddonID:
                    try:
                        NTVchannels = xbmcvfs.translatePath( xbmcaddon.Addon(id=kaddon).getAddonInfo('profile') + 'storage/channels.json')
                        log('NTVchannels= %r' % NTVchannels)
                        NTVwww = 'https://www.touchsportstv.com' ### To be fetched from addon... 2019-10-09
                        log('NTVwww= %r' % NTVwww)
                    except Exception as e:
                        pass
                        EpgError = 'Error in getting ' + kaddonID + ' Channels\n' + repr(e)
                        log(EpgError)
                        NTVchannels = ''
                        NTVwww = ''
                    
                    if os.path.isfile(NTVchannels):
                        log('Use ChannelFile in: ' + repr(NTVchannels))
                        nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                        utils.ADDONsetSetting('lastEPGimportInfo','Import ' + kaddonID + ' @ ' + nowS)
                        ended = datetime.today()
                        notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))###+' Src= ' + kaddonID) 
                        utils.ADDONsetSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs)) ###+' Src= ' + kaddonID)
                        try:
                            file = io.open(NTVchannels,'r', encoding="utf-8")   ###io.open(infile, 'r', encoding="utf-8")
                            datapanel = file.read()
                            ###log(datapanel)
                            file.close()
                        except Exception as e:
                            pass
                            EpgError = 'Error in getting '+ NTVchannels + ' \n' + repr(e)
                            EPGimportERRORS(EpgError)
                            log('1862')
                            log(EpgError)
                            datapanel = ''
                        try:
                            datapanel = json.loads(datapanel)
                            descrpanel = 'message= %r \nStatus= %r \nExpire= %r' %(datapanel['message'],datapanel['status'],recordings.parseDate(datapanel['timestamp']).strftime('%Y-%m-%d %H:%M'))
                            log('Start datapanel' + descrpanel)
                            added = datapanel['timestamp']
                            for chan in datapanel['body']:
                                log('name= %r, country= %r, xmltv_id= %r, id= %r dvr= %r' % (chan['name'],chan['country'],chan['xmltv_id'],chan['id'],chan['dvr']))
                                stream_id = kaddonID + str(notnone(chan['id']))
                                log('stream_id= %r' % stream_id)
                                name = (notnone(chan['name']) + ' ' + kaddonID +'-'+ notnone(chan['country'])).strip()
                                log('name= %r' % name)
                                category_name = notnone(chan['category_name'])
                                log('category_name= %r' % category_name)
                                stream_icon = NTVwww + '/assets/img/channels/' + notnone(chan['logo']) 
                                log('stream_icon= %r' % stream_icon)
                                epg_channel_id = notnone(chan['xmltv_id'])
                                log('epg_channel_id= %r' % epg_channel_id)
                                tv_archive_duration = notnone(chan['dvr'])
                                log('tv_archive_duration= %r' % tv_archive_duration)
                                if chan['health'] != 1:   ### broken = '[COLOR blue] Broken[/COLOR]'
                                    tv_archive_duration = -1
                                url = kaddon
                                log('1. url= %r' % url)
                                ChannelFav = recordings.getChannelFav(c,stream_id)
                                ChannelEpg = recordings.getChannelEpgid(c,stream_id)
                                if ChannelEpg != '':
                                    epg_channel_id = ChannelEpg
                                displaydescription = 'Category: ' + category_name
                                log('recordings.addEPGChannel(c, stream_id= %r, name= %r, url= %r, stream_icon= %r, epg_channel_id= %r, EPGgenerator= %r,  description= %r)'% (stream_id, name, url, stream_icon, epg_channel_id, EPGgenerator, displaydescription))
                                name = ' '.join(name.split())  ## Remove doublespaces etc
                                log('1862 errXX addEPGChannel(\n  c= %r, \n  stream_id= %r, \n  name= %r)' % (c, stream_id, name))
                                recordings.addEPGChannel(c, stream_id, name, url, stream_icon, epg_channel_id, EPGgenerator, epg_channel=epg_channel_id, description=displaydescription)
                                recordings.setChannelCatchup(c,stream_id,tv_archive_duration)
                                recordings.setChannelFav(c,stream_id,ChannelFav)
                                if ChannelEpg != '':
                                    recordings.setChannelEpgid(c,stream_id,ChannelEpg)
                                    recordings.setChannelIcon(c,stream_id,recordings.getIconfromEPG(ChannelEpg))
                                recordings.setChannelAdded(c,stream_id,added)
                                channels += 1
                        except Exception as e:
                            pass
                            EpgError = 'Error in getting datapanel for '+ NTVchannels + ' \n' + repr(e)
                            EPGimportERRORS(EpgError)
                            log('1907')
                            log(EpgError)
                            datapanel = ''
                        
        ###if (lastEPGimport-now).total_seconds()/3600 < -12:
        ### >>>>>> ROQ TV PANEL
        ROQTVusername = utils.ADDONgetSetting('user')
        if ROQTVusername.lower() == 'none' or utils.ADDONgetSetting('panel_api') == 'false':
            utils.ADDONsetSetting('expiredate',ROQTVusername)
            utils.ADDONsetSetting('concurrentstreams',ROQTVusername)
            EPGgeneratorName = 'No User'
        else:
            ###linkpanel = definition.getBASEURL() + definition.getCOMMAND() + 'username=' +ROQuser+ '&password=' +ROQpass + definition.getCOMMANDEND()
            linkpanel = definition.getBASEURL() + '/panel_api.php?username=' +utils.ADDONgetSetting('user')+ '&password=' +utils.ADDONgetSetting('pass')
            EPGgeneratorName = 'panel_api'
            ended = datetime.today()
            notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ###+' Src= ' + EPGgeneratorName) 
            
            nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
            utils.ADDONsetSetting('lastEPGimportInfo','Import ' + EPGgeneratorName + ' @ ' + nowS)
            utils.ADDONsetSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs)) ###+' Src= ' + EPGgeneratorName)

            try:
                ChannelFile = os.path.join(datapath,ADDONid) + '.info'
                datapanel = utils.readlink(linkpanel,ChannelFile,module)
            except Exception as e:
                pass
                EpgError = 'Error in getting '+ linkpanel + ' \n' + repr(e)
                EPGimportERRORS(EpgError)
                log('1935')
                notification(EpgError)
                datapanel = ''

            try:
                datapanel = json.loads(datapanel)
                datapanel1 = datapanel['user_info']
                descrpanel = 'Username= %s \nStatus= %s \nExpire= %s \nMax connections= %s' %(datapanel1['username'],datapanel1['status'],recordings.parseDate(datapanel1['exp_date']).strftime('%Y-%m-%d %H:%M'),datapanel1['max_connections'])
                log('Start datapanel: %r' % descrpanel)
                ### expiredate/concurrentstreams
                forever = utils.ADDONgetSetting('forever')    
                if forever == 'true':
                    expiredate = 'none'
                    remainingdaysS = ''
                    log('2 expiredate= %r' % expiredate)
                else:
                    expiredate = recordings.parseDate(datapanel1['exp_date'])
                    expiredate = expiredate.strftime('%Y-%m-%d %H:%M')
                utils.ADDONsetSetting('expiredate',expiredate)     
                utils.ADDONsetSetting('concurrentstreams',str(datapanel1['max_connections']))
                datapanelS = datapanel['server_info']
                utils.ADDONsetSetting('server_info_url',str(datapanelS['url']))
                utils.ADDONsetSetting('server_info_port',str(datapanelS['port']))
                try:
                    utils.ADDONsetSetting('server_info_https_port',str(datapanelS['https_port']))
                except Exception as e:
                    pass
                    utils.ADDONsetSetting('server_info_https_port','')
                    log('Error getting https_port: %r'% e)
                try:
                    utils.ADDONsetSetting('server_info_protocol',str(datapanelS['server_protocol']))
                except Exception as e:
                    pass
                    utils.ADDONsetSetting('server_info_protocol','http')
                    log('Error getting https_port: %r'% e)
            except Exception as e:
                pass
                EpgError = 'Error in getting '+ ADDONid + ' info! Check your User ID\n' + repr(e)
                EPGimportERRORS(EpgError)
                log('1973')
                notification(EpgError)
                datapanel = []

            """
            "available_channels":{
            "281":{
            "num":1,
            "name":"UK: BBC ONE HD",
            "stream_type":"live",
            "type_name":"Live Streams",
            "stream_id":"281",
            "stream_icon":"https:\/\/upload.wikimedia.org\/wikipedia\/commons\/1\/1a\/BBC_One_2002.png",
            "epg_channel_id":"BBC One London",
            "added":"1487332455",
            "category_name":"UK: ENTERTAINMENT",
            "category_id":"14",
            "series_no":null,
            "live":"1",
            "container_extension":null,
            "custom_sid":":0:19:22e3:80d:2:11a0000:0:0:0:",
            "tv_archive":1,
            "direct_source":"",
            "tv_archive_duration":"7"},
            """
            streamtype = utils.ADDONgetSetting('streamtype').replace('0','m3u8').replace('1','ts').replace('2','rtmp')
            EPGgenerator = ADDONid +' available_channels'
            try:
                for chan in datapanel['available_channels']:
                    if (channels % 1000 == 0 and channels != 0) or (programs % 10000 == 0 and programs != 0) or channels <= 100:
                        ended = datetime.today()
                        notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))  ###+' Src= ' + EPGgeneratorName)
                        nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                        utils.ADDONsetSetting('lastEPGimportInfo','Import ' + EPGgeneratorName + ' @ ' + nowS)
                        utils.ADDONsetSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))

                    description = ''
                    stream_id = notnone(datapanel['available_channels'][chan]['stream_id'])
                    name = notnone(datapanel['available_channels'][chan]['name'])
                    category_name = notnone(datapanel['available_channels'][chan]['category_name'])
                    category_name = adjustCategoryName(category_name)
                    stream_icon = notnone(datapanel['available_channels'][chan]['stream_icon'])
                    epg_channel_id = notnone(datapanel['available_channels'][chan]['epg_channel_id'])
                    tv_archive = notnone(datapanel['available_channels'][chan]['tv_archive'])
                    tv_archive_duration = notnone(datapanel['available_channels'][chan]['tv_archive_duration'])
                    stream_type = notnone(datapanel['available_channels'][chan]['stream_type'])
                    container_extension = notnone(datapanel['available_channels'][chan]['container_extension'])

                    if stream_type == '' or stream_type == definition.getDefaultStreamType():
                        stream_typefiller = ''
                        container_extensionfiller = ''
                    else:
                        stream_typefiller = stream_type + '/'
                        if container_extension == '':
                            container_extensionfiller = ''
                        else:
                            container_extensionfiller = '.' + container_extension
                    added = notnone(datapanel['available_channels'][chan]['added'])   
                    ###if limitChannels(name+'vod',stream_type):  ### 2023-03-18 test
                    if limitChannels(name+category_name,stream_type,category_name):  ### 2023-05-07 test
                        try:  
                            url = definition.getBASEURL() + '/'+stream_typefiller+ROQuser+'/'+ROQpass+'/'+stream_id+container_extensionfiller
                        except Exception as e:
                            pass
                            EpgError = 'Error in live streamtype '+ ChannelFile + ' \n' + repr(e)
                            log('stream_type == live?? url= %r' % url)
                            ### EPGimportERRORS(EpgError)
                            log(EpgError)
                            url = 'url'  ### Dummy
                        log('2. url= %r' % url)
                        
                        ChannelFav = recordings.getChannelFav(c,stream_id)
                        ChannelEpg = recordings.getChannelEpgid(c,stream_id)
                        if ChannelEpg != '':
                            epg_channel_id = ChannelEpg
                        displaydescription = description
                        if category_name != '' and description != '':
                            displaydescription = 'Category: ' + category_name + '\n\nDescription:\n' + description
                        else:
                            displaydescription = category_name + displaydescription
                        
                        if stream_type.lower() == 'live' or utils.ADDONgetSetting('notonlylive').lower() == 'true' :
                            if category_name != '':
                                category_name_marker = '[' + category_name + ']'
                                if not category_name_marker in name :
                                    name = name + ' ' + category_name_marker  ### 2023-04-20
                            name = ' '.join(name.split())  ## Remove doublespaces etc
                            log('2021 errXX addEPGChannel(\n  c= %r, \n  stream_id= %r, \n  name= %r)' % (c, stream_id, name))
                            recordings.addEPGChannel(c, stream_id, name, url, stream_icon, epg_channel_id, EPGgenerator, epg_channel=epg_channel_id, description=displaydescription)  ### 2018-02-13
                            
                            recordings.setChannelCatchup(c,stream_id,tv_archive_duration)  ### 2018-06-08 catchup flag is number of days catchup
                            
                            recordings.setChannelFav(c,stream_id,ChannelFav)
                            if ChannelEpg != '':
                                recordings.setChannelEpgid(c,stream_id,ChannelEpg)
                                recordings.setChannelIcon(c,stream_id,recordings.getIconfromEPG(ChannelEpg))
                            recordings.setChannelAdded(c,stream_id,added)
                            channels += 1
                            
            except Exception as e:
                pass
                EpgError = 'Error in datapanel[available_channels] '+ ChannelFile + ' \n' + repr(e)
                EPGimportERRORS(EpgError)
                log(EpgError)
            
        cEPG.commit()
        ended = datetime.today()
        notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ###+' Src= ' + EPGgeneratorName) 
        nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        utils.ADDONsetSetting('lastEPGimportInfo','Import ' + EPGgeneratorName + ' @ ' + nowS)
        utils.ADDONsetSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ### +' Src= ' + EPGgeneratorName)
        log('EPG Import at ' + str(int((ended-now).total_seconds())) +' sec Channels= ' + repr(channels))    
        log('err EPG Import at ' + TimeUsed(ended,now) + ' Channels= ' + repr(channels)) 
        log('err useDirectChannels# %r' % 1)
        channelsM3U= []
        ###categories= []
        useDirectChannels = utils.ADDONgetSetting('useDirectChannels')
        log('useDirectChannels= %r' % useDirectChannels)
        log('useDirectChannels# %r' % 2)
        channelsM3U= []
        ChannelFiles = []
        ChannelBasicHTTP = definition.getBASEURL() + '/get.php?username=' +utils.ADDONgetSetting('user')+ '&password=' +utils.ADDONgetSetting('pass')+'&type=m3u_plus&output=ts'
        log('ChannelBasicHTTP %r' % (ChannelBasicHTTP))
        if 1 == 0 :  ### Ignore this part
            try:
                ChannelFileBasicHTTPfile = os.path.join(datapath,'directchannelsbasichttp.m3u')
                log('1 ChannelFileBasicHTTPfile %r' % (ChannelFileBasicHTTPfile))
                if utils.ADDONgetSetting('AcceptSSLErrors') == 'true' and ChannelBasicHTTP[0:5].lower() == 'https':
                    import ssl
                    # This restores the same behavior as before.
                    context = ssl._create_unverified_context()
                    BasicHTTP = urlopen(ChannelBasicHTTP, context=context)
                else:
                    BasicHTTP = urlopen(ChannelBasicHTTP)
                utils.makeOldFile(ChannelFileBasicHTTPfile)
                with open(ChannelFileBasicHTTPfile,'wb') as output:
                    output.write(BasicHTTP.read())
                log('2 ChannelFileBasicHTTPfile %r' % (ChannelFileBasicHTTPfile))
            except Exception as e:
                pass
                log('ChannelFileBasicHTTPfile %r\nERROR: %r' % (ChannelFileBasicHTTPfile,e))
                locking.deleteLockFile(ChannelFileBasicHTTPfile)
            ChannelFile = ChannelFileBasicHTTPfile
            if os.path.isfile(ChannelFile):    ### If directchannelsfromextraXMLTVfileHTTP exist in Program directory use it
                ChannelFiles.append(ChannelFile) 
        
        ChannelFileExtraHTTP = utils.ADDONgetSetting('directchannelsfromextraXMLTVfileHTTP')
        log('ChannelFileExtraHTTP %r' % (ChannelFileExtraHTTP))
        try:
            ChannelFileExtraHTTPfile = os.path.join(datapath,'directchannelshttp.m3u')
            log('1 ChannelFileExtraHTTPfile %r' % (ChannelFileExtraHTTPfile))
            if utils.ADDONgetSetting('AcceptSSLErrors') == 'true' and ChannelFileExtraHTTP[0:5].lower() == 'https':
                import ssl
                # This restores the same behavior as before.
                context = ssl._create_unverified_context()
                ExtraHTTP = urlopen(ChannelFileExtraHTTP, context=context)
            else:
                ExtraHTTP = urlopen(ChannelFileExtraHTTP)
            utils.makeOldFile(ChannelFileExtraHTTPfile)
            with open(ChannelFileExtraHTTPfile,'wb') as output:
                output.write(ExtraHTTP.read())
            log('2 ChannelFileExtraHTTPfile %r' % (ChannelFileExtraHTTPfile))
        except Exception as e:
            pass
            log('ChannelFileExtraHTTPfile %r\nERROR: %r' % (ChannelFileExtraHTTPfile,e))
            locking.deleteLockFile(ChannelFileExtraHTTPfile)
        ChannelFile = ChannelFileExtraHTTPfile
        if os.path.isfile(ChannelFile):    ### If directchannelsfromextraXMLTVfileHTTP exist in Program directory use it
            ChannelFiles.append(ChannelFile) 
        ChannelFileExtra = utils.ADDONgetSetting('directchannelsfromextraXMLTVfile')
        if not os.path.isfile(ChannelFileExtra):
            utils.ADDONsetSetting('directchannelsfromextraXMLTVfile','')
            ChannelFileExtra = ''
        ChannelFile = utils.ADDONgetSetting('directchannelsfromextraXMLTVfile') 
        if os.path.isfile(ChannelFile):    ### If directchannelsfromextraXMLTVfile exist in Program directory use it
            if utils.ADDONgetSetting('useDirectChannelsFile') == 'true' :
                ChannelFiles.append(ChannelFile) 
        if useDirectChannels == 'true':
            log('2110 err useDirectChannels# %r' % 3)
            
            ChannelFile = os.path.join(progpath,'directchannels.m3u.txt')
            if os.path.isfile(ChannelFile):    ### If ChannelFile exist in Program directory use it
                ChannelFiles.append(ChannelFile)
                if ChannelFileExtra == ChannelFile:
                    utils.ADDONsetSetting('directchannelsfromextraXMLTVfile','')
                
            ChannelFile = os.path.join(datapath,'directchannels.m3u')
            if os.path.isfile(ChannelFile):  ### Use updated directchannels if available
                ChannelFiles.append(ChannelFile)
                if ChannelFileExtra == ChannelFile:
                    utils.ADDONsetSetting('directchannelsfromextraXMLTVfile','')
            
        log('2124 err ChannelFiles: %r' % ChannelFiles)
        j = -1
        for ChannelFile in ChannelFiles:
            log('2127 err ChannelFile= %r' % ChannelFile)
            j += 1
            i = 0
            if os.path.isfile(ChannelFile): 
                log('err useDirectChannels# %r' % 4)
                log('err Use extra ChannelFile in: ' + repr(ChannelFile))
                nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                utils.ADDONsetSetting('lastEPGimportInfo','Start import of m3u direct channels '+ChannelFile + ' ' + nowS)
                ended = datetime.today()
                notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ###+' Src= Import of m3u direct channels') 
                utils.ADDONsetSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ###+' Src= Import of m3u direct channels')
                """
                #EXTM3U
                #PLAYLIST:FHC-BOXTV
                #EXTINF:-1,BBC One XXX
                https://fhc-boxtv.net/api/m3u/stream/0c9b93cbe66291181d414f24fd2147536ab7990091c0fcf2ee4dd6e41a44d8.m3u8
                #EXTINF:-1,5USA
                https://fhc-boxtv.net/api/m3u/stream/e56544595651fb8d318aa5aa87bda41554ee4feca5296415b13557db813e4c.m3u8
                """
                playlist = '<none>'
                tvgid=''
                tvgname=''
                tvgnamecat = ''
                tvglogo=''
                grouptitle=playlist
                name=''
                log('errX ChannelFile= %r ' % ChannelFile)  ### 2023-01-21
                ChannelFileText = open(ChannelFile, 'rb')
                log('errX ChannelFileText= %r ' % ChannelFileText)  ### 2023-01-21
                for line in utils.openRead(ChannelFile):  # opened in text-mode; all EOLs are converted to '\n'
                    log('errX Line: ' + repr(i) + ' - ' + line) 
                    line = line.rstrip('\n').rstrip('\r').strip()
                    if not line == '' and not line[:2] == '# ' :   # Ignore empty lines and comment lines
                        log('Line: %r' % 1) 
                        if '#EXTM3U' in line :
                            i += 1
                            log('errX Skip EXTM3U in line: ' + repr(i))
                        elif '#PLAYLIST:' in line :
                            i += 1
                            try:
                                playlist = line.split('#PLAYLIST:')[1]
                            except Exception as e:
                                pass
                                playlist = 'ERROR in playlist: %r' % e 
                            log('errX playlist = %r' % playlist)
                        elif '#EXTINF' in line :
                            i += 1
                            log('errX 2152 err Line:i %r' % i)
                            tvgid=''
                            tvgname=''
                            tvgnamecat = ''
                            tvglogo=''
                            grouptitle=playlist
                            name=''
                            try:
                                tvgid=line.split('tvg-id="',1)[1].split('"',1)[0]
                            except Exception as e:
                                pass
                                tvgid=''
                            try:
                                tvgname=line.split('tvg-name="',1)[1].split('"',1)[0]
                            except Exception as e:
                                pass
                                tvgname=''
                            try:
                                tvglogo=line.split('tvg-logo="',1)[1].split('"',1)[0]
                            except Exception as e:
                                pass
                                tvglogo=''
                            try:
                                grouptitle=line.split('group-title="',1)[1].split('"',1)[0]
                            except Exception as e:
                                pass
                                grouptitle=playlist
                            grouptitle=adjustCategoryName(grouptitle)
                            try:
                                name=line.split(',')[-1]
                                grouptitle=grouptitle.split('SEASON')[0].strip()
                                
                            except Exception as e:
                                pass
                                name='name ERROR: %r' % e
                                log('2194a errXname= %r' % name)
                            try:
                                if ':' in tvgname:
                                    tvgnamecat=tvgname.split(':')[0].strip()
                            except:
                                pass
                                tvgnamecat= ''
                        else:
                            i += 1
                            log('2194 err Line: else i %r' % i)
                            log('2195 err Line: %r' % line)
                            
                            ### https://drlive01hls.akamaized.net/hls/live-ull/2014185/drlive01/master.m3u8
                            ### 2022-04-23
                            try:
                                cats=line.split('live-ull/')[1].split('/')[0]
                            except:
                                pass
                            
                                try:
                                    cats=line.split('live/')[1].split('/')[0]
                                except:
                                    pass
                                    try:
                                        cats=line.split('tv2danmark/')[1].split('/')[0]
                                    except:
                                        pass
                                        try:
                                            cats=line.split('i/')[1].split('/')[0]
                                        except:
                                            pass
                                            try:
                                                if '/' in line.split('.')[-1]:   ### 2018-12-01 Selected stream type if none
                                                    line1 = line + '.' + streamtype 
                                                else:
                                                    line1 = line ### 2018-12-01 Selected stream type if none
                                                cats=line1.split('.')[-2].split('/')[-1]
                                            except Exception as e:
                                                pass
                                                EpgError = 'errX Error in m3u file: '+ repr(ChannelFile) + ' @ line= '+line+'\n' + repr(e)
                                                EPGimportERRORS(EpgError)
                                                notification(EpgError)
                                                cats=''
                            if 'series' in line :
                                log('errX with series line= %r' % line)
                            if not 'movie' in line and not 'series' and not '[multi-subs]'in line:
                                catsinlink='! live'
                            else:
                                catsinlink=''

                            if '_' in cats:
                                if not 'bbc_' in cats:   ### 2017-08-28
                                    if not 'cbeebies_' in cats:
                                        if not cats[:1] == '_':  ### 2018-07-07
                                            log('errX cats no_= %r' % cats)
                                            cats = cats.split('_')[0]
                                            log('errX cats no_= %r' % cats)
                            ###grouptitle
                            if cats == 'm3u':
                                cats = name.strip()
                            
                            if j == 0:
                                appendData = [name.strip(),line,grouptitle,tvglogo,tvgname,tvgid,cats,catsinlink]
                            else:
                                appendData = [name.strip()+' (D'+str(j)+')',line,grouptitle,tvglogo,tvgname,tvgid,'DIR'+str(j)+cats,catsinlink]
                            log('errX 2251 channelsM3U.append: %r' % appendData)   
                            channelsM3U.append(appendData)
        
        log('errorX 2255 channelsM3U= %r' % channelsM3U)  
        j = 1
        for cat in channelsM3U:
            log('errorX Use channels: ' + repr(cat))
            if cat[0] != '':
                cat0 = cat[0]
            else:
                cat0 = str(j)
            description = ''
            if cat[6] != '':
                description += ' \n\rcat= ' + cat[6]
            if cat[5] != '':
                description += ' \n\rtvg-id= ' + cat[5]
            if cat[4] != '':
                description += ' \n\rtvg-name= '+cat[4]
            if cat[2] != '':
                description += ' \n\rgroup-title= ' + cat[2] 
            if cat[7] != '':
                description += ' \n\rcatsinlink= '+cat[7]
            if cat[1] != '' and utils.ADDONgetSetting('ShowLink') == 'true':
                description += ' \n\rlink= '+cat[1].replace('/','/ ')
            log('errorX cat in channelsM3U name= %r' % cat0+' '+cat[2])
            ###if ' (D' in cat[0] or '/live/' in cat[1].lower() or utils.ADDONgetSetting('notonlylive').lower() == 'true' or 'fhc-boxtv.net' in cat[1].lower() or 1 == 1 :     ### 2013-03-17 test
            if 1 == 1 :     ### 2013-03-17 test
                log('errorX recordings.addChannel(name= %r)' % cat[0]+cat[2])
                if limitChannels(cat0+cat[2],'notonlylive',cat[2]) :   ### 2023-05-07
                    name = ' '.join(cat0.split())  ## Remove doublespaces etc
                    log('errorX recordings.addChannel(name= %r' % name+' '+cat[2])
                    recordings.addChannel(name+' [<'+cat[2]+'>]',cat[1],cat[3],cat[6], ADDONid+ ' available_channels',epg_channel= cat[5],description=description)  ### 2021-01-15 weight= utils.SeriesEpisode(cat[0])
            j += 1
   
        ### >>>>>> ROQ TV ENIGMA
        ###link = 'http://roq-tv.net:25461/enigma2.php?username=XXX&password=XXXX'
        if ROQTVusername.lower() == 'none':
            utils.ADDONsetSetting('expiredate',ROQTVusername)
            utils.ADDONsetSetting('concurrentstreams',ROQTVusername)
            EPGgeneratorName = 'No User'
        else:
            try:
                if enigma2:
                    linkenigma = definition.getBASEURL() + '/enigma2.php?username=' +ROQuser+ '&password=' +ROQpass
                    EPGgeneratorName = 'enigma2'
                    ended = datetime.today()
                    notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ###+' Src= ' + EPGgeneratorName) 
                    nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                    utils.ADDONsetSetting('lastEPGimportInfo','Import ' + EPGgeneratorName + ' @ ' + nowS)
                    utils.ADDONsetSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ### +' Src= ' + EPGgeneratorName)
                    ChannelFile = os.path.join(datapath,ADDONid) + '.enigma'
                    dataenigma = utils.readlink(linkenigma,ChannelFile,module)
                else:
                    dataenigma = ''
            except Exception as e:
                pass
                EpgError = 'Error in getting '+ linkenigma + ' \n' + repr(e)
                EPGimportERRORS(EpgError)
                notification(EpgError)
                dataenigma = ''
            ### Nothing done with enigma data!!! 2018-07-06    <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

        httplinkEPG = ''
        httplinkEPGenable = utils.ADDONgetSetting('tvguideimporthttpenable')  ### 2018-06-12
        if httplinkEPGenable.lower() == 'true':
            ended = datetime.today()
            notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))  ###+' Src= Import HTTP guide') 
            nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
            utils.ADDONsetSetting('lastEPGimportInfo','Import ' + EPGgeneratorName + ' @ ' + nowS)
            utils.ADDONsetSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ###+ ' Src= Import HTTP guide')
            httplinkEPG = utils.ADDONgetSetting('tvguideimporthttp')
            ROQTVusername = utils.ADDONgetSetting('user')
            if ROQTVusername.lower() != 'none':
                if httplinkEPG == '':
                    httplinkEPG = definition.getBASEURL() + '/xmltv.php?username=' +ROQuser+ '&password=' +ROQpass
            log(ADDONname + ' EPG link: ' + repr(httplinkEPG))
        if utils.ADDONgetSetting('tvguidefromfile') == 'true':
            ChannelFile1 = utils.ADDONgetSetting('tvguideimport')
            log('2539 errorY ChannelFile1= %r' % ChannelFile1)
            if 'special://' in ChannelFile1:
                ChannelFile1 = xbmcvfs.translatePath(ChannelFile1)
                if os.path.isfile(ChannelFile1):
                    utils.ADDONsetSetting('tvguideimport',ChannelFile1)
                ###else:
                    ###ChannelFile1 = utils.FileManagerPath(ChannelFile1)   ### 2023-03-28
                    ###utils.ADDONsetSetting('tvguideimport',ChannelFile1)
        else:
            ChannelFile1 = ''
        FileSize = 'missing'
        try:
            master = 'master.xml'
            ChannelFile1 = os.path.join(ChannelFile1,master)
            infile = os.path.join(datapath,master)
            log('2554 errorY infile= %r' % infile)
            ###shutil.copyfile(ChannelFile1, infile)
            if xbmcvfs.exists(ChannelFile1):
                log('error 2557 ChannelFile1 exists= %r' % ChannelFile1)
                copyOK = xbmcvfs.copy(ChannelFile1, infile)
                if not copyOK:
                    log('error 2560 Copy of %r failed - ERR: %r' %  (infile,copyOK))
            ChannelFile1 = infile
            log('2556 errorY infile= %r' % infile)
            FileSz    = float(os.stat(infile).st_size)
            FileSzKB  = FileSz/(1024)
            log('err Has size %r size in KB %r' % (FileSz,FileSzKB))
            FileSize = str(int(FileSzKB))
            log('err FileSize %r' % (FileSize))
            filetime = recordings.humantime(int(os.path.getmtime(infile)))
        except Exception as e:
            pass
            filetime = 'ERROR in filetime: ' + repr(e)
        FileData = 'Size: '+ FileSize + ' KB \nDate: ' + filetime
        log('errX tvguideimportinfo= %r' % FileData)
        utils.ADDONsetSetting('tvguideimportinfo',FileData)
        utils.ADDONsetSetting('tvguideimportfile',ChannelFile1)
        ChannelFile2 = ''
        if httplinkEPG != '':
            try:
                ChannelFile2 = os.path.join(datapath,ADDONid) + 'EPG.xml'
                data = utils.readlink(httplinkEPG,ChannelFile2,module)
            except Exception as e:
                pass
                EpgError = 'Error in httplinkEPG '+ httplinkEPG + ' \n' + repr(e)
                EPGimportERRORS(EpgError)
                notification(EpgError)
        EPGgeneratorDis = '<no name>'
        ChannelFiles = []
        
        epgfolder = os.path.join(utils.ADDONgetSetting('record_path'),'epg')
        destepgfolder = os.path.join(datapath,'epg')
        if not xbmcvfs.exists(destepgfolder):
            xbmcvfs.mkdir(destepgfolder)
        ### Get all EPG files in sourceepgfolder
        files = glob.glob(os.path.join(destepgfolder,'*'))
        for file in files:
            xbmcvfs.delete(file)
        files = glob.glob(os.path.join(epgfolder,'*.xml'))
        log('error files= %r' % files)
        i = 0
        
        for file in files:
            try:
                filename = file.split(os.sep)[-1]
                log('error filename %r\n%r ' % (filename,file))
            except Exception as e:
                pass
                log('error filename error %r\n%r ' % (e,file))
                filename = 'epg' + str(i) + '.xml'
                i += 1
            infile = os.path.join(destepgfolder,filename)
            copyOK = xbmcvfs.copy(file, infile)
            if not copyOK:
                log('error 2560 Copy of %r failed - ERR: %r' %  (infile,copyOK))
                infile = file
            ChannelFiles.append(infile)
        if ChannelFile2 != '':
            ChannelFiles.append(ChannelFile2)
        if ChannelFile1 != '':
            ChannelFiles.append(ChannelFile1)   
        log('error ChannelFiles= %r' % ChannelFiles)
        for ChannelFile in ChannelFiles:
            log('error 2601 ChannelFile= %r' % ChannelFile)
            try:
                ChannelFileMod = datetime.fromtimestamp(os.path.getmtime(ChannelFile))
            except Exception as e:
                pass
                EpgError = 'Error 2278 in EPG file '+ ChannelFile + ' \n' + repr(e)
                EPGimportERRORS(EpgError)
                notification(EpgError)
                ChannelFileMod = now
    
            log('errX 1 ChannelFile= %r' % (ChannelFile))
            if ChannelFile == ChannelFile1:
                log('errX 0 time offset: %r' % (TimeZoneXML))
            else:
                log('errX 1 Time Offset: %r' % (TimeZone))
            log('errX os.path.getmtime(ChannelFile)= %r' % (ChannelFileMod))
            try:
                log('errX lastEPGimport= %r' % lastEPGimport)
                log('errX ChannelFileMod= %r' % ChannelFileMod)
                log('errX lastEPGimport - os.path.getmtime(ChannelFile)= %r' % (lastEPGimport - ChannelFileMod))
                ###datetime.timedelta(seconds=73505, microseconds=568262)
                ###log('errX lastEPGimport - os.path.getmtime(ChannelFile) in hours= %r' %((lastEPGimport - ChannelFileMod).replace('datetime.timedelta(0, ','').split(')')[0].split(',')[0]) )    ###if (lastEPGimport - ChannelFileMod).total_seconds()/3600 < 12:
                ###log('errX lastEPGimport - os.path.getmtime(ChannelFile) in hours= %r' %(repr(lastEPGimport - ChannelFileMod).replace('datetime.timedelta(seconds=','').split(',')[0]) )    ###if (lastEPGimport - ChannelFileMod).total_seconds()/3600 < 12:
            except Exception as e:
                pass
                log('err lastEPGimport - ChannelFileMod= %r' % e)
            try:
                log('errX ChannelFile= %r' % ChannelFile)
                epgfile = io.open(ChannelFile, 'r', encoding="utf-8")
                log('errX  epgfile= %r' %  epgfile)
                dataepg = epgfile.read()
                log('2394 errX len(dataepg)= %r' % len(dataepg))
                log('errX dataepg= %r' % dataepg)
                epgfile.close() 
            except Exception as e:
                pass
                EpgError = 'Error 2399 in EPG file '+ ChannelFile + ' \n' + repr(e)
                log('EPGimportERRORS(EpgError)= %r' % EpgError)
                EPGimportERRORS(EpgError)
            try:
                log('errX 0 len(xmltodict.parse(dataepg))= %r' % len(dataepg))
                dataepg = xmltodict.parse(dataepg)
                log('errX 1 len(xmltodict.parse(dataepg))= %r' % len(dataepg))
            except Exception as e:
                pass
                EpgError = 'Error 2308 in EPG file '+ ChannelFile + ' \n' + repr(e)
                log('EPGimportERRORS(EpgError)*= %r' % EpgError)
                EPGimportERRORS(EpgError)
            try:
                log('len(dataepg)*= %r' % len(dataepg))
                datapanelEPG1 = dataepg['tv']
                log('errX datapanelEPG1 = dataepg[tv]= %r'%(datapanelEPG1))
                datapanelEPG2 = dataepg['tv']['@generator-info-name']
                log('errX datapanelEPG2 = dataepg[tv][@generator-info-name]= %r'%(datapanelEPG2))
                datapanelEPG3 = dataepg['tv']['@generator-info-url']
                log('errX datapanelEPG3 = dataepg[tv][@generator-info-url]= %r'%(datapanelEPG3))
            except Exception as e:
                pass
                EpgError = 'Error in datapanelEPG '+ ChannelFile + ' \n' + repr(e)
                EPGimportERRORS(EpgError)
                notification(EpgError)
            log('2424 err dataepg= %r' % dataepg)   
            try:
                EPGgeneratorName = getDict(dataepg,'tv','@generator-info-name')
                log('errorX EPGgeneratorName= %r' % EPGgeneratorName)  
                EPGgeneratorURL  = getDict(dataepg,'tv','@generator-info-url')
                log('errorX EPGgeneratorURL= %r' % EPGgeneratorURL)  
                if type(EPGgeneratorName) == dict :
                    EPGgeneratorName = str(EPGgeneratorName)
                if type(EPGgeneratorURL) == dict :
                    EPGgeneratorURL = str(EPGgeneratorURL)
                if EPGgeneratorName == '' or EPGgeneratorURL == '':
                    EPGgenerator = EPGgeneratorName + EPGgeneratorURL
                else:
                    EPGgenerator = EPGgeneratorName + ' - ' + EPGgeneratorURL
                if EPGgeneratorName != '':
                    if EPGgeneratorDis != '' and not EPGgeneratorName in EPGgeneratorDis:
                        EPGgeneratorDis = EPGgeneratorDis + ' - ' + EPGgeneratorName
                    else:
                        EPGgeneratorDis = EPGgeneratorName
                ChannelFilesplit = ChannelFile.split('epg')
                log('error ChannelFile.split(epg) %r ' % ChannelFile.split('epg'))
                if len(ChannelFilesplit) == 2:
                    log('error ChannelFile.split(epg)[1] %r ' % ChannelFile.split('epg')[1])
                    EPGgeneratorDis += ' ' + ChannelFile.split('epg')[1]
                log('error ChannelFile.split(epg) 2 %r ' % ChannelFile.split('epg'))
            except Exception as e:
                pass
                EPGgeneratorDis = 'Error in EPGgenerator: %r' % e
            utils.ADDONsetSetting('lastEPGimportInfo',EPGgeneratorDis)
            log('error 2778 utils.ADDONsetSetting(lastEPGimportInfo= %r ' % EPGgeneratorDis)
            ended = datetime.today()
            notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ###+' Src= ' + EPGgeneratorDis) 
            utils.ADDONsetSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))
            
            try:
                datapanelEPG3 = dataepg['tv']['channel']
            except Exception as e:
                pass
                EpgError = 'Error in datapanelEPG3 '+ ChannelFile + ' \n' + repr(e)
                EPGimportERRORS(EpgError)
                notification(EpgError)
                datapanelEPG3 = []
            i = 0
            for cid in datapanelEPG3:
                i += 1
                if (channels % 1000 == 0 and channels != 0) or (programs % 10000 == 0 and programs != 0) or channels <= 1000 :   
                    ended = datetime.today()
                    notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ###+' Src= ' + EPGgeneratorName)
                    nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                    utils.ADDONsetSetting('lastEPGimportInfo','Import ' + EPGgeneratorName + ' @ ' + nowS)
                    utils.ADDONsetSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))

                name = getDict(cid,'display-name','#text','@lang')
                name = ' '.join(name.split())  ## Remove doublespaces etc
                serepi = utils.SeriesEpisodeVOD(name)[0]  ### ,weight= serepi
                iconimage = getDict(cid,'icon','@src')

                if utils.ADDONgetSetting('notonlylive').lower() == 'true' :
                    stream_id = cid['@id']
                    ChannelFav = recordings.getChannelFav(c,stream_id)
                    ChannelEpg = recordings.getChannelEpgid(c,stream_id)
                    log('2477 errXX addEPGChannel(\n  c= %r, \n  stream_id= %r, \n  name= %r)' % (c, stream_id, name))
                    recordings.addEPGChannel(c,stream_id,name,'url',iconimage,repr(cid),EPGgenerator,weight= serepi)
                    recordings.setChannelFav(c,stream_id,ChannelFav)
                    if ChannelEpg != '':
                        log('errX i= %r, stream_id= %r ,ChannelEpg= %r' % (i,stream_id,ChannelEpg))
                        recordings.setChannelEpgid(c,stream_id,ChannelEpg)
                        recordings.setChannelIcon(c,stream_id,recordings.getIconfromEPG(ChannelEpg))
                    channels += 1

            cEPG.commit()
            ended = datetime.today()
            log('errYYY EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ###+' Src= ' + EPGgenerator)
            try:
                datapanelEPG4 = dataepg['tv']['programme']
            except Exception as e:
                pass
                EpgError = 'Error in dataepg[tv][programme] '+ ChannelFile + ' \n' + repr(e)
                EPGimportERRORS(EpgError)
                notification(EpgError)
                datapanelEPG4 = ''
            
            for prog in datapanelEPG4:
                i += 1
                if (channels % 1000 == 0 and channels != 0) or (programs % 10000 == 0 and programs != 0) or programs <= 100 : 
                    ended = datetime.today()
                    
                    notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ###+' Src= ' + EPGgeneratorName)
                    nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                    utils.ADDONsetSetting('lastEPGimportInfo','Import ' + EPGgeneratorName + ' @ ' + nowS)
                    utils.ADDONsetSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))
                    
                channel = getDict(prog,'@channel')
                title = getDict(prog,'title','#text','@lang')
                sub_title = getDict(prog,'sub_title','#text','@lang')
                nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                try:
                    description = getDict(prog,'desc','#text','@lang').replace('?n','?\n').replace('!n','!\n').replace('.nn','.\n').replace('. nn','.\n').replace('.n','.\n').replace('. n','.\n') + ' \n\nEPG Created ' + nowS  ### 2018-04-27
                except:
                    pass
                    description = ' \n\nEPG Created ' + nowS
                if ChannelFile == ChannelFile1:
                    recordings.addEPGProgram(c,prog,channel, title, sub_title, parse_date_stringXML(prog['@start']), parse_date_stringXML(prog['@stop']), description, source=EPGgenerator)
                else:
                    recordings.addEPGProgram(c,prog,channel, title, sub_title, parse_date_string(prog['@start']), parse_date_string(prog['@stop']), description, source=EPGgenerator)
                programs += 1
                cEPG.commit()
            cEPG.commit()
        cEPG.commit()
        c.close()
        ended = datetime.today()
        utils.ADDONsetSetting('lastEPGimport',ended.strftime('%Y-%m-%d %H:%M:%S') + ' using ' + TimeUsed(ended,now))
        notification('EPG Import Ended in ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))
        log('errYYY err EPG Import Ended at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ###+ ' Src= ' + EPGgenerator)
        locking.scanUnlock('EPG_update')
    
    log('err #2585 before last updateiconsfromEPG()')
    updateiconsfromEPG()  ### 2022-05-09
    log('err #2587 after last updateiconsfromEPG()')
    updateseries()   ### 2021-01-16
    ended = datetime.today()
    lastEPGimportInfoData = 'Ended in ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs)
    
    utils.ADDONsetSetting('lastEPGimportInfoData',lastEPGimportInfoData)
    log('errYYY err GetOriginalDescriptionsFromDict(second time)')
    GetOriginalDescriptionsFromDict()
    log('errYYY err GetOriginalDescriptionsFromDict(second time finished)')
    utils.ADDONsetSetting('lastEPGimportInfo','Force INI file')
    recordings.ftvntvlist() ### Force INI file
    utils.ADDONsetSetting('lastEPGimportInfo','Delete old programs')
    recordings.delOldEPGPrograms()  ### 7 days old programs and 2 days old channels  
    utils.ADDONsetSetting('lastEPGimportInfo','Find Doubletes')
    updatedrecordings = recordings.finddoubletes()  ### Find double programs
    if updatedrecordings >= 1:
        utils.ADDONsetSetting('lastEPGimportInfo','Reschedule Started')
        recordings.reschedule() ### Set EPG program start
        utils.ADDONsetSetting('lastEPGimportInfo','Reschedule Ended')
    ended = datetime.today()
    notification('EPG Import Ended in ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+ ' Find doublette programs ended')
    log('errYYY EPG Import Ended at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= ' + EPGgenerator+ ' Find doublette programs ended')
    utils.ADDONsetSetting('lastEPGimportInfo','Find dublet channels Started')
    ###deleteDoubletChannels = recordings.deleteDoubletChannels()
    ###utils.ADDONsetSetting('lastEPGimportInfo','Find dublet channels Ended with %r deletions' % deleteDoubletChannels)
    
    utils.ADDONsetSetting('lastEPGimportInfo','Grab Started')
    findtvguidenotifications.findtvguidenotifications()
    utils.ADDONsetSetting('lastEPGimportInfo','Grab Ended')
    utils.ADDONsetSetting('lastEPGimportInfo','Update EPG Ended')
