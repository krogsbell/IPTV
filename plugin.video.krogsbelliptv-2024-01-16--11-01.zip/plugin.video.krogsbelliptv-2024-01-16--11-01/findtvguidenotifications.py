#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmcplugin,xbmcgui,xbmc,xbmcaddon,xbmcvfs
import definition
ADDON = definition.getADDON()
import urllib,sys,re,os
import utils
###import net
###from hashlib import md5  
import json
import glob
import recordings
import locking
import definition
###import sqlite3
from sqlite3 import dbapi2 as sqlite3
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
from operator import itemgetter

ADDONname  = utils.ADDONgetAddonInfo('name')
ADDONid    = utils.ADDONgetAddonInfo('id')
module = 'findtvguidenotifications.py'
utils.logdev(module,'error Start')
utils.logdev(module,'error Start %r' % sys.argv)
recordings.addAlarm(module, 'start', '', '00:00:00', 'options')
TimeZoneOffset = 0
#EPG_DB = 'source.db'  Depends on actual TV Guide
RECORDS_DB = 'recordings_adc.db'
###CHANNEL_DB = 'channels.db'
CHANNEL_DB = 'recordings_adc.db'
RECURSIVEMARKER = 'Recursive:'
TVguideNR = utils.ADDONgetSetting('tvguidenr')

dbPath = xbmcvfs.translatePath(utils.ADDONgetAddonInfo('profile'))
###dbPathNTV = os.path.join(xbmcvfs.translatePath(utils.ADDONgetAddonInfo('path')),'resources')
dbPathNTV = dbPath
scriptTrig   = os.path.join(utils.ADDONgetAddonInfo('path'), 'TrigTVGuide.py')

def log(infotext,showlength=500):
    debug = utils.ADDONgetSetting('debug').lower()
    if debug in infotext[0:25].lower() and not debug == '':
        utils.logdev('error',module + ': ' + infotext,showlength=showlength)
    else:
        nolog = True
"""
def log(infotext,showlength=500):
    if 'error' in infotext.lower():
        utils.logdev('error',module + ': ' + infotext,showlength=showlength)
    elif 'err' in infotext.lower():
        nolog = True
        ###utils.logdev(module,infotext,showlength=showlength)
    else:
        nolog = True
        ###utils.logdev(module,infotext,showlength=showlength)
"""    
def HT(ts):  ### Human Time from timestamp
    try:
        return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts))
    except Exception as e:
        pass
        return 'HT(%r) ERROR: %r' % (ts,e)

def sorteditems(items):
    ### Sort list from first column and then remove first column
    log('items0-1 %r' % items)
    
    items = sorted(items, key=itemgetter(0)) 
    
    log('items0-2 %r' % items,size=2500)
    ItemsNoTitle = []
    for diri in items:
        ItemsNoTitle.append((diri[1],diri[2],diri[3]))
    log('ItemsNoTitle1-1 %r' % ItemsNoTitle)
    return ItemsNoTitle
  
def MyChannels():
    log('err MyChannels')
    channels = recordings.getAllChannels()
    log('err channels= %r' % channels)
    #channelsLC = []
    #for cha in channels:
    #    channelsLC.append(cha[1].lower(),cha)
    ##channels = sorted(channels, key=itemgetter(1))
    # sorted_list = sorted(unsorted_list, key=lambda s: s.lower())
    #channelsLC = sorted(channelsLC, key=itemgetter(0))
    #channels = sorted(channels, key=lambda s: s.lower())
    channels = sorted(channels,key=lambda i:i[1].lower())  ### Sort ignore case coloum 1
    ###channels = sorted(channels, key=itemgetter(1))  ### 2021-03-24 Not used
    
    AllMyChannels=[]
    ### Limit search to special sources
    log('err limitsources')
    limitsourcesSQ = recordings.getAllChannelSources()
    log('errX limitsources= %r' % limitsourcesSQ)
    limitsources = []
    for sourceSQ in limitsourcesSQ:
        log('errX limitsources sourceSQ[0]= %r' % sourceSQ[0])
        if not ADDONid in sourceSQ[0]:
            limitsources.append(sourceSQ[0])
    ##limitsources = ['IPTV','Rytec']
    log('errX limitsources= %r' % limitsources)
    if len(limitsources) > 1:
        limitsources = sorted(limitsources)    # sort alphabetically
        limitsource = limitsources[xbmcgui.Dialog().select('Select Source for EPG', limitsources)]
    elif len(limitsources) == 1:
        log('errX limitsources= %r' % limitsources)
        limitsource = limitsources[0]
        log('errX aftervlimitsources= %r' % limitsources)
    else:
        limitsource = ''
    log('err limitsource= %r' % limitsource)
    for field in channels:
        cat          = field[0]
        name         = field[1]    ###.encode("utf-8")
        iconimage    = field[2]
        url          = field[3]
        source       = field[4]
        if '-' in source:
            sourceID = source.split('-')[0].strip()
        elif '.' in source:
            sourceID = source.split('.')[2].split(' ')[0].strip()
        else:
            sourceID = field[4]
        visible      = field[5]
        weight       = field[6]
        ###if not source == ADDONid:
        ### log( 'source= %s, module= %s' % (source,module))
        ###if source == ADDONid and not '/movie/' in url:   
        if not '/movie/' in url and not sourceID == ADDONid and not sourceID == ADDONid + ' available_channels':
            displaychannelnumber = (name + ' (' +cat+' - ' + sourceID + ')\n' )
            if source == limitsource: 
                AllMyChannels.append(displaychannelnumber)
    
    AllMyChannelsSorted = []
    for chan in AllMyChannels:
        AllMyChannelsSorted.append([chan.lower().replace(' ',''),chan])
    AllMyChannelsS = sorted(AllMyChannelsSorted)
    AllMyChannels = []
    for chan in AllMyChannelsS:
        AllMyChannels.append(chan[1])
    return AllMyChannels

def MyPlayChannels():
    channels = recordings.getAllChannels()
    channels = sorted(channels, key=itemgetter(1))
    
    AllMyChannels=[]
    
    for field in channels:
        cat          = field[0]
        name         = field[1]    ###.encode("utf-8")
        log('errX 147 name= %r' % name)
        iconimage    = field[2]
        url          = field[3]
        source       = field[4]
        log('errX 151 source 0= %r' % source)
        if '-' in source:
            source = source.split('-')[0].strip()
        elif '.' in source:
            source = source.split('.')[2].split(' ')[0].strip()
        elif ' ' in source:
            source = source.split(' ')[0].strip()   ### 2017-09-17
        else:
            source = field[4]
        log('errx 160 source 1= %r' % source)
        visible      = field[5]
        weight       = field[6]
        ###if not source == ADDONid:
        ### log( 'source= %s, module= %s' % (source,module))
        ###if source == ADDONid and not '/movie/' in url:   
        if not url == 'url' and not url == '' and not '/movie/' in url and not source == ADDONid:
            displaychannelnumber = (name + ' (' +cat+' - ' + source + ')\n' )
            AllMyChannels.append(displaychannelnumber)
    log('AllMyChannels= %r' % AllMyChannels)    
    return AllMyChannels


def findtvguidenotifications():
    log('findtvguidenotifications START')
    if locking.isAnyRecordLocked() and utils.ADDONgetSetting('grabduringrecord') == 'false'  :
        locking.scanUnlockAll()
        findtvguidenotificationsend('[B][COLOR red]Recording - Grab disabled[/COLOR][/B]')
        return
    elif  locking.isAnyScanLocked():
        findtvguidenotificationsend('[B][COLOR red]Already scanning - New grab disabled[/COLOR][/B]')
        return
    else:
        locking.scanLock('findtvguidenotifications')
    if not locking.isScanLocked('findtvguidenotifications'):
        findtvguidenotificationsend('[B][COLOR red]Scan lock not working - Grab disabled[/COLOR][/B]')
        return
    TVguide= utils.TVguide()
    log('TVguide= %r' % TVguide)
    Recursive = RecursiveRecordings() ## Get all recursive recordings
    log('Recursive= %r' % Recursive)
    #guidenotifications= ADDON.getSetting('tvguidenotifications')
    scheduled = 0
    for Guide in range(0, len(TVguide)):
        
        guide = TVguide[Guide][0]
        guideDB = TVguide[Guide][1]
        
        scheduled += grabGuide(guide,guideDB)
        ###try:
        log('guide= %r, guideDB= %r' % (guide,guideDB))
        logarray('Recursive',Recursive,nelements=2)
        
        scheduled += findrecursiverecordingsinGuide(guide,guideDB,Recursive)
        ###except Exception as  e:
        ### pass
        ### utils.logdev('findrecursiverecordingsinGuide EXECUTION FAILED 1', 'guide= %s ERROR= %s' % (guide,repr(e)))
        ### findtvguidenotificationsend('[COLOR red]Grab from TV Guide FAILED![/COLOR] - guide= %s ERROR= %s'% (guide,repr(e)))
        ### return
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    if scheduled != 0:
        findtvguidenotificationsend('[COLOR green]Grab from TV Guide finished! - Use Refresh to update view[/COLOR] %r\n[I][COLOR grey]Updated or new recordings: %r  [/COLOR][/I]' % (now,scheduled))
    else:
        findtvguidenotificationsend('[COLOR lightgreen]Grab from TV Guide finished![/COLOR] %r' % now)


def findtvguidenotificationsend(EndText):
    # Show menuentry when finished OK - but not when run in the background
    locking.scanUnlockAll()
    utils.notificationsend(EndText)

def RecursiveRecordings():
    conn = recordings.getConnection()
    c = conn.cursor()
    c.execute("PRAGMA journal_mode = WAL")  ### 2018-01-07 Try to speed up on Windows 
    #c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE '%Recursive:%' and NOT LIKE '%COLOR orange%' COLLATE NOCASE")  # Find all active recursive recordings
    try:
        c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE ? COLLATE NOCASE",['%'+RECURSIVEMARKER+'%'])  # Find all active recursive recordings RECURSIVEMARKER
    except Exception as e:
        pass
        log( 'c.execute(SELECT DISTINCT cat0, name1, start2, end3, alarmname4, description5, playchannel6 FROM recordings_adc WHERE name LIKE ? COLLATE NOCASE,[RECURSIVEMARKER]) failed! \nERROR= %r' % e)
    recordingsE = c.fetchall()
    # Put recursive recordings changed last - first
    recordingsC = sorted(recordingsE, key=itemgetter(2), reverse=True)
    try:
        log('Recursive recordings= %r'%recordingsC)
        log('Recursive recordings[1]= %r'%recordingsC[1])
        log('Recursive recordings[2]= %r'%recordingsC[2])
    except Exception as e:
        pass
        log('Recursive recordings ERROR: %r' % e)
    conn.commit()
    c.close()
    return recordingsC

def logarray(Name,Array,nelements=1):
    return ### Don't log 2023-05-07
    i = 0
    for rec in Array:
        try:
            if nelements==1:
                log('logarray in %s= %r %r' % (Name,i,rec))
                i += 1
            else:
                records = []
                for index in range(0, nelements):
                    records.append(rec[index])
                log('logarray in %s= %r %r' % (Name,i,records))
                i += 1
        except Exception as e:
            pass
            log('ERROR: logarray in %s= %r' % (Name,e))

def findrecursiverecordingsinGuide(guide,EPG_DB,Recursive):         
    log('error findrecursiverecordingsinGuideCode guide= %s' % guide)
    recordings.addAlarm(module, 'start findrecursiverecordingsinGuideCode', '', '00:00:00', 'options')
    ADDONguide = xbmcaddon.Addon(id=guide)
    scheduled = 0
    NTVchannels = MyPlayChannels()
    logarray('NTVchannels',NTVchannels,nelements=1)
    
    #SearchRecursiveIn: 0=Only selected channel|1=First 25 Cannels|2=First 50 Channels|3=All My Channels
    #SearchRecursiveIn= int(ADDON.getSetting('SearchRecursiveIn'))
    #log('findtvguidenotificationsGuide SearchRecursiveIn= %r' % SearchRecursiveIn)
    ###log('Start DB Create')
    """
    conv   = sqlite3.connect(os.path.join(dbPath, RECORDS_DB), timeout = 20, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conv.execute('PRAGMA foreign_keys = ON')
    conv.row_factory = sqlite3.Row
    conv.text_factory = str
    """
    conv = recordings.getDatabaseConnection(os.path.join(dbPath, RECORDS_DB))
    b = conv.cursor()
    b.execute("PRAGMA journal_mode = WAL")  ### 2018-01-07 Try to speed up on Windows 
    ###b.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)") ## 2016-05-15
    ###b.execute("CREATE TABLE IF NOT EXISTS channelslookup(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, favorite BOLEAN, catchup BOLEAN, description TEXT, PRIMARY KEY (title, source))")   ### 2017-07-24 channels --> channelslookup - Removed 2017-09-12
    ###log('Start DB Create1')
    dbPathEPG = xbmcvfs.translatePath(ADDONguide.getAddonInfo('profile'))
    #utils.logdev('findrecursiverecordingsinGuide', 'dbPath= %s' % dbPathEPG)
    if not os.path.exists(dbPathEPG):
        #utils.logdev('findrecursiverecordingsinGuide', 'os.mkdir(dbPath) where dbPath= %s' % dbPathEPG)
        os.mkdir(dbPathEPG)
    ###log('Start DB Create2')
    """
    conn   = sqlite3.connect(os.path.join(dbPathEPG, EPG_DB), timeout = 20, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    """
    conn = recordings.getDatabaseConnection(os.path.join(dbPath, EPG_DB))
    c = conn.cursor()
    c.execute("PRAGMA journal_mode = WAL")  ### 2018-01-07 Try to speed up on Windows 
    ###c = conv.cursor()
    if TVguideNR == '0':
        log('Start DB Create WB0')
        """
        c.execute("CREATE TABLE IF NOT EXISTS programs(channel TEXT, title TEXT, sub_title TEXT, start_date TIMESTAMP, end_date TIMESTAMP, description TEXT, categories TEXT, image_large TEXT, image_small TEXT, season TEXT, episode TEXT, is_movie TEXT, language TEXT, source TEXT, updates_id INTEGER, UNIQUE (channel, start_date, end_date), FOREIGN KEY(channel, source) REFERENCES channels(id, source) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED, FOREIGN KEY(updates_id) REFERENCES updates(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
        c.execute("CREATE TABLE IF NOT EXISTS programsForHumans (channel TEXT, title TEXT, start_date TEXT, end_date TEXT, description TEXT, image_large TEXT, image_small TEXT, source TEXT, updates_id INTEGER, PRIMARY KEY (channel, updates_id), FOREIGN KEY(updates_id) REFERENCES updates(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
        c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, lineup TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
        """
        ###log('Start DB Create WB1')
        c.execute("CREATE TABLE IF NOT EXISTS programs(channel TEXT, title TEXT, sub_title TEXT, start_date INTEGER, end_date INTEGER, description TEXT, categories TEXT, image_large TEXT, image_small TEXT, season TEXT, episode TEXT, is_movie TEXT, language TEXT, source TEXT, updates_id INTEGER, UNIQUE (channel, start_date, end_date), PRIMARY KEY (channel, start_date, end_date))")
        ###log('Start DB Create WB2')
        ###  Stop using programsForHumans
        ###c.execute("CREATE TABLE IF NOT EXISTS programsForHumans (channel TEXT, title TEXT, sub_title TEXT, start_date TEXT, end_date TEXT, description TEXT, image_large TEXT, image_small TEXT, source TEXT, updates_id INTEGER, PRIMARY KEY (channel, updates_id))")
        ###log('Start DB Create WB3')
        ###c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, lineup TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, source))")
        c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, lineup TEXT, visible BOOLEAN, weight INTEGER, epg_channel TEXT, description TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (id, title, source))")
        ###log('Start DB Create WB4')
    else:
        log('Start DB Create NoWB')
        c.execute("CREATE TABLE IF NOT EXISTS programs (channel TEXT, title TEXT, start_date TIMESTAMP, end_date TIMESTAMP, description TEXT, image_large TEXT, image_small TEXT, source TEXT, updates_id INTEGER, PRIMARY KEY (channel, updates_id), FOREIGN KEY(updates_id) REFERENCES updates(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
        ###  Stop using programsForHumans
        ###c.execute("CREATE TABLE IF NOT EXISTS programsForHumans (channel TEXT, title TEXT, start_date TEXT, end_date TEXT, description TEXT, image_large TEXT, image_small TEXT, source TEXT, updates_id INTEGER, PRIMARY KEY (channel, updates_id), FOREIGN KEY(updates_id) REFERENCES updates(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
        c.execute("CREATE TABLE IF NOT EXISTS channels (id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY(id,title, source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
    conn.commit()
    ###conv.commit()
    ###for index in range(0, len(Recursive)):
    ###    log('Recursive[%r]= %r X %r X %r' % (index,Recursive[index][0],Recursive[index][1],Recursive[index][2]))

    for index in range(0, len(Recursive)):
        log('index= %r' % index)
        log('Recursive[index][1]= %r' % Recursive[index][1].replace(RECURSIVEMARKER, '').strip())
        cat= Recursive[index][0]
        channel= recordings.EPG_ChannelFromCat(cat)
        log('err cat= %r, source= %r' % (cat,guide))
        # Find EPG channel name in TV Guide 1. saved conversion 2. name as used i NTV 6. playchannel
        """
        try:
            b.execute("SELECT * FROM channels WHERE id=? and source=? and visible=1", [cat,guide])
            channelconvert = b.fetchall()
            logarray('channelconvert',channelconvert,nelements=2)
            ###log('channelconvert= %r' % channelconvert)
        except Exception as e:
            pass
            log('channelconvert ERROR: %r' % e)
            channelconvert = []
        if len(channelconvert) == 1:
            ###channel= channelconvert[0][1]
            channel= channelconvert[0][6]   ### 2021-02-16 Use playchannel = epg
            log('Converted: cat= (%r) channel= %r' % (cat,channel))
        else:
            ###channel= recordings.ChannelName(cat)
            channel= recordings.EPG_ChannelFromCat(cat)
            log('LookedUp: cat= (%r) channel= %r, len(channelconvert)= %r' % (cat,channel,len(channelconvert)))
        """
        log('err findrecursiverecordingsinGuide cat= %r, channel= %r' % (cat,channel))
        # Find id from TV Guide channel name
        #c.execute("SELECT * FROM channels")
        #channelconvert = c.fetchall()
        ###log('channelconvert= %r' % channelconvert)
        """
        try:
            c.execute("SELECT * FROM channels WHERE title=? and visible=1 COLLATE NOCASE", [channel])
            channelconvert = c.fetchall()
            log('channelconvert= %r' % channelconvert)
            logarray('channelconvert',channelconvert,nelements=2)
            channel= channelconvert[0][0]
        except Exception as e:
            pass
            log('ERROR: channelconvert= %r' % e)
            channel= 0
        log('err ChannelConvert: cat= (%r) channel= %r #ofchannelconvert= %r' % (cat,channel,len(channelconvert)))
        """
        #utils.logdev('findrecursiverecordingsinGuide', 'channel= %s' % repr(channel))
        #c.execute("SELECT * FROM programs WHERE title LIKE ? AND channel=? COLLATE NOCASE", ['%'+(Recursive[index][1].replace(RECURSIVEMARKER, '').strip())+'%',channel])
        recursivechannel= channel  ### E! ==> E.se  ### NO must be EPG Channel 2018-08-28
        log('err recursivechannel= %r' % recursivechannel)
        ###SearchText = '%'+(Recursive[index][1].replace(RECURSIVEMARKER, '').strip())+'%'
        SearchText = (Recursive[index][1].replace(RECURSIVEMARKER, '').strip())
        log('SearchText= %r' % SearchText)
        try:
            SearchText = SearchText.split('^')
        except Exception as e:
            pass
            log('split search text EXECUTION FAILED 3 SearchText= %r\nERROR= %r' % (SearchText,e))
            log('Default SearchText= %r' % SearchText)
            SearchText = [SearchText.strip()]
        log('SearchText= %r' % SearchText)
        log('SearchText[0]= %r' % SearchText[0])
        log('len(SearchText)= %r' % len(SearchText))
        if '[COLOR orange]' in SearchText[0]:
            mark = True
            SearchText[0] = SearchText[0].replace('[COLOR orange]','',1).replace('[/COLOR]','',1)
        else:
            mark = False
        log('mark= %r' % mark)
        if SearchText[0] == '' or len(SearchText[0].strip()) < 3:
            log('SearchText is empty or less than 3 chars long')
        else:
            log('SearchText is more than 3 chars long')
            ###cy= c.execute("SELECT DISTINCT p.*, c.weight FROM channels c, programs p WHERE c.weight < 25 AND p.channel = c.id AND p.title = ? AND p.start_date >= ?",[program, now])
            ### channelsRecursive(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created)
            
            nowTS = time.mktime(datetime.now().timetuple())
            log('nowTS= %r' % nowTS)
            ###c.execute("SELECT DISTINCT p.title, p.channel, c.id, c.title, c.epg_channel, c.id, p.start_date  FROM programs p, channelsRecursive c WHERE p.title LIKE ? and p.channel = c.epg_channel and p.start_date > ? COLLATE NOCASE", ['%'+SearchText[0].strip()+'%', nowTS])
            searchtext = '%'+SearchText[0].strip()+'%'
            log('SearchText[0].strip()= %r' % (searchtext))
            try:
                c.execute("SELECT DISTINCT p.title, p.channel, c.id, c.title, c.epg_channel, c.id, p.start_date  FROM programs p, channels c WHERE p.channel = c.epg_channel AND p.title LIKE ?  and (c.epg_channel like '% (R)%' or c.favorite <> ? and c.favorite <> ? or c.catchup=?) and c.visible=? and p.start_date > ? COLLATE NOCASE", [searchtext,'false','False',1,1, nowTS])
            except Exception as e:
                pass
                log('c.execute(SELECT DISTINCT p.title ERROR: %r' % e)
            log('err After c.execute')
            ###[searchText,'True',1,1,origin])...c.title like '% (D)%' or 
            ###c.execute("SELECT DISTINCT p.title, p.channel, c.id, c.title, c.epg_channel, c.id, p.start_date  FROM programs p, channels c WHERE p.title LIKE ? and p.channel = c.epg_channel and p.start_date > ? COLLATE NOCASE", ['%'+SearchText[0].strip()+'%', nowTS])
            notifications = c.fetchall()
            
            if len(notifications) > 0:
                for indexN in range(0, len(notifications)): 
                    ptitle=       notifications[indexN][0]
                    pchannel=     notifications[indexN][1]
                    cid=          notifications[indexN][2]
                    ctitle=       notifications[indexN][3]
                    cepg_channel= notifications[indexN][4]
                    cid=          notifications[indexN][5]
                    pstart_date=  notifications[indexN][6]
                    
                    log('TEST - Found SearchText= %r' % ('%'+SearchText[0].strip()+'%'))
                    log('TEST - p.title= %r, \np.channel=     %r, c.id= %r, c.title= %r, \nc.epg_channel= %r \nc.id= %r \np.start_date= %r' % (ptitle, pchannel, cid, ctitle, cepg_channel, cid, time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(pstart_date))))
            else:
                log('TEST - Nothing found: %r' % ('%'+SearchText[0].strip()+'%'))
            
            log('len(SearchText)= %r, SearchText= %r' % (len(SearchText),SearchText))       
            if len(SearchText) == 1 : ##################################################################
                log('1. SearchText= %r' % ('%'+SearchText[0].strip()+'%'))
                c.execute("SELECT * FROM programs p, channelsRecursive c WHERE p.title LIKE ? and p.channel = c.epg_channel and p.start_date > ? COLLATE NOCASE", ['%'+SearchText[0].strip()+'%', nowTS])
            if len(SearchText) == 2 :  
                log('2. SearchText= %r' % ('%'+SearchText[0].strip()+'%'))
                c.execute("SELECT * FROM programs p, channelsRecursive c WHERE p.title LIKE ? AND p.title NOT LIKE ? AND p.channel = c.epg_channel and p.start_date > ? COLLATE NOCASE", ['%'+SearchText[0].strip()+'%','%'+SearchText[1].strip()+'%', nowTS])
            if len(SearchText) == 3 :  
                log('3. SearchText= %r' % ('%'+SearchText[0].strip()+'%'))
                c.execute("SELECT * FROM programs p, channelsRecursive c WHERE p.title LIKE ? AND p.title NOT LIKE ? AND p.title NOT LIKE ? AND p.channel = c.epg_channel and p.start_date > ? COLLATE NOCASE", ['%'+SearchText[0].strip()+'%','%'+SearchText[1].strip()+'%','%'+SearchText[2].strip()+'%', nowTS])
            if len(SearchText) > 3 :  
                log('4. SearchText= %r' % ('%'+SearchText[0].strip()+'%'))
                c.execute("SELECT * FROM programs p, channelsRecursive c WHERE p.title LIKE ? AND p.title NOT LIKE ? AND p.title NOT LIKE ? AND p.title NOT LIKE ? AND p.channel = c.epg_channel and p.start_date > ? COLLATE NOCASE", ['%'+SearchText[0].strip()+'%','%'+SearchText[1].strip()+'%','%'+SearchText[2].strip()+'%','%'+SearchText[3].strip()+'%', nowTS])
            notifications = c.fetchall()
            
            log('len(notifications)= %r' % len(notifications))
            if len(notifications) > 0:
                logarray('2. notifications',notifications,len(notifications[0]))
                ###programs(0channel, 1title, 2sub_title, 3start_date, 4end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
                ###channelsRecursive(0id TEXT, 1title TEXT, 2logo TEXT, 3stream_url TEXT, 4source TEXT, 5visible BOOLEAN, 6weight INTEGER, 7favorite BOLEAN, 8catchup BOLEAN, 9epg_channel TEXT, description TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (title, source))")
                for indexN in range(0, len(notifications)): 
                    ptitle=       notifications[indexN][1]
                    pchannel=     notifications[indexN][0]
                    cid=          notifications[indexN][15]  #2 - 0 +15
                    ctitle=       notifications[indexN][16]  #3 - 1
                    cepg_channel= notifications[indexN][24]  #4 - 9
                    cid=          notifications[indexN][15]  #5 - 0
                    pstart_date=  notifications[indexN][3]  
                    
                    log('2. TEST - Found SearchText= %r' % ('%'+SearchText[0].strip()+'%'))
                    log('2. TEST - p.title= %r, \np.channel=     %r, c.id= %r, c.title= %r, \nc.epg_channel= %r \nc.id= %r \np.start_date= %r' % (ptitle, pchannel, cid, ctitle, cepg_channel, cid, HT(pstart_date)))
            else:
                log('TEST - Nothing found: %r' % ('%'+SearchText[0].strip()+'%'))
               
            if len(notifications) > 0:
                for indexN in range(0, len(notifications)): 
                    channel= notifications[indexN][0]
                    program= notifications[indexN][1]
                    log('err indexN= %r' % indexN)
                    log('err channel= %r' % channel)
                    log('err SearchText= %r' % SearchText)
                    log('err   program= %r' % program)
                    c.execute("SELECT DISTINCT id, title, logo, stream_url, source, visible, weight, epg_channel FROM channelsRecursive WHERE epg_channel=? and visible=1",  [channel])   ### 2018-08-28
                    log('err epg_channel= %r' % (channel))
                    channeldata= c.fetchall()
                    if len(channeldata) > 0:
                        log('1. len(channeldata)= %r' % len(channeldata))
                        log('1. len(channeldata[0])= %r' % len(channeldata[0]))
                        logarray('1. channeldata',channeldata,nelements=len(channeldata[0]))
                        now = int(time.mktime(datetime.now().timetuple()))
                        cz= c.execute("SELECT * FROM programs WHERE channel=? AND title=? AND start_date >= ?",  [channel, program, now]) ### Recursive Only on channel in record
                        log('[channel= %r, program= %r, now= %r]' % (channel, program, now))
                        programs= cz.fetchall()
                        if len(programs) > 0:
                            log('err cz len(programs)= %r' % len(programs))
                            logarray('cz programs 1',programs,nelements=len(programs[0]))
                        
                        cy= c.execute("SELECT DISTINCT p.*, c.epg_channel FROM programs p, channelsRecursive c WHERE p.channel = c.epg_channel AND p.title = ? AND p.start_date >= ? AND c.epg_channel = ?",[program, now, channel])
                        log('[program= %r, now= %r, epg= %r]' % (program, now, channel))
                        ###programs += cy.fetchall()   ### TEST just test original channel 2017-08-25
                        programs = cy.fetchall()  
                        if len(programs) > 0:
                            log('err len(programs)= %r' % len(programs))
                            logarray('cy program 2',programs,nelements=len(programs[0]))
                        
                        NTVchannelSelect= NTVchannels
                        for prog in range(0, len(programs)):
                            try:
                                cweight= programs[prog][9]
                                log('cweight= %r' % cweight)
                            except:
                                pass
                            pchannel= programs[prog][0]
                            log('err pchannel= %r' % pchannel)
                            ptitle= programs[prog][1]
                            log('ptitle= %r' % ptitle)
                            if TVguideNR == '0':
                                pstart_date= programs[prog][3]
                                pend_date= programs[prog][4]
                            else:
                                pstart_date= programs[prog][2]
                                pend_date= programs[prog][3]
                            log('err pstart_date= %r pend_date= %r type(pstart_date)= %r' % (HT(pstart_date),HT(pend_date),type(pstart_date)))
                            
                            if not type(pstart_date) is int:
                                if type(pend_date) is int:
                                    log('err pstart_date is not int and set to pend-2h= %r' % pstart_date)
                                    pstart_date = datetime.fromtimestamp(pend_date) - timedelta(hours = 2)  ### If pstart is missing sub 2 hours from pend
                                    
                                else:
                                    log('err pstart_date is not datetime and set to now= %r -3h= %r' % (datetime.now(),pstart_date))
                                    pstart_date = datetime.now() - timedelta(hours = 3)  ### If pstart and pend is missing sub 3h from now making it obsolete
                            else:
                                pstart_date = datetime.fromtimestamp(pstart_date)
                            if not type(pend_date) is int:  
                                log('err pend_date (pstart_date + 2)= %r' % pend_date)
                                pend_date = pstart_date + timedelta(hours = 2)  ### If pend is missing add 2 hours
                            else:
                                pend_date = datetime.fromtimestamp(pend_date)
                            ### pstart_date and pend_date are now datetime
                            
                            if TVguideNR == '0':
                                pdescription= programs[prog][5]
                            else:
                                pdescription= programs[prog][4]
                            log('err channeldata[0][1]= %r' % (channeldata[0][1]))
                            try:
                                log('err channeldata[1][1]= %r' % (channeldata[1][1]))
                                log('err channeldata[2][1]= %r' % (channeldata[2][1]))
                            except:
                                pass
                            catX= recordings.CatFromChannelName(channeldata[0][1])
                            log('error CatFromChannelName catX= %r' % catX)
                            cat= recordings.catFromEPGcat(cat)
                            log('error CatFromChannelName cat= %r' % cat)
                            ###cat= recursivechannel  ### 2017-09-23
                            ####cat = catX    ### 2023-03-22
                            log('error catFromEPGcat cat= %r' % (cat))
                            if cat == '0' or cat == '-1':  ## Channel from TVguide not found - ignore
                                ###b.execute("SELECT * FROM channels WHERE title=? and source=? and visible=?", [channeldata[0][1],guide,1])
                                b.execute("SELECT * FROM channels WHERE epg_channel=? and source=? and visible=?", [pchannel,guide,1])  ### 2020-04-05
                                channelconvert = b.fetchall()
                                if len(channelconvert) == 0:
                                    SelectedChannel = xbmcgui.Dialog().select(guide + ': Select Channel forX: ' + channeldata[0][1] + ' - ' + channeldata[0][0] + ' - ' + ptitle, NTVchannelSelect)
                                    log('SelectedChannel= %r' % SelectedChannel)
                                    if SelectedChannel >= 0:
                                        try:
                                            log('NTVchannelSelect[SelectedChannel]= %r' % NTVchannelSelect[SelectedChannel])
                                            id = NTVchannelSelect[SelectedChannel].replace(' (D)','').replace(' (VPN OR UK ONLY)','').split('(')[1].split(')')[0].split(' -')[0]  ### 2017-08-24
                                            log('findrecursiverecordingsinGuide id= %r' % id)
                                            if id != '' and id != '0' and id != 0 :
                                                b.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight) VALUES(?, ?, ?, ?, ?, ?, ?)", [id, channeldata[0][1], '', '', guide, 'True', id])

                                                log('findrecursiverecordingsinGuide id= %s' % (repr(id)))
                                                cat = id
                                                log('findrecursiverecordingsinGuide Selected cat= %s' % (repr(cat)))
                                                
                                        except Exception as e:
                                            pass
                                            cat = '0'
                                            log('findrecursiverecordingsinGuide SelectedChannel FAILED guide= %s ERROR= %s' % (guide,repr(e)))
                                    conv.commit()
                                else:
                                    cat = channelconvert[0][0]
                                    log('findrecursiverecordingsinGuide Converted cat= %r' % cat)
                            now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                            try:
                                
                                log('findrecursiverecordingsinGuide guide= %s Recursive= %s' % (guide,Recursive[index]))
                                if type(pdescription) != str:
                                    pdescription = 'empty1'
                                if type(now) != str:
                                    now = 'empty2'
                                if type(Recursive[index][1]) != str:
                                    Recursive[index][1] = 'empty3'
                                if type(guide) != str:
                                    guide = 'empty4'
                                if type(channeldata[0][1]) != str:
                                    channeldata[0][1] = 'empty5'
                                if type(channeldata[0][0]) != str:
                                    channeldata[0][0] = 'empty6'
                                if type(ptitle) != str:
                                    ptitle = 'empty7'
                                pdescription = pdescription + ' \n\nCreated: ' + now +' \nRecursive [' + Recursive[index][1].replace(RECURSIVEMARKER, '') + '] from ' + guide + ' - ' + channeldata[0][1] + ' - ' + channeldata[0][0] + ' \n\n' + ptitle
                                pdescription = pdescription.replace('(','[').replace(')',']')
                            except Exception as e:
                                pass
                                log('findrecursiverecordingsinGuide Description FAILED guide= %s ERROR= %s' % (guide,repr(e)))
                            log('findrecursiverecordingsinGuide cat= %s' % repr(cat))
                            log('findrecursiverecordingsinGuide pdescription= %s' % repr(pdescription))
                            log('findrecursiverecordingsinGuide pend_date= %s' % repr(pend_date))
                            delta = timedelta(hours = TimeZoneOffset)
                            log('findrecursiverecordingsinGuide timedelta(hours = TimeZoneOffset)= %s' % repr(delta))
                            ###if not cat == '' :
                            log('err 1. recordings.schedule(cat= %r, pstart_date + timedelta(hours = TimeZoneOffset)= %r, pend_date + timedelta(hours = TimeZoneOffset)= %r, CcCc + program= %r, pdescription= %r)' % (cat, pstart_date + timedelta(hours = TimeZoneOffset), pend_date + timedelta(hours = TimeZoneOffset), 'CcCc' + program, pdescription))
                            if cat != '' and cat != '0' and cat != 0 :
                                log('err recordings.schedule DB= %r' % c)
                                if mark:
                                    scheduleflag = recordings.schedule(cat, pstart_date + timedelta(hours = TimeZoneOffset), pend_date + timedelta(hours = TimeZoneOffset), '*' + program, pdescription,c)   ### Disable recording
                                    log('err 2. recordings.schedule(cat= %r, pstart_date + timedelta(hours = TimeZoneOffset)= %r, pend_date + timedelta(hours = TimeZoneOffset)= %r, CcCc + program= %r, pdescription= %r)' % (cat, pstart_date + timedelta(hours = TimeZoneOffset), pend_date + timedelta(hours = TimeZoneOffset), '*' + program, pdescription))
                                else:
                                    scheduleflag = recordings.schedule(cat, pstart_date + timedelta(hours = TimeZoneOffset), pend_date + timedelta(hours = TimeZoneOffset), 'CcCc' + program, pdescription,c)
                                    log('3. recordings.schedule(cat= %r, pstart_date + timedelta(hours = TimeZoneOffset)= %r, pend_date + timedelta(hours = TimeZoneOffset)= %r, CcCc + program= %r, pdescription= %r)' % (cat, pstart_date + timedelta(hours = TimeZoneOffset), pend_date + timedelta(hours = TimeZoneOffset), 'CcCc' + program, pdescription))
                                log('scheduleflag= %r' % scheduleflag)
                                if scheduleflag == True:
                                    scheduled +=1
                                # Set notification in TV Guide channeldata[0][0], program, utils.ADDONgetAddonInfo('name')
                                try:
                                    c.execute("SELECT * FROM notifications WHERE channel = ? AND program_title = ? AND source = ?",  [channeldata[0][0], program, channeldata[0][4]])
                                    notify =  c.fetchall()
                                    logarray('notify',notify,nelements=2)
                                    if len(notify) == 0 and utils.ADDONgetSetting('updateguide')=='true':  ## Only insert if not already there and set up in settings that recursive recordings are transferred
                                        if mark:
                                            c.execute("INSERT OR REPLACE INTO notifications (channel, program_title, source) VALUES(?, ?, ?)", [channeldata[0][0], '[COLOR orange]'+program+'[/COLOR]', channeldata[0][4]])
                                        else:
                                            c.execute("INSERT OR REPLACE INTO notifications (channel, program_title, source) VALUES(?, ?, ?)", [channeldata[0][0], program, channeldata[0][4]])
                                except Exception as e:
                                    pass
                                    log('findrecursiverecordingsinGuide not cat ==  FAILED guide= %s ERROR= %s' % (guide,repr(e)))
                    
    """
    now = datetime.now()
    # Transfer programs to programsForHumans
    #utils.logdev('findtvguidenotifications','channels= %s' % (repr(programs[prog][0])))
    c.execute("SELECT * FROM channels WHERE visible")
    channels= c.fetchall()
    ###utils.logdevarray(module+ '-channels',channels)
    for chan in range(0, len(channels)):
        time.sleep(1/100)
        if channels[chan][1] == channels[chan][0]:
            humanchannel= channels[chan][0]
        else:
            humanchannel= channels[chan][1] + ' (' + channels[chan][0] + ')'
        try:
            c.execute("SELECT * FROM programs WHERE start_date >= ? AND channel=?",  [now,channels[chan][0]]) 
            programs= c.fetchall()
        except Exception as  e:
            pass
            utils.logdev('findrecursiverecordingsinGuide FAILED', 'now= %r, channel= %r, ERROR= %r' % (now,channels[chan][0],repr(e)))
            ###utils.logdev('findtvguidenotifications','programs= %s' % (repr(programs)))
        for prog in range(0, len(programs)):
            #utils.logdev('findtvguidenotifications','channels= %s' % (repr(channels)))
            #utils.logdev('findtvguidenotifications','channels[0][0]= %s, channels[0][1]= %s, egual= %s' % (repr(channels[0][1]), repr(channels[0][0]), repr(channels[0][1] == channels[0][0])))
            
            c.execute("SELECT * FROM programsForHumans WHERE channel=? AND title=? AND start_date=? AND end_date=? AND description=? AND source=?", [humanchannel, programs[prog][1],str(programs[prog][2]),str(programs[prog][3]),programs[prog][4],programs[prog][7]])
            programsForHumans =  c.fetchall()
            ###utils.logdev('findtvguidenotifications','len(programsForHumans)= %s' % repr(len(programsForHumans)))
            if len(programsForHumans) == 0:  ## Only insert if not already there
                c.execute("INSERT OR REPLACE INTO programsForHumans (channel, title, start_date, end_date, description, image_large, image_small, source) VALUES(?, ?, ?, ?, ?, ?, ?, ?)", [humanchannel, programs[prog][1],str(programs[prog][2]),str(programs[prog][3]),programs[prog][4],programs[prog][2],programs[prog][3],programs[prog][7]])
    """
    recordings.addAlarm(module, 'ended findrecursiverecordingsinGuideCode', '', '00:00:00', 'options')
    conn.commit()
    conv.commit()
    c.close()
    b.close()
    
    log('findrecursiverecordingsinGuideCode EXECUTION Finished guide= %s' % guide)
    return scheduled

def adjusttvguide(conn,c,first):
    try: 
        sqlfilename= utils.ADDONgetSetting('AdjustTVguideSqlFile')
        lineno = 0
        linemarker = '#lineno#'
        log('adjusttvguide'+repr(sqlfilename))
        sqlfile= open(sqlfilename,'r')
        line0 = sqlfile.readline()
        log('adjusttvguide'+repr(line0))
        if 'firstchannel=' in line0.lower():
            firstchannel= line0.lower().split('firstchannel=')[1].strip()
            if firstchannel != first.lower():
                line = sqlfile.readline().strip('\n')
                if linemarker in line:
                    line = line.replace(linemarker,str(lineno))   ### Automatic insert weight/linenumber
                    lineno += 1
                while line != '':
                    log('adjusttvguide'+repr(line))
                    c.execute(line)
                    line = sqlfile.readline()
                    if linemarker in line:
                        line = line.replace(linemarker,str(lineno))   ### Automatic insert weight/linenumber
                        lineno += 1
                log('adjusttvguide DROP TABLE programsForHumans')
                c.execute("DROP TABLE programsForHumans")
            else:
                log('adjusttvguide TV Guide already updated')
        else:
            utils.notificationbox('adjusttvguide: The sql file %s to adjust the TV Guide must start with: Firstchannel=' % repr(sqlfilename))
    except Exception as e:
        pass
        log('adjusttvguide No Adjust TV Guide SQL file or not all lines executed! ERROR= %r' % (e))
    conn.commit()   

def grabGuide(guide,EPG_DB):
    scheduled = 0
    if utils.ADDONgetSetting('DebugRecording') == 'false' or True:
        try:
            scheduled = grabGuideCode(guide,EPG_DB)
        except Exception as e:
            pass
            log('grabGuide EXECUTION FAILED 4: guide= %r, ERROR= %r' % (guide,e))
    else:
        scheduled = grabGuideCode(guide,EPG_DB)  
    log('findtvguidenotifications scheduled= %r' % scheduled)
    return scheduled


def grabGuideCode(guide,EPG_DB):        
    log('*dr2.dk grabGuideCode guide= %r' % guide)
    #try:
    ADDONguide = xbmcaddon.Addon(id=guide)
    scheduled = 0
    dbPathEPG = xbmcvfs.translatePath(ADDONguide.getAddonInfo('profile'))
    ###utils.logdev('grabGuideCode', 'dbPath= %s' % dbPathEPG)
    if not os.path.exists(dbPathEPG):
        #utils.logdev('findtvguidenotifications', 'os.mkdir(dbPath) where dbPath= %s' % dbPathEPG)
        os.mkdir(dbPathEPG)
    if not os.path.exists(dbPathNTV):
        os.mkdir(dbPathNTV)
    """
    cNTV   = sqlite3.connect(os.path.join(dbPathNTV, CHANNEL_DB), timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    cNTV.execute('PRAGMA foreign_keys = ON')
    cNTV.row_factory = sqlite3.Row
    cNTV.text_factory = str
    """
    cNTV = recordings.getDatabaseConnection(os.path.join(dbPath, CHANNEL_DB))
    a = cNTV.cursor()
    a.execute("PRAGMA journal_mode = WAL")  ### 2018-01-07 Try to speed up on Windows 
    ###a.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)") ## 2016-05-15
    a.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, title, source))")
    cNTV.commit()
    ###utils.logdev('grabGuideCode', 'cNTV.commit() dbPath= %s' % dbPathEPG)
    """
    conv   = sqlite3.connect(os.path.join(dbPath, RECORDS_DB), timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conv.execute('PRAGMA foreign_keys = ON')
    conv.row_factory = sqlite3.Row
    conv.text_factory = str
    """
    conv = recordings.getDatabaseConnection(os.path.join(dbPath, RECORDS_DB))
    b = conv.cursor()
    b.execute("PRAGMA journal_mode = WAL")  ### 2018-01-07 Try to speed up on Windows 
    ##b.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)") ## 2016-05-15
    b.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, title, source))")
    conv.commit()
    ###utils.logdev('grabGuideCode', 'conv.commit() dbPath= %s' % dbPathEPG)
    """
    conn   = sqlite3.connect(os.path.join(dbPathEPG, EPG_DB), timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    """
    conn = recordings.getDatabaseConnection(os.path.join(dbPath, EPG_DB))
    c = conn.cursor()
    c.execute("PRAGMA journal_mode = WAL")  ### 2018-01-07 Try to speed up on Windows 
    ###utils.logdev('grabGuideCode', 'conXX.commit() dbPath= %s' % dbPathEPG)
    ###c.execute("CREATE TABLE IF NOT EXISTS notifications (channel TEXT, program_title TEXT, source TEXT, FOREIGN KEY(channel, source) REFERENCES channels(id, source) ON DELETE CASCADE)")
    c.execute("CREATE TABLE IF NOT EXISTS notifications (channel TEXT, program_title TEXT, source TEXT)")
    ###c.execute("CREATE TABLE IF NOT EXISTS programs (channel TEXT, title TEXT, start_date TIMESTAMP, end_date TIMESTAMP, description TEXT, image_large TEXT, image_small TEXT, source TEXT, updates_id INTEGER, PRIMARY KEY (id, updates_id), FOREIGN KEY(updates_id) REFERENCES updates(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
    ###utils.logdev('grabGuideCode', 'conXXXX.commit() dbPath= %s' % dbPathEPG)
    c.execute("CREATE TABLE IF NOT EXISTS programs (channel TEXT, title TEXT, start_date TIMESTAMP, end_date TIMESTAMP, description TEXT, image_large TEXT, image_small TEXT, source TEXT, updates_id INTEGER, PRIMARY KEY (id, updates_id))")
    ###c.execute("CREATE TABLE IF NOT EXISTS channels (id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY(id,source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
    ###utils.logdev('grabGuideCode', 'conXXXXXX.commit() dbPath= %s' % dbPathEPG)
    c.execute("CREATE TABLE IF NOT EXISTS channels (id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY(id,title, source))")
    conn.commit()
    ###utils.logdev('grabGuideCode', 'conn.commit() dbPath= %s' % dbPathEPG)
    ## Adjust TV Guide
    ###utils.logdev('grabGuideCode', 'SELECT * FROM channels WHERE weight=0')
    c.execute("SELECT * FROM channels WHERE weight=0")
    ###c.execute("SELECT * FROM channels")
    channels = c.fetchall()
    ###utils.logdev('grabGuideCode', 'len(channels)= %r' % len(channels))
    if len(channels) == 1:
        adjusttvguide(conn,c,channels[0][1])
    else:
        adjusttvguide(conn,c,'missing channel 0 force update')
        
    c.execute("SELECT * FROM notifications")
    notifications = c.fetchall()
    ###utils.logdev('grabGuideCode', 'notifications= %r' % notifications)
    ###utils.logdevarray('grabGuideCode-notifications', notifications)
    
    NTVchannels = MyPlayChannels() ######################################### 2017-08-25
    ###utils.logdev('grabGuideCode', 'MyNTVchannels= %r' % NTVchannels)

    #if len(NTVchannels) < 2:   ## Only Euronews is not enough (2)
    #   from operator import itemgetter
    #   a.execute("SELECT * FROM channels WHERE id=ltrim(id,'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ') ") #### id must be number!
    #   NTVchannels = a.fetchall()
    #   #utils.logdev('findtvguidenotifications', 'NTVchannels(unsorted)= %s' % repr(NTVchannels))
    #   NTVchannels = sorted(NTVchannels, key=itemgetter(1))
    #   #utils.logdev('findtvguidenotifications', 'NTVchannels= %s' % repr(NTVchannels))

    for index in range(0, len(notifications)): 
        time.sleep(1/100)
        channel= notifications[index][0]
        program= notifications[index][1]
        log('*dr2.dk grabGuideCode channel= %r' % channel)
        log('*dr2.dk grabGuideCode program= %r' % program)
        c.execute("SELECT DISTINCT id, title, logo, stream_url, source, visible, weight FROM channels WHERE id=? and visible=?",  [channel,1])
        channeldata= c.fetchall()
        logarray('* dr2.dk grabGuideCode-channeldata', channeldata,nelements=3)
        
        now = datetime.now()
        
        c.execute("SELECT * FROM programs WHERE channel=? AND title=? AND start_date >= ?",  [channel, program, now])
        
        programs= c.fetchall()
        logarray('* dr2.dk grabGuideCode-programs', programs,nelements=3)
    
        '''
        channel= 'BBC 1 London'
        program= 'The Big Questions'
        channeldata= [(u'BBC 1 London', u'BBC One', u'http://wozboxtv.com/downloads/xmltv/logos/BBC%20One.png', None, u'xmltv', 1, 0)]
        now= datetime(2016, 2, 7, 10, 46, 51, 603477)
        programs= [(u'BBC 1 London', u'The Big Questions', datetime(2016, 2, 7, 11, 0), datetime(2016, 2, 7, 12, 0), u'Nicky Campbell presents moral and religious discussions on topical issues from King Edward VI School, Southampton.(n)', None, u'http://cdn.tvguide.co.uk/HighlightImages/Large/big_questions.jpg', u'xmltv', 1)]
        '''
    
        #NTVchannelSelect = []
        #for x in range (0,len(NTVchannels)):
        #   #try:
        #       #utils.logdev('findtvguidenotifications', 'NTVchannels[x]= %s' % (repr(NTVchannels[x])))
        #       #if isnumeric(str(NTVchannels[x])):
        #       NTVchannelSelect.append(NTVchannels[x])
        #       #utils.logdev('findtvguidenotifications', 'NTVchannelSelect= %s' % (repr(NTVchannelSelect)))
        #   #except:
        #   #   pass
        #utils.logdev('findtvguidenotifications', 'guide= %s and EPG_DB= %s' % (guide,EPG_DB))
        #utils.logdev('findtvguidenotifications', 'NTVchannelSelect= %s' % (repr(NTVchannelSelect)))
    
        NTVchannelSelect= NTVchannels
        for prog in range(0, len(programs)):
            time.sleep(1/100)
            pchannel= programs[prog][0]
            ptitle= programs[prog][1]
            if TVguideNR == '0':
                pstart_date= programs[prog][3]
                pend_date= programs[prog][4]
                pdescription= programs[prog][5]
            else:
                pstart_date= programs[prog][2]
                pend_date= programs[prog][3]
                pdescription= programs[prog][4]

            cat= recordings.CatFromChannelName(channeldata[0][1])
            log('err CatFromChannelName cat= %r <-- %r' % (cat,channeldata[0][1]))
            if cat == '0':  ## Channel from TVguide not found ##
                log('err grabGuideCode-channelconvert [channeldata[0][1]= %r,guide= %r]'% (channeldata[0][1],guide))
                b.execute("SELECT * FROM channels WHERE title=? and source=? and visible=?", [channeldata[0][1],guide,1])
                channelconvert = b.fetchall()
                logarray('grabGuideCode-channelconvert', channelconvert, nelements=3)
                if len(channelconvert) == 0:
                    log('err findtvguidenotifications Waiting for Select Channel for  %s' % (repr(guide + ': Select Channel for: ' + channeldata[0][1] + ' - ' + channeldata[0][0] + ' - ' + ptitle)))
                    SelectedChannel = xbmcgui.Dialog().select(guide + ': Select Channel forY: ' + channeldata[0][1] + ' - ' + channeldata[0][0] + ' - ' + ptitle, NTVchannelSelect)
                    log('err findtvguidenotifications SelectedChannel= %r' % (SelectedChannel))
                    if SelectedChannel >= 0:
                        try:
                            id = NTVchannelSelect[SelectedChannel].split('(')[1].split(')')[0]
                            if not id == '' and not id == '0':
                                b.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight) VALUES(?, ?, ?, ?, ?, ?, ?)", [id, channeldata[0][1], '', '', guide, 'True', id])
                                cat = id  ### 2016-06-13
                        except Exception as e:
                            pass
                            log('err grabGuide SelectedChannel <> -1 FAILED 4 guide= %r, ERROR= %r' % (guide,e))
                    conv.commit()
                else:
                    cat = channelconvert[0][0]
            log('err grabGuideCode-channelconvert cat= %r,guide= %r]'% (cat,guide))
            now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
            log('grabGuideCode-channelconvert now= %r,guide= %r]'% (now,guide))
            pdescription = pdescription + ' \n\nCreated: ' + now + ' \nNotification from ' + guide + ' - ' + channeldata[0][1] + ' - ' + channeldata[0][0] + ' \n\n' + ptitle
            log('grabGuideCode-channelconvert pdescription= %r,guide= %r]'% (pdescription,guide))
            pdescription = pdescription.replace('(','[').replace(')',']')
            log('4. recordings.schedule(cat= %r, pstart_date + timedelta(hours = TimeZoneOffset)= %r, pend_date + timedelta(hours = TimeZoneOffset)= %r, program= %r, pdescription= %r)' % (cat, HT(pstart_date + timedelta(hours = TimeZoneOffset)), HT(pend_date + timedelta(hours = TimeZoneOffset)), program, pdescription))
            if not cat == '' and not cat == '0':
                log('err scheduleflag = recordings.schedule(cat= %r, pstart_date + timedelta(hours = TimeZoneOffset)= %r, pend_date + timedelta(hours = TimeZoneOffset)= %r, program= %r, pdescription= %r)' % (cat, pstart_date + timedelta(hours = TimeZoneOffset), pend_date + timedelta(hours = TimeZoneOffset), program, pdescription))
                scheduleflag = recordings.schedule(cat, pstart_date + timedelta(hours = TimeZoneOffset), pend_date + timedelta(hours = TimeZoneOffset), program, pdescription)
                if scheduleflag == True:
                    scheduled +=1
        
    c.close()
    b.close()
    return scheduled
    log('grabGuide FINISHED!')
    #except:
    #   pass
    #   utils.logdev('grabGuide', 'FAILED!')

######################################################################
"""
def RecursiveRecordingsPlanned(SearchAllFavorites):
    #import recordings
    ###cat = ADDON.getSetting('SearchRecursiveIn')
    if locking.isAnyRecordLocked():
        locking.scanUnlockAll()
        return
    elif  locking.isAnyScanLocked():
        return
    else:
        locking.scanLock(SearchAllFavorites)
    if not locking.isScanLocked(SearchAllFavorites):
        return
    #utils.logdev('findrecursivetvguide.py RUNNING RecursiveRecordingsPlanned','cat= %s, SearchAllFavorites= %s' % (repr(cat), repr(SearchAllFavorites)))
    ###ADDON.setSetting('RecursiveSearch','true')
    
    conn = recordings.getConnection()
    c = conn.cursor()
    c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE '%Recursive:%' COLLATE NOCASE")  # Find all recursive recordings
    recordingsE = c.fetchall()
    # Put recursive recordings changed last - first
    recordingsC = sorted(recordingsE, key=itemgetter(2), reverse=True)
    #utils.logdev('findrecursivetvguide.py: Recursive recordings',repr(recordingsC))
    for index in range(0, len(recordingsC)):
        if isinstance(recordings.parseDate(recordingsC[index][2]), datetime.date) and isinstance(recordings.parseDate(recordingsC[index][3]), datetime.date) and 'Recursive:' in recordingsC[index][1]:
            if int(ADDON.getSetting('SearchRecursiveIn')) > 0 or ((not SearchAllFavorites == 'NotAllFavorites')and(not SearchAllFavorites == 'Once')and(not SearchAllFavorites == 'Hour')):
                if not recordingsC[index][0] in uniques:
                    findrecursiveinplaychannel(recordingsC[index][0],recordingsC[index][1],index) # Allways search channel in record
                    if ADDON.getSetting('NotifyOnSearch')=='true' and not '[COLOR orange]' in recordingsC[index][1]:
                        utils.notification('Find%s [COLOR green]complete in own channel[/COLOR]' % recordingsC[index][1])
                for cat in uniques:
                    findrecursiveinplaychannel(cat,recordingsC[index][1],index)
                if ADDON.getSetting('NotifyOnSearch')=='true' and not '[COLOR orange]' in recordingsC[index][1]:
                    utils.notification('Find%s [COLOR green]complete[/COLOR]' % recordingsC[index][1])
            else:
                findrecursiveinplaychannel(recordingsC[index][0],recordingsC[index][1],index)
                if ADDON.getSetting('NotifyOnSearch')=='true' and not '[COLOR orange]' in recordingsC[index][1]:
                    utils.notification('Find%s [COLOR green]complete[/COLOR] in selected channel: %s' % (recordingsC[index][1], recordingsC[index][0]))
    conn.commit()
    c.close()
    if ADDON.getSetting('NotifyOnSearch')=='true':
        utils.notification('Find all recursives [COLOR green]complete[/COLOR]')
    locking.scanUnlockAll()
    ###ADDON.setSetting('RecursiveSearch','false')
    return

def findrecursiveinplaychannel(cat,title,index):
    if locking.isAnyRecordLocked():
        locking.scanUnlockAll()
        return
    if '[COLOR orange]' in title:
        utils.logdev('findrecursiveinplaychannel','DISABLED: %s' % repr(title))  # Put message in LOG
        return

    name = title
    try:
        name = name.split('Recursive:')[1]
    except Exception as  e:
        pass
        utils.logdev('grabGuide name.split(Recursive:)[1] FAILED ', 'guide= %r, ERROR= %r' % (guide,e))
    newname = recordings.latin1_to_ascii(name)
    newname = newname.strip()
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20')
    nowT= recordings.parseDate(datetime.today())
    
    conn = recordings.getConnection() ###################### TV Guide database
    c = conn.cursor()
    c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name CONTAINS 'Recursive:'")  ####################################################################################################
    recordingsE = c.fetchall()
    # Put recursive recordings changed last - first
    recordingsC = sorted(recordingsE, key=itemgetter(2), reverse=True)
    #utils.logdev('findrecursivetvguide.py: Recursive recordings',repr(recordingsC))
    for field in recordingsC:
        time='[COLOR yellow](%s) - [/COLOR]'%(startDate.strftime('%H:%M'))
        recordnameT = recordings.latin1_to_ascii(recordname)
        startDateT = recordings.parseDate(startDate)
        if (newname.upper() in recordnameT.upper()) and (nowT < (startDateT + timedelta(hours = TimeZoneOffset))):
            recordings.schedule(cat, startDate + timedelta(hours = TimeZoneOffset), endDate + timedelta(hours = TimeZoneOffset), recordname, description)
"""

