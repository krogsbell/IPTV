#!/usr/bin/python
# -*- coding: utf-8 -*-

import urllib2    ### krogsbell 2019-05-21
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import _strptime
import os
import xbmcgui, xbmcplugin, xbmcaddon
import utils
import json as simplejson
import xbmcvfs

CHANNELS_URL = 'https://www.dr.dk/mu-online/api/1.0/channel/all-active-dr-radio-channels'
PATH = sys.argv[1]
idtext = PATH.replace('plugin:','').replace('/','').replace('special:homeaddons','')
ADDON = xbmcaddon.Addon(id=idtext)
ADDONname = ADDON.getAddonInfo('name')
ADDONid   = ADDON.getAddonInfo('id')
ADDONpath = xbmc.translatePath('special://home/addons/%s/' % ADDONid)
LOGO_PATH = os.path.join(ADDONpath, 'resources', 'logos')
ICON = os.path.join(ADDONpath, 'icon.png')
FANART = os.path.join(ADDONpath, 'fanart.jpg')
module = 'startstation.py'

def __log(text):
    utils.logdev(sys.argv[0]+' '+sys.argv[2],text)

def playEPG(idx):
    __log('playEPG(idx= %r)'% idx)
    try:
        u = urllib2.urlopen(CHANNELS_URL)
        channelList = simplejson.loads(u.read())
        u.close()
    except Exception, ex:
        showError(str(ex))
        return
    try:
        for channel in channelList:
            title = channel['Title']
            slug  = channel['Slug']
            if title[0:3] == 'DR ':
                title = title[3:]
            __log('playEPG(title= %r slug= %r)'% (title,slug))
            idxlower = idx.lower()
            if ('p4' in idxlower and idxlower == slug) or idxlower[:2] == slug[:2]:   ### 2019-10-27
            ###if idx.lower() == slug:
                sourceUrl = channel['SourceUrl']
                logoImage = os.path.join(LOGO_PATH, sourceUrl[sourceUrl.rindex('/') + 1:] + '.png')
                if xbmcvfs.exists(logoImage):
                    item = xbmcgui.ListItem(title, iconImage=logoImage)
                else:
                    item = xbmcgui.ListItem(title, iconImage=ICON)

                item.setProperty('IsPlayable', 'true')
                item.setProperty('Fanart_Image', FANART)
                item.setInfo(type='music', infoLabels={
                    'title': title
                })

                url = None

                if 'StreamingServers' in channel:
                    for server in channel['StreamingServers']:
                        if 'LinkType' in server and server['LinkType'] == 'ICY' and 'Qualities' in server:
                            try:
                                url = server['Server'] + '/' + server['Qualities'][0]['Streams'][0]['Stream']
                                break
                            except:
                                pass
                __log('playEPG(url= %r)'% url)
                if url:
                    __log('play-ing-EPG(url= %r)'% url)
                    url = url.replace('https://live-icy.dr.dk/A/A2H.mp3','http://live-icy.gss.dr.dk/A/A25L.mp3')
                    __log('url= %r' % url)
                    if title[0:3] == 'DR ':
                        title = title[3:]
                    if title[0:2] != 'P4':
                        title = title[:2]
                    logoImage = os.path.join(LOGO_PATH, title + '.png')
                    item = xbmcgui.ListItem(path=url, thumbnailImage=logoImage)
                    item.setInfo(type='music', infoLabels={
                        'title': title
                    })
                    ADDON.setSetting('programplaying',idx)
                    if not xbmc.Player().isPlaying():
                        __log('Player is NOT Playing #0')
                    else:
                        __log('Player is Playing #0')
                    xbmc.Player().play(url, item, True)
                    __log('play-ing-EPG-started(url= %r)'% url)
                    xbmc.sleep(1000)
                    if not xbmc.Player().isPlaying():
                        __log('Player is NOT Playing #1')
                    else:
                        __log('Player is Playing #1')
                    x = 0
                    while not xbmc.Player().isPlaying() and x <= 100:
                        xbmc.sleep(1000)
                        x += 1
                        __log('Player is NOT playing - try again #%r' % x)
                        xbmc.Player().play(url, item, True)
                break   ### Stop at first match
    except Exception,e:
        pass
        __log('PlayEPG ERROR: %r' % e)
    
try:
    program    = sys.argv[0]
    PATH       = sys.argv[1]
    station_id = sys.argv[2]
    
except Exception,e:
    pass
    title = 'StartStation'
    PATH = repr(e)
    station_id = 'P4KBH'
    
try:
    __log('sys.argv= %r' % sys.argv)
    __log('os.environ= %s' % os.environ['OS'] ) #put in LOG
    __log('PATH= %r' % PATH)
    __log('ADDONpath= %r' % ADDONpath)
    __log('LOGO_PATH= %r' % LOGO_PATH)
    __log('ICON= %r' % ICON)
    __log('FANART= %r' % FANART)

except Exception,e:
    pass
    __log('ERROR data: %r' % e)
try:
    __log('code part')
    playEPG(station_id)
    utils.logdev('window','StartStation module= %r, CurrentWindowIdWindowId= %r' % (module, xbmcgui.getCurrentWindowId()))
    xbmc.executebuiltin("Container.Refresh")
    
except Exception,e:
    pass
    __log('ERROR: %r' % e)