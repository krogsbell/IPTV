#!/usr/bin/python
# -*- coding: utf-8 -*-
import utils
import xbmcaddon, xbmc
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import os

ADDON     = xbmcaddon.Addon()
ADDONname = ADDON.getAddonInfo('name')
ADDONid   = ADDON.getAddonInfo('id')
PATH      = 'special://home/addons/%s/' % ADDONid
ADDONpath = xbmc.translatePath(PATH)
module= 'service.py'
xbmc.log('%s in %s' % (module,ADDONname), level=xbmc.LOGNOTICE)

def __log(text):
    utils.logdev(module,text)

__log('Start')
__log('service.py in %s' % ADDONname)

utils.logdevreset()

ADDON.setSetting('LastFindStation','')


__log('Ended')

def TS(timestr):
    ### time format 2019-05-21T22:05:00Z
    time_tuple = time.strptime(timestr, "%Y-%m-%dT%H:%M:%SZ")
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
   
def nowTS():   ### UTC time
    dt_obj= datetime.utcnow()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def nowS(format):   ### Now date string UTC time
    time_tuple = time.localtime(nowTS())
    date_str = time.strftime(format, time_tuple)
    return(date_str)
    
def datestr(timestamp,format):   ### Now date string UTC time %Y-%m-%dT%H:%M:%SZ
    time_tuple = time.localtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)

def findprograms(delayHMS):
    findP = ADDON.getSetting('LastFindStation')  ### datestr(nowTS(),'h%Hm%Ms%S'))
    if findP == '':
        delta = 800
    else:
        delta = nowTS() - TS(findP)
    __log('delta= %r' % delta)
    if delta > 700:
        __log('Start findprograms:'+datestr(nowTS(),'d%dh%Hm%Ms%S'))
        ADDON.setSetting('findprograms','Start findprograms:'+datestr(nowTS(),'d%dh%Hm%Ms%S'))
        script = os.path.join(ADDONpath, 'findstation.py')
        __log('script= %r' % script)
        nameAlarm = ADDONid + '-findstations-'+delayHMS.replace(':','')
        __log('nameAlarm= %r' % nameAlarm)
        ###delayHMS = '00:10:00'   ### Run every 10 minutes
        ###delayHMS = '00:00:00'   ### Run once
        __log('delayHMS= %r' % delayHMS)
        ###cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),%s,loop,silent)' % (nameAlarm, script, PATH,delayHMS,delayHMS)
        if delayHMS == '00:00:00':
            cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),%s,silent)' % (nameAlarm, script, PATH,delayHMS,delayHMS)
        else:
            cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),%s,loop,silent)' % (nameAlarm, script, PATH,delayHMS,delayHMS)
        __log('cmd= %s' % cmd)
        xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
        xbmc.executebuiltin(cmd)  # Activate
        
if ADDON.getSetting('autorun').lower() == 'true':
    findprograms('00:00:00')
    findprograms('00:10:00')


"""
if __name__ == '__main__':
    monitor = xbmc.Monitor()
    
    while not monitor.abortRequested():
        findprograms()
        ADDON.setSetting('now','Now in UTC: %s' % nowS("%Y-%m-%dT%H:%M:%SZ"))
        # Sleep/wait for abort for 5 minute(s)
        if monitor.waitForAbort(5*60):
            # Abort was requested while waiting. We should exit
            break
        ###xbmc.log("hello addon! %s" % time.time(), level=xbmc.LOGNOTICE)
        ###utils.logdev(module,"hello %s! %r" % (ADDONname,time.time()))
        
"""       