#!/usr/bin/python
# -*- coding: utf-8 -*-
#print "findtvguidenotifications.py"
import xbmc,utils,locking,os
import definition
ADDON      = definition.getADDON()

program  = sys.argv[0]
guide    = sys.argv[1]
extrapar = sys.argv[2]
modul    = 'TrigTVGuide'

utils.logdev(modul,repr(sys.argv))

if locking.isAnyRecordLocked():
	utils.logdev(modul, 'Recording - No Trigger TV Guide= %s' % (guide))
else:
	try:
		utils.logdev(modul, 'Trigger TV Guide= %s' % (guide))
		###utils.notification(modul + " stop " + guide)
		###xbmc.executebuiltin("StopScript(" + guide + ")")  ### Stop Guide - will crash Kodi!!!
		###xbmc.sleep(5000)
		utils.notification(modul + " START " + guide)
		xbmc.executebuiltin("RunAddon(" + guide + ")")    ### Start Guide
		### Stop Guide after 10 min
		#scriptTrig   = os.path.join(ADDON.getAddonInfo('path'), 'StopTVGuide.py')
		#cmdStop = 'AlarmClock(%s,RunScript(%s,%s,%s),00:10:00,silent)' % ('StopTVGuide'+guide, scriptTrig, guide,'ExtraParameter')
		#xbmc.executebuiltin(cmdStop)
	except Exception as  e:
		pass
		utils.logdev(modul, 'Trigger TV Guide failed! Guide= %s ERROR= %s' % (guide,repr(e)))
