#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import definition
ADDON      = definition.getADDON()
module     = 'findrecursive.py'
import urllib,sys,re,os
import datetime
import time
import utils
import net
from hashlib import md5  
import json
import glob
import recordings
import locking
from operator import itemgetter

utils.logdev(module,'Start')
def deleteFile(file):
    tries    = 0
    maxTries = 10
    while os.path.exists(file) and tries < maxTries:
        try:
            os.remove(file)
            break
        except:
            xbmc.sleep(50)
            tries = tries + 1

def RecursiveRecordingsPlanned(SearchAllFavorites):
	global AccessError
	AccessError = []
	# SearchRecursiveIn 0= Only Selected Channel, 1= Favorite Channels and 2= All My Channels
	cat = ADDON.getSetting('SearchRecursiveIn')
	if locking.isAnyRecordLocked():
		locking.scanUnlockAll()
		return
	elif  locking.isAnyScanLocked():
		return
	else:
		locking.scanLock(SearchAllFavorites)
	if not locking.isScanLocked(SearchAllFavorites):
		return
	ADDON.setSetting('RecursiveSearch','true')
	if int(cat)>0 or ((not SearchAllFavorites == 'NotAllFavorites')and(not SearchAllFavorites == 'Once')and(not SearchAllFavorites == 'Hour')):
		# find all channels i favorite view
		# cat = '-1' # DUMMY -1 Favorites, -2 My Channels
		############################################################
		
		#Sort channels by name!
		channels = sorted(channels, key=itemgetter('name'))
		uniques=[]
		for field in channels:
			name         =  field['name'].encode("utf-8")
			channel      =  field['id']
			if channel not in uniques:
				uniques.append(channel)
	conn = recordings.getConnection()
	c = conn.cursor()
	c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc")
	recordingsE = c.fetchall()
	
	# Put recursive recordings changed last - first
	recordingsC = sorted(recordingsE, key=itemgetter(2), reverse=True)
	#print "findrecursive.py10"
	for index in range(0, len(recordingsC)):
		if locking.isAnyRecordLocked():
			locking.scanUnlockAll()
			ADDON.setSetting('RecursiveSearch','false')
			return
		if not locking.isScanLocked(SearchAllFavorites):
			ADDON.setSetting('RecursiveSearch','false')
			return
		if isinstance(recordings.parseDate(recordingsC[index][2]), datetime.date) and isinstance(recordings.parseDate(recordingsC[index][3]), datetime.date) and 'Recursive:' in recordingsC[index][1]:
			if int(ADDON.getSetting('SearchRecursiveIn')) > 0 or ((not SearchAllFavorites == 'NotAllFavorites')and(not SearchAllFavorites == 'Once')and(not SearchAllFavorites == 'Hour')):
				if not recordingsC[index][0] in uniques:
					findrecursiveinplaychannel(recordingsC[index][0],recordingsC[index][1],index) # Allways search channel in record
					if ADDON.getSetting('NotifyOnSearch')=='true' and not '[COLOR orange]' in recordingsC[index][1]:
						utils.notification('Find%s [COLOR green]complete in own channel[/COLOR]' % recordingsC[index][1])
				for cat in uniques:
					findrecursiveinplaychannel(cat,recordingsC[index][1],index)
				if ADDON.getSetting('NotifyOnSearch')=='true' and not '[COLOR orange]' in recordingsC[index][1]:
					utils.notification('Find%s [COLOR green]complete[/COLOR]' % recordingsC[index][1])
			else:
				findrecursiveinplaychannel(recordingsC[index][0],recordingsC[index][1],index)
				if ADDON.getSetting('NotifyOnSearch')=='true' and not '[COLOR orange]' in recordingsC[index][1]:
					utils.notification('Find%s [COLOR green]complete[/COLOR] in selected channel: %s' % (recordingsC[index][1], recordingsC[index][0]))
	try:
		conn.commit()
	except:
		pass
	c.close()
	if ADDON.getSetting('NotifyOnSearch')=='true':
		utils.notification('Find all recursives [COLOR green]complete[/COLOR]')
	locking.scanUnlockAll()
	ADDON.setSetting('RecursiveSearch','false')
	return

def findrecursiveinplaychannel(cat,title,index):
	global AccessError
	if locking.isAnyRecordLocked():
		locking.scanUnlockAll()
		return
	if '[COLOR orange]' in title:
		return
	if not cat in AccessError:
		try:
			rtmp     = data['src']
		except:
			pass
			AccessError.append(cat)
		if not cat in AccessError:
			name = title
			try:
				name = name.split('Recursive:')[1]
			except:
				pass
			newname = recordings.latin1_to_ascii(name)
			newname = newname.strip()
			############################
			guide=data['guide']
			nowT= recordings.parseDate(datetime.datetime.today())
			for field in guide:
				r=re.compile("(.+?)-(.+?)-(.+?) (.+?):(.+?):(.+?)")
				startTime= field['time']
				endTime= field['time_to']
				name= field['name'].encode("utf-8")
				recordname= field['name'].encode("utf-8")
				description= field['description'].encode("utf-8")
				match = r.search(startTime)
				matchend = r.search(endTime)
				year = match.group(1)
				month = match.group(2)
				day = match.group(3)
				hour = match.group(4)
				minute = match.group(5)
				endyear = matchend.group(1)
				endmonth = matchend.group(2)
				endday = matchend.group(3)
				endhour = matchend.group(4)
				endminute = matchend.group(5)
				startDate= datetime.datetime(int(year),int(month),int(day),int(hour),int(minute)) + datetime.timedelta(seconds = offset)
				endDate= datetime.datetime(int(endyear),int(endmonth),int(endday),int(endhour),int(endminute)) + datetime.timedelta(seconds = offset)
				time='[COLOR yellow](%s) - [/COLOR]'%(startDate.strftime('%H:%M'))
				recordnameT = recordings.latin1_to_ascii(recordname)
				startDateT = recordings.parseDate(startDate)
				
				if (newname.upper() in recordnameT.upper()) and (nowT < startDateT):
					recordings.schedule(cat, startDate, endDate, recordname, description)

