#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmc, xbmcvfs
import xbmcaddon
import xbmcgui
import xbmcplugin
import os
import sys
import time
import shutil
import datetime
import time
import signal
import base64
#import locking     #Use locking to write test messages as filenames
###import recordings
from subprocess import Popen, PIPE, STDOUT
import re
# For Python 3.0 and later
from urllib.request import urlopen
import urllib.request
import glob
import io
import definition

try:
    ADDONdrnu      = xbmcaddon.Addon(id='plugin.video.drnu')
    datapathdrnu   = xbmcvfs.translatePath(ADDONdrnu.getAddonInfo('profile'))
    ADDONdrnuTest  = True
except Exception as e:
        pass
        definition.log('Exception: ADDONdrnu = False %r' % e)
        ADDONdrnuTest = False

ADDON    = definition.getADDON()
datapath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

PATH     = ADDON.getAddonInfo('path')
module   = 'utils.py'
cmodule  = module

def ADDONgetAddonInfo(info):
    file = os.path.join(datapath,'ADDON-' + info) + '.set'
    if os.path.isfile(file) == False:
        value = ADDON.getAddonInfo(info)
        LF = open(file, 'w')
        LF.write(value)
        LF.close()
    else:
        LF = open(file,'r')
        value = LF.read()
    return value

def ADDONresetSetting(setting,value):
    definition.ADDONresetSetting(setting,value)   ### 2024-06-17
    ###ADDON.setSetting(setting,value)  ### (2023-06-05 Use real settings)
    """
    file = os.path.join(datapath,'ADDONsetting-'+setting) + '.set'
    LF = open(file, 'w')
    LF.write(value)
    LF.close()
    """

def ADDONsetSetting(setting,value):
    definition.ADDONsetSetting(setting,value)      ### 2024-06-17
    """
    if value != '':
        ADDON.setSetting(setting,value)  ### (2023-05-15 Use real settings)
        
        file = os.path.join(datapath,'ADDONsetting-'+setting) + '.set'
        LF = open(file, 'w')
        LF.write(value)
        LF.close()
    """
        
def ADDONgetSetting(setting):
    value = definition.ADDONgetSetting(setting)  ### 2024-06-17
    """
    value = ADDON.getSetting(setting)  ### (2023-05-15 Use real settings)
    valueinfile = ''
    file = os.path.join(datapath,'ADDONsetting-'+setting) + '.set'
    if os.path.isfile(file) == False:
        value = ADDON.getSetting(setting)
        ADDONresetSetting(setting,value)
    else:
        LF = open(file,'r')
        valueinfile = LF.read()
    if valueinfile != '':
        value = valueinfile
        ADDONresetSetting(setting,value)
       
    if setting == 'record_path' or setting == 'record_archive_path' or setting == 'record_archiveb_path' or setting == 'sharepath' or setting == 'tvguideimport'  or setting == 'backup_path' :  ### 2023-09-06
        value = FileManagerPath(value)
    """ 
    return value

def intADDONgetSetting(setting,maxvalue=100,module=module):
    try:
        settingint = definition.ADDONgetSetting(setting)
        countmax = int(settingint.strip())
    except (ValueError, TypeError):
        countmax = maxvalue
    """
    try:
        settingint = definition.ADDONgetSetting(setting)
        if settingint != '' :
            countmax = int(settingint)
        else:
            countmax = maxvalue
    except Exception as e:
        log(module,'intADDONgetSetting setting= %r, Exception: %r' % (setting,e))
        countmax = maxvalue
        pass
    """
    if countmax < 20:
        countmax = 20
    log(module,'Exception intADDONgetSetting= %r, countmax= %r' % (setting,countmax))
    return countmax

def intADDONgetNextSetting(setting,maxvalue=100):
    try:
        countmax = int(definition.ADDONgetSetting(setting))
        log(module,'intADDONgetNextSetting0= %r' % countmax)
        countmax += 1
        log(module,'intADDONgetNextSetting1= %r' % countmax)
        if countmax > maxvalue:
            countmax = 0
        definition.ADDONsetSetting(setting,str(countmax))
        log(module,'intADDONgetNextSetting2= %r' % countmax)
    except Exception as e:
        log(module,'intADDONgetNextSetting setting= %r, Exception: %r' % (setting,e))
        countmax = maxvalue
        pass
    log(module,'intADDONgetNextSetting3= %r' % countmax)
    return countmax

ADDONid    = ADDONgetAddonInfo('id')
ADDONname  = ADDONgetAddonInfo('name')
xbmc.log('utils.py in %s' % ADDONname) ###, level=xbmc.LOGNOTICE)
referral = definition.ADDONgetSetting('my_referral_link')

progpath = ADDONgetAddonInfo('path')   
###IMAGE = os.path.join(ADDONgetAddonInfo('path'), 'icon' + referral + '.jpg')
IMAGE = os.path.join(ADDONgetAddonInfo('path'), 'icon.png')
directrecording = definition.ADDONgetSetting('enable_record_drdk_directly')
module = 'utils.py'
SHOWLENGTH = 1024
try:
    ###LOGsize = 10 * 1024 * 1024 # 10 MB
    LOGsizeT = definition.ADDONgetSetting('logmaxsize')
    if LOGsizeT != '':
        LOGsize = int(LOGsizeT) * 1024 * 1024
    else:
        LOGsize = 10 * 1024 * 1024
        definition.ADDONsetSetting('logmaxsize','10')
except Exception as e:
    pass
    LOGsize = 10 * 1024 * 1024
    definition.ADDONsetSetting('logmaxsize','10')
    
notify = definition.ADDONgetSetting('notifyduringepgupdate')
if notify == 'true':
    notifyduringepgupdate = True
else:
    notifyduringepgupdate = False

"""
    Outputs message to log file
    :param msg: message to output
    :param level: debug levelxbmc. Values:
    xbmc.LOGDEBUG = 0
    xbmc.LOGERROR = 4
    xbmc.LOGFATAL = 6
    xbmc.LOGINFO = 1
    xbmc.LOGNONE = 7
    xbmc.LOGNOTICE = 2
    xbmc.LOGSEVERE = 5
    xbmc.LOGWARNING = 3
"""
   
def logdevreset(file='',reset=False):
    ###datapath = xbmcvfs.translatePath(ADDONgetAddonInfo('profile'))
    definition.log('logdevreset(%r) reset=%r' % (file,reset),SHOWLENGTH,module)
    logfileOLD =  'addonOLD.log'
    logfile = 'addon.log'
    if 'OLD' in file:
        logfileOLD = file
        logfile = logfileOLD.replace('OLD','')
    try:
        if not os.path.exists(datapath):
            os.makedirs(datapath)
    except Exception as e:
        pass
        definition.log('%r: os.makedirs(datapath= %r) Except: %r' % (ADDONname,datapath,e),SHOWLENGTH,module)
    addonlog = os.path.join(datapath, logfile)
    addonOLDlog = os.path.join(datapath, logfileOLD)
    
    try:
        size = os.path.getsize(addonlog)
        maxsize = LOGsize
        if os.path.exists(addonlog) and (size > maxsize or reset):
 
            shutil.copyfile(addonlog, addonOLDlog)
        
            tries    = 0
            maxTries = 10
            maxSleep = 50
            while os.path.exists(addonlog) and tries < maxTries:
                try:
                    os.remove(addonlog)
                    break
                except Exception as e:
                    pass
                    definition.log('#79 Exception: %r' % e,SHOWLENGTH,module)
                    xbmc.sleep(maxSleep)
                    tries = tries + 1
    except Exception as e:
        pass
        ###log(module,'err #83 Exception: %r' % e) - DON'T log during logdevreset
        xbmc.log('%r: Reset addon.log failed: %r' % (ADDONname,e), level=xbmc.LOGERROR)
        ###definition.log('%r: Reset addon.log failed: %r' % (ADDONname,e))
 
def logm(module,message):  ### Log to KODI Log
    xbmc.log(ADDONgetAddonInfo('name') + ' ' + module +': ' + message, level=xbmc.LOGERROR)
    ###definition.log(ADDONgetAddonInfo('name') + ' ' + module +': <*' + message[0:SHOWLENGTH]+'*>')
    
def logPREVIOUS(infotext,showlength=SHOWLENGTH):
    return ### Ignore
    if 'err' in infotext.lower():
        logdev('err',module + ': ' + infotext,showlength)
    else:
        logdev(module,infotext,showlength)

def log(module,infotext,showlength=1024):
    definition.log(infotext,showlength,module)

"""
def log(module,infotext,showlength=500):
    definition.log(ADDONgetAddonInfo('name') + ' ' + module +': <*' + infotext[0:showlength]+'*>')
    return ### Ignore
    debug = definition.ADDONgetSetting('debug').lower()
    if debug in infotext[0:25].lower() and not debug == '':
        logdev(module,infotext,showlength=showlength)
    else:
        nolog = True
        definition.log(ADDONgetAddonInfo('name') + ' ' + module +': <*' + infotext[0:showlength]+'*>')
"""       
def __log(infotext):
    return ### Ignore
    logdev(module,infotext,showlength=10000)
    
"""
def log(infotext,showlength=500):
    if 'error' in infotext.lower():
        logdev('error',module + ': ' + infotext,showlength=showlength)
    elif 'err' in infotext.lower():
        nolog = True
        ###logdev(module,infotext,showlength=showlength)
    else:
        nolog = True
        ###logdev(module,infotext,showlength=showlength)
"""   

def logarray(Name,Array,nelements=1):
    return ### Ignore
    i = 0
    for rec in Array:
        try:
            if nelements==1:
                log(module,'logarray in %s= %r %r' % (Name,i,rec))
                i += 1
            else:
                records = []
                for index in range(0, nelements):
                    records.append(rec[index])
                log(module,'logarray in %s= %r %r' % (Name,i,records))
                i += 1
        except Exception as e:
            log(module,'#234 logarray Exception: %r' % e)
            pass

def logdev(module,message,showlength = SHOWLENGTH):
    return ### Ignore
    debug = definition.ADDONgetSetting('debug').lower()
    if debug in message[0:25].lower() and not debug == '':
        logIT(module + ': debug= ' + debug + ' >>> ' + message,showlength=showlength)
        return   ### 2023-12-25
    modulestoaddonlog = definition.ADDONgetSetting('modulestoaddonlog')
    if modulestoaddonlog == '':
        modulestoaddonlog = 'updateepg.py,recordings.py'
        ADDONresetSetting('modulestoaddonlog',modulestoaddonlog)
        
    if definition.ADDONgetSetting('addonlog') == '1' and not module in modulestoaddonlog:
        logm(module,message)
    else:
        logIT(module + ': ' + message,showlength=showlength)

def logIT(message,showlength = SHOWLENGTH):       
    return ### Ignore
    try:
        nowHMS=datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        ###datapath = xbmcvfs.translatePath(ADDONgetAddonInfo('profile'))
        addonlog = os.path.join(datapath, 'addon.log')
        ###logdevreset()   ### Only reset log with http-keep-alive
        LogDev = open(addonlog, 'a', encoding="utf-8")    ### 2023-06-02
        ###LogDev = io.open(addonlog, 'ab')  ### 2023-04-21 'a' to 'ab' / io.
        # Write to our text file the information we have provided and then goto next line in our file.
        # LogDev.write(repr(module) + ': ' + repr(message) + '\n')
        if len(message) > showlength:
            LogDev.write(nowHMS + ' ' + module + ': <*\n' + message[0:showlength]+'...\n...\n...'+message[-200:]+'\n*>\n')
        else:
            LogDev.write(nowHMS + ' ' + module + ': <*\n' + message+'\n*>\n')
        LogDev.close()
    except Exception as e:
        xbmc.log(ADDONgetAddonInfo('name') + ' ' + module +': <*' + message[0:SHOWLENGTH]+'*>')
        pass

def loglist(module,programs,label):
    return ### Ignore
    for prog in programs:
        progpart = []
        for indexJ in range(0, len(prog)):
            progpart.append(prog[indexJ])
        log(module,'%s= %r' % (label,progpart))
        
def logdevarray(module,array):
    return ### Ignore
    log(module,'\n')
    try:
        if type(array) in (list, tuple, dict):
            log(module,'len(array)= %r' % len(array))
            for note in array:
                if type(note) in (list, tuple, dict):
                    i = 0
                    for n in note:
                        log(module,'array[%d]= %r' % (i,note))
                        i += 1
                else:
                    log(module,'array[x]= %r - %r' % (note, array[note]))
            log(module,'\n')
        else:
            log(module,'array= %r' % array)
    except Exception as e:
        log(module,'err #164 Exception: %r' % e)
        pass
        log(module,'err in logdevarray: ' + repr(e))

def logcontain(module,name,logsearch):
    return ### Ignore
    try:
        data = readFile(name)
        log(module,'logcontain Data= %r' % data,showlength=1000)
        if return_utf(logsearch) in data:
            log(module,'logcontain return True') 
            return True
        else: 
            log(module,'logcontain return False') 
            return False
    except Exception as e:
        pass
        log(module,'logcontain Error %r' % e)
        return False

def fileage(filename):
    try:
        today = datetime.datetime.today()
        file_mod_time = datetime.datetime.fromtimestamp(os.path.getmtime(filename))
        age = today - file_mod_time
        definition.log('fileage of file= %r, age.days %r' % (filename,age.days))
        return age
        ###if age.days > 90:
        ###    print "File older than 90 days"
        ###else:
        ###    print "File not older than 90 days"
    except Exception as e:
        pass
        definition.log('fileage of file= %r, Exception %r' % (filename,e))
        return today - today
            
def krogsbellWatchingVideo():
    try:
        SwFileFolder = os.path.join(xbmcvfs.translatePath('special://masterprofile/'), 'addon_data','krogsbell.switchaddons')
        SwFile = os.path.join(SwFileFolder,'watchingvideo.txt')
        if not os.path.exists(SwFileFolder):
            os.mkdir(SwFileFolder)
            open(SwFile, 'a').close()
        __log('SwFile= %r' % SwFile)
        LF = open(SwFile, 'w')
        LF.write(ADDONname)
        LF.close()
    except Exception as e:
        pass
        __log('krogsbellNOTWatchingVideo Error %r' % e)
    return  
    
def krogsbellNOTWatchingVideo():
    try:
        SwFileFolder = os.path.join(xbmcvfs.translatePath('special://masterprofile/'), 'addon_data','krogsbell.switchaddons')
        SwFile = os.path.join(SwFileFolder,'watchingvideo.txt')
        if not os.path.exists(SwFileFolder):
            os.mkdir(SwFileFolder)
            open(SwFile, 'a').close()
        __log('SwFile= %r' % SwFile)
        LF = open(SwFile, 'w')
        LF.write('')
        LF.close()
    except Exception as e:
        pass
        __log('krogsbellNOTWatchingVideo Error %r' % e)
    return  

def dialogShow(text,timeout = 10000):
    dialog = xbmcgui.Dialog()
    dialog.yesno('[B]' + ADDONname + '[/B] Show result',text, autoclose=timeout)

def writeDataFile(name,data):
    try:
        file = os.path.join(datapath,'Data-'+name) + '.txt'
        LF = open(file, 'wb')
        LF.write(b'%r' % data)
        LF.close()
    except Exception as e:
        log(module,'err #259 Exception: %r' % e)
        pass
 
def readDataFile(name) :
    try:
        file = os.path.join(datapath,'Data-'+name) + '.txt'
        ###LF = open(file, 'rb')
        LF = io.open(file, 'r', encoding = 'utf-8')
        data = LF.read()
        LF.close()
        return data
    except Exception as e:
        log(module,'err #266 Exception: %r' % e)
        pass
        return []

def readFile(file) :
    try:
        ###LF = open(file, 'rb')
        LF = io.open(file, 'r', encoding = 'utf-8')
        data = LF.read()
        LF.close()
        return data
    except Exception as e:
        log(module,'err #339 Exception: %r' % e)
        pass
        return []

def shareFile(datafile):
    log(module,'shareFile datafile= %r' % datafile)
    sharepath = definition.ADDONgetSetting('sharepath')
    dest = 'DestinationNotSetYet'
    destf = 'not set'
    try:
        if sharepath != '':
            SystemFriendlyName = str(xbmc.getInfoLabel('System.FriendlyName')).replace('[','').replace(']','')
            destname = (SystemFriendlyName+'-'+ADDONname).replace(' ','')
            dest = os.path.join(sharepath,destname)
            log(module,'shareFile to= %r' % dest)
            logfiles = [datafile]
            for file in logfiles :
                log(module,'shareFile file= %r' % file)
                dfile = destname+'-'+file.replace('/','¤').replace('\\','¤').replace(':','¤')
                destf = os.path.join(sharepath,dfile)
                log(module,'shareFile destf= %r' % destf)
                sourf = file
                log(module,'shareFile from= %r' % sourf)
                if os.path.exists(sourf):
                    copyOK = xbmcvfs.copy(sourf, destf)
                    if not copyOK:
                        log(module,'shareFile copy failed - ERR: %r' %  copyOK)
                log(module,'shareFile from= %r' % sourf)
                log(module,'shareFile to= %r' % destf)
    except Exception as  e:
        pass 
        log(module,'Copy shareFile to sharepath= %r Exception: %r' % (dest, e))
    return destf

def makearchiveLOCAL(archive_name,zip,root_dir, base_dir):
    try:
        log(module,'Exception makearchive(archive_name= %r,zipe= %r,root_dire= %r, base_dire= %r)' % (archive_name,zip,root_dir, base_dir))
        ADDONsetSetting('backupall','7')   ### Working local copy
        new = '_NeW'
        shutil.rmtree(root_dir+os.sep+ base_dir+new) 
        result = shutil.copytree(root_dir+os.sep+ base_dir,root_dir+os.sep+ base_dir+new)
        log(module,'makearchive= %r \n     Source= %r\n     result= %r' % (archive_name+'.'+zip, root_dir+os.sep+ base_dir+new, result)) 
        ADDONsetSetting('backupall','1')   ### Working
        result = shutil.make_archive(archive_name,zip, root_dir, base_dir+new)
        ADDONsetSetting('backupall','8')   ### Cleanup
        shutil.rmtree(root_dir+os.sep+ base_dir+new) 
    except Exception as  e:
        pass 
        log(module,'makearchive= %r \n     Source= %r\n     Exception: %r' % (archive_name+'.'+zip, root_dir+os.sep+ base_dir,  e)) 
        result = 'Except: %r'% e        
    return result

def RemoveTree(tree):
    try:
        shutil.rmtree(tree) 
        log(module,'  makearchive(RemoveTree= %r)' % tree)
    except Exception as  e:
        pass 
        log(module,'Exception makearchive(RemoveTree= %r Exception: %r)' % (tree,e))
 
def backupalldis(archive_name,number):
    log(module,'  backupalldis(archive_name= %r number=: %r)' % (archive_name,number))
    if 'kodifolder' in archive_name:
        definition.ADDONsetSetting('backupall',number)
 
def makearchive(archive_name,zip,root_dir, base_dir):
    try:
        new = '_NeW'
        archive_name = archive_name.rstrip('/\\')
        root_dir = root_dir.rstrip('/\\')+os.sep
        base_dir = base_dir.rstrip('/\\')+os.sep
        base_dir_new = base_dir.rstrip('/\\')+new+os.sep
        log(module,'515 makearchive(archive_name= %r,zip= %r,root_dir= %r, base_dire= %r)' % (archive_name,zip,root_dir, base_dir))
        backupalldis(archive_name,'7')   ### Working lan copy
        log(module,'518 makearchive RemoveTree(archive_name+os.sep+ base_dir_new)= %r)' % (archive_name+os.sep+ base_dir_new))
        RemoveTree(archive_name+os.sep+ base_dir_new) 
        log(module,'518 makearchive before copytree(archive_name+os.sep+ base_dir_new)= %r)' % (archive_name+os.sep+ base_dir_new))
        result = shutil.copytree(root_dir+os.sep+ base_dir,archive_name+os.sep+ base_dir_new)
        log(module,'  makearchive= %r \n     Source= %r\n     result= %r' % (archive_name+'.'+zip, root_dir+os.sep+ base_dir.rstrip('/\\')+new, result)) 
        backupalldis(archive_name,'1')   ### Working
        result = shutil.make_archive(archive_name,zip, archive_name, base_dir_new)
        backupalldis(archive_name,'8')   ### Cleanup
        ###RemoveTree(archive_name+os.sep+ base_dir_new) ### Remove ### when testing finished 2026-11-20
    except Exception as  e:
        pass 
        log(module,'makearchive= %r \n     Source= %r\n     Exception: %r' % (archive_name+'.'+zip, root_dir+os.sep+ base_dir,  e)) 
        result = 'Exception: %r'% e        
    return result
  
  
def shareLogs():
    sharelog = definition.ADDONgetSetting('sharelog')
    if sharelog == 'true':
        log(module,'shareLogs is Running')
        return
    else:
        definition.ADDONsetSetting('sharelog','true')
    sharepath = definition.ADDONgetSetting('sharepath')
    log(module,'shareLogs sharepath= %r' % sharepath)
    dest = 'DestinationNotSetYet'
    SystemFriendlyName = str(xbmc.getInfoLabel('System.FriendlyName')).replace('[','').replace(']','')
    try:
        if sharepath != '':
            destname = (SystemFriendlyName+'-'+ADDONname).replace(' ','')
            dest = os.path.join(sharepath,destname)
            log(module,'shareLogs 547 logs to= %r' % dest)
            logfiles = ['kodi.log','kodi.old.log']
            for file in logfiles :
                dfile = destname+'-'+file
                destf = os.path.join(sharepath,dfile)
                sourf = xbmcvfs.translatePath(os.path.join('special://logpath', file))
                log(module,'shareLogs 553 kodi.log from= %r' % sourf)
                if os.path.exists(sourf):
                    copyOK = xbmcvfs.copy(sourf, destf)
                    if not copyOK:
                        log(module,'shareLogs Copy of kodi.log failed - ERR: %r' %  copyOK)
                log(module,'shareLogs 558 kodi.log from= %r' % sourf)
                log(module,'shareLogs 559 kodi.log to= %r' % destf)
            
            file = destname+'-addon.xml'
            destf = os.path.join(sharepath,file)
            log(module,'shareLogs 563 addon.xml to= %r' % destf)
            sourf = xbmcvfs.translatePath(os.path.join(PATH, 'addon.xml'))
            log(module,'shareLogs 565 addon.xml from= %r' % destf)
            if os.path.exists(sourf):
                copyOK = xbmcvfs.copy(sourf, destf)
                
                if not copyOK:
                    log(module,'shareLogs Copy of addon.xml failed')
                
            log(module,'shareLogs 572 addon.xml from= %r' % sourf)
            log(module,'shareLogs 573 addon.xml to= %r' % destf)
            
            ###kodiuserfiles = ['sources.xml','passwords.xml','mediasources.xml','upnpserver.xml']
            kodiuserfiles = definition.kodiuserfiles()
            log(module,'shareLogs 577 kodiuserfiles: %r' % kodiuserfiles)
            for file in kodiuserfiles :
                log(module,'shareLogs 579 kodiuserfiles: %r' % file)
                dfile = destname+'-'+file.replace('/','-')
                destf = os.path.join(sharepath,dfile)
                log(module,'shareLogs 582 destf= %r' % destf)
                sourf = xbmcvfs.translatePath(os.path.join('special://masterprofile', file))
                log(module,'shareLogs 584 sourf= %r' % sourf)
                if os.path.exists(sourf):
                    log(module,'shareLogs 586 sourf exists= %r' % sourf)
                    copyOK = xbmcvfs.copy(sourf, destf)
                    if not copyOK:
                        log(module,'shareLogs 589 Copy of %r failed - ERR: %r' %  (file,copyOK))
            
            ###datafiles = ['scanLockEPG_update.txt','addon.log','addonOLD.log','definition.log','definitionOLD.log','settings.xml','master.xml','epg//favoritesEPG.xml','extraxmltvfile.m3u','recordings_adc.db','categories.db',ADDONid+'EPG.xml','files.db'] 
            datafiles = definition.getdatafiles()
            
            SETTINGSONLYINFILE = definition.getSETTINGSONLYINFILE()
            SETTINGSINFILE = definition.getSETTINGSINFILE()
            SETTINGINFILEMANAGER = definition.getSETTINGINFILEMANAGER()
            for setting in SETTINGSONLYINFILE :
                datafiles.append('ADDONsetting-'+setting + '.fix')
            log(module,'shareLogs 599 datafiles: %r' % datafiles)
            for setting in SETTINGSINFILE :
                datafiles.append('ADDONsetting-'+setting + '.set')
            log(module,'shareLogs 602 datafiles: %r' % datafiles)
            for setting in SETTINGINFILEMANAGER :
                datafiles.append('ADDONsetting-'+setting + '.set')
            
            addonfolder = datapath.replace(ADDONid,'')
            definition.log('shareLogs 607 addonfolder= %r' % addonfolder)
            dfile = destname+'-datafolder'
            if ADDONgetSetting('backuptemponlan') == 'false' :
                archive_name = os.path.expanduser(os.path.join('~', (dfile+'.zip').replace(os.sep+'.zip','').replace('.zip','')))
            else:
                archive_name = os.path.join(xbmcvfs.translatePath(definition.FileManagerPath('logs')), (dfile+'.zip').replace(os.sep+'.zip','').replace('.zip',''))
            definition.log('shareLogs 613 archive_name= %r' % archive_name)
            definition.log('shareLogs 614 addonfolder= %r' % addonfolder)
            definition.log('shareLogs 615 ADDONid= %r' % ADDONid)
            ###result = shutil.make_archive(archive_name,'zip', root_dir=addonfolder,base_dir=ADDONid)
            result = makearchive(archive_name,'zip',addonfolder,ADDONid+os.sep)
            definition.log('shareLogs 618 shutil.make_archive(archive_name= %r, result= %r' %(archive_name,result))
            
            if result:
                definition.log('shareLogs 621 copy archive_name= %r' % (result))
                dfile = os.path.basename(result)
                destf = os.path.join(sharepath,dfile)
                sourf = xbmcvfs.translatePath(result)
                log(module,'shareLogs 625 sourf= %r' % sourf)
                if os.path.exists(sourf):
                    log(module,'shareLogs 627 sourf exists= %r' % sourf)
                    copyOK = xbmcvfs.copy(sourf, destf)
                    if not copyOK:
                        log(module,'shareLogs 630 Copy of %r failed - ERR: %r' %  (sourf,copyOK))
                    xbmcvfs.delete(sourf)
                  
            ### Backup of this program program folder
            addonfolder = xbmcvfs.translatePath('special://home/addons')
            definition.log('shareLogs 635 addonfolder= %r' % addonfolder)
            dfile = destname+'-codefolder'
            if ADDONgetSetting('backuptemponlan') == 'false' :
                archive_name = os.path.expanduser(os.path.join('~', (dfile+'.zip').replace(os.sep+'.zip','').replace('.zip','')))
            else:
                archive_name = os.path.join(xbmcvfs.translatePath(definition.FileManagerPath('logs')), (dfile+'.zip').replace(os.sep+'.zip','').replace('.zip',''))
            definition.log('shareLogs 641 archive_name= %r' % archive_name)
            definition.log('shareLogs 642 addonfolder= %r' % addonfolder)
            definition.log('shareLogs 643 ADDONid= %r' % ADDONid)
            ### result = shutil.make_archive(archive_name,'zip', root_dir=addonfolder,base_dir=ADDONid)
            result = makearchive(archive_name,'zip',addonfolder,ADDONid+os.sep)
            definition.log('shareLogs 646 shutil.make_archive(archive_name= %r, result= %r' %(archive_name,result))
            if result:
                definition.log('  copy archive_name= %r' % (result))
                dfile = os.path.basename(result)
                destf = os.path.join(sharepath,dfile)
                sourf = xbmcvfs.translatePath(result)
                log(module,'shareLogs 652 sourf= %r' % sourf)
                if os.path.exists(sourf):
                    log(module,'shareLogs 654 sourf exists= %r' % sourf)
                    copyOK = xbmcvfs.copy(sourf, destf)
                    if not copyOK:
                        log(module,'shareLogs 657 Copy of %r failed - ERR: %r' %  (sourf,copyOK))
                    xbmcvfs.delete(sourf)
            
            """
            log(module,'  1 ADDONgetSetting(backupall)= %r' % ADDONgetSetting('backupall') )   
            log(module,'  1,5 ADDONgetSetting(backupall)= %r' %  definition.ADDONgetSetting('startbackup') )   
            if definition.ADDONgetSetting('startbackup') == 'true' :   ### Start     
                    definition.ADDONsetSetting('startbackup','false')
                    backupalldis('kodifolder','0')
                    log(module,'  1,5 ADDONgetSetting(backupall)= %r' % ADDONgetSetting('backupall') ) 
            log(module,'  2 ADDONgetSetting(backupall)= %r' % ADDONgetSetting('backupall') ) 
            if definition.ADDONgetSetting('backupall') == '0' :   ### Start
                backupalldis('kodifolder','1')   ### Working
                log(module,'  3 ADDONgetSetting(backupall)= %r' % ADDONgetSetting('backupall') ) 
                log(module,'  Backup of this machines Kodi folder Program and Data')
                ### Backup of this machines Kodi folder Program and Data  

                try:
                    SystemFriendlyName = str(xbmc.getInfoLabel('System.FriendlyName')).replace('[','').replace(']','')
                    destname = (SystemFriendlyName+'-'+ADDONname).replace(' ','')
                    addonfolder = os.path.normpath(xbmcvfs.translatePath('special://home/'))
                    definition.log('  1 addonfolder= %r' % addonfolder)
                    dfile = destname+'-kodifolder'
                    if ADDONgetSetting('backuptemponlan') == 'false' :
                        archive_name = os.path.expanduser(os.path.join('~', (dfile+'.zip').replace(os.sep+'.zip','').replace('.zip','')))   ### In data area
                    else:
                        archive_name = os.path.join(xbmcvfs.translatePath(definition.FileManagerPath('logs')),(dfile+'.zip').replace(os.sep+'.zip','').replace('.zip',''))   ### in logs folder
                    definition.log('  archive_name= %r' % archive_name)
                    ###addonfolder = addonfolder.replace(os.sep,'',-1)
                    ###home_path = os.path.normpath(xbmcvfs.translatePath('special://home/')
                    definition.log('  2 addonfolder= %r' % addonfolder)
                    definition.log('  2 ADDONid= %r' % ADDONid)
                    base_dir = os.path.basename(addonfolder) # f may be a directory or a file 
                    definition.log('  base_dir= %r' % base_dir)
                    ###addonfolder = addonfolder.replace(base_dir,'',-1)
                    if addonfolder.endswith(os.sep+base_dir):
                        addonfolder = addonfolder[:-len(os.sep+base_dir)]
                    definition.log('  3 addonfolder= %r' % addonfolder)
                    definition.log('  archive_name= %r' % archive_name)
                    definition.log('  FolderToZip= %r' % os.path.join(addonfolder, base_dir))
                    
                    definition.log('  Symlink test Start')
                    for root, dirs, files in os.walk(os.path.join(addonfolder, base_dir)):
                        for f in files:
                            p = os.path.join(root, f)
                            if os.path.islink(p):
                                definition.log("  Symlink: %r" % p)
                    definition.log('Exception Symlink test Finished')            
                    ###result = shutil.make_archive(archive_name,'zip', root_dir=addonfolder,base_dir=base_dir)
                    result = makearchive(archive_name,'zip',addonfolder,base_dir+os.sep)
                    definition.log('Exception shutil.make_archive(archive_name= %r, result= %r' %(archive_name+'.zip',result))
                    
                    definition.log('Exception zipfile test Start')
                    import zipfile
                    definition.log('  zipfile test 1')
                    with zipfile.ZipFile(result) as z:
                        zipfiles = set(z.namelist())
                    definition.log('  zipfile test 2')
                    backupalldis(archive_name,'5')    ### Testing
                    j = 0
                    definition.ADDONresetSetting('backupallerrors',str(j))
                    for root, dirs, files in os.walk(os.path.join(addonfolder, base_dir)):
                        for f in files:
                            definition.log('  zipfile test 3 f=%r' % f)
                            rel = os.path.relpath(os.path.join(root, f), addonfolder)
                            definition.log('  zipfile test 4')
                            if rel not in zipfiles:
                                j += 1
                                definition.ADDONresetSetting('backupallerrors',str(j))
                                definition.log('  Mangler i zip: %r' % rel)
                    definition.log('  zipfile test Finished j= %r' % j)         
                    
                    if j != 0:
                        notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] Backup Function failed: %r %r' % (j, result))
                        backupalldis(archive_name,'3')    ### Ended in Error
                    else:
                        notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] Backup Function Finished') 
                        backupalldis(archive_name,'2')    ### Ended
                except Exception as e:
                    pass
                    backupalldis(archive_name,'4')    ### Error
                    __log('Test 4499 Exception: ' + repr(e))
                    notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] Backup Function failed: %r' % e)
                ################################
                SystemFriendlyName = str(xbmc.getInfoLabel('System.FriendlyName')).replace('[','').replace(']','')
                destname = (SystemFriendlyName+'-'+ADDONname).replace(' ','')
                addonfolder = os.path.normpath(xbmcvfs.translatePath('special://home/'))
                definition.log('Exception 1 addonfolder= %r' % addonfolder)
                dfile = destname+'-kodifolder'
                archive_name = os.path.expanduser(os.path.join('~', (dfile+'.zip').replace(os.sep+'.zip','').replace('.zip','')))
                definition.log('Exception archive_name= %r' % archive_name)
                ###addonfolder = addonfolder.replace(os.sep,'',-1)
                ###home_path = os.path.normpath(xbmcvfs.translatePath('special://home/')
                definition.log('Exception 2 addonfolder= %r' % addonfolder)
                definition.log('Exception ADDONid= %r' % ADDONid)
                base_dir = os.path.basename(addonfolder) # f may be a directory or a file 
                definition.log('Exception base_dir= %r' % base_dir)
                ###addonfolder = addonfolder.replace(base_dir,'',-1)
                if addonfolder.endswith(os.sep+base_dir):
                    addonfolder = addonfolder[:-len(os.sep+base_dir)]
                definition.log('Exception 3 addonfolder= %r' % addonfolder)
                definition.log('Exception archive_name= %r' % archive_name)
                
                result = shutil.make_archive(archive_name,'zip', root_dir=addonfolder,base_dir=base_dir)
                definition.log('Exception shutil.make_archive(archive_name= %r, result= %r' %(archive_name,result))
                if result:
                    definition.log('Exception copy archive_name= %r' % (result))
                    dfile = os.path.basename(result)
                    destf = os.path.join(sharepath,dfile)
                    sourf = xbmcvfs.translatePath(result)
                    log(module,'Exception sourf= %r' % sourf)
                    if os.path.exists(sourf):
                        log(module,'Exception sourf exists= %r' % sourf)
                        copyOK = xbmcvfs.copy(sourf, destf)
                        if not copyOK:
                            log(module,'Exception Copy of %r failed - ERR: %r' %  (sourf,copyOK))
                        xbmcvfs.delete(sourf)
                """             
            log(module,'shareLogs 775 datafiles: %r' % datafiles)
            for file in datafiles :
                log(module,'shareLogs 777 datafiles: %r' % file)
                dfile = destname+'-'+file.replace('//','-').replace('..','').replace('/','-')   ### 2026-10-17
                destf = os.path.join(sharepath,dfile)
                log(module,'shareLogs 780 destf= %r' % destf)
                if '..' in file:
                    file = file.replace('../plugin.video.drnu/','')
                    log(module,'shareLogs 783 drnu file= %r' % file)
                    if ADDONdrnuTest :
                        sourf = xbmcvfs.translatePath(os.path.join(datapathdrnu, file))
                    else:
                        sourf = 'No such file'
                else:
                    sourf = xbmcvfs.translatePath(os.path.join(datapath, file))
                log(module,'shareLogs 790 sourf= %r' % sourf)
                if os.path.exists(sourf):
                    log(module,'shareLogs 792 sourf exists= %r' % sourf)
                    copyOK = xbmcvfs.copy(sourf, destf)
                    if not copyOK:
                        log(module,'shareLogs 795 Copy of %r failed - ERR: %r' %  (file,copyOK))
     
            ###file = destname+'-settings.cng'
            file = destname+'-settingsCNG.xml'   ### 2024-01-17
            cngf = os.path.join(sharepath,file)
            log(module,'shareLogs 800 cngf= %r' %  cngf)
            localcngf = xbmcvfs.translatePath(os.path.join(datapath, 'settings.cng'))
            log(module,'shareLogs 802 localcngf= %r' %  localcngf)
            ADDONresetSetting('Excution 2', 'cngf = %r' % cngf)
            try:
                if xbmcvfs.exists(cngf):
                    copyOK = xbmcvfs.copy(cngf, localcngf)
                    if not copyOK:
                        log(module,'shareLogs 808 Copy of settings.cng failed')
                    if os.path.isfile(localcngf) :
                        file = open(localcngf,'r',encoding='utf-8')
                        desc = file.read()
                        file.close()
                        ###params = desc.split('<setting id="')[1]
                        paramsx = desc.split('<setting id="')
                        for i in range(1,len(paramsx)):   ### 2024-01-17  set more than one parameter at one time
                            log(module,'shareLogs 816 localcngf= %r' %  localcngf)
                            params = desc.split('<setting id="')[i]
                            param = params.split('"')[0]
                            log(module,'shareLogs 819 param= %r' %  param)
                            values = params.split('>')[1].split('<')[0]
                            log(module,'shareLogs 821 values= %r' %  values)
                            definition.ADDONresetSetting(param,values)
                            log(module,'shareLogs 823 param= %r, values= %r' %  (param,definition.ADDONgetSetting(param)))
                        xbmcvfs.delete(cngf)
                        xbmcvfs.delete(localcngf)
            except Exception as e:
                pass
                log(module,'shareLogs 828 SettingCNG Exception: %r' % e)
                
            file = destname+'-code.zip'   ### 2024-01-18 Copy new code to datapath
            cngf = os.path.join(sharepath,file)
            localcngf = xbmcvfs.translatePath(os.path.join(datapath, 'code.zip'))
            xbmcvfs.delete(localcngf)
            log(module,'shareLogs 834 Copy of code.zip from: %r to %r' % (cngf,localcngf))
            try:
                if xbmcvfs.exists(cngf):
                    copyOK = xbmcvfs.copy(cngf, localcngf)
                    if not copyOK:
                        log(module,'shareLogs 839 Copy of code.zip failed')
                    else:
                        log(module,'shareLogs 841 Copy of code.zip succeded')
                        import zipfile
                        directory_to_extract_to = xbmcvfs.translatePath('special://home/addons/')
                        log(module,'shareLogs 844Extract code.zip to: %r' % directory_to_extract_to)
                        with zipfile.ZipFile(localcngf, 'r') as zip_ref:
                            zip_ref.extractall(directory_to_extract_to)
                        xbmcvfs.delete(localcngf)
                        xbmcvfs.delete(cngf)
            except Exception as e:
                pass
                log(module,'shareLogs 851 Exception: %r' % e)
                
            file = destname+'-data.zip'   ### 2025-07-29 Copy new data to datapath
            cngf = os.path.join(sharepath,file)
            localcngf = xbmcvfs.translatePath(os.path.join(datapath, 'data.zip'))
            xbmcvfs.delete(localcngf)
            log(module,'shareLogs 857 Copy of data.zip from: %r to %r' % (cngf,localcngf))
            try:
                if xbmcvfs.exists(cngf):
                    copyOK = xbmcvfs.copy(cngf, localcngf)
                    if not copyOK:
                        log(module,'shareLogs 862 Copy of data.zip failed')
                    else:
                        log(module,'shareLogs 864 Copy of data.zip succeded')
                        import zipfile
                        directory_to_extract_to = xbmcvfs.translatePath(datapath)
                        log(module,'shareLogs 867 Extract code.zip to: %r' % directory_to_extract_to)
                        with zipfile.ZipFile(localcngf, 'r') as zip_ref:
                            zip_ref.extractall(directory_to_extract_to)
                        xbmcvfs.delete(localcngf)
                        xbmcvfs.delete(cngf)
            except Exception as e:
                pass
                log(module,'shareLogs 874 Exception: %r' % e)
            kodifolderbackup()
    except Exception as  e:
        pass 
        log(module,'shareLogs 878 Copy shareLogs to sharepath= %r Exception: %r' % (dest, e))
    definition.ADDONsetSetting('sharelog','false')
 
def kodifolderbackup():
    log(module,'kodifolderbackup 882 ADDONgetSetting(backupall)= %r' % ADDONgetSetting('backupall') )   
    log(module,'kodifolderbackup 883 ADDONgetSetting(backupall)= %r' % definition.ADDONgetSetting('startbackup') )   
    ###if definition.ADDONgetSetting('startbackup') == 'true' :   ### Start     
    definition.ADDONsetSetting('startbackup','false')
    backupalldis('kodifolder','0')
    log(module,'kodifolderbackup 887 ADDONgetSetting(backupall)= %r' % ADDONgetSetting('backupall') ) 
    log(module,'kodifolderbackup 888 ADDONgetSetting(backupall)= %r' % ADDONgetSetting('backupall') ) 
    if definition.ADDONgetSetting('backupall') == '0' :   ### Start
        backupalldis('kodifolder','1')   ### Working
        log(module,'kodifolderbackup 891 ADDONgetSetting(backupall)= %r' % ADDONgetSetting('backupall') ) 
        log(module,'kodifolderbackup 892 Backup of this machines Kodi folder Program and Data')
        ### Backup of this machines Kodi folder Program and Data  

        try:
            SystemFriendlyName = str(xbmc.getInfoLabel('System.FriendlyName')).replace('[','').replace(']','')
            destname = (SystemFriendlyName+'-'+ADDONname).replace(' ','')
            addonfolder = os.path.normpath(xbmcvfs.translatePath('special://home/'))
            definition.log('kodifolderbackup 899 addonfolder= %r' % addonfolder)
            dfile = destname+'-kodifolder'
            if ADDONgetSetting('backuptemponlan') == 'false' :
                archive_name = os.path.expanduser(os.path.join('~', (dfile+'.zip').replace(os.sep+'.zip','').replace('.zip','')))   ### In data area
            else:
                archive_name = os.path.join(xbmcvfs.translatePath(definition.FileManagerPath('logs')),(dfile+'.zip').replace(os.sep+'.zip','').replace('.zip',''))   ### in logs folder
            definition.log('kodifolderbackup 905archive_name= %r' % archive_name)
            ###addonfolder = addonfolder.replace(os.sep,'',-1)
            ###home_path = os.path.normpath(xbmcvfs.translatePath('special://home/')
            definition.log('kodifolderbackup 908 addonfolder= %r' % addonfolder)
            definition.log('kodifolderbackup 909 ADDONid= %r' % ADDONid)
            base_dir = os.path.basename(addonfolder) # f may be a directory or a file 
            definition.log('kodifolderbackup 911 base_dir= %r' % base_dir)
            ###addonfolder = addonfolder.replace(base_dir,'',-1)
            if addonfolder.endswith(os.sep+base_dir):
                addonfolder = addonfolder[:-len(os.sep+base_dir)]
            definition.log('kodifolderbackup 915 addonfolder= %r' % addonfolder)
            definition.log('kodifolderbackup 916 archive_name= %r' % archive_name)
            definition.log('kodifolderbackup 917 FolderToZip= %r' % os.path.join(addonfolder, base_dir))
            """
            definition.log('kodifolderbackup 919 Symlink test Start')
            for root, dirs, files in os.walk(os.path.join(addonfolder, base_dir)):
                for f in files:
                    p = os.path.join(root, f)
                    if os.path.islink(p):
                        definition.log("kodifolderbackup 924 Symlink: %r" % p)
            definition.log('kodifolderbackup 925 Exception Symlink test Finished') 
            """        
            ###result = shutil.make_archive(archive_name,'zip', root_dir=addonfolder,base_dir=base_dir)
            definition.log('kodifolderbackup 927 makearchive(archive_name= %r, zip, addonfolder=%r,base_dir+os.sep= %r)' % (archive_name, addonfolder, base_dir+os.sep))
            result = makearchive(archive_name,'zip',addonfolder,base_dir+os.sep)
            definition.log('kodifolderbackup 928 shutil.make_archive(archive_name= %r, result= %r' %(archive_name+'.zip',result))
            
            definition.log('kodifolderbackup 930 Exception zipfile test Start')
            import zipfile
            definition.log('kodifolderbackup 932 zipfile test 1')
            with zipfile.ZipFile(result) as z:
                zipfiles = set(z.namelist())
            definition.log('kodifolderbackup 935 zipfile test 2')
            backupalldis(archive_name,'5')    ### Testing
            j = 0
            definition.ADDONresetSetting('backupallerrors',str(j))
            for root, dirs, files in os.walk(os.path.join(addonfolder, base_dir)):
                for f in files:
                    definition.log('kodifolderbackup 941 zipfile test 3 f=%r' % f)
                    rel = os.path.relpath(os.path.join(root, f), addonfolder)
                    definition.log('kodifolderbackup 943 zipfile test 4')
                    if rel not in zipfiles:
                        j += 1
                        definition.ADDONresetSetting('backupallerrors',str(j))
                        definition.log('kodifolderbackup 947 Mangler i zip: %r' % rel)
            definition.log('kodifolderbackup 948 zipfile test Finished j= %r' % j)         
            
            if j != 0:
                notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] Backup Function failed: %r %r' % (j, result))
                backupalldis(archive_name,'3')    ### Ended in Error
            else:
                notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] Backup Function Finished') 
                backupalldis(archive_name,'2')    ### Ended
        except Exception as e:
            pass
            backupalldis(archive_name,'4')    ### Error
            __log('kodifolderbackup 959 Exception: ' + repr(e))
            notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] Backup Function failed: %r' % e)    

def getrecordingprogram():
    try: 
        recordusing = definition.ADDONgetSetting('recordusing')
        recordingprograms = ['ffmpeg','yt-dlp']
        recordwith = recordingprograms[int(recordusing)]
        log(module,'getrecordingprogram recordwith= %r' % recordwith)
    except Exception as e:
        pass
        log(module,'getrecordingprogram Exception: %r' % e)
        recordwith = 'ffmpeg'
    return recordwith

def selectrecordingprogram():
    default = getrecordingprogram() ###'yt-dlp'  
    choices = ['ffmpeg', 'yt-dlp']
    position = choices.index(default)
    log(module,'selectrecordingprogram default= %r, position= %r' % (default, position))
    idx = xbmcgui.Dialog().select('Select Recording program:', choices, preselect= position,autoclose=5000) # 5 sekunder)
    if idx >= 0 :
        log(module,'selectrecordingprogram idx= %r' % idx)
        definition.ADDONresetSetting('recordusing',str(idx))
        recordwith = choices[idx]
        log(module,'selectrecordingprogram recordwith= %r' % recordwith)
        return recordwith
    else:
        return 'ffmpeg'
  
def bomType(file):
    """
    returns file encoding string for open() function

    EXAMPLE:
        bom = bomtype(file)
        open(file, encoding=bom, errors='ignore')
    """

    f = open(file, 'rb')
    b = f.read(5)
    f.close()

    if (b[0:3] == b'\xef\xbb\xbf'):
        return "utf8"

    # Python automatically detects endianess if utf-16 bom is present
    # write endianess generally determined by endianess of CPU
    if ((b[0:2] == b'\xfe\xff') or (b[0:2] == b'\xff\xfe')):
        return "utf16"

    if ((b[0:5] == b'\xfe\xff\x00\x00') 
              or (b[0:5] == b'\x00\x00\xff\xfe')):
        return "utf32"

    # If BOM is not provided, then assume its the codepage
    #     used by your operating system
    if definition.ADDONgetSetting('runningon').lower() == 'windows' :
        return "cp1252"  ### Windows
    else:
        return "cp850"
    ###return repr(b)
    # For the United States its: cp1252

def return_utf(s):
    if isinstance(s, str):
        return s.encode('utf-8')
    if isinstance(s, (int, float, complex)):
        return str(s).encode('utf-8')
    try:
        return s.encode('utf-8')
    except TypeError:
        try:
            return str(s).encode('utf-8')
        except AttributeError:
            return s
    except AttributeError:
        return s
    return s # assume it was already utf-8

def bomTypeText(name):
    """
    returns name encoding string for text
    NO - Just set based on operating system  2023-03-19
    
    s.encode('utf16')
    '\xff\xfea\x00b\x00c\x00d\x00'
    >>> s.encode('utf32')
    '\xff\xfe\x00\x00a\x00\x00\x00b\x00\x00\x00c\x00\x00\x00d\x00\x00\x00'
    """

    b = name
    m32  = '\xfe\xff\x00\x00'
    m32i = '\x00\x00\xff\xfe'
    m16  = '\xfe\xff'
    m16i = '\xff\xfe'
    m8   = '\xef\xbb\xbf'
    
    if m32 in b:
        return "utf32"
    if m32i in b:
        return "utf32"
    if m16 in b:
        return "utf16"    
    if m16i in b:
        return "utf16"   
    if m8 in b:
        return "utf8"   
        
    if (b[0:3] == b'\xef\xbb\xbf'):
        return "utf8"
    # Python automatically detects endianess if utf-16 bom is present
    # write endianess generally determined by endianess of CPU
    if ((b[0:2] == b'\xfe\xff') or (b[0:2] == b'\xff\xfe')):
        return "utf16"

    if ((b[0:5] == b'\xfe\xff\x00\x00') 
              or (b[0:5] == b'\x00\x00\xff\xfe')):
        return "utf32"

    # If BOM is not provided, then assume its the codepage
    #     used by your operating system
    if definition.ADDONgetSetting('runningon').lower() == 'windows' :
        return "cp1252"  ### Windows
    else:
        return "cp850"
    ###return repr(b)
    # For the United States its: cp1252
    
def utf(data):    ### 2025-06-22
        ###for j in range(0,255):
        ###    log(module,'error j= %r, chr(j)= %r, \\x%x' % (j,chr(j),j))
        ###return chr(j)  
        log(module,'error1 data= %r' % data)
        ###data = data.replace('Description:\n\\r\\n','Description:\n')
        ###data = data.replace('\n','\r\n')   
        data = data.replace('\\n',chr(10))
        data = data.replace('\n',chr(10))
        data = data.replace('\\r',chr(13))
        data = data.replace('\r',chr(13))
        log(module,'error2 data= %r' % data)
        for j in range (16,255):
            xchar = '\\x%x' % j
            if xchar in data :
                log(module,'error j= %r, chr(j)= %r, xchar= %r' % (j,chr(j),xchar))
                data = data.replace(xchar,chr(j))
        return data
        
def isUTF8(data):
    try:
        decoded = data.decode('UTF-8')
    except UnicodeDecodeError:
        pass
        return False
    """
    else:
        for ch in decoded:
            if 0xD800 <= ord(ch) <= 0xDFFF:
                return False
        return True
    """    
  
def isUTF16(data):
    try:
        decoded = data.decode('UTF-16')
    except UnicodeDecodeError:
        pass
        return False
    """
    else:
        for ch in decoded:
            if 0xD800 <= ord(ch) <= 0xDFFF:
                return False
        return True
    """
    
def isUTF32(data):
    try:
        decoded = data.decode('UTF-32')
    except UnicodeDecodeError:
        pass
        return False
    """
    else:
        for ch in decoded:
            if 0xD800 <= ord(ch) <= 0xDFFF:
                return False
        return True
    """

def isUTF(data):
    try:
        encoded = data.encode('UTF-32')
        decoded = encoded.decode('UTF-32')
        return 'UTF-32'
    except UnicodeDecodeError:
        pass
        try:
            encoded = data.encode('UTF-16')
            decoded = encoded.decode('UTF-16')
            return 'UTF-16'
        except UnicodeDecodeError:
            pass
            try:
                encoded = data.encode('UTF-8')
                decoded = encoded.decode('UTF-8')
                return 'UTF-8'
            except UnicodeDecodeError:
                pass
                return False
    """
    else:
        for ch in decoded:
            if 0xD800 <= ord(ch) <= 0xDFFF:
                return False
        return True
    """
    
def setUTF(data):
    result = isUTF(data)
    if result == False :
        return latin1_to_ascii_force(data)
    else:
        return data

def untilD8(data):    ### Limit text string to first arabic letter
    try:
        newdata = ''
        for i in range(0, len(data)-1):
            ###log(module,'535 error i= %r, data[i]= %r' % (i,data[i]))
            try:
                ###if data[i] == chr(216) and data[i+1] >= chr(128):
                if data[i] >= chr(128) and data[i+1] >= chr(128):
                    ###log(module,'539 error untilD8 Limited return data[0:i-1]= %r' % (data[0:i-1]))
                    return data[0:i-1]
            except Exception as e:
                pass
                log(module,'651 error untilD8 Exception: %r' % (e))
    except Exception as e:
        pass
        log(module,'655 error untilD8 Exception: %r' % (e))
    return data

def latin1_to_ascii_force(unitext):
    """
2020-02-02 13:43:56 default.py: l TEST i= 127, str(j)= '\x7f'=, unicrap(j)= '\x7f'
2020-02-02 13:43:56 default.py: l TEST i= 128, str(j)= '\x80'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 129, str(j)= '\x81'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 130, str(j)= '\x82'=, unicrap(j)= 'Euro'
2020-02-02 13:43:56 default.py: l TEST i= 131, str(j)= '\x83'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 132, str(j)= '\x84'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 133, str(j)= '\x85'=, unicrap(j)= 'AA'
2020-02-02 13:43:56 default.py: l TEST i= 134, str(j)= '\x86'=, unicrap(j)= 'AE'
2020-02-02 13:43:56 default.py: l TEST i= 135, str(j)= '\x87'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 136, str(j)= '\x88'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 137, str(j)= '\x89'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 138, str(j)= '\x8a'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 139, str(j)= '\x8b'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 140, str(j)= '\x8c'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 141, str(j)= '\x8d'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 142, str(j)= '\x8e'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 143, str(j)= '\x8f'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 144, str(j)= '\x90'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 145, str(j)= '\x91'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 146, str(j)= '\x92'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 147, str(j)= '\x93'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 148, str(j)= '\x94'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 149, str(j)= '\x95'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 150, str(j)= '\x96'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 151, str(j)= '\x97'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 152, str(j)= '\x98'=, unicrap(j)= 'OE'
2020-02-02 13:43:56 default.py: l TEST i= 153, str(j)= '\x99'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 154, str(j)= '\x9a'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 155, str(j)= '\x9b'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 156, str(j)= '\x9c'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 157, str(j)= '\x9d'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 158, str(j)= '\x9e'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 159, str(j)= '\x9f'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 160, str(j)= '\xa0'= , unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 161, str(j)= '\xa1'=¡, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 162, str(j)= '\xa2'=¢, unicrap(j)= 'c'
2020-02-02 13:43:57 default.py: l TEST i= 163, str(j)= '\xa3'=£, unicrap(j)= 'L'
2020-02-02 13:43:57 default.py: l TEST i= 164, str(j)= '\xa4'=¤, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 165, str(j)= '\xa5'=¥, unicrap(j)= 'Y'
2020-02-02 13:43:57 default.py: l TEST i= 166, str(j)= '\xa6'=¦, unicrap(j)= ':'
2020-02-02 13:43:57 default.py: l TEST i= 167, str(j)= '\xa7'=§, unicrap(j)= 's'
2020-02-02 13:43:57 default.py: l TEST i= 168, str(j)= '\xa8'=¨, unicrap(j)= '..'
2020-02-02 13:43:57 default.py: l TEST i= 169, str(j)= '\xa9'=©, unicrap(j)= 'c'
2020-02-02 13:43:57 default.py: l TEST i= 170, str(j)= '\xaa'=ª, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 171, str(j)= '\xab'=«, unicrap(j)= '<<'
2020-02-02 13:43:57 default.py: l TEST i= 172, str(j)= '\xac'=¬, unicrap(j)= '-'
2020-02-02 13:43:57 default.py: l TEST i= 173, str(j)= '\xad'=­, unicrap(j)= '-'
2020-02-02 13:43:57 default.py: l TEST i= 174, str(j)= '\xae'=®, unicrap(j)= 'R'
2020-02-02 13:43:57 default.py: l TEST i= 175, str(j)= '\xaf'=¯, unicrap(j)= '_'
2020-02-02 13:43:57 default.py: l TEST i= 176, str(j)= '\xb0'=°, unicrap(j)= 'deg'
2020-02-02 13:43:57 default.py: l TEST i= 177, str(j)= '\xb1'=±, unicrap(j)= '+/-'
2020-02-02 13:43:57 default.py: l TEST i= 178, str(j)= '\xb2'=², unicrap(j)= '^2'
2020-02-02 13:43:57 default.py: l TEST i= 179, str(j)= '\xb3'=³, unicrap(j)= '^3'
2020-02-02 13:43:57 default.py: l TEST i= 180, str(j)= '\xb4'=´, unicrap(j)= "'"
2020-02-02 13:43:57 default.py: l TEST i= 181, str(j)= '\xb5'=µ, unicrap(j)= 'm'
2020-02-02 13:43:57 default.py: l TEST i= 182, str(j)= '\xb6'=¶, unicrap(j)= 'pi'
2020-02-02 13:43:57 default.py: l TEST i= 183, str(j)= '\xb7'=·, unicrap(j)= '*'
2020-02-02 13:43:57 default.py: l TEST i= 184, str(j)= '\xb8'=¸, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 185, str(j)= '\xb9'=¹, unicrap(j)= '^1'
2020-02-02 13:43:57 default.py: l TEST i= 186, str(j)= '\xba'=º, unicrap(j)= '^0'
2020-02-02 13:43:57 default.py: l TEST i= 187, str(j)= '\xbb'=», unicrap(j)= '>>'
2020-02-02 13:43:57 default.py: l TEST i= 188, str(j)= '\xbc'=¼, unicrap(j)= '1/4'
2020-02-02 13:43:57 default.py: l TEST i= 189, str(j)= '\xbd'=½, unicrap(j)= '1/2'
2020-02-02 13:43:57 default.py: l TEST i= 190, str(j)= '\xbe'=¾, unicrap(j)= '3/4'
2020-02-02 13:43:57 default.py: l TEST i= 191, str(j)= '\xbf'=¿, unicrap(j)= '?'
2020-02-02 13:43:57 default.py: l TEST i= 192, str(j)= '\xc0'=À, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 193, str(j)= '\xc1'=Á, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 194, str(j)= '\xc2'=Â, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 195, str(j)= '\xc3'=Ã, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 196, str(j)= '\xc4'=Ä, unicrap(j)= 'AA'
2020-02-02 13:43:57 default.py: l TEST i= 197, str(j)= '\xc5'=Å, unicrap(j)= 'AA'
2020-02-02 13:43:57 default.py: l TEST i= 198, str(j)= '\xc6'=Æ, unicrap(j)= 'AE'
2020-02-02 13:43:57 default.py: l TEST i= 199, str(j)= '\xc7'=Ç, unicrap(j)= 'C'
2020-02-02 13:43:57 default.py: l TEST i= 200, str(j)= '\xc8'=È, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 201, str(j)= '\xc9'=É, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 202, str(j)= '\xca'=Ê, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 203, str(j)= '\xcb'=Ë, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 204, str(j)= '\xcc'=Ì, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 205, str(j)= '\xcd'=Í, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 206, str(j)= '\xce'=Î, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 207, str(j)= '\xcf'=Ï, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 208, str(j)= '\xd0'=Ð, unicrap(j)= 'Th'
2020-02-02 13:43:57 default.py: l TEST i= 209, str(j)= '\xd1'=Ñ, unicrap(j)= 'N'
2020-02-02 13:43:57 default.py: l TEST i= 210, str(j)= '\xd2'=Ò, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 211, str(j)= '\xd3'=Ó, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 212, str(j)= '\xd4'=Ô, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 213, str(j)= '\xd5'=Õ, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 214, str(j)= '\xd6'=Ö, unicrap(j)= 'OE'
2020-02-02 13:43:57 default.py: l TEST i= 215, str(j)= '\xd7'=×, unicrap(j)= '*'
2020-02-02 13:43:57 default.py: l TEST i= 216, str(j)= '\xd8'=Ø, unicrap(j)= 'OE'
2020-02-02 13:43:57 default.py: l TEST i= 217, str(j)= '\xd9'=Ù, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 218, str(j)= '\xda'=Ú, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 219, str(j)= '\xdb'=Û, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 220, str(j)= '\xdc'=Ü, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 221, str(j)= '\xdd'=Ý, unicrap(j)= 'Y'
2020-02-02 13:43:57 default.py: l TEST i= 222, str(j)= '\xde'=Þ, unicrap(j)= 'th'
2020-02-02 13:43:57 default.py: l TEST i= 223, str(j)= '\xdf'=ß, unicrap(j)= 'ss'
2020-02-02 13:43:57 default.py: l TEST i= 224, str(j)= '\xe0'=à, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 225, str(j)= '\xe1'=á, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 226, str(j)= '\xe2'=â, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 227, str(j)= '\xe3'=ã, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 228, str(j)= '\xe4'=ä, unicrap(j)= 'ae'
2020-02-02 13:43:57 default.py: l TEST i= 229, str(j)= '\xe5'=å, unicrap(j)= 'aa'
2020-02-02 13:43:57 default.py: l TEST i= 230, str(j)= '\xe6'=æ, unicrap(j)= 'ae'
2020-02-02 13:43:57 default.py: l TEST i= 231, str(j)= '\xe7'=ç, unicrap(j)= 'c'
2020-02-02 13:43:57 default.py: l TEST i= 232, str(j)= '\xe8'=è, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 233, str(j)= '\xe9'=é, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 234, str(j)= '\xea'=ê, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 235, str(j)= '\xeb'=ë, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 236, str(j)= '\xec'=ì, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 237, str(j)= '\xed'=í, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 238, str(j)= '\xee'=î, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 239, str(j)= '\xef'=ï, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 240, str(j)= '\xf0'=ð, unicrap(j)= 'th'
2020-02-02 13:43:57 default.py: l TEST i= 241, str(j)= '\xf1'=ñ, unicrap(j)= 'n'
2020-02-02 13:43:57 default.py: l TEST i= 242, str(j)= '\xf2'=ò, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 243, str(j)= '\xf3'=ó, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 244, str(j)= '\xf4'=ô, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 245, str(j)= '\xf5'=õ, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 246, str(j)= '\xf6'=ö, unicrap(j)= 'oe'
2020-02-02 13:43:57 default.py: l TEST i= 247, str(j)= '\xf7'=÷, unicrap(j)= '/'
2020-02-02 13:43:57 default.py: l TEST i= 248, str(j)= '\xf8'=ø, unicrap(j)= 'oe'
2020-02-02 13:43:57 default.py: l TEST i= 249, str(j)= '\xf9'=ù, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 250, str(j)= '\xfa'=ú, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 251, str(j)= '\xfb'=û, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 252, str(j)= '\xfc'=ü, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 253, str(j)= '\xfd'=ý, unicrap(j)= 'y'
2020-02-02 13:43:57 default.py: l TEST i= 254, str(j)= '\xfe'=þ, unicrap(j)= 'th'
2020-02-02 13:43:57 default.py: l TEST i= 255, str(j)= '\xff'=ÿ, unicrap(j)= 'y'
N\xc3\xa5r st\xc3\xb8vet har lagt sig
N      å r st      ø vet har lagt sig 
S\xc3\xb8ren Ryge pr\xc3\xa6senterer
S      ø ren Ryge pr      æ senterer 
    """
    xc3flag = False
    xlatec3={0x82:'Euro', 0x85:'AA', 0x86:'AE', 0x98:'OE', 
        0xa0:'',
        0xa1:'', 0xa2:'c', 0xa3:'L', 0xa4:'o',
        0xa5:'aa', 0xa6:'ae', 0xa7:'s', 0xa8:'..',
        0xa9:'c', 0xaa:'a', 0xab:'<<', 0xac:'-',
        0xad:'-', 0xae:'R', 0xaf:'_', 
        0xb0:'deg',
        0xb1:'+/-', 0xb2:'^2', 0xb3:'^3', 0xb4:"'",
        0xb5:'m', 0xb6:'oe', 0xb7:'*', 0xb8:'oe',
        0xb9:'^1', 0xba:'^0', 0xbb:'>>', 
        0xbc:'1/4', 0xbd:'1/2', 0xbe:'3/4', 0xbf:'?',
        0xc0:'A', 0xc1:'A', 0xc2:'A', 0xc3:'', 0xc4:'AA', 0xc5:'AA',
        0xc6:'AE', 0xc7:'C',
        0xc8:'E', 0xc9:'E', 0xca:'E', 0xcb:'E',
        0xcc:'I', 0xcd:'I', 0xce:'I', 0xcf:'I',
        0xd0:'Th', 0xd1:'N',
        0xd2:'O', 0xd3:'O', 0xd4:'O', 0xd5:'O', 0xd6:'OE', 
        0xd7:'*', 
        0xd8:'OE',
        0xd9:'U', 0xda:'U', 0xdb:'U', 0xdc:'U',
        0xdd:'Y', 0xde:'th', 0xdf:'ss',
        0xe0:'a', 0xe1:'a', 0xe2:'a', 0xe3:'a', 0xe4:'ae', 0xe5:'aa',
        0xe6:'ae', 0xe7:'c',
        0xe8:'e', 0xe9:'e', 0xea:'e', 0xeb:'e',
        0xec:'i', 0xed:'i', 0xee:'i', 0xef:'i',
        0xf0:'th', 0xf1:'n',
        0xf2:'o', 0xf3:'o', 0xf4:'o', 0xf5:'o', 0xf6:'oe', 0xf7:'/', 0xf8:'oe',
        0xf9:'u', 0xfa:'u', 0xfb:'u', 0xfc:'u',
        0xfd:'y', 0xfe:'th', 0xff:'y',
        }
    xlate={0x82:'Euro', 0x85:'AA', 0x86:'AE', 0x98:'OE', 
        0xa0:'',
        0xa1:'', 0xa2:'c', 0xa3:'L', 0xa4:'o',
        0xa5:'aa', 0xa6:':', 0xa7:'s', 0xa8:'..',
        0xa9:'c', 0xaa:'a', 0xab:'<<', 0xac:'-',
        0xad:'-', 0xae:'R', 0xaf:'_', 
        0xb0:'deg',
        0xb1:'+/-', 0xb2:'^2', 0xb3:'^3', 0xb4:"'",
        0xb5:'m', 0xb6:'pi', 0xb7:'*', 0xb8:'oe',
        0xb9:'^1', 0xba:'^0', 0xbb:'>>', 
        0xbc:'1/4', 0xbd:'1/2', 0xbe:'3/4', 0xbf:'?',
        0xc0:'A', 0xc1:'A', 0xc2:'A', 0xc3:'', 0xc4:'AA', 0xc5:'AA',
        0xc6:'AE', 0xc7:'C',
        0xc8:'E', 0xc9:'E', 0xca:'E', 0xcb:'E',
        0xcc:'I', 0xcd:'I', 0xce:'I', 0xcf:'I',
        0xd0:'Th', 0xd1:'N',
        0xd2:'O', 0xd3:'O', 0xd4:'O', 0xd5:'O', 0xd6:'OE', 
        0xd7:'*', 
        0xd8:'OE',
        0xd9:'U', 0xda:'U', 0xdb:'U', 0xdc:'U',
        0xdd:'Y', 0xde:'th', 0xdf:'ss',
        0xe0:'a', 0xe1:'a', 0xe2:'a', 0xe3:'a', 0xe4:'ae', 0xe5:'aa',
        0xe6:'ae', 0xe7:'c',
        0xe8:'e', 0xe9:'e', 0xea:'e', 0xeb:'e',
        0xec:'i', 0xed:'i', 0xee:'i', 0xef:'i',
        0xf0:'th', 0xf1:'n',
        0xf2:'o', 0xf3:'o', 0xf4:'o', 0xf5:'o', 0xf6:'oe', 0xf7:'/', 0xf8:'oe',
        0xf9:'u', 0xfa:'u', 0xfb:'u', 0xfc:'u',
        0xfd:'y', 0xfe:'th', 0xff:'y', 
        }
    r = ''
    unitext = unitext.replace('\xef\xbb\xbf','')   ### Remove: byte order mark (BOM)
    for i in unitext:
        if ord(i) == 0xc3:
            xc3flag = True
        else:
            if xc3flag == True:
                ###if xlatec3.has_key(ord(i)):
                if ord(i) in xlatec3:
                    r += xlatec3[ord(i)]
                elif ord(i) >= 0x80:
                    pass
                else:
                    r += str(i)
                xc3flag = False
            else:
                ###if xlate.has_key(ord(i)):
                if ord(i) in xlate:
                    r += xlate[ord(i)]
                elif ord(i) >= 0x80:
                    pass
                else:
                    r += str(i)
    return r

def find_codec(text):
    all_codecs = ['ascii', 'big5', 'big5hkscs', 'cp037', 'cp273', 'cp424', 'cp437', 
'cp500', 'cp720', 'cp737', 'cp775', 'cp850', 'cp852', 'cp855', 'cp856', 'cp857', 
'cp858', 'cp860', 'cp861', 'cp862', 'cp863', 'cp864', 'cp865', 'cp866', 'cp869', 
'cp874', 'cp875', 'cp932', 'cp949', 'cp950', 'cp1006', 'cp1026', 'cp1125', 
'cp1140', 'cp1250', 'cp1251', 'cp1252', 'cp1253', 'cp1254', 'cp1255', 'cp1256', 
'cp1257', 'cp1258', 'euc_jp', 'euc_jis_2004', 'euc_jisx0213', 'euc_kr', 
'gb2312', 'gbk', 'gb18030', 'hz', 'iso2022_jp', 'iso2022_jp_1', 'iso2022_jp_2', 
'iso2022_jp_2004', 'iso2022_jp_3', 'iso2022_jp_ext', 'iso2022_kr', 'latin_1', 
'iso8859_2', 'iso8859_3', 'iso8859_4', 'iso8859_5', 'iso8859_6', 'iso8859_7', 
'iso8859_8', 'iso8859_9', 'iso8859_10', 'iso8859_11', 'iso8859_13', 
'iso8859_14', 'iso8859_15', 'iso8859_16', 'johab', 'koi8_r', 'koi8_t', 'koi8_u', 
'kz1048', 'mac_cyrillic', 'mac_greek', 'mac_iceland', 'mac_latin2', 'mac_roman', 
'mac_turkish', 'ptcp154', 'shift_jis', 'shift_jis_2004', 'shift_jisx0213', 
'utf_32', 'utf_32_be', 'utf_32_le', 'utf_16', 'utf_16_be', 'utf_16_le', 'utf_7', 
'utf_8', 'utf_8_sig']
    for i in all_codecs:
        for j in all_codecs:
            try:
                log(module,'error TEST %r to %r --> %r' % (i, j, text.encode(i).decode(j)))
            except:
                pass

def openRead(file):
    bom = bomType(file)
    return open(file, 'r', encoding=bom, errors='ignore')

def addHeader(link):
    m = 'utils.readlink'
    """
    import requests
    from fake_useragent import UserAgent
    ua = UserAgent()
    headers = {"User-Agent": ua.random}
    ###response = requests.get("https://example.com", headers=headers)
    ###print(headers)

    request = urllib.request.Request(link)
    """
    ###import requests
    ###from urllib.request import urlopen
    ###import xml.etree.ElementTree as ET
        
    ###import random

    USER_AGENTS = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    ]

    ###headers = {"User-Agent": random.choice(USER_AGENTS)}
    headers = {"User-Agent": USER_AGENTS[0]}
    
    request = urllib.request.Request(link)
    
    ###response = requests.get("https://example.com", headers=headers)
    ###print(response.status_code)

    
    ###header = ADDONname + ' krogsbellIPTV (https://github.com/krogsbell/IPTV/)'   ### 2024-08-08
    ###header = 'Mozilla/5.0 (compatible; filibot/1.0; +https://filibot.com/)'
    log(m,'readlink  headers= %r' % headers)
    ###log(m,'readlink  headers[0]= %r' % headers[0])
    request.add_header('User-Agent', headers)
    log(m,'readlink  request= %r' % request)
    log(m,'readlink  request.get_full_url= %r' % request.get_full_url())
    return request.get_full_url()

def fixdelta(deltatime):  ### make delta time to 00:00:00 type
    try:
        if ':' in deltatime :
            c = deltatime.split(':')
            ### "%02d" % (number,)
            deltatime = '%02d:%02d:%02d' % (int(c[0]),int(c[1]),int(c[2]))
    except Exception as e:
        log(module,'error fixdelta Exception: %r' % e)
        pass   
    return deltatime
    
def isVPN():
    try:
        ### curl https://myip.dk or wget -qO- https://myip.dk   Get IP address
        result = 'Nothing yet!'
        outfile = xbmcvfs.translatePath(os.path.join(datapath, 'myipdk.txt'))
        link = 'https://myip.dk'
        
        definition.ADDONsetSetting('GetPublicAddressLink',link)
        result = readlink(link,outfile,cmodule)
        log(module,'  isVPN result 0= %r' % result)
        test1 = b'Here is your external public IP address:<br/>'
        test2 = b'Here is your external public IP address:<br />'
        if test1 in result:
            result = result.split(test1)[1]
        elif test2 in result:
            result = result.split(test2)[1]
        else:
            result = b'WEB result has changed<!--'
        log(module,'  isVPN result 1= %r' % result)
        result = result.split(b'<!--')[0]
        log(module,'  isVPN result 2= %r' % result)
        definition.ADDONsetSetting('PublicAddress',result)   
        log(module,'  isVPN result 3= %r' % result)
        PublicAddress = definition.ADDONgetSetting('PublicAddress')
        log(module,'  isVPN PublicAddress 0= %r' % PublicAddress)
        ###outfile = xbmcvfs.translatePath(os.path.join(datapath, 'ipinfoio.txt'))
        outfile = xbmcvfs.translatePath(os.path.join(datapath, 'fidroio.txt'))
        ###link = 'https://ipinfo.io/'
        link = 'https://fidro.io/tools/vpn-detector'   ### 2026-05-10
        ###link = 'https://ipleak.net/'   ### 2026-05-10
        
        definition.ADDONsetSetting('GetPublicAddressTypeLink',link)
        ###link += PublicAddress   ### 2026-05-10
        result = readlink(link,outfile,cmodule)
        ### errorstring = <HTTPError 429: 'Too Many Requests'>
        log(module,'  isVPN result 4= %r' % result)
        ### if b'Too Many Requests' in result:   ###Use last result if too many requests
        if b'No Result' in result:   ###Use last result if too many requests
            if outfile != '':
                file = open(outfile,'rb')
                result = file.read()
                file.close()

        test1 = b'No VPN</span>'
        test2 = b'No proxy</span>'
        test3 = b'Not Tor</span>'
        test4 = b'Not datacenter</span>'
        fon  = ''
        foff = ''
        
        if test1 in result:
            foff += 'VPN '
        else:
            fon += 'VPN '
        if test2 in result:
            foff += 'Proxy '
        else:
            fon += 'Proxy '
        if test3 in result:
            foff += 'Tor '
        else:
            fon += 'Tor '
        if test4 in result:
            foff += 'Datacenter '
        else:
            fon += 'Datacenter '
        if fon == '':    
            result = '[COLOR green][B]ISP[/B][/COLOR]' ### 2026-05-08
            definition.ADDONsetSetting('NetworkType','ISP')
        else:
            result = '[COLOR red][B]%s[/B][/COLOR]' % fon
            definition.ADDONsetSetting('NetworkType',fon)
        
        """
        test1 = b'<h6 class="uppercase-small-title">ASN type</h6>'
        if test1 in result:
            result = result.split(test1)[1]
        else:
            result = b'WEB result has changed!'
        log(module,'isVPN result 5= %r' % result)
        if b'<span>' in result:    ### 2026-05-08
            result = result.split(b'<span>')[1].split(b'</span>')[0]
            log(module,'isVPN result 6= %r' % result)   ### 2024-03-27
            definition.ADDONsetSetting('NetworkType',result.decode())
            if result != b'ISP':
                result = '[COLOR red][B]VPN[/B][/COLOR] ' + result.decode()
            else:
                result = '[COLOR green][B]ISP[/B][/COLOR]' ### 2026-05-08
        else:
            result = 'VPN no <span>'   ### 2026-05-08
        """
    except Exception as e:
        log(module,'isVPN Except: %r' % e)
        pass
        result = '[COLOR red]error in VPN test[/COLOR] %r' % e
    if definition.ADDONgetSetting('networktest') == 'true':
        return result
    else:
        return ''

def getvlcexecutive():
    try: 
        vlcexecutive = definition.ADDONgetSetting('vlcexecutive')
        log(module,"vlcexecutive= %r" % vlcexecutive)
        if os.path.isfile(vlcexecutive):
            return vlcexecutive
        heading = '[COLOR yellow][B]Find at the vlc executive[/B] - VideoLAN vlc[/COLOR]'
        ###vlcexecutive = xbmcgui.Dialog().browse(type, heading, shares[, mask, useThumbs, treatAsFolder, defaultt, enableMultiple])
        vlcexecutive = xbmcgui.Dialog().browse(1, heading, "files")
        if os.path.isfile(vlcexecutive):
            definition.ADDONsetSetting('vlcexecutive',vlcexecutive)
            return vlcexecutive
        else:
            return ''
            
    except Exception as e:
        pass
        log(module,'getvlcexecutive Exception: %r' % e)

def removedoubleslash(url):
    return url.replace('://','a¤B¤c').replace('//','/').replace('a¤B¤c','://')

def showdns():
    import platform
    import subprocess

    system = platform.system()

    if system == "Windows":
        cmd = "ipconfig /all"
    elif system == "Darwin":
        cmd = "scutil --dns"
    else:
        cmd = "cat /etc/resolv.conf"

    output = subprocess.check_output(cmd, shell=True, text=True)

    dns_servers = []

    for line in output.splitlines():
        if "DNS Servers" in line or "nameserver" in line:
            parts = line.split()
            for p in parts:
                if p.replace(".", "").isdigit():
                    dns_servers.append(p)

    ###print("Aktive DNS-servere:")
    ###log(module,"  Aktive DNS-servere:")
    for dns in dns_servers:
        ###print("-", dns)
        log(module,"  Aktive DNS-servere: %r" % dns)
    ### LibreELEC
    dnssetup = '/etc/connman/main.conf'
    
    output = subprocess.check_output(cmd, shell=True, text=True)
    
    if os.path.exists(dnssetup): 
        cmd = 'cat ' + dnssetup
        for line in output.splitlines():
            if "FallbackNameservers" in line or "nameserver" in line:
                parts = line.split()
                for p in parts:
                    if p.replace(".", "").isdigit():
                        dns_servers.append(p)
                    
    definition.ADDONsetSetting('dns_servers','%r'% dns_servers)
    return dns_servers


def readlink(link,outfile,cmodule):
    m = 'utils.readlink'
    import ssl
    context = ssl._create_unverified_context()
    ###BasicHTTP = urlopen(ChannelBasicHTTP, context=context)
    try:
        log(m,'1685 readlink(link= %r, outfile= %r) in module: %r' % (link,outfile,cmodule))
        linksWithTimeOut = definition.ADDONgetSetting('linksWithTimeOut')
        log(m,'1687 readlink linksWithTimeOut= %r' % linksWithTimeOut)
        linksWithTimeOutCount = definition.ADDONgetSetting('linksWithTimeOutCount')
        if linksWithTimeOutCount == '':
            linksWithTimeOutCount = 0
        else:
            linksWithTimeOutCount = int(linksWithTimeOutCount)
        linksWithTimeOutCount += 1
        ADDONresetSetting('linksWithTimeOutCount',str(linksWithTimeOutCount))  
        log(m,'1695 readlink(linksWithTimeOut= %r, linksWithTimeOutCount= %r)' % (linksWithTimeOut,linksWithTimeOutCount))
        if link in linksWithTimeOut and linksWithTimeOutCount < 100:
            log(m,'1697 readlink linksWithTimeOut return empty')
            return ''
        linksWithTimeOut = linksWithTimeOut.replace(link,'').strip()  
        ADDONresetSetting('linksWithTimeOut',linksWithTimeOut) 
        ADDONresetSetting('linksWithTimeOutCount','0')
        log(m,'1702 readlink(link= %r, outfile= %r) in module: %r' % (link,outfile,cmodule))
        
        request = urllib.request.Request(link)
        response = urllib.request.urlopen(request)
        log(m,'1706 response.read().decode(utf-8)= %r' % response.read().decode('utf-8'))
        
        log(m,'1708 readlink 1.5 link= %r' % link)
        try:
            ###link = link.replace('http://line.dino.ws:80/','http://line.plugdino.cc:80/',1)      ###TEST 2026-11-25
            ###link = link.replace('&next_days=10','',1)      ###TEST 2026-11-25
            log(m,'1713 readlink addHeader(link)= %r' % addHeader(link))  
            log(m,'1714 readlink context= %r' % context)  
            response = urlopen(addHeader(link), context=context)
        except Exception as e:
            pass
            log(m,'1718 Exception urlopen(addHeader) errorstring= %r' % e)    
            try:
                response = urlopen(link, context=context)   ### 2024-08-08 without header
            except Exception as e:
                pass
                log(m,'1719 Exception urlopen(context) errorstring= %r' % e)    
                try:
                    response = urlopen(link)   ### 2024-08-08 without header
                except Exception as e:
                    pass
                    log(m,'1724 Exception urlopen(link) errorstring= %r' % e)    
            
        log(m,'1726 readlink 2')
        data = response.read()
        log(m,'1728 readlink 3')
        log(m,'1729 readlink link=%r\noutfile= %r\ndata= %r' % (link,outfile,data))
        if outfile != '':
            log(m,'1731 readlink 4')
            makeOldFile(outfile)
            log(m,'1733 readlink 5')
            with open(outfile,'wb') as output:
                log(m,'1735 readlink 6')
                output.write(data)
        log(m,'1737 readlink 7')
        return data
    except Exception as e:
        pass
        errorstring= '%r' % e
        log(m,'1742 Exception errorstring= %r' % e)
        if 'TimeoutError' in errorstring:
            ADDONresetSetting('linksWithTimeOutCount','0') 
            if not link in linksWithTimeOut:
                ADDONresetSetting('linksWithTimeOut',linksWithTimeOut + ' ' + link) 
        log(m,'1747 readlink(\nlink= %r,\noutfile= %r,\ncmodule= %r\nException  %r' % (link,outfile,cmodule,e))
        return b'%r' % e

def copykodisetup():
    ### Get passwords, mediasources and sources if enabled and available
        if definition.ADDONgetSetting('copykodisetup') == 'true' :
            userdatapath = xbmcvfs.translatePath('special://masterprofile')
            ###userdatapath = xbmcvfs.translatePath(definition.FileManagerPath('userdata'))
            SystemFriendlyName = str(xbmc.getInfoLabel('System.FriendlyName')).replace('[','').replace(']','')
            destname = (SystemFriendlyName+'-'+ADDONname).replace(' ','')
            dest = os.path.join(userdatapath,destname)
            dest = os.path.join(dest,'test.xml')
            sour = os.path.join(datapath,'settings.xml')
            if os.path.exists(sour):
                copyOK = xbmcvfs.copy(sour, dest)
                if not copyOK:
                    log(module,'error copykodisetup Copy of test.XML %r failed - ERR: %r' %  (dest,copyOK))
                else:
                    log(module,'error copykodisetup Copy of test.XML %r OK - %r' %  (dest,copyOK))
            source = xbmcvfs.translatePath(definition.FileManagerPath('logs'))
            log(module,'error copykodisetup userdatapath= %r' % userdatapath)
            ### xmlfiles = ['sources.xml','mediasources.xml','passwords.xml']
            if os.path.exists(userdatapath):
                log(module,'error copykodisetup userdatapath exists %r ' %  userdatapath)
            else:
                log(module,'error copykodisetup userdatapath DO NOT exists %r ' %  userdatapath)
            ### is folder writable
            if os.access(userdatapath, os.W_OK):
                log(module,'error copykodisetup OK: folderwritable(userdatapath= %r)' % userdatapath)
            else:
                log(module,'error copykodisetup NOT WRITABLE: folderwritable(userdatapath= %r)' % userdatapath)
            xmlfiles = definition.xmlimportfiles()
            for file in xmlfiles :
                sourf = os.path.join(source,file)
                log(module,'error copykodisetup Source to copy XML %r ' %  (sourf))
                destf = os.path.join(userdatapath,file)   ###2025-02-06
                destb = os.path.join(userdatapath,'backup')   ###2025-02-06
                destbf = os.path.join(destb,file)   ###2025-02-06
                log(module,'error copykodisetup Destination to copy XML %r ' %  (destf))
                if os.path.isfile(sourf) or 1 == 1:
                    copyOK = xbmcvfs.copy(destf, destbf)
                    if not copyOK:
                        log(module,'error copykodisetup Copy of XML to backup failed%r  - ERR: %r' %  (destbf,copyOK))
                    else:
                        log(module,'error copykodisetup Copy of XML to backup OK %r, %r' %  (destbf,copyOK))
                    copyOK = xbmcvfs.copy(sourf, destf)
                    if not copyOK:
                        log(module,'error copykodisetup Copy of XML failed %r - ERR: %r' %  (sourf,copyOK))
                    else:
                        log(module,'error copykodisetup Copy of XML OK %r - %r' %  (sourf,copyOK))

def get_free_space_all():
    L = xbmcvfs.translatePath(definition.FileManagerPath('Recordings'))
    Log = xbmcvfs.translatePath(definition.FileManagerPath('log'))
    A = xbmcvfs.translatePath(definition.FileManagerPath('Videos'))
    B = xbmcvfs.translatePath(definition.FileManagerPath('VideosB'))
    F = xbmcvfs.translatePath(definition.FileManagerPath('VideosF'))
    G = xbmcvfs.translatePath(definition.FileManagerPath('VideosG'))
    system = xbmcvfs.translatePath('special://masterprofile')
    testdata = [[L,'L'],[A,'A'],[B,'B'],[F,'F'],[G,'G'],[Log,'/'],[system,'/']]
    for dirname in testdata :
        result = get_free_space_gb(dirname[0],dirname[1])
        log(module,'error get_free_space_all(dirname[0]= %r,archive=dirname[1]= %r, result(GB/KB)= %r' % (dirname[0],dirname[1],result))

def get_free_space_gb(dirname,archive='B'):
    try:
        log(module,'error test sdiskusage folderPath= %r archive= %r' % (dirname,archive))
        import ctypes
        import os
        import platform
        import sys
        log(module,'error get_free_space_gb dirname= %r' % dirname)
        freeGB = -1
        freeKB = -1
        ### Return folder/drive free space (in gigabytes)
        if 'smb://' in dirname.lower():
            freeGB = -1
            freeKB = -1
        elif platform.system() == 'Windows':
            free_bytes = ctypes.c_ulonglong(0)
            ctypes.windll.kernel32.GetDiskFreeSpaceExW(ctypes.c_wchar_p(dirname), None, None, ctypes.pointer(free_bytes))
            freeKB = free_bytes.value / 1024 / 1024
            freeKB = int(str(freeKB).split('.')[0])
            freeGB = free_bytes.value / 1024 / 1024 / 1024
            freeGB = int(str(freeGB).split('.')[0])
        else:
            st = os.statvfs(dirname)
            freeKB = st.f_bavail * st.f_frsize / 1024 / 1024
            freeKB = int(str(freeKB).split('.')[0])
            freeGB = st.f_bavail * st.f_frsize / 1024 / 1024 /1024
            freeGB = int(str(freeGB).split('.')[0])
        log(module,'error 1238 get_free_space_gb dirname= %r, archive= %r, FreeKB= %r, FreeGB= %r ' % (dirname, archive, freeKB, freeGB))
        if archive == 'A':
            ADDONresetSetting('record_archive_size',str(freeGB))
        elif archive == 'B':
            ADDONresetSetting('record_archiveb_size',str(freeGB))
        elif archive == 'F':
            ADDONresetSetting('record_archivef_size',str(freeGB))
        elif archive == 'G':
            ADDONresetSetting('record_archiveg_size',str(freeGB))
        elif archive == 'L':
            ADDONresetSetting('record_path_size',str(freeGB))
        elif archive == '/':
            ADDONresetSetting('system_free_size',str(freeKB))
        log(module,'error test sdiskusage archive= %r, freeGB= %r, folderPath= %r' % (archive,freeGB,dirname))
        if type(freeGB) == type(1):
            return freeGB
        else:
            return -1
    except Exception as e:
        pass
        log(module,'error sdiskusage EXCEPTION: %r' % e)
        try:
            if archive == 'A':
                ADDONresetSetting('record_archive_size',repr(e))
            elif archive == 'B':
                ADDONresetSetting('record_archiveb_size',repr(e))
            elif archive == 'F':
                ADDONresetSetting('record_archivef_size',repr(e))
            elif archive == 'L':
                ADDONresetSetting('record_path_size',repr(e))
            elif archive == '/':
                ADDONresetSetting('system_free_size',repr(e))
            log(module,'error test sdiskusage freeKB/GB Err= %r, folderPath= %r' % (e,dirname))
        except Exception as e:
            pass
            log(module,'error sdiskusage 2 %r' % e)
        return -1

def geturldirectorypath(archive):
    try:
        archive = archive.upper()
        if archive == 'L':
            urldirectorypath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_path')))
        elif archive == 'A':
            if definition.ADDONgetSetting('record_archive_path_enable') == 'true':
                urldirectorypath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_archive_path')))
            else:
                urldirectorypath = ''
        elif archive == 'B':
            if definition.ADDONgetSetting('record_archiveb_path_enable') == 'true':
                urldirectorypath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_archiveb_path')))
            else:
                urldirectorypath = ''
        elif archive == 'F':
            if definition.ADDONgetSetting('record_archivef_path_enable') == 'true':
                urldirectorypath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_archivef_path')))
            else:
                urldirectorypath = ''
        elif archive == 'G':
            if definition.ADDONgetSetting('record_archiveg_path_enable') == 'true':
                urldirectorypath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_archiveg_path')))
            else:
                urldirectorypath = ''
        else:
            urldirectorypath = ''
        log(module,'error OK geturldirectorypath archive= %r\nurldirectorypath= %r' % (archive,urldirectorypath))
        return urldirectorypath
    except Exception as e:
        pass
        log(module,'error geturldirectorypath archive= %r\nurldirectorypath= %r\n%r' % (archive,urldirectorypath,e))
        return ''        

def HT(TS):
    try:
        TStype = type(TS)
        log(module,'TStype= %r' % TStype)
        if isinstance(TS, float):
            return humantime(int(TS))
            ###recordings.humantime(time.mktime(TS.timetuple()))
        elif isinstance(TS, int):
            return humantime(TS)
        elif isinstance(TS, datetime.datetime):
            return humantime(TS)
        else:
            return humantime(TS)
    except Exception as e:
        log(module,'err #253 Exception: %r' % e)
        pass
        log(module,'ERR HT(TS= %r)\nERR: %r' % (TS,e))

def ht(ts):    ### Timestamp to short human time
    if not isinstance(ts, int):
        return ts
    dt = datetime.datetime.fromtimestamp(ts)
    ###ht = dt.strftime("%Y-%m-%d %H:%M:%S")
    ht = dt.strftime("%m-%d %H:%M")
    return ht
    
def humantime(ts):   ### Timestamp to human time
    if isinstance(ts, int):
        dt = datetime.datetime.fromtimestamp(ts)
    if isinstance(ts, float):
        dt = datetime.datetime.fromtimestamp(ts)
    elif isinstance(ts, datetime.datetime):
        dt = ts
    else:
        return ts
    ###dt = datetime.datetime.fromtimestamp(ts)
    ht = dt.strftime("%Y-%m-%d %H:%M:%S")
    ###ht = dt.strftime("%m-%d %H:%M")
    return ht

def humantimestop(dt):   ### datetime to human time with microseconds
    ###dt = datetime.fromtimestamp(ts)
    htms = dt.strftime("%f")[:3]
    ###ht = dt.strftime("%Y-%m-%d %H:%M:%S") + ',' + htms
    ht = dt.strftime("%H:%M:%S") + ',' + htms
    return ht

def dt(ts):   ### DateTime from Timestamp
    if not isinstance(ts, int):
        return ts
    dt = datetime.datetime.fromtimestamp(ts)
    return dt
    
def ts(ds):   ### Date string to timestamp
    if not isinstance(ds, str):
        return ds
    ###ds = "2008-11-10 17:53:59"
    time_tuple = time.strptime(ds, "%Y-%m-%d %H:%M:%S")
    ###time_tuple = (2008, 11, 12, 13, 59, 27, 2, 317, 0)
    ts = int(time.mktime(time_tuple))
    return ts

def tsds(ds):   ### Date string to timestamp
    if not isinstance(ds, str):
        return ds
    ###ds = "2008-11-10 17:53:59"
    time_tuple = time.strptime(ds, "datetime.datetime(%Y, %m, %d, %H, %M, %S, %f)")
    ###time_tuple = (2008, 11, 12, 13, 59, 27, 2, 317, 0)
    ts = int(time.mktime(time_tuple))
    return ts

def tsdt(ds):   ### Datetime to timestamp
    ###log(module,'  type(ds) = %r' % type(ds))
    if not type(ds) == type(datetime.datetime.now()):
        return ds
    ###ds = "2008-11-10 17:53:59"
    ###time_tuple = time.strptime(ds, "datetime.datetime(%Y, %m, %d, %H, %M, %S, %f)")
    ###time_tuple = (2008, 11, 12, 13, 59, 27, 2, 317, 0)
    ts = int(ds.timestamp())
    return ts

def sectoHT(HT):
    ### seconds to fixed human time 
    try:
        log(module,'error sectoHT HT= %r' % HT)
        dt_obj= datetime.datetime.now()
        log(module,'error sectoHT dt_obj= %r' % dt_obj)
        datenow = dt_obj.date()
        log(module,'error sectoHT datenow= %r' % datenow)
        time1dt = dt(datenow)
        log(module,'error sectoHT time1dt= %r' % time1dt)
        time2t = datetime.datetime.strftime(time1dt, "%Y-%m-%d") + ' ' + HT + ':00'
        log(module,'error sectoHT time2t= %r' % time2t)
        time1t = datetime.datetime.strftime(time1dt, "%Y-%m-%d %H:%M:%S")
        log(module,'error sectoHT time1t= %r' % time1t)
        time_tuple = time.strptime(time1t, "%Y-%m-%d %H:%M:%S")
        time1  = int(time.mktime(time_tuple))
        log(module,'error sectoHT time1= %r' % time1)
        time_tuple = time.strptime(time2t, "%Y-%m-%d %H:%M:%S")
        time2  = int(time.mktime(time_tuple))
        log(module,'error sectoHT time2= %r' % time2)
        nowt = datetime.datetime.strftime(dt_obj, "%Y-%m-%d %H:%M:%S")
        time_tuple = time.strptime(nowt, "%Y-%m-%d %H:%M:%S")
        now  = int(time.mktime(time_tuple))
        log(module,'error sectoHT now= %r' % now)
        difference = time2 - now
        log(module,'error sectoHT difference= %r' % difference)
        if difference <= 0:
            difference += 24 * 3600
        log(module,'error sectoHT difference final= %r' % difference)
        timetorun = dt(now + difference)
        log(module,'error sectoHT time to run: %r' % timetorun)
    except Exception as e:
        log(module,'error sectoHT Exception: %r' % e)
        pass
        difference = e
    return difference
    
"""
time_tuple = dt_obj.timetuple()
time_tuple = (2008, 11, 12, 13, 59, 27, 2, 317, 0)
timestamp = time.mktime(time_tuple)
"""
def get_sub_parameters(params,param):
    params=params.replace('?','').replace('& ','aMp ').replace('&%20','aMp%20')   ### 2019-02-23 Accept &<space> in filename
    log(module,'err params= %r' % params)
    if (params[len(params)-1]=='/'):
        log(module,'err params[len(params)-1]=="/"')
        params=params[0:len(params)-2]
        log(module,'err 2 params= %r' % params)
    pairsofparams=params.split('&')
    log(module,'err pairsofparams= %r' % pairsofparams)
    
    for j in range(len(pairsofparams)):
        splitparams={}
        splitparams=pairsofparams[j].split('=',1)
        log(module,'err splitparams= %r' % splitparams)
        log(module,'err len(splitparams)= %r' % len(splitparams))
        if (len(splitparams))==2:
            log(module,'err len(splitparams)== 2') 
            secondpart = decode64(splitparams[1])
            log(module,'err secondpart= %r' % secondpart)
            if '&' in secondpart:
                log(module,'err & in secondart')
                get_sub_parameters(splitparams[0]+'='+secondpart,param)
                log(module,'err & secondpart params= %r' % params)
            else:
                param[splitparams[0]]= secondpart.replace('aMp ','& ').replace('aMp%20','&%20')
                log(module,'err 0 param= %r' % param)
    log(module,'err final get_sub_parameters param= %r' % param)
            
def get_params(index):
    log(module,'err get_params(index= %r) sys.argv= %r' % (index,sys.argv))
    i = 0
    param={}
    for x in sys.argv:
        log(module,'error 1221 sys.argv [%r] x= %r' % (i,x), showlength = 5000)
        try:
            log(module,'error 1222 sys.argv [%r] decode(x)= %r' % (i,decode64(x)), showlength = 5000)
        except: 
            pass
        try:
            log(module,'error 1223 sys.argv [%r] decode2 of x= %r' % (i,x.split('&')[0]), showlength = 5000)
            log(module,'error 1223 sys.argv [%r] decode2(x)= %r' % (i,decode64(decode64(x.split('&')[0]))), showlength = 5000)
        except: 
            pass
        log(module,'error 1224 param= %r' % param, showlength = 5000)
        if i >= index:
            params=sys.argv[i]
            get_sub_parameters(params,param)
            log(module,'error 2 param= %r' % param, showlength = 5000)
            try:
                if 'uri=' in params:
                    log(module,'err uri= in params')
                    param['uriorg']= sys.argv[index].split('uri=')[1].split('&')[0]
                    log(module,'err 3 param= %r' % param, showlength = 5000)
            except Exception as e:
                log(module,'err #349 Exception: %r' % e)
                pass
                log(module,'err 2 param Exception: %r' % e)
        i += 1
    log(module,'error 1 param= %r' % param)
    return param
    
def param(u,match):
    try:
        ###log(module,'err param(u= %r, match= %r)' % (u,match))
        u = urllibunquote_plus(u)
        x = u.split('&'+match+'=')[1].split('&')[0]
    except Exception as e:
        log(module,'err #362 Exception: %r' % e)
        pass
        log(module,'err 1 param Exception: %r' % e)
        try:
            x = u.split('?'+match+'=')[1].split('&')[0]
        except Exception as e:
            log(module,'err #368 Exception: %r' % e)
            pass
            log(module,'err 2 param Exception: %r' % e)
            x = ''
    ###log(module,'err x= %r' % x)
    return x

def decode64(text):
    log(module,'1105 errorZ decode64(text= %r)' % text)
    decoded = text
    try:
        if text != None and text != '':
            log(module,'errorZ text[:10]= %r' % text[:10])
            ###if text[:4] == 'b64bXXX':  ### Don't USE
            ###    decoded = base64.b64decode(text[4:]).decode()  ### 2023-04-11  for iPlayerwww
            ###    log(module,'errorZ XX0 decoded= %r' % decoded)
            ###el
            if text[:3] == 'b64':
                log(module,'errorZ text[:3]= %r' % text[:3])
                text = text.replace('AbCdEf','+')   ### 2024-03-08
                log(module,'errorX text= %r' % text,showlength=5000)
                log(module,'errorZ text[3:]= %r' % text[3:],showlength=5000)
                textlengthby4 = len(text[3:])/4
                log(module,'errorZ len(text[3:])/4= %r' % textlengthby4)
                try:
                    decoded = base64.b64decode(text[3:])
                    log(module,'errorZ 1 decoded= %r' % decoded,showlength=5000)
                except Exception as e:
                    log(module,'errorZ 1275 Exception: %r' % e)
                    pass
                try:
                    decoded = base64.b64decode(text[3:]).decode()  ### 2021-03-25(until 2023-05-31)
                    log(module,'errorZ 2 decoded= %r' % decoded,showlength=5000)
                except Exception as e:
                    log(module,'error 1281 Exception: %r' % e)
                    pass
                log(module,'errorZ XX0 decoded= %r' % decoded)
                log(module,'errorZ XX0 decoded After')
                """
                if decoded[:3] == 'b64' and '&' in decoded:
                    decodedfirst = decoded.split('&')[0]
                    log(module,'err XX1 decodedfirst= %r' % decodedfirst)
                    decodedlast = decoded.replace(decodedfirst,'',1)
                    log(module,'err XX1 decodedlast= %r' % decodedlast)
                    decoded = base64.b64decode(decodedfirst[3:]).decode() + decodedlast
                    log(module,'err XX1 decoded= %r' % decoded)
                elif decoded[:3] == 'b64' and not '&' in decoded:
                    decoded = base64.b64decode(decoded[3:]).decode()
                    log(module,'err XX2 decoded= %r' % decoded)
                else:
                    decoded = text
                """
            
            else:
                decoded = text
        else:
            decoded = ''
    except Exception as e:
        log(module,'errorZ #402 Exception: %r' % e)
        pass
        log(module,'errorZ 392 decode64 of: %r\nErr %r' % (text,e))
        decoded = text
    log(module,'errorZ 394 decode64(decoded= %r)' % decoded)
    return decoded
    
def base64b64encode(texttoencode):
    try:
        result = base64.b64encode(texttoencode.encode())
    except Exception as e:
        log(module,'err #413 Exception: %r' % e)
        pass
        log(module,'base64b64encode() ERR: %r' % e)
        result = base64.b64encode(texttoencode)
    texttoencode = 'b64' + result.decode()
    return texttoencode

def encode64(text):
    try:
        if text != None and text != '':
            encoded = 'b64' + base64.b64encode(text)
        else:
            encoded = ''
    except Exception as e:
        log(module,'err #427 Exception: %r' % e)
        pass
        log(module,'base64.b64encode of: %r\nErr %r' % (text,e))
        encoded = text
    return encoded

def TwoLines(name):  ### Use in menus to allow autoscroll and see all text on both lines
    ###log(module,'TwoLines(name)= %r' % name)
    name = name.replace('  ',' ').split('\n')
    line1 = name[0]
    lenline1 = len(line1)
    line2 = ''
    for i in range(1, len(name)):
        line2 += name[i] + ' '
    lenline2 = len(line2)
    if lenline1 < lenline2:
        line1 = line1 + '  ' * (lenline2 - lenline1)
    if line2 != '':
        name = line1 +'\n' + line2
    else:
        name = line1
    return name 

def notnone(cat):
    if cat == None:
        return ''
    else:
        return cat
        
def makeOldFile(file):
    if os.path.isfile(file):
        ext = '.' + file.split('.')[-1]
        new = 'OLD' + ext
        oldfile = file.replace(ext,new)
        log(module,'oldfile= %r' % oldfile)
        shutil.copyfile(file, oldfile)
        
def getOldFile(file):
    if os.path.isfile(file):
        ext = '.' + file.split('.')[-1]
        new = 'OLD' + ext
        oldfile = file.replace(ext,new)
        log(module,'oldfile= %r' % oldfile)
        shutil.copyfile(oldfile, file)       
        
def copyFiles(source,destination):
    try:
        source = source.replace('[','?').replace(']','?')
        log(module,'err copyFiles(source= %r,destination= %r)' % (source,destination))
        Files = glob.glob(source)
        log(module,'err Files= %r' % Files)
        for file in Files:
            log(module,'err copyFiles file= %r' % file)
            
            destf = os.path.join(destination,os.path.basename(file))
            ###shutil.copy2(file, destination)
            if os.path.exists(file):
                copyOK = xbmcvfs.copy(file, destf)
                if not copyOK:
                    log(module,'error copyFiles failed - ERR: %r' %  copyOK)
            log(module,'err copyFiles(file= %r, destf= %r)' % (file, destf))
    except Exception as e:
        log(module,'err #475 Exception: %r' % e)
        pass
        log(module,'Err/Exceptionin copyFiles(source,destination): %r' % e)

def notificationsend(name):
    # Show menuentry when finished OK - but not when run in the background
    contextMenu = []
    try:
        log(module,'Notificationsend(name= %r)' % name)
        log(module,'sys.argv= %r' % sys.argv)
        liz=xbmcgui.ListItem(name)
        liz.setProperty('IsPlayable','false')
        contextMenu.append(('[COLOR orange][B]Back to view[/B][/COLOR]','RunPlugin(%s?name=None&mode=666&url=None&iconimage=None&cat=0)'% (sys.argv[0])))
        contextMenu.append(('[COLOR red][B]Back to Kodi[/B][/COLOR]','RunPlugin(%s?name=None&mode=29&url=None&iconimage=None&cat=0)'% (sys.argv[0])))
        liz.addContextMenuItems(contextMenu,replaceItems=True)
        try:
            sysargv1 = int(sys.argv[1])
        except Exception as e:
            pass
            sysargv1 = 0
        xbmcplugin.addDirectoryItem(handle = sysargv1, url='url',listitem = liz, isFolder = False) 
        log(module,'notificationsend - Finished in foreground with menu item: %r' % name)
    except Exception as e:
        pass
        log(module,'notificationsend Exception: %r' %e)
        log(module,'notificationsend - Finished in background - no menu item: %r' % name)
    
def deleteFile(file):
    tries    = 0
    maxTries = 10
    maxSleep = 50
    while os.path.exists(file) and tries < maxTries:
        try:
            os.remove(file)
            log(module,'remove file: %r' % file)
            break
        except Exception as e:
            log(module,'1783 Exception: %r' % e)
            xbmc.sleep(maxSleep)
            tries = tries + 1

def deleteset():
    file = os.path.join(datapath,'*.set')
    Files = glob.glob(file)
    # delete .set files
    for file in Files:
        log(module,'Delete file: %r' % file)
        deleteFile(file)
        
def nowTS():   ### Local time  2022-04-06
    dt_obj= datetime.datetime.now()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
    
def nowutcTS():   ### UTC time    ### 2022-04-06
    dt_obj= datetime.datetime.utcnow()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
    
def timeZone():     ### Local time  2022-04-06
    tz = (nowTS() - nowutcTS())//3600
    return tz
    
def testPrograms():
    notificationUPD('Test recording programs')
    try:  ### Get system timezone
        ###timezone = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Settings.GetSettingValue", "params": {"setting": "locale.timezone"}, "id": 1}')
        timezone = timeZone()
        log(module,'Kodi timezone= %r' % timezone)
    except Exception as e:
        log(module,'1818 Exception: %r' % e)
        pass
        log(module,'Get timezone err= %r' % e)
    try:   ### Test if ffmpeg is installed
        if runCommandTest('ffmpeg'):
            notificationUPD('FFMPEG has been installed!')
            log(module,'FFMPEG installed!')
        else:
            log(module,'FFMPEG NOT installed!')
    except Exception as e:
        log(module,'1828 Exception: %r' % e)
        pass
        log(module,'Get ffmpeg err= %r' % e)
    try:   ### Test if rtmpdump is installed
        if runCommandTest('rtmpdump'):
            log(module,'RTMPDUMP installed!')
        else:
            log(module,'RTMPDUMP NOT installed!')
    except Exception as e:
        log(module,'1837 Exception: %r' % e)
        pass
        log(module,'Get rtmpdump err= %r' % e)
    try:   ### Test if 7zip is installed
        if runCommandTest('7z'):
            log(module,'7z installed!')
        else:
            log(module,'7z NOT installed!')
    except Exception as e:
        log(module,'1846 Exception: %r' % e)
        pass
        log(module,'Get 7z err= %r' % e)
    try:   ### Test if xarchiver -v is installed
        if runCommandTest('xarchiver -v'):
            log(module,'xarchiver -v installed!')
        else:
            log(module,'xarchiver -v NOT installed!')
    except Exception as e:
        log(module,'err #587 Exception: %r' % e)
        pass
        log(module,'Get xarchiver -v err= %r' % e)

def FindDirectPrograms():
    directprograms= []
    ###log(module,'FindDirectPrograms directrecording= ' + repr(directrecording))
    if directrecording == '2':   ### HD
        directfile = os.path.join(progpath,'resources','directchannelshd.csv')
        log(module,'FindDirectPrograms: directfile HD= ' + repr(directfile))
    if directrecording == '1':   ### SD
        directfile = os.path.join(progpath,'resources','directchannelssd.csv')
        #log(module,'FindDirectPrograms','directfile SD= ' + repr(directfile))
    if not directrecording == '1' and not directrecording == '2':
        log(module,'FindDirectPrograms: No directfile!')
        return directprograms
        
    try: 
        csvfile = open(directfile,'r')
    except Exception as e:
        log(module,'1875 Exception: %r' % e)
        log(module,'FindDirectPrograms: Except in open file ' + repr(directfile) +': ' + repr(e))
        pass
        return directprograms
    line0 = csvfile.readline()
    #log(module,'FindDirectPrograms First line: ' + repr(line0))
    nextline=csvfile.readline().strip().split(',')
    #log(module,'FindDirectPrograms Next line: ' + repr(nextline))
    while not nextline == [''] :
        directprograms.append(nextline)
        #log(module,'FindDirectPrograms directprograms: ' + repr(directprograms))
        nextline=csvfile.readline().strip().split(',')
        #log(module,'FindDirectPrograms Next line: ' + repr(nextline))
        #log(module,'FindDirectPrograms len(nextline): ' + repr(len(nextline)))
        if not len(nextline) == 3:
            break 
        if len(nextline) == 0:
            break 
    csvfile.close()
    return directprograms

def directprogramsNTV(cat):
    drprograms=FindDirectPrograms()
    recorddrdirectly=''
    if directrecording > '0':   ### SD, HD
        for index in range(0, len(drprograms)): 
            if cat ==  drprograms[index][0]:
                recorddrdirectly = drprograms[index][2]
                return recorddrdirectly
    return recorddrdirectly

def getGuiSetting(guisetting,defaultsetting):
    ### guisettings.xml <webserverport>8081</webserverport>
    ### utils.getGuiSetting(guisetting,defaultsetting)
    ### utils.getGuiSetting('webserverport','8080')
    
    try:
        guisettings = xbmcvfs.translatePath(os.path.join('special://masterprofile' , 'guisettings.xml'))
        settingsfile = open(guisettings,'r')
        settings = settingsfile.read()
        webport = settings.split('<' + str(guisetting) + '>')
        webport = webport[1].split('</' + str(guisetting) + '>')[0]
    except Exception as e:
        log(module,'err #650 Exception: %r' % e)
        log(module,'getGuiSetting err in get ' + str(getGuiSetting) +': ' + repr(e))
        pass
        webport = str(defaultsetting)  ### Default
    log(module,'getGuiSetting Configured ' + str(getGuiSetting) +': ' + repr(webport))
    return webport

def TVguide():
    try:
        TVguideNr= int(definition.ADDONgetSetting('tvguidenr'))
    except Exception as e:
        log(module,'err #661 Exception: %r' % e)
        pass
        TVguideNr = 0
        ADDONresetSetting('tvguidenr',str(TVguideNr))
    # 0= wozboxtvguide/roq tv rec|1= tvguide|2= ftvguide|3= ivueguide|4= custom (if empty search all known)|5= no tv guide search
    #log(module,'TVguideNr',repr(TVguideNr))
    if TVguideNr == 0:
        ###TVguide= [['script.wozboxtvguide2.0','source.db']]
        TVguide= [[ADDONid,'recordings_adc.db']]
    elif TVguideNr == 1:
        TVguide= [['script.tvguide','source.db']]
    elif TVguideNr == 2:
        TVguide= [['script.ftvguide','source.db']]
    elif TVguideNr == 3:
        TVguide= [['script.ivueguide','master.db']]
    elif TVguideNr == 4:
        #TVguide= [ ['script.tvguide','source.db']]
        ExtraGuide= ''
        ExtraGuideDB= ''
        ExtraGuidePathDB= definition.ADDONgetSetting('tvguidenotificationsDB')
        ExtraGuideList= ExtraGuidePathDB.split(os.sep)
        ExtraGuide= ExtraGuideList[-2]
        ExtraGuideDB= ExtraGuideList[-1]
        if ExtraGuide != '' and ExtraGuideDB != '':
            TVguide= [[ExtraGuide,ExtraGuideDB]]
        else:
            # If Extra TV Guide not complete - try all
            TVguide= [['script.wozboxtvguide2.0','source.db'], ['script.tvguide','source.db'],['script.ftvguide','source.db'],['script.ivueguide','master.db']]
    else:
        # No search in TV Guide
        TVguide= []
    #log(module,'findtvguidenotifications TVguide',repr(TVguide))
    if len(TVguide) != 0:
        ADDONresetSetting('activetvguide',repr(TVguide[0][0]))
    else:
        ADDONresetSetting('activetvguide','none')
    return TVguide
    
def ChannelNameLookuponWeb(cat):
    
    net.set_cookies(cookie_jar)
    imageUrl=definition.getBASEURL() + '/res/content/tv/'
    now= datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20')
    url='&mwAction=category&xbmc=1&mwData={"id":"%s","time":"%s","type":"tv"}'%('-2',now)
    
    link = net.http_GET(site+url, headers={'User-Agent' : UA}).content
    
    data = json.loads(link)
    channels=data['contents']
    
    for field in channels:
        channel      =  field['id']
        if channel == cat:
            name         =  field['name'].encode("utf-8")
            
            return name
    notification( 'NOT FOUND: channel= %s' % (cat))
    return 'no name'

def logdebug(module,message):
    if definition.ADDONgetSetting('DebugRecording')=='true':
        log(message)

def notificationUPD(message, time = 0):
    log(module,'1401 errorX NotificationUPD %r' % message)
    if notifyduringepgupdate:
        notificationforced(message, time)
      
def notificationforced(message, time = 0):
    log(module,'  notificationforced %r' % message)
    if 'scanning videos' in message.lower():
        log(module,'  notificationforced ignored %r' % message)
        return
    if (not definition.ADDONgetSetting('RecursiveSearch')=='true' or definition.ADDONgetSetting('NotifyOnSearch')=='true'):
        message = message.replace(',',  '')     ### No commas in text allowed
        if time == 0:
            try:
                time = int(definition.ADDONgetSetting('NotificationTime'))
            except Exception as e:
                log(module,'error #735: %r' % e)
                pass
            if time == 0:
                time = 30
        
        header = definition.getTITLE()
        cmd  = 'Notification(%s, %s, %r, %s)' % (header, message, time*1000, IMAGE)  ### 2023-04-26   
        
        try:
            window_id = xbmcgui.getCurrentWindowId()
            log(module,'err notificationforced window_id= %r' % window_id)
            win = xbmcgui.Window(window_id)
            window_f = win.getFocus()   ### Only continue if current window is in focus!
            log(module,'err notificationforced window_f= %r' % window_f)
            if xbmc.getCondVisibility('Player.HasMedia') != True:
                log(module,'error notificationforced cmd= %r' % cmd)
                xbmc.executebuiltin(cmd) 
        except Exception as e:
            log(module,'Exception 2019: %r' % e)
            pass
            log(module,'Windows Focus Error - No Notifications: %r' % e)  

def setAudioLevel(Level):  ### In procentage
    try:
        xbmc.executebuiltin('RunPlugin(%s?mode=1023,%s)'% (definition.DRLYD(),Level))
    except Exception as e:
        log(module,'setDefaultVideoLevel Excep: %r' % e)
        pass
        lastAudioLevel = definition.ADDONgetSetting('lastAudioLevel')
        log(module,'setAudioLevel lastAudioLevel= %r' % lastAudioLevel) 
        log(module,'setAudioLevel Level= %r' % Level) 
        xbmc.executebuiltin("SetVolume("+Level+",showvolumebar)")
        definition.ADDONresetSetting('lastAudioLevel',Level)
            
def setDefaultVideoLevel():
    try:
        xbmc.executebuiltin('RunPlugin(%s?mode=10232)'% (definition.DRLYD()))
    except Exception as e:
        log(module,'error setDefaultVideoLevel Excep: %r' % e)
        pass
        
        if xbmc.Player().isPlaying(): 
            xbmc.Player().stop()
        xbmc.sleep(500)
        volumenatvideo = definition.ADDONgetSetting('volumenatvideo')
        if volumenatvideo == '':
            volumenatvideo = '100'
            definition.ADDONresetSetting('volumenatvideo',volumenatvideo)
        log(module,'error setDefaultVideoLevel= %r' % volumenatvideo)  
        xbmc.executebuiltin("SetVolume("+volumenatvideo+",showvolumebar)")
        definition.ADDONresetSetting('lastAudioLevel',volumenatvideo)
     
def notification(message, time = 0):
    log(module,'1445 errorX Notification %r' % message)
    if (not definition.ADDONgetSetting('RecursiveSearch')=='true' or definition.ADDONgetSetting('NotifyOnSearch')=='true'):
        
        message = message.replace(',',  '')     ### No commas in text allowed
        
        log(module,'1450 errorX Notification: ' + message)
        ###if ADDONgetSetting('ShowNotifications') == 'true' and xbmc.getCondVisibility('Player.HasMedia') != True :
        if definition.ADDONgetSetting('ShowNotifications') == 'true' and xbmc.Player().isPlayingVideo() != True : ###Dont show during video play
            notificationforced(message, time)
    
def notificationboxadd(message):
    log(module,'1456 errorX Notificationboxadd %r' % message)
    oldmessage= definition.ADDONgetSetting('allmessages')
    if oldmessage == '':
        allmessages= message
    else:
        allmessages= message + '/' + oldmessage
    definition.ADDONresetSetting('allmessages',allmessages)
    
def notificationbox(message):
    log(module,'1465 errorZ Notificationbox %r' % message)
    oldmessage= definition.ADDONgetSetting('allmessages')
    if oldmessage == '':
        allmessages= message
    else:
        allmessages= message + '[CR]' + oldmessage
    definition.ADDONresetSetting('allmessages',allmessages)
    log(module,'notificationbox' + allmessages)
    ###if ADDONgetSetting('ShowNotifications') == 'true' and xbmc.getCondVisibility('Player.HasMedia') != True :
    if definition.ADDONgetSetting('ShowNotifications') == 'true' and xbmc.Player().isPlayingVideo() != True : ###Dont show during video play
        xbmcgui.Dialog().ok( ADDONgetAddonInfo('name'), allmessages)
    definition.ADDONresetSetting('allmessages','')

def SeriesEpisodeVOD(chan0):
    log(module,'err SeriesEpisodeVOD(chan0= %r)' % chan0)
    try:
        log(module,'err chan0= %r' % (chan0))
        SEs = re.findall(r'S(\d+)', chan0)
        chan0 = chan0.replace('S'+SEs[0],'¤',1)
        log(module,'err S(\d+) SEs= %r' % SEs)
        SEe = re.findall(r'E(\d+)', chan0)
        chan0 = chan0.replace('E'+SEe[0],'¤',1)
        chan2 = chan0.split('¤')
        chan1 = chan2[0]
        for chan3 in chan2:
            if len(chan3) > len(chan1):
                chan1 = chan3
        chan0 = chan1  ### take the longest part
        chan0 = ' '.join(chan0.split())  ## Remove doublespaces etc
        log(module,'err E(\d+) SEe= %r' % SEe)
        Length = int(SEs[0]) * 1000 + int(SEe[0])
    except Exception as e:
        pass
        log(module,'err in SeriesEpisodeVOD calculation of: %r\nERR: %r' % (chan0,e))
        Length = 0
    log(module,'err SeriesEpisodeVOD Length= %r\n%r' % (Length,chan0))
    return [Length,chan0]
    
def SeriesEpisode(chan0,org=''):
    try:
        chanorg = chan0
        sublength = 0
        log(module,'chan0= %r\nFrom %r' % (chan0,org))
        SE = re.findall(r'S(\d+)', chan0)
        log(module,'err S(\d+) SE= %r' % SE)
        SEe = re.findall(r'E(\d+)', chan0)
        log(module,'err E(\d+) SEe= %r' % SEe)
        SEf = re.findall(r'\((\d+)\)', chan0)
        log(module,'err \((\d+)\) SEf= %r' % SEf)
        chan0 = chan0.split('[20')[0]
        chan0 = chan0.replace(' XXX',' S30').replace(' XXIX',' S29').replace(' XXVIII',' S28').replace(' XXVII',' S27').replace(' XXVI',' S26').replace(' XXV',' S25').replace(' XXIV',' S24').replace(' XXIII',' S23').replace(' XXII',' S22').replace(' XXI',' S21').replace(' XX',' S20').replace(' XIX',' S19').replace(' XVIII',' S18').replace(' XVII',' S17').replace(' XVI',' S16').replace(' XV',' S15').replace(' XIV',' S14').replace(' XIII',' S13').replace(' XII',' S12').replace(' XI',' S11').replace(' IX',' S9').replace(' VIII',' S8').replace(' VII',' S7').replace(' VI',' S6').replace(' IV',' S4').replace(' III',' S3').replace(' II',' S2')
        if len(SE) == 0 and (len(SEe) != 0 or len(SEf) != 0):
            chan0 = chan0.replace(' X',' S10')
            SE = re.findall(r'S(\d+)', chan0)
            if len(SE) == 0 :
                chan0.replace(' V',' S5')
                SE = re.findall(r'S(\d+)', chan0)
                if len(SE) == 0 :
                    chan0.replace(' I',' S1')
        log(module,'err 1 chan0= %r' % chan0)
    except Exception as e:
        pass
        log(module,'err in XI series calculation %r' % e)
    Length = -1
    try:
        SE = re.findall(r'(\d+)', chan0)
        log(module,'err (\d+) SE= %r' % SE)
        Length = int(SE[0])
        log(module,'err Length= %r' % Length)
        if Length >= 1000:    ### Ignore year in title
            Length = 0
    except Exception as e:
        pass
        log(module,'SeriesEpisode -1 Err: %r' % e)
    try:
        SE1 = re.findall(r'Series (\d+):(\d+).', chan0)
        log(module,'err Series (\d+):(\d+). SE1= %r' % SE1)
        Length += int(SE1[0])*1000 + int(SE1[1])
        log(module,'err S(\d+) Length= %r' % Length)
        
    except Exception as e:
        pass
        log(module,'SeriesEpisode 4a Err: %r' % e)
    try:
        SE = re.findall(r'(\d+)-(\d+)', chan0)
        log(module,'err (\d+)-(\d+) SE= %r' % SE)
        if int(SE[0][0]) <= int(SE[0][1]):
            Length = int(SE[0][0])
            log(module,'err Length= %r' % Length)
    except Exception as e:
        pass
        log(module,'SeriesEpisode 0 Err: %r' % e)
    try:
        SE = re.findall(r'(\d+)x(\d+)', chan0)
        log(module,'err (\d+)x(\d+) SE= %r' % SE)
        Length = int(SE[0][0])*1000 + int(SE[0][1])
        log(module,'Length= %r' % Length)
    except Exception as e:
        pass
        log(module,'SeriesEpisode 1 Err: %r' % e)
    try:
        SE = re.findall(r'(\d+):(\d+)', chan0)
        log(module,'err (\d+):(\d+) SE= %r' % SE)
        Length = int(SE[0][0])
        log(module,'Length= %r' % Length)
    except Exception as e:
        pass
        log(module,'SeriesEpisode 1a Err: %r' % e)
    try:
        SE = re.findall(r'(\d+);(\d+)', chan0)
        log(module,'err (\d+);(\d+) SE= %r' % SE)
        Length = int(SE[0][0])
        log(module,'Length= %r' % Length)
    except Exception as e:
        pass
        log(module,'SeriesEpisode 1b Err: %r' % e)
    try:
        SE = re.findall(r'Season (\d+) Episode (\d+)', chan0)
        log(module,'err Season (\d+) Episode (\d+) SE= %r' % SE)
        Length = int(SE[0][0])*1000 + int(SE[0][1])
        log(module,'Length= %r' % Length)
    except Exception as e:
        pass
        log(module,'SeriesEpisode 2 Err: %r' % e)
    
    try:
        log(module,'err chan0= %r' % chan0)
        SE = re.findall(r'\((\d+)\)', chan0)
        log(module,'err \((\d+)\) SE= %r' % SE)
        Length = int(SE[0])
        log(module,'err \((\d+)\) Length= %r' % Length)
        if SE[0] != '0' and Length < 1000:
            chan0 = chan0.replace('('+SE[0]+')','E'+SE[0])
        else:
            Length = 0
        log(module,'err \((\d+)\) SE= %r' % SE)
        log(module,'err chan0= %r' % chan0)
    except Exception as e:
        pass
        log(module,'SeriesEpisode 3 Err: %r' % e)
    
    try:
        log(module,'err chan0= %r' % chan0)
        SE = re.findall(r'E(\d+)', chan0)
        log(module,'err E(\d+) SE= %r' % SE)
        Length = int(SE[0])
        log(module,'err E(\d+) Length= %r' % Length)
    except Exception as e:
        pass
        log(module,'SeriesEpisode 3a Err: %r' % e)
    try:
        ###log(module,'  subepisode E(\d+).\d chan0= %r' % chan0)
        """
        SE = re.findall(r"E(\d+)\.(\d+)", chan0)

        a, b = SE[0]          # pak tuple ud
        a = int(a)
        b = int(b)
        """
        SE = re.findall(r'E(\d+)-(\d+)', chan0)
        log(module,'  subepisode E(\d+).\d chan0= %r, SE= %r' % (chan0, SE))
        if SE != []:
            Length1, sublength = SE[0]
            log(module,'  subepisode E(\d+).\d Length1= %r, sublengthE= %r' % (Length1, sublength))
            if sublength != '0' :
                Length = 0
                log(module,'set   subepisode E(\d+)\.(\d) Length= %r' % Length)
                sublength = int(sublength)
                log(module,'set   subepisode= %r' % sublength)
    except Exception as e:
        log(module,'Exception subepisode %r' % e)
        pass
        
    try:
        SE1 = re.findall(r'S(\d+)', chan0)
        log(module,'err S(\d+) SE1= %r' % SE1)
        Length += int(SE1[0])*1000
        log(module,'err S(\d+) Length= %r' % Length)
    except Exception as e:
        pass
        log(module,'SeriesEpisode 4a Err: %r' % e)
    try:
        SE1 = re.findall(r'Series (\d+): (\d+).', chan0)
        log(module,'err Series (\d+): (\d+). SE1= %r' % SE1)
        Length = int(SE1[0][0])*1000 + int(SE1[0][1])
        log(module,'err S(\d+) Length= %r' % Length)
        
    except Exception as e:
        pass
        log(module,'SeriesEpisode 4a Err: %r' % e)
    try:
        SE1 = re.findall(r'aar (\d+)', chan0)
        log(module,'err aar (\d+) SE1= %r' % SE1)
        SE2 = int(SE1[0])*1000
        if SE2 >= 1000:
            Length = Length%1000 ### skip previous Series
            Length += int(SE1[0])*1000
        log(module,'err S(aar) Length= %r' % Length)
    except Exception as e:
        pass
        log(module,'SeriesEpisode 4 Err: %r' % e)
    try:
        SE1 = re.findall(r'år (\d+)', chan0)
        log(module,'err aar (\d+) SE1= %r' % SE1)
        SE2 = int(SE1[0])*1000
        if SE2 >= 1000:
            Length = Length%1000 ### skip previous Series
            Length += int(SE1[0])*1000
        log(module,'err S(år) Length= %r' % Length)
    except Exception as e:
        pass
        log(module,'SeriesEpisode 5 Err: %r' % e)
    try:
        if Length < 1000 :  ### S0   2022-08-13 
            SE1 = re.findall(r'(\d\d\d\d)', chan0)
            Length += int(SE1[0])*1000
    except Exception as e:
        pass
        log(module,'SeriesEpisode 6a Err: %r' % e)
    try:
        if Length < 1000 :  ### S0   2022-08-13 
            SE1 = re.findall(r' \d\d\d\d ', chan0)
            Length += int(SE1[0])*1000
    except Exception as e:
        pass
        log(module,'SeriesEpisode 6 Err: %r' % e)
    log(module,'err final Length= %r' % Length)
    log(module,'err SeriesEpisode= %r\n%r\n%r\nFrom %r' % (Length,chanorg,chan0,org))
    """
    try:
        if '¤' in chan0 :
            log(module,'Exception subepisode chan0= %r' % chan0)
            SE2 = re.findall(r'¤\d', chan0)
            sublength = int(SE2[0])
            log(module,'Exception subepisode= %r' % sublength)
    except Exception as e:
        log(module,'Exception subepisode #2451 %r' % e)
        pass
    """
    ###Length = (Length *1000 + sublength)/1000
    log(module,'  subepisode= %r' % Length)
    return Length
"""
2022-09-10 10:30:05 err: <*
utils.py: err FileManagerPath 1 files= '\n            <path pathversion="1">W:\\Recordings\\</path>\n            <allowsharing>true</allowsharing>\n        </source>\n        <source>\n            <name>Videos</name>\n            <path pathversion="1">W:\\Videos\\</path>\n            <allowsharing>true</allowsharing>\n        </source>\n        <source>\n            <name>logs</name>\n            <path pathversion="1">smb://CoreELEC:445/Holt2_128GB/logs/</path>\n            <allowsharing>true</allowsharing>\n        </source>\n    </files>\n    <games>\n        <default pathversion="1"></default>\n    </games>\n</sources>\n'
"""
def FileManagerPath(PathInput):
    try:
        sources = xbmcvfs.translatePath('special://masterprofile/sources.xml')
        file = open(sources,'r', encoding = 'utf-8')
        allsources = file.read()
        files = allsources.split('<files>')[1]
        log(module,'err FileManagerPath files= %r' % files)
        searchtext = '<name>'+PathInput+'</name>'
        log(module,'err FileManagerPath searchtext= %r' % searchtext)
        files = files.split(searchtext)[1]
        log(module,'err FileManagerPath 1 files= %r' % files)
        files = files.split('>')[1]
        log(module,'err FileManagerPath 3 files= %r' % files)
        Path = files = files.split('</path')[0]
        
    except Exception as e:
        pass
        Path = PathInput
        log(module,'err in FileManagerPath= %r' % e)
        
    return Path    

def diskStat(disk):
    try:
        diskp = xbmcvfs.translatePath(disk)
        st_size=sizeGMKb(diskp.stat().st_size)
        definition.ADDONsetSetting('disksize',st_size)
    except Exception as e:
        pass
        eExcept = 'error in diskStat disk= %r, Except %r' % (diskp,e)
        log(module,eExcept)
        eExcept = 'error in diskStat disk= %r, Except %r' % (disk,e)
        definition.ADDONsetSetting('disksize',eExcept)
        
def human_size(num,module=module):
    log(module,'human_size(num= %r)'% num)
    if isinstance(num, (int, float, complex)):
        for unit in [" b", " Kb", " Mb", " Gb", " Tb"]:
            if num < 1024:
                log(module,'human_size(num)= %r'% (f"{num:.2f} {unit}"))
                return f"{num:.2f} {unit}"
            num /= 1024
    else:
        return 'Size unknown'
        
def filesize(file, module = module):
    try:
        log(module,'filesize(file= %r)' % file)
        if os.path.exists(file) :
            size = os.path.getsize(file)
            log(module,'filesize(size= %r, file= %r)' % (size,file))
            return human_size(size)
        else:
            return ' No File'
    except Exception as e:
        ex = 'size Exception: %r' % e
        log(module,ex)
        pass
        return ex
        
def filesizeint(file, module = module):
    try:
        log(module,'2894 filesizeint(file= %r)' % file)
        if os.path.exists(file) :
            size = os.path.getsize(file)
            log(module,'2897 filesizeint(size= %r, file= %r)' % (size,file))
            return size
        else:
            return -1
    except Exception as e:
        ex = '2901 filesizeint Exception: %r' % e
        log(module,ex)
        pass
        return -1
        
def filedata(file, module = module):
    log(module,'Exception  filedata (size= %r, file= %r)' % (filesize(file),file))
     
def sizeGMKb(size, module = module):
    log(module,'size= %r' % size) 
    human_size(size)
    
    ###size = os.path.getsize("myfile.txt")
    ###return(human_size(size))
    """
    try:
        ###sizetxt = '%.3f' % (size/1000)
        ###log(module,'error sizetxt.3f= %r' % sizetxt)
        if size > 1000000000 :
            sizetxt = '%.3f' % (size/1000000000) + ' Gb'
        elif size > 1000000 :
            sizetxt = '%.3f' % (size/1000000) + ' Mb'
        elif size > 1000 :
            sizetxt = '%.3f' % (size/1000) + ' Kb'
        elif size > 0 :
            sizetxt = str(size) + ' b'
        else:
            sizetxt = ''
    except Exception as e:
        log(module,'size Except: %r' % e)
        pass
        sizetxt = ''
    log(module,'sizetxt= %r' % sizetxt) 
    return sizetxt
    """

def maxonceperhour():
    try:
        now= datetime.datetime.now()
        log(module,'2513   now %r' % now)
        lastfailed3gb = definition.ADDONgetSetting('lastfailed3gb')
        log(module,'2515   lastfailed3gb %r' % lastfailed3gb)
        lastfailed3gbts = tsds(lastfailed3gb)
        log(module,'2517   lastfailed3gbts %r' % lastfailed3gbts)
        limit = tsdt(now - datetime.timedelta(hours=1))
        log(module,'2519   limit= %r lastfailed3gbts= %r diff= %r' % (limit, lastfailed3gbts, limit-lastfailed3gbts))
        log(module,'2520   limit= %r lastfailed3gbts= %r diff= %r' % (ht(limit), ht(lastfailed3gbts), limit-lastfailed3gbts))
        if limit-lastfailed3gbts > 0:
            log(module,'2522   limit= %r lastfailed3gbts= %r diff= %r' % (ht(limit), ht(lastfailed3gbts), limit-lastfailed3gbts))
            definition.ADDONsetSetting('lastfailed3gb','%r' % now)
            return False
        else:
            return True
    except Exception as e:
        log(module,'2527 Exception: %r' % e)    
        definition.ADDONsetSetting('lastfailed3gb','%r' % now)
        return True   
        
def folderwritable(path, cmodule=''):
    log(module,'folderwritable(path= %r) in module: %r' % (path,cmodule))
    
    autoclose=15000
    freeGB = definition.ADDONgetSetting('record_path_size')
    if freeGB == '':
        freeGB = 0
    else:
        try:
            freeGB = int(freeGB)
        except Exception as e:
            pass
            log(module,'err in folderwritable= %r' % e)
            freeGB = 0
    enable_record = definition.ADDONgetSetting('enable_record')
    log(module,'error ADDONgetSetting(enable_record)= %r' % enable_record)
    if os.access(path, os.W_OK) or enable_record == 'false':
        log(module,'error OK-1 folderwritable(path= %r)' % path)
        return True
    elif freeGB < 1:
        if not maxonceperhour():
            if xbmcgui.Dialog().yesno( ADDONgetAddonInfo('name'), '[COLOR red]utils.py folderwritable: ERROR[/COLOR]\n' + path + ' [empty path]\nNo room on folder! \nGoto Settings/Recording/Set Record Path \nand set that to a writable path \nor disable recording',autoclose=autoclose) :  ### 2022-03-01
                return True
            else:
                return False
    else:
        if '://' in path:
            log(module,'error OK-2 folderwritable(path= %r)' % path)
            return True
        else:
            if os.access(path, os.W_OK):
                log(module,'error OK-3 folderwritable(path= %r)' % path)
                return True
            if path=='':
                path = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_path')))
                log(module,'error empty folderwritable(path= %r)' % path)
                if os.access(path, os.W_OK):
                    log(module,'error OK-4 folderwritable(path= %r)' % path)
                    return True
                if path=='':
                    if xbmcgui.Dialog().yesno( ADDONgetAddonInfo('name'), "[COLOR red]utils.py folderwritable: ERROR[/COLOR]\n[Empty path]\nThe folder is not writable! \nDon't Goto Settings/Recording/Set Record Path \nand set that to a writable path \nor disable recording",autoclose=autoclose) : 
                        return False
                    else:
                        return True   ### 2022-03-01
            else:
                log(module,'error folderwritable(path= %r)' % path)
                if xbmcgui.Dialog().yesno( ADDONgetAddonInfo('name'), "[COLOR red]utils.py folderwritable: ERROR[/COLOR]\n' + path + '\nThe folder is not writable! \nDon't Goto Settings/Recording/Set Record Path \nand set that to a writable path \nor disable recording",autoclose=autoclose) :  ### 2022-03-01
                    return False
                else:
                    return True

def filterfalse(predicate, iterable):
    # filterfalse(lambda x: x%2, range(10)) --> 0 2 4 6 8
    if predicate is None:
        predicate = bool
    for x in iterable:
        if not predicate(x):
            yield x

def unique_everseen(iterable, key=None):
    "List unique elements, preserving order. Remember all elements ever seen."
    # unique_everseen('AAAABBBCCDAABBB') --> A B C D
    # unique_everseen('ABBCcAD', str.lower) --> A B C D
    seen = set()
    seen_add = seen.add
    if key is None:
        for element in filterfalse(seen.__contains__, iterable):
            seen_add(element)
            yield element
    else:
        for element in iterable:
            k = key(element)
            if k not in seen:
                seen_add(k)
                yield element

def uniquecolon(items):
    # ###print 'utils.py uniquecolon(items)= %s' % repr(items) 
    listitems=items.split(':')
    result=':'.join(unique_everseen(listitems))
    # ###print 'utils.py uniquecolon(items) result= %s' % repr(result) 
    return result
    
def FindPlatform():
    # Find the actual platform
    Platform = ''
    try:
        kodilog = xbmcvfs.translatePath(os.path.join('special://logpath' , 'kodi.log'))
        try: csvfile = open(kodilog,'r')
        except Exception as e:
            log(module,'err #1028 Except: %r' % e)
            pass
            kodilog = xbmcvfs.translatePath(os.path.join('special://logpath' , 'xbmc.log'))
            try: csvfile = open(kodilog,'r')
            except Exception as e:
                log(module,'err #1033 Except: %r' % e)
                pass
                kodilog = xbmcvfs.translatePath(os.path.join('special://logpath' , 'tvmc.log'))
                try: csvfile = open(kodilog,'r')
                except Exception as e:
                    log(module,'err #1038 Except: %r' % e)
                    pass
                    kodilog = xbmcvfs.translatePath(os.path.join('special://logpath' , 'spmc.log'))
                    try: csvfile = open(kodilog,'r')
                    except Exception as e:
                        log(module,'err #1043 Except: %r' % e)
                        pass
                        log(module,'ERROR FindPlatform csvfile not found')
                    """
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: -----------------------------------------------------------------------
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: Starting Kodi (18.2 Git:20190422-f264356). Platform: Linux x86 64-bit
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: Using Release Kodi x64 build
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: Kodi compiled 2019-04-22 by GCC 7.3.0 for Linux x86 64-bit version 4.15.18 (266002)
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: Running on Ubuntu 18.04.2 LTS, kernel: Linux x86 64-bit version 4.18.0-17-generic
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: FFmpeg version/source: 4.0.3-Kodi
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: Host CPU: Intel(R) Core(TM) i7-3517U CPU @ 1.90GHz, 4 cores available
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: special://xbmc/ is mapped to: /usr/share/kodi
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: special://xbmcbin/ is mapped to: /usr/lib/x86_64-linux-gnu/kodi
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: special://xbmcbinaddons/ is mapped to: /usr/lib/x86_64-linux-gnu/kodi/addons
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: special://masterprofile/ is mapped to: /home/hans/.kodi/userdata
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: special://envhome/ is mapped to: /home/hans
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: special://home/ is mapped to: /home/hans/.kodi
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: special://temp/ is mapped to: /home/hans/.kodi/temp
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: special://logpath/ is mapped to: /home/hans/.kodi/temp
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: The executable running is: /usr/lib/x86_64-linux-gnu/kodi/kodi-x11
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: Local hostname: fabses-UX31A
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: Log File is located: /home/hans/.kodi/temp/kodi.log
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: -----------------------------------------------------------------------
                    """


        line = csvfile.readline()   ### Read first 8 lines
        line += csvfile.readline()
        line += csvfile.readline()
        line += csvfile.readline()
        line += csvfile.readline()
        line += csvfile.readline()
        line += csvfile.readline()
        line += csvfile.readline()
        Platform = line.split('Platform: ')[1].split('-bit')[0].strip()+'-bit'
        definition.ADDONresetSetting('platform',Platform)
        RunningOn = line.split('Running on ')[1].split(' ')[0].strip()
        definition.ADDONresetSetting('runningon',RunningOn)
        log(module,'Platform'+ repr(definition.ADDONgetSetting('platform')))   # Put in LOG
        log(module,'RunningOn'+ repr(definition.ADDONgetSetting('runningon')))   # Put in LOG
        log(module,'OS'+ os.environ['OS'])  # Put in LOG
    except Exception as e: 
        log(module,'#2473 Except: %r' % e)
        pass
        log(module,'FindPlatform ERROR FAILED: ' + repr(e))   # Put in LOG
    finally:
        csvfile.close()
    return Platform

def rtmpdumpFilename():
    if definition.ADDONgetSetting('DebugRecording')=='false': #dont update Paltform if debugging recordings
        try:
            Platform = FindPlatform()
            definition.ADDONresetSetting('osplatform','')
            if Platform == 'Windows NT x86 32-bit':
                definition.ADDONresetSetting('os','11')
            elif Platform == 'Windows NT x86 64-bit':
                definition.ADDONresetSetting('os','11')
            elif Platform == 'Android ARM 32-bit':
                definition.ADDONresetSetting('os','13')
            elif Platform == 'Android x86 32-bit':
                definition.ADDONresetSetting('os','13')
            elif Platform == 'Linux x86 64-bit':
                definition.ADDONresetSetting('os','7')
            elif Platform == 'Linux x86 32-bit':
                definition.ADDONresetSetting('os','6')
            else:
                log(module,'rtmpdumpFilename:  Your platform= %s has not been set automatically!' % repr(Platform))  # Put in LOG
        except Exception as e:
            log(module,'err #1112 Except: %r' % e)
            pass
            log(module,'rtmpdumpFilename:  ERROR Failed to automatically update platform!')  # Put in LOG
        definition.ADDONresetSetting('osplatform',definition.ADDONgetSetting('os'))
        log(module,'rtmpdumpFilename Running on %s' % repr( definition.ADDONgetSetting('runningon')))
        if 'OpenELEC' in definition.ADDONgetSetting('runningon'):
            definition.ADDONresetSetting('os','12')
        if 'samsung' in definition.ADDONgetSetting('runningon'):
            definition.ADDONresetSetting('os','13')
        if 'WOZTEC' in definition.ADDONgetSetting('runningon'):
            definition.ADDONresetSetting('os','13')
        if 'MBX' in definition.ADDONgetSetting('runningon'): 
            definition.ADDONresetSetting('os','13')
        if 'Genymotion' in definition.ADDONgetSetting('runningon'): 
            definition.ADDONresetSetting('os','13')
        # Enable the following two lines to test running on Ubuntu!
        #if 'Ubuntu' in ADDONgetSetting('runningon'):  # ONLY TEST
        #   ADDONresetSetting('os','13')
    quality = definition.ADDONgetSetting('os')
    log(module,'rtmpdumpFilename quality= %s' %quality)
    #if quality == '0':
    #   return 'androidarm/rtmpdump'
    #elif quality == '1':
    #   return 'android86/rtmpdump'
    #el
    if quality == '2':
        return 'atv1linux/rtmpdump'
    elif quality == '3':
        return 'atv1stock/rtmpdump'
    elif quality == '4':
        return 'atv2/rtmpdump'
    elif quality == '5':
        return 'ios/rtmpdump'
    elif quality == '6':
        return 'linux32/rtmpdump'
    elif quality == '7':
        return 'linux64/rtmpdump'
    elif quality == '8':
        return 'osx106/rtmpdump'
    elif quality == '9':
        return 'osx107/rtmpdump'
    elif quality == '10':
        return 'pi/rtmpdump'
    elif quality == '11':
        return 'win/rtmpdump.exe'
    elif quality == '12':
        return '/usr/bin/rtmpdump'
    elif quality == '13' or quality == '0' or quality == '1':
        return  '/system/vendor/bin/rtmpdump' # HOTFIX Android - rtmpdump moved to /system/bin (using build in librtmp.so from kodi)
    else:
        log(module,'rtmpdumpFilename: Your platform= %s has not been set automatically!' % repr(Platform))  # Put in LOG
        return

def libPath():
    quality = definition.ADDONgetSetting('os')
    log(module,'libPath quality= %s' %quality)
    #if quality == '0':
    #   return os.path.join(ADDONgetAddonInfo('path'),'rtmpdump', 'androidarm')
    #elif quality == '1':
    #   return os.path.join(ADDONgetAddonInfo('path'),'rtmpdump', 'android86')
    #el
    if quality == '2':
        return os.path.join(ADDONgetAddonInfo('path'),'rtmpdump', 'atv1linux')
    elif quality == '3':
        return os.path.join(ADDONgetAddonInfo('path'),'rtmpdump', 'atv1stock')
    elif quality == '4':
        return os.path.join(ADDONgetAddonInfo('path'),'rtmpdump', 'atv2')
    elif quality == '5':
        return os.path.join(ADDONgetAddonInfo('path'),'rtmpdump', 'ios')
    elif quality == '6':
        return os.path.join(ADDONgetAddonInfo('path'),'rtmpdump', 'linux32')
    elif quality == '7':
        return os.path.join(ADDONgetAddonInfo('path'),'rtmpdump', 'linux64')
    elif quality == '8':
        return os.path.join(ADDONgetAddonInfo('path'),'rtmpdump', 'osx106')
    elif quality == '9':
        return os.path.join(ADDONgetAddonInfo('path'),'rtmpdump', 'osx107')
    elif quality == '10':
        return os.path.join(ADDONgetAddonInfo('path'),'rtmpdump', 'pi')
    elif quality == '11':
        return 'None'   
    elif quality == '12':
        return '/usr/bin/'
    elif quality == '13' or quality == '0' or quality == '1':
        LIBpath = '/data/data/org.xbmc.kodi/lib/'
        log(module,'libPath: os.path.exists(%s)= %s' % (repr(LIBpath),repr(os.path.exists(LIBpath))))  # Put in LOG
        log(module,'libPath: os.path.exists(%s)= %s' % (repr(LIBpath + 'librtmp.so'),repr(os.path.exists(LIBpath + 'librtmp.so'))))  # Put in LOG
        return LIBpath
"""
def runCommandTest(cmd):
    log(module,'runCommandTest cmd= %s' % repr(cmd)) # Put in LOG
    
    # subpr = Popen(cmd, shell=True, env=env, stdin=PIPE, stdout=PIPE, stderr=STDOUT) # original
    quality = ADDONgetSetting('os')
    if quality=='13' or  quality=='0' or quality=='1':
        subpr = Popen(cmd, executable='/system/bin/sh', shell=True, close_fds=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT)
    else:
        subpr = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT) 

    x = subpr.stdout.read()
    log(module,'runCommandTest x= %r' % x) # Put in LOG
    expectedresult = 'copyright'   ### 2017-12-16
    if expectedresult.lower() in x.lower():
        return True
    expectedresult = '(c)'   ### 2017-12-16
    if expectedresult.lower() in x.lower():
        return True
    else:
        return False  
"""
        
def runCommandTest(cmd):
    log(module,'err runCommandTest: 1.cmd= %r' % cmd) # Put in LOG
    # subpr = Popen(cmd, shell=True, env=env, stdin=PIPE, stdout=PIPE, stderr=STDOUT) # original
    quality = definition.ADDONgetSetting('os')
    log(module,'err runCommandTest: 2.quality= %r' % quality) # Put in LOG
    try:
        if quality != 'X':  ###Always use this path
            try:
                subpr = Popen(cmd, executable='/system/bin/sh', shell=True, close_fds=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT)
                log(module,'errrunCommandTest: 3.subpr= %r' % subpr) # Put in LOG
            except Exception as e:
                log(module,'#1234  %r' % e)
                pass
                log(module,'runCommandTest: 4. Err= %r' % e) # Put in LOG
                try:
                    subpr = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT)
                    log(module,'runCommandTest: 5.subpr= %r' % subpr) # Put in LOG
                except Exception as e:
                    log(module,'#2629 Except %r' % e)
                    pass
                    log(module,'runCommandTest: 6. Err= %r' % e) # Put in LOG
                    return False
        elif quality=='13' or  quality=='0' or quality=='1':
            subpr = Popen(cmd, executable='/system/bin/sh', shell=True, close_fds=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT)
        else:
            subpr = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT) 

        x = subpr.stdout.read(1024).decode()   ### Only read first part of output
        log(module,'err runCommandTest: 7.x= %r' % x) # Put in LOG
        expectedresult = 'copyright'   ### 2017-12-16
        if expectedresult.lower() in x.lower():
            return True
        expectedresult = '(c)'   ### 2017-12-16
        if expectedresult.lower() in x.lower():
            return True
        expectedresult = 'BusyBox'   ### 2018-05-26 xz on LibreELEC
        if expectedresult.lower() in x.lower():
            return True
        expectedresult = 'usage: mkchromecast'   ### 2018-05-26 mkchromecast on Ubuntu
        if expectedresult.lower() in x.lower():
            return True
        expectedresult = 'usage: vlc-cache-gen'
        if expectedresult.lower() in x.lower():
            return True
        else:
            return False 
    except Exception as e:
        log(module,'#2658 Except: %r' % e)
        pass
        log(module,'runCommandTest: 8. Err= %r' % e) # Put in LOG
        return False
        
def runCommand(cmd, LoopCount, libpath = None, module_path = './', nameAlarm=''):
    log(module,'err runCommand: cmd= %s' % repr(cmd)) # Put in LOG
    log(module,'err runCommand: LoopCount= %s' % repr(LoopCount)) # Put in LOG
    log(module,'err runCommand: libpath= %s' % repr(libpath)) # Put in LOG
    log(module,'err runCommand: module_path= %s' % repr(module_path)) # Put in LOG
    log(module,'err runCommand: nameAlarm= %s' % repr(nameAlarm)) # Put in LOG
    from subprocess import Popen, PIPE, STDOUT
    # get the list of already defined env settings
    env = os.environ
    log(module,'runCommand: env= %s' % env)
    if LoopCount == 0:
        if (libpath):
            log(module,'runCommand: libpath1= %s' %repr(libpath))
            # add the additional env setting
            envname = "LD_LIBRARY_PATH"
            ###if (env.has_key(envname)):
            if envname in env:
                env[envname] = env[envname] + ":" + libpath
                env[envname]=uniquecolon(env[envname])
            else:
                env[envname] = libpath
            envname = "DYLD_LIBRARY_PATH"
            if envname in env:
                env[envname] = uniquecolon(env[envname] + ":" + libpath)
            else:
                env[envname] = libpath
        envname = 'PYTHONPATH'
        if envname in env:
            env[envname] = uniquecolon(env[envname] + ":" + module_path)
        else:
            env[envname] = module_path
    try:
        log(module,'err runCommand: env[PYTHONPATH] = ' + env['PYTHONPATH'])  # Put in LOG
        log(module,'err runCommand: env[LD_LIBRARY_PATH] = ' + env['LD_LIBRARY_PATH']) # Put in LOG
        log(module,'err runCommand: env[DYLD_LIBRARY_PATH] = ' + env['DYLD_LIBRARY_PATH'])  # Put in LOG
    except Exception as e:
        log(module,'#2699 Except: %r' % e)
        pass

    # subpr = Popen(cmd, shell=True, env=env, stdin=PIPE, stdout=PIPE, stderr=STDOUT) # original
    try:
        quality = definition.ADDONgetSetting('os')
        if quality=='13' or  quality=='0' or quality=='1':
            subpr = Popen(cmd, executable='/system/bin/sh', shell=True, close_fds=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT)
        else:
            subpr = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT) 
        log(module,'err subpr= %r' % subpr)
    except Exception as e:
        log(module,'#2711 Except: %r' % e)
        pass
        subpr = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT)
        log(module,'runCommand: Err Popen \ncmd= %r\npid= %r' % (cmd,e))
        nowHM=datetime.datetime.today().strftime('%H:%M')
        ##recordings.updateRecordingPlanned(nameAlarm, '[COLOR red]Error ' + nowHM + '[/COLOR] ' + title + ' - ' + e)
    try:
        subprpid = subpr.pid
        if subprpid != 0 and definition.ADDONgetSetting('timeshiftbase') in cmd:  ### Only save TimeShift processes
            xbmcgui.Window(10000).setProperty(ADDONname + 'subprpid', repr(subprpid))
            xbmcgui.Window(10000).setProperty(ADDONname + 'subprcmd', cmd)
            log(module,'runCommand: TimeShift set pid= %r, cmd= %r' % (subprpid, cmd))
        else:
            log(module,'runCommand: NOT TimeShift pid= %r, cmd= %r' % (subprpid, cmd))
        if subprpid != 0 and 'mkchromecast' in cmd:
            definition.ADDONresetSetting('castsubpr',repr(subprpid))
            definition.ADDONresetSetting('castsubprcmd',cmd)
    except Exception as e:
        log(module,'#2729 Except: %r' % e)
        pass
        log(module,'runCommand: Err save \ncmd= %r\nErr: %r' % (cmd,e))
        nowHM=datetime.datetime.today().strftime('%H:%M')
        ##recordings.updateRecordingPlanned(nameAlarm, '[COLOR red]Error ' + nowHM + '[/COLOR] ' + title + ' - ' + e)
    try:
        x = subpr.stdout.read().decode()   ### 2019-05-02  Read last characters?
    except Exception as e:
        pass
        log(module,'#2738 subpr.stdout.read().decode() Except: %r' % e)
        x = subpr.stdout.read()   ### 2022-10-12
    log(module,'#2740 subpr.stdout.read()= %r' % x)
    #xbmcgui.Dialog().ok( ADDONgetAddonInfo('name'), 'Test runCommand: 1', '', repr(x[-100:]))
    #xbmcgui.Dialog().input('Test runCommand: 1 \n' + repr(x[-100:]), defaultt='', type=xbmcgui.INPUT_ALPHANUM, autoclose=5000)
    if definition.ADDONgetSetting('DebugRecording')=='true':
        log(module,'runCommand: subpr.stdout.read()= %s' % repr(x))
        if 'ERROR' in x:
            xError=x.replace('\n','[cr]')
            notification('[COLOR red]ERROR utils.py runCommand: Basic recording function failed![/COLOR]')
            xbmcgui.Dialog().ok( ADDONgetAddonInfo('name'), 'utils.py runCommand: ERROR', '', repr(xError))
    xbmc.sleep(2000)
    ###time.sleep(2)
    while subpr.poll() == None:
        xbmc.sleep(2000)
        ###time.sleep(2)
        x = subpr.stdout.read()   ### 2019-05-02  Read last characters?
        #xbmcgui.Dialog().ok( ADDONgetAddonInfo('name'), 'Test runCommand: 1', '', repr(x[-100:]))
        #xbmcgui.Dialog().input('Test runCommand: 2 \n' + repr(x[-100:]), defaultt='', type=xbmcgui.INPUT_ALPHANUM, autoclose=5000)
        if definition.ADDONgetSetting('DebugRecording')=='true':
            if 'ERROR' in x:
                xError=x.replace('\n','[cr]')
                notification('[COLOR red]ERROR utils.py runCommand: Basic recording function failed![/COLOR]')
                xbmcgui.Dialog().ok( ADDONgetAddonInfo('name'), 'utils.py runCommand: ERROR in Loop', '', repr(xError))
    return subpr    ### 2018-02-25

def terminateSubpr(subpr):  
    ### Popen.terminate()
    """
    There's a very good explanation of how to create a new process group with python subprocess. Adding option preexec_fn=os.setsid to Popen:

process_Festival = subprocess.Popen(["festival", "--tts", "/var/log/dmesg"],preexec_fn=os.setsid)
You can then get the process group from the process id and signal it:

pgrp = os.getpgid(process_Festival.pid)
os.killpg(pgrp, signal.SIGINT)

Popen("TASKKILL /F /PID {pid} /T".format(pid=process.pid))

    """
    record_path = definition.ADDONgetSetting('record_path')
    platform    = definition.ADDONgetSetting('platform')
    runningon   = definition.ADDONgetSetting('runningon')
    osplat      = definition.ADDONgetSetting('os')
    log(module,'err record_path= %r, platform= %r, runningon= %r, os= %r' % (record_path, platform, runningon, osplat)) 
    
    try:
        if osplat == '11':
            Popen("TASKKILL /F /PID {pid} /T".format(pid=int(subpr)))
            log(module,'subpr.terminate on Windows (%r)' % (subpr)) 
    except Exception as e:
        log(module,'#2789 Except: %r' % e)
        pass
        log(module,'Popen(TASKKILL /F /PID {pid} /T (%r) Err= %r' % (subpr,e)) 
    try:
        if osplat == '7':
            os.kill(int(subpr), signal.SIGINT)
            log(module,'subpr.terminate 7(%r)' % (subpr)) 
    except Exception as e:
        log(module,'#2797 Except: %r' % e)
        pass
        log(module,'subpr.terminate 7(%r) Err= %r' % (subpr,e)) 
          
    try:
        if osplat != '11' and osplat != '7':
            pgrp = os.getpgid(int(subpr))
            os.killpg(pgrp, signal.SIGINT)
            #os.killpg(pgrp, signal.SIGHUP)
            #os.killpg(pgrp, signal.SIGTERM)
            #os.killpg(pgrp, signal.SIGKILL)
            log(module,'subpr.terminate tree(%r)' % (subpr)) 
    except Exception as e:
        log(module,'#2810 Except: %r' % e)
        pass
        log(module,'subpr.terminate tree(%r) Err= %r' % (subpr,e)) 
        try:
            ### If you kill festival with a signal like SIGHUP rather than SIGKILL it will clean up any subprocesses properly.
            #os.kill(int(subpr), signal.SIGINT) # signal.SIGKILL or signal.SIGTERM
            #os.kill(int(subpr), signal.SIGHUP) # signal.SIGKILL or signal.SIGTERM
            os.kill(int(subpr), signal.SIGTERM) 
            #os.kill(int(subpr), signal.SIGKILL) 
            log(module,'subpr.terminate %r)' % (subpr)) 
        except Exception as e:
            log(module,'err #1426 Exception: %r' % e)
            pass
            log(module,'subpr.terminate(%r) Err= %r' % (subpr,e)) 
    log(module,'subpr.terminate() ACTIVATED!')    ### 2018-02-25
"""    
def terminateSubprOLD(subpr):  
    ### Popen.terminate()
    try:
        import os
        import signal

        os.kill(int(subpr), signal.SIGTERM) #or signal.SIGKILL 
        ### subpr.terminate()     ### 2018-02-25
        log(module,'subpr.terminate(%r)' % (subpr)) 
    except Exception as e:
        log(module,'err #1441 Exception: %r' % e)
        pass
        log(module,'subpr.terminate(%r) Error= %r' % (subpr,e)) 
    log(module,'subpr.terminate() ACTIVATED!')    ### 2018-02-25
"""    
def datetimeconversions():
    # Test date time conversions on this system
    #-------------------------------------------------
    # conversions to strings
    #-------------------------------------------------
    # datetime object to string
    dt_obj = datetime.datetime(2008, 11, 10, 17, 53, 59)
    date_str = dt_obj.strftime("%Y-%m-%d %H:%M:%S")
    ###print date_str

    # time tuple to string
    time_tuple = (2008, 11, 12, 13, 51, 18, 2, 317, 0)
    date_str = time.strftime("%Y-%m-%d %H:%M:%S", time_tuple)
    ###print date_str

    #-------------------------------------------------
    # conversions to datetime objects
    #-------------------------------------------------
    # time tuple to datetime object
    time_tuple = (2008, 11, 12, 13, 51, 18, 2, 317, 0)
    dt_obj = datetime.datetime(*time_tuple[0:6])
    ###print 'datetime.datetime(*time_tuple[0:6])'
    ###print repr(dt_obj)
    ###print str(dt_obj)
    
    # date string to datetime object
    date_str = "2008-11-10 17:53:59"
    ##fejler## dt_obj = datetime.datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")
    date_str = "2008-11-10 17:53:59"
    time_tuple = time.strptime(date_str, "%Y-%m-%d %H:%M:%S")
    dt_obj = datetime.datetime(*time_tuple[0:6])
    ###print repr(dt_obj)
    ###print str(dt_obj)

    # timestamp to datetime object in local time
    timestamp = 1226527167.595983
    dt_obj = datetime.datetime.fromtimestamp(timestamp)
    ###print repr(dt_obj)
    ###print str(dt_obj)

    # timestamp to datetime object in UTC
    timestamp = 1226527167.595983
    dt_obj = datetime.datetime.utcfromtimestamp(timestamp)
    ###print repr(dt_obj)
    ###print str(dt_obj)

    #-------------------------------------------------
    # conversions to time tuples
    #-------------------------------------------------
    # datetime object to time tuple
    dt_obj = datetime.datetime(2008, 11, 10, 17, 53, 59)
    time_tuple = dt_obj.timetuple()
    ###print repr(time_tuple)
    ###print str(time_tuple)

    # string to time tuple
    date_str = "2008-11-10 17:53:59"
    time_tuple = time.strptime(date_str, "%Y-%m-%d %H:%M:%S")
    ###print repr(time_tuple)
    ###print str(time_tuple)

    # timestamp to time tuple in UTC
    timestamp = 1226527167.595983
    time_tuple = time.gmtime(timestamp)
    ###print repr(time_tuple)
    ###print str(time_tuple)

    # timestamp to time tuple in local time
    timestamp = 1226527167.595983
    time_tuple = time.localtime(timestamp)
    ###print repr(time_tuple)
    ###print str(time_tuple)

    #-------------------------------------------------
    # conversions to timestamps
    #-------------------------------------------------
    # time tuple in local time to timestamp
    time_tuple = (2008, 11, 12, 13, 59, 27, 2, 317, 0)
    timestamp = time.mktime(time_tuple)
    ###print repr(timestamp)
    ###print str(timestamp)

    # time tuple in utc time to timestamp
    time_tuple_utc = (2008, 11, 12, 13, 59, 27, 2, 317, 0)
    timestamp_utc = calendar.timegm(time_tuple_utc)
    ###print repr(timestamp_utc)
    # time tuple in utc time to timestamp
    time_tuple_utc = (2008, 11, 12, 13, 59, 27, 2, 317, 0)
    #timestamp_utc = calendar.timegm(time_tuple_utc)
    timestamp_utc = calendar.timegm(time_tuple_utc)
    ###print repr(timestamp_utc)
    ###print str(timestamp_utc)

    #-------------------------------------------------
    # results
    #-------------------------------------------------
    # 2008-11-10 17:53:59
    # 2008-11-12 13:51:18
    # datetime.datetime(2008, 11, 12, 13, 51, 18)
    # datetime.datetime(2008, 11, 10, 17, 53, 59)
    # datetime.datetime(2008, 11, 12, 13, 59, 27, 595983)
    # datetime.datetime(2008, 11, 12, 21, 59, 27, 595983)
    # (2008, 11, 10, 17, 53, 59, 0, 315, -1)
    # (2008, 11, 10, 17, 53, 59, 0, 315, -1)
    # (2008, 11, 12, 21, 59, 27, 2, 317, 0)
    # (2008, 11, 12, 13, 59, 27, 2, 317, 0)
    # 1226527167.0
    # 1226498367
"""    
def username(infile):
    #Open settings file and find username/mailaddress
    # <setting id="user">xxxxxxxx</setting> ### Kodi 18!
    LF = io.open(infile, 'r', encoding="utf-8")
    input = LF.read()
    marker = '<setting id="user">'
    markerend = '</setting>'
    user=''
    if marker in input and user == '':
        user = input.split(marker)[1].split(markerend)[0]
    # Close our file
    LF.close()
    return user

def folder(infile):
    #Open settings file and find recording folder
    LF = open(infile, 'r', encoding = 'utf-8')
    input = LF.read()
    marker = '<setting id="record_display_path" value="'  ### NOT Kodi 18!
    markerend = '" />'
    user=''
    if marker in input and user == '':
        user = input.split(marker)[1].split(markerend)[0]
    # Close our file
    LF.close()
    return user
    
def versiondate():
    #Open addon.xml file and find version and date
    infile = os.path.join(ADDONgetAddonInfo('path'), 'addon.xml')
    LF = open(infile, 'r', encoding = 'utf-8')
    input = LF.read()
    marker = 'Version Date'
    markerend = '</description>'
    user=''
    if marker in input and user == '':
        user = input.split(marker)[1].split(markerend)[0]
    # Close our file
    LF.close()
    return user
    
def version():
    #Open addon.xml file and find version info
    infile = os.path.join(ADDONgetAddonInfo('path'), 'addon.xml')  
    log(module,'Path to addon.xml' + infile)     
    LF = open(infile, 'r', encoding = 'utf-8')
    input = LF.read()
    marker = '<addon id='
    markerend = '>'
    user=''
    if marker in input and user == '':
        user = input.split(marker)[1].split(markerend)[0]
    # Close our file
    LF.close()
    return user
"""    

def findsetting(infile, marker, markerend, maxsize):
    try:
        #Open settings file and find username/mailaddress
        # <setting id="user">xxxxxxxx</setting> ### Kodi 18!
        LF = io.open(infile, 'r', encoding = 'utf-8')
        log(module,'1727 err findsetting')
        ###LF = io.open(infile, 'r')   ### 2022-05-06
        log(module,'1729 err findsetting')
        user=''
        count = 0
        while user == '' and count < maxsize:
            count += 1   ### 2022-05-30
            inputx = LF.readline()
            if marker in inputx :
                user = inputx.split(marker)[1].split(markerend)[0]
            # Close our file
        LF.close()
        return user
    except Exception as e:
        pass
        log(module,'findsetting ERR: %r' % e)
        try: LF.close()
        except: pass
        return 'not found'   ### 2022-05-24      

def username(infile):
    log(module,'errYYY username(infile= %r) ' % infile)
    marker = '<setting id="user">'
    markerend = '</setting>'
    user = findsetting(infile, marker, markerend, 200)
    log(module,'errYYY username(user= %r) ' % user)
    return user

def folder(infile):
    marker = '<setting id="record_display_path" value="'  ### NOT Kodi 18!
    markerend = '" />'
    user = findsetting(infile, marker, markerend, 1000)
    return user
    
def versiondate():
    try:
        infile = os.path.join(ADDONgetAddonInfo('path'), 'addon.xml')
        marker = 'Version Date'
        markerend = '</description>'
        user = findsetting(infile, marker, markerend, 200)
        return user
    except Exception as e:
        pass
        return 'error in versiondate: %r' % e
    
def version():
    infile = os.path.join(ADDONgetAddonInfo('path'), 'addon.xml')
    marker = '<addon id='
    markerend = '>'
    user = findsetting(infile, marker, markerend, 200)
    return user
    
def MyVideos_DB():
    try:
        infile = xbmcvfs.translatePath(os.path.join('special://logpath' , 'kodi.log'))
        marker = 'database version MyVideos'
        markerend = '\n'
        user = findsetting(infile, marker, markerend, 1000)
        log(module,'error MyVideos_DB() findings= %r ' % user)
        user = 'MyVideos' + str(int(user)) + '.db'
        if len(user) == 14:   ### 11--> 14 2024-04-10
            return user
        else:
            KodiVersion = int(xbmc.getInfoLabel('System.BuildVersion')[:2])
            ###log(module,'xbmc.getInfoLabel(System.BuildVersion)[:2]= %r' % KodiVersion)
            if KodiVersion < 18:  
                MyVideos_DB = 'MyVideos116.db'   ### Kodi 18
            elif KodiVersion == 19:
                MyVideos_DB = 'MyVideos119.db'   ### Kodi 19
            elif KodiVersion == 20:
                MyVideos_DB = 'MyVideos121.db'   ### Kodi 20
            else:
                MyVideos_DB = 'MyVideos131.db'   ### Kodi 21
            return MyVideos_DB
    except Exception as e:
        pass
        log(module,'err MyVideos_DB Exception: %r' % e)
        KodiVersion = int(xbmc.getInfoLabel('System.BuildVersion')[:2])
        ###log(module,'xbmc.getInfoLabel(System.BuildVersion)[:2]= %r' % KodiVersion)
        if KodiVersion < 18:  
            MyVideos_DB = 'MyVideos116.db'   ### Kodi 18
        elif KodiVersion == 19:
            MyVideos_DB = 'MyVideos119.db'   ### Kodi 19
        else:
            MyVideos_DB = 'MyVideos121.db'   ### Kodi 20..
        return MyVideos_DB

def hmduration(duration) :
    durationH = int(int(duration)//60) 
    durationM = (int(duration) - durationH*60)
    orgduration =  str(durationH) + 'h' + str(durationM).zfill(2) + 'm'
    return orgduration
