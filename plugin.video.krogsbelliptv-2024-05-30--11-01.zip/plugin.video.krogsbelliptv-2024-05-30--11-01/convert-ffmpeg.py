#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys,xbmcaddon,xbmc,os
#import datetime
#import time
import utils

import definition
ADDON      = definition.getADDON()
ADDONname  = definition.ADDONgetAddonInfo('name')
ADDONid    = definition.ADDONgetAddonInfo('id')
module = 'convert-ffmpeg.py'
utils.logdev(module,'sys.argv= %s' %(str(repr(sys.argv))))
program  = sys.argv[0]
filename = sys.argv[1]
newext   = sys.argv[2]

LoopCount = 0
utils.logdev(module,'Converting file= %s' % filename)
##nowHM=datetime.datetime.today().strftime('%H:%M:%S')

cmd = 'ffmpeg -y -i '+filename+ ' -c copy ' + filename.split('.',-1)[0] + newext  # Use seperately installed ffmpeg program ###
            

if definition.ADDONgetSetting('os')=='11':
    utils.runCommand(cmd, LoopCount, libpath=None)
else:
    libpath = utils.libPath()
    utils.logdev(module,'libpath= %s' % repr(libpath))
    utils.runCommand(cmd, LoopCount, libpath=libpath)
utils.notification('Converting %s [COLOR red]complete[/COLOR]' % filename)
    
