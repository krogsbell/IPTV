#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#      Copyright (C) 2014 Tommy Winther
#      http://tommy.winther.nu
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt. If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
import os
import sys
import simplejson
import urllib2
import urlparse

import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import channels
import channelsDR   ### 2019-05-28
import buggalo
import utils
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import xmltodict

CHANNELS_URL = 'https://www.dr.dk/mu-online/api/1.0/channel/all-active-dr-radio-channels'
CHANNELS_URL_EPG = 'https://www.dr.dk/Tjenester/epglive/epg.radio.%s.drxml'
### Link to EPG List: https://www.dr.dk/Tjenester/epglive/

ADDON     = xbmcaddon.Addon()
ADDONname = ADDON.getAddonInfo('name')
ADDONid   = ADDON.getAddonInfo('id')
ADDONpath = xbmc.translatePath('special://home/addons/%s/' % ADDONid)
ProgramPlaying = ADDON.getSetting('ProgramPlaying')
programswanted = ADDON.getSetting('programswanted').split(',')
programsnogo   = ADDON.getSetting('programsnogo').split(',')
preferredstation = ADDON.getSetting('preferredstation') ### DR P4 København
backupstation    = ADDON.getSetting('backupstation') ### DR P5

def __log(text):
    utils.logdev('addon.py',text)
    
def TSl(timestr):
    ### time format 2019-05-21T22:05:00Z to date string i local
    time_tuple = time.strptime(timestr, "%Y-%m-%dT%H:%M:%SZ")
    timestamp = time.mktime(time_tuple)
    TO = datetime.fromtimestamp(timestamp)
    TOTS = int(time.mktime(TO.timetuple()))
    utcTO = datetime.utcfromtimestamp(timestamp)
    utcTOTS = int(time.mktime(utcTO.timetuple()))
    timeoffset = TOTS-utcTOTS
    __log('timeoffset= %r' % timeoffset)
    return(timestamp+timeoffset) 
    
def TS(timestr):
    ### time format 2019-05-21T22:05:00Z
    time_tuple = time.strptime(timestr, "%Y-%m-%dT%H:%M:%SZ")
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def now():   ### Local time
    dt_obj= datetime.now()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
   
def nowTS():   ### UTC time
    dt_obj= datetime.utcnow()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def nowS(format):   ### Now date string UTC time
    time_tuple = time.localtime(nowTS())
    date_str = time.strftime(format, time_tuple)
    return(date_str)
    
def datestr(timestamp,format):   ### Now date string UTC time %Y-%m-%dT%H:%M:%SZ
    time_tuple = time.localtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)

def datestrdelta(timestamp,format):   ### Now date string UTC time %Y-%m-%dT%H:%M:%SZ
    time_tuple = time.gmtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)
    
def takeSecond(elem): 
    return elem[1]
    
def direct_play(url):
    __log("direct_play ["+url+"]")

    title = ""

    try:
        xlistitem = xbmcgui.ListItem( title, iconImage="DefaultAudio.png", path=url)
    except:
        xlistitem = xbmcgui.ListItem( title, iconImage="DefaultAudio.png", )
    xlistitem.setInfo( "audio", { "Title": title } )

    playlist = xbmc.PlayList( xbmc.PLAYLIST_MUSIC )
    player_type = xbmc.PLAYER_CORE_AUTO
    xbmcPlayer = xbmc.Player( player_type )
    xbmcPlayer.play(playlist) 
    
def StartProgram(station_id,timestamp):
    try:
        __log('ADDON %r - %r' % (ADDONname,ADDONid))
        __log('station_id= %r Start @ %r' % (station_id,datestr(timestamp,'%H:%M:%S')))
        if not station_id:
            station_id = preferredstation
            __log('playEPG(DEFAULT station_id= %r)' % station_id)
            
        script = os.path.join(ADDONpath, 'startstation.py')
        __log('script= %r' % script)
        nameAlarm = ADDONid + '-start-' + str(station_id) + '-' + datestr(timestamp,'d%dh%Hm%Ms%S')
        __log('nameAlarm= %r' % nameAlarm)
        delay = timestamp - nowTS()
        __log('delay= %r' % delay)
        delayHMS = datestrdelta(delay,'%H:%M:%S')
        __log('delayHMS= %r' % delayHMS)
        if delay >= 0 and delay < 24*3600:
            cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),%s,silent)' % (nameAlarm, script, PATH,station_id,delayHMS)
            __log('cmd= %s' % cmd)
            __log('LastStartStation:' + station_id + ': '+datestr(timestamp,'d%dh%Hm%Ms%S'))
            ADDON.setSetting('LastStartStation',station_id + ': '+datestr(timestamp,'d%dh%Hm%Ms%S'))
            ADDON.setSetting('StartStation',station_id)
            xbmc.executebuiltin(cmd)  # Active
    except Exception,e:
        pass
        __log('StartProgram(station_id= %r,timestamp= %r) ERROR: %r' % (station_id,timestamp,e))
   
def EndProgram(station_id,timestamp):
    __log('ADDON %r - %r' % (ADDONname,ADDONid))
    __log('station_id= %r Start @ %r' % (station_id,datestr(timestamp,'%H:%M:%S')))
    __log('do not run this')
    """
    ###ADDONpath =  = xbmc.translatePath('special://home/addons/%s/' % ADDONid)
    script = os.path.join(ADDONpath, 'startstation.py')
    __log('script= %r' % script)
    nameAlarm = ADDONid + '-startstation-' + str(timestamp)
    #delay = timestamp - now.....
    cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),00:00:00,silent)' % (nameAlarm, script, station_id, str(timestamp))
    __log('cmd= %s' % cmd)
    ADDON.setSetting('StopStation',station_id)
    xbmc.executebuiltin(cmd)  # Active
    """
    #return
    
def showOverview():
    item = xbmcgui.ListItem(ADDON.getLocalizedString(30100), iconImage=ICON)
    item.setProperty('Fanart_Image', FANART)
    xbmcplugin.addDirectoryItem(HANDLE, PATH + '?show=dr', item, True)
    
    item = xbmcgui.ListItem(ADDON.getLocalizedString(30102), iconImage=ICON)
    item.setProperty('Fanart_Image', FANART)
    xbmcplugin.addDirectoryItem(HANDLE, PATH + '?show=epg', item, True)
    
    item = xbmcgui.ListItem(ADDON.getLocalizedString(30103), iconImage=ICON)
    item.setProperty('Fanart_Image', FANART)
    xbmcplugin.addDirectoryItem(HANDLE, PATH + '?show=epgm', item, True)

    item = xbmcgui.ListItem(ADDON.getLocalizedString(30101), iconImage=ICON)
    item.setProperty('Fanart_Image', FANART)
    xbmcplugin.addDirectoryItem(HANDLE, PATH + '?show=other', item, True)

    xbmcplugin.endOfDirectory(HANDLE)


def showDRChannels():
    try:
        u = urllib2.urlopen(CHANNELS_URL)
        channelList = simplejson.loads(u.read())
        u.close()
    except Exception, ex:
        showError(str(ex))
        return

    for channel in channelList:
        __log('showDRChannels(channel= %r)'% channel)
        title = channel['Title']
        slug  = channel['Slug']
        if title[0:3] == 'DR ':
            title = title[3:]
        __log('playEPG(title= %r, slug= %r)'% (title,slug))
        sourceUrl = channel['SourceUrl']
        logoImage = xbmc.translatePath(os.path.join(LOGO_PATH, sourceUrl[sourceUrl.rindex('/') + 1:] + '.png'))
        if xbmcvfs.exists(logoImage):
            __log('logoImage EXISTS %r'% logoImage)
            item = xbmcgui.ListItem(title, iconImage=logoImage)
        else:
            __log('logoImage DO NOT EXISTS %r'% logoImage)
            item = xbmcgui.ListItem(title, iconImage=ICON)

        item.setProperty('IsPlayable', 'true')
        item.setProperty('Fanart_Image', FANART)
        item.setInfo(type='music', infoLabels={
            'title': title
        })

        url = None

        if 'StreamingServers' in channel:
            for server in channel['StreamingServers']:
                if 'LinkType' in server and server['LinkType'] == 'ICY' and 'Qualities' in server:
                    try:
                        url = server['Server'] + '/' + server['Qualities'][0]['Streams'][0]['Stream']
                        break
                    except:
                        pass
        __log('playEPG(url= %r)'% url)
        if url:
            xbmcplugin.addDirectoryItem(HANDLE, url, listitem = item)

    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.endOfDirectory(HANDLE)
    
def showOtherChannels():
    for channel in channels.CHANNELS:
        logoImage = xbmc.translatePath(os.path.join(LOGO_PATH, str(channel.id) + '.png'))
        if xbmcvfs.exists(logoImage):
            __log('logoImage EXISTS %r'% logoImage)
            item = xbmcgui.ListItem(channel.name, iconImage=logoImage)
        else:
            __log('logoImage DO NOT EXISTS %r'% logoImage)
            item = xbmcgui.ListItem(channel.name, iconImage=ICON)

        item.setProperty('IsPlayable', 'true')
        item.setProperty('Fanart_Image', FANART)
        item.setInfo(type='music', infoLabels={
            'title': channel.name
        })
        xbmcplugin.addDirectoryItem(HANDLE, PATH + '?playOther=%s' % channel.id, listitem = item)

    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(HANDLE)
    
def showEPGm():
    __log('showEPGm START')
    try:
        for radioEPGi in channelsDR.CHANNELS:
            logoImage = xbmc.translatePath(os.path.join(LOGO_PATH, str(radioEPGi.icon) + '.png'))
            
            if xbmcvfs.exists(logoImage):
                __log('logoImage EXISTS %r'% logoImage)
                item = xbmcgui.ListItem(radioEPGi.name, iconImage=logoImage)
            else:
                __log('logoImage DO NOT EXISTS %r'% logoImage)
                item = xbmcgui.ListItem(radioEPGi.name, iconImage=ICON)
            station_id = radioEPGi.name
            __log('station_id= %r ' % station_id)
            
            ###item = xbmcgui.ListItem(station_id, iconImage=ICON)

            item.setProperty('IsPlayable', 'true')
            item.setProperty('Fanart_Image', FANART)
            item.setInfo(type='music', infoLabels={
                'title': station_id
            })
            xbmcplugin.addDirectoryItem(HANDLE, PATH + '?playEPG=%s' % station_id, item)
            
    except Exception,e:
        pass

    ### DO NOT SORT xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(HANDLE)

def showEPG():
    __log('Maintenance START')
    try:
        items = []
        WantedPrograms = []
        NogoPrograms   = []
        P4selected = ADDON.getSetting('selectedp4station')
        for radioEPGi in channelsDR.CHANNELS:
            station_id = radioEPGi.name
            if 'P4' in station_id and not station_id == P4selected:
                __log('Ignore Station: %r' % station_id)
            else:
                radioEPG  = radioEPGi.epg
                __log('station_id= %r ' % station_id)
                file = urllib2.urlopen(radioEPG)
                dataepg = file.read()
                file.close() 
                datadict = xmltodict.parse(dataepg)
                name = datadict['m_sch:message']['schedule']['channel']['name']
                type = datadict['m_sch:message']['schedule']['channel']['type']
                datadict1 = datadict['m_sch:message']['schedule']['programs']
                nowLocal = datestr(now(),'%H:%M')
                ###titlename = '[COLOR yellow][B]' + datadict['m_sch:message']['schedule']['channel']['name'] + '  -  ' + datadict['m_sch:message']['schedule']['broadcastdate'] + '[/B]' + '  Now ' + nowS('%H:%M') + ' GMT[/COLOR]'
                titlename = '[COLOR yellow][B]' + datadict['m_sch:message']['schedule']['channel']['name'] + '[/B]' + '  (' + nowLocal + ')[/COLOR]'
                logoImage = xbmc.translatePath(os.path.join(LOGO_PATH, str(radioEPGi.icon) + '.png'))
                __log('logoImage= %r' %logoImage)
                if xbmcvfs.exists(logoImage):
                    __log('logoImage EXISTS %r'% logoImage)
                    item = xbmcgui.ListItem(titlename, iconImage=logoImage)
                else:
                    __log('logoImage DO NOT EXISTS %r'% logoImage)
                    item = xbmcgui.ListItem(titlename, iconImage=ICON)

                item.setProperty('IsPlayable', 'true')
                item.setProperty('Fanart_Image', FANART)
                item.setInfo(type='music', infoLabels={
                    'title': station_id
                })
                xbmcplugin.addDirectoryItem(HANDLE, PATH + '?playEPG=%s' % station_id, item)
                
                i = 0
                for program in datadict1['program']:
                    stop = program['pro_publish']['ppu_stop_timestamp_presentation_utc']
                    start = program['pro_publish']['ppu_start_timestamp_announced_utc']
                    startactual = program['pro_publish']['ppu_start_timestamp_presentation_utc']
                    if TS(stop) > nowTS():
                        __log('1')
                        title = program['pro_publish']['ppu_title']  
                        for wanted in programswanted:
                            if wanted in title.lower():
                                title = '[COLOR lightgreen]' + title + '[/COLOR]'
                                WantedPrograms.append([station_id,startactual,stop])
                        for notwanted in programsnogo:
                            if notwanted in title.lower():
                                title = '[I][COLOR red]' + title + '[/COLOR][/I]' 
                                NogoPrograms.append([station_id,startactual,stop])
                        title = '[B]' + title + '[/B]'
                        punchline= program['pro_publish']['ppu_punchline']
                        if punchline:
                            title += ' - ' + punchline
                        description= program['pro_publish']['ppu_description']
                        if description:
                            title += '\n' + description
                        channel= program['pro_publish']['ppu_channel']
                        __log('2')
                        if start != startactual:
                            try:
                                ### 2019-05-21T22:05:00Z
                                timediff = repr(TS(startactual) - TS(start))
                                __log('timediff= %r, startactual= %r, start= %r' % (timediff, startactual, start))
                            except Exception,e:
                                pass
                                timediff = repr(e)
                            title = '[COLOR blue]'+timediff+'[/COLOR] ' + title
                        __log('3')
                        if i < 20:
                            i += 1
                            startactualLocal = TSl(startactual)
                            __log('4')
                            startactualLocal = datestr(TSl(startactual),'%H:%M')
                            
                            stopLocal = datestr(TSl(stop),'%H:%M')
                            __log('5')
                            ###titlename = startactual[11:-4] + ' - ' + stop[11:-4] + 'X' +startactualLocal+' - ' + stopLocal+ '  ' + title
                            titlename = startactualLocal+' - ' + stopLocal + '  ' + title
                            item = xbmcgui.ListItem(titlename, iconImage='x')  ### No icon on program lines

                            item.setProperty('IsPlayable', 'true')
                            item.setProperty('Fanart_Image', FANART)
                            item.setInfo(type='music', infoLabels={
                                'title': titlename
                            })
                            xbmcplugin.addDirectoryItem(HANDLE, PATH + '?playEPG=%s' % station_id, item)
                
    except Exception,e:
        pass
        __log('radioEPG ERROR: %r' % e)
    """
    Programs = []
    if WantedPrograms != []:
        __log('WantedPrograms= %r' % WantedPrograms)
        for prog in WantedPrograms:
            Programs.append(prog)
    if NogoPrograms != []:
        __log('NogoPrograms= %r' % NogoPrograms)
        for prog in NogoPrograms:
            if prog[0] == preferredstation:
                Programs.append((backupstation,prog[1],prog[2]))
    __log('Programs= %r' % Programs)
    Programs = sorted(Programs, key=takeSecond)
    __log('Programs= %r' % Programs)
    ProgramPlaying = ADDON.getSetting('ProgramPlaying')
    __log('ProgramPlaying= %r' % ProgramPlaying)
    player = xbmc.Player()
    if not player.isPlaying():
        if ProgramPlaying == '':
            ProgramPlaying = preferredstation
        ADDON.setSetting('ProgramPlaying',ProgramPlaying)
        StartProgram(ProgramPlaying,nowTS())
    if Programs != []:
        try:
            if Programs[0][0] != ProgramPlaying:
                ProgramPlaying = Programs[0][0]
                StartProgram(Programs[0][0],TS(Programs[0][1]))
                EndProgram(preferredstation,TS(Programs[0][2]))
        except Exception,e:
            pass
            __log('Programs[0][0] ERROR: %r' % e)
            __log('No Program Change needed')
    else:
        __log('No Program Change needed')
    """
    ### DO NOT SORT xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(HANDLE)

def playEPG(idx):
    __log('playEPG(idx= %r)'% idx)
    __log('ADDON= %r' % ADDON)
    __log('PATH= %r' % PATH)
    __log('HANDLE= %r' % HANDLE)
    __log('PARAMS= %r' % PARAMS)
    __log('LOGO_PATH= %r' % LOGO_PATH)
    __log('PATH= %r' % PATH)
    __log('FANART= %r' % FANART)
    try:
        u = urllib2.urlopen(CHANNELS_URL)
        channelList = simplejson.loads(u.read())
        u.close()
    except Exception, ex:
        showError(str(ex))
        return
    try:
        for channel in channelList:
            title = channel['Title']
            slug  = channel['Slug']
            if title[0:3] == 'DR ':
                title = title[3:]
            __log('playEPG(title= %r slug= %r)'% (title,slug))
            if idx.lower() == slug:
                sourceUrl = channel['SourceUrl']
                logoImage = xbmc.translatePath(os.path.join(LOGO_PATH, sourceUrl[sourceUrl.rindex('/') + 1:] + '.png'))
                if xbmcvfs.exists(logoImage):
                    __log('logoImage EXISTS %r'% logoImage)
                    item = xbmcgui.ListItem(title, iconImage=logoImage)
                else:
                    __log('logoImage DO NOT EXISTS %r'% logoImage)
                    item = xbmcgui.ListItem(title, iconImage=ICON)

                item.setProperty('IsPlayable', 'true')
                item.setProperty('Fanart_Image', FANART)
                item.setInfo(type='music', infoLabels={
                    'title': title
                })

                url = None

                if 'StreamingServers' in channel:
                    for server in channel['StreamingServers']:
                        if 'LinkType' in server and server['LinkType'] == 'ICY' and 'Qualities' in server:
                            try:
                                url = server['Server'] + '/' + server['Qualities'][0]['Streams'][0]['Stream']
                                break
                            except:
                                pass
                __log('playEPG(url= %r)'% url)
                if url:
                    __log('play-ing-EPG(url= %r)'% url)
                    ###direct_play(url)
                    
                    logoImage = xbmc.translatePath(os.path.join(LOGO_PATH, title + '.png'))
                    item = xbmcgui.ListItem(path=url, thumbnailImage=logoImage)
                    item.setInfo(type='music', infoLabels={
                        'title': title
                    })
                    __log('ADDON= %r' % ADDON)
                    __log('PATH= %r' % PATH)
                    __log('HANDLE= %r' % HANDLE)
                    __log('PARAMS= %r' % PARAMS)
                    __log('LOGO_PATH= %r' % LOGO_PATH)
                    __log('PATH= %r' % PATH)
                    __log('FANART= %r' % FANART)
                    ADDON.setSetting('programplaying',idx)
                    xbmcplugin.setResolvedUrl(HANDLE, True, listitem = item)
                    
                    __log('play-ing-EPG-started(url= %r)'% url)
                    break   ### Stop at first match
    except Exception,e:
        pass
        __log('PlayEPG ERROR: %r' % e)

def playDR(idx):
    channel = None
    for c in channelsDR.CHANNELS:
        if c.id == int(idx):
            channel = c
            break

    if channel is None:
        return

    logoImage = xbmc.translatePath(os.path.join(LOGO_PATH, str(channel.id) + '.png'))
    item = xbmcgui.ListItem(path=channel.url, thumbnailImage=logoImage)
    item.setInfo(type='music', infoLabels={
        'title': channel.name
    })
    __log('play-ing-EPG(url= %r)'% channel.url)
    ADDON.setSetting('programplaying',idx)
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem = item)
    
def playOther(idx):
    channel = None
    for c in channels.CHANNELS:
        if c.id == int(idx):
            channel = c
            break

    if channel is None:
        return

    logoImage = xbmc.translatePath(os.path.join(LOGO_PATH, str(channel.id) + '.png'))
    item = xbmcgui.ListItem(path=channel.url, thumbnailImage=logoImage)
    item.setInfo(type='music', infoLabels={
        'title': channel.name
    })
    __log('play-ing-EPG(url= %r)'% channel.url)
    ADDON.setSetting('programplaying',idx)
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem = item)


def showError(message):
    heading = buggalo.getRandomHeading()
    line1 = ADDON.getLocalizedString(30900)
    line2 = ADDON.getLocalizedString(30901)
    xbmcgui.Dialog().ok(heading, line1, line2, message)
    
def findprograms():
    findP = ADDON.getSetting('LastFindStation')  ### datestr(nowTS(),'h%Hm%Ms%S'))
    if findP == '':
        delta = 800
    else:
        delta = nowTS() - TS(findP)
    __log('delta= %r' % delta)
    if delta > 700:
        __log('Start findprograms:'+datestr(nowTS(),'d%dh%Hm%Ms%S'))
        ADDON.setSetting('findprograms','Start findprograms:'+datestr(nowTS(),'d%dh%Hm%Ms%S'))
        script = os.path.join(ADDONpath, 'findstation.py')
        __log('script= %r' % script)
        nameAlarm = ADDONid + '-findstations-'
        __log('nameAlarm= %r' % nameAlarm)
        ###delayHMS = '00:10:00'   ### Run every 10 minutes
        delayHMS = '00:00:00'   ### Run once
        __log('delayHMS= %r' % delayHMS)
        ###cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),%s,loop,silent)' % (nameAlarm, script, PATH,delayHMS,delayHMS)
        cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),%s,silent)' % (nameAlarm, script, PATH,delayHMS,delayHMS)
        __log('cmd= %s' % cmd)
        xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
        xbmc.executebuiltin(cmd)  # Activate

if __name__ == '__main__':
    ADDON = xbmcaddon.Addon()
    PATH = sys.argv[0]
    HANDLE = int(sys.argv[1])
    PARAMS = urlparse.parse_qs(sys.argv[2][1:])

    LOGO_PATH = xbmc.translatePath(os.path.join(ADDON.getAddonInfo('path'), 'resources', 'logos'))
    ICON = xbmc.translatePath(os.path.join(ADDON.getAddonInfo('path'), 'icon.png'))
    FANART = xbmc.translatePath(os.path.join(ADDON.getAddonInfo('path'), 'fanart.jpg'))
    ADDON.setSetting('PATH',str(PATH))
    __log('ADDON= %r' % ADDON)
    __log('PATH= %r' % PATH)
    __log('HANDLE= %r' % HANDLE)
    __log('PARAMS= %r' % PARAMS)
    __log('LOGO_PATH= %r' % LOGO_PATH)
    __log('PATH= %r' % PATH)
    __log('FANART= %r' % FANART)
    ###findprograms()
    buggalo.SUBMIT_URL = 'http://tommy.winther.nu/exception/submit.php'
    try:
        if 'show' in PARAMS and PARAMS['show'][0] == 'dr':
            showDRChannels()
        elif 'show' in PARAMS and PARAMS['show'][0] == 'other':
            showOtherChannels()
        elif 'show' in PARAMS and PARAMS['show'][0] == 'epg':
            showEPG()
        elif 'show' in PARAMS and PARAMS['show'][0] == 'epgm':
            showEPGm()
        elif 'show' in PARAMS and PARAMS['show'][0] == 'drx':
            showDRxChannels()
        elif 'playEPG' in PARAMS:
            __log('playEPG= %r' % PARAMS['playEPG'][0])
            playEPG(PARAMS['playEPG'][0])
        elif 'playDR' in PARAMS:
            __log('playDR= %r' % PARAMS['playDR'][0])
            playDR(PARAMS['playDR'][0])
        elif 'playOther' in PARAMS:
            __log('playOther= %r' % PARAMS['playOther'][0])
            playOther(PARAMS['playOther'][0])
        else:
            showOverview()

    except Exception:
        buggalo.onExceptionRaised()

