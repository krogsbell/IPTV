from platform import Platform
from settings import Settings
from logger import Log
from httpresponse import HttpResponse
import cookielib
import urllib
import urllib2
import socket
import ssl
import json
import os
import xbmc
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)


class Api:

    URL_LOGIN = '/mobile-api/auth'
    URL_REGISTER = '/register'
    URL_CHANNELS = '/mobile-api/channels';
    URL_PLAY = '/mobile-api/channels'
    URL_FAV_ADD = '/mobile-api/favorites/add'
    URL_FAV_REMOVE = '/mobile-api/favorites/remove'
    URL_ARCHIVE = '/channels/get-record/'   ### + chId + '/' + evtStart + '/' + evtDuration
    ### https://www.unlim.tv:443/channels/get-record/949/1557407400/6000
    
    settings = None
    cookiejar = None
    context = None
    cookiefile = None
    loginpassfile = None

    def __init__(self, _app, _settings):
        opener = urllib2.build_opener(urllib2.HTTPSHandler)
        urllib2.install_opener(opener)
        self.settings = _settings
        self.cookiejar = cookielib.LWPCookieJar()
        self.context = ssl.create_default_context()
        self.context.check_hostname = False
        self.context.verify_mode = ssl.CERT_NONE

        # generate cookie path
        cookie_path = os.path.join(_app.data_path, Platform.COOKIE_PATH)
        if not os.path.exists(cookie_path):
                os.makedirs(cookie_path)
        self.cookiefile = os.path.join(cookie_path, Platform.COOKIE_FILE)
        self.loginpassfile = os.path.join(cookie_path, Platform.LOGINPASS_FILE)

        socket.setdefaulttimeout(30)

    def have_cookies_in_file(self):
        if not os.path.exists(self.cookiefile):
            return False
        if not os.path.exists(self.loginpassfile):
            return False
        f = open(self.loginpassfile, "r")
        data = f.read()
        f.close()
        data = json.loads(data)
        if data['email'] != self.settings.get(Settings.EMAIL):
            return False
        if data['password'] != self.settings.get(Settings.PASSWORD):
            return False
        tmpjar = cookielib.LWPCookieJar()
        tmpjar.load(self.cookiefile, ignore_discard = True)
        return len(tmpjar) > 0

    def have_cookies(self):
        return len(self.cookiejar) > 0

    def erase_cookies(self):
        self.cookiejar = cookielib.LWPCookieJar()
        self.cookiejar.save(self.cookiefile, ignore_discard = True)
        data = {'email': '', 'password': ''}
        f = open(self.loginpassfile, "w")
        f.write(json.dumps(data))
        f.close()

    def load_cookies(self):
        self.cookiejar = cookielib.LWPCookieJar()
        if os.path.exists(self.cookiefile):
            self.cookiejar.load(self.cookiefile, ignore_discard=True)

    def save_cookies(self):
        self.cookiejar.save(self.cookiefile, ignore_discard=True)
        data = {'email': self.settings.get(Settings.EMAIL), 'password': self.settings.get(Settings.PASSWORD)}
        f = open(self.loginpassfile, "w")
        f.write(json.dumps(data))
        f.close()


    def fetch(self, url, data, upload_cookies = False, download_cookies = False):
        Log.log('fetch(self, url= %r, data= %r' %(url, data))
        ###url = 'https://www.unlim.tv/channels/get-record/957/1557440029/120'
        Log.log('fetch(self, url= %r, data= %r' %(url, data))
        request = urllib2.Request(url)
        Log.log('fetch(self, request = %r' %(request))
        request.add_header('User-Agent', Platform.USER_AGENT + self.settings.get(Settings.STREAM_TYPE))
        Log.log('fetch(self, request 2 = %r' %(request))

        if data:
            data = urllib.urlencode(data)
            request.add_data(data)

        if Platform.COMPRESSION:
            request.add_header('Accept-Encoding', 'gzip')

        if upload_cookies:
            self.cookiejar.add_cookie_header(request)

        response = urllib2.urlopen(request, context = self.context)

        if download_cookies:
            self.cookiejar.extract_cookies(response, request)

        return HttpResponse(response)

    def login(self, email, password):
        try:
            data = {'email': email, 'password': password}
            html = self.fetch(Platform.SITE + Api.URL_LOGIN, data, False, True).content
            Log.log('Api::login ' + html)
            data = json.loads(html)
            return data
        except Exception,e:
            pass
            Log.log('login failed: %r' % e)
            if 'unregisterd user' in repr(e):
                Gui.show_message(self, line1 = 'UNLIM tv', line2 = 'login failed', line3 = 'Insert correct email and password!')
                Settings.set(self, 'user','')
                Settings.set(self, 'password','')
            return []

    def register(self, firstname, lastname, email, password):
        data = {'email': email, 'password': password, 'firstname': firstname, 'lastname': lastname, 'tandc': 1}
        html = self.fetch(Platform.SITE + Api.URL_REGISTER, data).content
        Log.log('Api::register ' + html)
        data = json.loads(html)
        return data

    def channels(self):
        data = {}
        html = self.fetch(Platform.SITE + Api.URL_CHANNELS, data, True).content
        Log.log('Api::channels - retrieving channels')
        data = json.loads(html)
        return data

    def get_channel_link(self, channel_id):
        data = {}
        html = self.fetch(Platform.SITE + Api.URL_PLAY + '/' + str(channel_id), data, True).content
        Log.log('----------- Api::play_channel ' + html)
        data = json.loads(html)
        return data
        
    def get_archive_link(self, channel_id, evtStart, evtDuration):
        ### URL_ARCHIVE = '/channels/get-record/'   ### + chId + '/' + evtStart + '/' + evtDuration
        ### https://www.unlim.tv:443/channels/get-record/949/1557407400/6000
        data = {}
        now = datetime.now()
        nowTS = int(time.mktime(now.timetuple()))
        if evtStart == '':
            evtStart = nowTS - 3600   ### Dummy time 
        if evtDuration == '':
            evtDuration = 120         ### Dummy duration
        html = self.fetch(Platform.SITE + Api.URL_ARCHIVE + '/' + str(channel_id) + '/' + str(evtStart) + '/' + str(evtDuration), data, True).content
        Log.log('----------- Api::get_archive_link ' + html)
        data = json.loads(html)
        return data

    def fav_add(self, channel_id):
        data = {}
        html = self.fetch(Platform.SITE + Api.URL_FAV_ADD + '/' + str(channel_id), data, True).content
        data = json.loads(html)
        return data

    def fav_remove(self, channel_id):
        data = {}
        html = self.fetch(Platform.SITE + Api.URL_FAV_REMOVE + '/' + str(channel_id), data, True).content
        data = json.loads(html)
        return data

