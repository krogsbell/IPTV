import xbmc
import utils

class Log:

    @staticmethod
    def log(entry):
        utils.logdev('Original UnLim.tv APP',entry)
        ###xbmc.log(entry, xbmc.LOGNOTICE)
        
    @staticmethod    
    def param(u,match):
        try:
            u = urllib.unquote_plus(u)
            x = u.split('&'+match+'=')[1].split('&')[0]
        except:
            pass
            try:
                x = u.split('?'+match+'=')[1].split('&')[0]
            except:
                pass
                x = ''
        return x
