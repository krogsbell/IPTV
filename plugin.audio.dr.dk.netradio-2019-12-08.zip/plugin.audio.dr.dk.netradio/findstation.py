#!/usr/bin/python
# -*- coding: utf-8 -*-

import urllib2    ### krogsbell 2019-05-21
import xmltodict  ### pip install xmltodict (Ubuntu first: sudo apt install python-pip)
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import _strptime
import os
import xbmcgui, xbmcplugin
import utils
import json as simplejson
import xbmcvfs,xbmcaddon
import channelsDR

CHANNELS_URL = 'https://www.dr.dk/mu-online/api/1.0/channel/all-active-dr-radio-channels'
PATH = sys.argv[1]
idtext = PATH.replace('plugin:','').replace('/','').replace('special:homeaddons','')
ADDON = xbmcaddon.Addon(id=idtext)
ADDONname = ADDON.getAddonInfo('name')
ADDONid   = ADDON.getAddonInfo('id')
ADDONpath = xbmc.translatePath('special://home/addons/%s/' % ADDONid)
LOGO_PATH = os.path.join(PATH, 'resources', 'logos')
ICON = os.path.join(PATH, 'icon.png')
FANART = os.path.join(PATH, 'fanart.jpg')
module = 'findstation.py'

def __log(text):
    utils.logdev(sys.argv[0]+' '+sys.argv[2],text)

def TSlts(timestamp):
    TO = datetime.fromtimestamp(timestamp)
    TOTS = int(time.mktime(TO.timetuple()))
    utcTO = datetime.utcfromtimestamp(timestamp)
    utcTOTS = int(time.mktime(utcTO.timetuple()))
    timeoffset = TOTS-utcTOTS
    ###__log('timeoffset= %r' % timeoffset)
    return(timestamp+timeoffset) 

def TSl(timestr):
    ### time format 2019-05-21T22:05:00Z to date string i local
    time_tuple = time.strptime(timestr, "%Y-%m-%dT%H:%M:%SZ")
    timestamp = time.mktime(time_tuple)
    TO = datetime.fromtimestamp(timestamp)
    TOTS = int(time.mktime(TO.timetuple()))
    utcTO = datetime.utcfromtimestamp(timestamp)
    utcTOTS = int(time.mktime(utcTO.timetuple()))
    timeoffset = TOTS-utcTOTS
    ###__log('timeoffset= %r' % timeoffset)
    return(timestamp+timeoffset) 
        
def TS(timestr):
    ### time format 2019-05-21T22:05:00Z
    time_tuple = time.strptime(timestr, "%Y-%m-%dT%H:%M:%SZ")
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
   
def nowTS():   ### UTC time
    dt_obj= datetime.utcnow()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def nowS(format):   ### Now date string UTC time
    time_tuple = time.localtime(nowTS())
    date_str = time.strftime(format, time_tuple)
    return(date_str)

def now():   ### Local time
    dt_obj= datetime.now()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
    
def datestr(timestamp,format):   ### Now date string UTC time %Y-%m-%dT%H:%M:%SZ
    time_tuple = time.localtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)

def datestrdelta(timestamp,format):   ### Now date string UTC time %Y-%m-%dT%H:%M:%SZ
    time_tuple = time.gmtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)
    
def takeSecond(elem): 
    return elem[1]
    
def direct_play(url):
    __log("direct_play ["+url+"]")

    title = ""

    try:
        xlistitem = xbmcgui.ListItem( title, iconImage="DefaultAudio.png", path=url)
    except:
        xlistitem = xbmcgui.ListItem( title, iconImage="DefaultAudio.png", )
    xlistitem.setInfo( "audio", { "Title": title } )

    playlist = xbmc.PlayList( xbmc.PLAYLIST_MUSIC )
    player_type = xbmc.PLAYER_CORE_AUTO
    xbmcPlayer = xbmc.Player( player_type )
    xbmcPlayer.play(playlist) 
    
def StartProgram(station_id,timestamp):
    try:
        __log('ADDON %r - %r' % (ADDONname,ADDONid))
        __log('station_id= %r Start @ %r' % (station_id,datestr(TSlts(timestamp),'%H:%M:%S')))
        if not station_id:
            station_id = preferredstation
            __log('playEPG(DEFAULT station_id= %r)' % station_id)
        script = os.path.join(ADDONpath, 'startstation.py')    
        ###script = os.path.join(PATH, 'startstation.py')
        __log('script= %r' % script)
        nameAlarm = ADDONid + '-start-' + str(station_id) 
        __log('nameAlarm= %r' % nameAlarm)
        delay = timestamp - nowTS()
        if delay < 0:
            delay = 0
        __log('delay= %r' % delay)
        delayHMS = datestrdelta(delay,'%H:%M:%S')
        __log('delayHMS= %r' % delayHMS)
        if delay >= 0 and delay < 24*3600:
            cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),%s,silent)' % (nameAlarm, script, PATH,station_id,delayHMS)
            __log('cmd= %s' % cmd)
            
            __log('LastStartStation:' + station_id + ': '+datestr(TSlts(timestamp),'d%dh%Hm%M'))
            ###ADDON.setSetting('LastStartStation',station_id + ': '+datestr(timestamp,'d%dh%Hm%Ms%S'))
            ###ADDON.setSetting('LastStartStation',station_id + ': '+datestrdelta(timestamp,'d%dh%Hm%M'))
            ADDON.setSetting('LastStartStation',station_id + ': '+datestr(TSlts(timestamp),'d%dh%Hm%M'))
            ADDON.setSetting('StartStation',station_id)
            xbmc.executebuiltin(cmd)  # Active
    except Exception,e:
        pass
        __log('StartProgram(station_id= %r,timestamp= %r) ERROR: %r' % (station_id,timestamp,e))

def onlyAscii (unicrap):
    """This takes a UNICODE string and ignores all characters 128 (0x80) and higher
    """ 
    r = ''
    for i in unicrap:
        if ord(i) >= 0x80:
            pass
        else:
            r += str(i)
    return r

   
def playEPG(idx):
    __log('playEPG(idx= %r)'% idx)
    try:
        u = urllib2.urlopen(CHANNELS_URL)
        channelList = simplejson.loads(u.read())
        u.close()
    except Exception, ex:
        showError(str(ex))
        return
    try:
        for channel in channelList:
            title = channel['Title']
            slug  = channel['Slug']
            if title[0:3] == 'DR ':
                title = title[3:]
            __log('playEPG(title= %r slug= %r)'% (title,slug))
            idxlower = idx.lower()
            if ('p4' in idxlower and idxlower == slug) or idxlower[:2] == slug[:2] and not 'p4' in idxlower:   
            ###if idx.lower() == slug:
                sourceUrl = channel['SourceUrl']
                logoImage = os.path.join(LOGO_PATH, sourceUrl[sourceUrl.rindex('/') + 1:] + '.png')
                if xbmcvfs.exists(logoImage):
                    item = xbmcgui.ListItem(title, iconImage=logoImage)
                else:
                    item = xbmcgui.ListItem(title, iconImage=ICON)

                item.setProperty('IsPlayable', 'true')
                item.setProperty('Fanart_Image', FANART)
                item.setInfo(type='music', infoLabels={
                    'title': title
                })

                url = None

                if 'StreamingServers' in channel:
                    for server in channel['StreamingServers']:
                        if 'LinkType' in server and server['LinkType'] == 'ICY' and 'Qualities' in server:
                            try:
                                url = server['Server'] + '/' + server['Qualities'][0]['Streams'][0]['Stream']
                                break
                            except:
                                pass
                __log('playEPG(url= %r)'% url)
                if url:
                    __log('play-ing-EPG(url= %r)'% url)
                    logoImage = os.path.join(LOGO_PATH, title + '.png')
                    item = xbmcgui.ListItem(path=url, thumbnailImage=logoImage)
                    item.setInfo(type='music', infoLabels={
                        'title': title
                    })
                    xbmc.Player().play(url, item, True)
                    __log('play-ing-EPG-started(url= %r)'% url)
                break   ### Stop at first match
    except Exception,e:
        pass
        __log('PlayEPG ERROR: %r' % e)
    
try:
    program    = sys.argv[0]
    PATH       = sys.argv[1]
    station_id = sys.argv[2]
    ADDON.setSetting('LastFindStationStart',datestr(nowTS(),'%Y-%m-%dT%H:%M:%SZ'))
    
except Exception,e:
    pass
    title = 'StartStation'
    PATH = repr(e)
    station_id = 'P4KBH'
    
try:
    __log('sys.argv= %r' % sys.argv)
    __log('os.environ= %s' % os.environ['OS'] ) #put in LOG
    __log('PATH= %r' % PATH)
    __log('LOGO_PATH= %r' % LOGO_PATH)
    __log('ICON= %r' % ICON)
    __log('FANART= %r' % FANART)

except Exception,e:
    pass
    __log('ERROR data: %r' % e)
try:
    __log('code part')
    programswanted = ADDON.getSetting('programswanted').split(',')
    __log('programswanted= %r' % programswanted)
    ProgramPlaying = ADDON.getSetting('ProgramPlaying')
    __log('ProgramPlaying= at start %r' % ProgramPlaying)
    programsnogo   = ADDON.getSetting('programsnogo').split(',')
    __log('programsnogo= %r' % programsnogo)
    preferredstation = ADDON.getSetting('preferredstation') ### DR P4 København
    __log('preferredstation= %r' % preferredstation)
    backupstation    = ADDON.getSetting('backupstation') ### DR P5
    __log('backupstation= %r' % backupstation)
    ###ADDON.setSetting('now','Now in UTC: %s' % nowS("%Y-%m-%dT%H:%M:%SZ"))
    __log('now= %r' % datestr(now(),"%Y-%m-%d %H:%M:%S"))
    ADDON.setSetting('now','%s' % datestr(now(),"%Y-%m-%d %H:%M:%S"))
    
    try:
        player = xbmc.Player()
        if not player.isPlaying():
            __log('Player is not playing at start')
            if ProgramPlaying == '':
                ProgramPlaying = preferredstation
            ADDON.setSetting('ProgramPlaying',ProgramPlaying)
            StartProgram(ProgramPlaying,nowTS())
        
        P4selected = ADDON.getSetting('selectedp4station')
        items = []
        WantedPrograms = []
        NogoPrograms   = []
        for radioEPGi in channelsDR.CHANNELS:
            station_id = radioEPGi.name
            radioEPG  = radioEPGi.epg
            __log('station_id= %r ' % station_id)
            if 'P4' in station_id and not station_id == P4selected:
                __log('Ignore Station: %r' % station_id)
            else:
                file = urllib2.urlopen(radioEPG)
                dataepg = file.read()
                file.close() 
                datadict = xmltodict.parse(dataepg)
                name = datadict['m_sch:message']['schedule']['channel']['name']
                type = datadict['m_sch:message']['schedule']['channel']['type']
                datadict1 = datadict['m_sch:message']['schedule']['programs']
                
                stationname = datadict['m_sch:message']['schedule']['channel']['name']
                
                i = 0
                for program in datadict1['program']:
                    stop = program['pro_publish']['ppu_stop_timestamp_presentation_utc']
                    ### datestr(timestamp,format):   ### Date string UTC time %Y-%m-%dT%H:%M:%SZ
                    stop = datestr(TS(stop) - 60,'%Y-%m-%dT%H:%M:%SZ')   ### adjust stop with 1 minute
                    start = program['pro_publish']['ppu_start_timestamp_announced_utc']
                    startactual = program['pro_publish']['ppu_start_timestamp_presentation_utc']
                    if TS(stop) > nowTS():
                        title = program['pro_publish']['ppu_title']  
                        punchline= program['pro_publish']['ppu_punchline']
                        if punchline:
                            title += ' - ' + punchline
                        description= program['pro_publish']['ppu_description']
                        channel= program['pro_publish']['ppu_channel']
                        for wanted in programswanted:
                            if onlyAscii(wanted.lower()) in onlyAscii(title.lower()):
                                WantedPrograms.append([station_id,startactual,stop,title,description,channel])
                        for notwanted in programsnogo:
                            if onlyAscii(notwanted.lower()) in onlyAscii(title.lower()):
                                NogoPrograms.append([station_id,startactual,stop,title,description,channel])
    except Exception,e:
        pass
        __log('radioEPG ERROR: %r' % e)
    
    Programs = []
    if WantedPrograms != []:
        __log('WantedPrograms= %r' % WantedPrograms)
        for prog in WantedPrograms:  ### Dont accept nogo programs
            if NogoPrograms != []:
                for noprog in NogoPrograms:
                    if noprog != prog:
                        Programs.append(prog)
            else:
                Programs.append(prog)
    if NogoPrograms != []:
        __log('NogoPrograms= %r' % NogoPrograms)
        for prog in NogoPrograms:
            if prog[0] == preferredstation:
                Programs.append((backupstation,prog[1],prog[2],prog[3],prog[4],prog[5]))
    __log('Programs= %r' % Programs)
    Programs = sorted(Programs, key=takeSecond)
    __log('Programs Sorted= %r' % Programs)
    ProgramPlaying = ADDON.getSetting('ProgramPlaying')
    __log('ProgramPlaying= %r' % ProgramPlaying)
    player = xbmc.Player()
    if not player.isPlaying() and Programs == []:
        __log('Player is not playing')
        if ProgramPlaying == '':
            ProgramPlaying = preferredstation
        ADDON.setSetting('ProgramPlaying',ProgramPlaying)
        StartProgram(ProgramPlaying,nowTS())
    ADDON.setSetting('LastStartStation','')
    ADDON.setSetting('LastEndStation','')
    if Programs != []:
        try:
            if Programs[0][0] != ProgramPlaying or not player.isPlaying():
                ProgramPlaying = Programs[0][0]
                StartProgram(preferredstation,TS(Programs[0][2]))
                ADDON.setSetting('LastEndStation',preferredstation+ ': '+Programs[0][3]+ ' @ ' +datestr(TSl(Programs[0][2]),'d%dh%Hm%M'))
                StartProgram(Programs[0][0],TS(Programs[0][1]))
                ADDON.setSetting('LastStartStation',Programs[0][0] + ': '+Programs[0][3]+ ' @ ' +datestr(TSl(Programs[0][1]),'d%dh%Hm%M'))
                
        except Exception,e:
            pass
            __log('Programs[0][0] ERROR: %r' % e)
            __log('No Program Change possible')
    else:
        __log('No Program Change needed')
    ADDON.setSetting('LastFindStation',datestr(nowTS(),'%Y-%m-%dT%H:%M:%SZ'))
    CurrentWindowId = repr(xbmcgui.getCurrentWindowId())
    EPGWindowId = ADDON.getSetting('EPGWindowId')
    utils.logdev('window','FindStation module= %r, CurrentWindowIdWindowId= %r, EPGWindowId= %r' % (module, CurrentWindowId, EPGWindowId))
    ###ContainerContent = xbmc.executebuiltin("Container.FolderName")
    ###utils.logdev('window','Container.FolderName= %r' % ContainerContent)
    ###currentWindow = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    ###utils.logdev('window','currentWindow(%r)' % currentWindow)
    ###currentControlList = currentWindow.getFocusId()
    ###utils.logdev('window','currentControlList(%r)' % currentControlList)
    ###selectedListItem = currentWindow.getControl(currentControlList).getSelectedItem()
    ###utils.logdev('window','selectedListItem(%s)' % selectedListItem)
    if CurrentWindowId == EPGWindowId :
        utils.logdev('window','ActivateWindow(%s)' % EPGWindowId.replace("'",""))
        xbmc.executebuiltin("ActivateWindow(%s)" % EPGWindowId.replace("'",""))
        xbmc.executebuiltin("Container.Refresh")
    if xbmc.Player().isPlayingAudio():
        music = xbmc.Player().getMusicInfoTag()
        title = music.getTitle()
        titleOLD = ADDON.getSetting('titleOLD')
        ADDON.setSetting('titleOLD',title)
        __log('getMusicInfoTag()= %r' % music)
        __log('music.getURL= %r' % music.getURL())
        __log('music.getTitle= %r' % music.getTitle())
        __log('music.getArtist= %r' % music.getArtist())
        __log('music.getTrack= %r' % music.getTrack())

except Exception,e:
    pass
    __log('ERROR: %r' % e)