#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs,os
###import datetime
import time
import utils, recordings
import net
import base64
from hashlib import md5
import json
import html.parser as HTMLParser
import requests
from requests.packages import urllib3
#Below is required to get around an ssl issue
urllib3.disable_warnings()
import urllib
import locking

###import urllib.request   ### 2017-11-04
###urllib.request.urlretrieve('http://www.example.com/songs/mp3.mp3', 'mp3.mp3')
import wget
import definition
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
ADDON      = definition.getADDON()
ADDONname  = definition.ADDONgetAddonInfo('name')
ADDONid    = definition.ADDONgetAddonInfo('id')
module = 'recorduriffmpeg.py'
progpath   = definition.ADDONgetAddonInfo('path')

searchhighlightcolor = definition.ADDONgetSetting('searchhighlightcolor')

def log(infotext,showlength=500):
    debug = definition.ADDONgetSetting('debug').lower()
    if debug in infotext[0:25].lower() and not debug == '':
        utils.log(module,infotext,showlength=showlength)
    else:
        nolog = True

log('error Start')
try:
    baseurl = definition.getBASEURL().split('://')[1].split(':')[0]
except Exception as e:
    log('error 44 Exception: %r' % e)
    pass
    baseurl = ''

try:
    log('error 49 Arguments: %r' % sys.argv,showlength=5000)
except Exception as e:
    log('err 47 Exception: %r' % e)
    pass
    log('ERROR Arguments: sys.argv %r' % e)

def param(u,match):
    try:
        u = u.replace('& ','¤¤¤')
        x = u.split('&'+match+'=')[1].split('&')[0]
        x = x.replace('¤¤¤','& ')
    except Exception as e:
        log('err 55 Exception: %r' % e)
        pass
        try:
            x = u.split('?'+match+'=')[1].split('&')[0]
        except Exception as e:
            log('err 59 Exception: %r' % e)
            pass
            x = ''
    return x

def httpget(url, out=None):
    log('httpget:url= %r' % url)
    data = wget.download(url, out)
    log('httpget:data= %r' % data)
    return data

def OpenURL(url):
    ### BBC Subtitels download
    returnparser = ''
    cookie_jar = None
    user_agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:48.0) Gecko/20100101 Firefox/48.0'
    headers = {'User-Agent': user_agent}
    log('OpenURL:url= %r' % url)
    try:
        r = requests.get(url, headers=headers, cookies=cookie_jar)
        log('error requests.get(url= %r)' % url)
    except requests.exceptions.RequestException as e:
        pass
        return repr(e)
    try:
        for cookie in r.cookies:
            cookie_jar.set_cookie(cookie)
        #Set ignore_discard to overcome issue of not having session
        #as cookie_jar is reinitialised for each action.
        try:
            log('error before cookie_jar.save: %r)' % cookie_jar)
            cookie_jar.save(ignore_discard=True)
            log('error cookie_jar.save: %r)' % cookie_jar)
        except Exception as e:
            pass
            log('error cookie_jar.save ERROR %r)' % cookie_jar)
        log('err before returnparser!')
        returnparser = HTMLParser.HTMLParser().unescape(r.content.decode('utf-8'))
        log('err after returnparser= %r' % returnparser)
        return returnparser
    except Exception as e:
        log('err 86 Exception: %r' % e)
        pass
    return returnparser

def download_subtitles_BBC(url, offset, outfile):
    import codecs
    re_subtitles = re.compile('^\s*<p.*?begin=\"(.*?)(\.([0-9]+))?\"\s+.*?end=\"(.*?)(\.([0-9]+))?\"\s*>(.*?)</p>')
    # BBC
    # Download and Convert the TTAF format to srt
    # SRT:
    # 1
    # 00:01:22,490 --> 00:01:26,494
    # Next round!
    #
    # 2
    # 00:01:33,710 --> 00:01:37,714
    # Now that we've moved to paradise, there's nothing to eat.
    #

    # TT:
    # <p begin="0:01:12.400" end="0:01:13.880">Thinking.</p>
    ###outfile = os.path.join(DIR_USERDATA, 'iplayer.en.srt or .da.srt')
    outfile = outfile.replace('.srt','.xml',-1)
    fw = codecs.open(outfile, 'w', encoding='utf-8')

    if not url:
        fw.write("1\n0:00:00,001 --> 0:01:00,001\nNo subtitles available\n\n")
        fw.close()
        return
    log('download_subtitles_BBC:url= %r' % url)
    txt = OpenURL(url)
    fw.write(txt)
    """
    i = 0
    prev = None

    # some of the subtitles are a bit rubbish in particular for live tv
    # with lots of needless repeats. The follow code will collapse sequences
    # of repeated subtitles into a single subtitles that covers the total time
    # period. The downside of this is that it would mess up in the rare case
    # where a subtitle actually needs to be repeated
    for line in txt.split('\n'):
        entry = None
        m = re_subtitles.match(line)
        
        if m:
            if(m.group(3)):
                start_mil = "%s000" % m.group(3) # pad out to ensure 3 digits
            else:
                start_mil = "000"
            if(m.group(6)):
                end_mil = "%s000" % m.group(6)
            else:
                end_mil = "000"

            ma = {'start': m.group(1),
                'start_mil': start_mil[:3],
                'end': m.group(4),
                'end_mil': end_mil[:3],
                'text': m.group(7)}

            # ma['text'] = ma['text'].replace('&amp;', '&')
            # ma['text'] = ma['text'].replace('&gt;', '>')
            # ma['text'] = ma['text'].replace('&lt;', '<')
            ma['text'] = ma['text'].replace('<br />', '\n')
            ma['text'] = ma['text'].replace('<br/>', '\n')
            ma['text'] = re.sub('<.*?>', '', ma['text'])
            ma['text'] = re.sub('&#[0-9]+;', '', ma['text'])
            # ma['text'] = ma['text'].replace('<.*?>', '')
            
            if not prev:
                # first match - do nothing wait till next line
                prev = ma
                continue

            if prev['text'] == ma['text']:
                # current line = previous line then start a sequence to be collapsed
                prev['end'] = ma['end']
                prev['end_mil'] = ma['end_mil']
            else:
                i += 1
                entry = "%d\n%s,%s --> %s,%s\n%s\n\n" % (
                    i, prev['start'], prev['start_mil'], prev['end'], prev['end_mil'], prev['text'])
                prev = ma
        elif prev:
            i += 1
            entry = "%d\n%s,%s --> %s,%s\n%s\n\n" % (
                i, prev['start'], prev['start_mil'], prev['end'], prev['end_mil'], prev['text'])

        if entry:
            fw.write(entry)
    """
    fw.close()
    return outfile


def download_subtitles(url, offset, outfile):

    ###log('Subtitles at %s' % url)
    ###outfile = os.path.join(SUBTITLES_DIR, 'itv.srt')
    fw = open(outfile, 'w')
    log('download_subtitles:url= %r' % url)
    if not url:
        fw.write("1\n0:00:00,001 --> 0:01:00,001\nNo subtitles available\n\n")
        fw.close() 
        return outfile
    txt = httpget(url, outfile)
    ###log('txt= %r' % txt)
    try:
        log('Subtitles start: ' + repr(txt[0:50]))
    except Exception as e:
        log('err 195 Exception: %r' % e)
        pass
        log('Subtitles start Error: %r' % e)
    log('Subtitles start: '+repr(txt[0:6])+' or ' + repr(txt[3:9]))
    if repr(txt[3:9]) == "'WEBVTT'":
        ### ITV
        try:
            log('ITV Subtitles start: ' + repr(txt[0:50]))
            fw.write(txt)
            fw.close()    
            return outfile
        except Exception as e:
            log('err 205 Exception: %r' % e)
            pass
            log('Failed to decode (ITV UTF-16) Subtitles: \nError: ' + repr(e)+ '\n' +repr(txt[0:50]))
        
    if repr(txt[0:6]) == '\'WEBVTT\'':  ### 2017-01-30
        ### DRnu
        fw.write(txt)
        fw.close()    
        return outfile
            
    else: 
        ### ITV <?xml version="1.0" encoding="UTF-16"?>  ### BBC <?xml version="1.0" encoding="utf-8"?>
        if ('encoding="utf-8"?' in txt) or ('encoding="UTF-8"?' in txt):
            encoding="utf-8"
            try:
                download_subtitles_BBC(url, offset, outfile)
            except Exception as  e:
                log('err 221 Exception: %r' % e)
                pass
                txt = 'Failed to encode BBC Subtitles: ' + repr(txt[0:50]) + ' Error: ' + repr(e)
                log('Failed to encode utf-8 Subtitles: ' + repr(txt[0:50]) + ' Error: ' + repr(e))
            return outfile
        else:
            encoding="utf-16"
            try:
                txt = txt.decode("utf-16")
            except UnicodeDecodeError:
                txt = txt[:-1].decode("utf-16")
            try:
                txt = txt.encode('latin-1')
            except Exception as  e:
                log('err 234 Exception: %r' % e)
                pass
                txt = 'Failed to encode Subtitles: ' + repr(txt[0:50]) + ' Error: ' + repr(e)
                log('Failed to encode Subtitles: ' + repr(txt[0:50]) + ' Error: ' + repr(e))
    log('Start of Subtitles ('+encoding+' encoding): ' + repr(txt[0:99]))
    txt = re.sub("<br/>"," ",txt)
    
    p= re.compile('^\s*<p.*?begin=\"(.*?)\.([0-9]+)\"\s+.*?end=\"(.*?)\.([0-9]+)\"\s*>(.*?)</p>')
    i=0
    prev = None

    entry = None
    for line in txt.splitlines():
        subtitles1 = re.findall('<p.*?begin="(...........)" end="(...........)".*?">(.*?)</p>',line)
        log(str(i) + ' Subtitles ('+encoding+' encoding) subtitles1= '+repr(subtitles1) + ' in line: ' + repr(line))
        if subtitles1:
            for start_time, end_time, text in subtitles1:
                r = re.compile('<[^>]*>')
                text = r.sub('',text)
                start_hours = re.findall('(..):..:..:..',start_time)
                start_mins = re.findall('..:(..):..:..', start_time)
                start_secs = re.findall('..:..:(..):..', start_time)
                start_msecs = re.findall('..:..:..:(..)',start_time)
#               start_mil = start_msecs +'0'
                end_hours = re.findall('(..):..:..:..',end_time)
                end_mins = re.findall('..:(..):..:..', end_time)
                end_secs = re.findall('..:..:(..):..', end_time)
                end_msecs = re.findall('..:..:..:(..)',end_time)
#               end_mil = end_msecs +'0'
                entry = "%d\n%s:%s:%s,%s --> %s:%s:%s,%s\n%s\n\n" % (i, start_hours[0], start_mins[0], start_secs[0], start_msecs[0], end_hours[0], end_mins[0], end_secs[0], end_msecs[0], text)
                i=i+1
                
        if entry: 
            fw.write(entry)
    
    fw.close()    
    return outfile

def download_subtitles_files(url, outfile):
    return 0 ### 2018-06-18/2019-01-27 ???
    ### Fetch files ending with .srt and similar filename  2018-06-15
    ### add subtitle extension to outfile
    log('download_subtitles_files(url= %r, outfile= %r)' % (url, outfile))
    subtitles_fetched = 0
    urlnoext = url.rsplit('.',1)[0]
    subtitles = ['.en.srt','.da.srt']
    for sub in subtitles:
        try:    
            r = requests.get(urlnoext + sub)
            if r.status_code == 200:
                with open(outfile + sub, 'wb') as f:  
                    # Retrieve HTTP meta-data
                    log('r.status_code= %r' % r.status_code)  
                    log('r.headers[content-type]= %r' % r.headers['content-type'])  
                    log('r.encoding= %r' % r.encoding)  
                    f.write(r.content)
                    subtitles_fetched +=1
        except Exception as e: 
            log('err 291 Exception: %r' % e)
            pass
            log('download_subtitles_files Error= %r' % e)
    return subtitles_fetched
    
def TryAgain(uri, recordname, nameAlarm, OrgTitle, description):
    log('error TryAgain uri= %r' % uri)
    log('error TryAgain recordname= %r' % recordname)
    log('error TryAgain nameAlarm= %r' % nameAlarm)
    log('error TryAgain OrgTitle= %r' % OrgTitle)
    log('error TryAgain description= %r' % description)
    recordname = FileTitle(OrgTitle)
    startrecording = datetime.today() + timedelta(minutes = 1)
    stoprecording = startrecording + timedelta(hours = 1)
    startrecording = startrecording.strftime('%Y-%m-%d %H:%M:%S')
    stoprecording = stoprecording.strftime('%Y-%m-%d %H:%M:%S')
    StartRecordAt = '00:00:00'
    script   = os.path.join(progpath, 'recorduriffmpeg.py')
    description = utils.decode64(description)
    recordings.addRecordingPlanned(uri, startrecording, stoprecording, 'REPEAT ' + recordname.replace(',','').replace('+','Plus'), nameAlarm, 'Record repeat from VOD/Series or from other AddOn\n\n' + OrgTitle+'\n'+recordname + '\n\n' + description, '', DB='default')
    ###addAlarm(nameAlarm, prog, parameters, starttimedeltahms, options)
    recordings.addAlarm(nameAlarm, script, utils.base64b64encode(uri), StartRecordAt, recordname.replace(',',''))
    cmd = 'AlarmClock(%s,RunScript(%s,%s,%s,%s),%s,silent)' % (nameAlarm, script, utils.base64b64encode(uri), recordname.replace(',',''),utils.base64b64encode(nameAlarm),StartRecordAt)  ### 2017-08-05 + 2018-05-22
    log('error Recordffmpeg cmd= %r' % cmd)
    definition.ADDONresetSetting('RecordingFromOtherAddon','')
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin(cmd)  # Active

def FileTitle(title):
    filetitle = recordings.latin1_to_ascii_force(title) ### 2019-01-02
    log('errXXX 658 filetitle= %r' % filetitle)
    filetitle = filetitle.replace('?', '')
    filetitle = filetitle.replace(',', '.')    ### 2022-04-05 Make filename usable for translation by not using ';'
    filetitle = filetitle.replace(':', '.')    ### 2022-04-05 Make filename usable for translation by not using ';'
    filetitle = filetitle.replace('/', '-')
    filetitle = filetitle.replace('+','Plus')
    filetitle = filetitle.replace('\\', '_')
    filetitle = filetitle.replace('] [', '][') ### 2019-01-28
    filetitle = re.sub('[,:\\/*?\<>|"]+', '', filetitle)
    filetitle = " ".join(filetitle.split())  # Remove extra spaces from filename
    return filetitle
   
def addErrorToFile(titleFile):
    try:
        file = open(titleFile, 'r') 
        tit = file.read()
        tit = 'ERROR: ' + tit
        file.close()
        LF = open(titleFile, 'w') 
        LF.write(tit)
        # Close our file so no further writing is posible.
        LF.close()
        # Close our file so no further writing is posible.
    except Exception as e:
        pass
        log('addErrorToFile Exception: %r' % e)

uri = ''
try:
    nameAlarm = 'Not Set'
    log('err AAA sys.argv= %r' % sys.argv)
    params = utils.get_params(1)
    log('errorA AAA params= %r' % params)
    
    args = []
    log('error 384 arguments= %r' % args,showlength=5000)
    for arg in sys.argv:
        argument = utils.decode64(arg)
        allargument = utils.decode64(argument)
        args.append(argument)
        log('error 389 arguments= %r' % args,showlength=5000)
        log('error 390 allargument= %r' % allargument,showlength=5000)
    log('err 2 arguments= %r' % args,showlength=5000)
    
    program   = sys.argv[0]
    log('errorA program: %r' % program)
    log('errorA params= %r' % params,showlength=5000)
    uri       = sys.argv[1]
    log('errorA 330 Foreign uri= %r' % uri,showlength=5000)
    uri = uri.replace('Foreign','Foreign_HardOfHearing').replace('Lyp aG1hY','Lyp+aG1hY')  ### 2024-03-08
    log('errorA 332 Foreign uri= %r' % uri,showlength=5000)
    uri1 = ''
    if '&' in uri:
        uri0 = uri.split('&')[0]
        log('errorA 403 uri0= %r' % uri0,showlength=5000)
        uri1 = uri.split(uri0)[0]
        log('errorA 405 uri1= %r' % uri1,showlength=5000)
        uri  = uri0
    log('errorA 0 uri= %r' % uri)
    uri       = utils.decode64(uri)+uri1
    log('errorA 409 uri= %r' % uri,showlength=5000)
    URIORG = uri
    log('errorA 1 uri= %r' % uri)
    """
    try:
        if uri[:3] == 'b64':
            decoded = base64.b64decode(uri[3:])
        else:
            decoded = uri
    except Exception as e:
        log('err 329 Exception: %r' % e)
        pass
        log('base64.b64decode Error %r' % e)
        decoded = uri
    uri = decoded
    """
    log('errorA uri:1 ' + repr(uri))
    uri = uri.replace('AbCdEf','+')   ### 2024-03-08
    uri   = recordings.argumenttostring(uri)
    log('errorA uri:2 ' + repr(uri)) 
    ###searchhighlightcolor = searchhighlightcolor
    title = sys.argv[2]
    title = utils.decode64(title)
    """
    try:
        if title[:3] == 'b64':
            decoded = base64.b64decode(title[3:])
        else:
            decoded = title
    except Exception as e:
        log('err 347 Exception: %r' % e)
        pass
        log('base64.b64decode Error %r' % e)
        decoded = title
    title = decoded
    """
    title = recordings.argumenttostring(title.replace('[COLOR '+searchhighlightcolor+']','').replace('[/COLOR]',''))
    TITLEORG = title
    log('errorA title: ' + repr(title))
    nameAlarm = sys.argv[3]
    nameAlarm = utils.decode64(nameAlarm)
    log('377 errorA nameAlarm= %r' % nameAlarm)
    recordings.updateAlarm(nameAlarm)
    log('379 errorA nameAlarm= %r' % nameAlarm)
    """
    try:
        if nameAlarm[:3] == 'b64':
            decoded = base64.b64decode(nameAlarm[3:])
        else:
            decoded = nameAlarm
    except Exception as e:
        log('err 363 Exception: %r' % e)
        pass
        log('base64.b64decode Error %r' % e)
        decoded = nameAlarm
    nameAlarm = decoded
    """
    log('errorA nameAlarm-3: ' + repr(nameAlarm))
except Exception as e:
    log('err 270 Exception: %r' % e)
    pass
    title = 'Arkiv Video'
log('errorA title-3.1: ' + repr(title))
log('errorA nameAlarm-3.1: ' + repr(nameAlarm))    
try:
    argv5 = recordings.argumenttostring(sys.argv[5])
    argv8 = sys.argv[8]
    argv8 = utils.decode64(argv8)
    """
    try:
        if argv8[:3] == 'b64':
            decoded = base64.b64decode(argv8[3:])
        else:
            decoded = argv8
    except Exception as e:
        log('err 385 Exception: %r' % e)
        pass
        log('base64.b64decode Error %r' % e)
        decoded = argv8
    argv8 = decoded
    """
    if argv5 != '' and argv8 != '':  ### 2018-12-26 If recording has been modified
        title         = argv5.replace('[COLOR violet]','')
        log('errorA title argv5: %r' % title)
        nameAlarm     = argv8
        log('errorA nameAlarm-8: %r' % nameAlarm)
except Exception as e:
    log('errorA 396 Exception: %r' % e)
    pass
    log('errorA argv5-8 ERROR: %r' % e)
log('errorA title 5-8: ' + repr(title))
if nameAlarm == 'Not Set':
    nameAlarm = ADDONname + ' ' + title
    nameAlarm = recordings.latin1_to_ascii_force(nameAlarm)  ### 2019-01-02
    nameAlarm = re.sub('[(,:\\/*?\<>|")]+', '', nameAlarm).replace('[','').replace(']','')
###Recordings = definition.ADDONgetSetting('Recordings') + nameAlarm
locking.markLock(nameAlarm)
###definition.ADDONsetSetting('Recordings',Recordings)
if baseurl in uri:
    log('errorA recordLock(nameAlarm= %r )' % nameAlarm)
    locking.recordLock(nameAlarm)

allstreams      = param(uri,'allstreams')
log('errorA allstreams= %r' % allstreams)
description     = param(uri,'description')
description     = utils.decode64(description)
log('errorA description= %r' % description)
"""
try:
    if description[:3] == 'b64':
        decoded = base64.b64decode(description[3:])
    else:
        decoded = description
except Exception as e:
    log('err 422 Exception: %r' % e)
    pass
    log('base64.b64decode Error %r' % e)
    decoded = description
description = decoded
"""
OrgTitle = param(uri,'OrgTitle')
OrgTitle = utils.decode64(OrgTitle)
log('errorA 452 OrgTitle= %r' % OrgTitle)

if OrgTitle == '':
    OrgTitle = title

try:
    duration        = int(param(uri,'duration').split('.')[0])
    log('errorA 459 duration: ' + repr(duration))
except Exception as e:
    log('errorA 461 Exception: %r' % e)
    pass
    duration        = 0
if duration <= 5 :
    duration = 240
durationH = 0
durationM = 0
delim = '].'   ### 2022-03-31 '].'
if 'uration [' in description and delim in description:
    log('errorA 468 Duration: ' + repr(uri))
    orgduration = (description.split('uration [')[1].split(delim)[0] + 'm').replace(':','h')
    log('errorA 470 orgduration from uri: ' + orgduration)
    orgduration = orgduration.split(']')[0]
    log('errorA 472 orgduration from uri: ' + orgduration)
else:
    durationH = int(int(duration)//60)  ### 2021-06-21
    durationM = (int(duration) - durationH*60)
    orgduration =  str(durationH) + 'h' + str(durationM).zfill(2) + 'm'
    log('errorA orgduration from duration: ' + orgduration)
    
subtitlesurl    = param(uri,'subtitlesurl')
log('err 483 subtitlesurl= %r' % subtitlesurl)
###subtitlesurl    = subtitlesurl.replace('Foreign','Foreign_HardOfHearing')
###log('err 485 subtitlesurl= %r' % subtitlesurl)
try:
    subtitlesoffset = int(param(uri,'subtitlesoffset'))
except Exception as e:
    log('err 456 Exception: %r' % e)
    pass
    subtitlesoffset = 0
try:
    log('err uri: ' + repr(uri))
    ###uri = uri.split('&')[0]
    uri = uri.split('&description=')[0]
    try:
        uri = uri.split('&name=')[0]
    except Exception as e:
        log('err 465 Exception: %r' % e)
        pass
    try:
        uri = uri.split('&duration=')[0]   ### 2020-10-04
    except Exception as e:
        log('err 470 Exception: %r' % e)
        pass
    log('err uri: ' + repr(uri))
except Exception as e:
    log('err 472 Exception: %r' % e)
    pass
    log('Get uri FAILED ERROR: %r' % e)
    uri = ''
"""
try:
    description   = uri.split('&description=')[1]
    try:
        subtitlesurl    = description.split('&subtitlesurl=')[1]
        subtitlesoffset = subtitlesurl.split('&subtitlesoffset=')[1]
        duration        = int(subtitlesoffset.split('&duration=')[1])
        subtitlesoffset = int(subtitlesoffset.split('&duration=')[0])
        subtitlesurl    = subtitlesurl.split('&subtitlesoffset=')[0]
        description     = description.split('&subtitlesurl=')[0]
        log('Subtitles at: ' + repr(subtitlesurl))
    except Exception as e:
        log('err 487 Exception: %r' % e)
        pass
        log('NO Subtitles - Error: %r' % e)
        subtitlesurl = ''
        subtitleoffset = 0
    uri = uri.split('&description=')[0]
    try:
        uri = uri.split('&name=')[0]
    except Exception as e:
        log('err 495 Exception: %r' % e)
        pass
except Exception as e:
    log('err 497 Exception: %r' % e)
    pass
    try:
        description = uri.split('&description=')[1]
    except Exception as e:
        log('err 501 Exception: %r' % e)
        log('Description not found in: ' + repr(uri))       
        description = 'No description'

        ### 2019-01-03
            durationH = 0
            durationM = 0
            if 'Duration [' in description and '].' in description:
                orgduration = (description.split('uration [')[1].split('].')[0] + 'm').replace(':','h')
            else:
                durationH = int(int(duration)/3600)
                durationM = (int(duration) - durationH*3600)/60
                orgduration =  str(durationH) + 'h' + str(durationM) + 'm'
            if duration == '0':
                cmd += '"' + recordPath + filetitle + ' ['+recordstarttime+ PreTitle + playchannel  + ']'
            else:
                durationH = int(int(duration)/60)
                durationM = int(duration) - durationH*60
                cmd += '"' + recordPath + filetitle + ' ['+recordstarttime+ PreTitle + playchannel + ' ' + orgduration + ']'
        
        """
log('err description: ' + repr(description))
log('err uri: ' + repr(uri))
try:
    log(os.environ['OS']) #put in LOG
except Exception as e:
    log('err 526 Exception: %r' % e)
    pass

###if not definition.ADDONgetSetting('RecordFromTVguide') == 'true':
###    utils.notification('Recording %s [COLOR red]NOT enabled[/COLOR]' % (title))
###else:
recordPath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_path')))
log( 'recordPath= %s' %recordPath)
if not utils.folderwritable(recordPath,module):
    utils.notification('Recording %s [COLOR red]FAILED - You must set the recording path writable![/COLOR]' % OrgTitle)
else:
    datapath = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
    nowHM=datetime.today().strftime('%H:%M:%S')
    
    if duration == 0:  ### Duration is NOT in URI or Description
        duration = definition.ADDONgetSetting('RecordFromTVguideDurationMinutes')
        try:     ### Ask option no longer possible!
            if int(duration) < 0: 
                duration = '0'
        except Exception as e:
            log('err 544 Exception: %r' % e)
            pass
            duration = '0'
    else:
        duration = str(duration)
    cmdoption=''
    
    qrecord = xbmcgui.Dialog()
    arecord = True
    ###arecord = qrecord.yesno(definition.ADDONgetAddonInfo('name'),'Do you want to record?', '' ,title)
    log('answer= %s' % repr(arecord))
    if arecord:
        if duration == 'ask':
            dialog = xbmcgui.Dialog()
            duration = dialog.numeric(0, definition.ADDONgetAddonInfo('name') + ': Time to record in minutes, empty or 0=until end','0')
        try:
            #cmd += ' -V --stop ' + definition.ADDONgetSetting('RecordFromTVguideDurationMinutes')
            cmdoption += ' -t ' + str(int(duration)*60)
        except Exception as e:
            log('err 562 Exception: %r' % e)
            pass
            cmdoption += ' -t ' + str(240*60)
        if duration == 'ignore' or duration == '' or duration == '0' or duration == 'ask':
            #cmdoption =  ' -t ' +str(120*60)
            cmdoption = ''
            duration = '0'
        ffmpegfreeoption = definition.ADDONgetSetting('ffmpegfreeoption')    
        ffmpegmapoption = (definition.ADDONgetSetting('ffmpegmapoption').lower()).split(',')  
        titlelower = title.lower().replace('-','').replace('_','')
        descriptionlower = description.lower().replace('-','').replace('_','')
        for map0 in ffmpegmapoption :
            if map0 in titlelower or map0 in descriptionlower or allstreams == 'y':
                cmdoption += ' -map 0 '  ### 2018-07-20 - use -map 0 to record all subtitles and save in originalfile format
                break
        uri = uri.split('&')[0]   ### Now ignore commands in uri
        log('err uri= %r' % uri) #put in LOG
        ### https://63.gibberish.live:443/dvr_storage/951/tracks-v1a1/2020/10/04/09/36/28-06000.ts?token=3.1.1262.1518e0b44d3251fe83aa24048d0fe1e3.1.2.3.64.1601380020.30.122967834c3b3d2decd78489dccaa6dc
        rtmp  = uri.replace('_definst_/','')  ### Remove part of uri from unlimtv 2020-10-06
        ###rtmp  = uri
        log('err rtmp= %r' % rtmp) #put in LOG
        #xbmc.log('recorduriffmpeg.py: uri= %s' % repr(uri))
        ###cmd  =  os.path.join(definition.ADDONgetAddonInfo('path'),'rtmpdump', utils.rtmpdumpFilename())
        lowspeeddownload = definition.ADDONgetSetting('lowspeeddownload')
        if lowspeeddownload == 'true':
            ffmpegcmd = 'ffmpeg -y -re -listen_timeout 2000 -reconnect 1 -reconnect_at_eof 1 -reconnect_streamed 1 -reconnect_delay_max 2 -i '
        else:
            if 'itvpnpdotcom' in rtmp or 'live.akamaized.net' in rtmp:  ### Simple for ITV and BBC
                ffmpegcmd = 'ffmpeg -y -i '
            elif 'bbc iplayer' in title.lower() or 'itv player' in title.lower():  ### BBC or ITV
                ffmpegcmd = 'ffmpeg -y -i '
            else:
                ffmpegcmd = 'ffmpeg -y -listen_timeout 2000 -reconnect 1 -reconnect_at_eof 1 -reconnect_streamed 1 -reconnect_delay_max 2 -i '
        if os.access('/system/vendor/bin/ffmpeg', os.X_OK):
            cmd = '/system/vendor/bin/' + ffmpegcmd  # Use seperately installed ffmpeg program ###
        else:   ###  -rtmp_live live don't work for ITV Hub
            cmd = ffmpegcmd
        #cmd += ' -V --stop 10000'
        #cmd += ' --live '
        #cmd += ' --flv "' + recordPath + '['+datetime.datetime.today().strftime('%Y-%m-%d %H-%M')+'] - ' + re.sub('[,:\\/*?\<>|"]+', '', title) + '.flv"'
        cmd += '"' + rtmp + '"'
        if 'itvpnpdotcom' in rtmp:
            ffmpegoptions= '4'   ### Use this option with ITV (TESTING) 2019-01-15
        else:
            ffmpegoptions= definition.ADDONgetSetting('ffmpegoptions')
        log('ffmpegoptions: ' + repr(ffmpegoptions))
        if ffmpegoptions == '1':
            cmd += ' -f flv -c:v libx264 -b:v 2000k -c:a aac -strict experimental -b:a 128k -ar 44100 ' + cmdoption + ' ' ### For use with ffmpeg
        elif ffmpegoptions == '2':
            cmd += ' -c copy ' + cmdoption + ' ' ### For use with ffmpeg and ac3 sound
        elif ffmpegoptions == '0':
            cmd += ' -c copy -bsf:a aac_adtstoasc ' + cmdoption + ' ' ### For use with ffmpeg
        elif ffmpegoptions == '4':
            cmd += ' -c copy ' + cmdoption + ' '
        elif ffmpegoptions == '5':
            cmd += ' -c copy -map 0' + cmdoption + ' '
        else:
            ffmpegfreeoption = definition.ADDONgetSetting('ffmpegfreeoption')
            cmd += ' ' + ffmpegfreeoption + ' ' + cmdoption + ' ' ### For use with ffmpeg free option
        #cmd += ' -c copy -bsf:a aac_adtstoasc ' + cmdoption + ' ' ### For use with ffmpeg
        #cmd += ' -o '
        ### string.count(substring)
        cmdcount = cmd.count(' -map ')
        if cmdcount > 1:
            cmd = cmd.replace(' -map 0 ',' ',1) ### Remove -map 0 once
        log('error 6741 title= %r' % title)
        filetitle = FileTitle(title)
        """
        filetitle = recordings.latin1_to_ascii_force(title) ### 2019-01-02
        log('errXXX 658 filetitle= %r' % filetitle)
        filetitle = filetitle.replace('?', '')
        filetitle = filetitle.replace(',', '.')    ### 2022-04-05 Make filename usable for translation by not using ';'
        filetitle = filetitle.replace(':', '.')    ### 2022-04-05 Make filename usable for translation by not using ';'
        filetitle = filetitle.replace('/', '-')
        filetitle = filetitle.replace('+','Plus')
        filetitle = filetitle.replace('\\', '_')
        filetitle = filetitle.replace('] [', '][') ### 2019-01-28
        filetitle = re.sub('[,:\\/*?\<>|"]+', '', filetitle)
        filetitle = " ".join(filetitle.split())  # Remove extra spaces from filename
        """
        log('error 754 filetitle= %r' % filetitle)
        ###source = ''
        ###if ' - ' in filetitle:
        ###    filename = filetitle.replace(' - ','####',1).split('####')
        ###    filetitle = filename[1]
        ###    source = filename[0]
        ###    log('source= %r, filetitle=%r' % (source,filetitle))
        ###if source == '':
        log('errXXX 676 OrgTitle= %r' % OrgTitle)
        recordings.updateRecordingPlanned(nameAlarm, '[COLOR orange][recorduriffmpeg]Start recording of [/COLOR] ' + OrgTitle)
        log('errXXX 678 OrgTitle= %r' % OrgTitle)
        nowHM=datetime.today().strftime('%H:%M')
        utils.notification('Recording %s [COLOR yellow]started %s[/COLOR]' % (OrgTitle, nowHM))
        recordings.updateRecordingPlanned(nameAlarm, '[COLOR yellow]Started ' + nowHM + '[/COLOR] ' + OrgTitle)
        log('errXXX 682 OrgTitle= %r' % OrgTitle)
        source = ADDONname
        log('errXXX 684 source= %r' % source)
        try:
            ###definition.ADDONgetSetting('basicuserinfo')  ### 3 letter Addon get it from file name with user info
            ###source1 = ' ' + ADDONid.split('.')[2][:3].upper() + ' ' 
            ###source1 = ' ' + definition.ADDONgetSetting('basicuserinfo').split(os.sep)[-1][:3].upper() + ' '
            source1 = ' ' + definition.ADDONgetSetting('my_referral_init')         
        except Exception as e:
            log('errXXX 691 Exception: %r' % e)
            pass
            log('ADDONid.split(.)[2][:3].upper() ERROR: %r' % e)
            source1 = ''
        log('errXXX 695 duration= %r' % duration)
        if duration == '0':
            filename1 = recordPath + filetitle + '['+datetime.today().strftime('%Y-%m-%d %H-%M') + source1 + ']'
            log('errXXX 697 filename1= %r' % filename1)
        else:
            orgduration = '[' + orgduration +']'
            log('errXXX 701 duration= %r' % duration)
            if '[' in filetitle:   ### Put duration first on second line, if not in line
                log('errXXX 703 orgduration= %r' % orgduration)
                log('errXXX 703 filetitle= %r' % filetitle)
                if orgduration in filetitle:
                    log('errXXX 705 filetitle= %r' % filetitle)
                    filename1 = recordPath + filetitle + '['+datetime.today().strftime('%Y-%m-%d %H-%M') + source1 + ']'
                    log('errXXX 707 filename1= %r' % filename1)
                else:
                    log('errXXX 713 orgduration= %r' % orgduration)
                    log('errXXX 714 filetitle= %r' % filetitle)
                    filetitle1 = filetitle.replace('[',orgduration +'[',1)
                    log('errXXX 716 filetitle1= %r' % filetitle1)
                    filename1 = recordPath + filetitle1 + '['+datetime.today().strftime('%Y-%m-%d %H-%M') + source1 + ']'
                    log('errXXX 718 filename1= %r' % filename1)
            else:
                log('errXXX 720 filetitle= %r' % filetitle)
                filename1 = recordPath + filetitle + orgduration+ '['+datetime.today().strftime('%Y-%m-%d %H-%M') + source1 + ']'
                log('errXXX 722 filename1= %r' % filename1)
        log('errXXX 723 filename1= %r' % filename1)
        subtitlescount = download_subtitles_files(rtmp, filename1)
        ext = definition.ADDONgetSetting('ffmpegoutputtype')
        extorgcollectionraw = definition.ADDONgetSetting('extorgcollection')
        extorgcollection = extorgcollectionraw.split(',')
        if '.' in rtmp:
            extorg = rtmp.rsplit('.',1)[1].lower()  ### extension 2018-06-16
        else:
            extorg = ''
        if extorg == 'm3u' or extorg == 'm3u8' :   ### Don't use m3u or m3u8 as filenames
            extorg = ''
        log('errXXX 0:ext= %r\nextorgcollectionraw= %r\nextorgcollection= %r\nextorg= %r\nlen(extorg)= %r'% (ext, extorgcollectionraw, extorgcollection, extorg,len(extorg)))
        if not ext in extorgcollection:
            log('errXXXNOT ext in extorgcollection')
            if len(ext) > 1 and len(ext) < 6:
                if len(extorgcollectionraw) > 0:
                    log('len(extorgcollectionraw) > 0')
                    definition.ADDONsetSetting('extorgcollection',ext +',' + extorgcollectionraw)
                    xbmc.sleep(500)
                    extorgcollectionrawNEW = definition.ADDONgetSetting('extorgcollection')
                    if extorgcollectionrawNEW  == extorgcollectionraw:
                        definition.ADDONsetSetting('extorgcollection',ext +',' + extorgcollectionraw)
                        log('NOT ext in extorgcollection - TRY AGAIN')
                else:
                    log('len(extorgcollectionraw) == 0')
                    definition.ADDONsetSetting('extorgcollection',ext)
        if not extorg in extorgcollection:
            log('NOT extorg in extorgcollection')
            if len(extorg) > 1 and len(extorg) < 6:
                if len(extorgcollectionraw) > 0:
                    log('len(extorgcollectionraw) > 0')
                    definition.ADDONsetSetting('extorgcollection',extorg +',' + extorgcollectionraw)
                    xbmc.sleep(500)
                    extorgcollectionrawNEW = definition.ADDONgetSetting('extorgcollection')
                    if extorgcollectionrawNEW  == extorgcollectionraw:
                        definition.ADDONsetSetting('extorgcollection',extorg +',' + extorgcollectionraw)
                        log('NOT extorg in extorgcollection - TRY AGAIN')
                else:
                    log('len(extorgcollectionraw) == 0')
                    definition.ADDONresetSetting('extorgcollection',extorg)
        else:
            log('extorg in extorgcollection')
            """
            if len(extorg) > 1 and len(extorg) < 6:
                if len(extorgcollectionraw) > 0:
                    definition.ADDONsetSetting('extorgcollection',extorg +',' + extorgcollectionraw)
                else:
                    definition.ADDONsetSetting('extorgcollection',extorg)
            """
        ###if (extorg == 'mkv' or extorg == 'mp4' or extorg == 'ts') and definition.ADDONgetSetting('useknownextensions') == 'true' :
        if (len(extorg) > 1 and len(extorg) < 6 and definition.ADDONgetSetting('useknownextensions') == 'true') or 'multisub' in title.lower().replace('-',''):   ### 2018-07-21  if multi-subs save original filename
            if extorg != 'm3u' and extorg != 'm3u8' :
                ext = extorg
        log('errXXX 1:ext= %r\nextorgcollectionraw= %r\nextorgcollection= %r\nextorg= %r'% (ext, extorgcollectionraw, extorgcollection, extorg))
        if ext == '':
            ext = 'mp4'   ### 2020-09-01 Dont accept empty extension
        cmd += '"' + filename1 + '.' + ext +'"'
        log('errXXX 766 filename1= %r' % filename1)
        log('errXXX 767 cmd= %r' % cmd)
        infofilename = filename1 + '.txt'
        
        if 'DR NU' in title:
            subtitlesfilename = filename1 + '.da.srt'   ### .en.srt or .da.srt
            subtitlesincluded = 'Kilden indeholder undertekster'
        else:
            subtitlesfilename = filename1 + '.en.srt'   ### .en.srt or .da.srt
            subtitlesincluded = 'The source includes subtitles'
        #cmd += ' --rtmp "' + rtmp
        #cmd += '"'
        logfilename = filename1 + '.log'   ### 2023-12-23
        cmd += ' 2> "' + filename1 + '.log"'   ### Save FFMPEG log 2018-10-22
        ###xbmc.log('recordffmpeguri.py: cmd= %s' % repr(cmd))
        log('cmd= %r' % cmd)
        nowHM=datetime.today().strftime('%H:%M')
        utils.notification('Recording %s [COLOR green]started %s[/COLOR]' % (title, nowHM))
        try:
            titleFile = filename1 + '.tit'
            LF = open(titleFile, 'w')  ### 2020-11-03
            if OrgTitle != '':
                tit = OrgTitle
            else:
                tit = title
            if '[' in tit :
                tit = tit.replace('[',orgduration +'[',1)
            else:
                tit = tit + orgduration
            LF.write(tit)
            # Close our file so no further writing is posible.
            LF.close()
            try:
                os.chmod(titleFile, 0o776 )
                log('titleFile permission set to 0776')
            except Exception as  e:
                log('err 748 Exception: %r' % e)
                pass
                log('Failed to set titleFile permission to 0776: ' + repr(e))
        except Exception as  e:
            log('err 751 Exception: %r' % e)
            pass
            log('error writing titleFile= %r\n%r' % (titleFile,e))
        try:
            # Create file with info on recording 'infofilename'
            ### LF = open(infofilename, 'a')
            LF = open(infofilename, 'w')  ### 2017-08-09
            crlf = '\r\n'
            # Write to our text file the information we have provided and then goto next line in our file.
            LF.write('Recorded using: ' + definition.ADDONgetAddonInfo('name')+ crlf)
            LF.write('Version= ' + definition.ADDONgetAddonInfo('version')+ crlf)
            LF.write('Version Info= ' + utils.version()+ crlf)
            ### LF.write('Version Date= ' + utils.versiondate()+ crlf)
            program  = sys.argv[0]
            LF.write('Program Name= ' + program+ crlf)
            LF.write('Platform= ' + definition.ADDONgetSetting('platform')+ crlf)
            LF.write('Running on= ' + definition.ADDONgetSetting('runningon')+ crlf)
            LF.write('OS= ' + definition.ADDONgetSetting('os')+ crlf)
            LF.write('Record Path= ' + definition.ADDONgetSetting('record_path')+ crlf + crlf)
            LF.write('Record Command:' + crlf + cmd+ crlf + crlf)
            LF.write('Title= ' + OrgTitle + crlf)
            #LF.write('PlayChannel= ' + playchannel + crlf)
            #LF.write('cat= ' + cat + crlf)
            #LF.write('StartTime= ' + startTime + crlf)
            #LF.write('EndTime= ' + endTime + crlf)
            if not str(int(round(int(duration)))) == '0':   ### 2019-01-04 /60 removed - minutes not seconds
                LF.write('Duration= ' + str(int(round(int(duration)))) + ' minutes' + crlf)
            #LF.write('Argv6= ' + argv6 + crlf)
            #LF.write('Argv7= ' + argv7 + crlf)
            LF.write('NameAlarm= ' + nameAlarm + crlf)
            if not len(description) == 3 and not description == 'n a':
                LF.write('Description:' + crlf + recordings.argumenttostring(description).replace(';;',',') + crlf)
            else:
                LF.write('No description!' + crlf)
            if not subtitlesurl == '':
                LF.write(crlf + subtitlesincluded + crlf)
            # Close our file so no further writing is posible.
            LF.close()
            try:
                os.chmod(infofilename, 0o776 )
                log('Infofilename permission set to 0776')
            except Exception as  e:
                log('err 792 Exception: %r' % e)
                pass
                log('Failed to set info filename permission to 0776: ' + repr(e))
            
            infofilename = infofilename.replace('.txt','.nfo')
            LF = open(infofilename.replace('.txt','.nfo'), 'w')   ### 2017-08-09
            # Write to our text file the information we have provided and then goto next line in our file.
            LF.write('<?xml version="1.0" encoding="utf-8"?>' + crlf)
            LF.write('<episodedetails>'+ crlf)
            LF.write('    <title>' + title + '</title>' + crlf)
            if not len(description) == 3 and not description == 'n a':
                LF.write('    <plot>' + recordings.argumenttostring(description) + crlf)
                if not subtitlesurl == '':
                    LF.write(crlf + subtitlesincluded + crlf)
                LF.write('</plot>' + crlf)
            LF.write('</episodedetails>'+ crlf)
            # Close our file so no further writing is posible.
            LF.close()
            try:
                os.chmod(infofilename, 0o776 )
                log('Infofilename permission set to 0776')
            except Exception as  e:
                log('err 813 Exception: %r' % e)
                pass
                log('Failed to set infofilename permission to 0776: ' + repr(e))
            
            log('infofilename= %s written and closed' % (repr(infofilename))) # Add to log
        except Exception as  e:
            log('err 818 Exception: %r' % e)
            pass
            log('error writing infofile= %r\n%r' % (infofilename,e))
        
        if not subtitlesurl == '':
            try:
                log(download_subtitles(subtitlesurl, subtitlesoffset,subtitlesfilename))
            except Exception as  e: 
                log('err 825 Exception: %r' % e)
                log('error getting subtitles: ' + repr(e))
                pass
                log('No subtitles')
        
        if definition.ADDONgetSetting('os')=='11':
            
            utils.runCommand(cmd, LoopCount=0, libpath=None, nameAlarm=nameAlarm)
        else:
            libpath = utils.libPath()
            
            utils.runCommand(cmd, LoopCount=0, libpath=libpath, nameAlarm=nameAlarm)

        nowHM=datetime.today().strftime('%H:%M')
        ###utils.notificationbox('Recording %s [COLOR red]complete[/COLOR] %s' % (title, nowHM))
        if baseurl in uri:
            log('recordUnLock(nameAlarm= %r )' % nameAlarm)
            locking.recordUnlock(nameAlarm)
        ### does log contain 'missing picture' then recording may be defective!
        logsearch = 'missing picture'
        if utils.logcontain(module,logfilename,logsearch):
            recordings.updateRecordingPlanned(nameAlarm, '[COLOR red]Complete in ERROR: ' + logsearch + ' ' + nowHM + '[/COLOR] ' + OrgTitle)
            addErrorToFile(titleFile)
            TryAgain(URIORG, TITLEORG, nameAlarm+'1', OrgTitle, description)
            exit ()
        else:
            recordings.updateRecordingPlanned(nameAlarm, '[COLOR green]Complete ' + nowHM + '[/COLOR] ' + OrgTitle)
            ###TryAgain(URIORG, TITLEORG, nameAlarm+'1', OrgTitle, description)   ### 2023-12-27 TEST if no error
        utils.notification('Recording finished: ' + OrgTitle)
        log('Recording finished: ' + title+ ' at '+ nowHM)
        ###Recordings = definition.ADDONgetSetting('Recordings').replace(nameAlarm,'')
        locking.markUnlock(nameAlarm)
        ###definition.ADDONsetSetting('Recordings',Recordings)
        """
        try:
            Recordings = definition.ADDONgetSetting('Recordings')
            if nameAlarm in Recordings:
                Recordings = Recordings.split(nameAlarm)[1]
                definition.ADDONsetSetting('Recordings',Recordings)    ### only save later recordings
        except Exception as e:
            log('err 855 Exception: %r' % e)
            pass
            log('Error in removing in recordings: %r' % e)
            definition.ADDONresetSetting('Recordings','')  ### Clear recordings if possible
        """
        ### Recording finished - find next VOD and start it even before time
        nextvod = recordings.getNextVOD()
        log('err nextvod=  %r'% nextvod)
        ### [cat, name, startDate, endDate, alarmname, description, playchannel, DB]
        if len(nextvod) == 0: 
            ### If no more waiting VODs - adjust time to record
            nowTS = int(time.mktime(datetime.now().timetuple()))
            try:
                TimeInterval = int(definition.ADDONgetSetting('RecordingFromOtherAddonTimeInterval'))
            except Exception as e:
                log('err 869 Exception: %r' % e)
                pass
                TimeInterval = 30
            nowTSadjusted = nowTS - TimeInterval*60
            nowadjusted = recordings.humantime(nowTSadjusted)
            definition.ADDONresetSetting('RecordingFromOtherAddon',nowadjusted)
        else:
            cat = nextvod[0][0]
            name = nextvod[0][1].replace('[COLOR violet]','').replace('[/COLOR]','')
            startDate = nextvod[0][2]
            endDate = nextvod[0][3]
            alarmname = nextvod[0][4]
            description = nextvod[0][5]
            playchannel = 'VOD'   
            duration = 60
            log('len(nextvod)=  %r'% len(nextvod))
            ### Stop original Alarmname
            recordings.cancelAlarm(alarmname)   ### 2022-08-14
            ###log('xbmc.executebuiltin(CancelAlarm(%r,True)' % alarmname)
            ###xbmc.executebuiltin('CancelAlarm(%s,True)' % alarmname)
            ### Start new recording now
            now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
            ###nowTS = int(time.mktime(datetime.now().timetuple()))
            if endDate < now:
                endDate = now
            log('err recordings.addRecordingPlanned(cat= %r, now= %r, endDate= %r, recordname= %r, nameAlarm= %r, description= %r, playchannel= %r)' % (cat, now, now, name, alarmname, description, playchannel))
            recordings.addRecordingPlanned(cat, now, endDate, name, alarmname, description, playchannel)
            script = os.path.join(definition.ADDONgetAddonInfo('path'), 'recorduriffmpeg.py')
            args     = utils.base64b64encode(cat) + ',' + str(now) + ',' + str(endDate) + ',' + str(duration) + ',' + name + ',' + '60' + ',' + 'True'
            args= args + ',' + alarmname + ',' + utils.base64b64encode(description)
            cmd = 'AlarmClock(%s,RunScript(%s,%s),%d,True)' % (alarmname, script, args, 0)
            log('err xbmc.executebuiltin(cmd= %r)' % cmd)
            xbmc.executebuiltin(cmd)
            