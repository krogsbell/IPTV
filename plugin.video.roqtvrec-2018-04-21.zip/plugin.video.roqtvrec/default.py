#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import calendar
import net
import json
import locking,utils
import recordings
import glob
import definition
import shutil
import urllib2
import xmltodict
import base64
from operator import itemgetter
import updateepg
import findtvguidenotifications

ADDON      = definition.getADDON()
ADDONname  = ADDON.getAddonInfo('name')
ADDONid    = ADDON.getAddonInfo('id')
module     = 'default.py'
datapath   = xbmc.translatePath(ADDON.getAddonInfo('profile'))
progpath   = ADDON.getAddonInfo('path')
origin     = ADDONid +' available_channels'
IPTVuser   = ADDON.getSetting('user')

try:
    higlights = ADDON.getSetting('higlights')
    ###utils.logdev(module,'0 higlights= %r' % higlights)
    higlights = higlights.split('¤¤¤¤')
    if higlights == ['']:
        higlights = []
    utils.logdev(module,'1 higlights= %r' % higlights)
    if higlights != []:
        utils.logdev(module,'higlights= %r' % higlights)
    else:
        ###higlights = []
        utils.logdev(module,'Reset: higlights= %r' % higlights)
    highlightscmp = []
    for high in higlights:
        highlightscmp.append(high.split('#description=')[0] + '#')
except Exception,e:
    pass
    higlights = []
    utils.logdev(module,'higlights RESET= %r, ERROR %r' % (higlights,e))
highlightcount = len(higlights)
utils.logdev(module,'AT START higlights= %r' % higlights)
    
tz = ADDON.getSetting('AdjustTVguideTimeZoneOffset')
if tz == '':
    TimeZone = 0
else:
    TimeZone = int(tz)  
dataepg = []
data= []

def urllibquote_plus(cat):
    try:
        if cat == None:
            return '0'   ### 2018-02-24
        else:
            return urllib.quote_plus(cat)
    except Exception, e:
        pass
        utils.logdev(module,'Error in urllib.quote_plus(cat): ' + repr(e))
        return str(cat)
        
    
def parse_date(dateString):
    return datetime.fromtimestamp(time.mktime(time.strptime(dateString.encode('utf-8', 'replace'), "%Y-%m-%d %H:%M:%S")))

recordPath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_path')))
streamtype = ADDON.getSetting('streamtype').replace('0','m3u8').replace('1','ts').replace('2','rtmp')
###utils.logdev(module,'streamtype= %r' % streamtype)

try:
    recordDisplayPath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_display_path')))
    ###utils.logdev(module,'TEST: ' + recordings.latin1_to_ascii_force('æøåÆØÅ'))
except Exception, e:
    pass
    utils.logdev(module,'error in start: ' + repr(e))
if not os.path.exists(recordDisplayPath):
    recordDisplayPath = recordPath
    ADDON.setSetting('record_display_path',recordDisplayPath)

def LOGIN():
    utils.logdev(module,'LOGIN')
    username = ADDON.getSetting('user')
    password = ADDON.getSetting('pass')
    ###if '@' in username and not (username == '' or password == ''):
    if not (username == '' or password == ''):
        ADDON.setSetting('firstrun','true')
    else:
        utils.logdev(module,'Firstrun.Launch(1)')
        import firstrun
        
        ###restoreXml=recordings.restoreLastSetupXml()
        ###utils.logdev(module,'LOGIN restoreXml= %s' % repr(restoreXml))
        
def AUTH():
        utils.logdev(module,'AUTH')
        
def sessionExpired():
    return False         

def setLiveEPGchannel(ch):
    ###  ['The Vampire Diaries -x- [Serier] .  (E4)', 
    ##'I k\xc3\xb8lvandet p\xc3\xa5 Elena Gilbert\xc2\x92s afsked, begynder s\xc3\xa6son 7 med nogle personer, der kommer igen og andre, der begynder at vakle. Mens Lily fors\xc3\xb8ger at drive en kile ind mellem Salvatorebr\xc3\xb8drerne, kan vi stadig h\xc3\xa5be p\xc3\xa5 at Stefan og Carolines k\xc3\xa6rlighed er st\xc3\xa6rk nok til at overleve. Baseret p\xc3\xa5 L. J. Smiths bogserie: The Vampire Diaries.\nNina Dobrev, Paul Wesley, Ian Somerhalder, Steven R. McQueen, Kat Graham', 
    ###'Rytec - http://forums.openpli.org', 
    ###datetime.datetime(2017, 7, 15, 3, 45), 
    ###datetime.datetime(2017, 7, 15, 4, 30)]
    ###utils.logdev(module,'epg= <%r>, \nurl= %r' % (ch[9], ch[3]))
    """
    setLiveEPG: ch= [
        0'TV2Zulu.dk', 
        1'Dybvaaaaad! [Underholdning] .  (S8E9) [Danmark]', 
        2'OrderedDict([(u\'@start\', u\'20180217182500 +0000\'), (u\'@stop\', u\'20180217190000 +0000\'), (u\'@channel\', u\'TV2Zulu.dk\'), (u\'title\', OrderedDict([(u\'@lang\', u\'da\'), (\'#text\', u\'Dybvaaaaad! [Underholdning] .  (S8E9) [Danmark]\')])), (u\'desc\', OrderedDict([(u\'@lang\', u\'da\'), (\'#text\', u"\'Dybvaaaaad kigger endnu engang dybt i flasken af tvivlsomme tv-koncepter og fjogede bem\\xe6rkninger - denne gang fra Holstebro")]))]) \nKeyError(\'sub_title\',)', 
        3 1518891900, 
        4 1518894000, 
        5"'Dybvaaaaad kigger endnu engang dybt i flasken af tvivlsomme tv-koncepter og fjogede bem\xc3\xa6rkninger - denne gang fra Holstebro \n\nEPG Created 2018-02-13 22:10:39", 
        6'', 
        7'', 
        8'', 
        9'', 
        10'', 
        11'', 
        12'', 
        13'WebGrab+Plus/w MDB & REX Postprocess -- version V2.0.1 -- Jan van Straaten - http://www.webgrabplus.com', 
        14'']
        """
    try:
        ###utils.logdev('XYZxyz setLiveEPGchannel','ch= %r' % ch)
        cats = recordings.catsfromEPGid(ch[0])
        EPG = updateepg.getEPGnow(cats)[0]  ### Insert live EPG in description
        chx = ch[9] + ' \n'
        for indexX in range(0, len(EPG)):
            title = str(EPG[indexX][0])
            description = str(EPG[indexX][1]).replace('(n)','')
            ###starttime = str(EPG[indexX][3].strftime('%H:%M'))
            ###endtime = str(EPG[indexX][4].strftime('%H:%M'))
            starttime = str(datetime.fromtimestamp(EPG[indexX][3]).strftime('%H:%M'))
            endtime = str(datetime.fromtimestamp(EPG[indexX][4]).strftime('%H:%M'))
            chx += ' \n[COLOR lightgreen]'+starttime + ' - ' + endtime + '[B][/COLOR] \n[COLOR blue]'+ title+ '[/COLOR][/B] \n'+ description +' \n'
    except Exception, e:
        pass
        utils.logdev(module,'error setLiveEPGchannel: ' + repr(e))
        chx = 'No EPG or info'
    return chx

    
def setLiveEPG(ch):
    ###  ['The Vampire Diaries -x- [Serier] .  (E4)', 
    ##'I k\xc3\xb8lvandet p\xc3\xa5 Elena Gilbert\xc2\x92s afsked, begynder s\xc3\xa6son 7 med nogle personer, der kommer igen og andre, der begynder at vakle. Mens Lily fors\xc3\xb8ger at drive en kile ind mellem Salvatorebr\xc3\xb8drerne, kan vi stadig h\xc3\xa5be p\xc3\xa5 at Stefan og Carolines k\xc3\xa6rlighed er st\xc3\xa6rk nok til at overleve. Baseret p\xc3\xa5 L. J. Smiths bogserie: The Vampire Diaries.\nNina Dobrev, Paul Wesley, Ian Somerhalder, Steven R. McQueen, Kat Graham', 
    ###'Rytec - http://forums.openpli.org', 
    ###datetime.datetime(2017, 7, 15, 3, 45), 
    ###datetime.datetime(2017, 7, 15, 4, 30)]
    ###utils.logdev(module,'epg= <%r>, \nurl= %r' % (ch[9], ch[3]))
    """
    setLiveEPG: ch= [
    0'tv2zulu', 
    1'TV2Zulu (D)', 
    2'https://danishbits.org/static/bitbucket/users/1480871336.0465.png', 
    3'http://tv2danmark-tv2zulu-live.hls.adaptive.level3.net/tv2danmark/tv2zulu/master.m3u8', 
    4'plugin.video.roqtvrec available_channels', 
    5 1, 
    6 11, 
    7'', 
    8'', 
    9'TV2Zulu.dk', 
    10' \n\rcat= tv2zulu \n\rtvg-id= TV2Zulu.dk \n\rtvg-name= TV2Zulu \n\rgroup-title= DANSK \n\rcatsinlink= ! live \n\rlink= http:/ / tv2danmark-tv2zulu-live.hls.adaptive.level3.net/ tv2danmark/ tv2zulu/ master.m3u8', 
    11 1518541841, 
    12 1480374635]
    """
    try:
        ###utils.logdev('XYZxyz setLiveEPG','ch= %r' % ch)
        if ch[9] == '':
            ch[9] = 'No EPG'
        ### if 'movie' in ch[3] or ch[9] == '':
        if 'movie' in ch[3]:
            chx = ch[10]
        else:
            EPG = updateepg.getEPGnow(ch[0])[0]  ### Insert live EPG in description
            chx = ch[9] + ' \n'
            for indexX in range(0, len(EPG)):
                title = str(EPG[indexX][0])
                description = str(EPG[indexX][1]).replace('(n)','')
                ###starttime = str(EPG[indexX][3].strftime('%H:%M'))
                ###endtime = str(EPG[indexX][4].strftime('%H:%M'))
                starttime = str(datetime.fromtimestamp(EPG[indexX][3]).strftime('%H:%M'))
                endtime = str(datetime.fromtimestamp(EPG[indexX][4]).strftime('%H:%M'))
                chx += ' \n[COLOR lightgreen]'+starttime + ' - ' + endtime + '[B][/COLOR] \n[COLOR blue]'+ title+ '[/COLOR][/B] \n'+ description +' \n'
    except Exception, e:
        pass
        utils.logdev(module,'error setLiveEPG: ' + repr(e))
        chx = 'No EPG or info'
    return chx

def GoHome(view):
    if not view is None and not view is '':
        addDir('[COLOR white][B]%s ==> Home[/B][/COLOR]' % view,'',1,'','','','Go to Home menu from %s' % view)
    else:
        addDir('[COLOR white][B]Home[/B][/COLOR]','',1,'','','','Go to Home menu')

def FAVORITES():
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###now= datetime.today()
    ###utils.logdev(module,'FAVORITES')
    GoHome('Favorites')
    conn = recordings.getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE favorite=? and visible=? and source=?", ['True',1,origin])  ### WHERE id=? and source=?", [cat,origin])
    favorites = c.fetchall()
    favorites = sorted(favorites, key=itemgetter(1)) ### Sort by name
    ###utils.logdevarray(module+'-favorite',favorites)
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        if ch[8] == 1:   ### Channel with Archive/Catch up
            chname = ch[1] + ' (A)'
        else:
            chname = ch[1]
        addDir(chname,ch[3],200,ch[2],ch[0],'',setLiveEPG(ch))
    ###conn.commit()
    c.close()  
    setView('movies', 'main-view')  

def NEWCHANNELS():
    now = int(time.mktime(datetime.now().timetuple()))
    ###now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###now= datetime.today()
    ###utils.logdev(module,'NEWCHANNELS')
    GoHome('New Channels and Vod')
    ftvntvini = os.path.join(datapath,'New Channels or VOD '+ADDONname) + '.txt'
    LF = open(ftvntvini, 'w')
    conn = recordings.getConnection()
    c = conn.cursor()
    ####c.execute("SELECT * FROM channels WHERE NOT created = ?", [None])   #####
    c.execute("SELECT * FROM channels WHERE source=?",[origin])
    favorites = c.fetchall()
    favorites = sorted(favorites, key=itemgetter(12), reverse=True) ### Sort by Created date
    j = 0
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        ###now = int(time.mktime(datetime.now().timetuple()))
        created = favorites[index][12]
        ### utils.logdev(module,'created= %r' % created)
        ### timestamp = time.mktime(dt_obj.timetuple())
        ### dt_obj = datetime.fromtimestamp(timestamp)
        
        if not created is None:
            createdplus =    created + 5356800    ### 62 * 24 * 60 * 60  created-timedelta(days=62)
            if createdplus > now:
                created = str(datetime.fromtimestamp(created).strftime('%Y-%m-%d'))
                if ch[8] == 1:   ### Channel with Archive/Catch up
                    chname = '[COLOR lightgreen]' + created + ': [/COLOR]' + ch[1] + ' (A)'
                else:
                    chname = '[COLOR lightgreen]' + created + ': [/COLOR]' + ch[1]
                j += 1
                LF.write(format(j, '04d') + ' ' + created + ': ' + ch[1] + '\n')
                ###LF.write(created + ': ' + ch[1] + '\n')
                addDir(chname,ch[3],200,ch[2],ch[0],'',setLiveEPG(ch))
    c.close()  
    LF.close()
    setView('movies', 'main-view')  

def RECURSIVECHANNELS():
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###now= datetime.today()
    ###utils.logdev(module,'RECURSIVECHANNELS')
    GoHome('Recursive Search Channels')
    conn = recordings.getConnection()
    c = conn.cursor()
    ####c.execute("SELECT * FROM channels WHERE NOT created = ?", [None])   #####
    c.execute("SELECT * FROM channels WHERE (epg_channel like '% (R)%' or favorite=?) and visible=? and source=?", ['True',1,origin])
    favorites = c.fetchall()
    favorites = sorted(favorites, key=itemgetter(1)) ### Sort by name
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        ###created = favorites[index][11]
        ###if created + timedelta(days=62) > datetime.today():
        ###created = favorites[index][11].strftime('%Y-%m-%d')
        created = str(datetime.fromtimestamp(favorites[index][11]).strftime('%Y-%m-%d'))
        if ch[8] == 1:   ### Channel with Archive/Catch up
            chname = ch[1] + ' (A)'
        else:
            chname = ch[1]
        addDir(chname,ch[3],200,ch[2],ch[0],'',setLiveEPG(ch))
    c.close()  
    setView('movies', 'main-view')  

def MYSELECTEDCHANNELS():
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###now= datetime.today()
    ###utils.logdev(module,'MYSELECTEDCHANNELS')
    GoHome('Direct Channels')
    conn = recordings.getConnection()
    c = conn.cursor()
    ###c.execute("SELECT * FROM channels WHERE weight > ? and weight <? and visible =?", [0,101,1])
    c.execute("SELECT * FROM channels WHERE title like '% (D)%' and visible=? and source=?", [1,origin])
    favorites = c.fetchall()
    ###favorites = sorted(favorites, key=itemgetter(6))   ### Sort by weight
    ###favorites = sorted(favorites, key=itemgetter(0))   ### Sort by id
    favorites = sorted(favorites, key=itemgetter(1))   ### Sort by title
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
        ###def addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
        ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
        if ch[8] == 1:
            chname = ch[1] + ' (A)'
        else:
            chname = ch[1]
        """
        if ch[6] >= 1000:
            ch[6] -= 1000
        chname = '[COLOR lightgreen]' + str(ch[6]) +'[/COLOR]  ' + chname
        """
        addDir(chname,ch[3],200,ch[2],ch[0],'',setLiveEPG(ch))
    ###conn.commit()
    c.close()  
    setView('movies', 'main-view')
        
def HIDDENCHANNELS():
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###now= datetime.today()
    ###utils.logdev(module,'HIDDENCHANNELS')
    GoHome('Hidden Channels')
    conn = recordings.getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE visible=? and source=?", [0,origin])
    favorites = c.fetchall()
    favorites = sorted(favorites, key=itemgetter(1)) ### Sort by name
    ###utils.logdevarray(module+'-favorite',favorites)
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
        ###def addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
        ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
        if ch[8] == 1:
            chname = ch[1] + ' (A)'
        else:
            chname = ch[1]
        ###chname = '[COLOR lightgreen]' + str(ch[6]) +'[/COLOR]  ' + chname
        addDir(chname,ch[3],200,ch[2],ch[0],'',setLiveEPG(ch))
    ###conn.commit()
    c.close()  
    setView('movies', 'main-view')

def ARCHIVE():
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###now= datetime.today()
    ###utils.logdev(module,'ARCHIVE')
    GoHome('Archive')
    conn = recordings.getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE catchup=? and visible=?", ['1',1])
    favorites = c.fetchall()
    favorites = sorted(favorites, key=itemgetter(1))
    ###utils.logdevarray(module+'-favorite',favorites)
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')

            else:
                ch.append(favorites[index][i])
        ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
        ###def addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
        ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
        if ch[8] == 1:
            chname = ch[1] + ' (A)'
        else:
            chname = ch[1]
        addDir(chname,ch[3],200,ch[2],ch[0],'',setLiveEPG(ch))
    ###conn.commit()
    c.close()  
    setView('movies', 'main-view')
    
    """
    favorites = c.fetchall()
    favorites = sorted(favorites, key=itemgetter(1))
    ###utils.logdevarray(module+'-archive',favorites)
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
        ###def addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
        ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
        if ch[8] == 1:
            chname = ch[1] + ' (A)'
        else:
            chname = ch[1]
        addDir(chname,ch[3],200,ch[2],ch[0],'',ch[9])
    ###conn.commit()
    c.close()  
    setView('movies', 'main-view')      
    """
def SearchEPG(name):
    search_entered = ADDON.getSetting('searchepgvodcha')
    keyboard = xbmc.Keyboard(search_entered, '[COLOR lightgreen][B]Please Enter '+str(name)+' (<ESC> or Cancel to clear)[/B][/COLOR]')
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_entered = keyboard.getText()
        if search_entered == None:
            return False 
        else:
            ADDON.setSetting('searchepgvodcha',search_entered)   ### 2018-02-15
    else:
        ADDON.setSetting('searchepgvodcha','')
    return search_entered 
        
def PROGRAMSEARCH():
    """
    try:  ### Get Ritzau icons from dr.dk
        iconsatdr = 'https://www.dr.dk/assets/css/shared/ritzau-logos.css'
        file = urllib2.urlopen(iconsatdr)
        data = file.read()
        file.close()
        utils.logdev(module,'PROGRAMSEARCH iconsatdr= %r' % data)
        ### Example icon https://www.dr.dk/assets/img/ritzau-logos/ritzau-logo-dk4.png
        data = data.replace('\n','')  ### remove line feed/Carrige return
        data = data.split('../..')
        for i in range(1, len(data)):
            iconlink = data[i].split('"')[0]
            utils.logdev(module,'PROGRAMSEARCH iconlink= %r' % iconlink)
            addDir(iconlink,'url',0,'https://www.dr.dk/assets'+iconlink,'','','DR.DK ritzau-logo')
    except Exception,e:
        pass
        utils.logdev(module,'PROGRAMSEARCH iconsatdr Exception= %r' % e)
    """
    searchcount = 0
    searchcountmax = 98
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    nowDT= datetime.today()
    GoHome('Search EPG Programs')
    
    searchText = SearchEPG('Program to search for')
    if searchText:
        addDir('[COLOR lightgreen]Search EPG Programs:[/COLOR] [B]'+searchText+'[/B]','url',2050,'','','','Search all '+ADDONname +' channels EPG')
        searchText = '%' + searchText + '%'
        utils.logdev(module,'PROGRAMSEARCH searchText= %r' % searchText)
        conn = recordings.getConnection()
        c = conn.cursor()
        """
        setLiveEPG: ch= [
        0'tv2zulu', 
        1'TV2Zulu (D)', 
        2'https://danishbits.org/static/bitbucket/users/1480871336.0465.png', 
        3'http://tv2danmark-tv2zulu-live.hls.adaptive.level3.net/tv2danmark/tv2zulu/master.m3u8', 
        4'plugin.video.roqtvrec available_channels', 
        5 1, 
        6 11, 
        7'', 
        8'', 
        9'TV2Zulu.dk', 
        10' \n\rcat= tv2zulu \n\rtvg-id= TV2Zulu.dk \n\rtvg-name= TV2Zulu \n\rgroup-title= DANSK \n\rcatsinlink= ! live \n\rlink= http:/ / tv2danmark-tv2zulu-live.hls.adaptive.level3.net/ tv2danmark/ tv2zulu/ master.m3u8', 
        11 1518541841, 
        12 1480374635]
        
        setLiveEPG: ch= [
        0'TV2Zulu.dk', 
        1'Dybvaaaaad! [Underholdning] .  (S8E9) [Danmark]', 
        2'OrderedDict([(u\'@start\', u\'20180217182500 +0000\'), (u\'@stop\', u\'20180217190000 +0000\'), (u\'@channel\', u\'TV2Zulu.dk\'), (u\'title\', OrderedDict([(u\'@lang\', u\'da\'), (\'#text\', u\'Dybvaaaaad! [Underholdning] .  (S8E9) [Danmark]\')])), (u\'desc\', OrderedDict([(u\'@lang\', u\'da\'), (\'#text\', u"\'Dybvaaaaad kigger endnu engang dybt i flasken af tvivlsomme tv-koncepter og fjogede bem\\xe6rkninger - denne gang fra Holstebro")]))]) \nKeyError(\'sub_title\',)', 
        3 1518891900, 
        4 1518894000, 
        5"'Dybvaaaaad kigger endnu engang dybt i flasken af tvivlsomme tv-koncepter og fjogede bem\xc3\xa6rkninger - denne gang fra Holstebro \n\nEPG Created 2018-02-13 22:10:39", 
        6'', 
        7'', 
        8'', 
        9'', 
        10'', 
        11'', 
        12'', 
        13'WebGrab+Plus/w MDB & REX Postprocess -- version V2.0.1 -- Jan van Straaten - http://www.webgrabplus.com', 
        14'']
        """
        ###programs(channel, title, sub_title, start_date, end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
        ###c.execute("SELECT DISTINCT p.*, c.epg_channel FROM channelsRecursive c, programs p WHERE p.channel = c.epg_channel AND p.title = ? AND p.start_date >= ?",[program, now])
        """
        ch= [
0'TV2.dk', 
1'Harry Potter og halvblodsprinsen [Film] .  (Harry Potter and the Half-Blood Prince) [England]', 2"OrderedDict([(u'@start', u'20180213133000 +0000'), (u'@stop', u'20180213160000 +0000'), (u'@channel', u'TV2.dk'), (u'title', OrderedDict([(u'@lang', u'da'), ('#text', u'Harry Potter og halvblodsprinsen [Film] .  (Harry Potter and the Half-Blood Prince) [England]')])), (u'desc', OrderedDict([(u'@lang', u'da'), ('#text', u'Lord Voldemort har strammet sit greb om b\\xe5de Mugglerne og troldmandsverdenen, og Hogwarts er ikke l\\xe6ngere sikker. Harry Potter (Daniel Radcliff) har en mistanke om, at faren allerede er indenfor skolens mure, men Dumbledore (Michael Gambon) skyder denne tanke v\\xe6k, og vil hellere forberede Harry Potter p\\xe5 den endelige kamp mod Voldemort. De ops\\xf8ger Dumbledores gamle ven og kollega, Professor Horace Slughorn (Jim Broadbent), som ligger inde med hemmelig viden om Voldemort. Mens de arbejder med dette, blomstrer romantikken ogs\\xe5 p\\xe5 Hogwarts, men det endelige slag n\\xe6rmer sig - og snart vil alt m\\xe5ske v\\xe6re forandret! nDen sjette Harry Potter-film, der baserer sig p\\xe5 J. K. Rowlings roman-serie.\\nDavid Yates\\nDaniel Radcliffe\\nRupert Grint\\nEmma Watson\\nMichael Gambon\\nAlan Rickman\\nJim Broadbent\\nHelen Bonham Carter\\nTomothy Spall')]))]) \nKeyError('sub_title',)", 
3 1518528600, 
4 1518537600, 
5 'Lord Voldemort har strammet sit greb om b\xc3\xa5de Mugglerne og troldmandsverdenen, og Hogwarts er ikke l\xc3\xa6ngere sikker. Harry Potter (Daniel Radcliff) har en mistanke om, at faren allerede er indenfor skolens mure, men Dumbledore (Michael Gambon) skyder denne tanke v\xc3\xa6k, og vil hellere forberede Harry Potter p\xc3\xa5 den endelige kamp mod Voldemort. De ops\xc3\xb8ger Dumbledores gamle ven og kollega, Professor Horace Slughorn (Jim Broadbent), som ligger inde med hemmelig viden om Voldemort. Mens de arbejder med dette, blomstrer romantikken ogs\xc3\xa5 p\xc3\xa5 Hogwarts, men det endelige slag n\xc3\xa6rmer sig - og snart vil alt m\xc3\xa5ske v\xc3\xa6re forandret! nDen sjette Harry Potter-film, der baserer sig p\xc3\xa5 J. K. Rowlings roman-serie.\nDavid Yates\nDaniel Radcliffe\nRupert Grint\nEmma Watson\nMichael Gambon\nAlan Rickman\nJim Broadbent\nHelen Bonham Carter\nTomothy Spall \n\nEPG Created 2018-02-14 10:10:40', 
6'', 
7'', 
8'', 
9'', 
10'', 
11'', 
12'', 
13'WebGrab+Plus/w MDB & REX Postprocess -- version V2.0.1 -- Jan van Straaten - http://www.webgrabplus.com', 
14'', 
15'TV2 dk (D)', 
16'https://danishbits.org/static/bitbucket/users/1485171091.8076.png', 
17'http://tv2danmark-tv2nord-live.hls.adaptive.level3.net/tv2danmark/tv2nord/master.m3u8', 
18'']
        """
        c.execute("SELECT p.*, c.title, c.logo, c.stream_url, c.catchup, c.id FROM programs p, channels c WHERE p.channel = c.epg_channel AND p.title LIKE ?  and (c.title like '% (D)%' or c.epg_channel like '% (R)%' or c.favorite=? or c.catchup=?) and c.visible=? and c.source=? COLLATE NOCASE", [searchText,'True',1,1,origin])
        ###c.execute("SELECT p.*, c.title, c.logo, c.stream_url, c.catchup, c.id FROM programs p, channels c WHERE (c.epg_channel = p.channel) AND p.title LIKE ? and (c.title like '% (D)%' or c.epg_channel like '% (R)%' or c.favorite=? or c.catchup=?) and c.visible=? COLLATE NOCASE", [searchText,'True',1,1])  
        utils.logdev(module,'PROGRAMSEARCH searchText= %r,origin= %r' % (searchText,origin))
        favorites = c.fetchall()
        try:
            utils.logdev(module,'PROGRAMSEARCH favorites= %r' % favorites)
            for fav in favorites:
                utils.logdev(module,'PROGRAMSEARCH fav= %r' % fav[0])
        except:
            pass
        favorites = sorted(favorites, key=itemgetter(3)) ### Sort by start date
        utils.logdev(module,'PROGRAMSEARCH sorted favorites= %r' % favorites)
        for index in range(0, len(favorites)):
            ch = []
            for i in range(0, len(favorites[index])):
                if favorites[index][i] == None:
                    ch.append('')
                else:
                    ch.append(favorites[index][i])
            utils.logdev(module,'PROGRAMSEARCH ch= %r' % ch)
            """
            channels = recordings.catsfromEPGid(ch[0])
            utils.logdev('XYZxyz','channels= %r' % channels)
            utils.logdev('XYZxyz','type(channels)= %r' % type(channels))
            ###def addDir( name,url,mode,iconimage='',cat='',date='',description='',startDate='',endDate='',recordname='',whatsup=''):
            foundprograms = []
            if type(channels) not in [str, unicode]:
                for cha in channels:
                    if cha != '0':
                        foundprograms.append(cha)
            else:
                if channels != '0':
                    foundprograms.append(channels)
                
            for fprograms in foundprograms:
                guide = updateepg.getEPG(fprograms)
                try:
                    guideEPG = guide[0]
                except Exception, e:
                    pass
                    utils.logdev(module,'Error in getting TV Guide\n' + repr(e))
                    return
                nameEPG = guide[1]
                tv_archive = guide[2]
                tv_archive_duration= guide[3]
                epg_channel_id = guide[4]
                
                namech = nameEPG
                if namech == 'None' or namech == '':
                    namech = recordings.ChannelName(fprograms)
            addDir(namech +': '+ch[1],ch[3],200,ch[2],fprograms,'',ch[5])
            """
            try:
                startDate= ch[3]
                if type(startDate) == int:
                    startDate= datetime.fromtimestamp(float(ch[3]))
                    endDate= datetime.fromtimestamp(float(ch[4]))
                else:
                    startDate= ch[3]
                    endDate= ch[4]
                try:
                    ArchiveOffset = int(ADDON.getSetting('archiveoffset'))
                except:
                    pass
                    ArchiveOffset = 1
                startDateCU= startDate + timedelta(seconds = (ArchiveOffset - TimeZone)*3600 -60)  ### USE UK TimeZone and start 1 minutes early
            except Exception, e:
                pass
                startDate=''
                startDateCU=''
                endDate=''
                utils.logdev(module,'PROGRAMSEARCH Error in getting dates\n' + repr(e))
            name= ch[15] + ': [B]' + ch[1] + '[/B]'
            cat = ch[19]
            namech = name
            newiconurl = ch[16]
            channelurl = ch[17]
            tv_archive = ch[18]
            recordname= ch[1]
            StartDateTime = ''
            Duration = ''
            try:
                StartDateTime = ' \nStart ' + startDate.strftime('%Y-%m-%d %H:%M')
                dura = (endDate - startDate)/60
                Duration = ' \nDuration [' + str(dura)[-5:] +'] \n'  ###2018-03-08
                #Duration = ' \nDuration ' + str(dura) + ' \n'
                try:
                    if 'EPG Created ' in ch[5]:
                        EPGtime = 'EPG Created ' + ch[5].split('EPG Created ')[1][0:19]+'\n'
                except:
                    pass
                    EPGtime = ''
                description= (namech + ' (' +cat+'):'+StartDateTime+Duration + EPGtime +'\n'+ch[5])   ###.encode("utf-8")
                utils.logdev(module,'PROGRAMSEARCH Duration= %r' % Duration )
            except Exception, e:
                pass
                utils.logdev(module,'PROGRAMSEARCH Error in getting duration\n' + repr(e))
                description = (recordings.latin1_to_ascii_force(namech) + ' (' +recordings.latin1_to_ascii_force(cat)+'):' +StartDateTime+Duration+ recordings.latin1_to_ascii_force(ch[1]))
            description = description.replace('(n)','\n').replace('.n)','. \n') 
            try:
                if tv_archive == 1 and startDate < nowDT:  ### startDate <-- endDate
                    name='[COLOR salmon]%s[/COLOR]'%(name)
                    time=startDate.strftime('Arc %d.%m %H:%M  ')
                    ###addDir(name,url,mode,iconimage='',cat='',date='',description='',startDate='',endDate='',whatsup='')
                    ###duration = str(timedelta.total_seconds(endDate - startDate)/60 + 16)  ### duration plus 15 min
                    ###utils.logdev(module+'repr(endDate - startDate)=',repr(endDate - startDate))
                    ### ANDROID and Linux version
                    duration = str(int(repr(endDate - startDate).replace('datetime.timedelta(0, ','').split(')')[0].split(',')[0])/60 + 16) ### duration plus 15 min + 1 min ahead
                    start    = startDateCU.strftime('%Y-%m-%d:%H-%M')
                    url = definition.getBASEURL() + '/streaming/timeshift.php?username='+ADDON.getSetting('user')+'&password='+ADDON.getSetting('pass')+'&stream='+cat+'&duration='+duration+'&start='+start
                    ###utils.logdev(module,'2020 url= ' + url)
                    searchcount += 1
                    if searchcount >= searchcountmax:
                        if searchcount == searchcountmax:
                            addDir('[COLOR red][B]Search limit reached[/B][/COLOR]' ,'',0,'','0','0','Limit your search!','0','0','')
                    else:
                        addDir(time+name,url,2020,newiconurl,cat,startDate,description,startDate,endDate,recordname) ### Watch or record Archive
                elif tv_archive != 1 and endDate < nowDT :  ### Show History (1 day)
                    try:
                        hourstoshow = int(ADDON.getSetting('showhistoryintvguide'))
                        ###utils.logdev(module,'H start= %r, end= %r' % (startDate, endDate))
                        name='[COLOR cyan]%s[/COLOR]'%(name)
                        time=startDate.strftime('His %d.%m %H:%M  ')
                        if endDate > nowDT - timedelta(hours = hourstoshow):
                            searchcount += 1
                            if searchcount >= searchcountmax:
                                if searchcount == searchcountmax:
                                    addDir('[COLOR red][B]Search limit reached[/B][/COLOR]' ,'',0,'','0','0','Limit your search!','0','0','')
                            else:
                                addDir(time+name,'url',200,newiconurl,cat,startDate,description,startDate,endDate,recordname)
                    except:
                        pass
                elif startDate <= nowDT and nowDT <= endDate:
                    name='[COLOR yellow]%s[/COLOR]'%(name)
                    time=startDate.strftime('Now %d.%m %H:%M  ')
                    url = channelurl
                    searchcount += 1
                    if searchcount >= searchcountmax:
                        if searchcount == searchcountmax:
                            addDir('[COLOR red][B]Search limit reached[/B][/COLOR]' ,'',0,'','0','0','Limit your search!','0','0','')
                    else:
                        """
                        if '[' in name:
                            name = '[B]' + name.replace('[','\n[COLOR lightwhite][/B][I][',1) + '[/I]'
                            name = name.split('\n')
                            line1 = name[0]
                            lenline1 = len(line1)
                            line2 = name[1]
                            lenline2 = len(line2)
                            if lenline1 < lenline2:
                                line1 = line1 + ' ' * (lenline2 - lenline1 - 16)
                            name = line1 +'\n' + line2    ### +'.'+ str(lenline1)+'.'+ str(lenline2)
                        else:
                            name = '[B]' + name + '[/B]'
                        """
                        addDir(time+name,url,200,newiconurl,cat,startDate,description,startDate,endDate,recordname)
                elif startDate > nowDT and endDate > nowDT:
                    ### Find programs that are recording
                    recprograms = recordings.isRecording(cat,recordname,startDate,endDate)
                    utils.logdev(module,'PROGRAMSEARCH Is program: %r beeing recorded? SD= %r ED= %r ActivePrograms: %r' %(name,startDate,endDate,recprograms))
                    if recprograms:
                        name='[COLOR red]%s[/COLOR]'%(name)
                        namecolor='[B][COLOR red]'
                    else:
                        name='[COLOR lightgreen]%s[/COLOR]'%(name)
                        namecolor='[B][COLOR lightgreen]'
                    
                    time=startDate.strftime('Rec %d.%m %H:%M  ')
                    searchcount += 1
                    if searchcount >= searchcountmax:
                        if searchcount == searchcountmax:
                            addDir('[COLOR red][B]Search limit reached[/B][/COLOR]' ,'',0,'','0','0','Limit your search!','0','0','')
                    else:
                        if '[' in recordname:   ### 2018-04-21
                            name = ch[15] + ': '+ namecolor + recordname.replace('[','[/COLOR][/B]\n[COLOR lightwhite][I][',1) + '[/COLOR][/I]'
                            recordnamesizes = recordname.replace('[','aXaXa',1).split('aXaXa')
                            name = name.split('\n')
                            line1 = name[0]
                            lenline1 = len(recordnamesizes[0])
                            line2 = name[1]
                            lenline2 = len(recordnamesizes[1])
                            if lenline1 < lenline2:
                                line1 = line1 + ' ' * (lenline2 - lenline1 )
                            #dialog = xbmcgui.Dialog()
                            #dialog.ok('[COLOR white]ROQTV Test[/COLOR]',recordname,repr(recordnamesizes)+ ' 1= ' +repr(lenline1)+ ' 2= ' + repr(lenline2))
    
                            name = line1 +'\n' + line2  
                        else:
                            name = '[B]' + name ### + '[/B]'
                        
                        addDir(time+name,'url',2001,newiconurl,cat,startDate.strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20'),description,startDate.strftime('%Y-%m-%d %H:%M:%S'),endDate.strftime('%Y-%m-%d %H:%M:%S'),recordname) ### Record
                else:
                    utils.logdev(module,'PROGRAMSEARCH ERROR start= %r, end= %r' % (startDate, endDate))
            except Exception, e:
                pass
                utils.logdev(module,'PROGRAMSEARCH Error in setting menu\n' + repr(e))
            
        c.close()  
        setView('movies', 'main-view')      
              
def CHANNELSSEARCH():
    searchcount = 0
    searchcountmax = 98
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    GoHome('Search Channels')
    
    searchText = SearchEPG('Channel or VOD to search for')
    if searchText != '':
        addDir('[COLOR lightgreen]Search Channels and VOD: [/COLOR][B]'+searchText+'[/B]','url',2008,'','','','Search all '+ADDONname +' channels, VOD and all channels from extra XMLTV file ')
        searchText = '%' + searchText + '%'
        
        conn = recordings.getConnection()
        c = conn.cursor()
        c.execute("SELECT * FROM channels WHERE stream_url <> ? and visible=? and title LIKE ? COLLATE NOCASE", ['url',1,searchText])
        favorites = c.fetchall()
        ###utils.logdev(module+'-archive',repr(len(favorites)))
        favorites = sorted(favorites, key=itemgetter(1))
        ###utils.logdev(module+'-archive',repr(len(favorites)))
        for index in range(0, len(favorites)):
            ch = []
            for i in range(0, len(favorites[index])):
                if favorites[index][i] == None:
                    ch.append('')
                else:
                    ch.append(favorites[index][i])
            ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
            ###def addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
            ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
            if ch[8] == 1:
                chname = ch[1] + ' (A)'
            else:
                chname = ch[1]
            ###chx = ch[10]    ### Don't insert live EPG in description
            ###utils.logdev(module,'cat= %r, description= %r' % (ch[0],setLiveEPG(ch)))  ### 2017-07-29
            searchcount += 1
            if searchcount >= searchcountmax:
                if searchcount == searchcountmax:
                    addDir('[COLOR red][B]Search limit reached[/B][/COLOR]' ,'',0,'','0','0','Limit your search!','0','0','')
            else:
                addDir(chname,ch[3],200,ch[2],ch[0],'',setLiveEPG(ch))
        ###conn.commit()
        c.close()  
        setView('movies', 'main-view')      
        
def CHANNELSROQ():
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###now= datetime.today()
    ###utils.logdev(module,'CHANNELSROQ')
    GoHome('Channels')
    conn = recordings.getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE stream_url <> ? and visible=?", ['url',1])
    favorites = c.fetchall()
    ###utils.logdev(module+'-archive',repr(len(favorites)))
    favorites = sorted(favorites, key=itemgetter(1))
    ###utils.logdev(module+'-archive',repr(len(favorites)))
    for index in range(0, len(favorites)):
        ch = []
        for i in range(0, len(favorites[index])):
            if favorites[index][i] == None:
                ch.append('')
            else:
                ch.append(favorites[index][i])
        ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
        ###def addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
        ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
        if ch[8] == 1:
            chname = ch[1] + ' (A)'
        else:
            chname = ch[1]
        ###chx = ch[10]    ### Don't insert live EPG in description
        ###utils.logdev(module,'cat= %r, description= %r' % (ch[0],setLiveEPG(ch)))  ### 2017-07-29
        addDir(chname,ch[3],200,ch[2],ch[0],'',setLiveEPG(ch))
    ###conn.commit()
    c.close()  
    setView('movies', 'main-view')      
"""

http://roq-tv.net:25461/live/XXX/XXXX!/631.ts

http://roq-tv.net:25461/streaming/timeshift.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass') +'&stream=628&duration=120&start=2017-05-03:15-00

import urllib2
mp3file = urllib2.urlopen("http://www.example.com/songs/mp3.mp3")
with open('test.mp3','wb') as output:
  output.write(mp3file.read())

def addDir(name,url,mode,iconimage,description,fanart,genre=''):
        u=sys.argv[0]+"?url="+urllibquote_plus(url)+"&mode="+str(mode)+"&name="+urllibquote_plus(name)+"&iconimage="+urllibquote_plus(iconimage)+"&description="+urllibquote_plus(description)+"&genre="+urllibquote_plus(genre)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description,"Genre": genre} )
        liz.setProperty('fanart_image',str(fanart))
        if mode ==200:
            liz.setProperty("IsPlayable","true")
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        .......
        try:
        kodilog = xbmc.translatePath(os.path.join('special://logpath' , 'kodi.log'))
        #print kodilog
        try: logfile = open(kodilog,'r')
        except:
            pass
            kodilog = xbmc.translatePath(os.path.join('special://logpath' , 'xbmc.log'))
            #print kodilog
            try: logfile = open(kodilog,'r')
            except:
                pass
                kodilog = xbmc.translatePath(os.path.join('special://logpath' , 'tvmc.log'))
                #print kodilog
                logfile = open(kodilog,'r')
        #print kodilog
        #print repr(logfile)
        line0 = logfile.readline()
        #print line0
        line1 = logfile.readline()
        
        ............
        
#EXTM3U
#EXTINF:-1 tvg-id="BBC One London" tvg-name="UK: BBC ONE HD" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/1/1a/BBC_One_2002.png" group-title="UK: ENTERTAINMENT",UK: BBC ONE HD
http://roq-tv.net:25461/live/XXX/XXXX!/281.ts
#EXTINF:-1 tvg-id="BBC 1 CI" tvg-name="UK: BBC ONE CI (VPN OR UK ONLY)" tvg-logo="http://www.tv-logo.com/pt-data/uploads/images/logo/bbc_one_channel_islands.jpg" group-title="UK: ENTERTAINMENT",UK: BBC ONE CI (VPN OR UK ONLY)
http://roq-tv.net:25461/live/XXX/XXXX!/1457.ts

"""
            
def CATEGORIES():
    ###utils.logdev(module,'CATEGORIES ADDON= ' + ADDONid)
    LOGIN()
    addDir('[COLOR lightgreen]Favorites[/COLOR]','url',17,'','','','All '+ADDONname +' and direct channel favorites, you have selected on this box')
    addDir('[COLOR lightgreen]Search Channels and VOD[/COLOR]','url',2008,'','','','Search all '+ADDONname +' channels, VOD and all channels from extra XMLTV file ')
    addDir('[COLOR lightgreen]Search EPG Programs[/COLOR]','url',2050,'','','','Search all '+ADDONname +' channels EPG')
    if ADDON.getSetting('enable_record')=='true':
        ###addDir('[COLOR lightgreen]Search Channels and VOD[/COLOR]','url',2008,'','','','Search all '+ADDONname +' channels and all channels from extra XMLTV file ')
        addDir('[COLOR lightgreen]Search Recordings[/COLOR]','url',6,'','','','All recorded items in ' + recordPath)
        ###addDir('[COLOR lightgreen]Search Channels and VOD[/COLOR]','url',2008,'','','','Search all '+ADDONname +' channels and all channels from extra XMLTV file ')
        addDir('[COLOR lightgreen]Planned Recordings[/COLOR]','url',3,'','','','Planned recordings, result of recordings and recursive recordings')
    addDir('[COLOR lightgreen]Archive/Catch up[/COLOR]','url',18,'','','','All '+ADDONname +' channels, that have archive/catch up. \n\nGo to TV Guide for the channel to watch or record catch up or comming events')
    xmltvfile = ADDON.getSetting('directchannelsfromextraXMLTVfile').replace('/','/ ').replace('\\','\\ ')
    if xmltvfile != '':
        xmltvfile = '\n\nYour Direct Channels are defined in:\n' + xmltvfile
    addDir('[COLOR lightgreen]Direct Channels[/COLOR]','url',19,'','','','All direct channels from extra XMLTV file. Channels you can watch if you just are in the right country'+xmltvfile)
    addDir('[COLOR lightgreen]New Channels and Vod[/COLOR]','url',21,'','','','Newest '+ADDONname +' channels and vod sorted by creation date. \n\nShowing new channels and vod from the last 2 months')
    try:
        link = definition.getBASEURL() + '/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')
        ###utils.logdev(module,'CATEGORIES 0 link= %r' % link)
        file = urllib2.urlopen(link)
        data = file.read()
        file.close()
        ###utils.logdev(module,'CATEGORIES 1 data= %r' % data)
        for titem in ['title','description']:
            ###utils.logdev('Test Encoding','titem= ' + repr(titem) + ' - data= ' + repr(data))

            data = data.split('<'+titem+'>')
            ###utils.logdev('Test Encoding 1',repr(data))
            i=0
            newdata= ''
            for part in data:
                ###utils.logdev('Test Encoding 2',repr(part))
                if i==0:
                    newdata+=part
                    ###utils.logdev('Test Encoding 3',repr(newdata))
                    i+=1
                else:
                    part=part.split('</'+titem+'>',1)
                    ###utils.logdev('Test Encoding 4',repr(part))
                    ### newdata+='<'+titem+'>' + base64.b64decode(part[0]) +'</'+titem+'>' + part[1]
                    newdata+='<'+titem+'>' + base64.b64decode(part[0], '-_') +'</'+titem+'>' + part[1]
                    ###utils.logdev('Test Encoding 5',repr(newdata))
            ###utils.logdev(module,'CATEGORIES 2 data= %r' % data)
            data = newdata

        data = xmltodict.parse(newdata)
        ###utils.logdev('Test Encoding x',repr(data))
    
        for i, (key, value) in enumerate(data.iteritems()):
            ###utils.logdev('Test Encoding y1','i= %s, key= %s, value= %s' % (repr(i), repr(key),repr(value)))
            for i1, (key1, value1) in enumerate(value.iteritems()):
                if key1 == 'channel':
                    ###utils.logdev('Test Encoding y2','i1= %s, key1= %s, value1= %s' % (repr(i1), repr(key1),repr(value1)))
                    for channelROQ in value1:
                        d=channelROQ
                        ###utils.logdev('Test Encoding y3','i1= %s, key1= %s, channelROQ= %s, url= %s' % (repr(d.items()[0]), repr(d.items()[1]),repr(d.items()[2]),repr(d.items()[3])))
                        ###utils.logdev('Test Encoding y4','\n\ntitle= %s,\n description= %s,\n category_id= %s,\n playlist_url= %s\n' % (repr(d['title']), repr(d['description']),repr(d['category_id']),repr(d['playlist_url'])))
                        addDir(d['title'],d['playlist_url'],22,d['category_id'],'','',ADDONname+' in original sorting and categorizing: \n' + d['description'])
                        ###addDir(d['title'],d['playlist_url'],22,d['category_id'],'','','description default line 366')
    except Exception, e:
        pass
        utils.notification('Error in get Categori from enigma2: ' + repr(e))
        utils.logdev(module,'Error in get Categori from enigma2: ' + repr(e))
    
    """###Try to access catchup START
    ### 738 5.104997131 192.168.20.6    109.236.84.104  HTTP    234 GET /panel_api.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass') HTTP/1.1 
    link = 'http://roq-tv.net:25461/streaming/timeshift.php?username=XXX&password=XXXX&stream=276&duration=120&start=2017-05-21:16-00'
    ###http://roq-tv.net:25461/streaming/timeshift.php?username=XXX&password=XXXX'
    file = urllib2.urlopen(link)
    data = file.read()
    file.close()
    for titem in ['title','description']:
        ###utils.logdev('Test Encoding','titem= ' + repr(titem) + ' - data= ' + repr(data))

        data = data.split('<'+titem+'>')
        ###utils.logdev('Test Encoding 1',repr(data))
        i=0
        newdata= ''
        for part in data:
            ###utils.logdev('Test Encoding 2',repr(part))
            if i==0:
                newdata+=part
                ###utils.logdev('Test Encoding 3',repr(newdata))
                i+=1
            else:
                part=part.split('</'+titem+'>',1)
                ###utils.logdev('Test Encoding 4',repr(part))
                ### newdata+='<'+titem+'>' + base64.b64decode(part[0]) +'</'+titem+'>' + part[1]
                newdata+='<'+titem+'>' + base64.b64decode(part[0], '-_') +'</'+titem+'>' + part[1]
                ###utils.logdev('Test Encoding 5',repr(newdata))
        ###utils.logdev('Test Encoding 6',repr(newdata))
        data = newdata
    data = xmltodict.parse(newdata)
    ###utils.logdev('Test Encoding x',repr(data))
    
    for i, (key, value) in enumerate(data.iteritems()):
        ###utils.logdev('Test Encoding y1','i= %s, key= %s, value= %s' % (repr(i), repr(key),repr(value)))
        for i1, (key1, value1) in enumerate(value.iteritems()):
            if key1 == 'channel':
                ###utils.logdev('Test Encoding y2','i1= %s, key1= %s, value1= %s' % (repr(i1), repr(key1),repr(value1)))
                for channelROQ in value1:
                    d=channelROQ

                    ###utils.logdev('Test Encoding y3','i1= %s, key1= %s, channelROQ= %s, url= %s' % (repr(d.items()[0]), repr(d.items()[1]),repr(d.items()[2]),repr(d.items()[3])))
                    ###utils.logdev('Test Encoding y4','\n\ntitle= %s,\n description= %s,\n category_id= %s,\n playlist_url= %s\n' % (repr(d['title']), repr(d['description']),repr(d['category_id']),repr(d['playlist_url'])))
                    addDir(d['title'],d['playlist_url'],22,d['category_id'],'','',d['description'])
    ###Try to access catchup END
    """
    addDir('Categories','url',2,'','','','All '+ADDONname +' categories based on information in channel list and all channels from extra XMLTV file. \n\nA channel may be member of several categoties. \n\nCategories are sorted alphabetically')
    addDir('Channels','url',23,'','','','All '+ADDONname +' channels and all channels from extra XMLTV file shown without categories. \n\nUse search to find your channel or vod. \n\nChannels and Video on Demand are sorted alphabetically')
    ###addDir('Search Channels and VOD','url',2008,'','','','Search all '+ADDONname +' channels and all channels from extra XMLTV file ')
    ###if ADDON.getSetting('enable_record')=='true':
        ###addDir('Recordings','url',6,'','','','All recorded items in ' + recordPath)
        ###addDir('[COLOR lightgreen]Planned Recordings[/COLOR]','url',3,'','','','Planned recordings, result of recordings and recursive recordings')
        ###addDir('Recursive Search Channels','url',26,'','','','All channels used for recursive search')
        ###addDir('Restore Planned Recordings','url',104,'','','','Restore planned recordings or just recursive recordings')
        ###addDir('Delete New EPG programs','url',110,'','','','delNewEPGPrograms():   ### If to many programs have changed - update full afterwards')
        ###addDir('Delete All Channels','url',108,'','','','delAllChannels():   ### If user have changed - update full afterwards')
        ###addDir('Delete All Planned Recordings','url',109,'','','','delAllPlannedPrograms():   ### If recursive have made too many recordings - Stop all recordings and clear parts of database')
    addDir('Maintenance','url',49,'','','','Database Maintenance')
    ###addDir('My Account','url',8,'','','','Change your user name/email address and password or restore previous configurations. \n\nWatch your basic account information')
    ###addDir('Hidden Channels','url',20,'','','','All channels you have hidden from the other views')
    addDir('[COLOR red]Back to Kodi[/COLOR]','url',29,'','','','Back to Kodi from the %s addon' % ADDONname)
    
    try:
        ### httplink = 'http://roq-tv.net:25461/get.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')+ '&type=m3u_plus&output='+streamtype
        httplink = definition.getBASEURL() + '/get.php?username='+ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')+ '&type=m3u_plus&output='+streamtype
        """
        httplinkEPG = definition.getBASEURL() +'/xmltv.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')
        ###utils.logdev(module,'roq-tv EPG link: ' + repr(httplinkEPG))
        m3ufile = urllib2.urlopen(httplinkEPG)
        ChannelFile = os.path.join(datapath,ADDONid) + 'EPG.xml'
        with open(ChannelFile,'wb') as output:
            output.write(m3ufile.read())
        ######utils.logdev(module,'roq-tv EPG file downloaded: ' + repr(ChannelFile))
        #########utils.logdev('Decoded XML file',repr(newdata))
        ###########2017-06-14
        epgfile = open(ChannelFile, 'r')
        dataepg = epgfile.read()
        epgfile.close() 
        dataepg = xmltodict.parse(dataepg)
        #########utils.logdev('Decoded Dict',repr(data))
        channelsxml = os.path.join(datapath, 'channelsdictEPG')  + '.dict'
        LF = open(channelsxml, 'w')
        LF.write(repr(dataepg))
        LF.close()
        
        """
        ### Save .m3u file with all channels!
        utils.logdev(module,'roq-tv categories link: ' + repr(httplink))
        m3ufile = urllib2.urlopen(httplink)
        ChannelFile = os.path.join(datapath,ADDONid) + '.m3u'
        with open(ChannelFile,'wb') as output:
            output.write(m3ufile.read())
        utils.logdev(module,'roq-tv m3u file downloaded: ' + repr(ChannelFile))
        
    except Exception, e:
        pass
        utils.logdev(module,'Error in get Categori: ' + repr(e))
    
    setView('movies', 'main-view')         

def CHANNELSROQOLD(cname,cat,link,description):
    """ Stream
    OrderedDict([
     (u'title', u'UK: SKY SPORTS ACTIVE 5'), 
     (u'description', None), 
     (u'desc_image', u'http://www.tv-logo.com/pt-data/uploads/images/logo/sky_uk_sports_active_hi_01.jpg'), 
     (u'category_id', u'38'), 
     (u'stream_url', u'http://roq-tv.net:25461/live/XXX/XXXX/2782.ts')]), 
     
     Category
     <channel>
     <title>All</title>
     <description>Live Streams Category [ ALL ]</description>
     <category_id>0</category_id>
     <playlist_url><![CDATA[http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass') + '&cat_id=0]]></playlist_url>
     </channel>
    """
    GoHome('Live Streams or Vod')
    ###link = 'http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')
    file = urllib2.urlopen(link)
    data = file.read()
    file.close()
    data = data.replace('\n','').replace('<description/>','<description></description>')
    for titem in ['title','description']:
        #########utils.logdev('Test Encoding','titem= ' + repr(titem) + ' - data= ' + repr(data))
        data = data.split('<'+titem+'>')
        #########utils.logdev('Test Encoding 1',repr(data))
        #########utils.logdev(module,'Test Encoding 1')
        i=0
        newdata= ''
        for part in data:
            #########utils.logdev('Test Encoding 2',repr(part))
            #########utils.logdev(module,'Test Encoding 2')
            if i==0:
                newdata+=part
                #########utils.logdev('Test Encoding 3',repr(newdata))
                i+=1
                #########utils.logdev(module,'Test Encoding 3')
            else:
                part=part.split('</'+titem+'>',1)
                #########utils.logdev(module,'Test Encoding 4')
                #########utils.logdev('Test Encoding 4',repr(part))
                ### newdata+='<'+titem+'>' + base64.b64decode(part[0]) +'</'+titem+'>' + part[1]
                if not part[0] == None:
                    #########utils.logdev(module,'Test Encoding 5')
                    #########utils.logdev('Test Encoding 4a',repr(part))
                    if titem == 'title':
                        decodedtext = recordings.latin1_to_ascii_force(base64.b64decode(part[0], '-_').replace('&','&amp;').split('[',1)[0]).replace('<<','XX')
                        #########utils.logdev(module,'Test Encoding 6')
                    else:
                        decodedtext = recordings.latin1_to_ascii_force(base64.b64decode(part[0], '-_').replace('&','&amp;')).replace('<<','XX')
                        #########utils.logdev(module,'Test Encoding 7')
                else:
                    utils.notification('Missing channel: ' + repr(part))
                    decodedtext=''
                    #########utils.logdev(module,'Test Encoding 8')
                newdata+='<'+titem+'>' + decodedtext +'</'+titem+'>' + part[1]
                #########utils.logdev(module,'Test Encoding 9')
                #########utils.logdev('Test Encoding 5',repr(newdata))
        #########utils.logdev('Test Encoding 6',repr(newdata))
        #########utils.logdev(module,'Test Encoding 10')
        data = newdata
    #########utils.logdev(module,'Test Encoding 11')
    channelsxml = os.path.join(datapath, 'channelsxml')  + '.xml'
    LF = open(channelsxml, 'w')
    LF.write(newdata)
    LF.close()
    #########utils.logdev('Decoded XML file',repr(newdata))
    try:
        data = xmltodict.parse(newdata)
    except Exception, e:
        pass
        utils.logdev(module,'Error in xmltodict.parse(newdata): ' + repr(e))
        data = ''
    #########utils.logdev('Decoded Dict',repr(data))
    channelsxml = os.path.join(datapath, 'channelsdict')  + '.dict'
    LF = open(channelsxml, 'w')
    LF.write(repr(data))
    LF.close()
    ###addDir('Favorites','url',17,'','','','All '+ADDONname +' favorites, you have selected on this box')
    try:
        #########utils.logdev(module,'Test Encoding 12')
        for i, (key, value) in enumerate(data.iteritems()):
            #########utils.logdev('Test Encoding y1','i= %s, key= %s, value= %s' % (repr(i), repr(key),repr(value)))
            #########utils.logdev(module,'Test Encoding 13')
            for i1, (key1, value1) in enumerate(value.iteritems()):
                ######utils.logdev(module,'Test Encoding 14')
                if key1 == 'channel':
                    ######utils.logdev(module,'Test Encoding 15')
                    ######utils.logdev('Test Encoding y2','i1= %s, key1= %s, value1= %s' % (repr(i1), repr(key1),repr(value1)))
                    for channelROQ in value1:
                        utils.logdev(module,'channelROQ= %r' % channelROQ)  ### 2017-12-29
                        d=channelROQ
                        
                        if 'stream_url' in d and not d['stream_url'] == None:
                            ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
                            utils.logdev(module,'stream_url in channelROQ')
                            StreamURL=d['stream_url'].replace('![CDATA[','',1).replace(']]','',1)
                        
                            if not d['desc_image'] == None:
                                DescURL=d['desc_image'].replace('![CDATA[','',1).replace(']]','',1)
                            else:
                                DescURL = ''
                            try:
                                Description=d['description']
                                utils.logdev(module,'Description= %r, type= %r' %(Description,type(Description)))
                                if isinstance(Description, dict):
                                    Description = Description['em']+'\n'+Description['#text']
                                elif not isinstance(Description, unicode):
                                    if not (Description == None or Description == ''):
                                        Description='Unknown description type: ' + repr(type(Description))
                                    else: 
                                        ######utils.logdev(module,'Description= %s, type= %s' %( repr(Description),repr(type(Description))))
                                        Description = ''
                            except Exception, e:
                                pass
                                utils.logdev(module,'Error in get Description: ' + repr(e))
                                Description=''
                            ######utils.logdev(module,'Test Encoding 18')
                            ###utils.logdev(module,'Test Encoding 18 Title= %s, Stream= %s, DescURL= %s, Category_ID= %s, Description= %s' % (d['title'],StreamURL,DescURL,d['category_id'],Description))
                            catThis = recordings.catFromUrl(StreamURL)
                            utils.logdev(module,'catThis= %r' % catThis)
                            if recordings.isChannelVisible(catThis):
                                utils.logdev(module,'Visible catThis= %r' % catThis)
                                ###utils.logdev(module,'catThis = recordings.catFromUrl(StreamURL)= %r ' % catThis)
                                ##recordings.addChannel(d['title'].strip(),StreamURL,DescURL,catThis, ADDONid,description=Description)
                                ###def addDir(name,url,mode,iconimage='',cat='',date='',description='',startDate='',endDate='',recordname='',whatsup=''):
                                try:
                                    olddescription = recordings.getChannelDescription(catThis)
                                    ###utils.logdev(module,'get olddescription: ' + repr(olddescription))
                                    if olddescription != '':
                                        Description = olddescription
                                    else:
                                        recordings.setChannelDescription(catThis,Description)
                                except Exception, e:
                                    pass
                                    utils.logdev(module,'Error in get olddescription: ' + repr(e))
                                ###utils.logdev(module,'cat= <%r>1 \nurl= %r' % (catThis,StreamURL))
                                if 'movie' in StreamURL:
                                    chx = Description  ### Description of Movies
                                    ###utils.logdev(module,'MOVIE cat= <%r>1 \nurl= %r' % (catThis,StreamURL))
                                else:
                                    EPGx = updateepg.getEPGnow(catThis)  ### Live EPG on channels
                                    EPG  = EPGx[0]
                                    ###utils.logdev(module,'LIVE cat= <%r>1 \nurl= %r' % (catThis,StreamURL))
                                    ###utils.logdev(module,'EPGx[4]= <%r> \nEPGx[0]= %r' % (EPGx[4],EPGx[0]))
                                    if EPGx[4] != '':
                                        ###utils.logdev(module,'LIVE EPG cat= <%r>1 \nurl= %r \nlen(EPG)= %r' % (catThis,StreamURL,len(EPG)))
                                        chx = EPGx[4] + ' \n'
                                        for indexX in range(0, len(EPG)):
                                            title = str(EPG[indexX][0])
                                            description = str(EPG[indexX][1])
                                            ###starttime = str(EPG[indexX][3].strftime('%H:%M'))
                                            ###endtime = str(EPG[indexX][4].strftime('%H:%M'))
                                            starttime = str(datetime.fromtimestamp(EPG[indexX][3]).strftime('%H:%M'))
                                            endtime = str(datetime.fromtimestamp(EPG[indexX][4]).strftime('%H:%M'))
                                            chx += ' \n[COLOR lightgreen]'+starttime + ' - ' + endtime + '[/COLOR] \n[COLOR blue]'+ title+ '[/COLOR] \n'+ description +' \n'
                                    else:
                                        chx = Description
                                addDir(d['title'].strip(),StreamURL,200,DescURL,catThis,'',chx)
                                ######utils.logdev('Test Encoding stream','\n\ntitle= %s,\n description= %s,\n category_id= %s,\n stream_url= %s\n' % (repr(d['title']), repr(d['description']),repr(d['category_id']),repr(d['stream_url'])))
                        elif 'playlist_url' in d and not d['playlist_url'] == None:
                            ######utils.logdev(module,'Test Encoding 19')
                            PlaylistURL=d['playlist_url'].replace('![CDATA[','',1).replace(']]','',1)
                            try:
                                Description=d['description']
                                ######utils.logdev(module,'Description= %s, type= %s' %( repr(Description),repr(type(Description))))
                                if isinstance(Description, dict):
                                    Description = Description['em']+'\n'+Description['#text']
                                elif not isinstance(Description, unicode):
                                    if not (Description == None or Description == ''):
                                        Description='Unknown description type: ' + repr(type(Description))
                                    else: 
                                        ######utils.logdev(module,'Description= %s, type= %s' %( repr(Description),repr(type(Description))))
                                        Description = ''
                            except Exception, e:
                                pass
                                utils.logdev(module,'Error in get Description: ' + repr(e))
                                Description=''
                            ######utils.logdev('Test Encoding playlist','\n\ntitle= %s,\n description= %s,\n category_id= %s,\n playlist_url= %s\n' % (repr(d['title']), repr(d['description']),repr(d['category_id']),repr(d['playlist_url'])))
                            ######utils.logdev(module,'Test Encoding 20')
                            ###def addChannel(name,url,iconimage,cat,origin,visible=True,weight=0,description='')
                            ##recordings.addChannel(d['title'].strip(),PlaylistURL,'','', ADDONid,description=Description)
                            
                            addDir(d['title'].strip(),PlaylistURL,22,'','','',Description)
                        else:
                            ######utils.logdev(module,'Test Encoding 21')
                            utils.notification('No stream or playlist: ' + repr(d))
    except Exception, e:
        pass
        utils.logdev(module,'Error in showing Channels: ' + repr(e))
    ######utils.logdev(module,'Test Encoding 22')
    setView('movies', 'main-view')
    
def dictepgdata(date):
    try:
        ###utils.logdev(module,'dictepgdata(date)')
        for i, (key, value) in enumerate(data.iteritems()):
            #########utils.logdev('Test Encoding y1','i= %s, key= %s, value= %s' % (repr(i), repr(key),repr(value)))
            #########utils.logdev(module,'Test Encoding 13')
            for i1, (key1, value1) in enumerate(value.iteritems()):
                ######utils.logdev(module,'Test Encoding 14')
                if key1 == 'channel':
                    ######utils.logdev(module,'Test Encoding 15')
                    ######utils.logdev('Test Encoding y2','i1= %s, key1= %s, value1= %s' % (repr(i1), repr(key1),repr(value1)))
                    for channelROQ in value1:
                        ######utils.logdev(module,'Test Encoding 16')
                        d=channelROQ
                        
                        if 'stream_url' in d and not d['stream_url'] == None:
                            ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
                            ######utils.logdev(module,'Test Encoding 17')
                            StreamURL=d['stream_url'].replace('![CDATA[','',1).replace(']]','',1)
                        
                            if not d['desc_image'] == None:
                                DescURL=d['desc_image'].replace('![CDATA[','',1).replace(']]','',1)
                            else:
                                DescURL = ''
                            try:
                                Description=d['description']
                                ######utils.logdev(module,'Description= %s, type= %s' %( repr(Description),repr(type(Description))))
                                if isinstance(Description, dict):
                                    Description = Description['em']+'\n'+Description['#text']
                                elif not isinstance(Description, unicode):
                                    if not (Description == None or Description == ''):
                                        Description='Unknown description type: ' + repr(type(Description))
                                    else: 
                                        ######utils.logdev(module,'Description= %s, type= %s' %( repr(Description),repr(type(Description))))
                                        Description = ''
                            except Exception, e:
                                pass
                                ###utils.logdev(module,'Error in get Description: ' + repr(e))
                                Description=''
                            ######utils.logdev(module,'Test Encoding 18')
                            utils.logdev(module,'Test Encoding 18 Title= %s, Stream= %s, DescURL= %s, Category_ID= %s, Description= %s' % (d['title'],StreamURL,DescURL,d['category_id'],Description))
                            catThis = recordings.catFromUrl(StreamURL)
                            ###utils.logdev(module,'catThis = recordings.catFromUrl(StreamURL)= %r ' % catThis)
                            ##recordings.addChannel(d['title'].strip(),StreamURL,DescURL,catThis, ADDONid,description=Description)
                            addDir(d['title'].strip(),StreamURL,200,DescURL,'','',Description)
                            ######utils.logdev('Test Encoding stream','\n\ntitle= %s,\n description= %s,\n category_id= %s,\n stream_url= %s\n' % (repr(d['title']), repr(d['description']),repr(d['category_id']),repr(d['stream_url'])))
                        elif 'playlist_url' in d and not d['playlist_url'] == None:
                            ######utils.logdev(module,'Test Encoding 19')
                            PlaylistURL=d['playlist_url'].replace('![CDATA[','',1).replace(']]','',1)
                            try:
                                Description=d['description']
                                ######utils.logdev(module,'Description= %s, type= %s' %( repr(Description),repr(type(Description))))
                                if isinstance(Description, dict):
                                    Description = Description['em']+'\n'+Description['#text']
                                elif not isinstance(Description, unicode):
                                    if not (Description == None or Description == ''):
                                        Description='Unknown description type: ' + repr(type(Description))
                                    else: 
                                        ######utils.logdev(module,'Description= %s, type= %s' %( repr(Description),repr(type(Description))))
                                        Description = ''
                            except Exception, e:
                                pass
                                utils.logdev(module,'Error in get Description: ' + repr(e))
                                Description=''
                            ######utils.logdev('Test Encoding playlist','\n\ntitle= %s,\n description= %s,\n category_id= %s,\n playlist_url= %s\n' % (repr(d['title']), repr(d['description']),repr(d['category_id']),repr(d['playlist_url'])))
                            ######utils.logdev(module,'Test Encoding 20')
                            ###def addChannel(name,url,iconimage,cat,origin,visible=True,weight=0,description='')
                            ##recordings.addChannel(d['title'].strip(),PlaylistURL,'','', ADDONid,description=Description)
                            addDir(d['title'].strip(),PlaylistURL,22,'','','',Description)
                        else:
                            ######utils.logdev(module,'Test Encoding 21')
                            utils.notification('No stream or playlist: ' + repr(d))
    except Exception, e:
        pass
        utils.logdev(module,'Error in showing Channels: ' + repr(e))
 
def CHANNELS(cname,cat):
    ###utils.logdev(module,'roq-tv CHANNELS(cname= %s, cat= %s)' % (repr(cname),repr(cat)))
    ###addDir('Favorites','url',17,'','','','All '+ADDONname +' favorites, you have selected on this box')
    #net.set_cookies(cookie_jar)
    #imageUrl=definition.getBASEURL() +'/res/content/tv/'
    #now= datetime.today().strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20')
        ## 3.4.6 now= datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20')
        #url='&mwAction=category&xbmc=1&mwData={"id":"%s","time":"%s","type":"tv"}'%(cat,now)
    #print 'default.py YYYY site+url= %s%s'  % (site,url)
    #link = net.http_GET(site+url, headers={'User-Agent' : UA}).content
    #print 'default.py YYYY Channels link= %s' % str(repr(link))
    #data = json.loads(link)
    GoHome('Categories')
    channeldescription = 'All '+ADDONname +' categories based on information in channel list. A channel may be member of several categoties.'
    i = 0
    categories= []
    channels= []
    utils.logdev(module,'CHANNELS(cname= %r, cat= %r) ' %(cname,cat))
    ###ChannelFile = os.path.join(datapath,ADDONid) + '.m3u.txt'
    ChannelFile = os.path.join(datapath,'directchannels') + '.m3u.txt'
    utils.logdev(module,'Use extra ChannelFile in data?: ' + repr(ChannelFile))
    if not os.path.isfile(ChannelFile):    ### If ChannelFile exist in Data directory use it
        ###ChannelFile = os.path.join(progpath,ADDONid) + '.m3u.txt'  ### Otherwise try program directory
        ChannelFile = os.path.join(progpath,'directchannels') + '.m3u.txt'  ### Otherwise try program directory
        utils.logdev(module,'Use extra ChannelFile in prog?: ' + repr(ChannelFile))
    utils.logdev(module,'Use extra ChannelFile in: ' + repr(ChannelFile))
    if not os.path.isfile(ChannelFile): 
        utils.logdev(module,'NOT found xtra ChannelFile in: ' + repr(ChannelFile))
    else:
        utils.logdev(module,'Use extra ChannelFile in: ' + repr(ChannelFile))
        for line in open(ChannelFile):  # opened in text-mode; all EOLs are converted to '\n'
            ######utils.logdev(module,'Line: ' + repr(i) + ' - ' + line)
            line = line.rstrip('\n').rstrip('\r').strip()
            if not line == '' and not line[:2] == '# ' :   # Ignore empty lines and comment lines
                if '#EXTM3U' in line :
                    i += 1
                    ######utils.logdev(module,'Skip EXTM3U in line: ' + repr(i))
                elif '#EXTINF' in line :
                    i += 1
                    ######utils.logdev(module,'Use EXTINF in line: ' + repr(i) + ' - ' + line)
                    ###if ',' in line:
                    ### utils.logdev(module,'Comma(,) in line: ' + repr(i) + ' - ' + line)
                    tvgid=''
                    tvgname=''
                    tvgnamecat = ''
                    tvglogo=''
                    grouptitl=''
                    name=''
                    try:
                        tvgid=line.split('tvg-id="',1)[1].split('"',1)[0]
                        ######utils.logdev(module,'Use tvg-id in line: ' + repr(tvgid) + ' - ' + line)
                    except:
                        pass
                    try:
                        tvgname=line.split('tvg-name="',1)[1].split('"',1)[0]
                        ######utils.logdev(module,'Use tvg-name in line: ' + repr(tvgname) + ' - ' + line)
                    except:
                        pass
                    try:
                        tvglogo=line.split('tvg-logo="',1)[1].split('"',1)[0]
                        ######utils.logdev(module,'Use tvg-logo in line: ' + repr(tvglogo) + ' - ' + line)
                    except:
                        pass
                    try:
                        grouptitle=line.split('group-title="',1)[1].split('"',1)[0]
                        ######utils.logdev(module,'Use group-title in line: ' + repr(grouptitle) + ' - ' + line)
                    except:
                        pass
                    try:
                        name=line.split(',')[-1]
                        ######utils.logdev(module,'Use name in line: ' + repr(name) + ' - ' + line)
                        grouptitle=grouptitle.split('SEASON')[0].strip()
                    except:
                        pass
                    try:
                        if ':' in tvgname:
                            tvgnamecat=tvgname.split(':')[0].strip()
                    except:
                        pass
                else:
                    i += 1
                    try:
                        cats=line.split('live/')[1].split('/')[0]
                    except:
                        pass
                        try:
                            cats=line.split('tv2danmark/')[1].split('/')[0]
                        except:
                            pass
                            try:
                                cats=line.split('i/')[1].split('/')[0]
                            except:
                                pass
                                cats=line.split('.')[-2].split('/')[-1]
                    if 'live' in line:
                        catsinlink='! live'
                    else:
                        catsinlink=''
                    
                    if '_' in cats:
                        if not 'bbc_' in cats:   ### 2017-08-28
                            if not 'cbeebies_' in cats:
                                utils.logdev(module,'cats no_= %r' % cats)
                                cats = cats.split('_')[0]
                                utils.logdev(module,'cats no_= %r' % cats)
                    
                    ######utils.logdev(module,'Use cname= ' + repr(cname) + ' - grouptitle= ' + repr(grouptitle))
                    if cname == grouptitle or cname == tvgnamecat or cname == catsinlink or cname == 'Channels':
                        channels.append([name.strip()+' (D)',line,grouptitle,tvglogo,tvgname,tvgid,cats,catsinlink])
                    elif  cname == 'Categories':
                        if not grouptitle in categories and grouptitle != None :
                            categories.append(grouptitle)
                        if not tvgnamecat == '' and not tvgnamecat in categories and tvgnamecat != None:
                            categories.append(tvgnamecat)
                        if not catsinlink == '' and not catsinlink in categories and catsinlink != None :
                            categories.append(catsinlink)
                    ######utils.logdev(module,'Use URL in line: ' + repr(repr(i)) + ' - ' + line)
                    ###addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
                    ###addDir(name,line,200,tvglogo,cat,'','cat= ' + cat + '\n\rtvg-id= ' + tvgid + '\n\rtvg-name= '+tvgname + '\n\rgroup-title= ' + grouptitle,'','',tvgname)
    ChannelFile = os.path.join(datapath,ADDONid) + '.m3u'
    utils.logdev(module,'Use ChannelFile ?: ' + repr(ChannelFile))
    if os.path.isfile(ChannelFile):
        utils.logdev(module,'Use ChannelFile: ' + repr(ChannelFile))
        for line in open(ChannelFile):  # opened in text-mode; all EOLs are converted to '\n'
            ####utils.logdev(module,'Line: ' + repr(i) + ' - ' + line)
            line = line.rstrip('\n').rstrip('\r')
            if not line == '' and not line[:2] == '# ' :   # Ignore empty lines and comment lines
                if '#EXTM3U' in line :
                    i += 1
                    ####utils.logdev(module,'Skip EXTM3U in line: ' + repr(i))
                elif '#EXTINF' in line :
                    i += 1
                    ###if ',' in line:
                    ### utils.logdev(module,'Comma(,) in line: ' + repr(i) + ' - ' + line)
                    tvgid=''
                    tvgname=''
                    tvgnamecat = ''
                    tvglogo=''
                    grouptitl=''
                    name=''
                    ####utils.logdev(module,'Use EXTINF in line: ' + repr(i) + ' - ' + line)
                    tvgid=line.split('tvg-id="',1)[1].split('"',1)[0]
                    ####utils.logdev(module,'Use tvg-id in line: ' + repr(tvgid) + ' - ' + line)
                    tvgname=line.split('tvg-name="',1)[1].split('"',1)[0]
                    ####utils.logdev(module,'Use tvg-name in line: ' + repr(tvgname) + ' - ' + line)
                    tvglogo=line.split('tvg-logo="',1)[1].split('"',1)[0]
                    ####utils.logdev(module,'Use tvg-logo in line: ' + repr(tvglogo) + ' - ' + line)
                    grouptitle=line.split('group-title="',1)[1].split('"',1)[0]
                    ####utils.logdev(module,'Use group-title in line: ' + repr(grouptitle) + ' - ' + line)
                    name=line.split(',')[-1]
                    ####utils.logdev(module,'Use name in line: ' + repr(name) + ' - ' + line)
                    grouptitle=grouptitle.split('SEASON')[0].strip()
                    tvgnamecat = ''
                    if ':' in tvgname:
                        tvgnamecat=tvgname.split(':')[0].strip()
                else:
                    i += 1
                    cats=line.split('.')[-2].split('/')[-1]
                    catsinlink='! ' + line.split('/')[3]
                    if  catsinlink == '! rt':
                        catsinlink = ''
                    ######utils.logdev(module,'Use cname= ' + repr(cname) + ' - grouptitle= ' + repr(grouptitle))
                    if cname == grouptitle or cname == tvgnamecat or cname == catsinlink or cname == 'Channels':
                        channels.append([name.strip(),line,grouptitle,tvglogo,tvgname,tvgid,cats,catsinlink])
                    elif  cname == 'Categories':
                        if not grouptitle in categories:
                            categories.append(grouptitle)
                        if not tvgnamecat == '' and not tvgnamecat in categories:
                            categories.append(tvgnamecat)
                        if not catsinlink == '' and not catsinlink in categories:
                            categories.append(catsinlink)
                    ######utils.logdev(module,'Use URL in line: ' + repr(repr(i)) + ' - ' + line)
                    ###addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
                    ###addDir(name,line,200,tvglogo,cat,'','cat= ' + cat + '\n\rtvg-id= ' + tvgid + '\n\rtvg-name= '+tvgname + '\n\rgroup-title= ' + grouptitle,'','',tvgname)
    channels = sorted(channels)
    ######utils.logdev(module,'Use channels: ' + repr(channels))
    categories = sorted(categories)
    ######utils.logdev(module,'Use categories: ' + repr(categories))
    for cat in categories:
        ######utils.logdev(module,'Use categories: ' + repr(cat))
        if cat != '':
            addDir(cat,'url',2,'','','',channeldescription)
    ###cEPG = recordings.getConnection()
    ###recordings.createEPGchannelsTable(cEPG)
    ###c = cEPG.cursor()
    for cat in channels:
        ######utils.logdev(module,'Use channels: ' + repr(cat))
        if cat[0] != '':
            ###if RecordActive :  ###
            ### addChannel(name,url,iconimage,cat,source)
            ###recordings.addChannel(cat[0],cat[1],cat[3],cat[6], ADDONid)
            description = ''
            if cat[6] != '':
                description += ' \n\rcat= ' + cat[6]
            if cat[5] != '':
                description += ' \n\rtvg-id= ' + cat[5]
            if cat[4] != '':
                description += ' \n\rtvg-name= '+cat[4]
            if cat[2] != '':
                description += ' \n\rgroup-title= ' + cat[2]
            if cat[7] != '':
                description += ' \n\rcatsinlink= '+cat[7]
            if cat[1] != '' and ADDON.getSetting('ShowLink') == 'true':
                description += ' \n\rlink= '+cat[1].replace('/','/ ').replace('\\','\\ ')
            ## 2017-07-12 recordings.addChannel(cat[0],cat[1],cat[3],cat[6], ADDONid+ ' available_channels',description=description)   ### Add channel during build of menus --> move to updateepg.py ###
            olddescription = recordings.getChannelDescription(cat[6])
            if olddescription != '':
                description = olddescription
            ##else:
            ##  recordings.setChannelDescription(cat[6],description)
            ### Add Live EPG
            ###utils.logdev(module,'cat= <%r>2 \nurl= %r' % (cat[6],cat[1]))
            if 'movie' in cat[1]:  ### URL
                chx = description  ### Description of Movies
                ###utils.logdev(module,'MOVIE cat= <%r>3 \nurl= %r' % (cat[6],cat[1]))
            else:
                ###utils.logdev(module,'LIVE cat= <%r>4 \nurl= %r' % (cat[6],cat[1]))
                try:
                    EPGx = updateepg.getEPGnow(cat[6])  ### Live EPG on channels
                    EPG  = EPGx[0]
                    ###utils.logdev(module,'EPGx[0]= %r, EPGx[4]= %r' % (EPGx[0],EPGx[4]))
                    if EPGx[4] == '':
                        chx = description
                        ###utils.logdev(module,'LIVE no EPG cat= <%r>4 \nurl= %r' % (cat[6],cat[1]))
                    else:
                        chx = EPGx[4] + ' \n'
                        for indexX in range(0, len(EPG)):
                            title = str(EPG[indexX][0])
                            description = str(EPG[indexX][1])
                            ###starttime = str(EPG[indexX][3].strftime('%H:%M'))
                            ###endtime = str(EPG[indexX][4].strftime('%H:%M'))
                            starttime = str(datetime.fromtimestamp(EPG[indexX][3]).strftime('%H:%M'))
                            endtime = str(datetime.fromtimestamp(EPG[indexX][4]).strftime('%H:%M'))
                            chx += ' \n[COLOR lightgreen]'+starttime + ' - ' + endtime + '[/COLOR] \n[COLOR blue]'+ title+ '[/COLOR] \n'+ description +' \n'
                except Exception, e:
                    pass
                    utils.logdev(module,'Error in getting EPG \n' + repr(e))
                    chx = 'No EPG!'
            ###addDir(cat[0],cat[1],200,cat[3],cat[6],'',chx,'','',cat[4])
            addDir(cat[0],cat[1],200,cat[3],cat[6],'',chx)
            
            ###ChannelFav = recordings.getChannelFav(c,cat[0])
            ###recordings.addEPGChannel(c,cat[0],name,url,stream_icon,epg_channel_id,EPGgenerator)
            ###recordings.setChannelCatchup(c,cat[0],'False')
            ###recordings.setChannelFav(c,cat[0],ChannelFav)
            
            ###addDir(cat[0],cat[1],200,cat[3],cat[6],'','cat= ' + cat[6] + '\n\rtvg-id= ' + cat[5] + '\n\rtvg-name= '+cat[4] + '\n\rgroup-title= ' + cat[2] + ' \n\rcatsinlink= '+cat[7]+ ' \n\rlink= '+cat[1].replace('/','/ '),'','',cat[4])
            ###addDir(cat[0]+'*',cat[1].replace('.ts','.txt').replace('.mp4','.txt'),200,cat[3],cat[6],'',cat[1].replace('.ts','.txt').replace('.mp4','.txt'),'','',cat[4])
    ###link = 'http://roq-tv.net:25461/enigma2.php?username=XXX&password=XXXX&type=get_vod_categories'
    """
    2017-05-17 18:49:21 Test Encoding z: 
    OrderedDict(
    [(u'items', OrderedDict([(u'playlist_name', u'Example'), 
    (u'category', OrderedDict([(u'category_id', u'1'), (u'category_title', u'Example')])), 
    (u'channel', 
    [OrderedDict([(u'title', u'Live Streams'), (u'description', u'Live Streams Category'), (u'category_id', u'0'), (u'playlist_url', u'http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass') + '&type=get_live_categories')]), 
    OrderedDict([(u'title', u'Vod'), (u'description', u'Video On Demand Category'), (u'category_id', u'1'), (u'playlist_url', u'http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass') + '&type=get_vod_categories')])])]))])
    
How to iterate from end to beginning over an OrderedDict ?
Either:

z = OrderedDict( ... )
for item in z.items()[::-1]:
   # operate on item
Or:

z = OrderedDict( ... )
for item in reversed(z.items()):
   # operate on item

dict = OrderedDict()
# ...

for i, (key, value) in enumerate(dict.iteritems()):
    # Do what you want here

    
    """
    ###link = definition.getBASEURL() + '/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')
    link = definition.getBASEURL() + '/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')
    file = urllib2.urlopen(link)
    data = file.read()
    file.close()
    for titem in ['title','description']:
        ###utils.logdev('Test Encoding','titem= ' + repr(titem) + ' - data= ' + repr(data))
        data = data.split('<'+titem+'>')
        ###utils.logdev('Test Encoding 1',repr(data))
        i=0
        newdata= ''
        for part in data:
            ###utils.logdev('Test Encoding 2',repr(part))
            if i==0:
                newdata+=part
                ###utils.logdev('Test Encoding 3',repr(newdata))
                i+=1
            else:
                part=part.split('</'+titem+'>',1)
                ###utils.logdev('Test Encoding 4',repr(part))
                ### newdata+='<'+titem+'>' + base64.b64decode(part[0]) +'</'+titem+'>' + part[1]
                newdata+='<'+titem+'>' + base64.b64decode(part[0], '-_') +'</'+titem+'>' + part[1]
                ###utils.logdev('Test Encoding 5',repr(newdata))
        ###utils.logdev('Test Encoding 6',repr(newdata))
        data = newdata
    
    ### Save file with all newdata!
    ChannelFile = os.path.join(datapath,ADDONid) + '.newdata'
    with open(ChannelFile,'wb') as output:
        output.write(newdata)
        
    utils.logdev(module,'roq-tv m3u file downloaded: ' + repr(ChannelFile))
    data = xmltodict.parse(newdata)
    ###utils.logdev('Test Encoding x',repr(data))
    
    ChannelFile = os.path.join(datapath,ADDONid) + '.data'
    with open(ChannelFile,'wb') as output:
        output.write('Data= %r' % data)
        
    for i, (key, value) in enumerate(data.iteritems()):
        ###utils.logdev('Test Encoding y1','i= %s, key= %s, value= %s' % (repr(i), repr(key),repr(value)))
        for i1, (key1, value1) in enumerate(value.iteritems()):
            if key1 == 'channel':
                ###utils.logdev('Test Encoding y2','i1= %s, key1= %s, value1= %s' % (repr(i1), repr(key1),repr(value1)))
                for channelROQ in value1:
                    d=channelROQ
                    ###utils.logdev('Test Encoding y3','i1= %s, key1= %s, channelROQ= %s, url= %s' % (repr(d.items()[0]), repr(d.items()[1]),repr(d.items()[2]),repr(d.items()[3])))
                    ###utils.logdev('Test Encoding y4','\n\ntitle= %s,\n description= %s,\n category_id= %s,\n playlist_url= %s\n' % (repr(d['title']), repr(d['description']),repr(d['category_id']),repr(d['playlist_url'])))

    ###z = OrderedDict( ... )
    ###for item in data.items()[::-1]:
        # operate on item
    ### ###utils.logdev('Test Encoding y',repr(item))
        
    """
    Test Encoding 1: OrderedDict(
    [(u'items', OrderedDict(
        [(u'playlist_name', u'Movie [ Example ]'), (u'category', OrderedDict([(u'category_id', u'1'), (u'category_title', u'Movie [ Example ]')])), 
        (u'channel', 
            [OrderedDict([(u'title', u'QWxs'), (u'description', u'TW92aWUgU3RyZWFtcyBDYXRlZ29yeSBbIEFMTCBd'), (u'category_id', u'0'), (u'playlist_url', u'http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass') + '&type=get_vod_streams&cat_id=0')]), 
            OrderedDict([(u'title', u'Rk9SIEFEVUxUUw=='), (u'description', u'TW92aWUgU3RyZWFtcyBDYXRlZ29yeQ=='), (u'category_id', u'110'), (u'playlist_url', u'http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass') + '&type=get_vod_streams&cat_id=110')]), 
            OrderedDict([(u'title', u'TkVXIE1PVklFUw=='), (u'description', u'TW92aWUgU3RyZWFtcyBDYXRlZ29yeQ=='), (u'category_id', u'111'), (u'playlist_url', u'http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')+'&type=get_vod_streams&cat_id=111')]), 
            OrderedDict([(u'title', u'S0lEUyBNT1ZJRVM='), (u'description', u'TW92aWUgU3RyZWFtcyBDYXRlZ29yeQ=='), (u'category_id', u'112'), (u'playlist_url', u'http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass') + '&type=get_vod_streams&cat_id=112')]), 
            OrderedDict([(u'title', u'Qk9YU0VUUw=='), (u'description', u'TW92aWUgU3RyZWFtcyBDYXRlZ29yeQ=='), (u'category_id', u'113'), (u'playlist_url', u'http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')+ '&type=get_vod_scategories&scat_id=113')]), 
            OrderedDict([(u'title', u'VFZTRVJJRVM='), (u'description', u'TW92aWUgU3RyZWFtcyBDYXRlZ29yeQ=='), (u'category_id', u'77'), (u'playlist_url', u'http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')+'&type=get_vod_streams&cat_id=77')]), 
            OrderedDict([(u'title', u'TU9WSUVT'), (u'description', u'TW92aWUgU3RyZWFtcyBDYXRlZ29yeQ=='), (u'category_id', u'60'), (u'playlist_url', u'http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')+'&type=get_vod_streams&cat_id=60')])])]))])
    http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')+'&type=get_catchup_categories
    http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')+'&type=get_catchup_streams&cat_id=14
    http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')+'&type=get_vod_categories
    http://roq-tv.net:25461/enigma2.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')+'&type=get_vod_streams&cat_id=110
    import base64
    aircode = base64.b64decode('RElSRUNUT1I6IApQTE9UOiAKQ0FTVDogClJBVElORzogClJFTEVBU0VEQVRFOiAKR0VOUkU6IApJTURCX0lEOiAKRFVSQVRJT05fU0VDUzogMjIxNQpEVVJBVElPTjogMDA6MzY6NTUKVklERU86IEFycmF5CkFVRElPOiBBcnJheQpCSVRSQVRFOiA3NzQK')
    ###utils.logdev('Test Encoding',aircode)
    """
    setView('movies', 'main-view')     
            
def MyChannels():
    cat='-2'
    net.set_cookies(cookie_jar)
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20')
    url='&mwAction=category&xbmc=1&mwData={"id":"%s","time":"%s","type":"tv"}'%(cat,now)
    link = net.http_GET(site+url, headers={'User-Agent' : UA}).content
    data = json.loads(link)
    channels=data['contents']
    from operator import itemgetter
    #Sort channels by name or id/cat
    if ADDON.getSetting('SortAlphabetically')=='true':
        channels = sorted(channels, key=itemgetter('id'))
    else:
        channels = sorted(channels, key=itemgetter('name'))
    AllMyChannels=[]
    
    for field in channels:
        name         =  field['name'].encode("utf-8")
        channel      =  field['id']
        displaychannelnumber = (name + ' (' +channel+'):\n' )
        AllMyChannels.append(displaychannelnumber)
    return AllMyChannels
        

def GENRE(name,cat):
    GoHome('GENRE')
    _GENRE_=name.lower()
    #now= datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20')
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20')
    ## 3.4.6 now= datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20')
    
    net.set_cookies(cookie_jar)
    url='&mwAction=category&xbmc=2&mwData={"id":"%s","time":"%s","type":"tv"}'%(cat,now)
    link = net.http_GET(site+url, headers={'User-Agent' : UA }).content
    data = json.loads(link)
    channels=data['contents']
    # Krogsbell 2014-09-18 3 lines
    from operator import itemgetter
    #Sort channels by name!
    if ADDON.getSetting('SortAlphabetically')=='true':
         channels = sorted(channels, key=itemgetter('name'))
    uniques=[]
    
    offset= int(data['offset'])
    for field in channels:
        genre      =  field['genre']
        endTime      =  field['time_to']
        name         =  field['name'].encode("utf-8")
        channel      =  field['id']
        whatsup      =  field['whatsup'].encode("utf-8")
        displaychannelnumber = (name + ' (' +channel+'):\n' )
        description  =  (displaychannelnumber + field['descr']).encode("utf-8")
        #description  =  field['descr'].encode("utf-8")
        r=re.compile("(.+?)-(.+?)-(.+?) (.+?):(.+?):(.+?)")
        matchend     =  r.search(endTime)
        endyear      =  matchend.group(1)
        endmonth     =  matchend.group(2)
        endday       =  matchend.group(3)
        endhour      =  matchend.group(4)
        endminute    =  matchend.group(5)

        endDate  =  datetime(int(endyear),int(endmonth),int(endday),int(endhour),int(endminute)) + timedelta(seconds = offset)

        
        if ADDON.getSetting('tvguide')=='true':
            if not endDate  == '' and recordings.getRecordingsActiveAll(endDate,endDate): #################################################################
                name='%s - [COLOR red]%s[/COLOR]'%(name,whatsup)
            else:
                name='%s - [COLOR yellow]%s[/COLOR]'%(name,whatsup)
        if genre.lower() == _GENRE_:
            #newiconurl= recordings.imageUrlicon(imageUrl,channel,'.png')
            newiconurl= recordings.getIcon(name,channel)
            addDir(name,'url',200,newiconurl,channel,'',description,now,endDate,whatsup)
    setView('movies', 'channels-view')         
            
def MYACCOUNT():
    GoHome('My Account')
    username    =ADDON.getSetting('user')
    ###xbmcaddon.Addon(id=ADDONid).openSettings()
    addDir('Open Settings','url',10,'','','','Open Settings and change any you like')
    addDir('User: %s' % username,'url',14,'','','','Change your username and password. Then all channels will be removed and the EPG starts to update. You will loose favourites, recursive and hidden channels')
    addDir('Past settings.xml','url',15,'','','','Change setting to a previous state and may be user')
    addDir('Status','url',11,'','','','Watch the basic status of your account')
    #addDir('My Subscriptions','url',9,'','','','')
    #addDir('Past Orders','url',10,'','','','')
    setView('movies', 'main-view')

def Maintenance():
    GoHome('Maintenance')
    addDir('My Account','url',8,'','','','Change your user name/email address and password or restore previous configurations. \n\nWatch your basic account information')
    addDir('Backup Database and Settings','url',2059,'','','','Backup recordings_adc.db and settings.xml')
    addDir('Delete Database','url',116,'','','','Clear the Database. Stop all planned recordings and start a new EPG import')
    addDir('Restore from Database','url',104,'','','','Restore Database, Restore recursive recordings or EPG Data')
    addDir('Delete Old EPG programs','url',111,'','','','Delte 7 days old programs and 2 days old channels')
    addDir('Delete New EPG programs','url',110,'','','','Delte New EPG Programs. If to many programs have changed - update full afterwards')
    addDir('Delete All Channels','url',108,'','','','Delete All Channels. If user have changed - update full afterwards')
    if ADDON.getSetting('enable_record')=='true':
        addDir('Delete All Planned Recordings','url',109,'','','','Delete All Planned Programs. If recursive have made too many recordings - Stop all recordings and clear planned recording parts of database')
        addDir('Recursive Search Channels','url',26,'','','','All channels used for recursive search')
    addDir('Update EPG now','url',115,'','','','Start to Update EPG now')
    ftvntvini = (os.path.join(datapath,'ftv'+ADDONname) + '.ini').replace('/','/ ').replace('\\','\\ ')
    addDir('Make new INI file','url',112,'','','','Create INI file \n' + ftvntvini +' \nfor use with external TV Guides')
    addDir('Hidden Channels','url',20,'','','','All channels you have hidden from the other views - Here you can un-hide them')
    setView('movies', 'main-view')
      
def STATUS():
    GoHome('Status')
    link = definition.getBASEURL() + '/panel_api.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')
    file = urllib2.urlopen(link)
    data = file.read()
    file.close()
    
    ChannelFile = os.path.join(datapath,ADDONid) + '.info'
    with open(ChannelFile,'wb') as output:
        output.write(data)
    ###name= Status,url= url,mode= 11,iconimage= ,cat= ,date= ,description= {u'username': u'XXX', u'status': u'Active', u'is_trial': u'0', u'created_at': u'1493734688', u'auth': 1, u'allowed_output_formats': [u'm3u8', u'ts', u'rtmp'], u'exp_date': u'1499005088', u'active_cons': u'0', u'password': u'XXXX', u'max_connections': u'1'},startDate= ,endDate= ,recordname= )
    try:
        d = json.loads(data)
        d1 = d['user_info']
        formats = d1['allowed_output_formats']
        allowedformats = AllowedFormats(formats)
        """
        allowedformats = '['
        for f in formats:
            allowedformats += f + ', '
        allowedformats += ']'
        allowedformats = allowedformats.replace(', ]',']')
        """
        descr = 'Username= %s \nStatus= %s \nExpire= %s \nMax connections= %s \nAllowed formats= %s' %(d1['username'],d1['status'],recordings.parseDate(d1['exp_date']).strftime('%Y-%m-%d %H:%M'),d1['max_connections'],allowedformats)
    
        addDir('Basic Info','url',12,'','','',descr)
    except Exception, e:
        pass
        utils.notification('Error in getting '+ ADDONid + ' info! Check your User ID\n' + repr(e))
        d = []
    ###<<<   AddAtom('all',d)
    ###addDir('Test Info','url',12,'','','',d['server_info']['port'])
    """
    for field in d:
        ###utils.logdev(module,'params= %s' % repr(field))
        ###utils.logdev(module,'type(field)= %s' % repr(type(field)))
        if type(d[field]) == dict:
            da = d[field]
            for f in d[field]:
                if type(d[field][f]) == dict:
                for f in d[field]:
                    addDir(field +'/' +f,'url',12,'','','',repr(d[field][f]))
        else:
            
            addDir(field,'url',12,'','','',d[field])
    """     
    setView('movies', 'main-view') 

def AddAtom(level,data):
    if not type(data) == str:
        for field in data:
            if type(data[field]) == dict:
                AddAtom(level +'/'+ repr(field),data[field])
            else:
                if not field == 'movie' and not field == 'live':
                    ###utils.logdev(module,'addDir(level/field= %r,data[field]= %r)' % (level +'/'+ field,data[field]))
                    addDirBasic(level +'/'+ field,'url',12,'','','',data[field])

def AllowedFormats(formats):
    allowedformats = '['
    for f in formats:
        allowedformats += f + ', '
    allowedformats += ']'
    return allowedformats.replace(', ]',']')
    
def STATUSsub(data):
    GoHome('Status')
    ###utils.logdev(module,'STATUSsub data= %s' % repr(data))
    ###d = json.loads(data)
    for field in data:
        if len(field) > 2:
            ###utils.logdev(module,'STATUSsub params= %s' % repr(field))
            ###utils.logdev(module,'type(field)= %s' % repr(type(field)))
            if type(field) == dict:
                addDir(repr(field),'url',12,'','','',repr(data))
            else:
                addDir(field,'url',0,'','','',repr(data))
    setView('movies', 'main-view') 

def SUBS():
    GoHome('SUBS')
    net.set_cookies(cookie_jar)
    link = net.http_GET(definition.getBASEURL() +'/?' + recordings.referral() + 'c=1&a=18', headers={'User-Agent' : UA}).content
    data = json.loads(link)
    body = data['body']
    for field in body:
        title= field['title']
        platform= field['platforms'].encode("utf-8")
        status= field['status'].encode("utf-8")
        time_left= field['time_left'].encode("utf-8")
        name='%s-%s-(%s)[COLOR yellow] %s[/COLOR] '%(title,platform,time_left,status)
        addDir_STOP(name,'url','','','','')
    setView('movies', 'main-view') 
    
def ORDERS():
    GoHome('ORDERS')
    net.set_cookies(cookie_jar)
    link = net.http_GET(definition.getBASEURL() +'/?' + recordings.referral() + 'c=1&a=19', headers={'User-Agent' : UA}).content.encode('ascii', 'ignore')
    data = json.loads(link)
    body = data['body']
    for field in body:
        id= field['id'].encode("utf-8")
        price_total= field['price_total'].encode("utf-8")
        created= field['created'].encode("utf-8")
        status= field['status'].encode("utf-8")
        updated= field['updated'].encode("utf-8")
        name='%s-(%s)[COLOR yellow] %s-(%s)[/COLOR] '%(price_total, created, status, updated)
        addDir_STOP(name,'url','','','','')
    setView('movies', 'main-view') 

def Search(name):
        search_entered = ''
        keyboard = xbmc.Keyboard(search_entered, 'Please Enter '+str(name))
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText()
            if search_entered == None:
                return False          
        return search_entered  
        
def Numeric(name):
        dialog = xbmcgui.Dialog()
        keyboard=dialog.numeric(0, 'Please Enter '+str(name))
        return keyboard  

def ADD_FAV(cat):
    recordings.addChannelFav(cat)
    return
    
def DEL_FAV(cat):
    recordings.delChannelFav(cat)
    return

def SET_HIDE(cat):
    recordings.setChannelHide(cat)
    return
    
def DEL_HIDE(cat):
    recordings.delChannelHide(cat)
    return

def SET_RECURSIVE(cat):
    recordings.setChannelRecursive(cat)
    return
    
def DEL_RECURSIVE(cat):
    recordings.delChannelRecursive(cat)
    return

def SELECT_TV_GUIDE_CHANNEL(name,url,iconimage,cat):
    try:
        channel = updateepg.getEPGChannel(cat)
        name = channel[0]
        EPGchannel = channel[1]
        source = channel[2]
        #print Platform
        dialog = xbmcgui.Dialog()
        lockcause = 'change' ### Dummy command
        if type(EPGchannel) == str:
            if dialog.yesno(ADDON.getAddonInfo('name'), "[COLOR red]Change TV Guide Channel?[/COLOR]", name + ' (' + cat + ') --> ' + EPGchannel + ' ('  + source + ')', "What Do You Want To Do","[COLOR red]Change channel[/COLOR]","[COLOR green]Ignore[/COLOR]"):
                ### Ignore
                lockcause = 'ignore' ### Dummy command
            else:
                ### Stop recording and record new
                lockcause = 'change' ### Dummy command
        else:
            EPGchannel = ''
        #########################
        utils.logdev(module, 'SelectedChannel Channel= %r' % (name))
        if lockcause == 'change' :
            mychannels = ['No EPG'] + findtvguidenotifications.MyChannels()
            ###mychannels.append(findtvguidenotifications.MyChannels())
            SelectedChannel = xbmcgui.Dialog().select(name + ' (' + cat + ') --> ' + EPGchannel, mychannels)
            utils.logdev(module, 'SelectedChannelNo= %r' % (SelectedChannel))
            if SelectedChannel <> -1:
                try:
                    utils.logdev(module, 'try SelectedChannel= %r' % (mychannels[SelectedChannel]))
                    EPGchannel = mychannels[SelectedChannel].split('(')[-1].split(' - ')[0].strip()
                    updateepg.setEPGChannel(cat,EPGchannel)
                    utils.notification(name + ' (' + cat + ') --> ' + EPGchannel)
                except Exception, e:
                    pass
                    utils.logdev(module, 'SelectedChannel FAILED Channel= %r \nERROR= %r' % (SelectedChannel,e))
    except Exception, e:
        pass
        utils.logdev(module,'Error in SELECT_TV_GUIDE_CHANNEL\n' + repr(e))

def TVGUIDE(namech,cat):
    ### [recordings.getEPGPrograms(epg_channel_id), name-1, tv_archive-2, tv_archive_duration-3, epg_channel_id-4]
    GoHome('TV guide')
    now= datetime.today()
    guide = updateepg.getEPG(cat)
    try:
        guideEPG = guide[0]
    except Exception, e:
        pass
        utils.logdev(module,'Error in getting TV Guide\n' + repr(e))
        return
    nameEPG = guide[1]
    tv_archive = guide[2]
    tv_archive_duration= guide[3]
    epg_channel_id = guide[4]
    if namech == 'None' or namech == '':
        namech = nameEPG
        if namech == 'None' or namech == '':
            namech = recordings.ChannelName(cat)
    utils.logdev(module,'TVguide name= %r, tv_archive= %r, tv_archive_duration= %r, epg_channel_id= %r' % ( namech, tv_archive, tv_archive_duration, epg_channel_id))
    newiconurl = recordings.getIcon(namech,cat)
    for index in range(0, len(guideEPG)):
        ch = []
        for i in range(0, len(guideEPG[index])):
            if guideEPG[index][i] == None:
                ch.append('')
            else:
                ch.append(guideEPG[index][i])
        ###SELECT DISTINCT title-0, description-1, source-2, start_date-3, end_date-4 FROM programs WHERE channel=?
        ###def addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
        ###addDir(name,'url',200,iconimage,channel,'',description,now,endDate,whatsup)
        ###addDir(ch[0],'url',200,'',cat,'',ch[1] + ' \nEPG from: \n' + ch[2],ch[3],ch[4],ch[1])
        ###datetime.fromtimestamp
        
        try:
            ###utils.logdev(module,'start= %r, end= %r' % (ch[3], ch[4] ))
            ###startDate= datetime.fromtimestamp(float(ch[3]))
            startDate= ch[3]
            ###utils.logdev(module,'Getting startDate\n' + repr(startDate) + ' of type ' + repr(type(startDate)))
            if type(startDate) == int:
                startDate= datetime.fromtimestamp(float(ch[3]))
                endDate= datetime.fromtimestamp(float(ch[4]))
            else:
                startDate= ch[3]
                endDate= ch[4]
            try:
                ArchiveOffset = int(ADDON.getSetting('archiveoffset'))
            except:
                pass
                ArchiveOffset = 1
            ###utils.logdev(module,'ArchiveOffset= %r' % (ArchiveOffset))
            startDateCU= startDate + timedelta(seconds = (ArchiveOffset - TimeZone)*3600 -60)  ### USE UK TimeZone and start 1 minutes early
        except Exception, e:
            pass
            startDate=''
            startDateCU=''
            endDate=''
            utils.logdev(module,'Error in getting dates\n' + repr(e))
        name= ch[0] ###.encode("utf-8")
        recordname= ch[0] ###.encode("utf-8")
        StartDateTime = ''
        Duration = ''
        try:
            StartDateTime = ' \nStart ' + startDate.strftime('%Y-%m-%d %H:%M')
            ###t = int(ch[4]) - int(ch[3])
            dura = (endDate - startDate)/60
            ###if dura > 300:
            ### utils.logdev(module,'Duration= %r, start= %r, end= %r' % (dura, startDate, endDate ))
            Duration = ' \nDuration [' + str(dura)[-5:] +'] \n'  ###2018-03-08
            #Duration = ' \nDuration ' + str(dura) + ' \n'
            ###Duration = ' \nDuration ' + str((dura)/60) + ' min \n\n'
            try:  ### When was EPG created?
                if 'EPG Created ' in ch[1]:
                    EPGtime = 'EPG Created ' + ch[1].split('EPG Created ')[1][0:19]+'\n'
            except:
                pass
                EPGtime = ''
            description= (namech + ' (' +cat+'):'+StartDateTime+Duration +EPGtime+ '\n' + ch[1])   ###.encode("utf-8")  ### 2018-02-17
            ###utils.logdev(module,'Duration= %r' % Duration )
        except Exception, e:
            pass
            utils.logdev(module,'Error in getting duration\n' + repr(e))
            ###recordings.latin1_to_ascii_force (unicrap)
            description = (recordings.latin1_to_ascii_force(namech) + ' (' +recordings.latin1_to_ascii_force(cat)+'):' +StartDateTime+Duration+ recordings.latin1_to_ascii_force(ch[1]))
        description = description.replace('(n)','\n').replace('.n','. \n')   ### 2018-02-17
        if '[' in name:
            name = '[B]' + name.replace('[','\n[COLOR lightwhite][/B][I][',1) + '[/I]'
            name = name.split('\n')
            line1 = name[0]
            lenline1 = len(line1)
            line2 = name[1]
            lenline2 = len(line2)
            if lenline1 < lenline2:
                line1 = line1 + ' ' * (lenline2 - lenline1 - 16)
            name = line1 +'\n' + line2    ### +'.'+ str(lenline1)+'.'+ str(lenline2)
        else:
            name = '[B]' + name + '[/B]'
        try:
            if tv_archive == 1 and startDate < now:  ### startDate <-- endDate
                name='[COLOR salmon]%s[/COLOR]'%(name)
                time=startDate.strftime('Arc %d.%m %H:%M  ')
                ###addDir(name,url,mode,iconimage='',cat='',date='',description='',startDate='',endDate='',whatsup='')
                ###duration = str(timedelta.total_seconds(endDate - startDate)/60 + 16)  ### duration plus 15 min
                ###utils.logdev(module+'repr(endDate - startDate)=',repr(endDate - startDate))
                ### ANDROID and Linux version
                duration = str(int(repr(endDate - startDate).replace('datetime.timedelta(0, ','').split(')')[0].split(',')[0])/60 + 16) ### duration plus 15 min + 1 min ahead
                start    = startDateCU.strftime('%Y-%m-%d:%H-%M')
                url = definition.getBASEURL() + '/streaming/timeshift.php?username='+ADDON.getSetting('user')+'&password='+ADDON.getSetting('pass')+'&stream='+cat+'&duration='+duration+'&start='+start
                ###utils.logdev(module,'2020 url= ' + url)
                addDir(time+name,url,2020,newiconurl,cat,startDate,description,startDate,endDate,recordname) ### Watch or record Archive
            elif tv_archive != 1 and endDate < now :  ### Show History (1 day)
                try:
                    hourstoshow = int(ADDON.getSetting('showhistoryintvguide'))
                    ###utils.logdev(module,'H start= %r, end= %r' % (startDate, endDate))
                    name='[COLOR cyan]%s[/COLOR]'%(name)
                    time=startDate.strftime('His %d.%m %H:%M  ')
                    if endDate > now - timedelta(hours = hourstoshow):
                        addDir(time+name,'url',200,newiconurl,cat,startDate,description,startDate,endDate,recordname)
                except:
                    pass
            elif startDate <= now and now <= endDate:
                name='[COLOR yellow]%s[/COLOR]'%(name)
                time=startDate.strftime('Now %d.%m %H:%M  ')
                url = recordings.urlFromCat(cat)
                addDir(time+name,url,200,newiconurl,cat,startDate,description,startDate,endDate,recordname)
            elif startDate > now and endDate > now:
                ### Find programs that are recording
                recprograms = recordings.isRecording(cat,name,startDate,endDate)
                utils.logdev(module,'Is program: %r beeing recorded? SD= %r ED= %r ActivePrograms: %r' %(name,startDate,endDate,recprograms))
                if recprograms:
                    name='[COLOR red]%s[/COLOR]'%(name)
                else:
                    name='[COLOR lightgreen]%s[/COLOR]'%(name)
                
                time=startDate.strftime('Rec %d.%m %H:%M  ')
                addDir(time+name,'url',2001,newiconurl,cat,startDate.strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20'),description,startDate.strftime('%Y-%m-%d %H:%M:%S'),endDate.strftime('%Y-%m-%d %H:%M:%S'),recordname) ### Record
            else:
                utils.logdev(module,'ERROR start= %r, end= %r' % (startDate, endDate))
        except Exception, e:
            pass
            utils.logdev(module,'Error in setting menu\n' + repr(e))
    setView('movies', 'tvguide-view')

def RecordingsPlanned():
    GoHome('Planned Recordings')
    offset=0
    c = recordings.getConnection().cursor()
    #c.execute("SELECT * FROM recordings_adc WHERE end=?", [endDate])
    # SELECT * FROM COMPANY WHERE AGE >= 25 OR SALARY >= 65000;
    ## 3.4.6cutoffdate = (datetime.datetime.today() - datetime.timedelta(days = 1)).strftime('%Y-%m-%d')
    cutoffdate = (datetime.today() - timedelta(days = 1)).strftime('%Y-%m-%d')
    # 5) Retrieve all IDs of entries between that are older than 1 day and 12 hrs
    #c.execute("SELECT {idf} FROM {tn} WHERE DATE('now') - {dc} >= 1 AND DATE('now') - {tc} >= 12".\
    #    format(idf=id_field, tn=table_name, dc=date_col, tc=time_col))
    #all_1day12hrs_entries = c.fetchall()
    #c.execute("SELECT * FROM recordings_adc WHERE (DATETIME('now') - end) = 0 ")
    #all_1day12hrs_entries = c.fetchall()
    #print 'default.py: cutoffdate= %s' % repr(cutoffdate)
    #print 'default.py: SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE start > %s' % cutoffdate
    #c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE start > %s  AND name NOT CONTAINS 'Recursive' " % cutoffdate )
    try:
        c.execute("SELECT * FROM recordings_adc WHERE end>? AND name NOT LIKE '%Recursive:%'", [cutoffdate])
        #c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc")
    except Exception, e:
        pass
        utils.logdev(module, 'c.execute(SELECT * FROM recordings_adc WHERE end>? AND name NOT LIKE Recursive:, [cutoffdate]) failed! \nERROR= %r' % e)
    recordingsC = c.fetchall()
    #Sort Planned Recordings by start date!
    recordingsD = sorted(recordingsC, key=itemgetter(2))
    # print 'default.py: RecordingsPlanned recordingsD= %s' % repr(recordingsD)
    addDir('[COLOR white][B]Planned Recordings (' + str(len(recordingsD)) + ')[/B][/COLOR]','url',104,'','','','Counter','','','')
    for index in range(0, len(recordingsD)):
        if not 'Recursive:' in recordingsD[index][1]:
            showRecording(recordingsD,index)
    # Put recursive recordings last
    try:
        c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE '%Recursive:%'")
    except Exception, e:
        pass
        utils.logdev(module, 'c.execute(SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE Recursive:) failed! \nERROR= %r' % e)
    recordingsC = c.fetchall()
    #recordingsD = sorted(recordingsC, key=itemgetter(1))  # Sort by name
    #recordingsE = sorted(recordingsD, key=itemgetter(6))  # Sort by channel
    recordingsE = sorted(recordingsC, key=itemgetter(1)) # sort by last named
    # print 'default.py: RecordingsPlanned recordingsE= %s' % repr(recordingsE)
    addDir('[COLOR white][B]Recursive Recordings (' + str(len(recordingsE)) + ')[/B][/COLOR]','url',104,'','','','Counter','','','')
    for index in range(0, len(recordingsE)):
        if 'Recursive:' in recordingsE[index][1]:
            showRecording(recordingsE,index)
    setView('movies', 'recordingsplanned-view')
    try: c.commit()
    except:
        pass
        #print 'recordings.py commit failed!'
    c.close()

def RecordingsPlannedDebug():
    import recordings
    import utils
    GoHome('Planned Recordings (Debug)')
    offset=0
    c = recordings.getConnection().cursor()
    c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc")
    recordingsC = c.fetchall()
    from operator import itemgetter
    
    #Sort Planned Recordings by start date!
    recordingsD = sorted(recordingsC, key=itemgetter(2))
    #RecordingsPlannedDebugIcons(recordingsD)
    for index in range(0, len(recordingsD)):
        if not 'Recursive:' in recordingsD[index][1]:
            showRecordingDebug(recordingsD,index)
    # Put recursive recordings last
    recordingsD = sorted(recordingsC, key=itemgetter(1))  # Sort by channel
    recordingsE = sorted(recordingsD, key=itemgetter(6))  # Sort by channel
    # recordingsE = sorted(recordingsC, key=itemgetter(2), reverse=True) # sort by last modified
    for index in range(0, len(recordingsE)):
        if 'Recursive:' in recordingsE[index][1]:
            showRecordingDebug(recordingsE,index)
    setView('movies', 'recordingsplanned-view')
    try: c.commit()
    except:
        pass
        #print 'recordings.py commit failed!'
    c.close()
    
def RecordingsPlannedDebugIcons(recordingsD):
    for index in range(0, 10):
        showRecordingDebug(recordingsD,str(index))
        #print 'showRecordingDebug index= %s' % str(index)
    setView('movies', 'recordingsplanned-view')
    
def concurrentrecordings(startDate):
    try:
        ccc= recordings.getRecordingsConcurrent(startDate,startDate)
        ###utils.logdev(module, 'concurrentrecordings(startDate= %r)= %r' % (startDate,ccc))
        ccc= len(ccc)
        if ccc > 0:
            ccc= '[COLOR red]' + str(ccc) + '[/COLOR] '
        else:
            ccc= ''
        ###utils.logdev(module, 'len(concurrentrecordings(startDate= %r))= %r' % (startDate,ccc))
    except Exception,e:
        pass
        utils.logdev(module, 'concurrentrecordings(startDate= %r) FAILED %r' % (startDate,e))
        ccc= ''
    return ccc

def showRecording(recordingsC,index):
        ###GoHome('Show Recordings')
        now = recordings.parseDate(datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
        ignoreRecording = False
    #for index in range(0, len(recordingsC)): 
        cat         = recordingsC[index][0]
        #name        = recordings.latin1_to_ascii (recordingsC[index][1].encode("utf-8"))
        name        = recordingsC[index][1]
        startDate   = recordings.parseDate(recordingsC[index][2])
        endDate     = recordings.parseDate(recordingsC[index][3])
        alarmname   = recordingsC[index][4]
        description = recordingsC[index][5]
        playchannel = recordingsC[index][6] 
        try:
            playchannel = recordings.ChannelName(cat)
        except:
            pass
        try:
            #timeShowStart= str(startDate).split(':')[0] + ":" + str(startDate).split(':')[1]
            timeShowStart=str(startDate).split(' ')[0] + ' (' + (str(startDate).split(' ')[1]).split(':')[0] + ":" + (str(startDate).split(' ')[1]).split(':')[1] 
        except:
            pass
            #print 'default.py: ERROR in startDate= %s' % repr(startDate)
            ignoreRecording = True
            startDate = now
            timeShowStart = now
        try:
            timeShowEnd=(str(endDate).split(' ')[1]).split(':')[0] + ":" + (str(endDate).split(' ')[1]).split(':')[1] +')'
        except:
            pass
            #print 'default.py: ERROR in endDate= %s' % repr(endDate)
            ignoreRecording = True
            endDate = now
            timeShowEnd = now
        nowY = now.strftime('%Y-')
        nowYM = now.strftime('%Y-%m-')
        nowYMD = now.strftime('%Y-%m-%d ')
        time='[COLOR yellow]%s - %s [/COLOR]'%(timeShowStart.replace(nowYMD,'').replace(nowYM,'').replace(nowY,''),timeShowEnd)
        timeOld='%s - %s '%(timeShowStart.replace(nowYMD,'').replace(nowYM,'').replace(nowY,''),timeShowEnd)
        displaychannelnumber = playchannel + ' (' +cat+ '):\n'
        displaychannelnumberold = playchannel + '(' +cat+ '):'
        displaydescription = description.replace(displaychannelnumber,'').replace(displaychannelnumberold,'').lstrip()
        if ('Recursive:' in name):
            timeRecursive = '%s - '%(timeShowStart)
            #nameRecursive = str(name.replace(':','xxx',1))
            #nameRecursive = str(playchannel) + ' - ' + str(nameRecursive.split('xxx')[1])
            nameRecursive = str(name.replace('Recursive:','',1))
            nameRecursive = nameRecursive + ' - ' +  str(playchannel)
            if len(displaydescription) > 0:
                descriptionstrip =  (str(displaydescription).replace('[COLOR green]Example description of channel to record: [/COLOR]','')).lstrip()
                description = '[COLOR green]Example description of channel to record: [/COLOR]\n' + descriptionstrip
        recordname=name
        namecolor = ''
        namecolortest = '*'
        if '[COLOR' in name:
            namecolortest = name.split('[/COLOR]')
            if len(namecolortest) == 1 or len(namecolortest) == 3 or len(namecolortest) == 5:
                namecolor = '[/COLOR]'
        if ' [' in name:
            name = name.replace(' [',namecolor + '[/B]                                                   \n[I][COLOR grey][',1)
        ###name = name.replace(' [','[/B]                                                   \n[I][COLOR blue][',1)         ### 2018-04-21
        if '\n[I]' in name:
            name = '[B]' + name +'[/COLOR][/I]'
        #now = recordings.parseDate(now)
        now = recordings.parseDate(datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
        startDate = recordings.parseDate(startDate)
        endDate = recordings.parseDate(endDate)
        #print 'endDateTest =  endDate= %s + datetime.timedelta(days = 1)' % repr(endDate)
        endDateTest =  endDate + timedelta(days = 1) # Number of previous days to show in view
        #print 'endDateTest = %s  endDate + datetime.timedelta(days = 1)' % repr(endDateTest)
        #newiconurl= recordings.imageUrlicon(imageUrl,cat,'.png')
        newiconurl= recordings.getIcon(name,cat)
        newurl    = recordings.urlFromCat(cat)
        displaydescription = displaychannelnumber + description.replace(displaychannelnumber,'').replace(displaychannelnumberold,'').lstrip().replace('. ','.\n').replace('AAabBB',' ').replace('aAabBb','?').replace('BBabAA','=').replace('xXx',' ').replace('###',',').replace('AaAaA','=')  ### 2017-06-04        
        if (not ignoreRecording and ((recordings.parseDate(endDateTest) > recordings.parseDate(datetime.today().strftime('%Y-%m-%d'))) or ('Recursive:' in name))):
            if (startDate < now and now < endDate) and (not ('Recursive:' in name)):
                #http://www.dk4.dk/templates/dk4/images/dk4Logo.png
                #addDir(time+'[COLOR red]'+name+'[/COLOR]','url',200,'http://www.dk4.dk/templates/dk4/images/dk4Logo.png',cat,startDate,playchannel + ': ' + description,startDate,endDate,recordname)
                addDir(time+'[COLOR red]'+name+'[/COLOR]',newurl,200,newiconurl,cat,startDate,displaydescription,startDate,endDate,recordname)
            else:
                if (endDate < now) or ('Recursive:' in name):
                    if ('Recursive:' in name):
                        if recordings.directprograms(cat) == '':
                            addDir(nameRecursive + " (" + str(cat) + ")",newurl,200,newiconurl,cat,startDate,displaydescription,startDate,endDate,recordname)
                        else:
                            addDir('[COLOR lightgreen]' + nameRecursive + " (" + str(cat)+ ')[/COLOR]' ,newurl,200,newiconurl,cat,startDate,displaydescription,startDate,endDate,recordname)
                    else:
                        addDir(timeOld+name,newurl,200,newiconurl,cat,startDate,displaydescription,startDate,endDate,recordname)
                else:
                    if '[COLOR orange]' in name:
                        ccc = ''
                    else:
                        ccc = concurrentrecordings(startDate)
                    if recordings.directprograms(cat) == '':
                        addDir(time+ccc+name,newurl,200,newiconurl,cat,startDate,displaydescription,startDate,endDate,recordname)
                    else:
                        addDir(time+ccc +'[COLOR lightgreen]' + name + '[/COLOR]', 'url', 200, newiconurl, cat, startDate, displaydescription, startDate, endDate, recordname)
            #setView('movies', 'recordingsplanned-view')

def showRecordingDebug(recordingsC,index):
        import recordings
        ###GoHome('Show Recordings (Debug)')
        now = recordings.parseDate(datetime.today().strftime('%Y-%m-%d %H:%M:%S'))

    #for index in range(0, len(recordingsC)): 
        cat         = recordingsC[index][0]
        name        = recordingsC[index][1].encode("utf-8")
        startDate   = recordingsC[index][2]
        endDate     = recordingsC[index][3]
        alarmname   = recordingsC[index][4]
        description = recordingsC[index][5]
        playchannel = recordingsC[index][6]
        #cat            = str(index)
        #name        = str(index)
        #startDate   = now
        #endDate     = now
        #alarmname   = str(index)
        #description = str(index)
        #playchannel = str(index)       #description = '\nind=%s \ncat=%s \nnam=%s \nsta=%s \nend=%s \nala=%s \npla=%s' %(repr(index),repr(cat),repr(name),repr(startDate),repr(endDate),repr(alarmname),repr(playchannel))
        #print str(index)
        #print imageUrl+cat+'.png'
        #newiconurl= recordings.imageUrlicon(imageUrl,cat,'.png')
        newiconurl= recordings.getIcon(name,cat)
        try:
            #print repr(OPEN_URL(imageUrl+cat+'.png')) 
            addDir('[COLOR red]'+name+'[/COLOR]','url',200,newiconurl,cat,startDate,playchannel + ': '  + repr(startDate) + ' - ' + repr(startDate) + ' # ' + description,startDate,endDate,name)
        except:
            pass
        #setView('movies', 'recordingsplanned-view')

def playmediaORG(media_url):
    try:
        import traceback
        import  CustomPlayer
        player = CustomPlayer.MyXBMCPlayer()
        listitem = xbmcgui.ListItem( label = str(name), iconImage = "DefaultVideo.png", thumbnailImage = xbmc.getInfoImage( "ListItem.Thumb" ), path=media_url )
        player.play( media_url,listitem)
        xbmc.sleep(1000)
        while player.is_active:
            xbmc.sleep(200)
    except:
        traceback.print_exc()
    return ''
    
def playmedia(media_url):
    try:
        import traceback
        import  CustomPlayer
        player = CustomPlayer.MyXBMCPlayer()
        listitem = xbmcgui.ListItem( label = str(name), iconImage = "DefaultVideo.png", thumbnailImage = xbmc.getInfoImage( "ListItem.Thumb" ), path=media_url )
        utils.logdev(module,'player.play( media_url= %r,\nlistitem= %r)' % ( media_url,listitem))
        player.play( media_url,listitem)
        xbmc.sleep(1000)
        i = 0
        ###while player.is_active and i < 30:
        while player.is_active:
            ###time.sleep(1)
            xbmc.sleep(1000)
            i += 1
            ###utils.logdev(module,'player.play( media_url= %r, i= %r)' % ( media_url,i))
    except:
        pass
        utils.logdev(module,'traceback.print_exc()' )
        traceback.print_exc()
    ###return ''
    
def RECORD_CATCHUP(name,url,iconimage,cat,description): 
    ###utils.logdev(module,'RECORD_CATCHUP url= ' + url)
    utils.logdev(module,'RECORD_CATCHUP (name= %r \nurl= %r \niconimage= %r \ncat= %r \ndescription= %r )' % (name,url,iconimage,cat,description))
    startD = recordings.parseDate(datetime.now())
    endD = startD

    recordingsActive = []
    recordingsActiveAll = recordings.getRecordingsActive(startD,endD)
    utils.logdev(module,'recordingsActiveAll= %r' % recordingsActiveAll)
    for x in recordingsActiveAll:
        utils.logdev(module,'x= %s' % repr(x))
        if not '[COLOR orange]' in x:
            utils.logdev(module,'recordingsActive= %s' % repr(recordingsActive))
            recordingsActive.append(x)
            utils.logdev(module,'recordingsActive= %s' % repr(recordingsActive))
    if (recordingsActive != []) or locking.isAnyRecordLocked():
        utils.notification('OVERLAPPING Recordings NOT allowed: %s' % str(recordingsActive))
        #if (repr(recordingsActive) != "[]"):
        lockcause = repr(locking.RecordsLocked())
        #else:
        #   lockcause = repr(recordingsActive)
        dialog = xbmcgui.Dialog()
        if dialog.yesno(ADDON.getAddonInfo('name'), "[COLOR red]Stop recording?[/COLOR]", repr(recordingsActive), "What Do You Want To Do","[COLOR red]Stop recording[/COLOR]","[COLOR green]Ignore[/COLOR]"):
            ### Ignore
            lockcause = 'Ignore' ### Dummy command
        else:
            ### Stop recording and record new
            Recordffmpeg(name, url, '', '', description.replace(' ','AAabBB').replace('?','aAabBb').replace('=','BBabAA').replace(',','###').replace('&','AaAaA').replace('\n','NlNlNl'), auth)
    else:
        Recordffmpeg(name, url, '', '', description.replace(' ','AAabBB').replace('?','aAabBb').replace('=','BBabAA').replace(',','###').replace('&','AaAaA').replace('\n','NlNlNl'), auth)
    

def PLAY_CATCHUP(name,url,iconimage,cat,description):    ### Watch Archive 2020
    ###http://roq-tv.net:25461/streaming/timeshift.php?username=XXX&password=XXXX&stream=276&duration=120&start=2017-05-21:16-00
    ###duration = endDate - startDate  ### in minutes
    ###start    = startDate.strftime('%Y-%m-%d:%H-%M')
    ###url = 'http://roq-tv.net:25461/streaming/timeshift.php?username='+ADDON.getSetting('user')+'&password='+ADDON.getSetting('password')+'&stream='+cat+'&duration='+duration+'&start='+start
    utils.logdev(module,'PLAY_CATCHUP 2020 (name= %r \nurl= %r \niconimage= %r \ncat= %r \ndescription= %r )' % (name,url,iconimage,cat,description))
    ###PLAY_STREAM(name,url,iconimage,cat)
    startD = recordings.parseDate(datetime.now())
    endD = startD

    recordingsActive = []
    recordingsActiveAll = recordings.getRecordingsActive(startD,endD)
    utils.logdev(module,'recordingsActiveAll= %r' % recordingsActiveAll)
    for x in recordingsActiveAll:
        utils.logdev(module,'x= %s' % repr(x))
        if not '[COLOR orange]' in x:
            utils.logdev(module,'recordingsActive= %s' % repr(recordingsActive))
            recordingsActive.append(x)
            utils.logdev(module,'recordingsActive= %s' % repr(recordingsActive))
    if (recordingsActive != []) or locking.isAnyRecordLocked():
        utils.notification('OVERLAPPING Recordings NOT allowed: %s' % str(recordingsActive))
        #if (repr(recordingsActive) != "[]"):
        lockcause = repr(locking.RecordsLocked())
        #else:
        #   lockcause = repr(recordingsActive)
        dialog = xbmcgui.Dialog()
        if dialog.yesno(ADDON.getAddonInfo('name'), "[COLOR red]Stop recording?[/COLOR]", repr(recordingsActive), "What Do You Want To Do","[COLOR red]Stop recording[/COLOR]","[COLOR green]Record this later[/COLOR]"):
            ### Code to record/download
            playchannel = recordings.ChannelName(cat)
            RECORD_CATCHUP(name+' ('+playchannel+')',url,iconimage,cat,description)
            return
    """
    #print 'default.py: locking.recordUnlockAll()'
    locking.recordUnlockAll()
    # Test locking and unlock
    testX = 'TEST'
    locking.recordLock(testX)
    if locking.isRecordLocked(testX):
        locking.recordUnlock(testX)
    else:
        recordingLock = os.path.join(ADDON.getAddonInfo('path'),'rtmpdump', 'recordingLock') +  testX + '.txt'
        utils.notification('Record Locking fails at %s' % str(recordingLock))
    """
    try:
        _name=name.split(' -')[0].replace('[/COLOR]','').replace('[COLOR salmon]','')
        playername=name.split('- ')[1].replace('[/COLOR]','').replace('[COLOR salmon]','')
    except:
        _name=name.replace('[/COLOR]','')
        playername=name.replace('[/COLOR]','')
    dialog = xbmcgui.Dialog()
    if dialog.yesno(ADDON.getAddonInfo('name'), "[COLOR red]Record from archive?[/COLOR]", playername, "What Do You Want To Do","[COLOR red]Record[/COLOR]","[COLOR green]Watch[/COLOR]"):
        playmedia(url)
    else:
        ### Code to record/download
        playchannel = recordings.ChannelName(cat)
        RECORD_CATCHUP(name+' ('+playchannel+')',url,iconimage,cat,description)
        ###RECORD_CATCHUP(name,url,iconimage,cat,description)
        
def PLAY_STREAM(name,url,iconimage,cat):
    if cat == '':
        cat=recordings.catFromUrl(url)
    recorddrdirectly=recordings.directprograms(cat)  ### Get direct links
    playchannel = name + ' (' + cat + ')'
    if recorddrdirectly == '':
        LastPlayedStreamname = ADDON.getSetting('LastPlayedStreamname')
        LastPlayedStreamurl = ADDON.getSetting('LastPlayedStreamurl')
        LastPlayedStreamiconimage = ADDON.getSetting('LastPlayedStreamiconimage')
        LastPlayedStreamcat = ADDON.getSetting('LastPlayedStreamcat')
        if cat != '':
            ADDON.setSetting('LastPlayedStreamname', name)
            ADDON.setSetting('LastPlayedStreamurl', url)
            ADDON.setSetting('LastPlayedStreamiconimage', iconimage)
            ADDON.setSetting('LastPlayedStreamcat', cat)
            PlayDefaultStream = False
        else:
            name = LastPlayedStreamname
            url = LastPlayedStreamurl
            iconimage = LastPlayedStreamiconimage
            cat = LastPlayedStreamcat
            PlayDefaultStream = True
        startD = recordings.parseDate(datetime.now())
        endD = startD
        utils.logdev(module,'PlayDefaultStream= %s' % repr(PlayDefaultStream))
        if PlayDefaultStream:
            recordingsActive = []
        else:
            recordingsActive = []
            recordingsActiveAll = recordings.getRecordingsActive(startD,endD)
            utils.logdev(module,'recordingsActiveAll= %r' % (recordingsActiveAll))
            for x in recordingsActiveAll:
                utils.logdev(module,'x= %r' % (x))
                if not '[COLOR orange]' in x:
                    utils.logdev(module,'recordingsActive= %r' % (recordingsActive))
                    recordingsActive.append(x)
                    utils.logdev(module,'recordingsActive= %r' % (recordingsActive))
        if (recordingsActive != []) or locking.isAnyRecordLocked():
            utils.notification('OVERLAPPING Recordings NOT allowed: %r' % (recordingsActive))
            lockcause = repr(locking.RecordsLocked())
            dialog = xbmcgui.Dialog()
            if dialog.yesno(ADDON.getAddonInfo('name'), "[COLOR red]Stop recording?[/COLOR]", repr(recordingsActive), "What Do You Want To Do","[COLOR red]Stop recording[/COLOR]","[COLOR green]Ignore[/COLOR]"):
                return
    else:
        utils.logdev('play direct channel',repr(name))
    try:
        _name=name.split(' -')[0].replace('[/COLOR]','').replace('[COLOR yellow]','')
        playername=name.split('- ')[1].replace('[/COLOR]','').replace('[COLOR yellow]','')
    except:
        _name=name.replace('[/COLOR]','')
        playername=name.replace('[/COLOR]','')
    utils.logdev('TIMESHIFT','Start TimeShift')
    timeshiftsetting = ADDON.getSetting('timeshift')
    if timeshiftsetting == '1':
        ask = xbmcgui.Dialog().yesno( ADDON.getAddonInfo('name'), name + '\n\nUse TimeShift?')
        #utils.notificationbox(repr(ask))
        if repr(ask) == '1':
            timeshiftsetting = '2'
        else:
            timeshiftsetting = '0'
    if timeshiftsetting == '2':
        ###utils.logdev('default.py','RecordTimeShift(timeshift, url= %s, playpath= %s, app= %s)' % (url, playpath,app))
        
        ###timeshiftfileold = timeshiftfile.replace('.ts','OLD.ts')
        ###utils.logdev('default.py','shutil.copyfile(timeshiftfile= %s,timeshiftfileold= %s)' % (timeshiftfile,timeshiftfileold))
        ###deleteFile(timeshiftfileold)
        ###try:
        ###    shutil.copyfile(timeshiftfile,timeshiftfileold)  ###
            ###utils.logdev('default.py','shutil.copyfile(timeshiftfile,timeshiftfileold) EXECUTED')
        ###except:
        ###    pass
        """if os.path.isfile(timeshiftfile) == True: 
            deleteFile(timeshiftfile)
            count = 0
            test = os.path.isfile(timeshiftfile)
            while not test == True and count < 10:
                ###time.sleep(1)
                xbmc.sleep(1000)
                count += 1
                test = os.path.isfile(timeshiftfile)
                ###utils.logdev('default.py','RecordTimeShift test delete count= %s' % repr(count))
        """
        ADDON.setSetting('timeshiftfile','')  ### Clear Filename
        count = 0
        timeshiftfile = ADDON.getSetting('timeshiftfile')
        while timeshiftfile != '' and count < 10:
            xbmc.sleep(100)
            timeshiftfile = ADDON.getSetting('timeshiftfile')
            count += 1
        utils.logdev(module,'RecordTimeShift 1 #%r file= %r' % (count,timeshiftfile))
        stoptimeshift()
        """
        subprpid = xbmcgui.Window(10000).getProperty(ADDONname + 'subprpid')
        subprcmd = xbmcgui.Window(10000).getProperty(ADDONname + 'subprcmd')
        utils.logdev('runCommand','OldTimeShift subprpid= %r, subprcmd= %r' % (subprpid, subprcmd))
        if subprpid != '' and ADDON.getSetting('timeshiftbase') in subprcmd:
            utils.terminateSubpr(subprpid)
        try:
            xbmcgui.Window(10000).setProperty(ADDONname + 'subprpid', '')
            xbmcgui.Window(10000).setProperty(ADDONname + 'subprcmd', '')
        except Exception,e:
            pass
            utils.logdev('runCommand','Error reset \ncmd= %r\nError= %r' % (cmd,e))
        """
        
        RecordTimeShift(name, url, playpath, app, cat)  #### TimeShift record  ##########################
        
        try:
            timeshiftPID = xbmcgui.Window(10000).getProperty(ADDONname + 'subprpid')
            timeshiftCMD = xbmcgui.Window(10000).getProperty(ADDONname + 'subprcmd')
        except Exception,e:
            pass
            utils.logdev('runCommand','Error get \ncmd= %r\nError= %r' % (cmd,e))
            timeshiftPID = '*'
            timeshiftCMD = '*'
        
        utils.logdev('runCommand','0 timeshiftPID= %r, timeshiftCMD= %r' % (timeshiftPID, timeshiftCMD))
        recordPath = xbmc.translatePath(os.path.join(ADDON.getSetting('record_path')))
        timeshiftbase = ADDON.getSetting('timeshiftbase')
        timeshiftfileexpected = recordPath + timeshiftbase + '_' + datetime.today().strftime('%Y-%m-%d_%H-%M') + '.ts'
        
        count = 0
        timeshiftfile = ADDON.getSetting('timeshiftfile')
        while timeshiftfile == '' and count < 10:
            utils.logdev(module,'RecordTimeShift 2 #%r file= %r' % (count,timeshiftfile))
            xbmc.sleep(100)
            timeshiftfile = ADDON.getSetting('timeshiftfile')
            count += 1
        utils.logdev(module,'RecordTimeShift 3 #%r file= %r' % (count,timeshiftfile))
        
        try:
            timeshiftPID = xbmcgui.Window(10000).getProperty(ADDONname + 'subprpid')
            timeshiftCMD = xbmcgui.Window(10000).getProperty(ADDONname + 'subprcmd')
        except Exception,e:
            pass
            logdev('runCommand','Error get \ncmd= %r\npid= %r' % (cmd,e))
            timeshiftPID = '*'
            timeshiftCMD = '*'
        
        utils.logdev('runCommand','1 timeshiftPID= %r, timeshiftCMD= %r' % (timeshiftPID, timeshiftCMD))
        
        title = name
        playername = title
        channel = cat
        
        timeshiftfile = ADDON.getSetting('timeshiftfile')
        count = 0
        while timeshiftfile == '' and count < 10:
            utils.logdev(module,'RecordTimeShift 4 #%r file= %r' % (count,timeshiftfile))
            xbmc.sleep(100)
            count += 1
            timeshiftfile = ADDON.getSetting('timeshiftfile')
        utils.logdev(module,'RecordTimeShift 5 #%r file= %r' % (count,timeshiftfile))
        
        try:
            timeshiftPID = xbmcgui.Window(10000).getProperty(ADDONname + 'subprpid')
            timeshiftCMD = xbmcgui.Window(10000).getProperty(ADDONname + 'subprcmd')
        except Exception,e:
            pass
            logdev('runCommand','Error get \ncmd= %r\npid= %r' % (cmd,e))
            timeshiftPID = '*'
            timeshiftCMD = '*'
        
        utils.logdev('runCommand','2 timeshiftPID= %r, timeshiftCMD= %r' % (timeshiftPID, timeshiftCMD))
        
        count = 0
        timeshiftrunning = os.path.isfile(timeshiftfile)
        while timeshiftrunning == False and count < 10: 
            utils.logdev(module,'RecordTimeShift 6 #%r running= %r' % (count,timeshiftrunning))
            xbmc.sleep(100)
            count += 1
            timeshiftrunning = os.path.isfile(timeshiftfile)
        if count == 10:   ### Set default filename
            timeshiftfile = timeshiftfileexpected
            utils.logdev(module,'RecordTimeShift 7 #%r running= %r file= %r' % (count,timeshiftrunning,timeshiftfile))
        
        try:
            timeshiftPID = xbmcgui.Window(10000).getProperty(ADDONname + 'subprpid')
            timeshiftCMD = xbmcgui.Window(10000).getProperty(ADDONname + 'subprcmd')
        except Exception,e:
            pass
            logdev('runCommand','Error get \ncmd= %r\npid= %r' % (cmd,e))
            timeshiftPID = '*'
            timeshiftCMD = '*'
        
        utils.logdev('runCommand','3 timeshiftPID= %r, timeshiftCMD= %r' % (timeshiftPID, timeshiftCMD))
        
        utils.logdev(module,'RecordTimeShift 8 #%r running= %r file= %r' % (count,timeshiftrunning,timeshiftfile))   
        #liz=xbmcgui.ListItem(title, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz=xbmcgui.ListItem(playername)
        liz.setInfo( type="Video", infoLabels={ "Title": playername} )
        liz.setProperty("IsPlayable","true")
        ###utils.logdev(module,'timeshiftfile= %s' % (timeshiftfile))
        liz.setPath(timeshiftfile)
        ###utils.logdev(module,'RecordTimeShift 0++++ file= %s liz= %s' % (repr(timeshiftfile), repr(liz)))
        ##xbmc.sleep(5000) ## Shows only theese 5 sec?
        utils.logdev('runCommand','1 timeshiftPID= %r, timeshiftCMD= %r' % (timeshiftPID, timeshiftCMD))
        count = 0
        countmax = int(ADDON.getSetting('timeshiftbuffer'))
        while count < countmax: 
            xbmc.sleep(1000)
            count += 1
            utils.notification('Record TimeShift filling buffer: #%s %s (%s)' % (str(count),recordname,channel))
        ###playmedia(timeshiftfile)
        ###xbmc.executebuiltin("PlayMedia("+timeshiftfile+")")
        utils.logdev('runCommand','2 timeshiftPID= %r, timeshiftCMD= %r' % (timeshiftPID, timeshiftCMD))
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz) 
    
    
    if timeshiftsetting == '0':
        utils.logdev('default.py: PLAY_STREAM ',repr(recorddrdirectly))
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name} )
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz) 


"""
def PLAY_STREAM_NTV_TimeShift(name,url,iconimage,cat):
	#print 'default.py PLAY_STREAM(name,url,iconimage,cat) %s %s %s %s' % (repr(name), repr(url), repr(iconimage), repr(cat))
	recorddrdirectly=utils.directprograms(cat)  ### Get direct links
	dialog = xbmcgui.Dialog()
	playchannel = recordings.ChannelName(cat) + ' (' + cat + ')'
	# Play Direct if cat has Direct url and recording is active otherwise ask
	if not recorddrdirectly == '' and not locking.isAnyRecordLocked() and dialog.yesno(ADDON.getAddonInfo('name'), "Play Direct or NTV?", playchannel, "What Do You Want To Do","[COLOR red]NTV[/COLOR]","[COLOR green]Direct[/COLOR]"):
		# Play stream directly
		###utils.logdev('default.py: PLAY_STREAM Directly',repr(recorddrdirectly))
		liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
		liz.setInfo( type="Video", infoLabels={ "Title": name} )
		liz.setProperty("IsPlayable","true")
		liz.setPath(recorddrdirectly)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz) 
	else:	
		LastPlayedStreamname = ADDON.getSetting('LastPlayedStreamname')
		LastPlayedStreamurl = ADDON.getSetting('LastPlayedStreamurl')
		LastPlayedStreamiconimage = ADDON.getSetting('LastPlayedStreamiconimage')
		LastPlayedStreamcat = ADDON.getSetting('LastPlayedStreamcat')
		if cat != 0:
			ADDON.setSetting('LastPlayedStreamname', name)
			ADDON.setSetting('LastPlayedStreamurl', url)
			ADDON.setSetting('LastPlayedStreamiconimage', iconimage)
			ADDON.setSetting('LastPlayedStreamcat', cat)
			PlayDefaultStream = False
		else:
			name = LastPlayedStreamname
			url = LastPlayedStreamurl
			iconimage = LastPlayedStreamiconimage
			cat = LastPlayedStreamcat
			PlayDefaultStream = True
		#startD = recordings.parseDate(datetime.now())
		startD = recordings.parseDate(datetime.now())
		endD = startD
		###utils.logdev('default.py','PlayDefaultStream= %s' % repr(PlayDefaultStream))
		if PlayDefaultStream:
			recordingsActive = []
		else:
			recordingsActive = []
			recordingsActiveAll = recordings.getRecordingsActive(startD,endD)
			###utils.logdev('default.py','recordingsActiveAll= %s' % repr(recordingsActiveAll))
			for x in recordingsActiveAll:
				###utils.logdev('default.py','x= %s' % repr(x))
				if not '[COLOR orange]' in x:
					###utils.logdev('default.py','recordingsActive= %s' % repr(recordingsActive))
					recordingsActive.append(x)
					###utils.logdev('default.py','recordingsActive= %s' % repr(recordingsActive))
		if (recordingsActive != []) and locking.isAnyRecordLocked():
			utils.notification('OVERLAPPING Recordings NOT allowed: %s' % str(recordingsActive))
			#if (repr(recordingsActive) != "[]"):
			lockcause = repr(locking.RecordsLocked())
			#else:
			#	lockcause = repr(recordingsActive)
			dialog = xbmcgui.Dialog()
			if dialog.yesno(ADDON.getAddonInfo('name'), "[COLOR red]Stop recording?[/COLOR]", repr(recordingsActive), "What Do You Want To Do","[COLOR red]Stop recording[/COLOR]","[COLOR green]Ignore[/COLOR]"):
				return
		#print 'default.py: locking.recordUnlockAll()'
		locking.recordUnlockAll()
		# Test locking and unlock
		testX = 'TEST'
		locking.recordLock(testX)
		if locking.isRecordLocked(testX):
			locking.recordUnlock(testX)
		else:
			recordingLock = os.path.join(ADDON.getAddonInfo('path'),'rtmpdump', 'recordingLock') +  testX + '.txt'
			utils.notification('Record Locking fails at %s' % str(recordingLock))
		try:
			_name=name.split(' -')[0].replace('[/COLOR]','').replace('[COLOR yellow]','')
			playername=name.split('- ')[1].replace('[/COLOR]','').replace('[COLOR yellow]','')
		except:
			_name=name.replace('[/COLOR]','')
			playername=name.replace('[/COLOR]','')
		net.set_cookies(cookie_jar)
		url = '&mwAction=content&xbmc=1&mwData={"id":%s,"type":"tv"}'%cat
		link = net.http_GET(site+url, headers={'User-Agent' : UA}).content
		errorname = recordings.ChannelName(cat)
		if '"allown":false' in link:
			try:
				match=re.compile('"message":"(.+?)"').findall(link)
				dialog = xbmcgui.Dialog()
				dialog.ok(ADDON.getAddonInfo('name'), errorname + ' (' + cat +') ', match[0].replace('\/','/'))
			except:
				dialog = xbmcgui.Dialog()
				dialog.ok(ADDON.getAddonInfo('name'), errorname + ' (' + cat +') ', 'Please Sign Up To Watch The Streams')
		else:
			match=re.compile('"src":"(.+?)","type":"rtmp"').findall(link)
			if match:
				url=match[0].replace('\/','/')
				# NOT in 3.4.1 rtmp=match[0].replace('\/','/')
				# NOT in 3.4.1 playpath=rtmp.split('live/')[1]
				# NOT in 3.4.1 app='live?'+rtmp.split('?')[1]
				# NOT in 3.4.1 url='%s swfUrl=http://ntv.mx/inc/strobe/StrobeMediaPlayback.swf app=%s playPath=%s pageUrl=http://ntv.mx/?c=2&a=0&p=50 timeout=10'%(rtmp,app,playpath)
			else:
				match=re.compile('"src":"(.+?)","type":"hls"').findall(link)
				hls=match[0].replace('\/','/')
				url=hls
			timeshiftsetting = ADDON.getSetting('timeshift')
			if timeshiftsetting == '1':
				ask = xbmcgui.Dialog().yesno( ADDON.getAddonInfo('name'), name + '\n\nUse TimeShift?')
				#utils.notificationbox(repr(ask))
				if repr(ask) == '1':
					timeshiftsetting = '2'
				else:
					timeshiftsetting = '0'
			if timeshiftsetting == '2':
				###utils.logdev('default.py','RecordTimeShift(timeshift, url= %s, playpath= %s, app= %s)' % (url, playpath,app))
				timeshiftfile = ADDON.getSetting('timeshiftfile')
				timeshiftfileold = timeshiftfile.replace('.ts','OLD.ts')
				###utils.logdev('default.py','shutil.copyfile(timeshiftfile= %s,timeshiftfileold= %s)' % (timeshiftfile,timeshiftfileold))
				deleteFile(timeshiftfileold)
				try:
					shutil.copyfile(timeshiftfile,timeshiftfileold)  ###
					###utils.logdev('default.py','shutil.copyfile(timeshiftfile,timeshiftfileold) EXECUTED')
				except:
					pass
				if os.path.isfile(timeshiftfile) == True: 
					deleteFile(timeshiftfile)
					count = 0
					test = os.path.isfile(timeshiftfile)
					while not test == True and count < 10:
						time.sleep(1)
						count += 1
						test = os.path.isfile(timeshiftfile)
						###utils.logdev('default.py','RecordTimeShift test delete count= %s' % repr(count))
				RecordTimeShift(name, url, playpath, app, cat)  #### TimeShift record
			
				timeshiftfile = ADDON.getSetting('timeshiftfile')
				###utils.logdev(module,'RecordTimeShift 0+ file= %s' % repr(timeshiftfile))
			
				title = name
				playername = title
				channel = cat
			
				count = 0
				while timeshiftfile == '' and count < 100:
					###utils.logdev(module,'RecordTimeShift 0++ file= %s' % repr(timeshiftfile))
					xbmc.sleep(250)
					count += 1
					timeshiftfile = ADDON.getSetting('timeshiftfile')
					###utils.logdev(module,'RecordTimeShift count= %s' % repr(count))
					###utils.logdev(module,'RecordTimeShift 0+++ file= %s' % repr(timeshiftfile))
					#utils.notification('Record TimeShift Waiting for Agent: #%s %s (%s)' % (str(count),recordname,channel))
				###utils.logdev(module,'RecordTimeShift count= %s' % repr(count))
				count = 0
				timeshiftrunning = os.path.isfile(timeshiftfile)
				while timeshiftrunning == False and count < 100: 
					xbmc.sleep(250)
					count += 1
					timeshiftrunning = os.path.isfile(timeshiftfile)
					###utils.logdev(module,'RecordTimeShiftRunning count= %s - %s (%s)' % (repr(count),recordname,channel))
					#utils.notification('Record TimeShift Waiting for File: #%s %s (%s)' % (str(count),recordname,channel))
				###utils.logdev(module,'RecordTimeShiftRunning count= %s - %s (%s)' % (repr(count),recordname,channel))
				#liz=xbmcgui.ListItem(title, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
				liz=xbmcgui.ListItem(playername)
				liz.setInfo( type="Video", infoLabels={ "Title": playername} )
				liz.setProperty("IsPlayable","true")
				###utils.logdev(module,'timeshiftfile= %s' % (timeshiftfile))
				liz.setPath(timeshiftfile)
				###utils.logdev(module,'RecordTimeShift 0++++ file= %s liz= %s' % (repr(timeshiftfile), repr(liz)))
				##xbmc.sleep(5000) ## Shows only theese 5 sec?
				count = 0
				countmax = int(ADDON.getSetting('timeshiftbuffer'))
				while count < countmax: 
					xbmc.sleep(1000)
					count += 1
					utils.notification('Record TimeShift filling buffer: #%s %s (%s)' % (str(count),recordname,channel))
				###playmedia(timeshiftfile)
			
			
				##player = xbmc.Player()
				#for retry in range(0, 10):
				#	    if player.isPlaying():
				#	        break
				#	    utils.notification('Record TimeShift Waiting: #%s %s (%s)' % (str(retry),recordname,channel))
				#	    time.sleep( 1 )
				#	    #xbmc.sleep(250)
				#xbmc.sleep(5000)
				### int(sys.argv[1]) -- HANDLE
			
				xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
			
				#xbmc.executebuiltin("xbmc.PlayMedia("+timeshiftfile+")",True)
				##while (xbmc.Player().isPlayingVideo() == True) and (not xbmc.abortRequested):
				##	count += 1
				##	#utils.notification('Record TimeShift Running: #%s %s (%s)' % (str(count),recordname,channel))
				##	time.sleep( 1 )
				#utils.notification('Record TimeShift Ended: #%s %s (%s)' % (str(count),recordname,channel))
			
				###utils.logdev('default.py: PLAY_STREAM','RecordTimeShift')
				liz=xbmcgui.ListItem(playername, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
				liz.setInfo( type="Video", infoLabels={ "Title": playername} )
				liz.setProperty("IsPlayable","true")
				liz.setPath(timeshiftfile)
				xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)  ### TimeShift - show timeshift recording
				
				###utils.logdev('default.py','RecordTimeShift 0 file= %s' % repr(timeshiftfile))
				timeshiftfile = ADDON.getSetting('timeshiftfile')
				###utils.logdev('default.py','RecordTimeShift 0+ file= %s' % repr(timeshiftfile))
				count = 0
				while timeshiftfile == '' and count < 10:
					###utils.logdev('default.py','RecordTimeShift 0++ file= %s' % repr(timeshiftfile))
					time.sleep(1)
					count += 1
					timeshiftfile = ADDON.getSetting('timeshiftfile')
					###utils.logdev('default.py','RecordTimeShift count= %s' % repr(count))
					###utils.logdev('default.py','RecordTimeShift 0+++ file= %s' % repr(timeshiftfile))
				###utils.logdev('default.py','RecordTimeShift count= %s' % repr(count))
				liz=xbmcgui.ListItem(playername, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
				liz.setInfo( type="Video", infoLabels={ "Title": playername} )
				liz.setProperty("IsPlayable","true")
				###utils.logdev('default.py','timeshiftfile= %s' % (timeshiftfile))
				liz.setPath(timeshiftfile)
				###utils.logdev('default.py','RecordTimeShift 0++++ file= %s' % repr(timeshiftfile))
			
				##########################################################
				#item = xbmcgui.ListItem(path=timeshiftfile)
				datapath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
				playlist = os.path.join(datapath, 'TimeShift') + '.m3u'
			 	if os.path.isfile(playlist ) == False: 
					LF = open(playlist , 'a')
					LF.write('#EXTM3U \n')
					LF.write(timeshiftfile + '\n')
				else:
					LF = open(playlist , 'a')
					LF.write(timeshiftfile + '\n')
				#printL('Play Video')
				#xbmcplugin.setResolvedUrl(HANDLE, timeshiftfile is not None, item)
				xbmcplugin.setResolvedUrl(int(sys.argv[1]), timeshiftfile is not None, liz)
				
				if ADDON.getSetting('enable.subtitles') == 'true':
				    if video['SubtitlesUri']:
					player = xbmc.Player()
					for retry in range(0, 20):
					    if player.isPlaying():
						break
					    xbmc.sleep(250)
					xbmc.Player().setSubtitles(video['SubtitlesUri'])
				
				if os.path.isfile(timeshiftfile) == True: 
					###utils.logdev('default.py','RecordTimeShift 1')
					###xbmc.Player().play(timeshiftfile)
					xbmc.executebuiltin("PlayMedia("+timeshiftfile+")")
					###xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)  ### TimeShift - show timeshift recording
				else:
					###utils.logdev('default.py','RecordTimeShift 2-')
					time.sleep(1)
					###utils.logdev('default.py','RecordTimeShift 2')
					###xbmc.Player().play(timeshiftfile)
					xbmc.executebuiltin("PlayMedia("+timeshiftfile+")")
					###xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)  ### TimeShift - show timeshift recording
					#################################################################
				
			else:
				###utils.logdev('default.py: PLAY_STREAM','No RecordTimeShift')
				liz=xbmcgui.ListItem(playername, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
				liz.setInfo( type="Video", infoLabels={ "Title": playername} )
				liz.setProperty("IsPlayable","true")
				liz.setPath(url)
				xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)  ### TimeShift - show timeshift recording
"""

def stoptimeshift():
        subprpid = xbmcgui.Window(10000).getProperty(ADDONname + 'subprpid')
        subprcmd = xbmcgui.Window(10000).getProperty(ADDONname + 'subprcmd')
        utils.logdev(module,'OldTimeShift to stop and reset subprpid= %r, subprcmd= %r' % (subprpid, subprcmd))
        if subprpid != '' and ADDON.getSetting('timeshiftbase') in subprcmd:
            utils.terminateSubpr(subprpid)
        try:
            xbmcgui.Window(10000).setProperty(ADDONname + 'subprpid', '')
            xbmcgui.Window(10000).setProperty(ADDONname + 'subprcmd', '')
        except Exception,e:
            pass
            utils.logdev(module,'OldTimeShift to stop and reset - Error \ncmd= %r\nError= %r' % (subprcmd,e))
def exit():
        xbmc.executebuiltin("XBMC.Container.Update(path,replace)")
        xbmc.executebuiltin("XBMC.ActivateWindow(Home)")

def EXIT():
    recordings.backupSetupxml()
    if locking.isAnyRecordLocked():
        locking.recordUnlockAll()
    if locking.isAnyScanLocked():
        locking.scanUnlockAll()
    recordings.backupDataBase()
    ###recordings.stopAllRecordings()
        
def Record(recordname, uri, playpath,app):
    script   = os.path.join(ADDON.getAddonInfo('path'), 'recorduri.py')
    nameAlarm = ADDONid + '-Record-' + recordname
    try:
        if playpath == None:
            print 'No playpath'
        else:
            uri = uri + ' playpath=' + playpath
            print 'With playpath: uri= %s' % uri
    except:
        pass
    try:
        if app == None:
            print 'No app'
        else:
            uri = uri + ' app=' + app
            print 'With app: uri= %s' % uri
    except:
        pass
    cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),00:00:00,silent)' % (recordname.replace(',','####'), script, uri,recordname.replace(',','####'))
    print 'default.py: cmd= %s' % cmd
    xbmc.executebuiltin(cmd)  # Active
    
def Recordffmpeg(recordname, uri, playpath, app, description, auth):
    utils.logdev(module, 'Recordffmpeg(recordname= %r, uri= %r, playpath= %r, app= %r, description= %r, auth= %r)' % (recordname, uri, playpath, app, description, auth))
    script   = os.path.join(ADDON.getAddonInfo('path'), 'recorduriffmpeg.py') 
    ### Conversion at script!
    ### uri= sys.argv[1].replace('AAabBB',' ').replace('aAabBb','?').replace('BBabAA','=').replace('xXx',' ').replace('###',',').replace('AaAaA','=').replace('NlNlNl','\n')
    try:
        nameAlarm = ADDONid + '-Recordffmpeg-' + recordname.replace(',','####')
    except:
        pass
        nameAlarm = ADDONid+' Recordffmpeg-missing-name'
    try:
        if not auth == None:
            uri = uri + '?auth=' + auth
    except:
        pass
    """try:
        if aifp == None:
            print 'No aifp'
        else:
            uri = uri + '?aifp=' + aifp
            print 'With aifp= %s' % aifp
    except:
        pass
    try:
        if slist == None:
            print 'No slist'
        else:
            uri = uri + '&slist=' + slist
            print 'With slist= %s' % slist
    except:
        pass
    """
    try:
        if description != None and description != '':
            uri = uri + '&description=' + description ### 2017-07-01
    except:
        pass
    try:
        if playpath != None and playpath != '':
            uri = uri + ' playpath=' + playpath
    except:
        pass
    try:
        if app != None and app != '':
            uri = uri + ' app=' + app
    except:
        pass
    
    cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),00:00:00,silent)' % (nameAlarm, script, uri, recordname.replace(',',''))  ### 2017-08-05
    utils.logdev(module, 'cmd= %s' % cmd)
    xbmc.executebuiltin(cmd)  # Active
    
def RecordTimeShift(name, uri, playpath,app,cat):
    utils.logdev(module, 'RecordTimeShift(name= %r, uri= %r, playpath= %r, app= %r, cat= %r)' % (name, uri, playpath,app,cat))
    script   = os.path.join(ADDON.getAddonInfo('path'), 'recordtimeshift.py')
    nameAlarm = ADDONid + '-record-timeshift-' + name
    try:
        if not playpath == None:
            uri = uri + ' playpath=' + playpath
    except:
        pass
    try:
        if not app == None:
            uri = uri + ' app=' + app
    except:
        pass
    cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),00:00:00,silent)' % (nameAlarm, script, uri, name)
    utils.logdev(module, 'cmd= %s' % cmd)
    xbmc.executebuiltin(cmd)  # Active
    
    #script   = os.path.join(ADDON.getAddonInfo('path'), 'recordtimeshiftshow.py')
    #nameAlarm = 'record-timeshift-show' + name
    #
    #cmd = 'AlarmClock(%s,RunScript(%s,%s,%s,%s,%s,%s),00:00:00,silent)' % (nameAlarm, script, uri, nameAlarm, sys.argv[1],name,cat)
    #print 'default.py: cmd= %s' % cmd
    #utils.logdev(module, 'cmd= %s' % cmd)
    #xbmc.executebuiltin(cmd)  # Active
    
def scheduleRecording(cat, startDate, endDate, recordname, description):
    if cat != 0 and cat != '0' and cat != '' and cat != None:   
        recordings.add(cat, startDate, endDate, recordname, description)

def delRecording(cat, startDate, endDate, recordname):
    recordings.delRecordingPlanned(cat, startDate, endDate, recordname)
    
def modifyRecording(cat, startDate, endDate, recordname, description):
    recordings.modifyRecordingPlanned(cat, startDate, endDate, recordname, description)

def DOWNLOADS():
    GoHome('Recordings')
    path = recordDisplayPath

    ###infile = 'U:\\Videos\\'
    ###name = 'Local Video Archive'
    ###addDir('Recordings','url',6,'','','','All recorded items in ' + recordPath)
    ###addDir(name,'url',66,'',infile,'','Local Video Archive in ' + infile)
    ###liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage="DefaultFolder.png")
    ###liz.setInfo( type="Folder", infoLabels={ "Title": str(name), "Plot":"PLOT", "Category":"CATEGORY" } )
    ###liz.setProperty("IsPlayable","false")
    ###contextMenu = []
    ###liz.addContextMenuItems(contextMenu,replaceItems=True)
    ###xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url=infile,listitem = liz, isFolder = True)
    searchText = Search('Recording to search for')
    files =  glob.glob(os.path.join(path, '*'+searchText+'*'))
    #print 'DOWNLOADS: files= %s' % repr(files)
    files1 = sorted(files, reverse=False)
    for infile in files1:
        if os.path.isdir(infile):
            name = infile.replace(recordPath,'')
            liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage="DefaultFolder.png")
            ###addDir('Recordings','url',6,'','','','All recorded items in ' + recordPath)
            liz.setInfo( type="Folder", infoLabels={ "Title": str(name)})
            liz.setProperty("IsPlayable","false")
            contextMenu = []
            ###contextMenu.append(('[COLOR red][B]Grab from %s[/B][/COLOR]'% (activetvguide),'XBMC.Container.Update(%s?name=None&mode=3000&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
            contextMenu.append(('[COLOR yellow][B]Home[/B][/COLOR]','XBMC.Container.Update(%s?name=Home&mode=None&url=None&iconimage=None&cat=None)'% (sys.argv[0])))
            contextMenu.append(('[COLOR lightgreen][B]Search Channels/VOD[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=2008&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
            contextMenu.append(('[COLOR lightgreen][B]Search EPG Programs[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=2050&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
            contextMenu.append(('[COLOR lightgreen][B]Search Recorded[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=6&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
            contextMenu.append(('[COLOR red][B]Planned Recordings[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=3&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
            contextMenu.append(('[COLOR orange][B]Favourites[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=17&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
            contextMenu.append(('[COLOR orange][B]Refresh[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=2004&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
            if isTimeShiftActive():
                contextMenu.append(('[COLOR red][B]Stop Timeshift Recording[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=30&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
            contextMenu.append(('[COLOR red][B]Back to Kodi[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=29&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
            contextMenu.append(('[COLOR orange][B]Delete Folder (if empty)[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=103&url=%s)'% (sys.argv[0], infile)))
            liz.addContextMenuItems(contextMenu,replaceItems=True)
            xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url=infile,listitem = liz, isFolder = True)
        else:
            if not infile[-4:].lower()=='.zip' and not infile[-4:].lower()=='.txt' and not infile[-4:].lower()=='.srt' and not infile[-4:].lower()=='.ini' and not infile[-4:].lower()=='.nfo' and not infile[-4:].lower()=='.log':
                name = infile.replace(recordPath,'').replace('.flv','').replace('.mp4','').replace('.ts','')
                descfile = infile.replace('.flv','.txt').replace('.mp4','.txt').replace('.ts','txt')
                ###utils.logdev(module,'descfile= ' + repr(descfile))
                desc = ''
                if os.path.isfile(descfile):
                    descf = open(descfile,'r')
                    desc = descf.read()
                    descf.close()
                    try:
                        desc = desc.split('Description:')[1]
                    except: pass
                liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage="DefaultVideo.png")
                ###liz.setInfo( type="Video", infoLabels={ "Title": name,"Plot":description, "Category":description } )
                liz.setInfo( type="Video", infoLabels={ "Title": str(name), "Plot":desc, "Category":desc})
                liz.setProperty("IsPlayable","true")
                contextMenu = []
                ###contextMenu.append(('[COLOR red][B]Grab from %s[/B][/COLOR]'% (activetvguide),'XBMC.Container.Update(%s?name=None&mode=3000&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                contextMenu.append(('[COLOR yellow][B]Home[/B][/COLOR]','XBMC.Container.Update(%s?name=Home&mode=None&url=None&iconimage=None&cat=None)'% (sys.argv[0])))
                contextMenu.append(('[COLOR lightgreen][B]Search Channels/VOD[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=2008&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                contextMenu.append(('[COLOR lightgreen][B]Search EPG Programs[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=2050&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                contextMenu.append(('[COLOR lightgreen][B]Search Recorded[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=6&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                contextMenu.append(('[COLOR red][B]Planned Recordings[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=3&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                contextMenu.append(('[COLOR orange][B]Favourites[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=17&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
                contextMenu.append(('[COLOR orange][B]Refresh[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=2004&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
                if isTimeShiftActive():
                    contextMenu.append(('[COLOR red][B]Stop Timeshift Recording[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=30&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
                contextMenu.append(('[COLOR red][B]Back to Kodi[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=29&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
                contextMenu.append(('[COLOR orange][B]Delete[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=102&url=%s)'% (sys.argv[0], infile)))
                liz.addContextMenuItems(contextMenu,replaceItems=True)
                ###utils.logdev(module,'xbmcplugin.addDirectoryItem(handle = int(sys.argv[1])= %s, url=infile= %s,listitem = liz= %s, isFolder = False)' % (repr(int(sys.argv[1])),repr(infile),repr(liz)))
                xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url=infile,listitem = liz, isFolder = False)
    ###setView('movies', 'main-view')
    setView('movies', 'movies')

def DataBases():
    GoHome('Restore Planned Recordings')
    path = xbmc.translatePath(ADDON.getAddonInfo('profile'))
    files =  glob.glob(os.path.join(path, '*'))
    #print 'DOWNLOADS: files= %s' % repr(files)
    files1 = sorted(files, reverse=True)
    #print 'DOWNLOADS: files1= %s' % repr(files1)
    index = 0
    for infile in files1:
        if index < 50:
            index += 1
            try:
                #print infile
                #print infile[-3:]
                #print infile[-3:].lower()
                if infile[-3:].lower()=='.db':
                    name = infile.replace(path,'').replace('.db','')
                    ############################# How many records/recursive?
                    count = recordings.RecursiveRecordingsCount(infile)
                    user  = name.split('-')[1]
                    X = name.split('-')[0]
                    date  = X[:4]+'-'+X[4]+X[5]+'-'+X[6]+X[7]+' '+X[8]+X[9]+':'+X[10]+X[11]+':'+X[12]+X[13]
                    desc  = 'Date: ' + date + '\nUser: ' + user + '\n' +count.replace(' (P','Programs: ').replace('/R','\nRecursive programs: ').replace(')','')
                    ###liz=xbmcgui.ListItem(name + count, iconImage="DefaultFile.png", thumbnailImage="DefaultFile.png")
                    liz=xbmcgui.ListItem(date + ' ' + user + count, iconImage="DefaultFile.png", thumbnailImage="DefaultFile.png")
                    liz.setInfo( type="Video", infoLabels={ "Title": str(name), "Plot": desc})   ### TEST 2018-01-25
                    liz.setProperty("IsPlayable","false")
                    contextMenu = []
                    activeDB = recordings.RECORDS_DB.split('.')[0]
                    #print activeDB
                    if not name == activeDB: 
                        contextMenu.append(('[COLOR orange][B]Restore Backup[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=105&url=%s)'% (sys.argv[0], infile)))
                        contextMenu.append(('[COLOR orange][B]Restore Channels[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=113&url=%s)'% (sys.argv[0], infile)))
                        contextMenu.append(('[COLOR orange][B]Restore EPG[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=114&url=%s)'% (sys.argv[0], infile)))
                        contextMenu.append(('[COLOR orange][B]Restore Recursive Records[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=107&url=%s)'% (sys.argv[0], infile)))
                        contextMenu.append(('[COLOR orange][B]Delete[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=102&url=%s)'% (sys.argv[0], infile)))
                        liz.addContextMenuItems(contextMenu,replaceItems=True)
                        xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url=infile,listitem = liz, isFolder = False)
            except:
                pass
                #print 'Failed: %s' % repr(infile)
    setView('movies', 'main-view')

def SetupxmlFiles():
    GoHome('Past setting.xml')
    path = xbmc.translatePath(ADDON.getAddonInfo('profile'))
    files =  glob.glob(os.path.join(path, '*'))
    defaultfile = os.path.join(path, recordings.SETTINGSXML)
    #print 'DOWNLOADS: files= %s' % repr(files)
    files1 = sorted(files, reverse=True)
    #print 'DOWNLOADS: files1= %s' % repr(files1)
    activeDB = recordings.SETTINGSXML.split('.')[0]+ ' - ' + utils.username(defaultfile)
    index = 0
    for infile in files1:
        if index < 50:
            index += 1
            try:
                #print infile
                #print infile[-3:]
                #print infile[-3:].lower()
                if infile[-4:].lower()=='.xml':
                    mail = utils.username(infile)
                    folder = utils.folder(defaultfile)
                    if not mail == '':
                        name = infile.replace(path,'').replace('.xml','') + ' - ' + mail + ': ' + folder
                        liz=xbmcgui.ListItem(name, iconImage="DefaultFile.png", thumbnailImage="DefaultFile.png")
                        liz.setInfo( type="File", infoLabels={ "Title": str(name)})
                        liz.setProperty("IsPlayable","false")
                        contextMenu = []
                        ###if not name == activeDB and '@' in mail:
                        if not name == activeDB: 
                            contextMenu.append(('[COLOR orange][B]Restore settings.xml[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=106&url=%s)'% (sys.argv[0], infile)))
                            contextMenu.append(('[COLOR orange][B]Delete[/B][/COLOR]', 'XBMC.RunPlugin(%s?mode=102&url=%s)'% (sys.argv[0], infile)))
                            liz.addContextMenuItems(contextMenu,replaceItems=True)
                            xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url=infile,listitem = liz, isFolder = False)
            except:
                pass
                #print 'Failed: %s' % repr(infile)
    setView('movies', 'main-view')


def deleteFile(file):
    tries    = 0
    maxTries = 2
    while os.path.exists(file) and tries < maxTries:
        try:
            utils.logdev(module, 'removeFile: %s' % file ) # Put in LOG
            os.remove(file)
            break
        except:
            utils.logdev(module, 'Failed #= %d' % tries)  # Put in LOG
            xbmc.sleep(500)
            tries = tries + 1

def deleteDir(file):
    tries    = 0
    maxTries = 10
    while os.path.exists(file) and tries < maxTries:
        try:
            print 'removeDir: %s' % file  # Put in LOG
            os.rmdir(file)
            break
        except:
            print 'Failed #= %d' % tries  # Put in LOG
            xbmc.sleep(500)
            tries = tries + 1
            
def get_params():
        param=[]
        #print 'default.py get_params= %s' % repr(sys.argv)
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
"""
xbmcplugin.setContent(int(sys.argv[1]), 'movies')
xbmcplugin.setPluginCategory(int(sys.argv[1]), 'Comedy')
xbmcplugin.setPluginFanart(int(sys.argv[1]), 'special://home/addons/plugins/video/Apple movie trailers II/fanart.png', color2='0xFFFF3300')
xbmcplugin.setProperty(int(sys.argv[1]), 'Emulator', 'M.A.M.E.')
"""
def param(u,match):
    try:
        u = urllib.unquote_plus(u)
        x = u.split('&'+match+'=')[1].split('&')[0]
    except:
        pass
        try:
            x = u.split('?'+match+'=')[1].split('&')[0]
        except:
            pass
            x = ''
    return x

def isHighlighted(u):
    try:
        utils.logdev(module,'isHighlighted u= %r' % u)
        cat        = param(u,'cat')
        startDate  = param(u,'startDate')
        endDate    = param(u,'endDate')
        name       = '' ### param(u,'name')
        recordname = param(u,'name')
        
        ThisHighlight = '#cat=' + cat + '#startDate=' + startDate +'#endDate=' + endDate + '#name=' + name + '#recordname=' + recordname + '#'  
        utils.logdev(module,'HIGHLIGHT ThisHighlight= %r' % ThisHighlight)
        
        if ThisHighlight in highlightscmp:
            utils.logdev(module,'HIGHLIGHT set in URL u= %r' % u)
            return True
            """
            if not 'name=%5BCOLOR+red%5DHighLight%5B%2FCOLOR%5D' in u:
                u=u.replace('name=','name=%5BCOLOR+red%5DHighLight%5B%2FCOLOR%5D').replace('recordname=','recordname=%5BCOLOR+red%5DHighLight%5B%2FCOLOR%5D')
                utils.logdev(module,'HIGHLIGHT set in URL u= %r' % u)
            """
    except Exception,e:
        pass
        utils.logdev(module,'HIGHLIGHT failed u= %r, ERROR= %r' % (u,e))
    return False

def addDir(name,url,mode,iconimage='',cat='',date='',description='',startDate='',endDate='',recordname='',whatsup=''):
    ###def addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
    ###utils.logdev(module,'0 addDir(name= %s,url= %s,mode= %s,iconimage= %s,cat= %s,date= %s,description= %s)' % (name,url,mode,iconimage,cat,date,description))
    if cat == '' and not url == '':
        cat = recordings.catFromUrl(url)
    if not type(str(iconimage)) == str:
        iconimage = ''
    if not type(str(description)) == str:
        description = ''
    ###if not type(str(cat)) == str:
    ### cat = ''
    ###utils.logdev(module,'1 addDir(name= %s,url= %s,mode= %s,iconimage= %s,cat= %s,date= %s,description= %s)' % (name,url,mode,iconimage,cat,date,description))
    try:
        u=sys.argv[0]+"?url="+urllibquote_plus(url)+"&mode="+str(mode)+"&name="+urllibquote_plus(name)+"&iconimage="+urllibquote_plus(iconimage)+"&cat="+urllibquote_plus(cat)+"&date="+urllibquote_plus(str(date))+"&description="+urllibquote_plus(recordings.latin1_to_ascii(description))+"&startDate="+urllibquote_plus(str(startDate))+"&endDate="+urllibquote_plus(str(endDate))+"&recordname="+urllibquote_plus(recordings.latin1_to_ascii(recordname)) 
    except Exception, e:
        pass
        utils.logdev(module,'Error in setting u\n' + repr(e))
        u=str(sys.argv[0])+"?url="+str(urllibquote_plus(url))+"&mode="+str(mode)+"&name="+str(name)+"&iconimage="+str(iconimage)+"&cat="+str(cat)+"&date="+str(date)+"&description="+str(recordings.latin1_to_ascii(description))
    if startDate != '':
        u += "&startDate="+str(startDate)
    if endDate != '':
        u += "&endDate="+str(endDate)
    if whatsup != '':
        u += "&whatsup="+whatsup
    if isHighlighted(u):
        name = '[COLOR red][B]¤[/B][/COLOR]' + name + ' [COLOR red][B]SELECTED[/B][/COLOR]'
    ##### Dates added urllibquote_plus() Krogsbell 2016-03-11
    ###return addDirBasic(name,url,mode,iconimage,cat,date,description,startDate,endDate,recordname,u)
    ################ Suggested code to avoid: WARNING: CreateLoader - unsupported protocol(plugin) in plugin://plugin.video.wozboxntv/
    #url="http://www.sample-videos.com/video/mp4/480/big_buck_bunny_480p_10mb.mp4"

    #URI=url
    #item = xbmcgui.ListItem(title, thumbnailImage=image)

    #item.setInfo(type='video', infoLabels={'genre': 'genre', 'plot': 'desc' })
    #item.setProperty('IsPlayable', 'true')

    #xbmcplugin.addDirectoryItem(pluginhandle, URI, item, False)
    ################
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name,"Plot":description, "Category":description } )
    try: # Find the mode on entry = the actual view '3' = Palnned Recordings
        view= sys.argv[2].split('mode=',1)[1].split('&')[0]
        #print view
    except:
        pass
        view= '0'
    TVguide= utils.TVguide()
    activetvguide= ADDON.getSetting('activetvguide')
    menu=[]
    #if ADDON.getSetting('enable_record')=='true':
    #   menu.append(('[COLOR red][B]RECORD...[/B][/COLOR]','XBMC.RunPlugin(%s?mode=2001&url=url&cat=%s&startDate=%s&endDate=%s&recordname=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)))))
    ###if mode==200 or mode==12 or mode == 2020 or mode == 2001 or mode == 0:
    if mode==200 or mode==12 or mode == 2020 or mode == 2001:
        defaultdocmenu = True
    else:
        defaultdocmenu = False
    KodiVersion = int(xbmc.getInfoLabel('System.BuildVersion')[:2])
    ###utils.logdev(module,'xbmc.getInfoLabel(System.BuildVersion)[:2]= %r' % KodiVersion)
    if KodiVersion < 17:  ### 2017-08-02 
        ###utils.logdev(module,'Use menu scroll!')
        try:
            scroll = ADDON.getSetting('scroll')
            if scroll == '' or (scroll != 'top' and scroll != 'buttom'):
                scroll = 'top'
                ADDON.setSetting('scroll',scroll)
        except:
            pass
            scroll = 'top'
            ADDON.setSetting('scroll',scroll)
    else:
        scroll = 'noscroll'
    ###utils.notification('scroll= ' + repr(scroll))
    
    if scroll == 'buttom':
        menu.append(('[COLOR yellow][B]Top[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=50&url=None&iconimage=None&cat=%s)'% (sys.argv[0],scroll)))
    if ADDON.getSetting('tvguide')=='true' and defaultdocmenu:
        menu.append(('[COLOR yellow][B]TV Guide[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=4&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        if scroll == 'top' or scroll == 'noscroll' and defaultdocmenu:
            menu.append(('[COLOR yellow][B]Select TV Guide Channel[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=1004&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        utils.logdev(module,'len(higlights)= %r \nhiglights= %r' % (len(higlights),higlights))
        if scroll == 'top' or scroll == 'noscroll' and defaultdocmenu and highlightcount > 0 and(IPTVuser == 'test1' or krogsbell in IPTVuser): 
            menu.append(('[COLOR red][B]Deselect All (' + str(highlightcount) + ')[/B][/COLOR]','XBMC.RunPlugin(%s?mode=5001&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(name)),urllibquote_plus(recordings.latin1_to_ascii(description))))) 
        if scroll == 'top' or scroll == 'noscroll' and defaultdocmenu and (IPTVuser == 'test1' or krogsbell in IPTVuser): 
            menu.append(('[COLOR red][B]Select[/B][/COLOR]','XBMC.RunPlugin(%s?mode=5000&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(name)),urllibquote_plus(recordings.latin1_to_ascii(description))))) 
    if scroll == 'top' or scroll == 'noscroll':
        menu.append(('[COLOR red][B]Grab from %s[/B][/COLOR]'% (activetvguide),'XBMC.Container.Update(%s?name=None&mode=3000&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        menu.append(('[COLOR lightgreen][B]Search Channels/VOD[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=2008&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        menu.append(('[COLOR lightgreen][B]Search EPG Programs[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=2050&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        menu.append(('[COLOR lightgreen][B]Search Recorded[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=6&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    ###if scroll == 'buttom' or scroll == 'noscroll':
        ###menu.append(('[COLOR red][B]Force INI and Reschedule EPG[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=4000&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    if ADDON.getSetting('enable_record')=='true':
        if not name[0:9] =='Recursive':
            if scroll == 'top' or scroll == 'noscroll' and defaultdocmenu:
                menu.append(('[COLOR red][B]RECORD[/B][/COLOR]','XBMC.RunPlugin(%s?mode=2001&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(name)),urllibquote_plus(recordings.latin1_to_ascii(description))))) ###
                
            if scroll == 'top' or scroll == 'noscroll' and defaultdocmenu:
                menu.append(('[COLOR red][B]RECORD RECURSIVE[/B][/COLOR]','XBMC.RunPlugin(%s?mode=2005&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
        if view == '3':
            if scroll == 'top' or scroll == 'noscroll' and defaultdocmenu:
                menu.append(('[COLOR red][B]MODIFY RECORD[/B][/COLOR]','XBMC.RunPlugin(%s?mode=2003&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s)'% (sys.argv[0],urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)))))
            if scroll == 'top' or scroll == 'noscroll' and defaultdocmenu:
                menu.append(('[COLOR orange][B]DISABLE RECORD[/B][/COLOR]','XBMC.RunPlugin(%s?mode=2006&url=%s&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))  
            if scroll == 'top' or scroll == 'noscroll' and defaultdocmenu:
                menu.append(('[COLOR red][B]DELETE RECORD[/B][/COLOR]','XBMC.RunPlugin(%s?mode=2002&url=%s&cat=%s&startDate=%s&endDate=%s&name=%s&recordname=%s)'% (sys.argv[0],urllibquote_plus(url),urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(name)),urllibquote_plus(recordings.latin1_to_ascii(recordname)))))
        if not view == '3':
            if scroll == 'top' or scroll == 'noscroll':
                menu.append(('[COLOR red][B]Planned Recordings[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=3&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        if ADDON.getSetting('DebugRecording')=='true':
            if scroll == 'top' or scroll == 'noscroll':
                menu.append(('[COLOR green][B]Planned Recordings Debug[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=13&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        ###menu.append(('[COLOR green][B]Recorded[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=6&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    if ADDON.getSetting('LastView') == 'FAVORITES':
        if scroll == 'buttom' or scroll == 'noscroll' and defaultdocmenu:
            menu.append(('[COLOR orange][B]Remove '+ADDONname+' Favourite[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=77&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    else:
        if scroll == 'buttom' or scroll == 'noscroll' and defaultdocmenu:
            menu.append(('[COLOR orange][B]Set '+ADDONname+' Favourite[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=7&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
        ###if scroll == 'buttom' or scroll == 'noscroll':
        menu.append(('[COLOR orange][B]Favourites[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=17&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    if ADDON.getSetting('LastView') == 'RECURSIVECHANNELS':
        if scroll == 'buttom' or scroll == 'noscroll' and defaultdocmenu:
            menu.append(('[COLOR orange][B]Remove '+ADDONname+' Recursive Channel[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=28&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    else:
        if scroll == 'buttom' or scroll == 'noscroll' and defaultdocmenu:
            menu.append(('[COLOR orange][B]Set '+ADDONname+' Recursive Channel[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=27&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    if ADDON.getSetting('LastView') == 'HIDDENCHANNELS':
        if scroll == 'buttom' or scroll == 'noscroll' and defaultdocmenu:
            menu.append(('[COLOR orange][B]Remove '+ADDONname+' Hidden Channel[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=25&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    else:
        if scroll == 'buttom' or scroll == 'noscroll' and defaultdocmenu:
            menu.append(('[COLOR orange][B]Set '+ADDONname+' Hidden Channel[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=24&url=None&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
            
    #try:
    #   if name[0:9] =='Recursive' and not locking.isAnyRecordLocked():
    #       menu.append(('[COLOR orange][B]Refresh Recursive[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=2007&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
    #except:
    #   pass
    if ADDON.getSetting('enable_record')=='true':
        menu.append(('[COLOR orange][B]Restore from Database[/B][/COLOR]','XBMC.RunPlugin(%s?name=&mode=104&url=url&iconimage=None&cat=%s)'% (sys.argv[0],cat)))
    menu.append(('[COLOR orange][B]Refresh[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=2004&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
    if isTimeShiftActive():
        menu.append(('[COLOR red][B]Stop Timeshift Recording[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=30&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
    menu.append(('[COLOR red][B]Back to Kodi[/B][/COLOR]','XBMC.RunPlugin(%s?name=None&mode=29&url=None&iconimage=None&cat=%s&startDate=%s&endDate=%s&recordname=%s&description=%s)'% (sys.argv[0],urllibquote_plus(cat),startDate,endDate,urllibquote_plus(recordings.latin1_to_ascii(recordname)),urllibquote_plus(recordings.latin1_to_ascii(description)))))
    menu.append(('[COLOR yellow][B]Home[/B][/COLOR]','XBMC.Container.Update(%s?name=Home&mode=None&url=None&iconimage=None&cat=None)'% (sys.argv[0])))
    if scroll == 'top':
        menu.append(('[COLOR yellow][B]Buttom[/B][/COLOR]','XBMC.Container.Update(%s?name=None&mode=51&url=None&iconimage=None&cat=%s)'% (sys.argv[0],scroll)))
    if mode==200: ### NEW in 3.3.9
        liz.setProperty("IsPlayable","true")
    liz.addContextMenuItems(items=menu, replaceItems=True)
    if mode==200 or mode==12 or mode == 2020 or mode == 2001 or mode == 0:
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    else:
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def isTimeShiftActive():
    subprpid = xbmcgui.Window(10000).getProperty(ADDONname + 'subprpid')
    subprcmd = xbmcgui.Window(10000).getProperty(ADDONname + 'subprcmd')
    utils.logdev(module,'OldTimeShift to stop and reset subprpid= %r, subprcmd= %r' % (subprpid, subprcmd))
    if subprpid != '' and ADDON.getSetting('timeshiftbase') in subprcmd:
        return True
    else:
        return False
    
def addDirBasic(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='',u=''):
    u=sys.argv[0]+"?url="+str(url)+"&mode="+str(mode)+"&name="+str(name)+"&iconimage="+str(iconimage)+"&cat="+str(cat)+"&date="+str(date)+"&description="+str(description)+"&startDate="+str(startDate)+"&endDate="+str(endDate)+"&recordname="+str(recordname)
    
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name,"Plot":description, "Category":description } )
    try: # Find the mode on entry = the actual view '3' = Planned Recordings
        view= sys.argv[2].split('mode=',1)[1].split('&')[0]
        #print view
    except:
        pass
        view= '0'
    
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok


def addDir_STOP(name,url,iconimage,cat,date,description,startDate='',endDate='',recordname=''):
        u=sys.argv[0]+"?url="+urllibquote_plus(url)+"&name="+urllibquote_plus(name)+"&iconimage="+urllibquote_plus(iconimage)+"&cat="+urllibquote_plus(cat)+"&date="+str(date)+"&description="+urllibquote_plus(description)+"&startDate="+str(startDate)+"&endDate="+str(endDate)+"&recordname="+recordings.latin1_to_ascii(recordname)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name,"Premiered":date,"Plot":description} )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        
def SetUserAndPasswordNew():
    dialog = xbmcgui.Dialog()
    ##Dialog.radiolist(text, height=None, width=None, list_height=None, choices=[], **kwargs)
    ##choices – an iterable of (tag, item, status) tuples where status specifies the initial selected/unselected state of each entry; can be True or False, 1 or 0, "on" or "off" (True, 1 and "on" meaning selected), or any case variation of these two strings. No more than one entry should be set to True.
    choises = []
    selected = dialog.select(ADDON.getAddonInfo('name') + ' - Select a previous login:', choises ) ####################
    if selected == 'newmail':
        email=Search('Email')
    else:
        email = choises[selected]
    #email=Search('Email')
    ###utils.logdev(module,'email= %s' % repr(email))
    email = str(email)
    ###utils.logdev(module,'str(email)= %s' % repr(email))
    if not email == "":
        password=Search('Password')
        if not email == "" and not password == "":
            ADDON.setSetting('user',email)
            ADDON.setSetting('pass',password)
            AUTH()
            utils.notification('[COLOR green]Email and password updated[/COLOR]')
    MYACCOUNT()
    
def SetUserAndPassword():
    email=Search('Email')
    ###utils.logdev(module,'email= %s' % repr(email))
    email = str(email)
    ###utils.logdev(module,'str(email)= %s' % repr(email))
    if not email == "":
        password=Search('Password')
        if not email == "" and not password == "":
            ADDON.setSetting('user',email)
            ADDON.setSetting('pass',password)
            AUTH()
            utils.notification('[COLOR green]Email and password updated[/COLOR]')
            ### Delete all chanels
            recordings.delAllChannels()
            ### Start update of EPG
            recordings.EPGOnce()
    MYACCOUNT()

def views(name,cat,url,description):
    lastview = ADDON.getSetting('LastView')
    ###utils.logdev(module,'lastview= %r, name= %r, cat= %r' % (lastview, name, cat))
    if lastview == 'TVGUIDE':
        TVGUIDE(name,cat)
    elif lastview == 'CHANNELS': 
        CHANNELS(name,cat)
    
    elif lastview == 'STATUS':
        STATUS()
    
    elif lastview == 'MYACCOUNT':
        MYACCOUNT()

    elif lastview == 'DOWNLOADS':
        DOWNLOADS()
    
    elif lastview == 'CATEGORIES':
        CATEGORIES()

    elif lastview == 'RECORDINGSPLANNED':
        RecordingsPlanned()

    elif lastview == 'ntvCATEGORIES':
        ntvCATEGORIES()

    elif lastview == 'FAVORITES':
        FAVORITES()
    
    elif lastview == 'ARCHIVE':
        ARCHIVE()

    elif lastview == 'MYSELECTEDCHANNELS':
        MYSELECTEDCHANNELS()

    elif lastview == 'HIDDENCHANNELS':
        HIDDENCHANNELS()

    elif lastview == 'NEWCHANNELS':
        NEWCHANNELS()

    elif lastview == 'CHANNELSROQOLD':
        CHANNELSROQOLD(name,cat,url,description)

    elif lastview == 'CHANNELSROQ':
        CHANNELSROQ()
        
    elif lastview == 'CHANNELSSEARCH':
        CHANNELSSEARCH()
        
    elif lastview == 'PROGRAMSEARCH':
        PROGRAMSEARCH()
              
    elif lastview == 'RECURSIVECHANNELS':
        RECURSIVECHANNELS()
    
    elif lastview == 'SUBS':
        SUBS()
    ###xbmc.executebuiltin("Container.Refresh")

#below tells plugin about the views                
def setView(content, viewType):
        # set content type so library shows more views and info
        if content:
                xbmcplugin.setContent(int(sys.argv[1]), content)
        if ADDON.getSetting('auto-view') == 'true':#<<<----see here if auto-view is enabled(true) 
                xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )#<<<-----then get the view type

###recordings.ftvntvlist()  ### Debug
params=get_params()
###utils.logdev(module+'-params',repr(params))
###utils.logdevarray(module+'-params',params)
url=None
name=''
mode=None
iconimage=None
date=None
description=None
cat=None
startDate=None
endDate=None
record=None
uri=None
playpath=None
app=None
recordname=''
auth=None
###slist=None
###aifp=None
###utils.logdev('default.py params',repr(params))
"""try:
    aifp=urllib.unquote_plus(params["aifp"])  # URL
    ###utils.logdev('default.py aifp',aifp)
except:
    pass
try:
    slist=urllib.unquote_plus(params["slist"])  # URL
    ###utils.logdev('default.py slist',slist)
except:
    pass
"""
try:
    auth=urllib.unquote_plus(params["auth"])  # URL
    ###utils.logdev('default.py auth',auth)
except:
    pass    
try:
    url=urllib.unquote_plus(params["url"])  # URL
    ###utils.logdev('default.py url',url)
except:
    pass
try:
    #utils.logdev(module,'URI= %s' % repr(params["uri"]))
    uri=urllib.unquote_plus(params["uri"])  # URI
    ### Conversion at script!
    ###uri=uri.replace('###',',').replace('AaAaA','=')
    ###utils.logdev('default.py uri',uri)
except:
    pass
try:
    playpath=urllib.unquote_plus(params["playpath"])  # playpath
except:
    pass
try:
    app=urllib.unquote_plus(params["app"])  # app
except:
    pass
try:
    name=urllib.unquote_plus(params["name"])
    name = name.split('[/COLOR]')[1]
    ###utils.logdev('default.py name',repr(name))
except:
    pass
try:
    iconimage=urllib.unquote_plus(params["iconimage"])
except:
    pass
try:        
    mode=int(params["mode"])
except:
    pass
try:
    cat=urllib.unquote_plus(params["cat"])
except:
    pass
try:
    date=str(params["date"])
except:
    pass
try:
    description=(urllib.unquote_plus(params["description"])).replace('NlNlNl','\n')
    ###utils.logdev('default.py description',description)
except:
    pass
try:
    startDate=str(params["startDate"])
except:
    pass
try:
    endDate=str(params["endDate"])
except:
    pass
try:
    ###utils.logdev('default.py 00 recordname',recordname)
    recordname=urllib.unquote_plus(params["recordname"])
    ###utils.logdev('default.py 0 recordname',recordname)
    if recordname == '' and not name == '':
        recordname = name
    ###utils.logdev('default.py 1 recordname',recordname)
except:
    pass

utils.logdev(module, 'Just before commands: (cat= %r, mode= %r, url= %r, startDate= %r, endDate= %r, name= %r, recordname= %r, description= %r)' % (cat, mode, url, startDate, endDate, name, recordname, description))

#these are the modes which tells the plugin where to go
###if mode==None or url==None or len(url)<1:

if mode==6:
    ADDON.setSetting('LastView', 'DOWNLOADS')
    ADDON.setSetting('record_display_path',recordPath)
    DOWNLOADS()
    
elif mode==66:
    ADDON.setSetting('LastView', 'DOWNLOADS')
    ADDON.setSetting('record_display_path',cat)
    DOWNLOADS()
    
elif mode==1:  ### free
    utils.logdev(module,'mode 1 executed!')
    
elif mode==8:
    ADDON.setSetting('LastView', 'MYACCOUNT')
    MYACCOUNT()

elif mode==49:
    ADDON.setSetting('LastView', 'Maintenance')
    Maintenance()
    
elif mode==10:
    xbmcaddon.Addon(id=ADDONid).openSettings()
    setView('movies', 'main-view')
    utils.notificationsend('Open Setting Finished')

elif mode==9:
    ADDON.setSetting('LastView', 'SUBS')
    SUBS()

elif mode==11:
    ADDON.setSetting('LastView', 'STATUS')
    STATUS()

elif mode==12:
    STATUSsub(description)

elif mode==13:
    RecordingsPlannedDebug()

elif mode==14:
    SetUserAndPassword()
    
elif mode==15:
    SetupxmlFiles() 
    
elif mode==50:
    ### To Top  
    ADDON.setSetting('scroll','top')
    views(name,cat,url,description)
    
elif mode==51:
    ### Buttom      
    ADDON.setSetting('scroll','buttom')
    views(name,cat,url,description)
    
elif mode==102:
    try:    ### Delete information and subtitles if they are available
        fileext = '.' + url.split('.')[-1]
        try:
            deleteFile(url.replace(fileext,'.txt'))
        except:   pass  
        try:
            deleteFile(url.replace(fileext,'.srt'))
        except:   pass
        try:
            deleteFile(url.replace(fileext,'.en.srt'))
        except:   pass
        try:
            deleteFile(url.replace(fileext,'.da.srt'))
        except:   pass
        try:
            deleteFile(url.replace(fileext,'.nfo'))
        except:   pass
        try:
            deleteFile(url.replace(fileext,'.log'))
        except:   pass
    except:
        pass
    deleteFile(url)
    xbmc.executebuiltin("Container.Refresh")

elif mode==200:
    ###utils.logdev(module,'Mode=200: name= %s,recordname= %s,cat= %s,url= %s,description= %s'% (name,recordname,cat,url,description))
    PLAY_STREAM(name,url,iconimage,cat)
    
elif mode==210:
    #playcmd='plugin://plugin.video.wozboxntv/?url=url&mode=200&name=IPTV&iconimage=http://www.ntv.mx/res/content/tv/240.png&cat=%s'% cat
    # Show menuentry 
    menuname= 'Get IPTV from NTV - %s (%s)' % (name,cat)
    liz=xbmcgui.ListItem(menuname)
    xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url='',listitem = liz, isFolder = True) 
    playcmd='plugin://' + ADDON.getAddonInfo('id') + '/?url=url&mode=200&name=%s&cat=%s'% (name,cat)
    utils.logdev('PlayIPTV',playcmd)
    xbmc.executebuiltin('PlayMedia(' + playcmd + ')')

elif mode==2009:  # Record or play link from FTVguide or TV Guide
    if ADDON.getSetting('RecordFromTVguide')=='true':
        try:
            recordduration = int(ADDON.getSetting('RecordFromTVguideDurationMinutes'))
        except:
            pass
            recordduration = 120
        if recordduration < 10: recordduration = 120
        now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        startDate =  (datetime.today() + timedelta(minutes=1)).strftime('%Y-%m-%d %H:%M:%S')
        endDate = (datetime.today() + timedelta(minutes=recordduration)).strftime('%Y-%m-%d %H:%M:%S')
        print 'scheduleRecording(cat= %s, startDate= %s, endDate= %s, name= %s, url= %s)' % (cat, startDate, endDate, name, url)
        scheduleRecording(cat, startDate, endDate, name, url)
    else:
        PLAY_STREAM(name,url,iconimage,cat)
        
elif mode==2010:  # Record link from dr bonanza
    ###utils.logdev(module,'Record(name= %s, uri= %s,playpath= %s, app= %s)' % (name, uri, playpath, app))
    if ADDON.getSetting('RecordFromTVguide')=='true':
        Record(name, uri, playpath, app)
        
elif mode==2011:  # Record link from drnu/filmon
    if ADDON.getSetting('RecordFromTVguide')=='true':
        Recordffmpeg(name, uri, playpath, app, description, auth)
        
elif mode==2020: ### Watch Archive
    ###http://roq-tv.net:25461/streaming/timeshift.php?username=XXX&password=XXXX&stream=276&duration=120&start=2017-05-21:16-00
    ###duration = endDate - startDate  ### in minutes
    ###duration = '120'
    ###start    = startDate.strftime('%Y-%m-%d:%H-%M')
    ###url = 'http://roq-tv.net:25461/streaming/timeshift.php?username='+ADDON.getSetting('user')+'&password='+ADDON.getSetting('password')+'&stream='+cat+'&duration='+duration+'&start='+start
    ###utils.logdev(module,'2020 url= ' + url)
    ###utils.logdev(module,'2020 description= ' + description)
    ###playmedia(url)
    name = recordname.replace('[COLOR salmon]','').replace('[/COLOR]','')
    ###utils.logdev(module,'2020 (name= %r \nurl= %r \niconimage= %r \ncat= %r \ndescription= %r )' % (recordname,url,iconimage,cat,description))
    PLAY_CATCHUP(recordname,url,iconimage,cat,description)
    ###PLAY_STREAM(name,url,iconimage,cat)
    ###liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    ###liz.setInfo( type="Video", infoLabels={ "Title": name} )
    ###liz.setProperty("IsPlayable","true")
    ###liz.setPath(url)
    ###xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz) 
    
elif mode==2001:   ### Record
    if not ('Recursive' in recordname):
        ###utils.logdev(module,'record0 (name = %s, uri= %s, playpath= %s, cat= %s, startDate= %s, endDate= %s, recordname= %s, description= %s)' % (name, uri, playpath,cat,startDate, endDate, recordname, description))
        try:
            if recordname == '':
                if not name == '':
                    recordname = name  ###
                else:
                    recordname = 'recordname and name are empty' 
            ###utils.logdev(module,'record00 (name = %s, uri= %s, playpath= %s, cat= %s, startDate= %s, endDate= %s, recordname= %s, description= %s)' % (name, uri, playpath,cat,startDate, endDate, recordname, description))
            if '[COLOR lightgreen]' in recordname:
                if '[/COLOR]' in recordname:
                    recordname = recordname.split('[/COLOR]',1)[1]
            if '[COLOR salmon]' in recordname:
                recordname = recordname.split('[COLOR salmon]',1)[1]
            if '[COLOR yellow]' in recordname:
                recordname = recordname.split('[COLOR yellow]',1)[1]
            if '[COLOR cyan]' in recordname:
                recordname = recordname.split('[COLOR cyan]',1)[1]
        except:
            pass
            ###utils.logdev(module,'record01 (name = %s, uri= %s, playpath= %s, cat= %s, startDate= %s, endDate= %s, recordname= %s, description= %s)' % (name, uri, playpath,cat,startDate, endDate, recordname, description))
        try:
            if cat == '':
                cat = recordings.catFromUrl(url)  ###
            uri=url 
            ###utils.logdev(module,'record02 (name = %s, uri= %s, playpath= %s, cat= %s, startDate= %s, endDate= %s, recordname= %s, description= %s)' % (name, uri, playpath,cat,startDate, endDate, recordname, description))
        except:
            pass
            uri = recordings.urlFromCat(cat)  ### 
            ###utils.logdev(module,'record03 (name = %s, uri= %s, playpath= %s, cat= %s, startDate= %s, endDate= %s, recordname= %s, description= %s)' % (name, uri, playpath,cat,startDate, endDate, recordname, description))
        ###utils.logdev(module,'record1 (name = %s, uri= %s, playpath= %s, cat= %s, startDate= %s, endDate= %s, recordname= %s, description= %s)' % (name, uri, playpath,cat,startDate, endDate, recordname, description))
        ext = uri.split('.')[-1].lower()
        reclock = locking.isAnyRecordLocked()
        if ('/movie/' in uri or ext == 'mp4' or ext == 'mkv' or ext == 'avi' or ext == 'm4v') and not reclock:
            Recordffmpeg(recordname, uri, playpath, app, description.replace(' ','AAabBB').replace('?','aAabBb').replace('=','BBabAA').replace(',','###').replace('&','AaAaA').replace('\n','NlNlNl'), auth)
        elif ('/movie/' in uri or ext == 'mp4' or ext == 'mkv' or ext == 'avi' or ext == 'm4v') and reclock:
            utils.notification('Recording something already \nTry later')
        else:
            utils.notification('Schedule recording: cat= ' + cat+ ' \nTitle: '+recordname)  ### 2017-09-21
            scheduleRecording(cat, startDate, endDate, recordname, description.replace(' ','AAabBB').replace('?','aAabBb').replace('=','BBabAA').replace(',','###').replace('&','AaAaA'))   ###.replace('\n','NlNlNl'))
    ###xbmc.executebuiltin("Container.Refresh")
utils.logdev(module,'locking.isScanLocked(EPG_update)= %r' % locking.isScanLocked('EPG_update'))
if not locking.isScanLocked('EPG_update'):
    if mode==None or url==None:
        ###try:
            ADDON.setSetting('LastView', 'CATEGORIES')
            CATEGORIES()
        ###except Exception, e:
        ### pass
            ###utils.logdev(module,'Error in showing Categories: ' + repr(e))
        ### utils.notification('[COLOR red]Error in showing Categories[/COLOR] - [COLOR green]Check your internet connection![/COLOR]')

    elif mode==2:
        ###try:
            ###utils.logdev(module,'Mode=2: name= %s,recordname= %s,cat= %s,url= %s,description= %s'% (name,recordname,cat,url,description))
            ADDON.setSetting('LastView', 'CHANNELS')
            CHANNELS(name,cat)
        ###except Exception, e:
        ### pass
        ### utils.logdev(module,'Error in showing Channels: ' + repr(e))
        ### utils.notification('[COLOR red]Error in showing Channels[/COLOR] - [COLOR green]Check your internet connection![/COLOR]')

    elif mode==3:
        ADDON.setSetting('LastView', 'RECORDINGSPLANNED')
        RecordingsPlanned()

    elif mode==4:
        ADDON.setSetting('LastView', 'TVGUIDE')
        TVGUIDE(name,cat)

    elif mode==5:
        ADDON.setSetting('LastView', 'GENRE')
        GENRE(name,cat)

    elif mode==7:
        ###utils.logdev(module,'ADD_FAV cat= %r, \nurl= %r, \nuri= %r' % (cat, url, uri))
        if cat == '':
            cat=recordings.catFromUrl(url)
        ADD_FAV(cat)
        ###xbmc.executebuiltin("Container.Refresh")
    
    elif mode==77:
        if cat == '':
            cat=recordings.catFromUrl(url)
        DEL_FAV(cat)
        xbmc.executebuiltin("Container.Refresh")
    
    elif mode==16:
        ADDON.setSetting('LastView', 'ntvCATEGORIES')
        ntvCATEGORIES()

    elif mode==17:
        ADDON.setSetting('LastView', 'FAVORITES')
        FAVORITES()
    
    elif mode==18:
        ADDON.setSetting('LastView', 'ARCHIVE')
        ARCHIVE()

    elif mode==19:
        ADDON.setSetting('LastView', 'MYSELECTEDCHANNELS')
        MYSELECTEDCHANNELS()

    elif mode==20:
        ADDON.setSetting('LastView', 'HIDDENCHANNELS')
        HIDDENCHANNELS()

    elif mode==21:
        ADDON.setSetting('LastView', 'NEWCHANNELS')
        NEWCHANNELS()

    elif mode==22:
        ###try:
            ###utils.logdev(module,'Mode=22: name= %s,recordname= %s,cat= %s,url= %s,description= %s'% (name,recordname,cat,url,description))
            ADDON.setSetting('LastView', 'CHANNELSROQOLD')
            CHANNELSROQOLD(name,cat,url,description)
        ###except Exception, e:
        ### pass
        ### ###utils.logdev(module,'Error in showing Channels: ' + repr(e))
        ### utils.notification('[COLOR red]Error in showing Channels[/COLOR] - [COLOR green]Check your internet connection![/COLOR]')

    elif mode==23:
        ###try:
            ###utils.logdev(module,'Mode=2: name= %s,recordname= %s,cat= %s,url= %s,description= %s'% (name,recordname,cat,url,description))
            ADDON.setSetting('LastView', 'CHANNELSROQ')
            CHANNELSROQ()
        ###except Exception, e:
        ### pass
        ### utils.logdev(module,'Error in showing Channels: ' + repr(e))
        ### utils.notification('[COLOR red]Error in showing Channels[/COLOR] - [COLOR green]Check your internet connection![/COLOR]')
            
    elif mode==24:  ### Set Hidden
        if cat == '':
            cat=recordings.catFromUrl(url)
        ###utils.logdev(module,'elif mode==24:  ### Set Hidden cat= %r, url= %r' % (cat,url))
        SET_HIDE(cat)
        xbmc.executebuiltin("Container.Refresh")

    elif mode==25:  ### Remove Hidden
        ###utils.logdev(module,'elif mode==25:  ### Remove Hidden cat= %r, url= %r' % (cat,url))
        if cat == '':
            cat=recordings.catFromUrl(url)
        DEL_HIDE(cat)
        xbmc.executebuiltin("Container.Refresh")

    elif mode==26:  ### Recursive Search View
        ADDON.setSetting('LastView', 'RECURSIVECHANNELS')
        RECURSIVECHANNELS()

    elif mode==27:  ### Set Recursive
        if cat == '':
            cat=recordings.catFromUrl(url)
        SET_RECURSIVE(cat)
        xbmc.executebuiltin("Container.Refresh")

    elif mode==28:  ### Remove Recursive
        if cat == '':
            cat=recordings.catFromUrl(url)
        DEL_RECURSIVE(cat)
        xbmc.executebuiltin("Container.Refresh")
        
    elif mode==29:  ### EXIT - Back to Kodi
        stoptimeshift()
        exit()
    
    elif mode==30:  ### Stop Timeshift
        stoptimeshift()
    
    elif mode==103:
        deleteDir(url)
        xbmc.executebuiltin("Container.Refresh")
        
    elif mode==104:
        #recordPath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
        #ADDON.setSetting('record_display_path',recordPath)
        DataBases()
        #xbmc.executebuiltin("Container.Refresh")
        
    elif mode==105:
        #recordPath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
        #print 'restoreBackupFile(url)= %s' % (repr(url))
        recordings.restoreBackupDataBase(url)

    elif mode==106:
        #recordPath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
        #print 'restoreBackupFile(url)= %s' % (repr(url))
        recordings.restoreSetupXml(url)
    
    elif mode==107:
        #recordPath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
        #print 'restoreBackupFile(url)= %s' % (repr(url))
        recordings.restoreRecursiveRecordings(url)
    
    elif mode==108:
        recordings.delAllChannels()
        
    elif mode==109:
        recordings.delAllPlannedPrograms()
    
    elif mode==110:
        recordings.delNewEPGPrograms()
    
    elif mode==111:
        recordings.delOldEPGPrograms()
    
    elif mode==112:
        recordings.ftvntvlist()

    elif mode==113:  ### Restore Channels
        recordings.RestoreChannels(url)

    elif mode==114:  ### Restore EPG
        recordings.RestoreEPG(url)  

    elif mode==115:  ### Update EPG now
        recordings.EPGOnce() 

    elif mode==116:  ### Clear the Database. Stop all planned recordings, reset database and start a new EPG import
        dialog = xbmcgui.Dialog()
        if dialog.yesno(ADDON.getAddonInfo('name'), "[COLOR red]Delete database and start all over?[/COLOR]", '', "What Do You Want To Do","[COLOR red]Delete[/COLOR]","[COLOR green]Ignore[/COLOR]"):
            ### Ignore
            lockcause = 'ignore' ### Dummy command
        else:
            ### Stop recording and record new
            lockcause = 'change' ### Dummy command
            recordings.deleteDataBase()
            xbmc.sleep(1000)
            recordings.EPGOnce()
        
    elif mode==1004:   ### Select TV Guide Channel
        ###utils.logdev(module,'Mode=200: name= %s,recordname= %s,cat= %s,url= %s,description= %s'% (name,recordname,cat,url,description))
        SELECT_TV_GUIDE_CHANNEL(name,url,iconimage,cat)
    
    
    elif mode==2002:   ### delete record 2002
        ###utils.logdev('delete record 2002', '(cat= %r, startDate= %r, endDate= %r, name= %r, recordname= %r, description= %r)' % (cat, startDate, endDate, name, recordname, description))
        delRecording(cat, startDate, endDate, recordname)
        xbmc.executebuiltin("Container.Refresh")

    elif mode==2003:         ### modifyRecording 2003
        ###utils.logdev('modifyRecording 2003', '(cat= %r, startDate= %r, endDate= %r, name= %r, recordname= %r, description= %r)' % (cat, startDate, endDate, name, recordname, description))
        modifyRecording(cat, startDate, endDate, recordname, description)
        xbmc.executebuiltin("Container.Refresh")
        
    elif mode==2004:  ### Create ini and other startupfiles in debug mode with refresh
        if ADDON.getSetting('DebugRecording')=='true': 
            recordings.ftvntvlist()
        xbmc.executebuiltin("Container.Refresh")

    elif mode==2005:
        if not ('Recursive' in recordname):
            scheduleRecording(cat, startDate, endDate, 'Recursive:' + recordname, description)
        ###xbmc.executebuiltin("Container.Refresh")

    elif mode==2006:   ### DISABLE RECORD
        u = '#cat=' + cat + '#startDate=' + startDate +'#endDate=' + endDate + '#name=' + name + '#recordname=' + recordname + '#description=' + description + '#'
        if isHighlighted(u):
            for ux in higlights:
                catx        = param(u,'cat')
                startDatex  = param(u,'startDate')
                endDatex    = param(u,'endDate')
                namex       = param(u,'recordname')
                recordnamex = param(u,'name')
                descriptionx = param(u,'description')
                if not ('[COLOR orange]' in recordname):
                    delRecording(catx, startDatex, endDatex, recordnamex)
                    ###utils.logdev(module,'2006 scheduleRecording(cat= %r, startDate= %r, endDate= %r, * + recordname= %r, description= %r)' % (cat, startDate, endDate, '*' + recordname, description))
                    scheduleRecording(catx, startDatex, endDatex, '*' + recordnamex, descriptionx)
        else:
            if not ('[COLOR orange]' in recordname):
                delRecording(cat, startDate, endDate, recordname)
                ###utils.logdev(module,'2006 scheduleRecording(cat= %r, startDate= %r, endDate= %r, * + recordname= %r, description= %r)' % (cat, startDate, endDate, '*' + recordname, description))
                scheduleRecording(cat, startDate, endDate, '*' + recordname, description)
        xbmc.executebuiltin("Container.Refresh")
    elif mode==2007:
        import findrecursive
        if ('Recursive' in recordname):
            locking.scanUnlockAll()
            findrecursive.RecursiveRecordingsPlanned('NotAllFavorites')
        ###xbmc.executebuiltin("Container.Refresh")
     
    elif mode==2008:  ### Search Channel or Vod
        utils.logdev('Search Channel or Vod','Start')
        ADDON.setSetting('LastView', 'CHANNELSSEARCH')
        CHANNELSSEARCH()
        
    elif mode==2059:  ### Backup Database and files
        recordings.backupSetupxml()
        recordings.backupDataBase()
        utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] Backup Ended')
        
    elif mode==2050:  ### Search favorite programs
        utils.logdev('Search favorite programs','Start')
        ADDON.setSetting('LastView', 'PROGRAMSEARCH')
        PROGRAMSEARCH()
        
    elif mode==3000:  ### Grab from TV Guide
        findtvguidenotifications.findtvguidenotifications()
        utils.logdev('findtvguidenotifications.py','Ended')
        ###xbmc.executebuiltin("Container.Refresh")  ### Do not work here

    elif mode==4000:

        recordings.reschedule() ### Set EPG program start
        recordings.ftvntvlist() ### Force INI file
        recordings.delOldEPGPrograms()  ### 7 days old programs and 2 days old channels
        """ Force EPG Update
        locking.scanUnlock('EPG_update')
        nameAlarmEPGonce = ADDONname +'updateepgonce' 
        scriptEPG   = os.path.join(ADDON.getAddonInfo('path'), 'updateepg.py')
    
        cmdEPGonce = 'AlarmClock(%s,RunScript(%s,%s),00:00:00,silent)' % (nameAlarmEPGonce.encode('utf-8', 'replace'), scriptEPG.encode('utf-8', 'replace'), 'once')
        xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmEPGonce)
        xbmc.executebuiltin(cmdEPGonce)
        """
        ###recordings.ftvntvlist()
        ###recordings.getAllChannels()
        ###recordings.delOldEPGPrograms()
        
    elif mode==4500:
        codeDesc = 'lehekylg ='
        code = "aHR0cDovL21lb3d5YXBtZW93LmNvbQ=="
        utils.logdev('ROQTV Hosting CodeDesc','= %r, code= %r ' % (codeDesc, base64.b64decode(code)))
        dialog = xbmcgui.Dialog()
        dialog.ok('[COLOR white]ROQTV Hosting Code[/COLOR]',repr(codeDesc),repr(base64.b64decode(code)))
    
    elif mode==5000:   ### SELECT
        try:
            utils.logdev(module,'Select! activated on cat= %r, sys.argv[1]= %r ' % (cat,sys.argv[1]))
            utils.logdev(module,'10 higlights= %r' % higlights)
            ###ThisHighlight = '#cat=' + cat + '#startDate=' + startDate +'#endDate=' + endDate + '#name=' + name + '#recordname=' + recordname + '#'
            ThisHighlight = '#cat=' + cat + '#startDate=' + startDate +'#endDate=' + endDate + '#name=' + name + '#recordname=' + recordname + '#description=' + description + '#'
            ThisHighlight = ThisHighlight.replace(' [COLOR red][B]SELECTED[/B][/COLOR]','',1).replace('[COLOR red][B]¤[/B][/COLOR]','',1)
            RemoveHiglight = False
            if ThisHighlight in higlights:
                RemoveHiglight = True
            else:
                higlights.append(ThisHighlight)
            utils.logdev(module,'11 higlights= %r' % higlights)
            allhiglights = ''
            i = 0
            for x in higlights:
                i += 1
                utils.logdev(module,'12 i= %r, x= %r' % (i,x))
                if x == ThisHighlight and RemoveHiglight == True:
                    x = ''
                if allhiglights != '' and x != '':
                    allhiglights = x + '¤¤¤¤' + allhiglights
                elif x != '':
                    allhiglights = x
            ADDON.setSetting('higlights',allhiglights)
            utils.logdev(module,'13 allhiglights= %r' % allhiglights)
            """
            apikeyS = Search('apikey')
            apikey = xbmcplugin.getSetting(int(sys.argv[1]), id=apikeyS)
            xbmcgui.Dialog().ok( repr(apikeyS), repr(apikey))
            utils.logdev(module,'Select! before= %r, after= %r ' % (apikeyS,apikey))
            utils.logdev(module,'Select! liz= %r' % (liz))
            selected = liz.getSelectedItem().isSelected()
            liz.getSelectedItem().select(True)
            selected1 = liz.getSelectedItem().isSelected()
            utils.logdev(module,'Select! before= %r, after= %r ' % (selected,selected1))
            """
        except Exception,e:
            pass
            utils.logdev(module,'Select! activated on cat= %r, Exception= %r ' % (cat,e))
        xbmc.executebuiltin("Container.Refresh")
        """
        isSelected(...)
        isSelected() --Returns the listitem's selected status.
        example:
            - is = self.list.getSelectedItem().isSelected()
        
        select(...)
        select(selected)--Sets the listitem's selected status.
        selected : bool - True=selected/False=not selected
        example:
        - self.list.getSelectedItem().select(True)
        
        getSetting(...)
        getSetting(handle, id)--Returns the value of a setting as a string.
         
        handle : integer - handle the plugin was started with.
        id : string - id of the setting that the module needs to access.
         
        *Note, You can use the above as a keyword.
         
        example:
            - apikey = xbmcplugin.getSetting(int(sys.argv[1]), 'apikey')
        """
    elif mode==5001:   ### Deselect All
        try:
            ADDON.setSetting('higlights','')
            utils.logdev(module,'Deselect All! ')
            
        except Exception,e:
            pass
            utils.logdev(module,'Deselect all! activated on cat= %r, Exception= %r ' % (cat,e))
        xbmc.executebuiltin("Container.Refresh")
else:
    message = '[COLOR red]Wait - updating EPG![/COLOR]'
    utils.notification(message)
    findtvguidenotifications.findtvguidenotificationsend(message)
    xbmc.sleep(1000)

xbmcplugin.endOfDirectory(int(sys.argv[1]))

"""
import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,datetime,os,json,base64,plugintools,xbmc,news,pytz
from datetime import datetime as dtdeep
from dateutil.tz import tzlocal
import GoDev
import common,xbmcvfs,zipfile,downloader,extract
import xml.etree.ElementTree as ElementTree
import unicodedata
import time
import string
reload(sys)
dialog       =  xbmcgui.Dialog()
sys.setdefaultencoding('utf8')
SKIN_VIEW_FOR_MOVIES="515"
addonDir = plugintools.get_runtime_path()
global kontroll
global EPGColour
addon_id = "plugin.video.roqhosting"
background = "YmFja2dyb3VuZC5wbmc=" 
defaultlogo = "ZGVmYXVsdGxvZ28ucG5n" 
hometheater = "aG9tZXRoZWF0ZXIuanBn"
noposter = "bm9wb3N0ZXIuanBn"
theater = "dGhlYXRlci5qcGc="
addonxml = "YWRkb24ueG1s"
addonpy = "ZGVmYXVsdC5weQ=="
icon = "aWNvbi5wbmc="
fanart = "ZmFuYXJ0LmpwZw=="
supplier = "TGl2ZSBUVg=="
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png')) 
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'fanart.jpg')) 
APKS = base64.b64decode("aHR0cDovL2ZhYmlwdHYuY29tL2Fwa3MvbmV3YXBrcy50eHQ=")
HOME =  xbmc.translatePath('special://home/')
lehekylg= base64.b64decode("aHR0cDovL21lb3d5YXBtZW93LmNvbQ==")
pordinumber="8080"
message = "VU5BVVRIT1JJWkVEIEVESVQgT0YgQURET04h"
kasutajanimi=plugintools.get_setting("Username")
salasona=plugintools.get_setting("Password")
F1ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'F1.png'))
BASEURL = base64.b64decode("bmFkYQ==")
LOAD_LIVEchan = os.path.join( plugintools.get_runtime_path() , "resources" , "art/arch" )
loginurl   = base64.b64decode("JXM6JXMvZ2V0LnBocD91c2VybmFtZT0lcyZwYXNzd29yZD0lcyZ0eXBlPW0zdV9wbHVzJm91dHB1dD10cw==")%(lehekylg,pordinumber,kasutajanimi,salasona)

def run():
    global pnimi
    global televisioonilink
    global LiveCats
    global PlayerAPI
    global filmilink
    global andmelink
    global uuenduslink
    global lehekylg
    global LOAD_LIVE
    global uuendused
    global vanemalukk
    global version
    version = int(get_live("MQ=="))
    kasutajanimi=plugintools.get_setting("Username")
    salasona=plugintools.get_setting("Password")
    if not kasutajanimi:
        kasutajanimi = "NONE"
        salasona="NONE"
    
    uuendused=plugintools.get_setting(sync_data("dXVlbmR1c2Vk"))
    vanemalukk=plugintools.get_setting(sync_data("dmFuZW1hbHVraw=="))
    pnimi = get_live("T25lIFZpZXcg")
    LOAD_LIVE = os.path.join( plugintools.get_runtime_path() , "resources" , "art" )
    plugintools.log(pnimi+get_live("U3RhcnRpbmcgdXA="))
    televisioonilink = get_live("JXM6JXMvZW5pZ21hMi5waHA/dXNlcm5hbWU9JXMmcGFzc3dvcmQ9JXMmdHlwZT1nZXRfbGl2ZV9jYXRlZ29yaWVz")%(lehekylg,pordinumber,kasutajanimi,salasona)
    LiveCats = get_live("JXM6JXMvcGxheWVyX2FwaS5waHA/dXNlcm5hbWU9JXMmcGFzc3dvcmQ9JXMmYWN0aW9uPWdldF9saXZlX2NhdGVnb3JpZXM=")%(lehekylg,pordinumber,kasutajanimi,salasona)
    PlayerAPI = get_live("JXM6JXMvcGxheWVyX2FwaS5waHA/dXNlcm5hbWU9JXMmcGFzc3dvcmQ9JXM=")%(lehekylg,pordinumber,kasutajanimi,salasona)
    filmilink = vod_channels("JXM6JXMvZW5pZ21hMi5waHA/dXNlcm5hbWU9JXMmcGFzc3dvcmQ9JXMmdHlwZT1nZXRfdm9kX2NhdGVnb3JpZXM=")%(lehekylg,pordinumber,kasutajanimi,salasona)
    andmelink = vod_channels("JXM6JXMvcGFuZWxfYXBpLnBocD91c2VybmFtZT0lcyZwYXNzd29yZD0lcw==")%(lehekylg,pordinumber,kasutajanimi,salasona)
    params = plugintools.get_params()

    if params.get("action") is None:
        peamenyy(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    plugintools.close_item_list()

def peamenyy(params):
    plugintools.log(pnimi+vod_channels("TWFpbiBNZW51")+repr(params))
    load_channels()
    if not lehekylg:
        plugintools.open_settings_dialog()

    channels = kontroll()
    if channels == 1 and GoDev.mode != 5 and GoDev.mode != 1:
        plugintools.log(pnimi+vod_channels("TG9naW4gU3VjY2Vzcw=="))
        plugintools.add_item( action=vod_channels("c2VjdXJpdHlfY2hlY2s="),  title=vod_channels(supplier) , thumbnail=os.path.join(LOAD_LIVE,vod_channels("bGl2ZXR2LnBuZw==")) , fanart=os.path.join(LOAD_LIVE,vod_channels("YmFja2dyb3VuZC5wbmc=")) ,  folder=True )
    elif channels != 1 and GoDev.mode != 1:
        plugintools.add_item( action=vod_channels("bGljZW5zZV9jaGVjaw=="), title="Step 1. Insert Login Credentials" , thumbnail=os.path.join(LOAD_LIVE,vod_channels("aWNvbi5wbmc=")), fanart=os.path.join(LOAD_LIVE,vod_channels("YmFja2dyb3VuZC5wbmc=")), folder=False )	
        plugintools.add_item( action=vod_channels("bGljZW5zZV9jaGVjazI="), title="Step 2. Click Once Login Is Input" , thumbnail=os.path.join(LOAD_LIVE,vod_channels("aWNvbi5wbmc=")), fanart=os.path.join(LOAD_LIVE,vod_channels("YmFja2dyb3VuZC5wbmc=")), folder=False )	

def SPORT_LISTINGS(params):

    url = base64.b64decode(b'aHR0cDovL3d3dy53aGVyZXN0aGVtYXRjaC5jb20vdHYvaG9tZS5hc3A=')
    r = common.OPEN_URL_NORMAL(url).replace('\r','').replace('\n','').replace('\t','')
    match = re.compile('href="http://www.wheresthematch.com/fixtures/(.+?).asp.+?class="">(.+?)</em> <em class="">v</em> <em class="">(.+?)</em>.+?time-channel ">(.+?)</span>').findall(r)
    for game,team1,team2,gametime in match:
        a,b = gametime.split(" on ")
        plugintools.add_item (action="",  title='[COLOR white]'+team1+' vs '+team2+' - '+a+' [/COLOR]' , thumbnail=os.path.join(LOAD_LIVE,vod_channels("aWNvbi5wbmc=")) , fanart=os.path.join(LOAD_LIVE,vod_channels("YmFja2dyb3VuZC5wbmc=")) ,  folder=False )
        plugintools.add_item (action="",  title='[COLOR yellowgreen][B]Watch on '+b+'[/B][/COLOR]' , thumbnail=os.path.join(LOAD_LIVE,vod_channels("aWNvbi5wbmc=")) , fanart=os.path.join(LOAD_LIVE,vod_channels("YmFja2dyb3VuZC5wbmc=")) ,  folder=False )
        plugintools.add_item (action="",  title='------------------------------------------' , thumbnail=os.path.join(LOAD_LIVE,vod_channels("aWNvbi5wbmc=")) , fanart=os.path.join(LOAD_LIVE,vod_channels("YmFja2dyb3VuZC5wbmc=")) ,  folder=False )

def LATESTAPKS(params):
    link = common.OPEN_XML(APKS).replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?ersion="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        GoDev.addXMLMenu('[COLOR white]' + name +'[/COLOR] [COLOR white]- version: [/COLOR]' + '[COLOR white]'+description+'[/COLOR]',url,15,iconimage,fanart,description)

def Listings(params):
    plugintools.add_item( action=vod_channels("U1BPUlRfTElTVElOR1M="),   title="UK Sport Listings" , thumbnail=os.path.join(LOAD_LIVE,vod_channels("aWNvbi5wbmc=")), fanart=os.path.join(LOAD_LIVE,vod_channels("YmFja2dyb3VuZC5wbmc=")) ,  folder=True )
    plugintools.add_item( action=vod_channels("R29EZXYuU3BvcnRDaG9pY2U="),   title="All Sport Listings" , thumbnail=os.path.join(LOAD_LIVE,vod_channels("aWNvbi5wbmc=")), fanart=os.path.join(LOAD_LIVE,vod_channels("YmFja2dyb3VuZC5wbmc=")) ,  folder=True )

def Tools(params):
    plugintools.add_item( action=vod_channels("ZXhlY3V0ZV9haW5mbw=="),   title="Account Information", thumbnail=os.path.join(LOAD_LIVE,vod_channels("bXlhY2MucG5n")), fanart=os.path.join(LOAD_LIVE,vod_channels("YmFja2dyb3VuZC5wbmc=")) ,  folder=True )
    plugintools.addItem('Run Speedtest','speed',9,GoDev.Images + 'speed.png',GoDev.Images + 'background.png')
    plugintools.add_item( action=vod_channels("R29EZXYuREN0ZXN0"),   title="Datacentre Speedtest" , thumbnail=GoDev.Images + 'speed.png', fanart=os.path.join(LOAD_LIVE,vod_channels("YmFja2dyb3VuZC5wbmc=")) ,  folder=True )
    plugintools.add_item( action=vod_channels("TEFURVNUQVBLUw=="),   title="App Downloads" , thumbnail=os.path.join(LOAD_LIVE,vod_channels("aWNvbi5wbmc=")), fanart=os.path.join(LOAD_LIVE,vod_channels("YmFja2dyb3VuZC5wbmc=")) ,  folder=True )
    plugintools.add_item( action=vod_channels("bGljZW5zZV9jaGVjaw=="), title="Addon Settings" , thumbnail=os.path.join(LOAD_LIVE,vod_channels("aWNvbi5wbmc=")), fanart=os.path.join(LOAD_LIVE,vod_channels("YmFja2dyb3VuZC5wbmc=")) ,  folder=False )
    plugintools.add_item( action=vod_channels("U2hvd05ld3M="), title="View Latest News Mesage" , thumbnail=os.path.join(LOAD_LIVE,vod_channels("aWNvbi5wbmc=")), fanart=os.path.join(LOAD_LIVE,vod_channels("YmFja2dyb3VuZC5wbmc=")) ,  folder=False )

def ShowNews(params):
    TypeOfMessage="t"; (NewImage,NewMessage)=news.FetchNews(); 
    news.CheckNews(TypeOfMessage,NewImage,NewMessage,False); 

def TheDev(params):
    tvaAPI = base64.b64decode("JXM6JXMvcGFuZWxfYXBpLnBocD91c2VybmFtZT0lcyZwYXNzd29yZD0lcw==")%(lehekylg,pordinumber,kasutajanimi,salasona)
    link=open_url(tvaAPI)
    archivecheck = re.compile('"num":.+?,"name":"(.+?)".+?"stream_id":"(.+?)","stream_icon":"(.+?)".+?"tv_archive":(.+?).+?"tv_archive_duration":(.+?)}').findall(link)
    for kanalinimi,streamid,streamicon,tvarchive,archdays in archivecheck:
        if tvarchive == '1':
            streamicon = streamicon.replace('\/','/')
            archdays = archdays.replace('"','')
            plugintools.add_item( action=sync_data("dHZhcmNoaXZl"), title='[COLOR white]'+kanalinimi+'[/COLOR]' , thumbnail=streamicon, extra=streamid, page=archdays, fanart=os.path.join(LOAD_LIVE,sync_data("aG9tZXRoZWF0ZXIuanBn")), isPlayable=False, folder=True )
            plugintools.set_view( plugintools.LIST )

def tvarchive(params):
    plugintools.set_view( plugintools.EPISODES )
    fmt = "%Y%m%d%H%M%S"
    date3 = dtdeep.now() - datetime.timedelta(int(params.get("page")))
    AweekAgo = date3.strftime(fmt)
    APIv2 = base64.b64decode("JXM6JXMvcGxheWVyX2FwaS5waHA/dXNlcm5hbWU9JXMmcGFzc3dvcmQ9JXMmYWN0aW9uPWdldF9zaW1wbGVfZGF0YV90YWJsZSZzdHJlYW1faWQ9JXM=")%(lehekylg,pordinumber,kasutajanimi,salasona,params.get("extra"))
    data = json.load(urllib2.urlopen(APIv2))
    for x in data['epg_listings']:
        Title = x['title']
        Description = x['description']
        ChanID = x['channel_id']
        ShowTitle = base64.b64decode(Title)
        DesC = base64.b64decode(Description)
        start = x['start']
        end = x['end']
        format = '%Y-%m-%d %H:%M:%S'
        try:
            modend = dtdeep.strptime(end, format)
            modstart = dtdeep.strptime(start, format)
            modstart2 = dtdeep.strptime(start, format)
        except:
            modend = dtdeep(*(time.strptime(end, format)[0:6]))
            modstart = dtdeep(*(time.strptime(start, format)[0:6]))
        modend_ts = time.mktime(modend.timetuple())
        modstart_ts = time.mktime(modstart.timetuple())
        Duration=plugintools.get_setting("FinalDuration")
        if not Duration == 'Off':
            FinalDuration = Duration
        else:
            FinalDuration = int(modend_ts-modstart_ts) / 60
        try:
            ShowStart = dtdeep.strptime(start, '%Y-%m-%d %H:%M:%S').strftime("%Y%m%d%H%M%S")
        except:
            ShowStart = dtdeep(*(time.strptime(start, '%Y-%m-%d %H:%M:%S')[0:6])).strftime("%Y%m%d%H%M%S")
        TimeNow = pytz.timezone('UTC').localize(dtdeep.now()).astimezone(pytz.timezone('Europe/London'))
        TimeNow = TimeNow.replace(tzinfo=tzlocal())
        TimeNow = TimeNow.astimezone(pytz.timezone('Europe/London'))
        if 'USA/CA' in ChanID:
            modstart = pytz.timezone('UTC').localize(modstart).astimezone(pytz.timezone('Europe/London'))
            modstart = modstart.astimezone(pytz.timezone('America/New_York'))
        AweekAgo = (TimeNow - datetime.timedelta(int(params.get("page")))).strftime(fmt)
        try:
            Finalstart = dtdeep.strptime(start, '%Y-%m-%d %H:%M:%S').strftime("%Y-%m-%d:%H-%M")
        except:
            Finalstart = dtdeep(*(time.strptime(start, '%Y-%m-%d %H:%M:%S')[0:6])).strftime("%Y-%m-%d:%H-%M")
        Prefix = modstart.strftime("%a %d %H:%M")
        if ShowStart > AweekAgo:
            if ShowStart < TimeNow.strftime(fmt):
                catchupURL = base64.b64decode("JXM6JXMvc3RyZWFtaW5nL3RpbWVzaGlmdC5waHA/dXNlcm5hbWU9JXMmcGFzc3dvcmQ9JXMmc3RyZWFtPSVzJnN0YXJ0PQ==")%(lehekylg,pordinumber,kasutajanimi,salasona,params.get("extra"))
                ResultURL = catchupURL + str(Finalstart) + "&duration=%s"%(FinalDuration)
                kanalinimi = str('[COLOR white]'+Prefix+'[/COLOR]')+ " - " + '[COLOR gold]'+ShowTitle+'[/COLOR]'
                plugintools.add_item( action=sync_data("cnVuX2Nyb25qb2I="), title=kanalinimi , url=ResultURL, thumbnail=params.get("thumbnail") , plot=DesC, fanart=os.path.join(LOAD_LIVE,sync_data("aG9tZXRoZWF0ZXIuanBn")) , extra="", isPlayable=True, folder=False )

def license_check(params):
    plugintools.log(pnimi+get_live("U2V0dGluZ3MgbWVudQ==")+repr(params))
    plugintools.open_settings_dialog()

def license_check2(params):
    d = urllib.urlopen(loginurl)
    FileInfo = d.info()['Content-Type']
    if not 'application/octet-stream' in FileInfo:
        dialog.ok('[COLOR white]Invalid Login[/COLOR]','[COLOR white]Incorrect login details found![/COLOR]','[COLOR white]Please check your spelling and case sensitivity[/COLOR]','[COLOR white]Check your password with the team otherwise[/COLOR]')
        plugintools.open_settings_dialog()
    else:
        xbmc.executebuiltin('Container.Refresh')

def get_size(start_path):
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(start_path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            total_size += os.path.getsize(fp)
    return total_size

def convertSize(size):
   import math
   if (size == 0):
       return '[COLOR lime]0 MB[/COLOR]'
   size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
   i = int(math.floor(math.log(size,1024)))
   p = math.pow(1024,i)
   s = round(size/p,2)
   if size_name == "B" or "KB":
        return '[COLOR lime]%s %s' % (s,size_name[i]) + '[/COLOR]'
   if size_name == "GB" or "TB" or "PB" or "EB" or "ZB" or "YB":
        return '[COLOR red]%s %s' % (s,size_name[i]) + '[/COLOR]'
   if s >= 100:
        return '[COLOR red]%s %s' % (s,size_name[i]) + '[/COLOR]'
   if s < 50:
        return '[COLOR lime]%s %s' % (s,size_name[i]) + '[/COLOR]'
   if s >= 50:
        if i < 100:
            return '[COLOR orange]%s %s' % (s,size_name[i]) + '[/COLOR]'

def maintMenu(params):

    CACHE      =  xbmc.translatePath(os.path.join('special://home/cache',''))
    PACKAGES   =  xbmc.translatePath(os.path.join('special://home/addons','packages'))
    THUMBS     =  xbmc.translatePath(os.path.join('special://home/userdata','Thumbnails'))

    if not os.path.exists(CACHE):
        CACHE     =  xbmc.translatePath(os.path.join('special://home/temp',''))
    if not os.path.exists(PACKAGES):
        os.makedirs(PACKAGES)

    CACHE_SIZE_BYTE    = get_size(CACHE)
    PACKAGES_SIZE_BYTE = get_size(PACKAGES)
    THUMB_SIZE_BYTE    = get_size(THUMBS)
    
    CACHE_SIZE    = convertSize(CACHE_SIZE_BYTE)
    PACKAGES_SIZE = convertSize(PACKAGES_SIZE_BYTE)
    THUMB_SIZE    = convertSize(THUMB_SIZE_BYTE)

    startup_clean = plugintools.get_setting("acstartup")
    weekly_clean = plugintools.get_setting("clearday")

    if startup_clean == "false":
        startup_onoff = "[COLOR red]OFF[/COLOR]"
    else:
        startup_onoff = "[COLOR lime]ON[/COLOR]"
    if weekly_clean == "0":
        weekly_onoff = "[COLOR red]OFF[/COLOR]"
    else:
        weekly_onoff = "[COLOR lime]ON[/COLOR]"

    common.addItem('[COLOR white]Auto Clean Device[/COLOR]','url',19,ICON,FANART,'')
    common.addItem("[COLOR white]Clear Cache[/COLOR] - Current Size: " + str(CACHE_SIZE),BASEURL,20,ICON,FANART,'')
    common.addItem("[COLOR white]Delete Thumbnails [/COLOR] - Current Size: " + str(THUMB_SIZE),BASEURL,22,ICON,FANART,'')
    common.addItem("[COLOR white]Purge Packages [/COLOR] - Current Size: " + str(PACKAGES_SIZE),BASEURL,23,ICON,FANART,'')
    common.addItem('[COLOR white]Upload Log File[/COLOR]','url',27,ICON,FANART,'')
    common.addItem('[COLOR white]View Current or Old Log File[/COLOR]','url',18,ICON,FANART,'')
    common.addItem('[COLOR white]View the last error in log file[/COLOR]',BASEURL,24,ICON,FANART,'')
    common.addItem('[COLOR white]View all errors in the log file[/COLOR]',BASEURL,25,ICON,FANART,'')
    common.addItem('[COLOR white]Update Addons & Repos[/COLOR]',BASEURL,26,ICON,FANART,'')

def security_check(params):
    plugintools.add_item( action=vod_channels("VFZzZWFyY2g="),   title="Search Shows on Now" , thumbnail=os.path.join(LOAD_LIVE,vod_channels("dm9kLnBuZw==")), fanart=os.path.join(LOAD_LIVE,vod_channels("YmFja2dyb3VuZC5wbmc=")) ,  folder=True )
    plugintools.log(pnimi+sync_data("TGl2ZSBNZW51")+repr(params))
    request = urllib2.Request(televisioonilink, headers={"Accept" : "application/xml","User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36"})
    u = urllib2.urlopen(request)
    tree = ElementTree.parse(u)
    rootElem = tree.getroot()
    for channel in tree.findall(sync_data("Y2hhbm5lbA==")):
        kanalinimi = channel.find(get_live("dGl0bGU=")).text
        kanalinimi = base64.b64decode(kanalinimi)
        kategoorialink = channel.find(vod_channels("cGxheWxpc3RfdXJs")).text
        CatID = channel.find(get_live("Y2F0ZWdvcnlfaWQ=")).text
        ICON = os.path.join(LOAD_LIVE,sync_data("aWNvbi5wbmc="))
        if 'NHL' in kanalinimi.upper():
            ICON=os.path.join(LOAD_LIVE,sync_data("TkhMLnBuZw=="))
        if 'MLB' in kanalinimi.upper():
            ICON=os.path.join(LOAD_LIVE,sync_data("TUxCLnBuZw=="))
        if 'SPORTS' in kanalinimi.upper():
            ICON=os.path.join(LOAD_LIVE,sync_data("c3BvcnRzLnBuZw=="))
        plugintools.add_item( action=get_live("c3RyZWFtX3ZpZGVv"), title=kanalinimi , url=CatID , thumbnail=ICON , fanart=os.path.join(LOAD_LIVE,sync_data("dGhlYXRlci5qcGc=")) ,info_labels=kanalinimi, folder=True )

    plugintools.set_view( plugintools.LIST )

def stream_video(params):
    EPGColour=plugintools.get_setting("EPGColour")
    kasutajanimi=plugintools.get_setting("Username")
    salasona=plugintools.get_setting("Password")
    CatID = params.get(get_live("dXJs")) #description
    url = get_live("JXM6JXMvZW5pZ21hMi5waHA/dXNlcm5hbWU9JXMmcGFzc3dvcmQ9JXMmdHlwZT1nZXRfbGl2ZV9zdHJlYW1zJmNhdF9pZD0lcw==")%(lehekylg,pordinumber,kasutajanimi,salasona,CatID)
    xbmc.log(url)
    request = urllib2.Request(url, headers={"Accept" : "application/xml","User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36"})
    u = urllib2.urlopen(request)
    tree = ElementTree.parse(u)
    rootElem = tree.getroot()
    for channel in tree.findall(sync_data("Y2hhbm5lbA==")): #channel
        kanalinimi = channel.find(get_live("dGl0bGU=")).text #title
        kanalinimi = base64.b64decode(kanalinimi)
        kanalinimi = kanalinimi.partition("[")
        striimilink = channel.find(get_live("c3RyZWFtX3VybA==")).text #stream_url
        pony = striimilink
        if ("%s:%s/enigma2.php")%(lehekylg,pordinumber)  in striimilink: 
            pony = striimilink.split(kasutajanimi,1)[1]
            pony = pony.split(salasona,1)[1]
            pony = pony.split("/",1)[1]			
        pilt = channel.find(vod_channels("ZGVzY19pbWFnZQ==")).text #desc_image
        kava = kanalinimi[1]+kanalinimi[2]
        kava = kava.partition("]")
        kava = kava[2]
        kava = kava.partition("   ")
        kava = kava[2]
        shou = get_live("W0NPTE9SIHdoaXRlXSVzWy9DT0xPUl0gW0NPTE9SICVzXSVzIFsvQ09MT1Jd")%(kanalinimi[0],EPGColour,kava)
        kirjeldus = channel.find(sync_data("ZGVzY3JpcHRpb24=")).text #description
        if kirjeldus:
            kirjeldus = base64.b64decode(kirjeldus)
            nyyd = kirjeldus.partition("(")
            NowInfo = nyyd[2].partition(")")
            nyyd = sync_data("Tm93OiA=") +nyyd[0]
            jargmine = kirjeldus.partition(")\n")
            jargmine = jargmine[2].partition("(")
            jargmine = sync_data("TmV4dDog") +jargmine[0] #shou
            kokku = nyyd+jargmine
            if NowInfo:
                kokku = kokku+'\nNow:'+NowInfo[0]
        else:
            kokku = ""
        if pilt:
            plugintools.add_item( action=sync_data("cnVuX2Nyb25qb2I="), title=shou , url=pony, thumbnail=pilt, plot=kokku, fanart=os.path.join(LOAD_LIVE,sync_data("dGhlYXRlci5qcGc=")), extra="", isPlayable=True, folder=False )
        else:
            plugintools.add_item( action=sync_data("cnVuX2Nyb25qb2I="), title=shou , url=pony, thumbnail=os.path.join(LOAD_LIVE,vod_channels("YWxsY2hhbm5lbHMucG5n")) , plot=kokku, fanart=os.path.join(LOAD_LIVE,sync_data("dGhlYXRlci5qcGc=")) , extra="", isPlayable=True, folder=False )
    plugintools.set_view( plugintools.EPISODES )

def detect_modification(params):
    plugintools.add_item( action=vod_channels("Vk9Ec2VhcmNo"),   title="Search On Demand" , thumbnail=os.path.join(LOAD_LIVE,vod_channels("dm9kLnBuZw==")), fanart=os.path.join(LOAD_LIVE,vod_channels("YmFja2dyb3VuZC5wbmc=")) ,  folder=True )
    plugintools.add_item( action=vod_channels("UmVjZW50bHlBZGRlZA=="),   title="Recently Added" , thumbnail=os.path.join(LOAD_LIVE,vod_channels("dm9kLnBuZw==")), fanart=os.path.join(LOAD_LIVE,vod_channels("YmFja2dyb3VuZC5wbmc=")) ,  folder=True )
    plugintools.log(pnimi+vod_channels("Vk9EIE1lbnUg")+repr(params))
    request = urllib2.Request(filmilink, headers={"Accept" : "application/xml","User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36"})
    u = urllib2.urlopen(request)
    tree = ElementTree.parse(u)
    rootElem = tree.getroot()
    for channel in tree.findall(sync_data("Y2hhbm5lbA==")):
        filminimi = channel.find(get_live("dGl0bGU=")).text
        filminimi = base64.b64decode(filminimi)
        kategoorialink = channel.find(vod_channels("cGxheWxpc3RfdXJs")).text
        plugintools.add_item( action=vod_channels("Z2V0X215YWNjb3VudA=="), title=filminimi , url=kategoorialink , thumbnail=os.path.join(LOAD_LIVE,sync_data("dm9kLnBuZw==")) , fanart=os.path.join(LOAD_LIVE,sync_data("dGhlYXRlci5qcGc=")) , folder=True )
    
    plugintools.set_view( plugintools.LIST )

def open_url(url):
    try:
        req = urllib2.Request(url,headers={"Accept" : "application/xml","User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36"})
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link
    except:quit()

def RecentlyAdded(params):
    plugintools.set_view( plugintools.MOVIES )
    Recent = base64.b64decode(b'JXM6JXMvcGxheWVyX2FwaS5waHA/dXNlcm5hbWU9JXMmcGFzc3dvcmQ9JXMmYWN0aW9uPWdldF92b2Rfc3RyZWFtcw==')%(lehekylg,pordinumber,kasutajanimi,salasona)
    Load = json.load(urllib2.urlopen(Recent))
    now = datetime.datetime.now()
    diff = datetime.timedelta(days=7)
    future = now - diff
    Past = future.strftime("%Y-%m-%d %H:%M:%S")
    for x in Load:
        DateAdded = x['added']
        pealkiri = x['name']
        Icon = x['stream_icon']
        StreamID = x['stream_id']
        Ext = x['container_extension']
        Normal = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(float(DateAdded)))
        if Normal > Past:
            if StreamID:
                striimilink = vod_channels('JXM6JXMvbW92aWUvJXMvJXMvJXMuJXM=')%(lehekylg,pordinumber,kasutajanimi,salasona,StreamID,Ext)
                URL = vod_channels('JXM6JXMvcGxheWVyX2FwaS5waHA/dXNlcm5hbWU9JXMmcGFzc3dvcmQ9JXMmYWN0aW9uPWdldF92b2RfaW5mbyZ2b2RfaWQ9JXM=')%(lehekylg,pordinumber,kasutajanimi,salasona,StreamID)
                Meta = json.load(urllib2.urlopen(URL))
                try:
                    Plot = Meta['info']['plot']
                except:
                    Plot = 'No plot Available'
                try:
                    Genre = Meta['info']['genre']
                except:
                    Genre = 'Unknown Genre'
                try:
                    Director = Meta['info']['director']
                except:
                    Director = 'No Director Specified'
                try:
                    ReleaseDate = Meta['info']['releasedate']
                except:
                    ReleaseDate = 'Release Date Not Found'
                try:
                    Duration = Meta['info']['duration']
                except:
                    Duration = 'Duration Not Found'
                kirjeldus = Duration+'\n'+Plot.encode("utf-8")+'\n'+Director.encode("utf-8")+'\n'+Genre.encode("utf-8")+'\n'+ReleaseDate
                if Icon:
                    plugintools.add_item( action="restart_service", title=pealkiri , url=striimilink, thumbnail=Icon, plot=kirjeldus, fanart=os.path.join(LOAD_LIVE,sync_data("dGhlYXRlci5qcGc=")) , extra="", isPlayable=True, folder=False )
                else:
                    plugintools.add_item( action="restart_service", title=pealkiri , url=striimilink, thumbnail=os.path.join(LOAD_LIVE,sync_data("dm9kLnBuZw==")), plot=kirjeldus, fanart=os.path.join(LOAD_LIVE,sync_data("dGhlYXRlci5qcGc=")) , extra="", isPlayable=True, folder=False )

def VODsearch(params):
    SEARCH_LIST = base64.b64decode(b'JXM6JXMvZW5pZ21hMi5waHA/dXNlcm5hbWU9JXMmcGFzc3dvcmQ9JXMmdHlwZT1nZXRfdm9kX3N0cmVhbXMmY2F0X2lkPTA=')%(lehekylg,pordinumber,kasutajanimi,salasona)
    keyb = xbmc.Keyboard('', '[COLOR white]Search[/COLOR]')
    keyb.doModal()
    if (keyb.isConfirmed()):
        searchterm=keyb.getText()
        searchterm=string.capwords(searchterm)
    else:quit()
    link=open_url(SEARCH_LIST) 
    match = re.compile('<title>(.+?)</title><desc_image><!\[CDATA\[(.+?)\]\]></desc_image><description>(.+?)</description>.+?<stream_url><!\[CDATA\[(.+?)\]\]></stream_url>').findall(link)
    for pealkiri,pilt,kirjeldus,striimilink in match:
        pealkiri = base64.b64decode(pealkiri)
        pealkiri = pealkiri.encode("utf-8")
        if kirjeldus:
            kirjeldus = base64.b64decode(kirjeldus)
        if searchterm in pealkiri:
            if pilt:
                plugintools.add_item( action="restart_service", title=pealkiri , url=striimilink, thumbnail=pilt, plot=kirjeldus, fanart=os.path.join(LOAD_LIVE,sync_data("dGhlYXRlci5qcGc=")) , extra="", isPlayable=True, folder=False )
            else:
                plugintools.add_item( action="restart_service", title=pealkiri , url=striimilink, thumbnail=os.path.join("dm9kLnBuZw=="), plot=kirjeldus, fanart=os.path.join(LOAD_LIVE,sync_data("dGhlYXRlci5qcGc=")) , extra="", isPlayable=True, folder=False )

def TVsearch(params):
    EPGColour=plugintools.get_setting("EPGColour")
    SEARCH_LIST = base64.b64decode(b'JXM6JXMvZW5pZ21hMi5waHA/dXNlcm5hbWU9JXMmcGFzc3dvcmQ9JXMmdHlwZT1nZXRfbGl2ZV9zdHJlYW1zJmNhdF9pZD0w')%(lehekylg,pordinumber,kasutajanimi,salasona)
    keyb = xbmc.Keyboard('', '[COLOR white]Search[/COLOR]')
    keyb.doModal()
    if (keyb.isConfirmed()):
        searchterm=keyb.getText()
        searchterm=string.capwords(searchterm)
    else:quit()
    request = urllib2.Request(SEARCH_LIST, headers={"Accept" : "application/xml","User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36"})
    u = urllib2.urlopen(request)
    tree = ElementTree.parse(u)
    rootElem = tree.getroot()
    for channel in tree.findall(sync_data("Y2hhbm5lbA==")): #channel
        kanalinimi = channel.find(get_live("dGl0bGU=")).text #title
        kanalinimi = base64.b64decode(kanalinimi)
        kanalinimi = kanalinimi.partition("[")
        striimilink = channel.find(get_live("c3RyZWFtX3VybA==")).text #stream_url
        pony = striimilink
        if ("%s:%s/enigma2.php")%(lehekylg,pordinumber) in striimilink:
            pony = striimilink.split(kasutajanimi,1)[1]
            pony = pony.split(salasona,1)[1]
            pony = pony.split("/",1)[1]			
        pilt = channel.find(vod_channels("ZGVzY19pbWFnZQ==")).text #desc_image
        kava = kanalinimi[1]+kanalinimi[2]
        kava = kava.partition("]")
        kava = kava[2]
        kava = kava.partition("   ")
        kava = kava[2]
        shou = get_live("W0NPTE9SIHdoaXRlXSVzWy9DT0xPUl0gW0NPTE9SICVzXSVzIFsvQ09MT1Jd")%(kanalinimi[0],EPGColour,kava)
        kirjeldus = channel.find(sync_data("ZGVzY3JpcHRpb24=")).text #description
        if kirjeldus:
            kirjeldus = base64.b64decode(kirjeldus)
            nyyd = kirjeldus.partition("(")
            nyyd = sync_data("Tm93OiA=") +nyyd[0]
            jargmine = kirjeldus.partition(")\n")
            jargmine = jargmine[2].partition("(")
            jargmine = sync_data("TmV4dDog") +jargmine[0] #shou
            kokku = nyyd+jargmine
        else:
            kokku = ""
        if searchterm in kava:
            if pilt:
                plugintools.add_item( action=sync_data("cnVuX2Nyb25qb2I="), title=shou , url=pony, thumbnail=pilt, plot=kokku, fanart=os.path.join(LOAD_LIVE,sync_data("dGhlYXRlci5qcGc=")), extra="", isPlayable=True, folder=False )
            else:
                plugintools.add_item( action=sync_data("cnVuX2Nyb25qb2I="), title=shou , url=pony, thumbnail=os.path.join(LOAD_LIVE,vod_channels("YWxsY2hhbm5lbHMucG5n")) , plot=kokku, fanart=os.path.join(LOAD_LIVE,sync_data("dGhlYXRlci5qcGc=")) , extra="", isPlayable=True, folder=False )

def get_myaccount(params):
    if vanemalukk == "true":
       pealkiri = params.get("title")
       vanema_lukk(pealkiri)
    purl = params.get("url")
    request = urllib2.Request(purl, headers={"Accept" : "application/xml","User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36"})
    u = urllib2.urlopen(request)
    tree = ElementTree.parse(u)
    rootElem = tree.getroot()
    for channel in tree.findall("channel"):
        try:
            pealkiri = channel.find("title").text
            pealkiri = base64.b64decode(pealkiri)
            pealkiri = pealkiri.encode("utf-8")
            striimilink = channel.find("stream_url").text
            pilt = channel.find("desc_image").text
            kirjeldus = channel.find("description").text
            if kirjeldus:
               kirjeldus = base64.b64decode(kirjeldus)
            if pilt:
               plugintools.add_item( action="restart_service", title=pealkiri , url=striimilink, thumbnail=pilt, plot=kirjeldus, fanart=os.path.join(LOAD_LIVE,sync_data("dGhlYXRlci5qcGc=")) , extra="", isPlayable=True, folder=False )
            else:
               plugintools.add_item( action="restart_service", title=pealkiri , url=striimilink, thumbnail=os.path.join("dm9kLnBuZw=="), plot=kirjeldus, fanart=os.path.join(LOAD_LIVE,sync_data("dGhlYXRlci5qcGc=")) , extra="", isPlayable=True, folder=False )
        except:
            kanalinimi = channel.find("title").text
            kanalinimi = base64.b64decode(kanalinimi)
            kategoorialink = channel.find("playlist_url").text
            CatID = channel.find("category_id").text
            plugintools.add_item( action=get_live("Z2V0X215YWNjb3VudA=="), title=kanalinimi , url=kategoorialink , thumbnail=os.path.join(LOAD_LIVE,sync_data("dm9kLnBuZw==")) , fanart=os.path.join(LOAD_LIVE,sync_data("dGhlYXRlci5qcGc=")) ,info_labels=kanalinimi, folder=True )

    plugintools.set_view( plugintools.EPISODES )

def run_cronjob(params):
    kasutajanimi=plugintools.get_setting("Username")
    salasona=plugintools.get_setting("Password")
    lopplink = params.get("url")
    if "http://"  not in lopplink: 
        lopplink = get_live("aHR0cDovLyVzOiVzL2VuaWdtYS5waHAvbGl2ZS8lcy8lcy8lcw==")%(lehekylg,pordinumber,kasutajanimi,salasona,lopplink)
        lopplink = lopplink[:-2]
        lopplink = lopplink + "ts"
    listitem = xbmcgui.ListItem(path=lopplink)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)

def sync_data(channel):
    video = base64.b64decode(channel)
    return video

def restart_service(params):
    lopplink = params.get(vod_channels("dXJs"))
    plugintools.play_resolved_url( lopplink )

def grab_epg():
    req = urllib2.Request(andmelink)
    req.add_header(sync_data("VXNlci1BZ2VudA==") , vod_channels("S29kaSBwbHVnaW4gYnkgTWlra00="))
    response = urllib2.urlopen(req)
    link=response.read()
    try:
        jdata = json.loads(link.decode('utf8'))
        response.close()
        if jdata:
            plugintools.log(pnimi+sync_data("amRhdGEgbG9hZGVk"))
            return jdata
    except ValueError, e:
        return False

def kontroll():
    try:
        randomstring = grab_epg()
        kasutajainfo = randomstring[sync_data("dXNlcl9pbmZv")]
        kontroll = kasutajainfo[get_live("YXV0aA==")]
        return kontroll
    except:
        return None
def get_live(channel):
    video = base64.b64decode(channel)
    return video
def execute_ainfo(params):
    data = json.load(urllib2.urlopen(PlayerAPI))
    today = datetime.date.today()
    x=data['user_info']
    Username = x['username']
    Status = x['status']
    Creation = x['created_at']
    Created = datetime.datetime.fromtimestamp(int(Creation)).strftime('%H:%M %d/%m/%Y')
    Current = x['active_cons']
    Max = x['max_connections']
    Expiry = x['exp_date']
    if Expiry == None:
        Expired = 'Never'
    else:
        Expired = datetime.datetime.fromtimestamp(int(Expiry)).strftime('%H:%M %d/%m/%Y')
    plugintools.add_item( action="",   title="[COLOR white]User: "+Username+"[/COLOR]", thumbnail=os.path.join(LOAD_LIVE,vod_channels("bXlhY2MucG5n")) , fanart=os.path.join(LOAD_LIVE,sync_data("dGhlYXRlci5qcGc=")) , folder=False )
    plugintools.add_item( action="",   title="[COLOR white]Status: "+Status+"[/COLOR]", thumbnail=os.path.join(LOAD_LIVE,vod_channels("bXlhY2MucG5n")) , fanart=os.path.join(LOAD_LIVE,sync_data("dGhlYXRlci5qcGc=")) , folder=False )
    plugintools.add_item( action="",   title="[COLOR white]Created: "+Created+"[/COLOR]", thumbnail=os.path.join(LOAD_LIVE,vod_channels("bXlhY2MucG5n")) , fanart=os.path.join(LOAD_LIVE,sync_data("dGhlYXRlci5qcGc=")) , folder=False )
    plugintools.add_item( action="",   title="[COLOR white]Expires: "+Expired+"[/COLOR]", thumbnail=os.path.join(LOAD_LIVE,vod_channels("bXlhY2MucG5n")) , fanart=os.path.join(LOAD_LIVE,sync_data("dGhlYXRlci5qcGc=")) , folder=False )
    plugintools.add_item( action="",   title="[COLOR white]Max connections: "+Max+"[/COLOR]", thumbnail=os.path.join(LOAD_LIVE,vod_channels("bXlhY2MucG5n")) , fanart=os.path.join(LOAD_LIVE,sync_data("dGhlYXRlci5qcGc=")) , folder=False )
    plugintools.add_item( action="",   title="[COLOR white]Active connections: "+Current+"[/COLOR]", thumbnail=os.path.join(LOAD_LIVE,vod_channels("bXlhY2MucG5n")) , fanart=os.path.join(LOAD_LIVE,sync_data("dGhlYXRlci5qcGc=")) , folder=False )

    plugintools.set_view( plugintools.LIST )
def vanema_lukk(name):
        plugintools.log(pnimi+sync_data("UGFyZW50YWwgbG9jayA="))
        a = 'XXX', 'Adult', 'Adults','ADULT','ADULTS','adult','adults','Porn','PORN','porn','Porn','xxx'
        if any(s in name for s in a):
           xbmc.executebuiltin((u'XBMC.Notification("Parental Lock", "Channels may contain adult content", 2000)'))
           text = plugintools.keyboard_input(default_text="", title=get_live("UGFyZW50YWwgbG9jaw=="))
           if text==plugintools.get_setting(sync_data("dmFuZW1ha29vZA==")):
              return
           else:
              exit()
        else:
           name = ""
def check_user():
    plugintools.message(get_live("RVJST1I="),vod_channels("VU5BVVRIT1JJWkVEIEVESVQgT0YgQURET04h"))
    sys.exit()
def load_channels():
    statinfo = os.stat(LOAD_LIVE+"/"+get_live("YmFja2dyb3VuZC5wbmc="))

def vod_channels(channel):
    video = base64.b64decode(channel)
    return video

run()
"""


