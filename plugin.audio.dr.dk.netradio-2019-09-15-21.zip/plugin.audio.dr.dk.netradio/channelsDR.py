#
#      Copyright (C) 2014 Tommy Winther
#      http://tommy.winther.nu
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt. If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
CHANNELS = list()


class ChannelDR(object):
    def __init__(self, id, name, epg, icon):
        self.id = id
        self.name = name
        self.epg = epg
        self.icon = icon

        CHANNELS.append(self)

### ### Link to EPG List: https://www.dr.dk/Tjenester/epglive/
ChannelDR(1, 'P1', 'https://www.dr.dk/Tjenester/epglive/epg.radio.P1.drxml','P1D')
ChannelDR(2, 'P2', 'https://www.dr.dk/Tjenester/epglive/epg.radio.P2.drxml','P2D')
ChannelDR(3, 'P3', 'https://www.dr.dk/Tjenester/epglive/epg.radio.P3.drxml','P3')
ChannelDR(4, 'P4Bornholm', 'https://www.dr.dk/Tjenester/epglive/epg.radio.P4Bornholm.drxml','AB4')
ChannelDR(5, 'P4Esbjerg', 'https://www.dr.dk/Tjenester/epglive/epg.radio.P4Esbjerg.drxml','AB4')
ChannelDR(6, 'P4Fyn', 'https://www.dr.dk/Tjenester/epglive/epg.radio.P4Fyn.drxml','AB4')
ChannelDR(7, 'P4KBH', 'https://www.dr.dk/Tjenester/epglive/epg.radio.P4KBH.drxml','AB4')
ChannelDR(8, 'P4Vest', 'https://www.dr.dk/Tjenester/epglive/epg.radio.P4Midtogvest.drxml','AB4')
ChannelDR(9, 'P4Nord', 'https://www.dr.dk/Tjenester/epglive/epg.radio.P4Nordjylland.drxml','AB4')
ChannelDR(10, 'P4Aarhus', 'https://www.dr.dk/Tjenester/epglive/epg.radio.P4Oestjylland.drxml','AB4')
ChannelDR(11, 'P4Sjaelland', 'https://www.dr.dk/Tjenester/epglive/epg.radio.P4Sjaelland.drxml','AB4')
ChannelDR(12, 'P4Syd', 'https://www.dr.dk/Tjenester/epglive/epg.radio.P4Syd.drxml','AB4')
ChannelDR(13, 'P4Trekanten', 'https://www.dr.dk/Tjenester/epglive/epg.radio.P4Trekanten.drxml','AB4')
ChannelDR(14, 'P5', 'https://www.dr.dk/Tjenester/epglive/epg.radio.P5.drxml','P5D')
ChannelDR(15, 'P6Beat', 'https://www.dr.dk/Tjenester/epglive/epg.radio.P6Beat.drxml','P6B')
ChannelDR(16, 'P7Mix', 'https://www.dr.dk/Tjenester/epglive/epg.radio.P7M.drxml','P7M')
ChannelDR(17, 'P8Jazz', 'https://www.dr.dk/Tjenester/epglive/epg.radio.P8Jazz.drxml','P8J')
###ChannelDR(18, 'RamasjangRadio', 'https://www.dr.dk/Tjenester/epglive/epg.radio.RamasjangUltra.drxml','')


"""
2019-05-28 19:56:39 addon.py: playEPG(idx= 'P4Midtogvest')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P1' slug= u'p1')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P2' slug= u'p2')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P3' slug= u'p3')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P4 K\xf8benhavn' slug= u'p4kbh')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P4 Bornholm' slug= u'p4bornholm')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P4 Esbjerg' slug= u'p4esbjerg')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P4 Fyn' slug= u'p4fyn')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P4 Midt & Vest' slug= u'p4vest')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P4 Nordjylland' slug= u'p4nord')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P4 Sj\xe6lland' slug= u'p4sjaelland')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P4 Syd' slug= u'p4syd')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P4 Trekanten' slug= u'p4trekanten')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P4 \xd8stjylland' slug= u'p4aarhus')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P5' slug= u'p5')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P6 BEAT' slug= u'p6beat')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P7 MIX' slug= u'p7mix')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P8 JAZZ' slug= u'p8jazz')
2019-05-28 19:56:40 addon.py: playEPG(title= u'Ramasjang/Ultra Radio' slug= u'ramasjangradio')
2019-05-28 19:56:40 addon.py: playEPG(title= u'Nyheder' slug= u'nyhederradio')


CHANNELS_URL = 'https://www.dr.dk/mu-online/api/1.0/channel/all-active-dr-radio-channels'
CHANNELS_URL_EPG = 'https://www.dr.dk/Tjenester/epglive/epg.radio.%s.drxml'

ADDON     = xbmcaddon.Addon()
ADDONname = ADDON.getAddonInfo('name')
ADDONid   = ADDON.getAddonInfo('id')
ADDONpath = xbmc.translatePath('special://home/addons/%s/' % ADDONid)
ProgramPlaying = ADDON.getSetting('ProgramPlaying')
ADDON.setSetting('ProgramPlaying',ProgramPlaying)
programswanted = ['madsen']
programsnogo   = ['funk','povlsen']
preferredstation = 'P4'  ### DR P4
backupstation    = 'P5'  ### DR P5

"""