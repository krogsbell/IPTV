#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#      Copyright (C) 2014 Tommy Winther
#      http://tommy.winther.nu
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt. If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
import os
import sys
import json as simplejson
import urllib
import urllib.parse as urlparse
try:
    # For Python 3.0 and later
    from urllib.request import urlopen
except ImportError:
    # Fall back to Python 2's urllib2
    from urllib2 import urlopen
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import channels
import channelsDR   ### 2019-05-28
###import buggalo
import utils
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import _strptime
import xmltodict
import base64

CHANNELS_URL = 'https://www.dr.dk/mu-online/api/1.4/channel/all-active-dr-radio-channels'
### CHANNELS_URL_EPG = 'https://www.dr.dk/Tjenester/epglive/epg.radio.%s.drxml' ###2021-03 - stopped working
###CHANNELS_URL_EPG = 'https://www.dr.dk/mu-online-radio/api/1.0/spots/schedule/all/2021-03-24?group=false'
CHANNELS_URL_EPG = 'https://www.dr.dk/lyd/p4kbh'
### Link to EPG List: https://www.dr.dk/Tjenester/epglive/

ADDON     = xbmcaddon.Addon('plugin.audio.dr.dk.netradio')
ADDONname = ADDON.getAddonInfo('name')
ADDONid   = ADDON.getAddonInfo('id')
ADDONpath = xbmcvfs.translatePath('special://home/addons/%s/' % ADDONid)
datapath  = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
ProgramPlaying = ADDON.getSetting('ProgramPlaying')
programswanted = ADDON.getSetting('programswanted').split(',')
programsnogo   = ADDON.getSetting('programsnogo').split(',')
preferredstation = ADDON.getSetting('preferredstation') ### DR P4 København
backupstation    = ADDON.getSetting('backupstation') ### DR P5
module = 'addon.py'
if ADDON.getSetting('noepg') == 'true':
    noepg = True
else:
    noepg = False

DaysOfWeek = [ADDON.getLocalizedString(30510),ADDON.getLocalizedString(30511),ADDON.getLocalizedString(30512),ADDON.getLocalizedString(30513),ADDON.getLocalizedString(30514),ADDON.getLocalizedString(30515),ADDON.getLocalizedString(30516)]

def __log(text):
    utils.logdev(module,' '.join(text.split())[0:200])  ### Remove doublespaces etc
    
def TSl(timestr):
    ### time format 2019-05-21T22:05:00Z to date string i local
    ### 2022-06-04T03:00:00+00:00
    time_tuple = time.strptime(timestr, "%Y-%m-%dT%H:%M:%S%z")
    timestamp = time.mktime(time_tuple)
    TO = datetime.fromtimestamp(timestamp)
    TOTS = int(time.mktime(TO.timetuple()))
    utcTO = datetime.utcfromtimestamp(timestamp)
    utcTOTS = int(time.mktime(utcTO.timetuple()))
    timeoffset = TOTS-utcTOTS
    ###__log('timeoffset= %r' % timeoffset)
    return(timestamp+timeoffset) 
    
def TS(timestr):
    ### time format 2019-05-21T22:05:00Z
    ### 2022-06-04T03:00:00+00:00
    time_tuple = time.strptime(timestr, "%Y-%m-%dT%H:%M:%S%z")
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def now():   ### Local time
    dt_obj= datetime.now()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
    
def ison(start,end,pendTS):   ### Local time
    if start == '' or end == '' or pendTS == '':
        return False
    start = int(start)-100
    end   = int(end)+100
    dt_obj= datetime.now()
    time_tuple = dt_obj.timetuple()
    now   = time_tuple[2]*10000 + time_tuple[3]*100 + time_tuple[4]
    pend  = int(datestr(pendTS,'%d%H%M'))
    __log('ison(start= %r, end= %r, time_tuple= %r)' %(start,end,now))
    __log('ison(pendTS= %r, pend= %r)' %(pendTS,pend))
    ###ison(start= '14m03', end= '16m04', time_tuple= time.struct_time(tm_year=2019, tm_mon=11, tm_mday=29, tm_hour=13, tm_min=58, tm_sec=18, tm_wday=4, tm_yday=333, tm_isdst=-1))
    if start <= now and now <= end and start <= pend and pend <= end:
        return True
    else:
        return False
   
def nowTS():   ### UTC time
    dt_obj= datetime.utcnow()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def nowS(format):   ### Now date string Local time
    time_tuple = time.localtime(nowTS())
    date_str = time.strftime(format, time_tuple)
    return(date_str)
    
def datestr(timestamp,format):   ### Date string UTC time %Y-%m-%dT%H:%M:%S%z
    time_tuple = time.localtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)

def datestrdelta(timestamp,format):   ### Now date string UTC time %Y-%m-%dT%H:%M:%S%z
    time_tuple = time.gmtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)
    
def takeSecond(elem): 
    return elem[1]

def testHTTP(url):  
    try:
        return True
        import socket
        if url[:4].lower() != 'http':
            __log('testHTTP(%r)=\n%r' % (url,'Play non http or https!'))
            return True
        # timeout in seconds
        timeout = 10
        socket.setdefaulttimeout(timeout)

        # this call to urlopen now uses the default timeout
        # we have set in the socket module
        req = urllib.parse.Request(url)
        response = urlopen(req)
        __log('testHTTP(%r)=\n%r' % (url,response))
        return response
    except Exception as e:
        pass
        __log('testHTTP(%r)\nERROR: %r' % (url,e))
        return False
   
def direct_play(url):
    __log("direct_play ["+url+"]")

    title = ""

    try:
        xlistitem = xbmcgui.ListItem( title, path=url)
        xlistitem.setArt({ 'icon': "DefaultAudio.png", 'thumb' : "DefaultAudio.png" })
    except:
        xlistitem = xbmcgui.ListItem( title)
        xlistitem.setArt({ 'icon': "DefaultAudio.png", 'thumb' : "DefaultAudio.png" })
    xlistitem.setInfo( "Music", { "Title": title } )

    playlist = xbmc.PlayList( xbmc.PLAYLIST_MUSIC )
    player_type = xbmc.PLAYER_CORE_AUTO
    xbmcPlayer = xbmc.Player( player_type )
    xbmcPlayer.play(playlist) 

def StopAllStationAlarms():
    __log('StopAllStationAlarms()')
    try:
        for chan in channels.CHANNELS:
            station_id = chan.name
            nameAlarm = ADDONid + '-start-' + str(station_id)
            xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
        for radioEPGi in channelsDR.CHANNELS:
            station_id = radioEPGi.name
            nameAlarm = ADDONid + '-start-' + str(station_id)
            xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
    except Exception as e:
        pass
        __log('StopAllStationAlarms() ERROR: %r' % e)
    
def StartProgram(station_id,timestamp):
    try:
        __log('ADDON %r - %r' % (ADDONname,ADDONid))
        __log('station_id= %r Start @ %r' % (station_id,datestr(timestamp,'%H:%M:%S')))
        if not station_id:
            station_id = preferredstation
            __log('playEPG(DEFAULT station_id= %r)' % station_id)
            
        script = os.path.join(ADDONpath, 'startstation.py')
        __log('script= %r' % script)
        ###nameAlarm = ADDONid + '-start-' + str(station_id) + '-' + datestr(timestamp,'d%dh%Hm%Ms%S')
        nameAlarm = ADDONid + '-start-' + str(station_id)
        __log('nameAlarm= %r' % nameAlarm)
        delay = timestamp - nowTS()
        __log('delay= %r' % delay)
        delayHMS = datestrdelta(delay,'%H:%M:%S')
        __log('delayHMS= %r' % delayHMS)
        if delay >= 0 and delay < 24*3600:
            cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),%s,silent)' % (nameAlarm, script, PATH,station_id,delayHMS)
            __log('cmd= %s' % cmd)
            __log('LastStartStation:' + station_id + ': '+datestr(timestamp,'d%dh%Hm%Ms%S'))
            ADDON.setSetting('LastStartStation',station_id + ': '+datestr(timestamp,'d%dh%Hm%Ms%S'))
            ADDON.setSetting('StartStation',station_id)
            xbmc.executebuiltin(cmd)  # Active
    except Exception as e:
        pass
        __log('StartProgram(station_id= %r,timestamp= %r) ERROR: %r' % (station_id,timestamp,e))
   
def EndProgram(station_id,timestamp):
    __log('ADDON %r - %r' % (ADDONname,ADDONid))
    __log('station_id= %r Start @ %r' % (station_id,datestr(timestamp,'%H:%M:%S')))
    __log('do not run this')
    """
    ###ADDONpath =  = xbmcvfs.translatePath('special://home/addons/%s/' % ADDONid)
    script = os.path.join(ADDONpath, 'startstation.py')
    __log('script= %r' % script)
    nameAlarm = ADDONid + '-startstation-' + str(timestamp)
    #delay = timestamp - now.....
    cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),00:00:00,silent)' % (nameAlarm, script, station_id, str(timestamp))
    __log('cmd= %s' % cmd)
    ADDON.setSetting('StopStation',station_id)
    xbmc.executebuiltin(cmd)  # Active
    """
    #return
    
def TwoLines(name):  ### Use in menus to allow autoscroll and see all text on both lines
    name = name.replace('  ',' ').split('\n')
    line1 = name[0]
    lenline1 = len(line1)
    line2 = ''
    for i in range(1, len(name)):
        line2 += name[i] + ' '
    lenline2 = len(line2)
    if lenline1 < lenline2:
        line1 = line1 + '  ' * (lenline2 - lenline1)
    name = line1 +'\n' + line2
    return name
    
def showOverview():
    item = xbmcgui.ListItem(ADDON.getLocalizedString(30100))
    item.setArt({ 'icon': ICON, 'thumb' : ICON })
    item.setProperty('Fanart_Image', FANART)
    xbmcplugin.addDirectoryItem(HANDLE, PATH + '?show=dr', item, True)
    
    if not noepg:
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30102))
        item.setArt({ 'icon': ICON, 'thumb' : ICON })
        item.setProperty('Fanart_Image', FANART)
        xbmcplugin.addDirectoryItem(HANDLE, PATH + '?show=epg', item, True)
    
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30104))
        item.setArt({ 'icon': ICON, 'thumb' : ICON })
        item.setProperty('Fanart_Image', FANART)
        xbmcplugin.addDirectoryItem(HANDLE, PATH + '?show=epga', item, True)
        
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30103))
        item.setArt({ 'icon': ICON, 'thumb' : ICON })
        item.setProperty('Fanart_Image', FANART)
        xbmcplugin.addDirectoryItem(HANDLE, PATH + '?show=epgm', item, True)                    

    item = xbmcgui.ListItem(ADDON.getLocalizedString(30101))
    item.setArt({ 'icon': ICON, 'thumb' : ICON })
    item.setProperty('Fanart_Image', FANART)
    xbmcplugin.addDirectoryItem(HANDLE, PATH + '?show=other', item, True)
    
    item = xbmcgui.ListItem(ADDON.getLocalizedString(30406))
    item.setArt({ 'icon': ICON, 'thumb' : ICON })
    item.setProperty('Fanart_Image', FANART)
    xbmcplugin.addDirectoryItem(HANDLE, PATH + '?find=other', item, True)

    item = xbmcgui.ListItem(ADDON.getLocalizedString(30405))
    item.setArt({ 'icon': ICON, 'thumb' : ICON })
    item.setProperty('Fanart_Image', FANART)
    if krogsbellswitchavailable():
        xbmcplugin.addDirectoryItem(HANDLE, PATH + '?switch=other', item, True)
    
    """
    item = xbmcgui.ListItem('Test Start P6Beat', iconImage=ICON)
    item.setArt({ 'icon': logoImage, 'thumb' : logoImage })
    item.setProperty('Fanart_Image', FANART)
    xbmcplugin.addDirectoryItem(HANDLE, PATH + '?start=P6Beat', item, True)
    """
    
    xbmcplugin.endOfDirectory(HANDLE)

def getDRChannels():
    try:
        u = urlopen(CHANNELS_URL)
        channelList = simplejson.loads(u.read())
        u.close()
    except Exception as  ex:
        showError(str(ex))
        return
    Channels = []
    for channel in channelList:
        __log('showDRChannels(channel= %r)'% channel)
        title = channel['Title']
        if title[0:3] == 'DR ':
            title = title[3:]
        if title[0:2] == 'P5':
            title = title[:2]
        __log('getDRChannels(title= %r)'% title)
        Channels.append(title)
    return sorted(Channels, key=str.casefold)

def showDRChannels():
    try:
        u = urlopen(CHANNELS_URL)
        channelList = simplejson.loads(u.read())
        u.close()
    except Exception as  ex:
        showError(str(ex))
        return
    ### http://live-icy.gss.dr.dk/A/A25L...A28L.mp3  <<== https://live-icy.dr.dk/A/A02H.mp3 P5 Fyn ... København
    for channel in channelList:
        __log('showDRChannels(channel= %r)'% channel)
        title = channel['Title']
        slug  = channel['Slug']
        if title[0:3] == 'DR ':
            title = title[3:]
        if title[0:2] == 'P5':
            title = title[:2]
        __log('playEPG(title= %r, slug= %r)'% (title,slug))
        sourceUrl = channel['SourceUrl']
        logoImage = xbmcvfs.translatePath(os.path.join(LOGO_PATH, sourceUrl[sourceUrl.rindex('/') + 1:] + '.png'))
        __log('4 logoImage= %r'% logoImage)
        if xbmcvfs.exists(logoImage):
            ###__log('logoImage EXISTS %r'% logoImage)
            item = xbmcgui.ListItem(title)
            item.setArt({ 'icon': logoImage, 'thumb' : logoImage })
        else:
            ###__log('logoImage DO NOT EXISTS %r'% logoImage)
            item = xbmcgui.ListItem(title)
            item.setArt({ 'icon': ICON, 'thumb' : ICON })
        menu=[]
        if krogsbellswitchavailable():
            menutext = ADDON.getLocalizedString(30405)   ### Switch Krogsbell Addons
            menu.append(('[COLOR blue][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?switch=other)'% (sys.argv[0]))) 
        item.addContextMenuItems(items=menu, replaceItems=True)
        item.setProperty('IsPlayable', 'true')
        item.setProperty('Fanart_Image', FANART)
        item.setInfo(type='music', infoLabels={
                    'title': title,
                    'tracknumber': 12345679,
                    'discnumber': 13,
                    'duration': 245999,
                    'year': 1999,
                    'genre': 'genre',
                    'album': 'Pulse1',
                    'artist': 'Cat',
                    'rating': int(utils.ADDONgetSetting('setvolumen'))/10
                })
        """
        item.setInfo(type='music', infoLabels={
            'title': title,
            'genre': 'genre345'
        })
        """

        url = None

        if 'StreamingServers' in channel:
            for server in channel['StreamingServers']:
                if 'LinkType' in server and server['LinkType'] == 'ICY' and 'Qualities' in server:
                    try:
                        url = server['Server'] + '/' + server['Qualities'][0]['Streams'][0]['Stream']
                        
                        break
                    except:
                        pass
        __log('playEPG(url 245= %r)'% url)
        if url:
            __log('url= %r' % url)
            ###url = url.replace('https://live-icy.dr.dk/A/A02H.mp3','http://live-icy.gss.dr.dk/A/A25L.mp3')
            __log('url= %r' % url)
            url = url.replace('https://live-icy.dr.dk/A/A02H.mp3','http://live-icy.gss.dr.dk/A/A28L.mp3')  ### P5 København
            xbmcplugin.addDirectoryItem(HANDLE, url, listitem = item)

    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.endOfDirectory(HANDLE)

def getOtherChannels():
    Channels = []
    for channel in channels.CHANNELS:
        Channels.append(str(channel.name))
    return sorted(Channels, key=str.casefold)
   
def showOtherChannels():
    for channel in channels.CHANNELS:
        logoImage = xbmcvfs.translatePath(os.path.join(LOGO_PATH, str(channel.id) + '.png'))
        __log('3 logoImage= %r'% logoImage)
        if xbmcvfs.exists(logoImage):
            ###__log('logoImage EXISTS %r'% logoImage)
            item = xbmcgui.ListItem(channel.name)
            item.setArt({ 'icon': logoImage, 'thumb' : logoImage })
        else:
            ###__log('logoImage DO NOT EXISTS %r'% logoImage)
            item = xbmcgui.ListItem(channel.name)
            item.setArt({ 'icon': ICON, 'thumb' : ICON })
        menu=[]
        if krogsbellswitchavailable():
            menutext = ADDON.getLocalizedString(30405)   ### Switch Krogsbell Addons
            menu.append(('[COLOR blue][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?switch=other)'% (sys.argv[0]))) 
        item.addContextMenuItems(items=menu, replaceItems=True)
        item.setProperty('IsPlayable', 'true')
        item.setProperty('Fanart_Image', FANART)
        item.setInfo(type='music', infoLabels={
            'title': channel.name,
            'genre': 'genre395',
            'rating': int(utils.ADDONgetSetting('setvolumen'))/10
        })
        xbmcplugin.addDirectoryItem(HANDLE, PATH + '?playOther=%s' % channel.id, listitem = item)

    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(HANDLE)
    
def showEPGm():
    __log('showEPGm START')
    default_list_item = 0
    show_list_item = 0
    PlayingFound = False
    preferredstation = ADDON.getSetting('preferredstation') ### DR P4 København
    backupstation    = ADDON.getSetting('backupstation') ### DR P5
    P4selected       = ADDON.getSetting('selectedp4station')
    
    try:
        for radioEPGi in channelsDR.CHANNELS:
            menu=[]
            station_id = radioEPGi.name
            menutext = ADDON.getLocalizedString(30401) ### Preferred Station
            menu.append(('[COLOR blue][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?setPref=%s)'% (sys.argv[0],radioEPGi.name)))   
            menutext = ADDON.getLocalizedString(30402)   ### Backup Station
            menu.append(('[COLOR yellow][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?setBckup=%s)'% (sys.argv[0],radioEPGi.name)))   
            if 'P4' in station_id and not station_id == P4selected:
                menutext = ADDON.getLocalizedString(30400)   ### Select P4 Station
                menu.append(('[COLOR red][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?setP4=%s)'% (sys.argv[0],radioEPGi.name)))   
            if krogsbellswitchavailable():
                menutext = ADDON.getLocalizedString(30405)   ### Switch Krogsbell Addons
                menu.append(('[COLOR blue][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?switch=other)'% (sys.argv[0]))) 
            logoImage = xbmcvfs.translatePath(os.path.join(LOGO_PATH, str(radioEPGi.icon) + '.png'))
            __log('2 logoImage= %r'% logoImage)
            if station_id == preferredstation:
                station_id = '[COLOR blue][B]' + station_id + '[/B][/COLOR]' 
            if station_id == backupstation:
                station_id = '[COLOR yellow][B]' + station_id + '[/B][/COLOR]' 
            if station_id == P4selected:
                station_id = '[COLOR red][B]' + station_id + '[/B][/COLOR]' 
            if xbmcvfs.exists(logoImage):
                ###__log('logoImage EXISTS %r'% logoImage)
                item = xbmcgui.ListItem(station_id)
                item.setArt({ 'icon': logoImage, 'thumb' : logoImage })
            else:
                ###__log('logoImage DO NOT EXISTS %r'% logoImage)
                item = xbmcgui.ListItem(station_id)
                item.setArt({ 'icon': ICON, 'thumb' : ICON })
            __log('station_id= %r ' % station_id)

            item.setProperty('IsPlayable', 'true')
            item.addContextMenuItems(items=menu, replaceItems=True)
            item.setProperty('Fanart_Image', FANART)
            __log('#446')
            item.setInfo(type='music', infoLabels={
                'title': station_id,
                'genre': 'genre444',
                'rating': int(utils.ADDONgetSetting('setvolumen'))/10
            })
            xbmcplugin.addDirectoryItem(HANDLE, PATH + '?playEPG=%s' % station_id, item)
            __log('radioEPGi.name= %r' % radioEPGi.name)
            __log('ProgramPlaying= %r' % ProgramPlaying)
            if radioEPGi.name == ProgramPlaying and not PlayingFound:
                PlayingFound = True
                show_list_item = default_list_item + 2
            else:
                default_list_item += 1
            __log('PlayingFound= %r' % PlayingFound)
            __log('default_list_item= %r' % default_list_item)
            __log('show_list_item= %r' % show_list_item)
    except Exception as e:
        __log('ERROR in showEPGm: %r' % e)
        pass

    ### DO NOT SORT xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    try:
        __log('default_list_item= %r' % default_list_item)
        win = xbmcgui.Window(xbmcgui.getCurrentWindowId())
        __log('xbmcgui.Window= %r' % win)
        cid = win.getFocusId()
        __log('win.getFocusId= %r' % cid)
        xbmc.executebuiltin('SetFocus(%s, %s)' % (cid, show_list_item))
    except Exception as e:
        __log('ERROR in showEPGm SetFocus: %r' % e)
        pass
    xbmcplugin.endOfDirectory(HANDLE)
    
def getvolumenepg(station):
    laststop = ADDON.getSetting('laststop')
    __log('laststop= %r' % laststop)
    laststopdate = laststop.replace("'","")[:10]
    __log('laststopdate= %r' % laststopdate)
    __log('now()= %r' % now())
    __log('TS(laststopdate+T12:00:00+00:00 = %r ' % TS(laststopdate+'T12:00:00+00:00'))
    if now() > TS(laststopdate+'T12:00:00+00:00') :
        laststop = '[COLOR red][B] ' + ADDON.getLocalizedString(30428) + ' ' + laststopdate + '[/B][/COLOR]'
    else:
        laststop = '[COLOR lightgreen] ' + ADDON.getLocalizedString(30429) + ' [/COLOR]'
    volum = utils.ADDONgetSetting('setvolumen') 
    __log('getvolumenepg(station= %r)= %r' % (station,volum))
    volum += laststop 
    if volum:
        station += ADDON.getLocalizedString(30390) + '\n[I]' + ADDON.getLocalizedString(30416) + volum + ' ' + ADDON.getSetting('titleupdating') + '[/I]'
    elif ADDON.getSetting('titleupdating'):
        station += ADDON.getLocalizedString(30390) + '\n[I]' + ' ' + ADDON.getSetting('titleupdating') + '[/I]'
    else:
        station += ADDON.getLocalizedString(30390)
    return station
    
def getSchedule(dataepg,station_id):   ### returns channelTitle, channelSlug, [schedule]
    datadict = xmltodict.parse(dataepg)
    __log('538 len(datadict)= %r' % len(datadict))
    __log('539 datadict= %r' % datadict)
    Channelfile = os.path.join(datapath, station_id + '.dic')  ### filename here 2022-05-31
    __log('540 Channelfile= %r' % Channelfile)
    try:
        with open(Channelfile,'w') as output:
            ###output.write('%r'% datadict)
            s = '%r'% datadict
            __log('545 s= %r' % s)
            output.write(s)
            
    except Exception as e:
        pass
        __log('546 write error Channelfile.dic= %r' % e)
    masterkey = '-html-body-script-0-'
    __log('548 masterkey= %r' % masterkey)
    datadict = datadict['html']['body']['script'][0]
    __log('550 datadict= %r' % datadict)
    dict_keys = list(datadict.keys())
    __log('552 dict_keys= %r' % dict_keys)
    Channelfile = os.path.join(datapath, station_id + masterkey + '.keys')
    try:
        with open(Channelfile,'w') as output:
            output.write(repr(dict_keys))
    except Exception as e:
        pass
        __log('559 write error Channelfile.keys= %r' % e)
    for i in range(len(dict_keys)):
        key = dict_keys[i]
        name = datadict[key] 
        __log('563 datadict[key= %r]= %r' % (key,name))
        if isinstance(name, list):
            for j in range(len(name)):
                Channelfile = os.path.join(datapath, station_id + masterkey + key + str(j) + '.dic')
                __log('567 datadict[key= %r]= %r' % (key,j))
                __log('568 datadict[key= %r] to %r' % (key,Channelfile))
                try:
                    with open(Channelfile,'w') as output:
                        output.write(repr(name[j]))
                except Exception as e:
                    pass
                    __log('578 write error Channelfile.keys= %r' % e)
        else:
            Channelfile = os.path.join(datapath, station_id + masterkey + key + '.dic')
            __log('573 datadict[key= %r] to %r' % (key,Channelfile))
            try:
                with open(Channelfile,'w') as output:
                    output.write(repr(name))
            except Exception as e:
                pass
                __log('587 write error Channelfile.keys= %r' % e)
        schedule = []
        __log('577 key= %r' % key)
        if key == '#text' :
            __log('579 key= %r' % key)
            datapanel = simplejson.loads(name)
            __log('581 datapanel= %r' % datapanel)
            channelTitle= datapanel['props']['pageProps']['schedule']['channel']['title']
            __log('582 channelTitle= %r' % channelTitle)
            channelSlug = datapanel['props']['pageProps']['schedule']['channel']['slug']
            __log('624 channelSlug= %r' % channelSlug)
            items = datapanel['props']['pageProps']['schedule']['items']
            for j in range(len(items)):
                startTime = datapanel['props']['pageProps']['schedule']['items'][j]['startTime']
                __log('628 startTime= %r' % startTime)
                endTime = datapanel['props']['pageProps']['schedule']['items'][j]['endTime']
                __log('630 endTime= %r' % endTime)
                title = datapanel['props']['pageProps']['schedule']['items'][j]['title']
                __log('634 title= %r' % title)
                try:
                    description = datapanel['props']['pageProps']['schedule']['items'][j]['description']
                    __log('636 description= %r' % description)
                except Exception as e:
                    pass
                    description = ''
                schedule.append([channelTitle,channelSlug,startTime,endTime,title,description])
            
            __log('Schedule= %r' % schedule)
            Channelfile = os.path.join(datapath, station_id + masterkey + key + '.json')
            try:
                with open(Channelfile,'w') as output:
                    output.write(repr(schedule))
            except Exception as e:
                pass
                __log('621 write error Channelfile.keys= %r' % e)
    return [channelTitle, channelSlug, schedule]

def shareLogs(change): ### Only change = True in this file only
    sharepath = ADDON.getSetting('sharepath')
    __log('603 shareLogs sharepath= %r' % sharepath)
    ###if not os.path.exists(sharepath):
    ###    os.mkdir(sharepath)
    ###    __log('606 folder created: %r' % sharepath)
    ###    open(sharepath, 'a').close()
    
    dest = 'DestinationNotSetYet'
    try:
        if sharepath != '':
            destname = (str(xbmc.getInfoLabel('System.FriendlyName'))+'-'+ADDONname).replace(' ','')
            dest = os.path.join(sharepath,destname)
            __log('613 logs to= %r' % dest)
            
            ADDON.setSetting('Excution 1', 'Before Copy Files')
            datapath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
            if not change :
                file = destname+'-kodi.log'
                destf = os.path.join(sharepath,file)
                sourf = xbmcvfs.translatePath(os.path.join('special://logpath', 'kodi.log'))
                ###xbmcvfs.copy(sourf, destf)
                if os.path.exists(sourf):
                    copyOK = xbmcvfs.copy(sourf, destf)
                    if not copyOK:
                        __log('Copy of kodi.log failed')
                __log('619 kodi.log from= %r' % sourf)
                __log('620 kodi.log to= %r' % destf)
                
                file = destname+'-addon.log'
                destf = os.path.join(sharepath,file)
                sourf = xbmcvfs.translatePath(os.path.join(datapath, 'addon.log'))
                if os.path.exists(sourf):
                    copyOK = xbmcvfs.copy(sourf, destf)
                    if not copyOK:
                        __log('Copy of addon.log failed')
                __log('627 addon.log from= %r' % sourf)
                __log('628 addon.log to= %r' % destf)
            ###settingUpdated = False    
            if change :
                file = destname+'-settings.cng'
                cngf = os.path.join(sharepath,file)
                localcngf = xbmcvfs.translatePath(os.path.join(datapath, 'settings.cng'))
                ADDON.setSetting('Excution 2', 'cngf = %r' % cngf)
                try:
                    copyOK = xbmcvfs.copy(cngf, localcngf)
                    if not copyOK:
                        __log('Copy of settings.cng failed')
                        ADDON.setSetting('Exception 1', 'Copy of settings.cng failed')
                    if os.path.isfile(localcngf) :
                        ADDON.setSetting('Excution 3', 'localcngf = %r' % localcngf)
                        file = open(localcngf,'r',encoding='utf-8')
                        desc = file.read()
                        ADDON.setSetting('Excution 4', 'desc = %r' % desc)
                        file.close()
                        params = desc.split('<setting id="')[1]
                        ADDON.setSetting('Excution 5', 'params = %r' % params)
                        param = params.split('"')[0]
                        ADDON.setSetting('Excution 6', 'param = %r' % param)
                        values = params.split('>')[1].split('<')[0]
                        ADDON.setSetting('Excution 7', 'values = %r' % values)
                        ADDON.setSetting(param, values)
                        xbmcvfs.delete(cngf)
                        xbmcvfs.delete(localcngf)
                        ###settingUpdated = True
                except Exception as e:
                    pass
                    ADDON.setSetting('Exception', repr(e))
            
            ADDON.setSetting('Excution 9', 'Before Copy settings.xml')
            if not change :
                file = destname+'-settings.xml'
                destf = os.path.join(sharepath,file)
                sourf = xbmcvfs.translatePath(os.path.join(datapath, 'settings.xml'))
                if os.path.exists(sourf):
                    copyOK = xbmcvfs.copy(sourf, destf)
                    ###if settingUpdated :
                    ###    copyOKreturn = xbmcvfs.copy(destf, sourf)
                    if not copyOK:
                        __log('Copy of settings.xml failed')
                    ###if not copyOKreturn:
                    ###    __log('Copy back of settings.xml failed')
                __log('653 settings.xml from= %r' % sourf)
                __log('654 settings.xml to= %r' % destf)
            
    except Exception as  e:
        pass 
        __log('Change setting or Copy shareLogs to sharepath= %r FAILED: %r' % (dest, e))
  
def showEPG():
    __log('showEPG START')
    shareLogs(True)
    default_list_item = 0
    show_list_item = 0
    program_list_item = 0
    PlayingFound = False
    EPGWindowId = repr(xbmcgui.getCurrentWindowId())
    utils.logdev('window','showEPG module= %r, CurrentWindowIdWindowId= %r' % (module, EPGWindowId))
    ADDON.setSetting('EPGWindowId',EPGWindowId)
    
    try:
        ProgramPlaying   = ADDON.getSetting('ProgramPlaying')
        preferredstation = ADDON.getSetting('preferredstation') 
        backupstation    = ADDON.getSetting('backupstation')
        epglines         = int(ADDON.getSetting('epglines'))
        items          = []
        WantedPrograms = []
        NogoPrograms   = []
        logoImageP = ''
        P4selected = ADDON.getSetting('selectedp4station')
        for radioEPGi in channelsDR.CHANNELS:
            if ProgramPlaying == radioEPGi.name:
                logoImageP = xbmcvfs.translatePath(os.path.join(LOGO_PATH, str(radioEPGi.icon) + '.png'))
                break
        for radioEPGi in channelsDR.CHANNELS:
            station_id = radioEPGi.name
            station = ''
            
            if station_id == preferredstation:
                station = getvolumenepg(station)
                """laststop = ADDON.getSetting('laststop')
                if laststop :
                    laststop = ' *** ' + laststop
                volum = utils.ADDONgetSetting('setvolumen') + laststop  ### 2021-09-23
                if volum:
                    station += ADDON.getLocalizedString(30390) + '\n[I]' + ADDON.getLocalizedString(30416) + volum + ' ' + ADDON.getSetting('titleupdating') + '[/I]'
                elif ADDON.getSetting('titleupdating'):
                    station += ADDON.getLocalizedString(30390) + '\n[I]' + ' ' + ADDON.getSetting('titleupdating') + '[/I]'
                else:
                    station += ADDON.getLocalizedString(30390)
                """
            if station_id == backupstation:
                station += ADDON.getLocalizedString(30391)
            ###station += ' ' + ADDON.getLocalizedString(30404) + ': ' + ProgramPlaying
            descriptionP = ADDON.getLocalizedString(30404) + ': ' + ProgramPlaying + '\n[B]' + ADDON.getLocalizedString(30390) + '[/B] ' + preferredstation + '\n[B]' + ADDON.getLocalizedString(30391) + '[/B] ' + backupstation
            if 'P4' in station_id and not station_id == P4selected:
                __log('Ignore Station: %r' % station_id)
            else:
                radioEPG  = radioEPGi.epg
                __log('498 station_id= %r, radioEPG= %r ' % (station_id,radioEPG))
                radioEPG = radioEPG.replace('https:','http:')   ### 2021-06-07
                radioEPG = radioEPG.replace('www.dr.dk','dr.dk')   ### 2021-06-07
                __log('501 station_id= %r, radioEPG= %r ' % (station_id,radioEPG))
                if 'https' in radioEPG:
                    import ssl
                    # This restores the same behavior as before.
                    context = ssl._create_unverified_context()
                    file = urlopen(radioEPG, context=context)
                else:
                    file = urlopen(radioEPG)
                dataepg = file.read()
                Channelfile = os.path.join(datapath, station_id + '.xml')  ### filename here 2022-05-31
                with open(Channelfile,'wb') as output:
                    output.write(dataepg)
                __log('510 dataepg= %r' % dataepg)
                file.close() 
                Schedule = getSchedule(dataepg,station_id)   ### returns channelTitle, channelSlug, [schedule]
                """
                datadict = xmltodict.parse(dataepg)
                __log('594 datadict= %r' % datadict)
                __log('595 len(datadict)= %r' % len(datadict))
                Channelfile = os.path.join(datapath, station_id + '.dic')  ### filename here 2022-05-31
                with open(Channelfile,'w') as output:
                    output.write(repr(datadict))
                masterkey = '-html-body-script-0-'
                datadict = datadict['html']['body']['script'][0]
                dict_keys = list(datadict.keys())
                __log('600 dict_keys= %r' % dict_keys)
                Channelfile = os.path.join(datapath, station_id + masterkey + '.keys')
                with open(Channelfile,'w') as output:
                    output.write(repr(dict_keys))
               
                for i in range(len(dict_keys)):
                    key = dict_keys[i]
                    name = datadict[key] 
                    if isinstance(name, list):
                        for j in range(len(name)):
                            Channelfile = os.path.join(datapath, station_id + masterkey + key + str(j) + '.dic')  
                            with open(Channelfile,'w') as output:
                                output.write(repr(name[j]))
                    else:
                        Channelfile = os.path.join(datapath, station_id + masterkey + key + '.dic')
                        with open(Channelfile,'w') as output:
                            output.write(repr(name))
                    schedule = []
                    if key == '#text' :
                        datapanel = simplejson.loads(name)
                        channelTitle= datapanel['props']['pageProps']['schedule']['channel']['title']
                        __log('622 channelTitle= %r' % channelTitle)
                        channelSlug = datapanel['props']['pageProps']['schedule']['channel']['slug']
                        __log('624 channelSlug= %r' % channelSlug)
                        items = datapanel['props']['pageProps']['schedule']['items']
                        for j in range(len(items)):
                            startTime = datapanel['props']['pageProps']['schedule']['items'][j]['startTime']
                            __log('628 startTime= %r' % startTime)
                            endTime = datapanel['props']['pageProps']['schedule']['items'][j]['endTime']
                            __log('630 endTime= %r' % endTime)
                            title = datapanel['props']['pageProps']['schedule']['items'][j]['title']
                            __log('634 title= %r' % title)
                            try:
                                description = datapanel['props']['pageProps']['schedule']['items'][j]['description']
                                __log('636 description= %r' % description)
                            except Exception as e:
                                pass
                                description = ''
                            schedule.append([channelTitle,channelSlug,startTime,endTime,title,description])
                        
                        __log('Schedule= %r' % schedule)
                        Channelfile = os.path.join(datapath, station_id + masterkey + key + '.json')
                        with open(Channelfile,'w') as output:
                            output.write(repr(schedule))
                """
                nowLocal = datestr(now(),'%H:%M')

                title = Schedule[0]
                __log('654 channelTitle= %r' % title)
                if title[0:3] == 'DR ':
                    title = title[3:]
                if title[0:2] == 'P5':
                    title = title[:2]
                if station_id == ProgramPlaying:
                    titlename = '[COLOR lightgreen][B]' + title + '[/B][/COLOR]  ' + station
                else:
                    titlename = '[COLOR yellow][B]' + title + '[/B][/COLOR]  ' + station
                logoImage = xbmcvfs.translatePath(os.path.join(LOGO_PATH, str(radioEPGi.icon) + '.png'))
                __log('1 logoImage= %r' %logoImage)
                if xbmcvfs.exists(logoImageP):
                    ###__log('logoImage EXISTS %r'% logoImage)
                    item = xbmcgui.ListItem(titlename)  ### 2019-09-15 Allways show playing icon
                    item.setArt({ 'icon': logoImageP, 'thumb' : logoImageP })
                else:
                    ###__log('logoImage DO NOT EXISTS %r'% logoImage)
                    item = xbmcgui.ListItem(titlename)
                    item.setArt({ 'icon': ICON, 'thumb' : ICON })
                menu=[]
                if krogsbellswitchavailable():
                    menutext = ADDON.getLocalizedString(30405)   ### Switch Krogsbell Addons
                    menu.append(('[COLOR blue][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?switch=other)'% (sys.argv[0]))) 
                item.addContextMenuItems(items=menu, replaceItems=True)
                item.setProperty('IsPlayable', 'true')
                item.setProperty('Fanart_Image', FANART)
                titlenameX = '[COLOR lightgreen][B]' + ADDON.getLocalizedString(30404) + ': ' + ProgramPlaying + '[/B][/COLOR] (' + nowLocal + ')\n\n' + titlename
                __log('#577')
                item.setInfo(type='music', infoLabels={
                    'title': station_id,
                    #'tracknumber': 12345679,
                    #'discnumber': 13,
                    #'duration': 245999,
                    #'year': 1999,
                    'genre': titlenameX,
                    #'album': 'Pulse1',
                    #'artist': 'Cat',
                    'rating': int(utils.ADDONgetSetting('setvolumen'))/10
                })
                __log('descriptionP= %r' % descriptionP)
                ###__log('getMusicInfoTag()= %r' % item.getMusicInfoTag())
                xbmcplugin.addDirectoryItem(HANDLE, PATH + '?playEPG=%s' % station_id, item)
                __log('xbmcplugin.addDirectoryItem station_id= %r' % station_id)
                if radioEPGi.name == ProgramPlaying and not PlayingFound:
                    PlayingFound = True
                    show_list_item = default_list_item + 2
                    ###show_list_item = program_list_item + 2
                    __log('show_list_item= %r' % show_list_item)
                else:
                    default_list_item += 1
                    program_list_item += 1
                    __log('default_list_item= %r' % default_list_item)
                i = 0
                for program in Schedule[2]:
                    __log('program= %r' % program)
                    ### schedule.append([channelTitle 0,channelSlug 1,startTime 2,endTime 3,title 4,description 5])
                    stop = program[3]
                    laststop = repr(stop)
                    __log('laststop= %r' % laststop)
                    if laststop :
                        ADDON.setSetting('laststop',laststop)
                    start = program[2]
                    startactual = program[2]
                    if TS(stop) > nowTS():
                        title = program[4]  
                        menu=[]
                        menutext = ADDON.getLocalizedString(30392)   ### Wanted Programs
                        menu.append(('[COLOR lightgreen][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?setWanted=%s)'% (sys.argv[0],title.lower())))   
                        menutext = ADDON.getLocalizedString(30393)   ### Nogo Programs
                        menu.append(('[COLOR red][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?setNogop=%s)'% (sys.argv[0],title.lower()))) 
                        if krogsbellswitchavailable():
                            menutext = ADDON.getLocalizedString(30405)   ### Switch Krogsbell Addons
                            menu.append(('[COLOR blue][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?switch=other)'% (sys.argv[0]))) 
                        
                        programswantedASCII = []
                        for x in programswanted:
                            programswantedASCII.append(onlyAscii(x))
                        __log('programswantedASCII= %r' % programswantedASCII)
                        
                        programsnogoASCII = []
                        for x in programsnogo:
                            programsnogoASCII.append(onlyAscii(x))
                        __log('programsnogoASCII= %r' % programsnogoASCII) 
                        
                        for notwanted in programsnogoASCII:
                            __log('title.lower()= %r' % title.lower())
                            __log('onlyAscii(title.lower()= %r' % onlyAscii(title.lower()))
                            if notwanted in onlyAscii(title.lower()):
                                __log('notwanted= %r' % notwanted)
                                if notwanted != '':
                                    title = '[I][COLOR red]' + title + '[/COLOR][/I]' 
                                    NogoPrograms.append([station_id,startactual,stop])
                        
                        for wanted in programswantedASCII:
                            __log('wanted= %r' % wanted)
                            __log('title.lower()= %r' % title.lower())
                            __log('onlyAscii(title.lower()= %r' % onlyAscii(title.lower()))
                            if wanted in onlyAscii(title.lower()):
                                __log('wanted1= %r' % wanted)
                                if wanted != '':
                                    title = '[COLOR lightgreen]' + title + '[/COLOR]'
                                    WantedPrograms.append([station_id,startactual,stop])

                        title = '[B]' + title + '[/B]'
                        description= program[5]
                        
                        if description:
                            title += '\n' + description.replace('\n',' ').strip()
                        title = TwoLines(title)
                        channel= program[0]
                        __log('channel= %r, title= %r' % (channel,title)) 
                        if start != startactual:
                            try:
                                ### 2019-05-21T22:05:00Z
                                timediff = repr(TS(startactual) - TS(start))
                                __log('timediff= %r, startactual= %r, start= %r' % (timediff, startactual, start))
                            except Exception as e:
                                pass
                                timediff = repr(e)
                            title = '[COLOR blue]'+timediff+'[/COLOR] ' + title
                        if i < epglines * 20 or '[I][COLOR red]' in title or '[COLOR lightgreen]' in title:
                            i += 1
                            
                            ###startactualLocal = TSl(startactual)
                            startactualLocal = datestr(TSl(startactual),'%H:%M')
                            stopLocal = datestr(TSl(stop),'%H:%M')
                            ###titlename = startactual[11:-4] + ' - ' + stop[11:-4] + 'X' +startactualLocal+' - ' + stopLocal+ '  ' + title
                            titlename = startactualLocal+' - ' + stopLocal + '  ' + title
                            ###item = xbmcgui.ListItem(titlename, iconImage='x')  ### No icon on program lines
                            item = xbmcgui.ListItem(titlename)
                            item.setArt({ 'icon': logoImageP, 'thumb' : logoImageP })
                            item.addContextMenuItems(items=menu, replaceItems=True)
                            item.setProperty('IsPlayable', 'true')
                            item.setProperty('Fanart_Image', FANART)
                            __log('timediff= %r' %(TS(stop) - TS(start)))
                            titlename = '[COLOR lightgreen][B]' + ADDON.getLocalizedString(30404) + ': ' + ProgramPlaying + '[/B][/COLOR] (' + nowLocal + ')\n'+ADDON.getSetting('titleupdating')+'\n[COLOR yellow][B]' + channel +'[/B][/COLOR]\n\n'+ title
                            __log('titlename= %r' %(titlename))
                            __log('#690')
                            item.setInfo(type='music', infoLabels={
                                'title': title,
                                #'tracknumber': 12345678,
                                #'discnumber': 12,
                                'duration': TS(stop) - TS(start),
                                #'year': 1998,
                                'genre': titlename,
                                #'album': 'Pulse',
                                #'artist': descriptionP,
                                'rating': int(utils.ADDONgetSetting('setvolumen'))/10
                            })
                            xbmcplugin.addDirectoryItem(HANDLE, PATH + '?playEPG=%s' % station_id, item)
                            default_list_item += 1
                            __log('default_list_item(epg entry)= %r' % default_list_item)
                    
    except Exception as e:
        pass
        __log('1 radioEPG ERROR: %r' % e)
    try:
        __log('show_list_item= %r' % show_list_item)
        __log('default_list_item= %r' % default_list_item)
        win = xbmcgui.Window(xbmcgui.getCurrentWindowId())
        __log('xbmcgui.Window= %r' % win)
        cid = win.getFocusId()
        __log('win.getFocusId= %r' % cid)
        xbmc.executebuiltin('SetFocus(%s, %s)' % (cid, show_list_item))
    except Exception as e:
        __log('ERROR in showEPG SetFocus: %r' % e)
        pass
    try:
        ### DO NOT SORT xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
        skin_used = xbmc.getSkinDir()
        __log('skin_used= %r' % skin_used)
        ADDON.setSetting('skin_used',skin_used)
        mediatype = ['','music','song','album','artist']
        content = mediatype[int(ADDON.getSetting('mediatype'))]
        __log('mediatype= %r' % content)
        xbmcplugin.setContent(HANDLE, content)
    except Exception as e:
        pass
        __log('radioEPG Play ERROR: %r' % e)
    """
    mediatype	string - “music”, “song”, “album”, “artist”
    
    if skin_used == 'skin.estuary':
        viewmode = ADDON.getSetting('wideview')
        xbmc.executebuiltin('Container.SetViewMode(%s)' % viewmode) 
    if skin_used == 'skin.confluence':
        xbmc.executebuiltin('Container.SetViewMode(500)') # "Thumbnail" view
    elif skin_used == 'skin.aeon.nox':
        xbmc.executebuiltin('Container.SetViewMode(512)') # "Info-wall" view. 
    """
   
    xbmcplugin.endOfDirectory(HANDLE)

def krogsbellswitchavailable():
    SwFileFolder = os.path.join(xbmcvfs.translatePath('special://masterprofile/'), 'addon_data','krogsbell.switchaddons')
    SwFile = os.path.join(SwFileFolder,'switchaddons.txt')
    if os.path.isfile(SwFile):
        return True
    else:
        return False

def showEPGa():   ### Active channel limited + Wanted and No Go Programs
    __log('showEPGa START')
    shareLogs(True)
    default_list_item = 0
    show_list_item = 0
    PlayingFound = False
    EPGWindowId = repr(xbmcgui.getCurrentWindowId())
    __log('showEPGa CurrentWindowIdWindowId= %r' % EPGWindowId)
    ADDON.setSetting('EPGWindowId',EPGWindowId)
    try:
        __log('showEPGa 1031')
        ProgramPlaying = ADDON.getSetting('ProgramPlaying')
        epglines = int(ADDON.getSetting('epglines'))
        preferredstation = ADDON.getSetting('preferredstation') 
        backupstation    = ADDON.getSetting('backupstation')
        items = []
        WantedPrograms = []
        NogoPrograms   = []
        logoImageP = ''
        P4selected = ADDON.getSetting('selectedp4station')
        laststartstation = ADDON.getSetting('laststartstation')
        laststartstationID = laststartstation[:2]
        laststartstationTime = laststartstation[-8:].replace('d','').replace('h','').replace('m','')
        lastendstation = ADDON.getSetting('lastendstation')
        lastendstationTime = lastendstation[-8:].replace('d','').replace('h','').replace('m','')
        __log('laststartstationID= %r, laststartstationTime= %r, lastendstationTime= %r' % (laststartstationID, laststartstationTime, lastendstationTime))
        for radioEPGi in channelsDR.CHANNELS:
            if ProgramPlaying == radioEPGi.name:
                logoImageP = xbmcvfs.translatePath(os.path.join(LOGO_PATH, str(radioEPGi.icon) + '.png'))
                __log('showEPGa 1050')
                break
        for radioEPGi in channelsDR.CHANNELS:
            station_id = radioEPGi.name
            __log('0 station_id= %r' % station_id)
            station = ''
            if station_id == preferredstation:
                station = getvolumenepg(station)
            if station_id == backupstation:
                station += ADDON.getLocalizedString(30391)
            descriptionP = ADDON.getLocalizedString(30404) + ': ' + ProgramPlaying + '\n[B]' + ADDON.getLocalizedString(30390) + '[/B] ' + preferredstation + '\n[B]' + ADDON.getLocalizedString(30391) + '[/B] ' + backupstation
            if 'P4' in station_id and not station_id == P4selected:
                __log('Ignore Station: %r' % station_id)
            else:
                __log('showEPGa 1064')
                radioEPG  = radioEPGi.epg
                __log('765 station_id= %r, radioEPG= %r ' % (station_id,radioEPG))
                radioEPG = radioEPG.replace('https:','http:')   ### 2021-06-07
                radioEPG = radioEPG.replace('www.dr.dk','dr.dk')   ### 2021-06-07
                __log('768 station_id= %r, radioEPG= %r ' % (station_id,radioEPG))
                if 'https' in radioEPG:
                    import ssl
                    # This restores the same behavior as before.
                    context = ssl._create_unverified_context()
                    file = urlopen(radioEPG, context=context)
                else:
                    file = urlopen(radioEPG)
                
                dataepg = file.read()
                ###__log('775 dataepg= %r' % dataepg)
                file.close() 
                __log('showEPGa 1081')
                Schedule = getSchedule(dataepg,station_id)   ### returns channelTitle, channelSlug, [schedule]
                __log('showEPGa 1083')
                ###datadict = xmltodict.parse(dataepg)
                ### name = datadict['m_sch:message']['schedule']['channel']['name']
                name = Schedule[0]
                __log('name= %r' % name)
                ### typeD = datadict['m_sch:message']['schedule']['channel']['type']   ###2021-09-23 type --> typeD
                ### __log('type= %r' % typeD)
                ### datadict1 = datadict['m_sch:message']['schedule']['programs']
                nowLocal = datestr(now(),'%H:%M')
                ### title = datadict['m_sch:message']['schedule']['channel']['name']
                title = Schedule[0]
                if title[0:3] == 'DR ':
                    title = title[3:]
                if title[0:2] == 'P5':
                    title = title[:2]
                __log('showEPGa 1098')
                if station_id == ProgramPlaying:
                    titlename = '[COLOR lightgreen][B]' + title + '[/B][/COLOR]  ' + station
                else:
                    titlename = '[COLOR yellow][B]' + title + '[/B][/COLOR]  ' + station
                logoImage = xbmcvfs.translatePath(os.path.join(LOGO_PATH, str(radioEPGi.icon) + '.png'))
                ###__log('logoImage= %r' %logoImage)
                __log('showEPGa 1105')
                if xbmcvfs.exists(logoImageP):
                    ###__log('logoImage EXISTS %r'% logoImage)
                    item = xbmcgui.ListItem(titlename)  ### 2019-09-15 Allways show playing icon
                    item.setArt({ 'icon': logoImageP, 'thumb' : logoImageP })
                else:
                    ###__log('logoImage DO NOT EXISTS %r'% logoImage)
                    item = xbmcgui.ListItem(titlename)
                    item.setArt({ 'icon': ICON, 'thumb' : ICON })
                __log('showEPGa 1114')
                menu=[]
                if krogsbellswitchavailable():
                    menutext = ADDON.getLocalizedString(30405)   ### Switch Krogsbell Addons
                    menu.append(('[COLOR blue][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?switch=other)'% (sys.argv[0]))) 
                item.addContextMenuItems(items=menu, replaceItems=True)
                item.setProperty('IsPlayable', 'true')
                item.setProperty('Fanart_Image', FANART)
                titlenameX = '[COLOR lightgreen][B]' + ADDON.getLocalizedString(30404) + ': ' + ProgramPlaying + '[/B][/COLOR] (' + nowLocal + ')\n'+ADDON.getSetting('titleupdating')+'\n' + titlename
                __log('showEPGa 1123')
                item.setInfo(type='music', infoLabels={
                    'title': station_id,
                    #'tracknumber': 12345679,
                    #'discnumber': 13,
                    #'duration': 245999,
                    #'year': 1999,
                    'genre': titlenameX,
                    #'album': 'Pulse1',
                    #'artist': 'Cat',
                    'rating': int(utils.ADDONgetSetting('setvolumen'))/10
                })
                __log('descriptionP= %r' % descriptionP)
                ###__log('getMusicInfoTag()= %r' % item.getMusicInfoTag())
                xbmcplugin.addDirectoryItem(HANDLE, PATH + '?playEPG=%s' % station_id, item)
                if radioEPGi.name == ProgramPlaying and not PlayingFound:
                    PlayingFound = True
                    show_list_item = default_list_item + 3   ### show actual program EPG
                else:
                    default_list_item += 1
                ###if  station_id == ProgramPlaying :
                __log('showEPGa 1144')
                if 1 == 1:
                    i = 0
                    ### __log('datadict1= %r' % datadict1)
                    if Schedule[2] != None:
                        for program in Schedule[2]:
                            ### schedule.append([channelTitle 0,channelSlug 1,startTime 2,endTime 3,title 4,description 5])
                            __log('program= %r' % program)
                            stop = program[3]
                            laststop = repr(stop)
                            __log('laststop= %r' % laststop)
                            if laststop :
                                ADDON.setSetting('laststop',laststop)
                            ###stop = program['pro_publish']['ppu_stop_timestamp_presentation_utc']
                            start = program[2]
                            startactual = program[2]
                            if TS(stop) > nowTS():
                                title = program[4]  
                                menu=[]
                                menutext = ADDON.getLocalizedString(30392)   ### Wanted Programs
                                menu.append(('[COLOR lightgreen][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?setWanted=%s)'% (sys.argv[0],title.lower())))   
                                menutext = ADDON.getLocalizedString(30393)   ### Nogo Programs
                                menu.append(('[COLOR red][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?setNogop=%s)'% (sys.argv[0],title.lower()))) 
                                
                                if krogsbellswitchavailable():
                                    menutext = ADDON.getLocalizedString(30405)   ### Switch Krogsbell Addons
                                    menu.append(('[COLOR blue][B]%s[/B][/COLOR]'% menutext,'RunPlugin(%s?switch=other)'% (sys.argv[0]))) 
                                
                                if station_id == laststartstationID:
                                    if ison(laststartstationTime,lastendstationTime,TSl(stop)):
                                        title = '[COLOR lightblue]' + title + '[/COLOR]' 
                                programswantedASCII = []
                                for x in programswanted:
                                    programswantedASCII.append(onlyAscii(x))
                                __log('programswantedASCII= %r' % programswantedASCII)
                                
                                programsnogoASCII = []
                                for x in programsnogo:
                                    programsnogoASCII.append(onlyAscii(x))
                                __log('programsnogoASCII= %r' % programsnogoASCII) 
                                
                                for notwanted in programsnogoASCII:
                                    __log('title.lower()= %r' % title.lower())
                                    __log('onlyAscii(title.lower()= %r' % onlyAscii(title.lower()))
                                    if notwanted in onlyAscii(title.lower()):
                                        __log('notwanted= %r' % notwanted)
                                        if notwanted != '':
                                            title = '[I][COLOR red]' + title + '[/COLOR][/I]' 
                                            NogoPrograms.append([station_id,startactual,stop])
                                
                                for wanted in programswantedASCII:
                                    __log('wanted= %r' % wanted)
                                    __log('title.lower()= %r' % title.lower())
                                    __log('onlyAscii(title.lower()= %r' % onlyAscii(title.lower()))
                                    if wanted in onlyAscii(title.lower()):
                                        __log('wanted1= %r' % wanted)
                                        if wanted != '':
                                            title = '[COLOR lightgreen]' + title + '[/COLOR]'
                                            WantedPrograms.append([station_id,startactual,stop])

                                title = '[B]' + title + '[/B]'
                                ### punchline= program[5]
                                ### if punchline:
                                ###    title += ' - ' + punchline.replace('\n',' ').strip()
                                description= program[5]
                                
                                if description:
                                    title += '\n' + description.replace('\n',' ').strip()
                                title = TwoLines(title)
                                channel= program[0]
                                __log('channel= %r, title= %r' % (channel,title)) 
                                if start != startactual:
                                    try:
                                        ### 2019-05-21T22:05:00Z
                                        timediff = repr(TS(startactual) - TS(start))
                                        __log('timediff= %r, startactual= %r, start= %r' % (timediff, startactual, start))
                                    except Exception as e:
                                        pass
                                        timediff = repr(e)
                                    title = '[COLOR blue]'+timediff+'[/COLOR] ' + title
                                ###if i < epglines:
                                if (i < epglines and station_id == ProgramPlaying) or '[I][COLOR red]' in title or '[COLOR lightgreen]' in title or '[COLOR lightblue]' in title:
                                    i += 1
                                    
                                    ###startactualLocal = TSl(startactual)
                                    startactualLocal = datestr(TSl(startactual),'%H:%M')
                                    stopLocal = datestr(TSl(stop),'%H:%M')
                                    ###titlename = startactual[11:-4] + ' - ' + stop[11:-4] + 'X' +startactualLocal+' - ' + stopLocal+ '  ' + title
                                    titlename = startactualLocal+' - ' + stopLocal + '  ' + title
                                    ###item = xbmcgui.ListItem(titlename, iconImage='x')  ### No icon on program lines
                                    item = xbmcgui.ListItem(titlename)
                                    item.setArt({ 'icon': logoImageP, 'thumb' : logoImageP })
                                    item.addContextMenuItems(items=menu, replaceItems=True)
                                    item.setProperty('IsPlayable', 'true')
                                    item.setProperty('Fanart_Image', FANART)
                                    __log('timediff= %r' %(TS(stop) - TS(start)))
                                    titlename = '[COLOR lightgreen][B]' + ADDON.getLocalizedString(30404) + ': ' + ProgramPlaying + '[/B][/COLOR] (' + nowLocal + ')\n'+ADDON.getSetting('titleupdating')+'\n[COLOR yellow][B]' + channel +'[/B][/COLOR]\n\n'+ title
                                    __log('titlename= %r' %(titlename))
                                    __log('#958')
                                    item.setInfo(type='music', infoLabels={
                                        'title': title,
                                        #'tracknumber': 12345678,
                                        #'discnumber': 12,
                                        'duration': TS(stop) - TS(start),
                                        #'year': 1998,
                                        'genre': titlename,
                                        #'album': 'Pulse',
                                        #'artist': descriptionP,
                                        'rating': int(utils.ADDONgetSetting('setvolumen'))/10
                                    })
                                    xbmcplugin.addDirectoryItem(HANDLE, PATH + '?playEPG=%s' % station_id, item)
                        
    except Exception as e:
        pass
        __log('2 radioEPG ERROR: %r' % e)
    
    try:
        ### DO NOT SORT xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
        skin_used = xbmc.getSkinDir()
        __log('skin_used= %r' % skin_used)
        ADDON.setSetting('skin_used',skin_used)
        mediatype = ['','music','song','album','artist']
        content = mediatype[int(ADDON.getSetting('mediatype'))]
        xbmcplugin.setContent(int(sys.argv[1]), content)
    except Exception as e:
        pass
        __log('radioEPG Play ERROR: %r' % e)
    """
    mediatype	string - “music”, “song”, “album”, “artist”
    
    if skin_used == 'skin.estuary':
        viewmode = ADDON.getSetting('wideview')
        xbmc.executebuiltin('Container.SetViewMode(%s)' % viewmode) 
    if skin_used == 'skin.confluence':
        xbmc.executebuiltin('Container.SetViewMode(500)') # "Thumbnail" view
    elif skin_used == 'skin.aeon.nox':
        xbmc.executebuiltin('Container.SetViewMode(512)') # "Info-wall" view. 
    """
    try:
        __log('default_list_item= %r' % default_list_item)
        win = xbmcgui.Window(xbmcgui.getCurrentWindowId())
        __log('xbmcgui.Window= %r' % win)
        cid = win.getFocusId()
        __log('win.getFocusId= %r' % cid)
        xbmc.executebuiltin('SetFocus(%s, %s)' % (cid, show_list_item))
    except Exception as e:
        __log('ERROR in showEPGm SetFocus: %r' % e)
        pass
    xbmcplugin.endOfDirectory(HANDLE)

def playEPG(idx):
    __log('playEPG(idx= %r)'% idx)
    __log('ADDON= %r' % ADDON)
    __log('PATH= %r' % PATH)
    __log('HANDLE= %r' % HANDLE)
    __log('PARAMS= %r' % PARAMS)
    __log('LOGO_PATH= %r' % LOGO_PATH)
    __log('FANART= %r' % FANART)
    try:
        __log('CHANNELS_URL ready to read: %r' % CHANNELS_URL)
        u = urlopen(CHANNELS_URL)
        channelList = simplejson.loads(u.read())
        ###__log('CHANNELS_URL channelList= %r' % channelList)
        datapath   = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        ChannelFile2 = os.path.join(datapath,ADDONid) + '_CHANNELS_URL.txt'
        utils.makeOldFile(ChannelFile2)
        text_file = open(ChannelFile2, "w")
        text_file.write(repr(channelList))
        text_file.close()
        __log('CHANNELS_URL read and copyed: %r' % (CHANNELS_URL))
        u.close()
    except Exception as  ex:
        __log('CHANNELS_URL ERROR: %r' % ex)
        showError(str(ex))
        return
    try:
        for channel in channelList:
            title = channel['Title']
            slug  = channel['Slug']
            if title[0:3] == 'DR ':
                title = title[3:]
            if title[0:2] != 'P4':
                title = title[:2]
            __log('playEPG(title= %r slug= %r)'% (title,slug))
            idxlower = idx.lower()
            if ('p4' in idxlower and idxlower == slug) or idxlower[:2] == slug[:2] and not 'p4' in idxlower: 
                sourceUrl = channel['SourceUrl']
                logoImage = xbmcvfs.translatePath(os.path.join(LOGO_PATH, sourceUrl[sourceUrl.rindex('/') + 1:] + '.png'))
                if xbmcvfs.exists(logoImage):
                    ###__log('logoImage EXISTS %r'% logoImage)
                    item = xbmcgui.ListItem(title)
                    item.setArt({ 'icon': logoImage, 'thumb' : logoImage })
                else:
                    ###__log('logoImage DO NOT EXISTS %r'% logoImage)
                    item = xbmcgui.ListItem(title)
                    item.setArt({ 'icon': ICON, 'thumb' : ICON })
                item.setProperty('IsPlayable', 'true')
                item.setProperty('Fanart_Image', FANART)
                item.setInfo(type='music', infoLabels={
                    'title': title,
                    #'tracknumber': 12345679,
                    #'discnumber': 13,
                    #'duration': 245999,
                    #'year': 1999,
                    'genre': 'genre1057',
                    #'album': 'Pulse1',
                    #'artist': 'Cat',
                    'rating': int(utils.ADDONgetSetting('setvolumen'))/10
                })

                url = None

                if 'StreamingServers' in channel:
                    for server in channel['StreamingServers']:
                        if 'LinkType' in server and server['LinkType'] == 'ICY' and 'Qualities' in server:
                            try:
                                url = server['Server'] + '/' + server['Qualities'][0]['Streams'][0]['Stream']
                                break
                            except:
                                pass
                __log('playEPG(url 503= %r)'% url)
                if url:
                    __log('play-ing-EPG(url= %r)'% url)
                    __log('url= %r' % url)
                    ### data-urn="urn:dr:mu:bundle:5db189f16187cd0b88fe35b7">P5 Fyn<
                    ### data-urn="urn:dr:mu:bundle:5db18a716187cd0b88fe35c7">P5 København
                    ###url = url.replace('https://live-icy.dr.dk/A/A02H.mp3','http://live-icy.gss.dr.dk/A/A25L.mp3') ### P5 Fyn
                    url = url.replace('https://live-icy.dr.dk/A/A02H.mp3','http://live-icy.gss.dr.dk/A/A28L.mp3')  ### P5 København
                    __log('url= %r' % url)
                    ###direct_play(url)
                    
                    logoImage = xbmcvfs.translatePath(os.path.join(LOGO_PATH, title + '.png'))
                    item = xbmcgui.ListItem(path=url)
                    item.setArt({ 'icon': logoImage, 'thumb' : logoImage })
                    item.setInfo(type='music', infoLabels={
                        'title': title,
                        #'tracknumber': 12345678,
                        #'discnumber': 12,
                        #'duration': 245000,
                        #'year': 1998,
                        'genre': 'genre1092',
                        #'album': 'Pulse',
                        #'artist': 'Muse',
                        'rating': int(utils.ADDONgetSetting('setvolumen'))/10
                    })
                    __log('ADDON= %r' % ADDON)
                    __log('PATH= %r' % PATH)
                    __log('HANDLE= %r' % HANDLE)
                    __log('PARAMS= %r' % PARAMS)
                    __log('LOGO_PATH= %r' % LOGO_PATH)
                    __log('FANART= %r' % FANART)
                    ###__log('xbmc.Player().isPlaying(520): %r' % xbmc.Player().isPlaying())
                    ADDON.setSetting('programplaying',idx)
                    xbmcplugin.setResolvedUrl(HANDLE, True, listitem = item)
                    xbmc.executebuiltin('Dialog.Close(busydialog)')
                    utils.logdev('window','PlayEPG module= %r, CurrentWindowIdWindowId= %r' % (module, xbmcgui.getCurrentWindowId()))
                    xbmc.executebuiltin("Container.Refresh")
                    ###__log('xbmc.Player().isPlaying(523): %r' % xbmc.Player().isPlaying())
                    __log('play-ing-EPG-started(url= %r)'% url)
                    break   ### Stop at first match
    except Exception as e:
        pass
        __log('PlayEPG idx: %r\nERROR: %r' % e)

"""
listitem.setInfo(type='Music', infoLabels={'title': a.get('title') or '',
                                           'artist': a.get('artist') or '',
                                           'album': a.get('artist') or '',
                                           'duration': a.get('duration') or 0,
                                           'genre': 'Karaoke',
                                           'lyrics': lyrics})
                                           
setInfo(type, infoLabels)[source]
Sets the listitem’s infoLabels.

Parameters:	
type – string - type of
infoLabels – dictionary - pairs of { label: value }
Available types

Command name	Description
video	Video information
music	Music information
pictures	Pictures informanion
game	Game information
To set pictures exif info, prepend exif: to the label. Exif values must be passed as strings, separate value pairs with a comma. (eg. ``{‘exif:resolution’: ‘720,480’}`` See kodi_pictures_infotag for valid strings.

You can use the above as keywords for arguments and skip certain optional arguments. Once you use a keyword, all following arguments require the keyword.

General Values (that apply to all types):

Info label	Description
count	integer (12) - can be used to store an id for later, or for sorting purposes
size	long (1024) - size in bytes
date	string (d.m.Y / 01.01.2009) - file date

Video Values:
Info label	Description
genre	string (Comedy) or list of strings ([“Comedy”, “Animation”, “Drama”])
country	string (Germany) or list of strings ([“Germany”, “Italy”, “France”])
year	integer (2009)
episode	integer (4)
season	integer (1)
sortepisode	integer (4)
sortseason	integer (1)
episodeguide	string (Episode guide)
showlink	string (Battlestar Galactica) or list of strings ([“Battlestar Galactica”, “Caprica”])
top250	integer (192)
setid	integer (14)
tracknumber	integer (3)
rating	float (6.4) - range is 0..10
userrating	integer (9) - range is 1..10 (0 to reset)
watched	depreciated - use playcount instead
playcount	integer (2) - number of times this item has been played
overlay	integer (2) - range is 0..7 . See Overlay icon types for values
cast	list ([“Michal C. Hall”,”Jennifer Carpenter”]) - if provided a list of tuples cast will be interpreted as castandrole
castandrole	list of tuples ([(“Michael C. Hall”,”Dexter”), (“Jennifer Carpenter”,”Debra”)])
director	string (Dagur Kari) or list of strings ([“Dagur Kari”, “Quentin Tarantino”, “Chrstopher Nolan”])
mpaa	string (PG-13)
plot	string (Long Description)
plotoutline	string (Short Description)
title	string (Big Fan)
originaltitle	string (Big Fan)
sorttitle	string (Big Fan)
duration	integer (245) - duration in seconds
studio	string (Warner Bros.) or list of strings ([“Warner Bros.”, “Disney”, “Paramount”])
tagline	string (An awesome movie) - short description of movie
writer	string (Robert D. Siegel) or list of strings ([“Robert D. Siegel”, “Jonathan Nolan”, “J.K. Rowling”])
tvshowtitle	string (Heroes)
premiered	string (2005-03-04)
status	string (Continuing) - status of a TVshow
set	string (Batman Collection) - name of the collection
setoverview	string (All Batman movies) - overview of the collection
tag	string (cult) or list of strings ([“cult”, “documentary”, “best movies”]) - movie tag
imdbnumber	string (tt0110293) - IMDb code
code	string (101) - Production code
aired	string (2008-12-07)
credits	string (Andy Kaufman) or list of strings ([“Dagur Kari”, “Quentin Tarantino”, “Chrstopher Nolan”]) - writing credits
lastplayed	string (Y-m-d h:m:s = 2009-04-05 23:16:04)
album	string (The Joshua Tree)
artist	list ([‘U2’])
votes	string (12345 votes)
path	string (/home/user/movie.avi)
trailer	string (/home/user/trailer.avi)
dateadded	string (Y-m-d h:m:s = 2009-04-05 23:16:04)
mediatype	string - “video”, “movie”, “tvshow”, “season”, “episode” or “musicvideo”
dbid	integer (23) - Only add this for items which are part of the local db. You also need to set the correct ‘mediatype’!

Music Values:
Info label	Description
tracknumber	integer (8)
discnumber	integer (2)
duration	integer (245) - duration in seconds
year	integer (1998)
genre	string (Rock)
album	string (Pulse)
artist	string (Muse)
title	string (American Pie)
rating	float - range is between 0 and 10
userrating	integer - range is 1..10
lyrics	string (On a dark desert highway…)
playcount	integer (2) - number of times this item has been played
lastplayed	string (Y-m-d h:m:s = 2009-04-05 23:16:04)
mediatype	string - “music”, “song”, “album”, “artist”
dbid	integer (23) - Only add this for items which are part of the local db. You also need to set the correct ‘mediatype’!
listeners	integer (25614)
musicbrainztrackid	string (cd1de9af-0b71-4503-9f96-9f5efe27923c)
musicbrainzartistid	string (d87e52c5-bb8d-4da8-b941-9f4928627dc8)
musicbrainzalbumid	string (24944755-2f68-3778-974e-f572a9e30108)
musicbrainzalbumartistid	string (d87e52c5-bb8d-4da8-b941-9f4928627dc8)
comment	string (This is a great song)

Picture Values:
Info label	Description
title	string (In the last summer-1)
picturepath	string (/home/username/pictures/img001.jpg )
exif*	string (See kodi_pictures_infotag for valid strings)
                                           
"""

def playDR(idx):
    try:
        channel = None
        for c in channelsDR.CHANNELS:
            if c.id == int(idx):
                channel = c
                break

        if channel is None:
            return

        logoImage = xbmcvfs.translatePath(os.path.join(LOGO_PATH, str(channel.id) + '.png'))
        item = xbmcgui.ListItem(path=channel.url)
        item.setArt({ 'icon': logoImage, 'thumb' : logoImage })
        item.setInfo(type='music', infoLabels={
            'title': channel.name,
			'genre': 'genre1247',
            'rating': int(utils.ADDONgetSetting('setvolumen'))/10
        })
        __log('play-ing-EPG(url= %r)'% channel.url)
        ###__log('xbmc.Player().isPlaying(546): %r' % xbmc.Player().isPlaying())
        ADDON.setSetting('programplaying',idx)
        xbmcplugin.setResolvedUrl(HANDLE, True, listitem = item)
        ###__log('xbmc.Player().isPlaying(549): %r' % xbmc.Player().isPlaying())
    except Exception as e:
        pass
        __log('playDR idx: %r\nERROR: %r' % (idx,e))
    
def playOther(idx):
    try:
        channel = None
        for c in channels.CHANNELS:
            if c.id == int(idx):
                channel = c
                break

        if channel is None:
            return

        logoImage = xbmcvfs.translatePath(os.path.join(LOGO_PATH, str(channel.id) + '.png'))
        item = xbmcgui.ListItem(path=channel.url)
        item.setArt({ 'icon': logoImage, 'thumb' : logoImage })
        item.setInfo(type='music', infoLabels={
            'title': channel.name,
            'genre': 'genre1272',
            'rating': int(utils.ADDONgetSetting('setvolumen'))/10
        })
        __log('play-ing-EPG(url= %r)'% channel.url)
        if testHTTP(channel.url):
            ###__log('xbmc.Player().isPlaying(565): %r' % xbmc.Player().isPlaying())
            ADDON.setSetting('programplaying',idx)
            xbmcplugin.setResolvedUrl(HANDLE, True, listitem = item)
            ###__log('xbmc.Player().isPlaying(569): %r' % xbmc.Player().isPlaying())
        else:
            __log('NOT play-ing-EPG(url= %r)'% channel.url)
    except Exception as e:
        pass
        __log('playOther idx: %r\nERROR: %r' % (idx,e))
"""
preferredstation = ADDON.getSetting('preferredstation') ### DR P4 København
backupstation    = ADDON.getSetting('backupstation') ### DR P5
P4selected        = ADDON.getSetting('selectedp4station')
"""
def setP4Channel(P4area):
    try:
        ADDON.setSetting('selectedp4station',P4area)
        utils.logdev('window','setP4Channel module= %r, CurrentWindowIdWindowId= %r' % (module, xbmcgui.getCurrentWindowId()))
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        pass
        __log('setPref ERROR: %r' % e)   

def setPref(P4area):
    try:
        ADDON.setSetting('preferredstation',P4area)
        utils.logdev('window','setPref module= %r, CurrentWindowIdWindowId= %r' % (module, xbmcgui.getCurrentWindowId()))
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        pass
        __log('setPref ERROR: %r' % e)    
    
def setBckup(P4area):
    try:
        ADDON.setSetting('backupstation',P4area)
        utils.logdev('window','setBckup module= %r, CurrentWindowIdWindowId= %r' % (module, xbmcgui.getCurrentWindowId()))
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        pass
        __log('setBckup ERROR: %r' % e)    
    
def setWanted(title):
    programswanted = [title]
    programswanted += ADDON.getSetting('programswanted').split(',')
    programswanted = list(dict.fromkeys(programswanted))
    dialog = xbmcgui.Dialog()
    selection = dialog.multiselect(ADDON.getAddonInfo('name') + ' [COLOR red]' + ADDON.getLocalizedString(30403) + '[/COLOR]', programswanted)
    __log('Selection: %r\n%r' % (selection,programswanted))
    if selection != None:
        programsnow = []
        for prog in selection:
            programsnow.append(programswanted[prog])
        if programsnow == []:
            programsnow = programswanted
        programsnow = list(dict.fromkeys(programsnow))
        try:
            ADDON.setSetting('programswanted',','.join(programsnow)) 
            utils.logdev('window','setWanted module= %r, CurrentWindowIdWindowId= %r' % (module, xbmcgui.getCurrentWindowId()))
            xbmc.executebuiltin("Container.Refresh")
        except Exception as e:
            pass
            __log('setWanted ERROR: %r' % e)    
    
def setNogop(title):
    programswanted = [title]
    programswanted += ADDON.getSetting('programsnogo').split(',')
    programswanted = list(dict.fromkeys(programswanted))
    dialog = xbmcgui.Dialog()
    selection = dialog.multiselect(ADDON.getAddonInfo('name') + ' [COLOR red]' + ADDON.getLocalizedString(30403) + '[/COLOR]', programswanted)
    __log('Selection: %r\n%r' % (selection,programswanted))
    if selection != None:
        programsnow = []
        for prog in selection:
            programsnow.append(programswanted[prog])
        if programsnow == []:
            programsnow = programswanted
        programsnow = list(dict.fromkeys(programsnow))
        try:
            ADDON.setSetting('programsnogo',','.join(programsnow))
            utils.logdev('window','setNogop module= %r, CurrentWindowIdWindowId= %r' % (module, xbmcgui.getCurrentWindowId()))            
            xbmc.executebuiltin("Container.Refresh")
        except Exception as e:
            pass
            __log('setNogopswitch ERROR: %r' % e)    
        
def switch(x):
    dialog = xbmcgui.Dialog()
    addons = []
    try:
        SwFileFolder = os.path.join(xbmcvfs.translatePath('special://masterprofile/'), 'addon_data','krogsbell.switchaddons')
        SwFile = os.path.join(SwFileFolder,'switchaddons.txt')
        if not os.path.exists(SwFileFolder):
            os.mkdir(SwFileFolder)
            open(SwFile, 'a').close()
        __log('SwFile= %r' % SwFile)
        switchfile = open(SwFile, 'r')
        addonsO = switchfile.read()
        switchfile.close() 
        if not ADDONid in addonsO:
            addonsO += '\n' + ADDONname + ':' + ADDONid
            addonsO = addonsO.replace('\n\n\n\n','\n').replace('\n\n\n','\n').replace('\n\n','\n')
            LF = open(SwFile, 'w')
            LF.write(addonsO)
            LF.close()
        ADDON.setSetting('switchaddons',addonsO)
        if addonsO != '' :
            addonsO = addonsO.split('\n')
            for addon in addonsO:
                if addon != '':
                    __log('addon= %r' % addon)
                    newaddon = addon.split(':')
                    if newaddon[1] != ADDONid:
                        try:
                            testAddon = xbmcaddon.Addon(id=newaddon[1])
                            pathTOaddon = os.path.join(xbmcvfs.translatePath('special://home/addons'), newaddon[1])
                            if os.path.exists(pathTOaddon):
                                addons.append(newaddon)
                        except Exception as e:
                            pass
                            __log('testAddon FAILED= %r' % e)
    except Exception as e:
        pass
        addons.append(['ERROR',repr(e)])
    addons = sorted(addons)
    choises = []
    for choise in addons:
       choises.append(choise[0] + ': ' + choise[1])
    if len(choises) > 0:
        selected = dialog.select(ADDON.getAddonInfo('name') + ADDON.getLocalizedString(30418), choises)
        if selected != -1:
            __log('selected Addon= %r - %r' % (addons[selected][0],addons[selected][1]))
            IDdoADDON = addons[selected][1]
            __log('Start Addon= %r' % IDdoADDON)
            try:
                xbmc.executebuiltin('Dialog.Close(busydialog)')   ### 2019-09-03 needed to allow switch addon
                xbmc.executebuiltin('RunAddon(%s)' % IDdoADDON)   
            except Exception as e:
                pass
                __log('switch ERROR: %r' % e)            
            
def onlyAscii (unicrap):
    """This takes a UNICODE string and ignores all characters 128 (0x80) and higher
    """ 
    r = ''
    for i in unicrap:
        if ord(i) >= 0x80:
            pass
        else:
            r += str(i)
    return r

def showError(message):
    ###heading = buggalo.getRandomHeading()
    heading = ADDONname
    line1 = ADDON.getLocalizedString(30900)
    line2 = ADDON.getLocalizedString(30901)
    ###xbmcgui.Dialog().ok(heading, line1, line2, message)
    __log(heading+'\n'+line1+'\n'+line2+'\n'+message)
    
def findprogramsOLD():
    if ADDON.getSetting('autorun').lower() == 'true':
        findP = ADDON.getSetting('LastFindStation')  ### datestr(nowTS(),'h%Hm%Ms%S'))
        __log('findP= %r' % findP)
        if findP == '':
            delta = 800
        else:
            delta = nowTS() - TS(findP)
        __log('delta= %r' % delta)
        
        if delta > 700 or (not xbmc.Player().isPlaying() and delta > 60):
        ###if delta > 700:
            __log('Start findprograms OLD')
            findprograms('00:00:00')
        
def findprograms(delayHMS):
    StopAllStationAlarms()  ###Stop all previous alarms starting programs
    __log('Start findprograms:'+datestr(nowTS(),'d%dh%Hm%Ms%S'))
    ADDON.setSetting('findprograms','Start findprograms:'+datestr(nowTS(),'d%dh%Hm%Ms%S'))
    script = os.path.join(ADDONpath, 'findstation.py')
    __log('script= %r' % script)
    nameAlarm = ADDONid + '-findstations-'+delayHMS.replace(':','')
    __log('nameAlarm= %r' % nameAlarm)
    ###delayHMS = '00:10:00'   ### Run every 10 minutes
    ###delayHMS = '00:00:00'   ### Run once
    __log('delayHMS= %r' % delayHMS)
    ###cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),%s,loop,silent)' % (nameAlarm, script, PATH,delayHMS,delayHMS)
    if delayHMS == '00:00:00':
        cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),%s,silent)' % (nameAlarm, script, PATH,delayHMS,delayHMS)
    else:
        cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),%s,loop,silent)' % (nameAlarm, script, PATH,delayHMS,delayHMS)
    __log('cmd= %s' % cmd)
    try:
        xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
        xbmc.executebuiltin(cmd)  # Activate
    except Exception as e:
        pass
        __log('findprograms ERROR: %r' % e)

if __name__ == '__main__':
    ADDON = xbmcaddon.Addon()
    PATH = sys.argv[0]
    HANDLE = int(sys.argv[1])
    PARAMS = urlparse.parse_qs(sys.argv[2][1:])

    LOGO_PATH = xbmcvfs.translatePath(os.path.join(ADDON.getAddonInfo('path'), 'resources', 'logos'))
    ICON = xbmcvfs.translatePath(os.path.join(ADDON.getAddonInfo('path'), 'icon.png'))
    FANART = xbmcvfs.translatePath(os.path.join(ADDON.getAddonInfo('path'), 'fanart.jpg'))
    ADDON.setSetting('PATH',str(PATH))
    __log('ADDON= %r' % ADDON)
    __log('PATH= %r' % PATH)
    __log('HANDLE= %r' % HANDLE)
    __log('PARAMS= %r' % PARAMS)
    __log('LOGO_PATH= %r' % LOGO_PATH)
    __log('FANART= %r' % FANART)
    ###buggalo.SUBMIT_URL = 'http://tommy.winther.nu/exception/submit.php'
    try:
        shareLogs(True)
        findprogramsOLD()    ### Check if findprograms are running
        if 'show' in PARAMS and PARAMS['show'][0] == 'dr':
            showDRChannels()
        elif 'show' in PARAMS and PARAMS['show'][0] == 'other':
            showOtherChannels()
        elif 'show' in PARAMS and PARAMS['show'][0] == 'epg':
            showEPG()
        elif 'show' in PARAMS and PARAMS['show'][0] == 'epga':
            showEPGa()
        elif 'show' in PARAMS and PARAMS['show'][0] == 'epgm':
            showEPGm()
        elif 'show' in PARAMS and PARAMS['show'][0] == 'drx':
            showDRxChannels()
        elif 'playEPG' in PARAMS:
            __log('playEPG= %r' % PARAMS['playEPG'][0])
            playEPG(PARAMS['playEPG'][0])
        elif 'playDR' in PARAMS:
            __log('playDR= %r' % PARAMS['playDR'][0])
            playDR(PARAMS['playDR'][0])
        elif 'playOther' in PARAMS:
            __log('playOther= %r' % PARAMS['playOther'][0])
            playOther(PARAMS['playOther'][0])
        elif 'setP4' in PARAMS:
            __log('setP4= %r' % PARAMS['setP4'][0])
            setP4Channel(PARAMS['setP4'][0])
        elif 'setPref' in PARAMS:
            __log('setPref= %r' % PARAMS['setPref'][0])
            setPref(PARAMS['setPref'][0])
        elif 'setBckup' in PARAMS:
            __log('setBckup= %r' % PARAMS['setBckup'][0])
            setBckup(PARAMS['setBckup'][0])
        elif 'setWanted' in PARAMS:
            __log('setWanted= %r' % PARAMS['setWanted'][0])
            setWanted(PARAMS['setWanted'][0])
        elif 'setNogop' in PARAMS:
            __log('setNogop= %r' % PARAMS['setNogop'][0])
            setNogop(PARAMS['setNogop'][0])
        elif 'switch' in PARAMS:
            __log('switch= %r' % PARAMS['switch'][0])
            switch(PARAMS['switch'][0])
        elif 'start' in PARAMS:   ### Debug
            __log('start= %r' % PARAMS['start'][0])
            StartProgram(PARAMS['start'][0],nowTS())
        elif 'find' in PARAMS:    ### Debug
            __log('find= %r' % PARAMS['find'][0])
            findprograms('00:00:00')
        elif 'mode' in PARAMS:    ### Debug
            __log('3010= %r' % PARAMS['mode'][0])
            __log('3010= %r' % DaysOfWeek)
            dialog = xbmcgui.Dialog()
            lastselectedchannel = ADDON.getSetting('lastselectedchannel')
            __log('3010 lastselectedchannel= %r' % lastselectedchannel)
            AllChannels = getDRChannels() + getOtherChannels()
            lastselectedchannelnumber = 0
            j = 0
            for cha in AllChannels:
                __log('3010 cha= %r\nlastselectedchannel= %r, j= %r' % (cha,lastselectedchannel,j))
                if cha == lastselectedchannel:
                    __log('3010 cha= %r, j= %r' % (cha,j))
                    lastselectedchannelnumber = j
                    break
                j+=1
            channel = AllChannels[dialog.select(ADDON.getAddonInfo('name') + ADDON.getLocalizedString(30419), AllChannels, False, lastselectedchannelnumber)]
            __log('3010 channel= %r' % channel)
            ADDON.setSetting('lastselectedchannel',str(channel))
            dayofweek = str(dialog.select(ADDON.getAddonInfo('name') + ADDON.getLocalizedString(30418), DaysOfWeek))
            __log('3010-3= %r' % dayofweek)
            actualschedule = 'schedule' + dayofweek
            __log('actualschedule= %r' % actualschedule)      
            schedule = ADDON.getSetting(actualschedule)
            __log('3010-1= %r' % schedule)
            __log('3010-2= %r' % channel)
            starttime= ADDON.getSetting('starttime')
            newstarttime = utils.Numeric(starttime,ADDON.getLocalizedString(30505))
            ADDON.setSetting('starttime',newstarttime)
            __log('3010-4= %r' % newstarttime)
            endtime  = ADDON.getSetting('endtime')
            newendtime = utils.Numeric(endtime,ADDON.getLocalizedString(30506))
            ADDON.setSetting('endtime',newendtime)
            __log('3010-5= %r' % newendtime)
            newschedule = channel + '@' + newstarttime + '-' + newendtime
            if not newschedule in schedule:
                ADDON.setSetting(actualschedule,newschedule + ',' + schedule)
            schedule = ADDON.getSetting(actualschedule)
            __log('3010-6= %r' % schedule)
        else:
            showOverview()

    except Exception as e:
        ###buggalo.onExceptionRaised()
        __log('No buggalo - Error: %r' % e)
