#!/usr/bin/python
# -*- coding: utf-8 -*-
import recordings, utils, locking
import xbmcaddon, xbmc, datetime, os

import definition
ADDON      = definition.getADDON()
ADDONname  = definition.ADDONgetAddonInfo('name')
xbmc.log('service.py in %s' % definition.ADDONgetAddonInfo('name'))
module= 'service.py'
recordings.resetAlarmDatabase()
recordings.addAlarm(module, '1 start', '', '00:00:00', 'options')

def log(infotext,showlength=500):
    debug = definition.ADDONgetSetting('debug').lower()
    if debug in infotext[0:25].lower() and not debug == '':
        utils.logdev('error',module + ': ' + infotext,showlength=showlength)
    else:
        nolog = True
        
utils.logdevreset()
log('error Start')
log('error Version= %r' % utils.version())    
log('error VersionDate= %r' % utils.versiondate())

try:
    utils.deleteset()
    ###reload(sys)  
    ###sys.setdefaultencoding('utf8')
    log('err defaultencoding= %r' % sys.getdefaultencoding())
    Platform = utils.rtmpdumpFilename()
    if not Platform == '':
        utils.notification('[COLOR green]Platform found and set[/COLOR]')
except:
    pass
    log('err FindPlatform FAILED')  # Put in LOG
recordings.addAlarm(module, '2', '', '00:00:00', 'options')    
log('err 34')
locking.recordUnlockAll()
log('err 36')
locking.scanUnlockAll()
log('err 38')
locking.markUnlockAll()
log('err 40')
recordings.addAlarm(module, '3', '', '00:00:00', 'options')
recordings.backupSetupxml()
log('err 42')
recordings.addAlarm(module, '4', '', '00:00:00', 'options')
recordings.restoreLastSetupXml()
log('err 44')
recordings.addAlarm(module, '5', '', '00:00:00', 'options')
###utils.logdevreset()
recordings.cleanTempFiles()
recordings.addAlarm(module, '6', '', '00:00:00', 'options')
recordings.ftvntvlist()  ### also made after EPG Update  
recordings.addAlarm(module, '7', '', '00:00:00', 'options')
log('err 48')
recordings.setAlarm('http-keep-alive-once','http-keep-alive.py','once','00:00:00','silent')
recordings.setAlarm('http-keep-alive-loop','http-keep-alive.py','loop','00:05:30','loop,silent')
utils.sectoHT('04:00')
recordings.setAlarm('cleanup','cleanup.py','once','00:00:00','silent')  ### Run at start 2025-01-21
recordings.setAlarm('cleanup','cleanup.py','loop','24:00:00','loop,silent')  ### Run daily 2025-01-21
###nameAlarmKeep = ADDONname +'http-keep-alive-once' 
###scriptKeep   = os.path.join(definition.ADDONgetAddonInfo('path'), 'http-keep-alive.py')
###cmdKeep = 'AlarmClock(%s,RunScript(%s,%s),00:00:00,silent)' % (nameAlarmKeep, scriptKeep, 'once')
###xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmKeep)
###xbmc.executebuiltin(cmdKeep)  # Active
log('err 41')
###recordings.downloadicons()
definition.ADDONresetSetting('allmessages','')
definition.ADDONresetSetting('RecursiveSearch','false')
definition.ADDONresetSetting('RecordingFromOtherAddon','0')
definition.ADDONresetSetting('Recordings','')   ### Reset setting with recording names
definition.ADDONresetSetting('castsubpr','')    ### Reset cast info
definition.ADDONresetSetting('castsubprcmd','')
definition.ADDONresetSetting('linksWithTimeOut','')
definition.ADDONresetSetting('linksWithTimeOutCount','')
log('err 49')
recordings.addAlarm(module, '8-copykodisetup', '', '00:00:00', 'options')
utils.copykodisetup()        ### Copy userdata xml files from log 2025-02-09
recordings.addAlarm(module, '8-get_free_space_all', '', '00:00:00', 'options')
utils.get_free_space_all()   ### Set all free space markers
recordings.addAlarm(module, '8-krogsbellWatchingVideo', '', '00:00:00', 'options')
utils.krogsbellWatchingVideo()
log('error 79')
if definition.ADDONgetSetting('copyrecordingsdatabase')=='true':
    recordings.setRecordsBase()    ### Copy recordings database to recordings folder
log('error 82')
if definition.ADDONgetSetting('getrecordingsdatabase')=='true':
    recordings.getRecordsBase()    ### Copy recordings database from recordings folder
log('error 85')    
if definition.ADDONgetSetting('enable_record')=='true':
    recordings.addAlarm(module, '9', '', '00:00:00', 'options')
    now = recordings.parseDate(datetime.datetime.now()) 
    startDate=now - datetime.timedelta(days = 10)
    endDate=now + datetime.timedelta(days = 100)
    recordingsActive=recordings.getRecordingsActive(startDate, endDate)
    recordings.addAlarm(module, '10', '', '00:00:00', 'options')
    log('err recordingsActive ' + repr(recordingsActive))
    log('err 56')
    try:
        recordings.backupDataBase()
        recordings.addAlarm(module, '11', '', '00:00:00', 'options')
        recordings.reschedule()
        recordings.addAlarm(module, '12', '', '00:00:00', 'options')
        utils.notification('[COLOR green]Reschedule Complete[/COLOR]')
        definition.ADDONsetSetting('DebugRecording','false')
        log('err 62')
    except Exception as e:
        pass
        recordings.addAlarm(module, 'Reschedule failed', '', '00:00:00', '%r'%e)
        utils.notification('[COLOR red]Reschedule failed:[/COLOR] Check your planned recordings! - Recording Debug has been set')
        definition.ADDONsetSetting('DebugRecording','true')
        log('err 67')
        xbmc.sleep(5000)
recordings.addAlarm(module, '13 ended', '', '00:00:00', 'options')

