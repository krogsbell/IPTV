#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#      Copyright (C) 2014 Tommy Winther
#      http://tommy.winther.nu
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
"""
        <news>[B]Version 2023-02-26[B]
        To add recording to DRNU addon, install Krogsbell IPTV Addon from: https://github.com/krogsbell/IPTV and try the menuoption Switch Krogsbell Addon.
        To add the recording function to a new version of DRNU addon:
        Add the file krogsbell.py together with addon.py in the root
        At resources\lib\addon.py add 'import krogsbell'
        At def playVideo(self, id, kids_channel, path):
        add two lines
        if krogsbell.krogsbellRecord(self, id, kids_channel, path) :  ### Krogsbell addon
            return                                                    ### Krogsbell addon
        At resources\lib\tvapi.py
        add 'import krogsbell' in the start
        and in  many def get_xxx(self, xxx):
        after
        if u.status_code == 200:
            krogsbell.krogsbellGetProgramcard(u.json(), path or id)               ### Krogsbell addon
            return u.json()
        add the line
        krogsbell.krogsbellGetProgramcard(u.json(), path or id)
        Remember some programs do not record outside Denmark unless you use special network settings
        </news>
"""
#
import pickle
import os
import sys
import urllib.parse as urlparse
import re
import datetime
import time
import _strptime
from operator import itemgetter

import xbmc, xbmcvfs
import xbmcgui
import xbmcaddon
import xbmcplugin

from resources.lib import tvapi
from resources.lib import tvgui

import shutil
import base64

import glob

xbmc.log('DRNU: Start')
ADDON      = xbmcaddon.Addon()
ADDONname  = ADDON.getAddonInfo('name')
ADDONid    = ADDON.getAddonInfo('id')
if ADDON.getSetting('enable.debug') == 'true' :
    DEBUGGING  = True
else:
    DEBUGGING  = True  ### Just debug
get_setting = ADDON.getSetting

def bool_setting(name):
    return get_setting(name) == 'true'

def RecordFlagSet(sourceApp,flag):   ### 2018-11-08
    if sourceApp == '':
        ADDONsource = xbmcaddon.Addon()
    else:
        ADDONsource = xbmcaddon.Addon(sourceApp)
    datapath = xbmcvfs.translatePath(ADDONsource.getAddonInfo('profile'))
    recordflag = os.path.join(datapath, 'RecordFlag.txt')
    FlagFile = open(recordflag, 'w')
    # Write to our text file the information we have provided and then goto next line in our file.
    # LogDev.write(repr(module) + ': ' + repr(message) + '\n')
    FlagFile.write(flag)
    FlagFile.close()

def RecordFlagGet(sourceApp):   ### 2018-11-08
    if sourceApp == '':
        ADDONsource = xbmcaddon.Addon()
    else:
        ADDONsource = xbmcaddon.Addon(sourceApp)
    datapath = xbmcvfs.translatePath(ADDONsource.getAddonInfo('profile'))
    recordflag = os.path.join(datapath, 'RecordFlag.txt')
    if os.path.isfile(recordflag):
        FlagFile = open(recordflag, 'r')
        # Write to our text file the information we have provided and then goto next line in our file.
        # LogDev.write(repr(module) + ': ' + repr(message) + '\n')
        flag = FlagFile.read()
    else:
        flag = ''
    return flag

def logdev(module,message):
    if DEBUGGING :
        nowHMS=datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        datapath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        addonlog = os.path.join(datapath, 'addon.log')
        ###xbmc.log('DRNU: logdev before reset')
        logdevreset(addonlog)
        # create lock file
        LogDev = open(addonlog, 'a')
        # Write to our text file the information we have provided and then goto next line in our file.
        # LogDev.write(repr(module) + ': ' + repr(message) + '\n')
        LogDev.write('%s %s: %s\n\n' % (nowHMS, module, message))

def logdevreset(addonlog): 
    xbmc.log('DRNU: logdevreset')
    addonOLDlog = addonlog.replace('.log','OLD.log')
    try:
        size = os.path.getsize(addonlog)
        xbmc.log('DRNU: addon.log size= %r' % size)
        maxsize = 10 * 1024 * 1024 # 1 MB --> TEST 10 MB
        xbmc.log('DRNU: log size= %r' % size)
        if os.path.exists(addonlog) and size > maxsize:
            shutil.copyfile(addonlog, addonOLDlog)
            tries    = 0
            maxTries = 10
            maxSleep = 50
            while os.path.exists(addonlog) and tries < maxTries:
                try:
                    os.remove(addonlog)
                    break
                except:
                    xbmc.sleep(maxSleep)
                    tries = tries + 1
    except Exception as e:
        pass
        xbmc.log('DRNU: Reset addon.log failed: %r' % e)
        
def _DrDkTvAddon__log(text):
    if DEBUGGING :
        logdev('krogsbell.py',text.encode("utf-8"))
        
def __log(text):
    if DEBUGGING :
        logdev('krogsbell.py',text.encode("utf-8"))
    
def printL(message, module = 'krogsbell.py', size=250):
    if DEBUGGING :
        if len(message) > size:
            logdev(module,message[0:size]+'...\n...\n...'+message[-250:]+'\n')
        else:
            logdev(module,message)

def cmp_to_key(mycmp):
    'Convert a cmp= function into a key= function'
    class K:
        def __init__(self, obj, *args):
            self.obj = obj
        def __lt__(self, other):
            return mycmp(self.obj, other.obj) < 0
        def __gt__(self, other):
            return mycmp(self.obj, other.obj) > 0
        def __eq__(self, other):
            return mycmp(self.obj, other.obj) == 0
        def __le__(self, other):
            return mycmp(self.obj, other.obj) <= 0
        def __ge__(self, other):
            return mycmp(self.obj, other.obj) >= 0
        def __ne__(self, other):
            return mycmp(self.obj, other.obj) != 0
    return K

def krogsbellAddons():
    ### Krogsbell IPTV addons have the file 'definition.py'
    addons = []
    try:
        SwFileFolder = os.path.join(xbmcvfs.translatePath('special://masterprofile/'), 'addon_data','krogsbell.switchaddons')
        SwFile = os.path.join(SwFileFolder,'switchaddons.txt')
        if not os.path.exists(SwFileFolder):
            os.mkdir(SwFileFolder)
            open(SwFile, 'a').close()
        printL('SwFile= %r' % SwFile)
        switchfile = open(SwFile, 'r')
        addonsO = switchfile.read()
        switchfile.close() 
        if not ADDONid in addonsO:
            addonsO += '\n' + ADDONrefer + ':' + ADDONid
            addonsO = addonsO.replace('\n\n\n\n','\n').replace('\n\n\n','\n').replace('\n\n','\n')
            LF = open(SwFile, 'w')
            LF.write(addonsO)
            LF.close()
        ADDON.setSetting('switchaddons',addonsO)
        if addonsO != '' :
            addonsO = addonsO.split('\n')
            for addon in addonsO:
                if addon != '':
                    newaddon = addon.split(':')
                    if newaddon[1] != ADDONid:
                        try:
                            testAddon = xbmcaddon.Addon(id=newaddon[1])
                            pathTOaddon = os.path.join(xbmcvfs.translatePath('special://home/addons'), newaddon[1])
                            if os.path.exists(pathTOaddon):
                                addons.append(newaddon)
                        except Exception as e:
                            pass
                            printL('testAddon FAILED= %r' % e)
    except Exception as e:
        pass
        addons.append(['ERROR',repr(e)])
    ###[['GlowIPTV','plugin.video.glowiptv.rec'],['DR NU','plugin.video.drnu'],['BBC iPlayer','plugin.video.iplayerwww'],['ITV Player','plugin.video.itv']]
    addons = sorted(addons)
    choises = []
    for choise in addons:
       choises.append(choise[0] + ': ' + choise[1])
    return choises

def krogsbellAddonsSelect():
    printL('krogsbellAddonsSelect: Start')
    choisesall = krogsbellAddons()
    choises    = []
    progpath   = ADDON.getAddonInfo('path')
    datapath   = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    for choise in choisesall:
        try:
            newADDONid = choise.replace(': ',':').split(':')[1]
            progpathnew= os.path.join(progpath.replace(ADDONid,newADDONid),'definition.py')
            printL('progpathnew= %r' % progpathnew)
            if os.path.exists(progpathnew):
                ### ...\addon_data\...\storage\channels.json
                datapathnew= os.path.join(datapath.replace(ADDONid,newADDONid),'storage','channels.json')
                printL('datapathnew= %r' % datapathnew)
                if not os.path.exists(datapathnew):
                    targetADDON = xbmcaddon.Addon(id=newADDONid)
                    enable_record = targetADDON.getSetting('enable_record')
                    printL('targetADDON= %r, enable_record= %r'% (targetADDON, enable_record))            
                    if enable_record == 'true':
                        printL('choises.append(choise)= %r' % choise)
                        choises.append(choise)
        except Exception as e:
            pass
            choises.append('Error: %r' % e)
    selected = -1
    if len(choises) > 0:
        dialog = xbmcgui.Dialog()
        printL('select(choises)= %r' % choises)
        selected = dialog.select('[B]'+ADDON.getAddonInfo('name') +'[/B][I]'+ ADDON.getLocalizedString(30802)+'[/I]', choises) ####################
        printL('selected choise#= %r' % selected)
    if selected != -1:
        printL('selected Addon = %r ' % choises[selected])
        return choises[selected].replace(': ',':').split(':')[1]
    return ''

def humantime(ts):   ### Timestamp to human time
    try:
        dt = datetime.datetime.fromtimestamp(ts)
        ht = dt.strftime("%Y-%m-%d %H:%M:%S")
        ###ht = dt.strftime("%m-%d %H:%M")
    except Exception as e:
        pass
        __log('humantime ERROR= %r'% e)
    return ht

def deleteOldProgramcards():
    try:
        now = time.time()
        __log('deleteOldProgramcards now= %r'% now)
        timespan = 1 * 86400  ### one day
        ###timespan = 1 * 60  ### one minute - test
        filename = 'programCard*'
        lastProgramCardDelete = 'lastProgramCardDelete.txt'
        datapath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        delmarker = os.path.join(datapath, lastProgramCardDelete)
        if not os.path.isfile(delmarker):
            File = open(delmarker, 'w')
            File.write('deleteOldProgramcards marker created %r' % humantime(now))
            File.close()
        if os.stat(delmarker).st_mtime < now - timespan:
            path = os.path.join(datapath, filename)
            __log('deleteOldProgramcards path= %r'% path)
            for f in glob.glob(path):
              if os.stat(f).st_mtime < now - timespan:
                if os.path.isfile(f):
                  __log('deleteOldProgramcards f= %r'% f)
                  os.remove(os.path.join(path, f))
            File = open(delmarker, 'w')
            File.write('Last delete of ProgramCards %r' % humantime(now))
            File.close()
    except Exception as e:
        pass
        __log('deleteOldProgramcards ERROR= %r'% e)

def krogsbellGetProgramcard(self, programCard, path=''):
    if bool_setting('krogsbell.enabled') :
        try:
            __log('krogsbellGetProgramcard programCard 1= %r'% programCard)
            if path == '':
                path = programCard['path']  ### 2024-03-06
                watchPath = programCard['watchPath'] 
            __log('krogsbellGetProgramcard path= %r'% path)
            __log('krogsbellGetProgramcard watchPath= %r'% watchPath)
            __log('krogsbellGetProgramcard type(path)= %r'% type(path))
            deleteOldProgramcards()
            if type(path) == type(1) :
                desc = str(path)
            elif type(path) == type('path') :
                desc = path.split('_')[-1].split('/')[-1]
            else:
                desc = path
            __log('krogsbellGetProgramcard desc= %r'% desc)
            __log('krogsbellGetProgramcard programCard 2= %r'% programCard)
            __log('krogsbellGetProgramcard programCard_type= %r'% type(programCard))
            filename = 'programCard' + desc + '.txt'
            __log('krogsbellGetProgramcard filename= %r' % filename)
            datapath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
            flag = os.path.join(datapath, filename)
            __log('krogsbellGetProgramcard flag= %r'% flag)
            try:
                File = open(flag, 'wb')
                File.write(b'%r'% programCard)
                File.close()
            except Exception as e:
                pass
                __log('krogsbellGetProgramcard programCard .txt ERROR= %r'% e)
            filename = 'programCard' + desc + '.pickle'
            __log('krogsbellGetProgramcard filename= %r' % filename)
            pickleFile = os.path.join(datapath, filename)
            with open(pickleFile, 'wb') as handle:
                pickle.dump(programCard, handle, protocol=pickle.HIGHEST_PROTOCOL)
        except Exception as e:
            pass
            try: 
                __log('krogsbellGetProgramcard programCard ERROR= %r'% e)
            except:
                pass
    
def krogsbellRecord(self, id, kids_channel, path):
    __log('krogsbellRecord path= %r' % path)
    if not bool_setting('krogsbell.enabled') :
        return False
    try:
        __log('krogsbellRecord path= %r' % path)
        if path.startswith('/kanal'):
            # live stream
            video = self.api.get_livestream(path, with_subtitles=bool_setting('enable.subtitles'))
        elif path.startswith('/film'):
            video = self.api.unfold_list(path)
        else:
            ###self.updateRecentlyWatched(path)
            video = self.api.get_stream(id)
        __log('krogsbellRecord video= %r' % video)
        subs = {}
        for i, sub in enumerate(video['subtitles']):
            subs[sub['language']] = i
            __log('krogsbellRecord subs[sub[language]]= %r' % i)
        kids_channel = kids_channel == 'True'

        if not video['url']:
            self.displayError(tr(30904))
            return False

        item = xbmcgui.ListItem(path=video['url'], offscreen=True)

        if get_setting('inputstream') == 'adaptive':
            is_helper = Helper('hls')
            if is_helper.check_inputstream():
                item.setProperty('inputstream', is_helper.inputstream_addon)
                item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        
        ###krogsbell.krogsbellRecord(video, path)   ### Krogsbell addon previous call
        ###krogsbell(name,url,there_are_subtitles,subtitles_file)
        try:
            subtitlesAvailable = video['subtitles'][1]['isEmbedded']
            subtitles = video['subtitles'][1]['link']
        except Exception as e:
            pass
            try:
                subtitlesAvailable = video['subtitles'][0]['isEmbedded']
                subtitles = video['subtitles'][0]['link']
            except Exception as e:
                pass
                subtitlesAvailable = False
                subtitles = ''
        __log('krogsbellRecord path= %r' % path)
        __log('krogsbellRecord video[subtitles][isEmbedded]= %r' % subtitlesAvailable)
        __log('krogsbellRecord video[subtitles][link]= %r' % subtitles)      
        if krogsbell(self,path,video['url'],subtitlesAvailable,subtitles) :
            return True
        ###krogsbell(name,url,there_are_subtitles,subtitles_file)
    except Exception as e:
        pass
        __log('krogsbellRecord ERROR %r' % e)
        return False
  
def get_info(self, data):
    try:
        __log('get_info data= %r' % data)
        __log('get_info data type= %r'% type(data))
        title = data['title']
        __log('get_info api.get_info 0 title= %r' % title)
        typeD = data['type']
        __log('get_info api.get_info 0 type= %r' % typeD)
        title, infoLabels = self.api.get_info(data)   ### 2023-02-25
        __log('get_info api.get_info 1 title= %r' % title)
        __log('get_info infoLabels= %r' % infoLabels)
    except Exception as e:
        pass
        __log('get_info api.get_info ERROR %r' % e)
    
def descriptionFromProgramcard(self, id):
    __log('descriptionFromProgramcard id= %r' % id)
    desc = id.split('_')[-1].split('/')[-1]
    __log('descriptionFromProgramcard desc= %r' % desc)
    data = {}
    try:
        filename = 'programCard' + desc + '.txt'
        __log('descriptionFromProgramcard filename= %r' % filename)
        datapath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        flag = os.path.join(datapath, filename)
        File = open(flag, 'r')
        programCard = File.read()
        File.close()
    
        filename = 'programCard' + desc + '.pickle'
        __log('descriptionFromProgramcard filename= %r' % filename)
        pickleFile = os.path.join(datapath, filename)
        with open(pickleFile, 'rb') as handle:
            data = pickle.load(handle)
        get_info(self, data)
    except Exception as e:
        pass
        __log('descriptionFromProgramcard filrname ERROR %r' % e)
    datakeys = None
    items = None
    param = ['id','title','duration','releaseYear','shortDescription','description','IsGeoRestricted','PlayButtonExtraDetails','ProductionCountry']
    values= [desc,'','','','','','','','']
    while items == None :
        try:
            datakeys = data.keys()
        except Exception as e:
            pass
            __log('descriptionFromProgramcard data.keys() ERROR= %r' % e)
        __log('descriptionFromProgramcard data.keys()= %r' % datakeys)
        try: 
            values[7] = data['customFields']['PlayButtonExtraDetails']
        except Exception as e:
            pass
            __log('descriptionFromProgramcard customFields PlayButtonExtraDetails ERROR %r' % e)
        try: 
            values[8] = data['customFields']['ProductionCountry']
        except Exception as e:
            pass
            __log('descriptionFromProgramcard customFields ProductionCountry ERROR %r' % e)
        
        if 'entries' in datakeys and len(data['entries']) > 0 :
            try:
                entriesType = type(data['entries'])
                __log('descriptionFromProgramcard entriesType= %r' % entriesType)
                if entriesType == 'dict':
                    __log('descriptionFromProgramcard entriesType == dict')
                    data = data['entries']
                    get_info(self, data)
                else:
                    try:
                        __log('descriptionFromProgramcard entriesType != dict\n%r' % data)
                        data = data['entries'][0]
                        get_info(self, data)
                    except Exception as e:
                        pass    
                        __log('descriptionFromProgramcard entries not dict ERROR %r' % e)
                        if 'type' in datakeys and data['type'] == 'channel':
                            items = data
            except Exception as e:
                pass
                __log('descriptionFromProgramcard entries ERROR %r' % e)
        ###'canonical': '/liste/ta-mest-sete-film_365856'}
        ###elif 'canonical' in datakeys:
        ###    canonicalid = data['canonical']
        ###    descriptionFromProgramcard(self,canonicalid)
        ###    break
        elif 'episodes' in datakeys:
            data = data['episodes']
        elif 'list' in datakeys:
            data = data['list']
        elif 'item' in datakeys:
            data = data['item']
        elif 'items' in datakeys:
            data = data['items']
            items = data
        elif 'type' in datakeys and data['type'] == 'channel':
            items = data
        else:
            items = data
    
        ###items = data['entries'][0]['list']['items']
        __log('descriptionFromProgramcard dict items= %r' % items)
        try:
            itemkeys = items[0].keys()
        except:
            pass
            try:
                itemkeys = items.keys()
            except:
                pass
                itemkeys = ''
        __log('descriptionFromProgramcard itemkeys= %r' % itemkeys)
        __log('descriptionFromProgramcard items= %r' % items)
        try:
            try:
                lenItems = len(items)
                __log('descriptionFromProgramcard lenItems= %r' % lenItems)
            except Exception as e:
                pass
                lenItems = 0
                __log('descriptionFromProgramcard lenItems ERROR %r'% e)
            if 'items' not in itemkeys:
                i = 1
                while i <= len(param)-1 :
                    __log('descriptionFromProgramcard 0 i= %r' % i)
                    __log('descriptionFromProgramcard 0 XXX[%r] param= %r itemkeysT= %r' % (i,param[i],itemkeys))
                    if param[i] in itemkeys :
                        __log('descriptionFromProgramcard 0 [%r] %r= %r' % (i,param[i],values[i]))
                        __log('descriptionFromProgramcard 0 [%r] items= %r' % (i,items))
                        
                        if "%r" % type(items) == "<class 'list'>" :
                            __log('descriptionFromProgramcard items [ type= %r ]' % type(items))
                            __log('descriptionFromProgramcard 0 [%r] items[param[i]]= %r' % (i,items[0][param[i]]))
                            values[i] = str(items[0][param[i]])
                        else:
                            __log('descriptionFromProgramcard items ( type= %r )' % type(items))
                            __log('descriptionFromProgramcard 0 [%r] items[param[i]]= %r' % (i,items[param[i]]))
                            values[i] = str(items[param[i]])
                        __log('descriptionFromProgramcard 1 [%r] %r= %r' % (i,param[i],values[i]))
                    i += 1
            else:
                for o in range(lenItems):
                    idkey = data[o]['id']
                    __log('descriptionFromProgramcard dict items key id %r= %r' % (desc, idkey))
                    i = 1
                    if desc == idkey :
                        while i <= len(param)-1 :
                            __log('descriptionFromProgramcard 1 i= %r' % i)
                            __log('descriptionFromProgramcard 1 XXX[%r] param= %r itemkeysT= %r' % (i,param[i],itemkeys))
                            if param[i] in itemkeys :
                                values[i] = str(items[o][param[i]])
                                __log('descriptionFromProgramcard [%r] %r= %r' % (i,param[i],values[i]))
                            i += 1
        except Exception as e:
            pass
            __log('descriptionFromProgramcard ERROR %r'% e)
        __log('descriptionFromProgramcard values= %r\nparam= %r' % (values, param))
    title = values[1]
    __log('descriptionFromProgramcard title= %r' % title)
    duration = values[2]
    __log('descriptionFromProgramcard duration= %r' % duration)
    releaseYear = values[3]
    __log('descriptionFromProgramcard releaseYear= %r' % releaseYear)
    shortdescription = values[4]
    __log('descriptionFromProgramcard shortdescription= %r' % shortdescription)
    description = values[5]
    __log('descriptionFromProgramcard description= %r' % description)
    IsGeoRestricted = values[6]
    __log('descriptionFromProgramcard IsGeoRestricted= %r' % IsGeoRestricted)
    PlayButtonExtraDetails = values[7]
    __log('descriptionFromProgramcard PlayButtonExtraDetails= %r' % PlayButtonExtraDetails)
    ProductionCountry = values[8]
    __log('descriptionFromProgramcard ProductionCountry= %r' % ProductionCountry)
    
    
    if releaseYear != '':
        title = title + ' (' + releaseYear + ')'
    if ProductionCountry != '':
        title = title + ' [' + ProductionCountry + ']'
    if PlayButtonExtraDetails != '':
        title = title + '[' + PlayButtonExtraDetails + ']'
    if IsGeoRestricted != '':
        title = title + '[' + IsGeoRestricted + ']'
    __log('descriptionFromProgramcard final title= %r' % title)
    if len(shortdescription) >= len(description) :
        description = shortdescription
    return (title, duration, description.replace('/n','NewLine'))
    
def krogsbell(self,name,url,there_are_subtitles,subtitles_file):
    ###def PLAY_STREAM_HLS_LIVE(name,url,iconimage):
    printL('krogsbell(name=%r\n,url=%r\n,there_are_subtitles=%r\n,subtitles_file=%r\n)'% (name,url,there_are_subtitles,subtitles_file))
    cmd  = 'XBMC.Notification(%s, %s, %r, %s)' % (name, url, 10000, '') 
    xbmc.executebuiltin(cmd) 
    title, duration, description = descriptionFromProgramcard(self, name)
    __log('Programcard title= %r' % title)
    __log('Programcard duration= %r' % duration)
    __log('Programcard description= %r' % description)
    if there_are_subtitles == 1:
        subtitles_url = subtitles_file
    else:
        subtitles_url = ''
    if title != '':
        name = title
    ### else keep name from call
        
    if duration != '':
        durtxt = '&duration=' + str(int(duration)//60 +1)
    else:
        durtxt = '&duration=240'
    __log('descriptionFromProgramcard durtxt= %r' % durtxt)
    __log('replace , in name with (nothing) name= %r' % name)
    iconimage = 'DefaultVideo.png'
    krogsbellAddonID = krogsbellAddonsSelect()
    recording = False
    if krogsbellAddonID != '' :
        __log('name1='+name+'[DR NU]')
        name2 = base64b64encode(name+'[DR NU]')
        __log('name2= %r' % name2)
        name3 = base64b64decode(name2)
        __log('name3= %r' % name3)
        __log('uri1='+url)
        uri2 = base64b64encode(url)
        __log('uri2= %r' % uri2)
        uri3 = base64b64decode(uri2)
        __log('uri3= %r' % uri3)
        if not '&description=' in url:
            URI='plugin://'+krogsbellAddonID+'/?url=url&mode=2011&name='+base64b64encode(name+'[DR NU]')+'&OrgTitle='+base64b64encode(name+'[DR NU]')+'&source=' + ADDONid + '&uri='+base64b64encode(url+durtxt+'&OrgTitle='+name+'[DR NU]&description=' + description+'&subtitlesurl='+subtitles_url+'&subtitlesoffset=0')
        else:
            URI='plugin://'+krogsbellAddonID+'/?url=url&mode=2011&name='+base64b64encode(name+'[DR NU]')+'&OrgTitle='+base64b64encode(name+'[DR NU]')+'&source=' + ADDONid + '&uri='+base64b64encode(url+durtxt+'&OrgTitle='+name+'[DR NU]&subtitlesurl='+subtitles_url+'&subtitlesoffset=0')
        __log('URI= %r' % URI)
        __log('URI=decode %r' % base64b64decode(URI))
        try:
            URI = URI.replace('+','AbCdEf')    ### 2024-03-08
            __log('URI=new %r' % URI)
            xbmc.executebuiltin('RunPlugin(%s)' % URI)
            recording = True
        except:
            pass
            __log('No valid Addon to record stream!')
            __log('Play Video')
    return recording


def recordingaddons():
    try:
        addons = []
        SwFileFolder = os.path.join(xbmcvfs.translatePath('special://masterprofile/'), 'addon_data','krogsbell.switchaddons')
        SwFile = os.path.join(SwFileFolder,'switchaddons.txt')
        if not os.path.exists(SwFileFolder):
            os.mkdir(SwFileFolder)
            open(SwFile, 'a').close()
        __log('SwFile= %r' % SwFile)
        switchfile = open(SwFile, 'r')
        addonsO = switchfile.read()
        switchfile.close() 
        if addonsO != '' :
            addonsO = addonsO.split('\n')
            for addon in addonsO:
                if addon != '':
                    __log('addon= %r' % addon)
                    newaddon = addon.split(':')
                    if newaddon[1] != ADDONid:
                        if 'video.' in newaddon[1]:
                            pathTOaddon = os.path.join(xbmcvfs.translatePath('special://home/addons'), newaddon[1])
                            if os.path.exists(pathTOaddon):
                                addons.append(newaddon)
    except Exception as e:
        pass
        addons.append(['ERROR',repr(e)])
    addons = sorted(addons)
    return addons

def TS(timestr):
    ### time format 2019-05-21T22:05:00Z
    time_tuple = time.strptime(timestr, "%Y-%m-%dT%H:%M:%SZ")
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def now():   ### Local time
    dt_obj= datetime.datetime.now()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
   
def nowTS():   ### UTC time
    dt_obj= datetime.datetime.utcnow()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def nowS(format):   ### Now date string UTC time
    time_tuple = time.localtime(nowTS())
    date_str = time.strftime(format, time_tuple)
    return(date_str)
    
def datestr(timestamp,format):   ### Date string UTC time %Y-%m-%dT%H:%M:%SZ
    time_tuple = time.localtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)

def datestrdelta(timestamp,format):   ### Now date string UTC time %Y-%m-%dT%H:%M:%SZ
    time_tuple = time.gmtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)

def base64b64encode(texttoencode):
    ###printL('0 texttoencode= %r' % texttoencode)
    try:
        result = base64.b64encode(texttoencode.encode())
        ###printL('1 result= %r' % result)
    except Exception as e:
        pass
        printL('base64b64encode() ERROR: %r' % e)
        result = base64.b64encode(texttoencode)
        ###printL('2 result= %r' % result)
        
    ###printL('3 result= %r' % result)
    texttoencode = 'b64' + result.decode()
    ###printL('1 texttoencode= %r' % texttoencode)
    return texttoencode
    
def base64b64decode(texttodecode):
    try:
        result = base64.b64decode(texttodecode[3:])
    except Exception as e:
        pass
        printL('base64b64encode() ERROR: %r' % e)
        
    return result
        
    
def switch(x):
    findP = ADDON.getSetting('LastSwitch')  ### datestr(nowTS(),'h%Hm%Ms%S'))
    if findP == '':
        delta = 10
    else:
        delta = nowTS() - TS(findP)
    __log('delta= %r' % delta)
    if delta > 9:
        ADDON.setSetting('LastSwitch',datestr(nowTS(),'%Y-%m-%dT%H:%M:%SZ'))
        dialog = xbmcgui.Dialog()
        addons = []
        try:
            SwFileFolder = os.path.join(xbmcvfs.translatePath('special://masterprofile/'), 'addon_data','krogsbell.switchaddons')
            SwFile = os.path.join(SwFileFolder,'switchaddons.txt')
            if not os.path.exists(SwFileFolder):
                os.mkdir(SwFileFolder)
                open(SwFile, 'a').close()
            __log('SwFile= %r' % SwFile)
            switchfile = open(SwFile, 'r')
            addonsO = switchfile.read()
            switchfile.close() 
            if not ADDONid in addonsO:
                addonsO += '\n' + ADDONname + ':' + ADDONid
                addonsO = addonsO.replace('\n\n\n\n','\n').replace('\n\n\n','\n').replace('\n\n','\n')
                LF = open(SwFile, 'w')
                LF.write(addonsO)
                LF.close()
            ADDON.setSetting('switchaddons',addonsO)
            if addonsO != '' :
                addonsO = addonsO.split('\n')
                for addon in addonsO:
                    if addon != '':
                        __log('addon= %r' % addon)
                        newaddon = addon.split(':')
                        if newaddon[1] != ADDONid:
                            try:
                                testAddon = xbmcaddon.Addon(id=newaddon[1])
                                pathTOaddon = os.path.join(xbmcvfs.translatePath('special://home/addons'), newaddon[1])
                                if os.path.exists(pathTOaddon):
                                    addons.append(newaddon)
                            except Exception as e:
                                pass
                                __log('testAddon FAILED= %r' % e)
        except Exception as e:
            pass
            addons.append(['ERROR',repr(e)])
        addons = sorted(addons)
        choises = []
        for choise in addons:
           choises.append(choise[0] + ': ' + choise[1])
        if len(choises) > 0:
            selected = dialog.select(ADDON.getAddonInfo('name') + ' - Select an Addon to switch to:', choises)
            if selected != -1:
                __log('selected Addon= %r - %r' % (addons[selected][0],addons[selected][1]))
                IDdoADDON = addons[selected][1]
                __log('Start Addon= %r' % IDdoADDON)
                xbmc.executebuiltin('Dialog.Close(busydialog)')   ### 2019-09-03 needed to allow switch addon
                xbmc.executebuiltin('RunAddon(%s)' % IDdoADDON)
     
def latin1_to_ascii_force(unitext):
    printL('latin1_to_ascii_force(unitext= %r)' % unitext)
    xc3flag = False
    xlatec3={0x82:'Euro', 0x85:'AA', 0x86:'AE', 0x98:'OE', 
        0xa0:'',
        0xa1:'', 0xa2:'c', 0xa3:'L', 0xa4:'ae',
        0xa5:'aa', 0xa6:'ae', 0xa7:'s', 0xa8:'..',
        0xa9:'e', 0xaa:'a', 0xab:'<<', 0xac:'-',
        0xad:'-', 0xae:'R', 0xaf:'_', 
        0xb0:'deg',
        0xb1:'+/-', 0xb2:'^2', 0xb3:'o', 0xb4:"'",
        0xb5:'m', 0xb6:'oe', 0xb7:'*', 0xb8:'oe',
        0xb9:'^1', 0xba:'^0', 0xbb:'>>', 
        0xbc:'1/4', 0xbd:'1/2', 0xbe:'3/4', 0xbf:'?',
        0xc0:'A', 0xc1:'A', 0xc2:'A', 0xc3:'', 0xc4:'AA', 0xc5:'AA',
        0xc6:'AE', 0xc7:'C',
        0xc8:'E', 0xc9:'E', 0xca:'E', 0xcb:'E',
        0xcc:'I', 0xcd:'I', 0xce:'I', 0xcf:'I',
        0xd0:'Th', 0xd1:'N',
        0xd2:'O', 0xd3:'O', 0xd4:'O', 0xd5:'O', 0xd6:'OE', 
        0xd7:'*', 
        0xd8:'OE',
        0xd9:'U', 0xda:'U', 0xdb:'U', 0xdc:'U',
        0xdd:'Y', 0xde:'th', 0xdf:'ss',
        0xe0:'a', 0xe1:'a', 0xe2:'a', 0xe3:'a', 0xe4:'ae', 0xe5:'aa',
        0xe6:'ae', 0xe7:'c',
        0xe8:'e', 0xe9:'e', 0xea:'e', 0xeb:'e',
        0xec:'i', 0xed:'i', 0xee:'i', 0xef:'i',
        0xf0:'th', 0xf1:'n',
        0xf2:'o', 0xf3:'o', 0xf4:'o', 0xf5:'o', 0xf6:'oe', 0xf7:'/', 0xf8:'oe',
        0xf9:'u', 0xfa:'u', 0xfb:'u', 0xfc:'u',
        0xfd:'y', 0xfe:'th', 0xff:'y',
        }
    xlate={0x82:'Euro', 0x85:'AA', 0x86:'AE', 0x98:'OE', 
        0xa0:'',
        0xa1:'', 0xa2:'c', 0xa3:'L', 0xa4:'o',
        0xa5:'aa', 0xa6:':', 0xa7:'s', 0xa8:'..',
        0xa9:'c', 0xaa:'a', 0xab:'<<', 0xac:'-',
        0xad:'-', 0xae:'R', 0xaf:'_', 
        0xb0:'deg',
        0xb1:'+/-', 0xb2:'^2', 0xb3:'o', 0xb4:"'",
        0xb5:'m', 0xb6:'pi', 0xb7:'*', 0xb8:'oe',
        0xb9:'^1', 0xba:'^0', 0xbb:'>>', 
        0xbc:'1/4', 0xbd:'1/2', 0xbe:'3/4', 0xbf:'?',
        0xc0:'A', 0xc1:'A', 0xc2:'A', 0xc3:'', 0xc4:'AA', 0xc5:'AA',
        0xc6:'AE', 0xc7:'C',
        0xc8:'E', 0xc9:'E', 0xca:'E', 0xcb:'E',
        0xcc:'I', 0xcd:'I', 0xce:'I', 0xcf:'I',
        0xd0:'Th', 0xd1:'N',
        0xd2:'O', 0xd3:'O', 0xd4:'O', 0xd5:'O', 0xd6:'OE', 
        0xd7:'*', 
        0xd8:'OE',
        0xd9:'U', 0xda:'U', 0xdb:'U', 0xdc:'U',
        0xdd:'Y', 0xde:'th', 0xdf:'ss',
        0xe0:'a', 0xe1:'a', 0xe2:'a', 0xe3:'a', 0xe4:'ae', 0xe5:'aa',
        0xe6:'ae', 0xe7:'c',
        0xe8:'e', 0xe9:'e', 0xea:'e', 0xeb:'e',
        0xec:'i', 0xed:'i', 0xee:'i', 0xef:'i',
        0xf0:'th', 0xf1:'n',
        0xf2:'o', 0xf3:'o', 0xf4:'o', 0xf5:'o', 0xf6:'oe', 0xf7:'/', 0xf8:'oe',
        0xf9:'u', 0xfa:'u', 0xfb:'u', 0xfc:'u',
        0xfd:'y', 0xfe:'th', 0xff:'y', 
        }
    r = ''
    printL('unitext= %r' % unitext)
    ###unitext = unitext.encode("utf-8")
    ###printL('unitext-utf-8= %r' % unitext)
    unitext = unitext.replace('\xef\xbb\xbf','')   ### Remove: byte order mark (BOM)
    printL('unitext-noBOM= %r' % unitext)
    for i in unitext:
        printL('i= %r, ord(i)= %r' %  (i,ord(i)))
        try:
            if ord(i) == 0xc3:
                xc3flag = True
            else:
                if xc3flag == True:
                    ###if xlatec3.has_key(ord(i)):
                    if ord(i) in xlatec3:
                        r += xlatec3[ord(i)]
                    elif ord(i) >= 0x80:
                        pass
                    else:
                        r += str(i)
                    xc3flag = False
                else:
                    ###if xlate.has_key(ord(i)):
                    if ord(i) in xlate:
                        r += xlate[ord(i)]
                    elif ord(i) >= 0x80:
                        pass
                    else:
                        r += str(i)
        except Exception as e:
            pass
            printL('latin1_to_ascii_force(unitext) ERROR= %r)' % e)
    printL('latin1_to_ascii_force(unitext-->r= %r)' % r)
    return r
    
def shareLogs(change): ### Only change = True in this file only
    sharepath = ADDON.getSetting('sharepath')
    __log('603 shareLogs sharepath= %r' % sharepath)
    ###if not os.path.exists(sharepath):
    ###    os.mkdir(sharepath)
    ###    __log('606 folder created: %r' % sharepath)
    ###    open(sharepath, 'a').close()
    
    dest = 'DestinationNotSetYet'
    try:
        if sharepath != '':
            destname = (str(xbmc.getInfoLabel('System.FriendlyName'))+'-'+ADDONname).replace(' ','')
            dest = os.path.join(sharepath,destname)
            __log('613 logs to= %r' % dest)
            
            ADDON.setSetting('Excution 1', 'Before Copy Files')
            datapath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
            
            try:
                file = 'DRTV-favorites.txt'
                destf = os.path.join(sharepath,file)
                sourf = xbmcvfs.translatePath(os.path.join(datapath, 'favorites.txt'))
                copyOK = xbmcvfs.copy(destf, sourf)
                if not copyOK:
                    __log('Copy of favorites.txt failed')
                __log('619 favorites.txt to= %r' % sourf)
                __log('620 favorites.txt from= %r' % destf)
            except Exception as e:
                pass
                ADDON.setSetting('Exception favorites.txt', repr(e))
            
            if not change :
                file = destname+'-kodi.log'
                destf = os.path.join(sharepath,file)
                sourf = xbmcvfs.translatePath(os.path.join('special://logpath', 'kodi.log'))
                ###xbmcvfs.copy(sourf, destf)
                if os.path.exists(sourf):
                    copyOK = xbmcvfs.copy(sourf, destf)
                    if not copyOK:
                        __log('Copy of kodi.log failed')
                __log('619 kodi.log from= %r' % sourf)
                __log('620 kodi.log to= %r' % destf)
                
                file = destname+'-addon.log'
                destf = os.path.join(sharepath,file)
                sourf = xbmcvfs.translatePath(os.path.join(datapath, 'addon.log'))
                if os.path.exists(sourf):
                    copyOK = xbmcvfs.copy(sourf, destf)
                    if not copyOK:
                        __log('Copy of addon.log failed')
                __log('627 addon.log from= %r' % sourf)
                __log('628 addon.log to= %r' % destf)
            ###settingUpdated = False    
            if change :
                file = destname+'-settings.cng'
                cngf = os.path.join(sharepath,file)
                localcngf = xbmcvfs.translatePath(os.path.join(datapath, 'settings.cng'))
                ADDON.setSetting('Excution 2', 'cngf = %r' % cngf)
                try:
                    copyOK = xbmcvfs.copy(cngf, localcngf)
                    if not copyOK:
                        __log('Copy of settings.cng failed')
                        ADDON.setSetting('Exception 1', 'Copy of settings.cng failed')
                    if os.path.isfile(localcngf) :
                        ADDON.setSetting('Excution 3', 'localcngf = %r' % localcngf)
                        file = open(localcngf,'r',encoding='utf-8')
                        desc = file.read()
                        ADDON.setSetting('Excution 4', 'desc = %r' % desc)
                        file.close()
                        params = desc.split('<setting id="')[1]
                        ADDON.setSetting('Excution 5', 'params = %r' % params)
                        param = params.split('"')[0]
                        ADDON.setSetting('Excution 6', 'param = %r' % param)
                        values = params.split('>')[1].split('<')[0]
                        ADDON.setSetting('Excution 7', 'values = %r' % values)
                        ADDON.setSetting(param, values)
                        xbmcvfs.delete(cngf)
                        xbmcvfs.delete(localcngf)
                        ###settingUpdated = True
                except Exception as e:
                    pass
                    ADDON.setSetting('Exception', repr(e))
            
            ADDON.setSetting('Excution 9', 'Before Copy settings.xml')
            if not change :
                file = destname+'-settings.xml'
                destf = os.path.join(sharepath,file)
                sourf = xbmcvfs.translatePath(os.path.join(datapath, 'settings.xml'))
                if os.path.exists(sourf):
                    copyOK = xbmcvfs.copy(sourf, destf)
                    ###if settingUpdated :
                    ###    copyOKreturn = xbmcvfs.copy(destf, sourf)
                    if not copyOK:
                        __log('Copy of settings.xml failed')
                    ###if not copyOKreturn:
                    ###    __log('Copy back of settings.xml failed')
                __log('653 settings.xml from= %r' % sourf)
                __log('654 settings.xml to= %r' % destf)
            
    except Exception as  e:
        pass 
        __log('Change setting or Copy shareLogs to sharepath= %r FAILED: %r' % (dest, e))
 
