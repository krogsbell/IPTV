#!/usr/bin/python
# -*- coding: utf-8 -*-

import urllib
from urllib.request import urlopen
 
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import _strptime
import os
import xbmcgui, xbmcplugin, xbmcaddon
import utils
import json as simplejson
import xbmcvfs
import channels
import channelsDR

from infotagger.listitem import ListItemInfoTag
INFO_TAG = True     ### 2023-11-25 don't use info_tag
###CHANNELS_URL = 'https://www.dr.dk/mu-online/api/1.0/channel/all-active-dr-radio-channels'
###PATH = sys.argv[1]
###idtext = PATH.replace('plugin:','').replace('/','').replace('special:homeaddons','')
###ADDON = xbmcaddon.Addon(id=idtext)
ADDON = xbmcaddon.Addon('plugin.audio.dr.dk.netradio')
ADDONname = ADDON.getAddonInfo('name')
ADDONid   = ADDON.getAddonInfo('id')
ADDONpath = xbmcvfs.translatePath('special://home/addons/%s/' % ADDONid)
progpath  = ADDON.getAddonInfo('path')
PATH      = progpath
LOGO_PATH = os.path.join(ADDONpath, 'resources', 'logos')
ICON = os.path.join(ADDONpath, 'icon.png')
FANART = os.path.join(ADDONpath, 'fanart.jpg')
module = 'startstation.py'

def __log(text):
    ###utils.logdev(sys.argv[0]+' '+sys.argv[2],text)
    utils.logdev(module,text)
__log('39 Start startstation!')   

findstationrunning = utils.ADDONgetSetting('findstationrunning')
startstationrunning = utils.ADDONgetSetting('startstationrunning')
if startstationrunning == 'true':
    __log('44 Dont start startstation!')
    exit()
else:
    __log('startstationrunning != true')
    utils.ADDONsetSetting('startstationrunning','true')
__log('49 Start startstation!')   

def now():   ### Local time
    dt_obj= datetime.now()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
    
def todayDate():
    dt_obj= datetime.today().date()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
    
def AdjustDateTime(dateTS,Hours,Minutes):
    dt_obj = datetime.fromtimestamp(dateTS) + timedelta(hours= int(Hours), minutes= int(Minutes))
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
    
def humantime(ts):   ### Timestamp to human time
    if isinstance(ts, int):
        dt = datetime.fromtimestamp(ts)
    elif isinstance(ts, datetime.datetime):
        dt = ts
    else:
        return ts
    ###dt = datetime.datetime.fromtimestamp(ts)
    ht = dt.strftime("%Y-%m-%d %H:%M:%S")
    ###ht = dt.strftime("%m-%d %H:%M")
    return ht

def showError(message):
    heading = 'Error in Startstation!'
    line1 = ADDON.getLocalizedString(30900)
    line2 = ADDON.getLocalizedString(30901)
    ###xbmcgui.Dialog().ok(heading, line1, line2, message)
    __log(heading+'\n'+line1+'\n'+line2+'\n'+message)    
    
def testHTTP(url):  
    try:
        return True
        import socket
        if url[:4].lower() != 'http':
            __log('testHTTP(%r)=\n%r' % (url,'Play non http or https!'))
            return True
        # timeout in seconds
        timeout = 10
        socket.setdefaulttimeout(timeout)

        # this call to urlopen now uses the default timeout
        # we have set in the socket module
        req = urllib.parse.Request(url)
        response = urlopen(req)
        __log('testHTTP(%r)=\n%r' % (url,response))
        return response
    except Exception as e:
        pass
        __log('testHTTP(%r)\nERROR: %r' % (url,e))
        return False

def playEPG(idx):
    __log('100 playEPG(idx= %r)'% idx)
    try:
        url = ''
        for chan in channelsDR.CHANNELS:
            station_id = chan.name
            if idx == station_id:
                url = chan.url
                iconImage = chan.icon
                title = chan.name
                break
        __log('110 idx= %r, url= %r, icomImage = %r, title= %r' % (idx, url, iconImage, title))
        if url != '':
            if 1 == 0:   ### Don't use
                item = xbmcgui.ListItem(idx)
                item.setArt({ 'icon': iconImage, 'thumb' : iconImage })
                item.setProperty('IsPlayable', 'true')
                item.setProperty('Fanart_Image', FANART)
                if INFO_TAG:
                    info_tag = ListItemInfoTag(item, 'music')
                    ###kanal = utils.ADDONgetSetting('kanal') 
                    ###if kanal != '' and title != '':
                    ###    titleX = title + ': ' + kanal
                    ###elif kanal != '':
                    ###    titleX = kanal
                    ###else:
                    ###    titleX  = title
                    infolabels = { 'title': title}   ### 2023.11-01 'genre': 'Not Set' }
                    info_tag.set_info(infolabels)
                    __log('119 infolabels= %r' % infolabels)
                """
                item.setInfo(type='music', infoLabels={
                    'title': title})
                """
            logoImage = os.path.join(LOGO_PATH, title + '.png')
            item = xbmcgui.ListItem(path=url)
            item.setArt({ 'icon': logoImage, 'thumb' : logoImage })
            if INFO_TAG:
                info_tag = ListItemInfoTag(item, 'music')
                ###kanal = utils.ADDONgetSetting('kanal') 
                ###if kanal != '' and title != '':
                ###    titleX = title + ': ' + kanal
                ###elif kanal != '':
                ###    titleX = kanal
                ###else:
                ###    titleX  = title
                infolabels = { 'title': title}
                info_tag.set_info(infolabels)
                __log('130 infolabels= %r' % infolabels)
            """
            item.setInfo(type='music', infoLabels={
                'title': title})
            """
            __log('162 setSetting(programplaying= %r' % idx)
            utils.ADDONsetSetting('programplaying',idx)  ### 2023-11-01
            if not xbmc.Player().isPlaying():
                __log('0 Player is NOT Playing #0')
            else:
                __log('0 Player is Playing #0')
            xbmc.Player().play(url, item, True)
            __log('167 play-ing-EPG-started(url= %r)'% url)
            xbmc.sleep(1000)
            if not xbmc.Player().isPlaying():
                __log('1 Player is NOT Playing #1')
            else:
                __log('1 Player is Playing #1')
            x = 0
            xbmc.sleep(10000)    ### 2023-08-16
            while not xbmc.Player().isPlaying() and x <= 100:
                xbmc.sleep(10000)   ### 2023-08-16
                x += 1
                try:
                    __log('Player is NOT playing - try again #%r' % x)
                    xbmc.Player().play(url, item, True)
                except Exception as e:
                    pass
                    __log('PlayEPG Player ERROR: %r' % e)
                __log('PlayEPG Player break!')
                break   ### Stop at first match
    except Exception as e:
        __log('152 playEPG Exception: %r'% e)
 
def playOther(idx):
    __log('playOther(idx= %r)'% idx)
    url = None
    try:
        ### other channel
        __log('Other Channels')
        if url == None:
            try:
                channel = None
                for c in channels.CHANNELS:
                    __log('Other Channel= %r: %r' % (c.id,c.name))
                    if c.name == idx:
                        channel = c
                        break

                if channel is None:
                    __log('Other Channel= None')
                    return

                logoImage = xbmcvfs.translatePath(os.path.join(LOGO_PATH, str(channel.id) + '.png'))
                item = xbmcgui.ListItem(path=channel.url)
                item.setArt({ 'icon': logoImage, 'thumb' : logoImage })
                if INFO_TAG:
                    info_tag = ListItemInfoTag(item, 'music')
                    ###kanal = utils.ADDONgetSetting('kanal') 
                    title = channel.name
                    ###if kanal != '' and title != '':
                    ###    titleX = title + ': ' + kanal
                    ###elif kanal != '':
                    ###    titleX = kanal
                    ###else:
                    ###    titleX  = title
                    infolabels = { 'title': title}
                    ###infolabels = { 'title': channel.name}   ### 2023.11-01 'genre': 'Not Set' }
                    info_tag.set_info(infolabels)
                    __log('286 infolabels= %r' % infolabels)
                """
                item.setInfo(type='music', infoLabels={
                    'title': channel.name
                })
                """
                __log('play-ing-EPG(url= %r)'% channel.url)
                if testHTTP(channel.url):
                    ###__log('xbmc.Player().isPlaying(565): %r' % xbmc.Player().isPlaying())
                    ###utils.ADDONsetSetting('programplaying',idx)
                    url = channel.url
                    ###xbmcplugin.setResolvedUrl(HANDLE, True, listitem = item)
                    ###__log('xbmc.Player().isPlaying(569): %r' % xbmc.Player().isPlaying())
                else:
                    __log('NOT play-ing-EPG(url= %r)'% channel.url)
            except Exception as e:
                pass
                __log('playOther idx: %r\nERROR: %r' % (idx,e))
        __log('287 playEPG(url= %r)'% url)
        if url != None:
            __log('play-ing-EPG(url= %r)'% url)
            
            __log('248 setSetting(programplaying= %r' % idx)
            utils.ADDONsetSetting('programplaying',idx)
            if not xbmc.Player().isPlaying():
                __log('Player is NOT Playing #0')
            else:
                __log('Player is Playing #0')
            xbmc.Player().play(url, item, True)
            __log('250 play-ing-EPG-started(url= %r)'% url)
            xbmc.sleep(1000)
            if not xbmc.Player().isPlaying():
                __log('Player is NOT Playing #1')
            else:
                __log('Player is Playing #1')
            x = 0
            while not xbmc.Player().isPlaying() and x <= 100:
                xbmc.sleep(1000)
                x += 1
                try:
                    __log('Player is NOT playing - try again #%r' % x)
                    xbmc.Player().play(url, item, True)
                except Exception as e:
                    pass
                    __log('PlayEPG Player ERROR: %r' % e)
                break   ### Stop at first match
    except Exception as e:
        pass
        __log('PlayEPG ERROR: %r' % e)
    
try:
    __log('sys.argv= %r' % sys.argv)
    program      = sys.argv[0]
    PATHfromArgv = sys.argv[1]
    station_id   = sys.argv[2]
    
except Exception as e:
    pass
    title = 'StartStation'
    PATHfromArgv  = repr(e)
    station_id = 'P4 København'
    
try:
    __log('sys.argv= %r' % sys.argv)
    __log('os.environ= %s' % os.environ['OS'] ) #put in LOG
    __log('PATH= %r' % PATH)
    __log('PATHfromArgv= %r' % PATHfromArgv)
    __log('ADDONpath= %r' % ADDONpath)
    __log('LOGO_PATH= %r' % LOGO_PATH)
    __log('ICON= %r' % ICON)
    __log('FANART= %r' % FANART)

except Exception as e:
    pass
    __log('ERROR data: %r' % e)
try:
    timer = now()
    __log('Timer at start! %r' % timer)
    player = xbmc.Player()
    try:
        timebetweenupdates = utils.ADDONgetSetting('timebetweenupdates').split(':')
        __log('293 timebetweenupdates= %r' % timebetweenupdates)
        timebetweenupdatesH = int(timebetweenupdates[0])
        timebetweenupdatesM = int(timebetweenupdates[1])
        timebetweenupdatesS = int(timebetweenupdates[2])
        
        timeaftervideodummy = int(utils.ADDONgetSetting('timeaftervideo'))//(timebetweenupdatesH*3600 + timebetweenupdatesM*60 + timebetweenupdatesS)
        __log('timeaftervideodummy= %r' % timeaftervideodummy)
    except Exception as e:
        pass
        timeaftervideodummy = 5
        __log('timeaftervideodummy ERROR: %r' % e)
    
    if player.isPlayingVideo():
        PlayingVideo = True
        timeaftervideo = timeaftervideodummy
        try:
            utils.ADDONsetSetting('timeaftervideo',str(timeaftervideo*(timebetweenupdatesH*3600 + timebetweenupdatesM*60 + timebetweenupdatesS)))  ### Adjust to actual time based on timeupdateinterval
            utils.ADDONsetSetting('timeaftervideocounter',str(timeaftervideo))
        except Exception as e:
            pass
            __log('timeaftervideo ERROR: %r' % e)
        __log('PlayingVideo = True')
    else:
        PlayingVideo = False
        timeaftervideoI = ADDON.getSetting('timeaftervideocounter')
        if timeaftervideoI == '':
            timeaftervideoI = timeaftervideodummy
        timeaftervideo = int(timeaftervideoI)
        timeaftervideo -= 1
        if timeaftervideo <= 0:
            timeaftervideo = 0
        utils.ADDONsetSetting('timeaftervideocounter',str(timeaftervideo))
        __log('PlayingVideo = False')
except Exception as e:
    pass
    PlayingVideo = False
    timeaftervideo = timeaftervideodummy
    try:
        utils.ADDONsetSetting('timeaftervideo',str(timeaftervideo*(timebetweenupdatesH*3600 + timebetweenupdatesM*60 + timebetweenupdatesS)))  ### Adjust to actual time based on timeupdateinterval
    except Exception as e:
        pass
        __log('timeaftervideo ERROR: %r' % e)
    utils.ADDONsetSetting('timeaftervideocounter',str(timeaftervideo))
    __log('Is Palying Video Test ERROR: %r' % e)
__log('Test part:Play Video= %r, timeaftervideo= %r' % (PlayingVideo,timeaftervideo))
__log('Timer at code part %r' % (now() - timer))
try:
    __log('code part')
    __log('PlayingVideo= %r, timeaftervideo= %r' % (PlayingVideo, timeaftervideo))
    if not PlayingVideo and timeaftervideo <= 0 :
        __log('Video is not playing')
        utils.setChannelVolumen(station_id)
        __log('after utils.setChannelVolumen(station_id= %r)' % station_id )
        
        playEPG(station_id)
        utils.logdev('window','StartStation module= %r, CurrentWindowIdWindowId= %r' % (module, xbmcgui.getCurrentWindowId()))
        xbmc.executebuiltin("Container.Refresh")
    
except Exception as e:
    pass
    __log('ERROR: %r' % e)
__log('Timer at Finish %r' % (now() - timer))
utils.ADDONsetSetting('startstationrunning','false')
__log('startstationrunning= false')
exit()