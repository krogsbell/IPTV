#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#      Copyright (C) 2014 Tommy Winther
#      http://tommy.winther.nu
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt. If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
CHANNELS = list()


class ChannelDR(object):
    def __init__(self, id, name, epg, icon, url):
        self.id = id
        self.name = name
        self.epg = epg
        self.icon = icon
        self.url = url

        CHANNELS.append(self)

### ### Link to EPG List: https://www.dr.dk/Tjenester/epglive/
ChannelDR(1, 'P1', 'https://www.dr.dk/lyd/p1','P1D','http://live-icy.dr.dk/A/A03H.mp3')
ChannelDR(2, 'P2', 'https://www.dr.dk/lyd/p2','P2D','http://live-icy.dr.dk/A/A04H.mp3')
ChannelDR(3, 'P3', 'https://www.dr.dk/lyd/p3','P3','http://live-icy.dr.dk/A/A05H.mp3')
ChannelDR(4, 'P4 Bornholm', 'https://www.dr.dk/lyd/p4bornholm','AB4','http://live-icy.dr.dk/A/A06H.mp3')
ChannelDR(5, 'P4 Esbjerg', 'https://www.dr.dk/lyd/p4esbjerg','AB4','http://live-icy.dr.dk/A/A15H.mp3')
ChannelDR(6, 'P4 Fyn', 'https://www.dr.dk/lyd/p4fyn','AB4','http://live-icy.dr.dk/A/A07H.mp3')
ChannelDR(7, 'P4 København', 'https://www.dr.dk/lyd/p4kbh','AB4','http://live-icy.dr.dk/A/A08H.mp3')
ChannelDR(8, 'P4 Midtvest', 'https://www.dr.dk/lyd/p4vest','AB4','http://live-icy.dr.dk/A/A09H.mp3')
ChannelDR(9, 'P4 Nord', 'https://www.dr.dk/lyd/p4nord','AB4','http://live-icy.dr.dk/A/A10H.mp3')
ChannelDR(10, 'P4 Østjylland', 'https://www.dr.dk/lyd/p4aarhus','AB4','http://live-icy.dr.dk/A/A14H.mp3')
ChannelDR(11, 'P4 Sjælland', 'https://www.dr.dk/lyd/p4sjaelland','AB4','http://live-icy.dr.dk/A/A11H.mp3')
ChannelDR(12, 'P4 Syd', 'https://www.dr.dk/lyd/p4syd','AB4','http://live-icy.dr.dk/A/A12H.mp3')
ChannelDR(13, 'P4 Trekanten', 'https://www.dr.dk/lyd/p4trekanten','AB4','http://live-icy.dr.dk/A/A13H.mp3')
ChannelDR(14, 'P5', 'https://www.dr.dk/lyd/p5kbh','P5D','http://live-icy.dr.dk/A/A28H.mp3')
###ChannelDR(15, 'P5 Fyn', 'https://DR.DK/Tjenester/epglive/epg.radio.P5.drxml','P5D','http://live-icy.dr.dk/A/A02H.mp3')
ChannelDR(15, 'P6 Beat', 'https://www.dr.dk/lyd/p6beat','P6B','http://live-icy.dr.dk/A/A29H.mp3')
###ChannelDR(16, 'P7Mix', 'https://DR.DK/Tjenester/epglive/epg.radio.P7M.drxml','P7M')
ChannelDR(16, 'P8 Jazz', 'https://www.dr.dk/lyd/p8jazz','P8J','http://live-icy.dr.dk/A/A22H.mp3')
###ChannelDR(18, 'RamasjangRadio', 'https://DR.DK/Tjenester/epglive/epg.radio.RamasjangUltra.drxml','','http://live-icy.dr.dk/A/A03H.mp3')
###ChannelDR(17, 'DR Mama', 'https://www.dr.dk/lyd','','http://live-icy.gss.dr.dk:8000/A/A18H.mp3')
###ChannelDR(18, 'DR Nyheder', 'https://www.dr.dk/lyd','','http://live-icy.gss.dr.dk:8000/A/A02H.mp3')

###ChannelDR(19, 'Klassisk Live', '','','http://onair.100fmlive.dk:80/klassisk_live.mp3')
###ChannelDR(20, 'Nova FM', '','','http://stream.novafm.dk:80/nova128')
###ChannelDR(21, 'Pop FM', '','','http://stream.popfm.dk:80/pop128')
###ChannelDR(22, 'Radio 100 FM', '','','http://onair.100fmlive.dk:80/100fm_live.mp3')
###ChannelDR(23, 'Radio Charlie', '','','http://89.184.153.12:8000/radiocharlie.mp3')
###ChannelDR(24, 'The Voice', '','','http://195.184.101.203/voice128')
ChannelDR(17, 'Riviera Radio', '', 'RR1', 'https://rivieraradio.ice.infomaniak.ch/rivieraradio-high.mp3')
"""
  ["DR P1"]="http://live-icy.gss.dr.dk:8000/A/A03H.mp3"
  ["DR P2 Klassisk"]="http://live-icy.gss.dr.dk:8000/A/A04H.mp3"
  ["DR P3"]="http://live-icy.gss.dr.dk:8000/A/A05H.mp3"
  ["DR P4 Bornholm"]="http://live-icy.gss.dr.dk:8000/A/A06H.mp3"
  ["DR P4 Esbjerg"]="http://live-icy.gss.dr.dk:8000/A/A15H.mp3"
  ["DR P4 Fyn"]="http://live-icy.gss.dr.dk:8000/A/A07H.mp3"
  ["DR P4 København"]="http://live-icy.gss.dr.dk:8000/A/A08H.mp3"
  ["DR P4 Midt & Vest"]="http://live-icy.gss.dr.dk:8000/A/A09H.mp3"
  ["DR P4 Nordjylland"]="http://live-icy.gss.dr.dk:8000/A/A10H.mp3"
  ["DR P4 Sjælland"]="http://live-icy.gss.dr.dk:8000/A/A11H.mp3"
  ["DR P4 Syd"]="http://live-icy.gss.dr.dk:8000/A/A12H.mp3"
  ["DR P4 Trekanten"]="http://live-icy.gss.dr.dk:8000/A/A13H.mp3"
  ["DR P4 Østjylland"]="http://live-icy.gss.dr.dk:8000/A/A14H.mp"
  ["DR P5"]="http://live-icy.gss.dr.dk:8000/A/A25H.mp3"
  ["DR P6 Beat"]="http://live-icy.gss.dr.dk:8000/A/A29H.mp3"
  ["DR P7 Mix"]="http://live-icy.gss.dr.dk:8000/A/A21H.mp3"
  ["DR P8 Jazz"]="http://live-icy.gss.dr.dk:8000/A/A22H.mp3"
  ["DR Ramasjang/Ultra"]="http://live-icy.gss.dr.dk:8000/A/A24H.mp3"
  
P1
http://live-icy.dr.dk/A/A03H.mp3.m3u

P2
http://live-icy.dr.dk/A/A04H.mp3.m3u

P3
http://live-icy.dr.dk/A/A05H.mp3.m3u

P4 Bornholm
http://live-icy.dr.dk/A/A06H.mp3.m3u

P4 Esbjerg
http://live-icy.dr.dk/A/A15H.mp3.m3u

P4 Fyn
https://live-icy.dr.dk/A/A07H.mp3

P4 København
http://live-icy.dr.dk/A/A08H.mp3.m3u

P4 Midtvest
http://live-icy.dr.dk/A/A08H.mp3.m3u

P4 Nordjylland
http://live-icy.dr.dk/A/A10H.mp3.m3u

P4 Sjælland
http://live-icy.dr.dk/A/A11H.mp3.m3u

P4 Syd
http://live-icy.dr.dk/A/A12H.mp3.m3u

P4 Trekanten
http://live-icy.dr.dk/A/A13H.mp3.m3u

P4 Østjyllands Radio
http://live-icy.dr.dk/A/A14H.mp3.m3u

P5 Bornholm
https://live-icy.dr.dk/A/A30H.mp3

P5 Esbjerg
https://live-icy.dr.dk/A/A26H.mp3

P5 Fyn
https://live-icy.dr.dk/A/A02H.mp3

P5 København
https://live-icy.dr.dk/A/A28H.mp3

P5 Midtvest
https://live-icy.dr.dk/A/A17H.mp3

P5 Nordjylland
https://live-icy.dr.dk/A/A18H.mp3

P5 Sjælland
https://live-icy.dr.dk/A/A19H.mp3

P5 Syd
https://live-icy.dr.dk/A/A20H.mp3

P5 Trekanten
https://live-icy.dr.dk/A/A23H.mp3

P5 Østjylland
https://live-icy.dr.dk/A/A24H.mp3

P6 BEAT
http://live-icy.dr.dk/A/A29H.mp3.m3u

P8 JAZZ
http://live-icy.dr.dk/A/A22H.mp3.m3u



2019-05-28 19:56:39 addon.py: playEPG(idx= 'P4Midtogvest')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P1' slug= u'p1')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P2' slug= u'p2')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P3' slug= u'p3')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P4 K\xf8benhavn' slug= u'p4kbh')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P4 Bornholm' slug= u'p4bornholm')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P4 Esbjerg' slug= u'p4esbjerg')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P4 Fyn' slug= u'p4fyn')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P4 Midt & Vest' slug= u'p4vest')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P4 Nordjylland' slug= u'p4nord')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P4 Sj\xe6lland' slug= u'p4sjaelland')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P4 Syd' slug= u'p4syd')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P4 Trekanten' slug= u'p4trekanten')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P4 \xd8stjylland' slug= u'p4aarhus')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P5' slug= u'p5')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P6 BEAT' slug= u'p6beat')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P7 MIX' slug= u'p7mix')
2019-05-28 19:56:40 addon.py: playEPG(title= u'P8 JAZZ' slug= u'p8jazz')
2019-05-28 19:56:40 addon.py: playEPG(title= u'Ramasjang/Ultra Radio' slug= u'ramasjangradio')
2019-05-28 19:56:40 addon.py: playEPG(title= u'Nyheder' slug= u'nyhederradio')


CHANNELS_URL = 'https://www.dr.dk/mu-online/api/1.0/channel/all-active-dr-radio-channels'
CHANNELS_URL_EPG = 'https://www.dr.dk/Tjenester/epglive/epg.radio.%s.drxml'

ADDON     = xbmcaddon.Addon()
ADDONname = ADDON.getAddonInfo('name')
ADDONid   = ADDON.getAddonInfo('id')
ADDONpath = xbmc.translatePath('special://home/addons/%s/' % ADDONid)
ProgramPlaying = ADDON.getSetting('ProgramPlaying').split(':')[0]   ### 2023-11-27
ADDON.setSetting('ProgramPlaying',ProgramPlaying)
programswanted = ['madsen']
programsnogo   = ['funk','povlsen']
preferredstation = 'P4'  ### DR P4
backupstation    = 'P5'  ### DR P5

"""