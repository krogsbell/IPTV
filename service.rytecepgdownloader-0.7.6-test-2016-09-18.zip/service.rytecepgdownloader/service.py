#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
import xbmc, xbmcgui, xbmcaddon, os
from resources.lib import common

id = 'service.rytecepgdownloader'
addon = xbmcaddon.Addon(id=id)
IMAGE = os.path.join(addon.getAddonInfo('path'), 'icon.png')

def log(message):
	xbmc.log('[Rytec EPG Downloader service.py]: '  + message)
	
def logbox(message):
	cmd  = 'XBMC.Notification(%s, %s, %d, %s)' % ('[Rytec EPG Downloader]: ', message, 9999, IMAGE)
	log(message)
	xbmc.executebuiltin(cmd)
	

def start_rytec_service(manual=False):
    from resources.lib import rytec
    log('rytec service started')
    descriptions = common.get_descriptions()
    log('descriptions= ' + repr(descriptions))
    sources_list = None
    merge = False
    for description in descriptions:
        log('description= ' + repr(description))
        ret = False
        if description.startswith('http'):
            epg_url = description
        else:
            epg_url = common.get_description_url(description)
        log('epg_url= ' + repr(epg_url))
        if epg_url:
            ret = common.load_local_xml(epg_url)
            log('ret= ' + repr(ret))
            if ret:
                log('no epg update needed ' + description)
            else:
                if description.startswith('http'):
                    if manual:
                        ret = rytec.download_epg(epg_url)
                if not manual:
                    ret = rytec.download_epg(epg_url)
                    if ret: merge = True
        if not ret and not description.startswith('http'):
            log('sources_list= ' + repr(sources_list))
            if not sources_list: sources_list = rytec.get_sources_list()
            log('sources_list= ' + repr(sources_list))
            if sources_list:
                ret = rytec.get_epg(sources_list, description)
                log('ret= ' + repr(ret))
                if ret:
                    merge = True
                else:
                    xbmc.executebuiltin('Notification(could not download epg data: %s)' % description)
                    log('could not download epg data ' + description)
            else:
                xbmc.executebuiltin('Notification(could not download sources list: %s)' % description)
                log('could not download sources list '+ description)
    #if merge and len(descriptions) > 1:
    if merge and len(descriptions) > 0:  
        try:
            common.merge_epg()
        except Exception, e:
            #xbmc.executebuiltin('Notification(could not merge epg: %s Error: %s)' % (description, repr(e)))
            logbox('could not merge epg ' + description + ' Error: ' + repr(e))

def service():
	a = False
	#i = 0
	while (not xbmc.abortRequested):
		if common.download_allowed(a):
			if not common.blocked(a):
			    start_rytec_service()
		a = True
		xbmc.sleep(1000) 
		#i += 1
		#log('serviceloop= ' + repr(i))
"""
def service():
    a = False
    while (not xbmc.abortRequested):
        if not (xbmc.Player().isPlaying() or xbmc.getCondVisibility('Library.IsScanningVideo')):
            if common.download_allowed(a):
                if not common.blocked(a):
                    start_rytec_service()
            a = True
        xbmc.sleep(1000)
"""

if common.get_xml_path() and common.get_activation_code():
    try:
        if sys.argv[1:][0] == 'manual_download':
            dialog = xbmcgui.Dialog()
            ret = dialog.yesno('Rytec EPG Downloader', 'Start Manual Download')
            if ret:
                manual = True
                start_rytec_service(manual)
                ok = dialog.ok('Rytec EPG Downloader', 'Manual Download Finished')
    except:
        service()
