#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmcaddon
import xbmc
import xbmcgui
import xbmcvfs
import gzip
import os
import base64
import time, datetime
import shutil
from StringIO import StringIO
import xml.etree.ElementTree as etree

id = 'service.rytecepgdownloader'
addon = xbmcaddon.Addon(id=id)
IMAGE = os.path.join(addon.getAddonInfo('path'), 'icon.png')

def log(message):
	xbmc.log('[Rytec EPG Downloader common.py]: '  + message)
	
def logbox(message):
	cmd  = 'XBMC.Notification(%s, %s, %d, %s)' % ('[Rytec EPG Downloader]: ', message, 9999, IMAGE)
	log(message)
	xbmc.executebuiltin(cmd)
	
def get_descriptions():
    descriptions = []
    set = [addon.getSetting('xmltv_1'), addon.getSetting('xmltv_2'), addon.getSetting('xmltv_3'), addon.getSetting('xmltv_4')]
    for s in set:
        if s:
            if not s == 'None' or s.startswith('http'):
                descriptions.append(s)
    return descriptions

def load_local_xml(epg_url):
    ret = False
    name = epg_url.split('/')[-1]
    xml_file = get_xml_file(name)
    if os.path.exists(xml_file):
        ret = check_date(xml_file)
    return ret

def get_description_url(description):
    epg_url = None
    try:
        epg_url = bdecode(addon.getSetting(description))
    except:
        log('no epg url found in settings ' + description)
    return epg_url

def save_epg_url(epg_url, description):
    addon.setSetting(description, bencode(epg_url))

def get_xml_path():
    xml_path = addon.getSetting('path').decode('utf-8')
    if not xml_path:
        addon.openSettings()
        xml_path = addon.getSetting('path').decode('utf-8')
    return xml_path

def get_xml_file(name):
    xml_path = get_xml_path()
    xml_file = os.path.join(xml_path, name)
    return xml_file

def bencode(original_string):
    encoded_string = base64.b64encode(original_string)
    return encoded_string

def bdecode(encoded_string):
    decoded_string = base64.b64decode(encoded_string)
    return decoded_string

def check_date(file):
    #cache_days = 3  # Original: cache_days = 3
    cache_days = 1
    modified_time = round(os.stat(file).st_mtime)
    current_time = round(time.time())
    t = current_time - modified_time
    if (t / 3600) < 24*cache_days:
        return True

def download_allowed(a):
    gmt = time.gmtime()
    if gmt.tm_hour > 2 and gmt.tm_hour < 7:
        if not a:
            logbox('epg download not allowed between 3 and 7 GMT')
        return False
    else:
        return True
        
def get_counter():
    counter = addon.getSetting('counter')
    if not counter:
        counter = '0'
    return counter

def blocked(a):
    counter = int(get_counter())
    ct = round(time.time())
    #log('blocked: ct= %s' % repr(ct))
    if counter == 0:
        counter += 1
        addon.setSetting('counter', str(counter))
        addon.setSetting('bt', str(ct).split('.')[0])
        return False
    elif counter == 1:
        counter += 1
        addon.setSetting('counter', str(counter))
        return False
    elif counter > 1:
        #log('blocked: bt= %s' % repr(addon.getSetting('bt')))
        try:
        	bt = int(addon.getSetting('bt'))
        except:
        	bt = 0
        t = ct - bt
        #log('blocked: t= %s' % repr(t))
        if (t / 3600) > 23:
            addon.setSetting('counter', '0')
            return False
        else:
            if not a:
                logbox('%sh blocked' % round(24 - (t / 3600),1))
            return True
    else:
        return True

def get_activation_code():
    ac = addon.getSetting('ac')
    if bencode(ac) == 'MzAyNQ==':
        return True
    else:
        addon.openSettings()
        ac = addon.getSetting('ac')
        if bencode(ac) == 'MzAyNQ==':
            return True
        else:    
            return False

def mergeedit(b,mergetitles,subtitles,divclass,newline,newline1,pattern,newlineback):
	if mergetitles:
		###b = subtitles.sub('==y==',b)
		###b = divclass.sub('==x==',b)     ### 2016-09-16 - <div class="other">
		b = newline.sub(r'<newline></newline>', b)  ### 2016-07-16  Combine Title and subtitle
		###b = newline1.sub(r'<newline></newline>', b)
		b = pattern.sub(' -sub- ', b)                   ### 2016-07-16
		b = newlineback.sub(r'\n', b) 
		b = b.replace('</sub-title>','</title>')    ### 2016-07-16

def merge_epg():
    # code from enen92. thank you
    merged_epg = 'merged_epg.xml'
    master     = 'master.xml'
    masterOLD  = 'masterOLD.xml'
    log('merge epg') 
    xml_path = get_xml_path()
    temp = os.path.join(xml_path,'temp')
    if not xbmcvfs.exists(temp):
        xbmcvfs.mkdir(temp)
    out = os.path.join(xml_path,merged_epg)
    if xbmcvfs.exists(out):
        xbmcvfs.delete(out)
    logbox('start extracting files')
    
    import re

    # If you need to use the regex more than once it is suggested to compile it.
    #pattern = re.compile(r'(</title>\s<sub-title[\w ="]{0,}>)', flags=re.MULTILINE)
    pattern = re.compile(r'(</title><newline></newline>[ ]{0,}<sub-title[\w ="]{0,}>)', flags=re.DOTALL+re.MULTILINE)
    title = re.compile(r'(</title><newline></newline>)', flags=re.DOTALL+re.MULTILINE)
    tv = re.compile(r'(</tv>)', flags=re.DOTALL+re.MULTILINE)
    newline = re.compile(r'(\r\n)', flags=re.DOTALL+re.MULTILINE)
    newline1 = re.compile(r'(\n)', flags=re.DOTALL+re.MULTILINE)
    newlineback = re.compile(r'(<newline></newline>)', flags=re.DOTALL+re.MULTILINE)
    slash = re.compile(r'(<newline></newline>)', flags=re.DOTALL+re.MULTILINE)
    ###divclass = re.compile(r'[^.a-zA-Z0-9();]{0,3}&lt;div class="other"&gt;', flags=re.DOTALL+re.MULTILINE) ### one nonprintable character and <div class="other">
    divclass = re.compile(r'[^.a-zA-Z0-9();]&lt;div class="other"&gt;', flags=re.DOTALL+re.MULTILINE) ### one nonprintable character and <div class="other">
    subtitles = re.compile(r'[^.a-zA-Z0-9();](Subtitles)', flags=re.DOTALL+re.MULTILINE) ### (Subtitles)
    #pattern = re.compile(r'(regexp -all -- {(</title>\s<sub-title[ a-zA-Z0-9="]{0,}>)} string match v1)')
    #pattern = re.compile(r'regexp -nocase -all -line -inline -- {(\</title\>\s\<sub-title\w\>)} string')
    log('pattern= ' + repr(pattern))
    log('title= ' + repr(title))
    log('tv= ' + repr(tv))
    log('newline= ' + repr(newline))
    log('newline1= ' + repr(newline1))
    log('newlineback= ' + repr(newlineback))
    log('slash= ' + repr(slash))
    log('divclass= ' + repr(divclass))
    log('subtitles= ' + repr(subtitles))
    # <\/{0,}\[\d+>
    # 
    # Match the character “<” literally «<»
    # Match the character “/” literally «\/{0,}»
    #    Between zero and unlimited times, as many times as possible, giving back as needed (greedy) «{0,}»
    # Match the character “[” literally «\[»
    # Match a single digit 0..9 «\d+»
    #    Between one and unlimited times, as many times as possible, giving back as needed (greedy) «+»
    # Match the character “>” literally «>»
    #<title lang="cs">A Beautiful Mind</title>
    #<sub-title lang="cs">(A Beautiful Mind (7))</sub-title>
    #subject = """this is a paragraph with<[1> in between</[1> and then there are cases ... where the<[99> number ranges from 1-100</[99>. 
    #and there are many other lines in the txt files
    #with<[3> such tags </[3>"""

    #result = pattern.sub("", subject)
    
    dirs, files = xbmcvfs.listdir(xml_path)
    for f in files:
        if f.endswith('.gz'):
            log(repr(f))
            inF = gzip.GzipFile(fileobj=StringIO(xbmcvfs.File(os.path.join(xml_path,f)).read()))
            s = inF.read()
            inF.close()
            outF = xbmcvfs.File(os.path.join(temp,f.replace('.gz','.xml')), 'wb')
            outF.write(s)
            outF.close()
    logbox('start merging files')
    #Save old file to masterOLD.xml
    try:
            source = os.path.join(xml_path,master)
            dest = os.path.join(xml_path,masterOLD)
            shutil.copy(source, dest)
    except Exception, e:
        log('error in copy old master.xml: ' + repr(e))
    dirs, xmltv_list = xbmcvfs.listdir(temp)
    i=1
    total = len(xmltv_list)
    for xmltv in xmltv_list:
        if xmltv.endswith('.xml'):
		log('xmltv file ' + repr(i) + ': ' + repr(xmltv))
		xmlfile = os.path.join(temp,xmltv)
		
		if addon.getSetting('mergetitles') == 'Yes':
			mergetitles = True
			logbox('merging files and titles with sub-titles')
		else:
			mergetitles = False
			logbox('merging files')
				
		if i==1:
			f = xbmcvfs.File(os.path.join(temp,xmltv))
			b = f.read()
			b = tv.sub('', b)
			mergeedit(b,mergetitles,subtitles,divclass,newline,newline1,pattern,newlineback)
			f.close()
			ltw = b.splitlines()
		else:
			f = xbmcvfs.File(os.path.join(temp,xmltv),'r')
			b = f.read()
			b = tv.sub('', b)
			mergeedit(b,mergetitles,subtitles,divclass,newline,newline1,pattern,newlineback)
			lines = b.splitlines()
			f.close()
			li = 0
			for line in lines:
			    if li == 0 or li == 1: pass
			    else: ltw.append(line)
			    li += 1
		xbmcvfs.delete(os.path.join(temp,xmltv))
		i += 1
    o = xbmcvfs.File(out,'w')
    j = 0
    for line in ltw:
        o.write(line.strip() + '\n')
        j += 1
    o.write('</tv>'+ '\n')
    log('last writen line= ' + repr(j) + ': ' + repr(line))
    o.close
    logbox('merging files done')
    
    #Copy final file to master.xml
    source = os.path.join(xml_path,merged_epg)
    dest = os.path.join(xml_path,master)
    shutil.copy(source, dest)
    now= datetime.datetime.today().strftime('%Y-%m-%d %H:%M')
    addon.setSetting('lastupdate',now)
