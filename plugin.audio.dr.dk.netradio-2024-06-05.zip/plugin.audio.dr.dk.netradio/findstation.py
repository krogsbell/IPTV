#!/usr/bin/python
# -*- coding: utf-8 -*-

import urllib
try:
    # For Python 3.0 and later
    from urllib.request import urlopen
except ImportError:
    # Fall back to Python 2's urllib2
    from urllib2 import urlopen

import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import _strptime
import calendar
import os
import xbmc,xbmcgui, xbmcplugin
import utils
import json as simplejson
import xbmcvfs,xbmcaddon
import xmltodict
import channelsDR
import channels

from infotagger.listitem import ListItemInfoTag
INFO_TAG = True     ### 2023-11-25 don't use info_tag
ADDON = xbmcaddon.Addon('plugin.audio.dr.dk.netradio')
###import addon    ### Use functions from main program NO 2023-10-12
###import urlquick

###CHANNELS_URL = 'https://www.dr.dk/mu-online/api/1.0/channel/all-active-dr-radio-channels'
PATHargv = sys.argv[1]
###idtext = PATH.replace('plugin:','').replace('/','').replace('special:homeaddons','')
###ADDON = xbmcaddon.Addon(id=idtext)
ADDON = xbmcaddon.Addon('plugin.audio.dr.dk.netradio')
ADDONname = ADDON.getAddonInfo('name')
ADDONid   = ADDON.getAddonInfo('id')
ADDONpath = xbmcvfs.translatePath('special://home/addons/%s/' % ADDONid)
progpath  = ADDON.getAddonInfo('path')
PATH      = progpath
datapath  = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
LOGO_PATH = os.path.join(PATH, 'resources', 'logos')
ICON = os.path.join(PATH, 'icon.png')
FANART = os.path.join(PATH, 'fanart.jpg')
module = 'findstation.py'
dateformat = '%Y-%m-%dT%H:%M:%S%z'
dateformatX = '%Y-%m-%d %H:%M:%S'
utils.ADDONsetSetting('findstation#','49' + repr(sys.argv))
def __log(text):
    utils.logdev(module,' '.join(text.split())[0:200])  ### Remove doublespaces etc
###def __log(text):
###    utils.logdev(sys.argv[0]+' '+sys.argv[2],'%r' % text[0:200])
findstationrunning = utils.ADDONgetSetting('findstationrunning')
startstationrunning = utils.ADDONgetSetting('startstationrunning')
if utils.ADDONgetSetting('autorun') == 'false':   ### 2023-12-22 Stop find station as soon as autorun is false - to keep one station running
    __log("Don't start findstation! Autorun disabled")
    exit()
if findstationrunning == 'true' : ### 2023-11-17 or startstationrunning == 'true':
    __log("Don't start findstation!")
    utils.ADDONsetSetting('findstation#','58' + repr(sys.argv))
    try:
        findstationrunningcount = int(utils.ADDONgetSetting('findstationrunningcount'))
    except:
        pass
        findstationrunningcount = 0
    if findstationrunningcount < 2:
        utils.ADDONsetSetting('findstationrunningcount',str(findstationrunningcount + 1))
        exit()
    utils.ADDONsetSetting('findstationrunningcount','0')
    utils.ADDONsetSetting('findstation#','60' + repr(sys.argv))
    ###xbmc.sleep(10000)
    utils.ADDONsetSetting('findstation#','62' + repr(sys.argv))
    __log("Don't start findstation! waited xx sec")
else:
    __log('findstationrunning != true')
    utils.ADDONsetSetting('findstationrunningcount','0')
    utils.ADDONsetSetting('findstation#','66' + repr(sys.argv))
    utils.ADDONsetSetting('findstationrunning','true')
__log('Start findstation!')    
if utils.ADDONgetSetting('useepg') == 'true':
    useepg = True
else:
    useepg = False
utils.ADDONsetSetting('findstation#','70' + repr(sys.argv))
def TSlts(timestamp):
    TO = datetime.fromtimestamp(timestamp)
    TOTS = int(time.mktime(TO.timetuple()))
    utcTO = datetime.utcfromtimestamp(timestamp)
    utcTOTS = int(time.mktime(utcTO.timetuple()))
    timeoffset = TOTS-utcTOTS
    ###__log('timeoffset= %r' % timeoffset)
    return(timestamp+timeoffset) 

def TSl(timestr):
    ### time format 2019-05-21T22:05:00Z to date string i local
    time_tuple = time.strptime(timestr, dateformat)
    timestamp = time.mktime(time_tuple)
    TO = datetime.fromtimestamp(timestamp)
    TOTS = int(time.mktime(TO.timetuple()))
    utcTO = datetime.utcfromtimestamp(timestamp)
    utcTOTS = int(time.mktime(utcTO.timetuple()))
    timeoffset = TOTS-utcTOTS
    ###__log('timeoffset= %r' % timeoffset)
    return(timestamp+timeoffset) 
        
def TS(timestr):
    ### time format 2019-05-21T22:05:00Z
    time_tuple = time.strptime(timestr, dateformat)
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def TSx(timestr):
    ### time format 2019-05-21T22:05:00
    time_tuple = time.strptime(timestr, dateformatX)
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
    
def nowTS():   ### UTC time
    dt_obj= datetime.utcnow()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def nowS(format):   ### Now date string UTC time
    time_tuple = time.localtime(nowTS())
    date_str = time.strftime(format, time_tuple)
    return(date_str)

def now():   ### Local time
    dt_obj= datetime.now()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    ###__log('humantime-now= %r' % humantime(timestamp))
    return(timestamp)

def nowL(format):   ### Now date string Local time
    time_tuple = time.localtime(now())
    date_str = time.strftime(format, time_tuple)
    return(date_str)
          
def todayDate():
    dt_obj= datetime.today().date()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
utils.ADDONsetSetting('findstation#','127' + repr(sys.argv))   
def AdjustDateTime(dateTS,Hours,Minutes):
    dt_obj = datetime.fromtimestamp(dateTS) + timedelta(hours= int(Hours), minutes= int(Minutes))
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
    
def humantime(ts):   ### Timestamp to human time
    if isinstance(ts, int):
        dt = datetime.fromtimestamp(ts)
    elif isinstance(ts, datetime.datetime):
        dt = ts
    else:
        return ts
    ###dt = datetime.datetime.fromtimestamp(ts)
    ht = dt.strftime("%Y-%m-%d %H:%M:%S")
    ###ht = dt.strftime("%m-%d %H:%M")
    return ht

def humanTS(timestr):
    ### time format 2019-05-21T22:05:00Z
    __log('timestr= %r' % timestr) 
    nowdate = nowS("%Y-%m-%d")
    __log('nowdate= %r' % nowdate)
    timestr = nowdate + ' ' + timestr
    __log('timestr= %r' % timestr) 
    ###ts = calendar.timegm(time.strptime(timestr, '%Y-%m-%d %H:%M'))  ###UTC
    ts = time.mktime(time.strptime(timestr, '%Y-%m-%d %H:%M'))
    
    ###ts = datetime.strptime(timestr, '%H:%M')
    __log('ts= %r' % ts) 
    timestamp = int(ts)
    __log('timestamp= %r' % timestamp) 
    """
    nowdate = nowS("%Y-%m-%d")
    __log('nowdate= %r' % nowdate)
    timestr = nowdate + ' ' + timestr
    __log('timestr= %r' % timestr) 
    time_tuple = time.strptime(timestr, "%Y-%m-%d %H:%M")
    __log('time_tuple= %r' % time_tuple) 
    timestamp = int(time.mktime(time_tuple))
    __log('timestamp= %r' % timestamp) 
    """
    return(timestamp)
    
def datestr(timestamp,format):   ### Now date string UTC time %Y-%m-%dT%H:%M:%S%z
    time_tuple = time.localtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)

def datestrdelta(timestamp,format):   ### Now date string UTC time %Y-%m-%dT%H:%M:%SZ
    time_tuple = time.gmtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)
    
def takeSecond(elem): 
    return elem[1]

def getSchedule(dataepg,station_id):   ### returns channelTitle, channelSlug, [schedule]
    __log('getSchedule(station_id= %r, dataepg= %r)'% (station_id,dataepg))
    utils.ADDONsetSetting('findstation#','187' + repr(sys.argv))
    if dataepg != '':
        datadict = xmltodict.parse(dataepg)
        __log('538 len(datadict)= %r' % len(datadict))
        __log('539 datadict= %r' % datadict)
        Channelfile = os.path.join(datapath, station_id + '.dic')  ### filename here 2022-05-31
        __log('540 Channelfile= %r' % Channelfile)
        try:
            with open(Channelfile,'wb') as output:
                ###output.write('%r'% datadict)
                __log('575 datadict= %r' % datadict)
                output.write(b'%r'% datadict)
            utils.ADDONsetSetting('findstation#','199' + repr(sys.argv))       
        except Exception as e:
            pass
            __log('552 write error Channelfile.dic= %r' % e)
        masterkey = '-html-body-script-0-'
        __log('554 masterkey= %r' % masterkey)
        datadict = datadict['html']['body']['script']      ### 2022-10-15 removed [0]
        __log('550 datadict= %r' % datadict)
        dict_keys = list(datadict.keys())
        __log('552 dict_keys= %r' % dict_keys)
        Channelfile = os.path.join(datapath, station_id + masterkey + '.keys')
        __log('589 Channelfile= %r' % Channelfile)
        try:
            with open(Channelfile,'wb') as output:
                output.write(b'%r'% dict_keys)
        except Exception as e:
            pass
            __log('559 write error Channelfile.keys= %r' % e)
        utils.ADDONsetSetting('findstation#','217' + repr(sys.argv))
        for i in range(len(dict_keys)):
            key = dict_keys[i]
            name = datadict[key] 
            __log('563 datadict[key= %r]= %r' % (key,name))
            if isinstance(name, list):
                for j in range(len(name)):
                    utils.ADDONsetSetting('findstation#','224' + repr(sys.argv))
                    Channelfile = os.path.join(datapath, station_id + masterkey + key + str(j) + '.dic')
                    __log('567 datadict[key= %r]= %r' % (key,j))
                    __log('568 datadict[key= %r] to %r' % (key,Channelfile))
                    try:
                        with open(Channelfile,'wb') as output:
                            output.write(b'%r'% name[j])
                    except Exception as e:
                        pass
                        __log('578 write error Channelfile.keys= %r' % e)
            else:
                utils.ADDONsetSetting('findstation#','235' + repr(sys.argv))
                Channelfile = os.path.join(datapath, station_id + masterkey + key + '.dic')
                __log('573 datadict[key= %r] to %r' % (key,Channelfile))
                try:
                    with open(Channelfile,'wb') as output:
                        output.write(b'%r'% name)
                except Exception as e:
                    pass
                    __log('587 write error Channelfile.keys= %r' % e)
            utils.ADDONsetSetting('findstation#','244' + repr(sys.argv))
            schedule = []
            __log('577 key= %r' % key)
            if key == '#text' :
                __log('579 key= %r' % key)
                utils.ADDONsetSetting('findstation#','249' + repr(sys.argv))
                datapanel = simplejson.loads(name)
                __log('581 datapanel= %r' % datapanel)
                try:
                    channelTitle= datapanel['props']['pageProps']['schedule']['channel']['title']
                    __log('582 channelTitle= %r' % channelTitle)
                    channelSlug = datapanel['props']['pageProps']['schedule']['channel']['slug']
                    __log('624 channelSlug= %r' % channelSlug)
                    items = datapanel['props']['pageProps']['schedule']['items']
                except Exception as e:
                    pass
                    __log('schedule Exception: %r' % e)
                    channelTitle = 'missing'
                    channelSlug = 'missing'
                    items = []   ### 2023-09-28
                for j in range(len(items)):
                    utils.ADDONsetSetting('findstation#','265' + repr(sys.argv))
                    startTime = datapanel['props']['pageProps']['schedule']['items'][j]['startTime']
                    __log('628 startTime= %r' % startTime)
                    endTime = datapanel['props']['pageProps']['schedule']['items'][j]['endTime']
                    __log('630 endTime= %r' % endTime)
                    title = datapanel['props']['pageProps']['schedule']['items'][j]['title']
                    __log('634 title= %r' % title)
                    try:
                        description = datapanel['props']['pageProps']['schedule']['items'][j]['description']
                        __log('636 description= %r' % description)
                    except Exception as e:
                        pass
                        description = ''
                    schedule.append([channelTitle,channelSlug,startTime,endTime,title,description])
                utils.ADDONsetSetting('findstation#','279' + repr(sys.argv))
                __log('3 Schedule= %r' % schedule)
                Channelfile = os.path.join(datapath, station_id + masterkey + key + '.json')
                try:
                    with open(Channelfile,'wb') as output:
                        output.write(b'%r'% schedule)
                except Exception as e:
                    pass
                    __log('621 write error Channelfile.keys= %r' % e)
        utils.ADDONsetSetting('findstation#','288' + repr(sys.argv))
        return [channelTitle, channelSlug, schedule]
    else:
        utils.ADDONsetSetting('findstation#','291' + repr(sys.argv))
        return ['','','']

def StartChannelFromSchedule():
    __log("StartChannelFromSchedule Start")
    utils.ADDONsetSetting('findstation#','296' + repr(sys.argv))
    dayofweek = datetime.today().weekday()
    nowts = now()
    __log('nowts= %r' % nowts)
    actualschedule = 'schedule' + str(dayofweek)
    __log('actualschedule= %r' % actualschedule)      
    schedule = utils.ADDONgetSetting(actualschedule)
    __log('schedule= %r' % schedule) 
    schedules = schedule.split(',')
    __log('schedules ,= %r' % schedules) 
    for schedule in schedules:
        utils.ADDONsetSetting('findstation#','307' + repr(sys.argv))
        __log('schedule in loop= %r' % schedule) 
        if schedule :
            station_id= schedule.split('@')[0]
            __log('station_id= %r' % station_id) 
            starttime = schedule.split('-')[0].split('@')[1]
            __log('starttime= %r' % starttime) 
            starttimeTS = humanTS(starttime)
            __log('starttimeTS= %r' % starttimeTS) 
            endtime   = schedule.split('-')[1]
            __log('endtime= %r' % endtime) 
            endtimeTS = humanTS(endtime)
            __log('endtimeTS= %r' % endtimeTS) 
            __log('schedule C= %r, S= %r, E= %r' % (station_id, starttime, endtime))
            __log('schedule C= %r, S= %r, N= %r, E= %r' % (station_id, starttimeTS-nowts, nowts, endtimeTS-nowts))
            ProgramPlaying = utils.ADDONgetSetting('programplaying')
            ProgramPlayingScheduled = utils.ADDONgetSetting('ProgramPlayingScheduled')
            __log('\nProgramPlaying         = %r\nProgramPlayingScheduled= %r' % (ProgramPlaying,ProgramPlayingScheduled))
            utils.ADDONsetSetting('findstation#','325' + repr(sys.argv))
            if starttimeTS < nowts and nowts < endtimeTS :
                __log("StartChannelFromSchedule Start Scheduled Channel if not active")
                if  ProgramPlaying != station_id :
                    __log("StartChannelFromSchedule Start Scheduled Channel")
                    StartProgramLocal(station_id,starttimeTS)  
                utils.ADDONsetSetting('ProgramPlayingScheduled',station_id)
                utils.ADDONsetSetting('findstation#','332' + repr(sys.argv))
                return True
            ###StartProgram(station_id,starttimeTS)
    utils.ADDONsetSetting('findstation#','335' + repr(sys.argv))
    __log("StartChannelFromSchedule NO Start of Scheduled Channel")
    return False
    
def direct_play(url):
    __log("direct_play ["+url+"]")
    utils.ADDONsetSetting('findstation#','341' + repr(sys.argv))
    title = ""

    try:
        xlistitem = xbmcgui.ListItem( title, path=url)
    except Exception as e:
        pass
        xlistitem = xbmcgui.ListItem( title )
    xlistitem.setArt({ 'icon': "DefaultAudio.png", 'thumb' : "DefaultAudio.png" })
    ###xlistitem.setInfo( "audio", { 'title': title } )
    if INFO_TAG:
        info_tag = ListItemInfoTag(xlistitem, 'music')
        infolabels = { 'title': channel.name }  ###, 'genre': 'Not Set' }
        info_tag.set_info(infolabels)
        __log('326 infolabels= %r' % infolabels)
    utils.ADDONsetSetting('findstation#','355' + repr(sys.argv))
    playlist = xbmc.PlayList( xbmc.PLAYLIST_MUSIC )
    player_type = xbmc.PLAYER_CORE_AUTO
    xbmcPlayer = xbmc.Player( player_type )
    xbmcPlayer.play(playlist) 
    station_id = channels.CHANNELS[0].name
    utils.setChannelVolumen(station_id)    ### 2024-02-10
    utils.ADDONsetSetting('findstation#','360' + repr(sys.argv))
    
def StopAllStartProgramTimers():
    utils.ADDONsetSetting('findstation#','363' + repr(sys.argv))
    for radioEPGi in channelsDR.CHANNELS:   ### DR Channels
        station_id = radioEPGi.name
        nameAlarm = ADDONid + '-start-' + onlyAscii(str(station_id))
        xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
        __log('CancelAlarm(%s,True)' % nameAlarm)
    for radioEPGi in channels.CHANNELS:  ### Other channels
        station_id = radioEPGi.name
        nameAlarm = ADDONid + '-start-' + onlyAscii(str(station_id))
        xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
        __log('CancelAlarm(%s,True)' % nameAlarm)

def StartProgramLocal(station_id,timestamp):
    utils.ADDONsetSetting('findstation#','376' + repr(sys.argv))
    try:
        
        __log('StartProgramLocal ADDON %r - %r' % (ADDONname,ADDONid))
        __log('StartProgramLocal station_id= %r Start @ %r' % (station_id,datestr(timestamp,'%H:%M:%S')))
        __log('StartProgramLocal station_id= %r Start @ %r' % (station_id,timestamp))
        __log('StartProgramLocal station_id= %r Start @ %r' % (station_id,humantime(timestamp)))
        if not station_id:
            station_id = preferredstation
            __log('StartProgramLocal playEPG(DEFAULT station_id= %r)' % station_id)
        script = os.path.join(ADDONpath, 'startstation.py')    
        ###script = os.path.join(PATH, 'startstation.py')
        __log('StartProgramLocal script= %r' % script)
        nameAlarm = ADDONid + '-startLocal-' + onlyAscii(str(station_id)) 
        __log('StartProgramLocal nameAlarm= %r' % nameAlarm)
        utils.ADDONsetSetting('findstation#','391' + repr(sys.argv))
        delay = timestamp - now()
        if delay < 0:
            delay = 0
        __log('StartProgramLocal delay= %r' % delay)
        delayHMS = datestrdelta(delay,'%H:%M:%S')
        __log('StartProgramLocal delayHMS= %r' % delayHMS)
        if delay >= 0 and delay < 24*3600:
            utils.ADDONsetSetting('findstation#','399' + repr(sys.argv))
            cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),%s,silent)' % (nameAlarm, script, PATH,station_id,delayHMS)
            __log('StartProgramLocal cmd= %s' % cmd)
            
            ###__log('StartProgramLocal LastStartStation:' + station_id + ': '+datestr(TS(timestamp),'d%dh%Hm%M'))
            ###utils.ADDONsetSetting('LastStartStation',station_id + ': '+datestr(timestamp,'d%dh%Hm%Ms%S'))
            ###utils.ADDONsetSetting('LastStartStation',station_id + ': '+datestrdelta(timestamp,'d%dh%Hm%M'))
            utils.ADDONsetSetting('LastStartStation',station_id + ': '+datestr(timestamp,'d%dh%Hm%M'))
            utils.ADDONsetSetting('StartStation',station_id)
            utils.setChannelVolumen(station_id)   ### 2023-12-17
            xbmc.executebuiltin(cmd)  # Active
    except Exception as e:
        pass
        __log('StartProgramLocal(station_id= %r,timestamp= %r) ERROR: %r' % (station_id,timestamp,e))

def onlyAscii(unicrap):
    """This takes a UNICODE string and ignores all characters 128 (0x80) and higher
    """ 
    r = ''
    for i in unicrap:
        if ord(i) >= 0x80:
            pass
        else:
            r += str(i)
    return r

def showError(message):
    utils.ADDONsetSetting('findstation#','425' + repr(sys.argv))
    heading = 'Error in Findstation!'
    line1 = ADDON.getLocalizedString(30900)
    line2 = ADDON.getLocalizedString(30901)
    ###xbmcgui.Dialog().ok(heading, line1, line2, message)
    __log(heading+'\n'+line1+'\n'+line2+'\n'+message)
    utils.ADDONsetSetting('findstation#','431' + repr(sys.argv))

def sleep(sleeptime):
    __log('sleep(sleeptime= %r)' % (sleeptime))
    utils.ADDONsetSetting('findstation#','435' + repr(sys.argv))
    xbmc.sleep(sleeptime) 
    utils.ADDONsetSetting('findstation#','437' + repr(sys.argv))
   
def playEPG(idx):
    __log('playEPG(idx= %r)'% idx)
    utils.ADDONsetSetting('findstation#','441' + repr(sys.argv))
    try:
        u = urlopen(CHANNELS_URL)
        utils.ADDONsetSetting('findstation#','444' + repr(sys.argv))
        channelList = simplejson.loads(u.read())
        utils.ADDONsetSetting('findstation#','446' + repr(sys.argv))
        u.close()
    except Exception as  ex:
        pass
        utils.ADDONsetSetting('findstation#','450' + repr(sys.argv))
        showError(str(ex))
        return
    try:
        for channel in channelList:
            utils.ADDONsetSetting('findstation#','455' + repr(sys.argv))
            title = channel['Title']
            slug  = channel['Slug']
            if title[0:3] == 'DR ':
                title = title[3:]
            __log('playEPG(title= %r slug= %r)'% (title,slug))
            idxlower = idx.lower()
            station_id = idxlower
            utils.ADDONsetSetting('findstation#','462' + repr(sys.argv))
            if (('p4' in idxlower and idxlower == slug) or idxlower[:2] == slug[:2] and not 'p4' in idxlower) or (('p5' in idxlower and idxlower == slug) or idxlower[:2] == slug[:2] and not 'p5' in idxlower):   ### 2023-11-02
            ###if idx.lower() == slug:
                utils.ADDONsetSetting('findstation#','465' + repr(sys.argv))
                sourceUrl = channel['SourceUrl']
                logoImage = os.path.join(LOGO_PATH, sourceUrl[sourceUrl.rindex('/') + 1:] + '.png')
                if xbmcvfs.exists(logoImage):
                    item = xbmcgui.ListItem(title)
                    item.setArt({ 'icon': logoImage, 'thumb' : logoImage })
                    limage = logoImage
                else:
                    item = xbmcgui.ListItem(title)
                    item.setArt({ 'icon': ICON, 'thumb' : ICON })
                    limage = ICON
                utils.ADDONsetSetting('findstation#','476' + repr(sys.argv))
                item.setProperty('IsPlayable', 'true')
                item.setProperty('Fanart_Image', FANART)
                if INFO_TAG:
                    info_tag = ListItemInfoTag(item, 'music')
                    infolabels = { 'title': title } ###, 'genre': 'Not Set' }
                    info_tag.set_info(infolabels)
                    __log('1715 infolabels= %r' % infolabels)
                """
                item.setInfo(type='music', infoLabels={
                    'title': title
                })
                """
                utils.ADDONsetSetting('findstation#','488' + repr(sys.argv))
                url = None

                if 'StreamingServers' in channel:
                    for server in channel['StreamingServers']:
                        utils.ADDONsetSetting('findstation#','493' + repr(sys.argv))
                        if 'LinkType' in server and server['LinkType'] == 'ICY' and 'Qualities' in server:
                            try:
                                utils.ADDONsetSetting('findstation#','496' + repr(sys.argv))
                                url = server['Server'] + '/' + server['Qualities'][0]['Streams'][0]['Stream']
                                break
                                utils.ADDONsetSetting('findstation#','499' + repr(sys.argv))
                            except:
                                pass
                                utils.ADDONsetSetting('findstation#','502' + repr(sys.argv))
                __log('playEPG(url= %r)'% url)
                utils.ADDONsetSetting('findstation#','504' + repr(sys.argv))
                if url:
                    __log('play-ing-EPG(url= %r)'% url)
                    utils.ADDONsetSetting('findstation#','507' + repr(sys.argv))
                    logoImage = os.path.join(LOGO_PATH, title + '.png')
                    item = xbmcgui.ListItem(path=url, thumbnailImage=logoImage)
                    if INFO_TAG:
                        info_tag = ListItemInfoTag(item, 'music')
                        infolabels = { 'title': title } ###, 'genre': 'Not Set' }
                        info_tag.set_info(infolabels)
                        __log('459 infolabels= %r' % infolabels)
                    """
                    item.setInfo(type='music', infoLabels={
                        'title': title
                    })
                    """
                    utils.ADDONsetSetting('findstation#','519' + repr(sys.argv))
                    xbmc.Player().play(url, item, True)
                    utils.setChannelVolumen(station_id)    ### 2024-02-10
                    __log('play-ing-EPG-started(url= %r)'% url)
                utils.ADDONsetSetting('findstation#','522' + repr(sys.argv))
                break   ### Stop at first match
        utils.ADDONsetSetting('findstation#','524' + repr(sys.argv))
    except Exception as e:
        pass
        __log('PlayEPG ERROR: %r' % e)
    utils.ADDONsetSetting('findstation#','528' + repr(sys.argv))
 
def programsnow(programs):
    utils.ADDONsetSetting('findstation#','531' + repr(sys.argv))
    programsjustnow = []
    i = 0
    for program in programs:
        i += 1
        __log('544 #%r program= %r' % (i,program))
        utils.ADDONsetSetting('findstation#','536' + repr(sys.argv))
        __log('546 #%r program= %r' % (i,program))
        __log('547 program[2]= %r ' % program[2])
        stop = program[2]
        __log('549 stop= %r' % stop)
        stop = datestr(TS(stop) - 10,dateformat)   ### adjust stop with 10 seconds
        __log('551 stop= %r' % stop)
        start = program[1]
        __log('553 start= %r' % start)
        start = datestr(TS(start) - 10,dateformat)   ### adjust start with 10 seconds
        __log('555 start= %r' % start)
        __log('556 #%r program= %r' % (i,program))
        if TS(stop) > nowTS() and nowTS() >= TS(start):
            programsjustnow.append(program)
        utils.ADDONsetSetting('findstation#','559 program= %r  + %r' % (program, sys.argv))
    utils.ADDONsetSetting('findstation#','560' + repr(sys.argv))
    return programsjustnow
    
try:
    progAddon  = sys.argv[0]
    PATHargv   = sys.argv[1]
    Interval   = sys.argv[2]
    utils.ADDONsetSetting('LastFindStationStart',datestr(nowTS(),dateformat))
    ###addon.
    utils.ADDONsetSetting('findstation#','560' + repr(sys.argv))
    utils.shareLogs(False)  ### Only change in addon and not in this
    utils.ADDONsetSetting('findstation#','562' + repr(sys.argv))
    
except Exception as e:
    pass
    utils.ADDONsetSetting('findstation#','566' + repr(sys.argv))
    title    = 'FindStation'
    PATHargv = repr(e)
    Interval = '00:01:00'
    
try:
    utils.ADDONsetSetting('findstation#','572' + repr(sys.argv))
    count = 0
    count += 1
    utils.ADDONsetSetting('count','Line# %r, %r, %r' % (512,count,sys.argv))
    __log('sys.argv= %r' % sys.argv)
    __log('os.environ= %s' % os.environ['OS'] ) #put in LOG
    __log('PATH= %r' % PATH)
    __log('PATHargv= %r' % PATHargv)
    __log('LOGO_PATH= %r' % LOGO_PATH)
    __log('ICON= %r' % ICON)
    __log('FANART= %r' % FANART)
    utils.ADDONsetSetting('findstation#','583' + repr(sys.argv))
except Exception as e:
    pass
    __log('586 ERROR data: %r' % e)
try:
    utils.ADDONsetSetting('findstation#','588' + repr(sys.argv))
    player = xbmc.Player()
    try:
        count += 1
        utils.ADDONsetSetting('count','Line# %r, %r' % (530,count))
        timebetweenupdates = utils.ADDONgetSetting('timebetweenupdates').split(':')
        __log('402 timebetweenupdates= %r' % timebetweenupdates)
        timebetweenupdatesH = int(timebetweenupdates[0])
        timebetweenupdatesM = int(timebetweenupdates[1])
        timebetweenupdatesS = int(timebetweenupdates[2])
        
        timeaftervideodummy = int(utils.ADDONgetSetting('timeaftervideo'))//(timebetweenupdatesH*3600 + timebetweenupdatesM*60 + timebetweenupdatesS)
        __log('timeaftervideodummy= %r' % timeaftervideodummy)
        utils.ADDONsetSetting('findstation#','601' + repr(sys.argv))
    except Exception as e:
        pass
        timeaftervideodummy = 5
        __log('605timeaftervideodummy ERROR: %r' % e)
    utils.ADDONsetSetting('findstation#','606' + repr(sys.argv))
    if player.isPlayingAudio():
        utils.ADDONsetSetting('findstation#','608' + repr(sys.argv))
        music = xbmc.Player().getMusicInfoTag()
        title = music.getTitle()
        __log('music.getTitle()= %r' % title)
        __log('getMusicInfoTag()= %r' % music)
        __log('music.getURL= %r' % music.getURL())
        __log('music.getTitle= %r' % music.getTitle())
        __log('music.getArtist= %r' % music.getArtist())
        __log('music.getTrack= %r' % music.getTrack())
    else:
        utils.ADDONsetSetting('findstation#','618' + repr(sys.argv))
        __log('getMusicInfoTag()= %r' % 'Not playing Music!')
    count += 1
    utils.ADDONsetSetting('count','Line# %r, %r' % (556,count))
    if player.isPlayingVideo():
        PlayingVideo = True
        timeaftervideo = timeaftervideodummy
        try:
            utils.ADDONsetSetting('findstation#','626' + repr(sys.argv))
            utils.ADDONsetSetting('timeaftervideo',str(timeaftervideo*(timebetweenupdatesH*3600 + timebetweenupdatesM*60 + timebetweenupdatesS)))  ### Adjust to actual time based on timeupdateinterval
            utils.ADDONsetSetting('timeaftervideocounter',str(timeaftervideo))
        except Exception as e:
            pass
            __log('1 timeaftervideo ERROR: %r' % e)
        utils.ADDONsetSetting('findstation#','632' + repr(sys.argv))
        __log('PlayingVideo = True')
    else:
        PlayingVideo = False
        timeaftervideoI = utils.ADDONgetSetting('timeaftervideocounter')
        utils.ADDONsetSetting('findstation#','637' + repr(sys.argv))
        if timeaftervideoI == '':
            timeaftervideoI = timeaftervideodummy
        timeaftervideo = int(timeaftervideoI)
        timeaftervideo -= 1
        if timeaftervideo <= 0:
            timeaftervideo = 0
        utils.ADDONsetSetting('timeaftervideocounter',str(timeaftervideo))
        __log('PlayingVideo = False')
except Exception as e:
    pass
    utils.ADDONsetSetting('findstation#','648' + repr(sys.argv))
    PlayingVideo = False
    timeaftervideo = timeaftervideodummy
    try:
        utils.ADDONsetSetting('timeaftervideo',str(timeaftervideo*(timebetweenupdatesH*3600 + timebetweenupdatesM*60 + timebetweenupdatesS)))
    except Exception as e:
        pass
        __log('2 timeaftervideo ERROR: %r' % e)
    utils.ADDONsetSetting('timeaftervideocounter',str(timeaftervideo))
    __log('Is Palying Video Test ERROR: %r' % e)
    utils.ADDONsetSetting('findstation#','658' + repr(sys.argv))
utils.ADDONsetSetting('findstation#','659' + repr(sys.argv)) 
try:
    count += 1
    utils.ADDONsetSetting('count','Line# %r, %r' % (593,count))
    __log('code part:Play Video= %r, timeaftervideo= %r' % (PlayingVideo,timeaftervideo))
    timer = now()
    __log('Timer at start! %r' % timer)
    utils.ADDONsetSetting('findstation#','666' + repr(sys.argv))
    if not PlayingVideo and timeaftervideo <= 0 :
        programswanted = utils.ADDONgetSetting('programswanted').lower().split(',')
        __log('programswanted= %r' % programswanted)
        ProgramPlaying = utils.ADDONgetSetting('programplaying')
        __log('ProgramPlaying= at start %r' % ProgramPlaying)
        programsnogo   = utils.ADDONgetSetting('programsnogo').lower().split(',')
        __log('programsnogo= %r' % programsnogo)
        preferredstation = utils.ADDONgetSetting('preferredstation') ### P4 København
        __log('preferredstation= %r' % preferredstation)
        backupstation    = utils.ADDONgetSetting('backupstation') ### P5
        __log('backupstation= %r' % backupstation)
        backupbackupstation    = utils.ADDONgetSetting('backupbackupstation') ### DR P6 Beat
        __log('backupbackupstation= %r' % backupbackupstation)
        ###utils.ADDONsetSetting('now','Now in UTC: %s' % nowS("%Y-%m-%dT%H:%M:%S%z"))
        __log('now= %r' % datestr(now(),"%Y-%m-%d %H:%M:%S"))
        utils.ADDONsetSetting('now','%s' % datestr(now(),"%Y-%m-%d %H:%M:%S"))
        utils.TestInfoTag(module)
        utils.ADDONsetSetting('findstation#','684' + repr(sys.argv))
        count += 1
        utils.ADDONsetSetting('count','Line# %r, %r' % (615,count))
        utils.ADDONsetSetting('findstation_running','false')
        __log('626 TEST findstation_running= false')
        try:
            utils.ADDONsetSetting('findstation#','690' + repr(sys.argv))
            player = xbmc.Player()
            if not player.isPlayingAudio():   ### 2023-11-03
                __log('Player is not playing at start')
                utils.ADDONsetSetting('findstation#','694' + repr(sys.argv))
                ###if ProgramPlaying == '':
                ProgramPlaying = preferredstation    ### If not playing - start preferred station
                __log('534 setSetting(programplaying= %r' % ProgramPlaying)
                utils.ADDONsetSetting('programplaying',ProgramPlaying)
                __log('ADDONgetSetting(ProgramPlaying 1= %r)' % utils.ADDONgetSetting('programplaying'))
                utils.ADDONsetSetting('findstation#','700' + repr(sys.argv))
                utils.StartProgram(ProgramPlaying,nowTS())
                utils.ADDONsetSetting('findstation#','702' + repr(sys.argv))
                ###sleep(2000)  ### 2023-11-03
            __log('ADDONgetSetting(ProgramPlaying 2= %r)' % utils.ADDONgetSetting('programplaying'))
            P4selected = utils.ADDONgetSetting('selectedp4station')
            P5selected = utils.ADDONgetSetting('selectedp5station')
            ### Set Volumen!  2024-06-05
            __log('Video is not playing')
            utils.setChannelVolumen(P4selected)
            __log('after utils.setChannelVolumen(station_id= %r)' % P4selected )
            items = []
            WantedPrograms = []
            NogoPrograms   = []
            scheduleActive = True
            utils.ADDONsetSetting('findstation#','711' + repr(sys.argv))
            count += 1
            utils.ADDONsetSetting('count','Line# %r, %r' % (635,count))
            utils.ADDONsetSetting('findstation_running','false')
            __log('646 TEST findstation_running= false')
            if not StartChannelFromSchedule():
                scheduleActive = False
                __log('After StartChannelFromSchedule NOT Started')
                utils.ADDONsetSetting('findstation#','719' + repr(sys.argv))
                for radioEPGi in channelsDR.CHANNELS:
                    utils.ADDONsetSetting('findstation#','721 %r, %r' % (radioEPGi.name, sys.argv))
                    count += 1
                    utils.ADDONsetSetting('count','Line# %r, %r' % (641,count))
                    station_id = radioEPGi.name
                    radioEPG  = radioEPGi.epg
                    __log('station_id= %r ' % station_id)
                    utils.ADDONsetSetting('findstation#','726' + repr(sys.argv))
                    if 'P4' in station_id and not station_id == P4selected:
                        __log('Ignore Station: %r' % station_id)
                    elif 'P5' in station_id and not station_id == P5selected:
                        __log('Ignore Station: %r' % station_id)
                    else:
                        utils.ADDONsetSetting('findstation#','732' + repr(sys.argv))
                        if useepg and radioEPG != '':
                            count += 1
                            utils.ADDONsetSetting('count','Line# %r, %r' % (652,count))
                            __log('765 station_id= %r, radioEPG= %r ' % (station_id,radioEPG))
                            
                            maxage= utils.max_age()
                            __log('671 maxage= %r' % maxage)
                            resp = utils.readChannelEPG(station_id,radioEPG,maxage)
                            __log('673 resp= %r' % resp)
                            utils.ADDONsetSetting('findstation#','742' + repr(sys.argv))
                            dataepg = resp
                            
                            ###Schedule = addon.getSchedule(dataepg,station_id)   ### returns channelTitle, channelSlug, [schedule]
                            __log('667 getSchedule(station_id= %r, dataepg= %r)'% (station_id,dataepg))
                            utils.ADDONsetSetting('findstation#','747' + repr(sys.argv))
                            Schedule = getSchedule(dataepg,station_id)   ### returns channelTitle, channelSlug, [schedule]
                            __log('679 getSchedule(station_id= %r, dataepg= %r)'% (station_id,dataepg))
                            utils.ADDONsetSetting('findstation#','750' + repr(sys.argv))
                            stationname =  Schedule[0]
                            __log('667 stationname= %r' % stationname)
                            __log('668 Schedule[2]= %r' % Schedule[2])
                            for programX in Schedule[2]:
                                utils.ADDONsetSetting('findstation#','755 programX= %r, titel= %r, %r' % (programX[1],programX[4],sys.argv))
                                count += 1
                                utils.ADDONsetSetting('count','Line# %r, %r, %r' % (671,count,programX[0]))
                                ### schedule.append([channelTitle 0,channelSlug 1,startTime 2,endTime 3,title 4,description 5])
                                stop = programX[3]
                                __log('692 stop= %r' % stop)
                                ### datestr(timestamp,format):   ### Date string UTC time %Y-%m-%dT%H:%M:%S%z
                                stop = datestr(TS(stop) - 120,dateformat)   ### adjust stop with 2 minute
                                __log('695 stop= %r' % stop)
                                start = programX[2]
                                __log('697 start= %r' % start)
                                startactual = programX[2]
                                __log('698 startactual= %r' % startactual)
                                utils.ADDONsetSetting('findstation#','768' + repr(sys.argv))
                                if TS(stop) > nowTS():
                                    title = programX[4]
                                    titleDesc = programX[4] + programX[5]   ### 2023-05-24 Go/Nogo search in title and description
                                    __log('685 title= %r' % title)
                                    description= programX[5]
                                    channel= programX[0]   
                                    __log('688 channel= %r' % channel)
                                    utils.ADDONsetSetting('findstation#','776' + repr(sys.argv))
                                    for wanted in programswanted:
                                        __log('581 onlyAscii(titleDesc= %r\nonlyAscii(wanted= %r' % (onlyAscii(titleDesc.lower()),onlyAscii(wanted.lower())))
                                        if onlyAscii(wanted.lower()) in onlyAscii(titleDesc.lower()):
                                            WantedPrograms.append([station_id,startactual,stop,title,description,channel])
                                    for notwanted in programsnogo:
                                        __log('585 onlyAscii(titleDesc= %r\nonlyAscii(notwanted= %r' % (onlyAscii(titleDesc.lower()),onlyAscii(notwanted.lower())))
                                        if onlyAscii(notwanted.lower()) in onlyAscii(titleDesc.lower()):
                                            NogoPrograms.append([station_id,startactual,stop,title,description,channel])
                                    utils.ADDONsetSetting('findstation#','785' + repr(sys.argv))
                                    count += 1
                                    utils.ADDONsetSetting('count','Line# %r, %r' % (698,count))
                                utils.ADDONsetSetting('findstation#','788' + repr(sys.argv))
                            __log('620 \nWantedPrograms= %r\nNogoPrograms  = %r' % (WantedPrograms,NogoPrograms))
                            utils.ADDONsetSetting('findstation#','790 %r, %r' % (radioEPGi.name,sys.argv))
                        utils.ADDONsetSetting('findstation#','791 %r, %r' % (radioEPGi.name,sys.argv))
                    utils.ADDONsetSetting('findstation#','792 %r, %r' % (radioEPGi.name,sys.argv))
                utils.ADDONsetSetting('findstation#','793 %r, %r' % (radioEPGi.name,sys.argv))
            utils.ADDONsetSetting('findstation#','794' + repr(sys.argv))
            __log('568 After StartChannelFromSchedule')
            utils.ADDONsetSetting('findstation#','796' + repr(sys.argv))
        except Exception as e:
            pass
            __log('571 radioEPG ERROR: %r' % e)
        utils.ADDONsetSetting('findstation#','800' + repr(sys.argv))
        utils.ADDONsetSetting('findstation_running','false')
        __log('717 TEST findstation_running= false')
        
        count += 1
        utils.ADDONsetSetting('count','Line# %r, %r' % (705,count))
        __log('807 Timer at Programs %r' % (now() - timer))
        Programs = []
        nowStart = now()
        __log('810')
        nowEnd   = AdjustDateTime(nowStart,1,0)
        __log('812')
        utils.ADDONsetSetting('findstation#','813' + repr(sys.argv))
        ###datestr(timestamp,format)
        __log('815')
        nowStartS = datestrdelta(nowStart,dateformat)
        __log('817')
        nowEndS   = datestr(nowEnd,dateformat)
        __log('819')
        WantedPrograms = programsnow(WantedPrograms)
        __log('821')
        utils.logasfile('WantedPrograms.log',WantedPrograms)
        __log('823')
        NogoPrograms = programsnow(NogoPrograms)
        utils.logasfile('NogoPrograms.log',NogoPrograms)
        utils.ADDONsetSetting('findstation#','818' + repr(sys.argv))
        WantedPrograms.append([preferredstation ,nowStartS,nowEndS,'Prefered Station','Default Prefered Station',preferredstation])
        ###utils.logasfile('WantedPrograms1.log',WantedPrograms)
        WantedPrograms.append([backupstation,nowStartS,nowEndS,'Backup Station','Default Backup Station',backupstation])
        ###utils.logasfile('WantedPrograms2.log',WantedPrograms)
        WantedPrograms.append([backupbackupstation,nowStartS,nowEndS,'Backupx2 Station','Default Backupx2 Station',backupbackupstation])
        ###utils.logasfile('WantedPrograms3.log',WantedPrograms)
        LastChannel = channelsDR.CHANNELS[-1].name
        __log('LastChannel= %r' % LastChannel)
        WantedPrograms.append([LastChannel,nowStartS,nowEndS,'Last Station','Last Station',LastChannel])
        utils.logasfile('WantedProgramsAll.log',WantedPrograms)
        utils.ADDONsetSetting('findstation#','829' + repr(sys.argv))
        count += 1
        utils.ADDONsetSetting('count','Line# %r, %r' % (729,count))
        if WantedPrograms != []:
            __log('705 WantedPrograms= %r' % WantedPrograms)
            utils.ADDONsetSetting('findstation#','834' + repr(sys.argv))
            for prog in WantedPrograms:  ### Dont accept nogo programs
                count += 1
                utils.ADDONsetSetting('count','Line# %r, %r' % (734,count))
                utils.ADDONsetSetting('findstation#','838' + repr(sys.argv))
                if NogoPrograms != []:
                    NogoProgramsChan = [item[0] for item in NogoPrograms]
                    __log('prog[0]= %r, NogoPrograms[0]= %r' % (prog[0], NogoProgramsChan))
                    if not prog[0] in NogoProgramsChan:
                        __log('1: prog[0]= %r, NogoPrograms[0]= %r' % (prog[0], NogoProgramsChan))
                        Programs.append(prog)
                    utils.ADDONsetSetting('findstation#','845' + repr(sys.argv))
                else:
                    utils.ADDONsetSetting('findstation#','847' + repr(sys.argv))
                    Programs.append(prog)
            utils.ADDONsetSetting('findstation#','849' + repr(sys.argv))
        utils.ADDONsetSetting('findstation#','850' + repr(sys.argv))
        count += 1
        utils.ADDONsetSetting('count','Line# %r, %r' % (744,count))
        Programs = programsnow(Programs)
        Programs = sorted(Programs, key=takeSecond)
        utils.logasfile('ProgramsNow.log',Programs)
        ProgramPlaying = utils.ADDONgetSetting('programplaying')
        __log('Programs[0][0]= %r' % Programs[0][0])
        __log('ProgramPlaying= %r' % ProgramPlaying)
        if Programs[0][0] != ProgramPlaying :
            __log('Start playing wanted channel %r' % Programs[0][0])
            utils.StartProgram(Programs[0][0],0)
        else:
            __log('Already playing wanted channel')
        utils.ADDONsetSetting('findstation#','864' + repr(sys.argv))
        count += 1
        utils.ADDONsetSetting('count','Line# %r, %r' % (840,count))
        CurrentWindowId = repr(xbmcgui.getCurrentWindowId())
        EPGWindowId = utils.ADDONgetSetting('EPGWindowId')
        __log('FindStation module= %r, CurrentWindowIdWindowId= %r, EPGWindowId= %r' % (module, CurrentWindowId, EPGWindowId))
        ###ContainerContent = xbmc.executebuiltin("Container.FolderName")
        ###utils.logdev('window','Container.FolderName= %r' % ContainerContent)
        ###currentWindow = xbmcgui.Window(xbmcgui.getCurrentWindowId())
        ###utils.logdev('window','currentWindow(%r)' % currentWindow)
        ###currentControlList = currentWindow.getFocusId()
        ###utils.logdev('window','currentControlList(%r)' % currentControlList)
        ###selectedListItem = currentWindow.getControl(currentControlList).getSelectedItem()
        ###utils.logdev('window','selectedListItem(%s)' % selectedListItem)
        __log('xbmc.Player().isPlayingAudio() ???')
        count += 1
        utils.ADDONsetSetting('count','Line# %r, %r' % (854,count))
        utils.ADDONsetSetting('findstation#','881' + repr(sys.argv))
        if xbmc.Player().isPlayingAudio():
            count += 1
            utils.ADDONsetSetting('count','Line# %r, %r' % (857,count))
            __log('xbmc.Player().isPlayingAudio()')
            utils.ADDONsetSetting('findstation#','886' + repr(sys.argv))
            music = xbmc.Player().getMusicInfoTag()
            title = music.getTitle()
            ###title = 'TEST'   ### TEST 2023-09-14  #####################################################
            __log('music.getTitle()= %r' % title)
            titleOLD = utils.ADDONgetSetting('titleOLD')
            __log('titleOLD= %r' % titleOLD)
            titleOLDtime = utils.ADDONgetSetting('titleOLDtime')
            __log('titleOLDtime= %r' % titleOLDtime)
            if titleOLD != title :
                __log('titleOLD != title %r != %r' % (titleOLD, title))
                utils.ADDONsetSetting('titleOLD',title)
                utils.ADDONsetSetting('titleOLDtime','%s' % datestr(now(),"%Y-%m-%d %H:%M:%S"))
            else:
                __log('titleOLD == title %r' % title)
            try:
                utils.ADDONsetSetting('findstation#','902' + repr(sys.argv))
                count += 1
                utils.ADDONsetSetting('count','Line# %r, %r' % (875,count))
                utils.ADDONsetSetting('titleOLDtimenow','%s' % datestr(now(),"%Y-%m-%d %H:%M:%S"))
                titleOLDtimenow = utils.ADDONgetSetting('titleOLDtimenow')
                __log('utils.ADDONgetSetting(titleOLDtimenow)= %r' % titleOLDtimenow)
                __log('utils.ADDONgetSetting(TSx(titleOLDtimenow))= %r' % TSx(titleOLDtimenow))
                __log('utils.ADDONgetSetting(titleOLDtime)= %r' % titleOLDtime)
                __log('utils.ADDONgetSetting(TSx(titleOLDtime))= %r' % TSx(titleOLDtime))  
                diff = TSx(titleOLDtimenow) - TSx(titleOLDtime)
                __log('TSx(titleOLDtimenow) - TSx(titleOLDtime)= %r' % diff)
            except Exception as e:
                pass
                __log('diff ERROR: %r' % e)
                diff = 0
                utils.ADDONsetSetting('findstation#','917' + repr(sys.argv))
            count += 1
            utils.ADDONsetSetting('count','Line# %r, %r' % (889,count))
            if titleOLD == title and diff > 10*60:  ### 10 minutes
                __log('Play Title is NOT updating')
                utils.ADDONsetSetting('titleupdating',ADDON.getLocalizedString(30413))
            else:
                __log('Play Title is updating')
                titletext = ADDON.getLocalizedString(30404)+ ': ' + title
                utils.ADDONsetSetting('titleupdating',titletext)   ### 2023-09-13 ' ' --> titletext
            __log('getMusicInfoTag()= %r' % music)
            __log('music.getURL= %r' % music.getURL())
            __log('music.getTitle= %r' % music.getTitle())
            __log('music.getArtist= %r' % music.getArtist())
            __log('music.getTrack= %r' % music.getTrack())
            utils.ADDONsetSetting('findstation#','932' + repr(sys.argv))    
        else:
            utils.ADDONsetSetting('findstation#','934' + repr(sys.argv))
            __log('xbmc.Player().isPlayingAudio() NO NOT PLAYING')
            utils.StartProgram(utils.ADDONgetSetting('preferredstation'),nowTS())
        utils.ADDONsetSetting('findstation#','937' + repr(sys.argv))
        count += 1
        utils.ADDONsetSetting('count','Line# %r, %r' % (906,count))    
        if CurrentWindowId == EPGWindowId and 1 == 0:   ### Disable refresh  2023-11-12
            utils.logdev('window','ActivateWindow(%s)' % EPGWindowId.replace("'",""))
            xbmc.executebuiltin("ActivateWindow(%s)" % EPGWindowId.replace("'",""))
            xbmc.executebuiltin("Container.Refresh")
        utils.ADDONsetSetting('findstation#','944' + repr(sys.argv))
    else:
        count += 1
        utils.ADDONsetSetting('count','Line# %r, %r' % (913,count))
        __log('PlayingVideo or timeaftervideo > 0')
        utils.ADDONsetSetting('findstation#','949' + repr(sys.argv))
    __log('Find station finished')
    utils.ADDONsetSetting('findstation#','951' + repr(sys.argv))
except Exception as e:
    pass
    __log('878 ERROR: %r' % e)
    utils.ADDONsetSetting('findstation#','955' + repr(sys.argv))
utils.ADDONsetSetting('findstation#','956' + repr(sys.argv))
count += 1
programplaying = utils.ADDONgetSetting('programplaying')   ### 2023-12-18
utils.setChannelVolumen(programplaying)   ### 2023-12-18
utils.ADDONsetSetting('count','Line# %r, %r' % (920,count))
__log('Find Station Total Finished')
__log('now()= %r' % now())
__log('timer= %r' % timer)
__log('Timer at Finished %r' % (now() - timer))
utils.ADDONsetSetting('findstationrunning','false')
__log('findstationrunning= false')
utils.ADDONsetSetting('findstation#','965' + repr(sys.argv))
###exit()
###utils.ADDONsetSetting('findstation#','967' + repr(sys.argv))