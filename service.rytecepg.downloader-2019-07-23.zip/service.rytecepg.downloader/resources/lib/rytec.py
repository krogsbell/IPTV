#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmcaddon
import os
import requests
import gzip
import re
import random
import xbmcvfs
import xbmc
import xml.etree.ElementTree as ET
from StringIO import StringIO
import common
import datetime

__version__ = '0.5.1'
__author__ = 'Jin'
epgsources = 'aHR0cDovL2VwZ2FsZmFzaXRlLmR5bmRucy50di9rb2RpLWVwZ3NvdXJjZXM='
headers = {'User-Agent': 'Rytec EPG Downloader %s by %s' % (__version__,__author__), 'Referer': 'rytecepgdownloader.%s' % (__version__)}

###id = 'service.rytecepg.downloader'
addon = xbmcaddon.Addon()
IMAGE = os.path.join(addon.getAddonInfo('path'), 'icon.png')

def logX(message):
    xbmc.log('[Rytec EPG Downloader rytec.py]: '  + message)
    
def log(message):
    if addon.getSetting('addonlog') == '1':
        logX(message)
    else:
        module = 'rytec.py'
        nowHMS=datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        datapath = xbmc.translatePath(addon.getAddonInfo('profile'))
        addonlog = os.path.join(datapath, 'addon.log')
        LogDev = open(addonlog, 'a')
        # Write to our text file the information we have provided and then goto next line in our file.
        LogDev.write(nowHMS + ' ' + module + ': ' + message + '\n')
    
    
def logbox(message):
    ###cmd  = 'XBMC.Notification(%s, %s, %d, %s)' % ('[Rytec EPG Downloader]', '<'+message+'>', 9999, IMAGE)
    log(message)
    common.logbox(message)
    #addon.setSetting('status',message)
    #if addon.getSetting('notification') == 'Yes':
    #    xbmc.executebuiltin(cmd)
 

def get_sources_list():
    sources_list = []
    """
    http://epgalfasite.dyndns.tv/kodi-epgsources ==>
    http://www.vuplus-community.net/rytec/sources/kodi-epgsources
    
    http://rytecepg.wanwizard.eu/sources/rytec.WW.sources.xml
    http://www.xmltvepg.nl/rytec.NL.sources.xml
    http://www.vuplus-community.net/rytec/rytec.VUplus.sources.xml
    http://rytecepg.ipservers.eu/epg_data/rytec.King.sources.xml
    http://91.121.106.172/~rytecepg/epg_data/rytec.WoS.sources.xml
    """
    try:
        log('get sources list: ' + repr(common.bdecode(epgsources)))
        #r = requests.get(common.bdecode(epgsources), headers=headers)
        r = requests.get(common.bdecode(epgsources))
        #log('r= ' + repr(r))
        #log('r.text.splitlines()= ' + repr(r.text.splitlines()))
        #log('r.content= ' + repr(r.content))
        sources_list = ''
        if r.status_code == 200:
            sources_list = r.text.splitlines()
            log('sources_list0= %r' % sources_list)
            sources_listA = []
            for index in range(0, len(sources_list)): 
                sources_listA.append(sources_list[index].replace('rytec//epg_data','rytec//epg_data1234'))
            ###sources_list = sources_list.replace('epg_data','epg_data1234')  ### server down 2018-08-02
            sources_list = sources_listA
            log('sources_list1= %r' % sources_list)
            random.shuffle(sources_list)
            log('sources_list2= %r' % sources_list)
            ###sources_list = gzip.GzipFile(fileobj=StringIO(r.content)).read().splitlines() ##################################
    except Exception, e:
        log('error in get sources list: ' + repr(e))
    log('sources_list= %r' % sources_list)
    ###nowHMS=datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###addon.setSetting('version',nowHMS)
    ###addon.setSetting('xmltv',repr(sources_list))
    return sources_list

def get_epg_list(sources_list):
    log('get_epg_list(sources_list= %r)' % (sources_list))
    ret = False
    log('get epg list')
    for source in sources_list:
        try:
            log('source= %r' % source)
            r = requests.get(source)
            #log('r= ' + repr(r))
            #log('r.text.splitlines()= ' + repr(r.text.splitlines()))
            #log('r.content= ' + repr(r.content))
            if r.status_code == 200:
                content = r.content
                log('content= ' + repr(content))
                root = ET.fromstring(content)
                desc = []
                for source in root.findall('source'):
                    desc.append(source)
                nowHMS=datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                addon.setSetting('version',nowHMS)
            else:
                log('source offline ' + repr(r.status_code))
        except Exception, e:
            log('error in get epg: ' + repr(e))
    return desc

    
def get_epg(sources_list, description):
    log('get_epg(sources_list= %r \ndescription= %r)' % (sources_list, description))
    ret = False
    epg_url = None
    #log('get epg')
    for source in sources_list:
        try:
            log('source= %r' % source)
            if not 'http://www.xmltvepg.nl/' in source:  #### Ignore NL source - too old
                r = requests.get(source)
                #log('r= ' + repr(r))
                #log('r.text.splitlines()= ' + repr(r.text.splitlines()))
                #log('r.content= ' + repr(r.content))
                if r.status_code == 200:
                    content = r.content
                    ###log('content= ' + repr(content))
                    epg_url = get_epg_url(content, description)
                    log('description= %r\nepg_url= %r' % (description,epg_url))
                    if epg_url:
                        ret = download_epg(epg_url,description)
                        if ret:
                            root = ET.fromstring(content)
                            desc = []
                            for source in root.findall('source'):
                                rootsource= ET.fromstring(source)
                                desc.append(rootsource.findall('description'))
                            nowHMS=datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                            addon.setSetting('version',nowHMS)
                            
                            addon.setSetting('xmltv',repr(desc))
                            log('source.description= %r' % desc)
                            break
                    else:
                        log('no epg url found')
                else:
                    log('source offline ' + repr(r.status_code))
        except Exception, e:
            log('error in get epg: ' + repr(e))
    if ret and epg_url:
        log('save epg url to config')
        try:
            common.save_epg_url(epg_url, description)
        except Exception, e:
            log('could not write url to config' + repr(e))
    return ret

def get_epg_url(content, description):
    epg_url = None
    try:
        #log('get epg url')
        log('get_epg_url(description= %r \ncontent= %r)' % (description, content))
        root = ET.fromstring(content)
        ###nowHMS=datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        ###addon.setSetting('version',nowHMS)
        ###addon.setSetting('xmltv',repr(root))

        for source in root.findall('source'):
            sd = source.find('description').text
            url = source.find('url').text
            log('sd= %r \nurl= %r' % (sd,url))
            if sd == description:
                epg_url = url
                break
    except Exception, e:
        log('error in get epg url: ' + repr(e))
    return epg_url
        
def download_epg(epg_url,description):
    ret = False
    try:
        nowSTHM= datetime.datetime.today().strftime('%H:%M')
        name = epg_url.split('/')[-1]
        logbox('download epg ' + nowSTHM + ' ' + name)
        xml_file = common.get_xml_file(name)
        from contextlib import closing
        with closing(requests.get(epg_url, headers=headers, stream=True)) as r:
            log ('r.status_code= %r, r.headers[content-type]= %r, int(r.headers[content-length]= %r' % (r.status_code, r.headers['content-type'], int(r.headers['content-length'])))
            ###if r.status_code == 200 and (r.headers['content-type'] == 'application/x-gzip' or r.headers['content-type'] == 'application/x-xz')  and int(r.headers['content-length']) > 1024:
            if r.status_code == 200 and  int(r.headers['content-length']) > 1024:
                log('epg download started')
                f = xbmcvfs.File(xml_file, 'wb')
                logfile = xml_file+'.txt'
                fx = xbmcvfs.File(logfile, 'w')
                head = 'description=%r \nepg_url=%r' % (description,epg_url)
                log('logfile= %r, head= %r' % (logfile,head))
                fx.write(head)
                for chunk in r.iter_content(chunk_size=1024): 
                    if chunk:
                        f.write(chunk)
                    else:
                        log('epg download failed')
                        fx.close()
                        break
                        return ret
                log('epg download complete')
                f.close()
                fx.close()
                ret = True
            else:
                log('epg url offline: ' + repr(r.status_code))
    except Exception, e:
        pass
        ret = 'error in download epg: ' + repr(e)
        log('error in download epg: ' + repr(e))
    return ret
