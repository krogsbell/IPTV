#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs,os
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import calendar
import net
import json
import locking,utils
import recordings
import glob
import fnmatch
import definition
import shutil
import xmltodict
import base64
from operator import itemgetter
from urllib.request import urlopen
import io
import findtvguidenotifications
from sqlite3 import dbapi2 as sqlite3

ADDON      = definition.getADDON()
ADDONname  = definition.ADDONgetAddonInfo('name')
ADDONid    = definition.ADDONgetAddonInfo('id')
ADDONrefer = definition.ADDONgetSetting('my_referral_name')
if 'true' == definition.ADDONgetSetting('enigma2'): 
    enigma2 = True
else:
    enigma2 = False
args = sys.argv  ### args[1] == 'once' or 'hourly'
module = 'updateepg.py'
origin = ADDONid +' available_channels'
datapath = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
progpath = definition.ADDONgetAddonInfo('path')
referral = definition.ADDONgetSetting('my_referral_link')
dateStringDummy = '20200625070000 +0100'

notify = definition.ADDONgetSetting('notifyduringepgupdate')
if notify == 'true':
    notifyduringepgupdate = True
else:
    notifyduringepgupdate = False

def notnone(cat):
    if cat == None:
        return ''
    else:
        return cat

def log(infotext,showlength=1024):
    definition.log(infotext,showlength,module)

log('Start Exception')
log('Exception args: '+ repr(args))    

def sleep(sleeptime):
    log('sleep(sleeptime= %r)' % (sleeptime))
    xbmc.sleep(sleeptime)

def notification(infotext):  
    if notifyduringepgupdate:
        utils.notification(repr(infotext)) 

def lowerelement(element,att):
    att = element.attrib.get(att)
    if type(att) == type('a'):
        att = att.lower()
    return att
                 
def SelectXMLTVchannels(wanted,xmlinput,xmloutput):
    try:
        start = datetime.now()
        if len(wanted) == 0 :
            log('Exception SelectXMLTVchannels(wanted= %r)' % (wanted))
            return [0,0,start,0]  
        #add the channels you want to this list
        ###wanted = ['1035.dvb.guide','1026.dvb.guide',]
        
        log('Exception SelectXMLTVchannels(start= %r)' % (start))
        utils.filedata(xmlinput)
        log('Exception SelectXMLTVchannels(wanted= %r,xmlinput= %r,xmloutput= %r)' % (wanted,xmlinput,xmloutput))
        log('Exception SelectXMLTVchannels(filesizes xmlinput= %r,xmloutput= %r)' % (utils.filesize(xmlinput),utils.filesize(xmloutput)))
        utils.filedata(xmlinput)
        utils.filedata(xmloutput)
        from xml.etree.ElementTree import ElementTree
        i = 0   ### count of elements
        j = 0   ### count of accepted elements
        #reads the input xml file
        xml = io.open(xmlinput, 'r', encoding="utf-8")
        data = xml.read()
        log('SelectXMLTVchannels(data= %r)' % (data))
        #get header and footer, then seek the file back to 0 to start parsing xml info
        header = data[:data.find('<tv')-1]
        log('SelectXMLTVchannels(header= %r)' % (header))
        footer = data[data.find('<!--\n'):]
        log('SelectXMLTVchannels(footer= %r)' % (footer))
        del data
        xml.seek(0)

        #parse the data
        tree = ElementTree(file=xml)
        root = tree.getroot()
        orgname = root.get('generator-info-name')
        log('SelectXMLTVchannels:(orgname= %r)' % (orgname))
        utils.notificationforced('[COLOR green]SelectXMLTVchannels(orgname= %r)[/COLOR]' % orgname, time = 20)
        now = datetime.now()
        nowTS = int(datetime.timestamp(now))
        log('SelectXMLTVchannels: nowTS= %r)' % nowTS)
        newname = str(xbmc.getInfoLabel('System.FriendlyName'))+'_'+orgname+'_'+recordings.humantime(nowTS)
        root.set('generator-info-name',newname)
        log('SelectXMLTVchannels(orgname= %r, newname=%r)' % (orgname,newname))
        lroot = list(root)
        ###log('SelectXMLTVchannels(lroot= %r)' % (lroot))
        logtxt = ''
        for element in lroot:
                i += 1
                id      = lowerelement(element,'id')
                channel = lowerelement(element,'channel')
                log('SelectXMLTVchannels(#= %r, id= %r,channel= %r)' % (i,id,channel))
                
                if not (id in wanted or channel in wanted):
                    root.remove(element)
                else:
                    log('Exception SelectXMLTVchannels Accepted (#= %r, id= %r,channel= %r)' % (j,id,channel))
                    now=datetime.today().strftime('%H:%M:%S')
                    log('Exception SelectXMLTVchannels now= %r' % now)
                    ###definition.ADDONsetSetting('EPGimportaccept', '#= %r, id= %r,channel= %r @%r' % (j,id,channel,now))  ### 2026-03-09
                    if id == None:
                        logtxt = '%s #%s @%s' % (channel,j,now)
                        definition.ADDONsetSetting('EPGimportaccept', logtxt)  ### 2026-03-09
                        j +=1
        
        definition.ADDONsetSetting('EPGimportaccept', logtxt + ' Ended' )  ### 2026-03-09
        #write the data
        ###out_xml = open(xmloutput,'w')
        
        log('exception SelectXMLTVchannels write the data to (xmloutput= %r)' % (xmloutput))
        ###out_xml = io.open(xmloutput, 'wb', encoding="utf-8")
        out_xml = io.open(xmloutput, 'wb')   ### 2025-07-23
        log('exception SelectXMLTVchannels write the data OPEN (xmloutput= %r)' % (xmloutput))
        out_xml.write((header+footer+'\n').encode("utf-8"))
        log('exception SelectXMLTVchannels write the data header/footer to (xmloutput= %r)' % (xmloutput))
        ###out_xml.write((footer+'\n').encode("utf-8"))
        ###log('SelectXMLTVchannels write the data footer to (xmloutput= %r)' % (xmloutput))
        tree.write(out_xml)
        utils.filedata(xmloutput)
        """
        xmloutput = str(xbmc.getInfoLabel('System.FriendlyName'))+xmloutput
        log('SelectXMLTVchannels write the data to (xmloutput= %r)' % (xmloutput))
        out_xml = io.open(xmloutput, 'wb')   ### 2025-07-23
        log('SelectXMLTVchannels write the data OPEN (xmloutput= %r)' % (xmloutput))
        out_xml.write((header+footer+'\n').encode("utf-8"))
        log('SelectXMLTVchannels write the data header/footer to (xmloutput= %r)' % (xmloutput))
        tree.write(out_xml)
        log('SelectXMLTVchannels write the data tree to (xmloutput= %r)' % (xmloutput))
        """
        ended = datetime.now()
        return [j,i,start,ended-start]
        ### ? test = 1/0
    except Exception as e:
        pass
        log('SelectXMLTVchannels Exception: %r' % e)

def getFullAndFavoriteEPG():
    try:
        ChannelFile2 = os.path.join(datapath,full) + 'EPG.xml'         
        ChannelFile4 = 'EPGfavorites.xml'
        ROQuser = definition.ADDONgetSetting('user')
        ROQpass = definition.ADDONgetSetting('pass')
        httplinkEPG = definition.getBASEURL() + '/xmltv.php?username=' +ROQuser+ '&password=' +ROQpass +'&next_days=10'     ### 2026-04-19
        data = utils.readlink(httplinkEPG,ChannelFile2,module)
        ### copy EPG to master.xml in Recordingsfolder
        if os.path.exists(ChannelFile2):
            log('getFullAndFavoriteEPG ChannelFile2 exists= %r' % ChannelFile2)
            Recordings = xbmcvfs.translatePath(definition.FileManagerPath('Recordings'))
            destf = os.path.join(Recordings,'fullEPG.xml')
            copyOK = xbmcvfs.copy(ChannelFile2, destf)
            if not copyOK:
                log('getFullAndFavoriteEPG Copy of %r failed - ERR: %r' %  (destf,copyOK))
            wanted = recordings.getFavoriteChannelsEPG()
            utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] Select XMLTV channels Wanted: %r' % wanted)
            ###wanted = ['dr1.dk','493972']
            destf = os.path.join(Recordings,ChannelFile4)
            ###result = updateepg.SelectXMLTVchannels(wanted,ChannelFile2,destf)
            result = SelectXMLTVchannels(wanted,ChannelFile2,destf)
            log('getFullAndFavoriteEPG SelectXMLTVchannels result= %r' % result)
        utils.notificationsend('[COLOR lightgreen][B]' + ADDONname + '[/B][/COLOR] Select XMLTV channels Finished with result %r' % result)
        
    except Exception as e:
        pass
        log('getFullAndFavoriteEPG Select XMLTV channels Exception: ' + repr(e))
        utils.notificationsend('[COLOR red][B]' + ADDONname + '[/B][/COLOR] Select XMLTV channels failed: %r' % e)

def krogsbellAddons():
    ### Krogsbell IPTV addons have the file 'definition.py'
    addons    = []
    addonsAll = []
    try:
        SwFileFolder = os.path.join(xbmcvfs.translatePath('special://masterprofile/'), 'addon_data','krogsbell.switchaddons')
        SwFile = os.path.join(SwFileFolder,'switchaddons.txt')
        if not os.path.exists(SwFileFolder):
            os.mkdir(SwFileFolder)
            open(SwFile, 'a').close()
        log('SwFile= %r' % SwFile)
        switchfile = open(SwFile, 'r')
        addonsO = switchfile.read()
        switchfile.close() 
        
        if not ADDONid in addonsO:
            targetADDON = xbmcaddon.Addon(id=ADDONid)
            newADDONname = targetADDON.getAddonInfo('name')
            log('err newADDONname= %r' % newADDONname)
            ###addonsO += '\n' + ADDONrefer + ':' + ADDONid
            addonsO += '\n' + newADDONname + ':' + ADDONid
        if addonsO != '' :
            addonsO = addonsO.split('\n')
            for addon in addonsO:
                if addon != '':
                    newaddon = addon.split(':')
                    targetADDON = xbmcaddon.Addon(id=newaddon[1])
                    newaddon[0] = targetADDON.getAddonInfo('name')
                    if newaddon[1] != ADDONid:
                        try:
                            testAddon = xbmcaddon.Addon(id=newaddon[1])
                            pathTOaddon = os.path.join(xbmcvfs.translatePath('special://home/addons'), newaddon[1])
                            if os.path.exists(pathTOaddon):
                                addons.append(newaddon)
                                addonsAll.append(newaddon)
                        except Exception as e:
                            log('215 Exception: %r' % e)
                            pass
                    else:
                        addonsAll.append(newaddon)
    except Exception as e:
        log('220 Exception: %r' % e)
        pass
        addons.append(['ERROR',repr(e)])
    ###[['GlowIPTV','plugin.video.glowiptv.rec'],['DR NU','plugin.video.drnu'],['BBC iPlayer','plugin.video.iplayerwww'],['ITV Player','plugin.video.itv']]
    addonsAll = sorted(addonsAll)
    log('err krogsbellAddons addonsAll= %r' % addonsAll)
    addonsO = ''
    for addon in addonsAll:
        addonsO += addon[0] + ':' + addon[1] + '\n'
    definition.ADDONresetSetting('switchaddons',addonsO)
    LF = open(SwFile, 'w')
    LF.write(addonsO)
    LF.close()
            
    addons = sorted(addons)
    choises = []
    for choise in addons:
       choises.append('[B][COLOR lightgreen]'+ choise[0] + ':[/COLOR][/B] ' + choise[1])
    return choises
      
def testPrograms():
    try:  ### Get system timezone
        timezone = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Settings.GetSettingValue", "params": {"setting": "locale.timezone"}, "id": 1}')
        log('errYYY Kodi timezone= %r' % timezone)
    except Exception as e:
            pass
            log('246 Get timezone error= %r' % e)
    try:   ### Test if ffmpeg is installed
        if utils.runCommandTest('ffmpeg'):
            log('249 FFMPEG installed!')
    except Exception as e:
            pass
            log('252 Get ffmpeg error= %r' % e)
    try:   ### Test if rtmpdump is installed
        if utils.runCommandTest('rtmpdump'):
            log('255 RTMPDUMP installed!')
    except Exception as e:
            pass
            log('258 Get rtmpdump error= %r' % e)
    try:   ### Test if 7zip is installed
        if utils.runCommandTest('7z'):
            log('261 7z installed!')
        else:
            log('263 7z NOT installed!')
    except Exception as e:
            pass
            log('266 Get 7z Except %r' % e)
    ### xarchiver -v
    try:   ### Test if xarchiver -v is installed
        if utils.runCommandTest('xarchiver -v'):
            log('errYYY xarchiver -v installed!')
        else:
            log('errYYY xarchiver -v NOT installed!')
    except Exception as e:
            pass
            log('errYYY Get xarchiver -v error= %r' % e)
            
def GetFromDict(link,number=0):           
    try:  ### Get original descriptions from enigma2 link
        log('Read enigma2 link= %r, number= %r'% (link, number))
        """
        ###link = 'http://roq-tv.net:25461/enigma2.php?username=' +definition.ADDONgetSetting('user')+ '&password=' +definition.ADDONgetSetting('pass')
        enigma2 i, (key= u'items', value= OrderedDict([(u'playlist_name', u'My_Bouquet_Name'), (u'category', OrderedDict([(u'category_id', u'1'), (u'category_title', u'My_Bouquet_Name')])), (u'channel', [OrderedDict([(u'title', u'Live Streams'), (u'description', u'Live Streams Category'), (u'category_id', u'0'), (u'playlist_url', u'http://www.e900x.com:8000/enigma2.php?username=xxx&password=yyy&type=get_live_categories')]), OrderedDict([(u'title', u'Vod'), (u'description', u'Video On Demand Category'), (u'category_id', u'1'), (u'playlist_url', u'http://www.e900x.com:8000/enigma2.php?username=xxx&password=yyy&type=get_vod_categories')]), OrderedDict([(u'title', u'TV Series'), (u'description', u'TV Series Category'), (u'category_id', u'2'), (u'playlist_url', u'http://www.e900x.com:8000/enigma2.php?username=xxx&password=yyy&type=get_series_categories')])])])): 
        """
        ### ROQTVusername = definition.ADDONgetSetting('user')
        log('enigma2 GetFromDict(link)0= %r' % link)
        if link != '' :
            
            log('enigma2 GetFromDict(link)1= %r' % link)
            
            ###file = urllib.parse.urlopen(link)
            ###data = file.read()
            ###file.close()
            data = utils.readlink(link,'',module)
            log('enigma2 GetFromDict(link) data0= %r' % data)
            ###data = data.replace('\n','').replace('<description/>','<description></description>')  ### 2023-07-09
            log('enigma2 GetFromDict(link) data1= %r' % data)
            for titem in [b'title',b'description']:
                log('enigma2 GetFromDict(link) titem = %r' % titem )
                data = data.split(b'<'+titem+b'>')
                log('enigma2 GetFromDict(link) data2= %r' % data)
                i=0
                newdata= b''
                for part in data:
                    log('enigma2 GetFromDict(link) part0= %r' % part)
                    if i==0:
                        newdata+=part
                        log('enigma2 GetFromDict(link) newdata= %r' % newdata)
                        i+=1
                    else:
                        log('enigma2 GetFromDict(link) part1= %r' % part)
                        part=part.split(b'</'+titem+b'>',1)
                        log('enigma2 GetFromDict(link) part2= %r' % part)
                        if part[0] != None:
                            ###enigma2 GetFromDict(link) part2= [b'TGl2ZSBTdHJlYW1z', b'<description>TGl2ZSBTdHJlYW1zIENhdGVnb3J5</description><category_id>0</category_id><playlist_url><![CDATA[http://37.120.189.187:8080/enigma2?username=mulehouseote&password=cWSZUcYNY2&type=get_live_categories]]></playlist_url></channel><channel>']*>
                            log('enigma2 GetFromDict(link) part[0] != None %r' % part[0])
                            decodedtext = base64.b64decode(part[0])
                            log('enigma2 GetFromDict(link) decodedtext= %r' % decodedtext)
                            """
                            if titem == b'title':
                                log('enigma2 GetFromDict(link) titem 2= %r' % titem )
                                ###decodedtext = recordings.latin1_to_ascii_force(base64.b64decode(part[0], '-_').replace('&','&amp;')).replace('<<','XX')
                                decodedtext = base64.b64decode(part[0])
                            else:
                                log('enigma2 GetFromDict(link) titem 3= %r' % titem )
                                decodedtext = recordings.latin1_to_ascii_force(base64.b64decode(part[0], '-_').replace('&','&amp;')).replace('<<','XX')
                                decodedtext = base64.b64decode(part[0])
                            """    
                        else:
                            log('enigma2 GetFromDict(link) Missing channel: ' + repr(part))
                            decodedtext=''
                        log('enigma2 GetFromDict(link) decodedtext 1= %r' % decodedtext)
                        try:   
                            log('enigma2 GetFromDict(link) 1')
                            if part[1] != None:
                                log('enigma2 GetFromDict(link) 2')
                                log('enigma2 GetFromDict(link) part[1] != None %r' % part[1])
                                newdata+=b'<'+titem+b'>' + decodedtext +b'</'+titem+b'>' + part[1]
                                log('enigma2 GetFromDict(link) newdata 1= %r' % newdata)
                                log('enigma2 GetFromDict(link) 3')
                            else:
                                log('enigma2 GetFromDict(link) 4')
                                log('enigma2 GetFromDict(link) part[1] == None')
                                newdata+=b'<'+titem+b'>' + decodedtext +b'</'+titem+b'>'
                                log('enigma2 GetFromDict(link) newdata 2= %r' % newdata)
                                log('enigma2 GetFromDict(link) 5')
                            log('enigma2 GetFromDict(link) 6')
                        except Exception as e:
                            pass
                            log('enigma2 GetFromDict(link) 7')
                            log('enigma2 GetFromDict(link) part[1] != None ERROR: %r' % e)
                            log('enigma2 GetFromDict(link) newdata 4= %r' % newdata)
                            newdata+=b'<'+titem+b'>' + decodedtext +b'</'+titem+b'>'
                            log('enigma2 GetFromDict(link) newdata 5= %r' % newdata)
                        log('enigma2 GetFromDict(link) 8')
                    log('enigma2 GetFromDict(link) 9')
                    log('enigma2 GetFromDict(link) newdata 6= %r' % newdata)
                log('enigma2 GetFromDict(link) 10')        
                log('enigma2 GetFromDict(link) newdata 7= %r' % newdata)
                data = newdata
                log('enigma2 GetFromDict(link) newdata 8= %r' % newdata)
            
            channelsxml = os.path.join(datapath, 'channelsxml')+ str(number)  + '.xml'
            log('enigma2 GetFromDict(link) channelsxml= %r' % channelsxml)
            LF = open(channelsxml, 'wb')
            LF.write(newdata)
            LF.close()
            log('enigma2 GetFromDict(link) newdata xml= %r' % newdata)
            log('enigma2 GetFromDict(link) newdata xml type= %r' % type(newdata))
            if type(newdata) != dict:
                log('enigma2 GetFromDict(link) newdata not type dict')
                data = xmltodict.parse(newdata)   ### 2023-07-11
            log('enigma2 GetFromDict(link) xmltodict.parse(newdata) dict data= %r' % data)
            """
            try:
                ###newdata = newdata.replace('*#*>','*#*').replace('<*#*','*#*')  ### SPORT BEIN ARABIA fix
                data = xmltodict.parse(newdata)
            except Exception as e:
                pass
                log('Error in enigma2 xmltodict.parse(newdata)1: #%r\n%r'% (number,e))
                data = b''
            """
            channelsdict = os.path.join(datapath, 'channelsdict')  + str(number)+ '.dict'
            log('enigma2 GetFromDict(link) channelsdict= %r' % channelsdict)
            LF = open(channelsdict, 'w', encoding="utf-8")  
            
            try:
                LF.write(repr(data))  
            except Exception as e:
                pass
                error = '\n\nError in enigma2 LF.write(repr(data)): #%r\n%r'% (number,e)
                LF.write('File name: ' + channelsdict + error) 
                log(error)
            LF.close()
            log('enigma2 GetFromDict(link) channelsdict 1= %r' % channelsdict)
    except Exception as e:
        pass
        log('Error in enigma2 xmltodict.parse(newdata)2: #%r\n%r'% (number,e))
        data = ''    
    log('GetOriginalDescriptionsFromDict() enigma2 channelsdict.dict transformed 305: %r' % data)
    return data

def scandata(data1,number,label):
    log('enigma2 scandata(number= %r\nlabel= %r\ndata1= %r)' % (number,label,data1))
    label += '@'
    log('enigma2 scandata(number= %r\nlabel= %r)' % (number,label))
    ###for j, (key2, value2) in enumerate(data1.iteritems()):
    if type(data1) == dict:
        for (key2, value2) in data1.items():
            log('enigma2 scandata (key2= %r, number= %r, label= %r, value2= %r)' % (key2, number, label, value2))
            for (key3, value3) in value2.items():
                log('enigma2 scandata key3?channel %r, type(value3)= %r, value3= %r' % (key3,type(value3),value3))
                """
                type(value3)= <class 'collections.OrderedDict'>
                
                if repr(type(value3)) == "<class 'collections.OrderedDict'>":
                    log('key3?channel-type-list %r, type(value3)= %r' % (key3,type(value3)))
                    scandata(value3,number,label+'#')
                """
                if key3 == 'channel':
                    if type(value3) == dict:
                        log('enigma2 scandata key3?channel-type-list %r, type(value3)= %r' % (key3,type(value3)))
                        scandata(value3,number,label+'#')
                    else:
                        for d3 in value3:
                            log('enigma2 scandata 0 value3= %r' % value3)
                            log('enigma2 scandata type(d3)= %r' % type(d3))
                            log('enigma2 scandata d3= %r' % d3)
                            if type(d3) == dict:
                                log('enigma2 scandata key3?d3 %r, type(d3)= %r' % (key3,type(d3)))
                                scandata(d3,number,label+'!')
                            else:
                                if 'playlist_name' in d3 :
                                    log('enigma2 scandata playlist_name')
                                    try:
                                        playlist_name3 = d3['playlist_name']
                                        log('enigma2 scandata d3-3-0, (key3= %r, value3= %r, number= %r)' % (key3, playlist_name3, number))
                                        label += playlist_name3 + '¤'
                                        log('enigma2 scandata d3-3-0, (key3= %r, value3= %r, label= %r)' % (key3, playlist_name3, label))
                                    except Exception as e:
                                        pass
                                        log('enigma2 scandata playlist_name ERROR: %r' % e)
                                    log('enigma2 scandata 1 value3= %r' % value3)
                                elif 'playlist_url' in d3 : ### and not d3['playlist_url'] == None:
                                    log('enigma2 scandata playlist_url')
                                    try:
                                        log('enigma2 scandata d3-playlist_url= %r' % d3)
                                        playlist_url3 = d3['playlist_url']
                                        log('enigma2 scandata d3-3, (key3= %r, value3= %r, number= %r)' % (key3, playlist_url3, number))
                                        data2 = GetFromDict(playlist_url3,number=number)
                                        log('enigma2 scandata d3-2, (data2= %r, number= %r)' % (data2, number))
                                        number += 1
                                        log('enigma2 before scandata(data2,number= %r)' % number)
                                        scandata(data2,number,label)
                                        log('enigma2 after scandata(data2,number= %r)' % number)
                                    except Exception as e:
                                        pass
                                        log('enigma2 scandata playlist_url ERROR: %r' % e)
                                    log('enigma2 scandata 2 value3= %r' % value3)
                                elif 'stream_url' in d3 : ###and not d3['stream_url'] == None:
                                    log('enigma2 scandata d3-stream_url= %r' % d3)
                                    log('enigma2 scandata stream_url')
                                    try:
                                        StreamURL=d3['stream_url'].replace('![CDATA[','',1).replace(']]','',1)
                                        log('enigma2 scandata d3-1, (StreamURL= %r)' % (StreamURL))
                                        if not d3['desc_image'] == None:
                                            DescURL=d3['desc_image'].replace('![CDATA[','',1).replace(']]','',1)
                                        else:
                                            DescURL = ''
                                        try:
                                            Description=d3['description']
                                            if isinstance(Description, dict):
                                                try:
                                                    Description = Description['em']+'\n'+Description['#text']
                                                except Exception as e:
                                                    ###pass
                                                    Description = repr(Description) + repr(e)  ### 2019-03-31
                                            elif not isinstance(Description, unicode):
                                                if not (Description == None or Description == ''):
                                                    Description='Unknown description type: ' + repr(type(Description))
                                                else: 
                                                    Description = repr(Description)
                                        except Exception as e:
                                            pass
                                            log('enigma2 scandata Error in get enigma2 Description: ' + repr(e))
                                            EPGimportERRORS('266 Error in get enigma2 Description: ' + repr(e))
                                            Description= 'Error in get enigma2 Description: ' + repr(e)
                                    except Exception as e:
                                        pass    
                                        log('enigma2 scandata Error in get enigma2 stream_url: ' + repr(e))
                                    log('enigma2 scandata 1 label= %r, d3title= %r' % (label,d3['title']))
                                    log('enigma2 scandata Test enigma2 Title= %r, Stream= %r, DescURL= %r, Category_ID= %r, Description= %r' % (label+d3['title'],StreamURL,DescURL,d3['category_id'],Description))
                                    catThis = recordings.catFromUrl(StreamURL)
                                    log('enigma2 scandata recordings.catFromUrl= %r from\nStreamURL= %r' %(catThis,StreamURL))
                                    try:
                                        if definition.ADDONgetSetting('user') in catThis :
                                            catThis = '#'
                                    except Exception as e:
                                        pass
                                        log('enigma2 scandata definition.ADDONgetSetting(user) in catThis= %r ERROR: %r' % (catThis,e))
                                    log('enigma2 scandata catThis= %r' % catThis)
                                    if recordings.isChannelVisible(catThis) or catThis == '#' or 1==1:  ### 2020-04-06
                                        log('enigma2 scandata Visible catThis= %r' % catThis)
                                        try:
                                            if catThis != '#' : 
                                                if definition.ADDONgetSetting('titlewithcategory') == 'true' :
                                                    category_name = d3['category_name']
                                                    if category_name != '':
                                                        category_name = ' [' + category_name + ']' 
                                                else:
                                                    category_name = ''
                                                log('error 417 category_name= %r' % category_name)
                                                name = label+d3['title'] + category_name  ### 2023-03-19
                                                name = ' '.join(name.split())  ## Remove doublespaces etc
                                                log('enigma2 scandata addChannel(d3[title]= %r, StreamURL= %r, DescURL= %r, catThis= %r, origin= %r,description= %r)' % 
                                                (name, StreamURL, DescURL, catThis, origin, Description))
                                                log('enigma2 scandata 0 label= %r, d3title= %r' % (label,d3['title']))             
                                                recordings.addChannel(name,StreamURL,DescURL,catThis,origin,description=Description)
                                                log('enigma2 scandata after recordings.addChannel')
                                        except Exception as e:
                                            pass
                                            log('enigma2 scandata series/  Error in get enigma2: ' + repr(e))
                                            EPGimportERRORS('296 Error in get enigma2: ' + repr(e))
                                            log('enigma2 scandata 297')
                                else:
                                    log('enigma2 scandata ERROR:  Not playlist_name, playlist_url or stream_url: %r' % d3)
                
def GetOriginalDescriptionsFromDict(calledfrom): 
    log('GetOriginalDescriptionsFromDict() enigma2 called from %r' % calledfrom)
    """
    ###link = 'http://roq-tv.net:25461/enigma2.php?username=' +definition.ADDONgetSetting('user')+ '&password=' +definition.ADDONgetSetting('pass')
    enigma2 i, (key= u'items', value= OrderedDict([(u'playlist_name', u'My_Bouquet_Name'), (u'category', OrderedDict([(u'category_id', u'1'), (u'category_title', u'My_Bouquet_Name')])), (u'channel', [OrderedDict([(u'title', u'Live Streams'), (u'description', u'Live Streams Category'), (u'category_id', u'0'), (u'playlist_url', u'http://www.e900x.com:8000/enigma2.php?username=xxx&password=yyy&type=get_live_categories')]), OrderedDict([(u'title', u'Vod'), (u'description', u'Video On Demand Category'), (u'category_id', u'1'), (u'playlist_url', u'http://www.e900x.com:8000/enigma2.php?username=xxx&password=yyy&type=get_vod_categories')]), OrderedDict([(u'title', u'TV Series'), (u'description', u'TV Series Category'), (u'category_id', u'2'), (u'playlist_url', u'http://www.e900x.com:8000/enigma2.php?username=xxx&password=yyy&type=get_series_categories')])])]))

    OrderedDict([(u'items', OrderedDict([(u'playlist_name', u'SubCategory [ My_Bouquet_Name ]'), (u'category', OrderedDict([(u'category_id', u'1'), (u'category_title', u'SubCategory [ My_Bouquet_Name ]')])), (u'channel', [OrderedDict([(u'title', u'All'), (u'description', u'TV Series Category [ ALL ]'), (u'category_id', u'0'), (u'playlist_url', u'http://www.e900x.com:8000/enigma2.php?username=xxx&password=yyy&type=get_series&cat_id=0')]), OrderedDict([(u'title', u'English Series'), (u'description', u'TV Series Category'), (u'category_id', u'45'), (u'playlist_url', u'http://www.e900x.com:8000/enigma2.php?username=xxx&password=yyy&type=get_series&cat_id=45')])])]))])
    """          
    try:  ### Get original descriptions from enigma2 link
    ###if 1 ==1:
        log('GetOriginalDescriptionsFromDict() enigma2 Read link')
        number=0
        ###link = 'http://roq-tv.net:25461/enigma2.php?username=' +definition.ADDONgetSetting('user')+ '&password=' +definition.ADDONgetSetting('pass')
        ROQTVusername = definition.ADDONgetSetting('user')
        if ROQTVusername.lower() != 'none' and enigma2 :
            link = definition.getBASEURL() + '/enigma2.php?username=' +definition.ADDONgetSetting('user')+ '&password=' +definition.ADDONgetSetting('pass')
            log('GetOriginalDescriptionsFromDict() enigma2 link= %r' % link)
            data = GetFromDict(link,number=number)
            number += 1
            
            channelsdict = os.path.join(datapath, 'channelsdict')  + '.dict'
            log('GetOriginalDescriptionsFromDict() enigma2 channelsdict= %r' % channelsdict)
            LF = open(channelsdict, 'w', encoding="utf-8")  
            
            try:
                LF.write(repr(data))  
            except Exception as e:
                pass
                error = '\n\nError in enigma2 LF.write(repr(data)): #%r\n%r'% (number,e)
                LF.write('File name: ' + channelsdict + error) 
                log(error)
            ###LF = open(channelsdict, 'w')
            ###LF.write(repr(data))
            LF.close()
        
            log('GetOriginalDescriptionsFromDict() enigma2 channelsdict.dict transformed 464: %r' % data)
            ###for i, (key, value) in enumerate(data.iteritems()):
            """
            OrderedDict([('items', OrderedDict([('playlist_name', 'z'), ('category', OrderedDict([('category_id', '1'), ('category_title', 'z')])), ('channel', [OrderedDict([('title', 'Live Streams'), ('description', 'Live Streams Category'), ('category_id', '0'), ('playlist_url', 'http://37.120.189.187:8080/enigma2?username=mulehouseote&password=cWSZUcYNY2&type=get_live_categories')]), OrderedDict([('title', 'VOD'), ('description', 'Video On Demand Category'), ('category_id', '1'), ('playlist_url', 'http://37.120.189.187:8080/enigma2?username=mulehouseote&password=cWSZUcYNY2&type=get_vod_categories')]), OrderedDict([('title', 'TV Series'), ('description', 'TV Series Category'), ('category_id', '2'), ('playlist_url', 'http://37.120.189.187:8080/enigma2?username=mulehouseote&password=cWSZUcYNY2&type=get_series_categories')])])]))])
            """
            log('GetOriginalDescriptionsFromDict() enigma2 channelsdict data[items][playlist_name]= %r' % data['items'])
            log('GetOriginalDescriptionsFromDict() enigma2 channelsdict data[items][playlist_name]= %r' % data['items']['playlist_name'])
            ###i = 0
            for key, value in data.items():   ### 2023-07-11
                log('GetOriginalDescriptionsFromDict() enigma2 (key= %r, value= %r): ' % (key, value))
                log('GetOriginalDescriptionsFromDict() enigma2 value.items()= %r: ' % value.items())
                for (key1, value1) in value.items():
                    log('GetOriginalDescriptionsFromDict() enigma2 (key1= %r, value1= %r): ' % (key1, value1))
                    if key1 == 'channel':
                        for d in value1:
                            log('GetOriginalDescriptionsFromDict() enigma2 d in value1= %r' % d)
                            ### dict: d in value1= OrderedDict([(u'title', u'TV Series'), (u'description', u'TV Series Category'), (u'category_id', u'2'), (u'playlist_url', u'http://portal.stiptv.com:8080/enigma2.php?username=sfg7jILXn6&password=PItYZEeXir&type=get_series_categories')])
                            if 'playlist_url' in d and not d['playlist_url'] == None:
                                playlist_url=d['playlist_url']
                                log('GetOriginalDescriptionsFromDict() enigma2 playlist_url= %r' % playlist_url)
                                data4 = GetFromDict(playlist_url,number=number)
                                log('GetOriginalDescriptionsFromDict() enigma2 GetFromDict(number= %r, playlist_url= %r)' % (number,playlist_url))
                                number += 1
                                if type(data4) == dict:
                                    for (key4, value4) in data4.items():
                                        log('GetOriginalDescriptionsFromDict() enigma2 enigma2 (key4= %r, value4= %r): ' % (key4, value4))
                                        for (key5, value5) in value4.items():
                                            log('GetOriginalDescriptionsFromDict() enigma2 (key5= %r, value5= %r): ' % (key5, value5))
                                            log('GetOriginalDescriptionsFromDict() enigma2 key5?channel %r, value5= %r' % (key5,value5))
                                            if key5 == 'channel':
                                                log('GetOriginalDescriptionsFromDict() enigma2 key5==channel %r'% key5)
                                                for d5 in value5:
                                                    log('GetOriginalDescriptionsFromDict() enigma2 d5= %r'% d5)
                                                    if d5['title'] == 'All':
                                                        playlist_url5=d5['playlist_url']
                                                        log('GetOriginalDescriptionsFromDict() enigma2 d5, (key5= %r, value5= %r, number= %r)' % (key5, playlist_url5, number))
                                                        data1 = GetFromDict(playlist_url5,number=number)
                                                        number += 1
                                                        log('enigma2 before scandata(data1,number= %r)' % number)
                                                        scandata(data1,number,'')
                                                        log('enigma2 after scandata(data1,number= %r)' % number)
                                                        """
                                                        for j, (key2, value2) in enumerate(data1.iteritems()):
                                                            log('enigma2 j= %r, (key2= %r, value2= %r)' % (j, key2, value2))
                                                            for j1, (key3, value3) in enumerate(value2.iteritems()):
                                                                ###log('enigma2 j1, (key3= %r, value3= %r)' % (key3, value3))
                                                                log('key3?channel %r, value3= %r' % (key3,value3))
                                                                if key3 == 'channel':
                                                                    for d3 in value3:
                                                                        if 'playlist_url' in d3 and not d3['playlist_url'] == None:
                                                                            log('d3-playlist_url= %r' % d3)
                                                                            playlist_url3 = d3['playlist_url']
                                                                            log('enigma2 d3, (key3= %r, value3= %r, number= %r)' % (key3, playlist_url3, number))
                                                                            data2 = GetFromDict(playlist_url3,number=number)
                                                                            number += 1
                                                                        elif 'stream_url' in d3 and not d3['stream_url'] == None:
                                                                            StreamURL=d3['stream_url'].replace('![CDATA[','',1).replace(']]','',1)
                                                                            log('enigma2 d3, (StreamURL= %r)' % (StreamURL))
                                                                            if not d3['desc_image'] == None:
                                                                                DescURL=d3['desc_image'].replace('![CDATA[','',1).replace(']]','',1)
                                                                            else:
                                                                                DescURL = ''
                                                                            try:
                                                                                Description=d3['description']
                                                                                if isinstance(Description, dict):
                                                                                    try:
                                                                                        Description = Description['em']+'\n'+Description['#text']
                                                                                    except Exception as e:
                                                                                        pass
                                                                                        Description = repr(Description) + repr(e)  ### 2019-03-31
                                                                                elif not isinstance(Description, unicode):
                                                                                    if not (Description == None or Description == ''):
                                                                                        Description='Unknown description type: ' + repr(type(Description))
                                                                                    else: 
                                                                                        Description = repr(Description)
                                                                                
                                                                            except Exception as e:
                                                                                pass
                                                                                log('Error in get enigma2 Description: ' + repr(e))
                                                                                EPGimportERRORS('Error in get enigma2 Description: ' + repr(e))
                                                                                Description= 'Error in get enigma2 Description: ' + repr(e)
                                                                                
                                                                            log('Test enigma2 Title= %s, Stream= %s, DescURL= %s, Category_ID= %s, Description= %s' % (d3['title'],StreamURL,DescURL,d3['category_id'],Description))
                                                                            catThis = recordings.catFromUrl(StreamURL)
                                                                            if definition.ADDONgetSetting('user') in catThis :
                                                                                catThis = '#'
                                                                            log('catThis= %r' % catThis)
                                                                            if recordings.isChannelVisible(catThis) or catThis == '#':
                                                                                log('Visible catThis= %r' % catThis)
                                                                                
                                                                                try:
                                                                                    
                                                                                    if catThis != '#' :
                                                                                        recordings.setChannelDescription(catThis,Description)   ### 2019-02-11 Save descriptions in onlinE DATABASE
                                                                                except Exception as e:
                                                                                    pass
                                                                                    log('Error in get enigma2: ' + repr(e))
                                                                                    EPGimportERRORS('Error in get enigma2: ' + repr(e))
                                                        """    
    
    except Exception as e:
        pass
        log('Error in getting enigma2 Channels: ' + repr(e))
        EPGimportERRORS('555 Error in getting enigma2 Channels: ' + repr(e))
       
    log('GetOriginalDescriptionsFromDict() enigma2  Ended')       

def updateseriesOLD():
    try:
        conn = recordings.getConnection()
        recordings.createTable(conn)
        c = conn.cursor()
        
        ftvntvini = os.path.join(datapath,'TVSeries_'+ADDONrefer) + '.txt'
        LF = open(ftvntvini, 'w')
        LF.write('TV Series '+ADDONrefer + '\n\n')
        
        seriesmark = '%series%'
        c.execute("SELECT * FROM channels WHERE source=? and (stream_url like ? or weight > 0) COLLATE NOCASE",[origin,seriesmark]) ### 2021-01-15
        favorites = c.fetchall()
        favorites = sorted(favorites, key=itemgetter(1), reverse=False) ### Sort by Title
        j = 0
        seriesz = []   ### names of series
        serieszize = []   ### number of episodes for series
        for index in range(0, len(favorites)):
            created = favorites[index][12]
            seriexx = favorites[index][1].lower().split('series')
            if len(seriexx) == 2:
                seriex = seriexx[0]
            elif len(seriexx) == 3:
                seriex = seriexx[0] + 'series' + seriexx[1]
            elif len(seriexx) == 4:
                seriex = seriexx[0] + 'series' + seriexx[1]+ 'series' + seriexx[2]
            else:
                seriex = favorites[index][1].lower().split(' s0')
            seriey = favorites[index][1][:len(seriex)].strip()
            if not seriey in seriesz:
                seriesz.append(seriey)
                seriestitle = seriey + ' s%'
                c.execute("SELECT id FROM channels WHERE source=? and title like ? and (stream_url like ? or weight >0 ) COLLATE NOCASE",[origin,seriestitle,seriesmark])
                episodes = c.fetchall()
                serieszize.append(len(episodes))
                created = str(datetime.fromtimestamp(created).strftime('%Y-%m-%d'))
                chname = seriey + ' (' + str(len(episodes)) + ')'
                j += 1
                LF.write(format(j, '04d') + ' ' + chname + ' Created: '+ created + '\n')
                log('errYYY addTVSeries(c= %r, seriey= %r, len(episodes)= %r)' % (c, seriey, len(episodes)))
                recordings.addTVSeries(c, seriey, len(episodes))
        c.close()  
        LF.close()
    except Exception as e:
        pass
        log('errYYY Update TV Series ERROR: %r' % e)
        try:
            c.close()  
        except :
            pass 
        try:
            LF.close()
        except :
            pass 

def updateseries():   ### TV Series based on weight = S * 1000 + E
    try:
        conn = recordings.getConnection()
        recordings.createTable(conn)
        c = conn.cursor()
        
        ftvntvini = os.path.join(datapath,'TVSeries_'+ADDONrefer) + '.txt'
        LF = open(ftvntvini, 'w')
        LF.write('TV Series '+ADDONrefer + '\n\n')
        
        ###seriesmark = '%series%'
        c.execute("SELECT * FROM channels WHERE source=? and weight > 0 COLLATE NOCASE",[origin]) ### 2021-01-16
        favorites = c.fetchall()
        favorites = sorted(favorites, key=itemgetter(1), reverse=False) ### Sort by Title
        j = 0
        seriesz = []   ### names of series
        serieszize = []   ### number of episodes for series
        for index in range(0, len(favorites)):
            created = favorites[index][12]
            if 'series' in favorites[index][1].lower() and 1 == 0:   ### 2021-01-18 Only use TV Series based on weight = S * 1000 + E
                seriexx = favorites[index][1].lower().split('series')
                if len(seriexx) == 2:
                    seriex = seriexx[0]
                elif len(seriexx) == 3:
                    seriex = seriexx[0] + 'series' + seriexx[1]
                elif len(seriexx) == 4:
                    seriex = seriexx[0] + 'series' + seriexx[1]+ 'series' + seriexx[2]
                else:
                    seriex = favorites[index][1].lower().split(' s0')
                seriey = favorites[index][1][:len(seriex)].strip()
            else:
                seriey = utils.SeriesEpisodeVOD(favorites[index][1])[1]
                
            log('errYYY seriey= %r' % seriey)
            if not seriey in seriesz:
                seriesz.append(seriey)
                seriestitle = '%' + seriey + '%'
                c.execute("SELECT id FROM channels WHERE source=? and title like ? and weight >0 COLLATE NOCASE",[origin,seriestitle])
                episodes = c.fetchall()
                serieszize.append(len(episodes))
                created = str(datetime.fromtimestamp(created).strftime('%Y-%m-%d'))
                chname = seriey + ' (' + str(len(episodes)) + ')'
                j += 1
                LF.write(format(j, '04d') + ' ' + chname + ' Created: '+ created + '\n')
                log('errYYY addTVSeries(c= %r, seriey= %r, len(episodes)= %r)' % (c, seriey, len(episodes)))
                recordings.addTVSeries(c, seriey, len(episodes))
        c.close()  
        LF.close()
    except Exception as e:
        pass
        log('errYYY Update TV Series ERROR: %r' % e)
        try:
            c.close()  
        except :
            pass 
        try:
            LF.close()
        except :
            pass 

def updateiconsfromEPG():
    try:
        log('errYYY err #534 updateiconsfromEPG START')
        conn = recordings.getConnection()
        recordings.createTable(conn)
        c = conn.cursor()
        c.execute("SELECT * FROM channels WHERE source=? COLLATE NOCASE",[origin]) 
        favorites = c.fetchall()
        favorites = sorted(favorites, key=itemgetter(1), reverse=False) ### Sort by Title
        log('errYYY err #534 updateiconsfromEPG number of channels= %r' % len(favorites))
        for index in range(0, len(favorites)):
            log('errYYY err #543 updateiconsfromEPG index= %r' % index)
            cat  = favorites[index][0]
            Icon = favorites[index][2]
            EPG  = favorites[index][9]
            if Icon == '' and EPG != '' :   ### No Icon, but EPG
                log('errYYY err #542 updateiconsfromEPG cat= %r, EPG= %r, IconURL= %r' % (cat,Icon,EPG))
                Icon = recordings.getIconfromEPG(EPG)
                log('errYYY err #547 updateiconsfromEPG cat= %r, EPG= %r, IconURL= %r' % (cat,Icon,EPG))
                recordings.setChannelIcon(c,cat,Icon)
        c.close()  
    except Exception as e:
        pass
        log('errYYY updateiconsfromEPG ERROR: %r' % e)
        try:
            c.close()  
        except :
            pass 
            
tz = definition.ADDONgetSetting('AdjustTVguideTimeZoneOffset')
if tz == '':
    TimeZone = 0
else:
    TimeZone = int(tz)  
tzx = definition.ADDONgetSetting('AdjustTVguideTimeZoneOffsetExtraXML')

if tzx == '':
    tzx = definition.ADDONgetSetting('AdjustTVguideTimeZoneOffsetExtraXML')  ### read an extra time 2022-04-06
    if tzx == '':
        TimeZoneXML = 0
    else:
        TimeZoneXML = int(tzx) 
else:
    TimeZoneXML = int(tzx)  
log('error master.xml \n  TimeZone= %r, tz= %r, \n  TimeZoneXML= %r, tzx= %r' % (TimeZone,tz,TimeZoneXML,tzx))   
datapanel = []
dataepg = []
data= []
EPGgenerator = ''
ChannelFile = ''
channels = 0
programs = 0

def EPGimportERRORS(ERROR):
    log('errYYY 1 EPGimportERRORS= %r' % ERROR)
    NoERROR = '[B][COLOR lightgreen]No Errors[/COLOR][/B]'
    ERRORS  = '[B][COLOR red]Error(s)[/COLOR][/B]'
    if ERROR == '':
        ERROR = NoERROR
        log('errYYY 2 EPGimportERRORS= %r' % ERROR)
    else:
        ERROR = repr(ERROR)
        ERROR = (ERROR + ', ' + definition.ADDONgetSetting('lastEPGimportERRORS')).replace(NoERROR,ERRORS)
        log('errYYY 3 EPGimportERRORS= %r' % ERROR)
        ERROR = ERROR[0:1000]
    definition.ADDONresetSetting('lastEPGimportERRORS',ERROR)
    log('errYYY 4 EPGimportERRORS= %r' % ERROR)

def parse_date(dateString):
    if dateString != '':
        return datetime.fromtimestamp(time.mktime(time.strptime(dateString, "%Y-%m-%d %H:%M:%S")))
    else:
        log('ERROR parse_date(dateString= %r)' % dateString)
        return None
    
def parse_date_string(dateString):
    try:
        ###ValueError: time data '20170625070000 +0100' does not match format '%Y%m%d%H%M%S z'
        ###return time.mktime(time.strptime(dateString, '%Y%m%d%H%M%S Z'))  ### UTC time
        ###logdev('resulttime0',repr(dateString))
        dt = dateString.split(' ')
        if int(dt[0]) < 0:
            dateStringOLD = dateString
            log('resulttime0'+repr(dateString))
            log('parse_date_string0 dt[0]= %r' % dt[0])
            dateString = dateStringDummy
            dt = dateString.split(' ')
            resulttime = time.mktime(time.strptime(dt[0], '%Y%m%d%H%M%S'))
            log('parse_date_string1a dt= %r' % dt)
            EPGimportERRORS('ERROR in date HTML: %r using dummy time: %r' % (dateStringOLD,dateString))
            log('623')
        resulttime = time.mktime(time.strptime(dt[0], '%Y%m%d%H%M%S'))
        ###logdev('resulttime1',repr(resulttime))
        resulttime =  int(resulttime) - (int(dt[1])/100 - TimeZone)*3600
        ###logdev('resulttime2',repr(resulttime))
        ###logdev('resulttime3',repr(datetime.fromtimestamp(resulttime)))
        return str(resulttime)
    except Exception as e:
        pass
        return 'parse_date_string(%r)\n ERROR: %r' % (dateString,e)
    
def parse_date_stringXML(dateString):
    dt = dateString.split(' ')
    if int(dt[0]) < 0:
        dateStringOLD = dateString
        log('resulttime0'+repr(dateString))
        log('parse_date_string0 dt[0]= %r' % dt[0])
        dateString = dateStringDummy
        dt = dateString.split(' ')
        resulttime = time.mktime(time.strptime(dt[0], '%Y%m%d%H%M%S'))
        log('parse_date_string1a dt= %r' % dt)
        EPGimportERRORS('ERROR in date XML: %r using dummy time: %r' % (dateStringOLD,dateString))
        log('644')
    resulttime = time.mktime(time.strptime(dt[0], '%Y%m%d%H%M%S'))
    resulttime =  int(resulttime) - (int(dt[1])/100 - TimeZoneXML)*3600
    return str(resulttime)

def getDict(dictA,name,ntype='',dtype=''):
    ###if definition.ADDONgetSetting('KeyErrorStop') != '':
    ### return ''
    element = ''
    en = "KeyError('" + name + "',)"
    ex = "KeyError('" + ntype + "',)"
    ey = "KeyError('" + dtype + "',)"
    if name == 'sub_title':
        return repr(dictA) + ' \n' + en  ### Debug option
    try:
        if dtype != '' and ntype != '':
            elementd = dictA[name][dtype]
            element = dictA[name][ntype]
            ###if type(element) in (list, tuple, dict):
            ### for elem in element:
            ###     return elem
            ###else:
            ###return repr(element)
            return element
    except Exception as e:
        pass
        err = repr(e)
        if err==en:
            return ''
        if err==ey:
            return 'ey1'
        if err==ex:
            return 'ex1'
    try:
        if ntype != '':
            element = dictA[name][ntype]
            ###if type(element) in (list, tuple, dict):
            ### for elem in element:
            ###     return elem
            ###else:
            ###return repr(element)
            return element
    except Exception as e:
        pass
        err = repr(e)
        if err==en:
            return ''
        if err==ex:
            return 'ex2'
    try:
        element = dictA[name]
        ###if type(element) in (list, tuple, dict):
        ### for elem in element:
        ###     return elem
        ###else:
        ###return repr(element)
        return element
    except Exception as e:
        pass
        err = repr(e)
        if err==en:
            return 'en3'
    return ''

def getEPGChannel(cat):
    try:
        log('getEPGChannel(cat)')
        conn = recordings.getConnection()
        c = conn.cursor()
        c.execute("SELECT DISTINCT title, epg_channel, source FROM channels WHERE id=?", [cat])
        favorites = c.fetchall()
        if len(favorites) > 0:
            result = [favorites[0][0],favorites[0][1],favorites[0][2]]  ### Title, EPG Channel
        else:
            result = ''
        c.close() 
        return result
    except Exception as e:
        pass
        notification('Error in getEPGChannel(cat) '+ cat + ' \n' + repr(e))
    
def setEPGChannel(cat,channel):
    try:
        log('setEPGChannel(cat)')
        conn = recordings.getConnection()
        c = conn.cursor()
        c.execute("SELECT * FROM channels WHERE id=?", [cat])
        favorites = c.fetchall()
        result = []

        for index in range(0, len(favorites)):
            ch = []
            for i in range(0, len(favorites[index])):
                if favorites[index][i] == None:
                    ch.append('')
                else:
                    ch.append(favorites[index][i])
            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [ch[0], ch[1], ch[2], ch[3], ch[4], ch[5], ch[6], ch[7], ch[8], channel,ch[10],ch[11],ch[12]])
        if result == []:
            log('EPG not found for cat= %r' % cat)
        conn.commit()
        
        c.execute("SELECT * FROM channelsRecursive WHERE id=?", [cat])
        favorites = c.fetchall()
        result = []

        for index in range(0, len(favorites)):
            ch = []
            for i in range(0, len(favorites[index])):
                if favorites[index][i] == None:
                    ch.append('')
                else:
                    ch.append(favorites[index][i])
            c.execute("INSERT OR REPLACE INTO channelsRecursive(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [ch[0], ch[1], ch[2], ch[3], ch[4], ch[5], ch[6], ch[7], ch[8], channel,ch[10],ch[11],ch[12]])
        if result == []:
            log('EPG not found for cat= %r' % cat)
        conn.commit()
        
        c.close() 
    except Exception as e:
        pass
        notification('Error in setEPGChannel(cat) '+ cat + ' \n' + repr(e))
    log('setEPGChannel(cat= %r)-->Channel/Epgid= %r' % (cat,channel))

def getEPGnow(cat):
    ###now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###now= datetime.today()
    log('error getEPGnow(cat= %r)' % cat)
    conn = recordings.getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE id=?", [cat])
    favorites = c.fetchall()
    log('error getEPGnow(favorites= %r)' % favorites)
    result = []
    for index in range(0, len(favorites)):
        log('error getEPGnow(index= %r)' % index)
        if result == []:
            ch = []
            for i in range(0, len(favorites[index])):
                if favorites[index][i] == None:
                    ch.append('')
                else:
                    ch.append(favorites[index][i])
                log('error getEPGnow(ch= %r)' % ch)
            ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
            name = ch[1]
            tv_archive = ch[8]  ### Holds duration in days - 0 means no archive
            log('error getEPGnow(name= %r)' % name)
            log('error getEPGnow(tv_archive= %r)' % tv_archive)
            try:
                if type(tv_archive) != int:
                    tv_archive = 0
                default_tv_archive_duration = int(definition.ADDONgetSetting('tv_archive_duration'))
                if type(default_tv_archive_duration) != int:
                    default_tv_archive_duration = 2
                tv_archive_duration = tv_archive
            except:
                pass
                tv_archive = 0
                default_tv_archive_duration = 2
                tv_archive_duration = default_tv_archive_duration
            if tv_archive_duration > default_tv_archive_duration:
                definition.ADDONresetSetting('tv_archive_duration',str(tv_archive_duration))
            if tv_archive > 0:
                tv_archive = 1
            epg_channel_id = ch[9].replace(' (R)','')  ### Ignore Recursive marker
            log('error getEPGnow(epg_channel_id= %r)' % epg_channel_id)
            log('error getEPGnow(recordings.getEPGProgramsNow(epg_channel_id)= %r)' % recordings.getEPGProgramsNow(epg_channel_id))
            result = [recordings.getEPGProgramsNow(epg_channel_id), name, tv_archive, tv_archive_duration, epg_channel_id]
    if result == []:
        log('EPG not found for cat= %r' % cat)
    c.close() 
    return result
    
def getEPG(cat):
    try:
        ###now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        ###now= datetime.today()
        ###log('getEPG(cat)')
        conn = recordings.getConnection()
        c = conn.cursor()
        c.execute("SELECT * FROM channels WHERE id=? AND visible=1", [cat])
        favorites = c.fetchall()
        result = []
        for index in range(0, len(favorites)):
            if result == []:
                ch = []
                for i in range(0, len(favorites[index])):
                    if favorites[index][i] == None:
                        ch.append('')
                    else:
                        ch.append(favorites[index][i])
                ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
                name = ch[1]
                tv_archive = ch[8]  ### Holds duration in days - 0 means no archive
                if type(tv_archive) != int:
                    tv_archive = 0
                try:
                    default_tv_archive_duration = int(definition.ADDONgetSetting('tv_archive_duration'))
                    if type(default_tv_archive_duration) != int:
                        default_tv_archive_duration = 2
                except:
                    pass
                    default_tv_archive_duration = 2
                tv_archive_duration = tv_archive
                if tv_archive_duration > default_tv_archive_duration:
                    definition.ADDONresetSetting('tv_archive_duration',str(tv_archive_duration))
                if tv_archive > 0:
                    tv_archive = 1
                epg_channel_id = ch[9].replace(' (R)','')  ### Ignore Recursive marker
                result = [recordings.getEPGPrograms(epg_channel_id), name, tv_archive, tv_archive_duration, epg_channel_id]
                log('errYYY epg_channel_id= %r, name= %r, tv_archive= %r, tv_archive_duration= %r'   % (epg_channel_id, name, tv_archive, tv_archive_duration))
        if result == []:
            log('EPG not found for cat= %r' % cat)
        c.close() 
        return result
    except Exception as e:
        pass
        log('Error in getEPG!\n' + repr(e))
    return []
    """
    ### Find name, tv_archive, tv_archive_duration, epg_channel_id in database... 2017-07-14
    linkpanel = 'http://roq-tv.net:25461/panel_api.php?username=' +ROQuser+ '&password=' +ROQpass
    file = urllib.parse.urlopen(linkpanel)
    datapanel = file.read()
    file.close()
    try:
        datapanel = json.loads(datapanel)
        name = datapanel['available_channels'][cat]['name']
        tv_archive = datapanel['available_channels'][cat]['tv_archive']
        tv_archive_duration = datapanel['available_channels'][cat]['tv_archive_duration']
        epg_channel_id = datapanel['available_channels'][cat]['epg_channel_id']
    except Exception as e:
        pass
        ### or Find epg_channel_id based on cat....
        notification('Error in getting '+ ADDONid + ' info or your channel is from XML file!\n' + repr(e))
        return ''
    
    return [recordings.getEPGPrograms(epg_channel_id), name, tv_archive, tv_archive_duration, epg_channel_id]
    """
    """
    httplinkEPG = 'http://roq-tv.net:25461/xmltv.php?username=' +ROQuser+ '&password=' +ROQpass
    file = urllib.parse.urlopen(httplinkEPG)
    dataepg = file.read()
    file.close()
    try:
        dataepg = xmltodict.parse(dataepg)
    except Exception as e:
        pass
        notification('Error 848 in EPG file '+ httplinkEPG + ' \n' + repr(e))
        return ''
    try:
        epg = dataepg['tv']['programme']
        logdev(module,repr(dataepg['tv']['programme']))
    except Exception as e:
        pass
        notification('Error in EPG programme '+ httplinkEPG + ' \n' + repr(e))
        return ''
    return
    """
    
def isExtKnown(infile):
    ffmpegoutputtype = definition.ADDONgetSetting('ffmpegoutputtype').lower()
    infileext = infile.lower().rsplit('.',1)[-1]
    ###log('infileext= %r, ffmpegoutputtype= %r' % (infileext, ffmpegoutputtype))
    if infileext == ffmpegoutputtype:
        return True
    extorgcollection = definition.ADDONgetSetting('extorgcollection').lower().split(',')
    if infileext in extorgcollection:
    ###if infile[-3:].lower()=='.ts' or infile[-4:].lower()=='.mp4' or infile[-4:].lower()=='.mkv' or infile[-4:].lower()== '.avi' or infile[-4:].lower() == '.m4v' or infile[-4:].lower()=='.flv' or infile[-ffmpegoutputtypelen:].lower()==ffmpegoutputtype:
        return True
    else:
        return False
    
def find_files(directory, pattern):
    for root, dirs, files in os.walk(directory):
        for basename in files:
            if fnmatch.fnmatch(basename, pattern):
                filename = os.path.join(root, basename)
                yield filename
"""
def geturldirectorypath(archive):
    try:
        archive = archive.upper()
        if archive == 'L':
            urldirectorypath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_path')))
        elif archive == 'A':
            if definition.ADDONgetSetting('record_archive_path_enable') == 'true':
                urldirectorypath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_archive_path')))
            else:
                urldirectorypath = ''
        elif archive == 'B':
            if definition.ADDONgetSetting('record_archiveb_path_enable') == 'true':
                urldirectorypath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_archiveb_path')))
            else:
                urldirectorypath = ''
        else:
            urldirectorypath = ''
        log('error OK geturldirectorypath archive= %r\nurldirectorypath= %r' % (archive,urldirectorypath))
        return urldirectorypath
    except Exception as e:
        pass
        log('error geturldirectorypath archive= %r\nurldirectorypath= %r\n%r' % (archive,urldirectorypath,e))
        return ''
"""        
def geturldirectorydestinationpath(options):
    try:
        if options[:2] == 'l:':
            urldirectorydestinationpath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_path')))
        elif options[:2] == 'a:':
            if definition.ADDONgetSetting('record_archive_path_enable') == 'true':
                urldirectorydestinationpath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_archive_path')))
            else:
                urldirectorydestinationpath = ''
        elif options[:2] == 'b:':
            if definition.ADDONgetSetting('record_archiveb_path_enable') == 'true':
                urldirectorydestinationpath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_archiveb_path')))
            else:
                urldirectorydestinationpath = ''
        elif options[:2] == 'f:':
            if definition.ADDONgetSetting('record_archivef_path_enable') == 'true':
                urldirectorydestinationpath = xbmcvfs.translatePath(os.path.join(definition.ADDONgetSetting('record_archivef_path')))
            else:
                urldirectorydestinationpath = ''
        else:
            urldirectorydestinationpath = ''
        log('error OK geturldirectorydestinationpath options= %r\nurldirectorydestinationpath= %r' % (options,urldirectorydestinationpath))
        return urldirectorydestinationpath
    except Exception as e:
        pass
        log('error geturldirectorydestinationpath options= %r\nurldirectorydestinationpath= %r\n%r' % (options,urldirectorydestinationpath,e))
        return ''
    
def FindCommands(c,folderpath,archive):
    commands = ['rename','move','movetofolder','delete','changetitle']
    try:
        ### CHANGE TITLE command
        c.execute("SELECT * FROM files WHERE archive=? AND command=?" , [archive,'changetitle'])
        channels = c.fetchall()
        log('FindCommands changetitle archive= %r, count= %r' % (archive,len(channels)))
        x = len(channels)
        if x > 0:
            utils.notificationforced('Change Title ' + str(x) + ' records in '+archive.lower()+': ', time = 1)
            for chan in channels:
                ###c.execute("INSERT OR REPLACE INTO files(filename, ext, path, video, description, size, archive, updated, created, updatedHuman, command, options, realtitle, startmark) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [filename, chan[1], chan[2], chan[3], chan[4], chan[5], archive, nowTS, chan[8], humantime(nowTS), command, options, realtitle, startmark])
                try:    ### changetitle
                    log('changetitle')
                    urlbase = chan[0] 
                    if chan[1] != '':
                        fileext = '.' + chan[1]
                    else:
                        fileext = ''
                    urldirectorypath = utils.geturldirectorypath(archive)
                    path = chan[2]
                    if path != '':
                        urldirectorypath = os.path.join(urldirectorypath,path)   
                    if not os.path.exists(urldirectorypath):
                        log('os.makedirs(urldirectorypath= %r' % urldirectorypath)
                        os.makedirs(urldirectorypath)    
                    log('error FindCommands changetitle archive= %r, urldirectorypath= %r' % (archive, urldirectorypath))
                    urlnewi = chan[11]   ### options
                    if urlnewi != '':
                        urlnewi = ' '.join(urlnewi.split())  ## Remove doublespaces etc
                        urlbase = os.path.join(urldirectorypath,urlbase)
                        log('urlbase= %r' % urlbase)
                        urlbase = urlbase.replace('aMp ','& ').replace('xXx','+')   ### 2019-03-17
                        ###write options to .tit file
                        try:
                            titleFile = urlbase + '.tit'
                            if urlnewi != '':
                                LF = open(titleFile, 'w')  ### 2020-11-03
                                LF.write(urlnewi)
                                if chan[13] != '':
                                    LF.write('\n'+chan[13])
                            # Close our file so no further writing is posible.
                            LF.close()
                            ###def addFile(c, filename, ext, path, video, description, size, archive, realtitle='', startmark='', duration= '')
                            recordings.addFile(c, chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[11], chan[13], chan[14], chan[15])  ### change real title
                            recordings.addFileCommand(c, chan[0], chan[1], chan[2], chan[6], '', '')  ### Clear command
                            """
                            try:
                                ###os.chmod(titleFile, 0o776 )
                                log('err NOT titleFile permission set to 0776')
                            except Exception as e:
                                pass
                                log('Failed to set titleFile permission to 0776: ' + repr(e))
                            """
                        except Exception as e:
                            pass
                            log('error writing titleFile= %r\n%r' % (titleFile,e))
                except Exception as e:
                    pass
                    log('changetitle error %r' % e)
        else:
            log('error FindCommands changetitle - no records found!')        
        ### RENAME command
        c.execute("SELECT * FROM files WHERE archive=? AND command=?" , [archive,'rename'])
        channels = c.fetchall()
        log('FindCommands rename archive= %r, count= %r' % (archive,len(channels)))
        x = len(channels)
        if x > 0:
            utils.notificationforced('Rename ' + str(x) + ' records in '+archive.lower()+': ', time = 1)
            for chan in channels:
                ###c.execute("INSERT OR REPLACE INTO files(filename, ext, path, video, description, size, archive, updated, created, updatedHuman, command, options) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [filename, chan[1], chan[2], chan[3], chan[4], chan[5], archive, nowTS, chan[8], humantime(nowTS), command, options])
                try:    ### Rename information and subtitles if they are available
                    urlbase = chan[0] 
                    if chan[1] != '':
                        fileext = '.' + chan[1]
                    else:
                        fileext = ''
                    urldirectorypath = utils.geturldirectorypath(archive)     
                    path = chan[2]
                    if path != '':
                        urldirectorypath = os.path.join(urldirectorypath,path)   
                    if not os.path.exists(urldirectorypath):
                        log('os.makedirs(urldirectorypath= %r' % urldirectorypath)
                        os.makedirs(urldirectorypath)    
                    log('FindCommands rename archive= %r, urldirectorypath= %r' % (archive, urldirectorypath))
                    urlnewi = chan[11]
                    if urlnewi != '':
                        urlnewi = recordings.latin1_to_ascii_force(urlnewi)   ### use only acceptable characters
                        urlnewi = ' '.join(urlnewi.split())  ## Remove doublespaces etc
                        urlnew = os.path.join(urldirectorypath,urlnewi)
                        pathofdestination = os.path.dirname(urlnew)
                        log('pathofdestination= %r' % pathofdestination)
                        if not os.path.exists(pathofdestination):
                            log('os.makedirs(pathofdestination= %r'  % pathofdestination)
                            os.makedirs(pathofdestination)  
                        log('urlnew= %r' % urlnew)
                        urlbase = os.path.join(urldirectorypath,urlbase)
                        log('urlbase= %r' % urlbase)
                        log('rename urlbase+fileext= %s, urlnew+fileext= %s' % (urlbase+fileext, urlnew+fileext))
                        urlbase = urlbase.replace('aMp ','& ').replace('xXx','+')   ### 2019-03-17
                        ###os.rename(urlbase+fileext,urlnew+fileext)
                        shutil.move(urlbase+fileext,urlnew+fileext)
                        try:
                            shutil.move(urlbase+'.txt',urlnew+'.txt')
                        except Exception as e:
                            pass
                            log('Rename error %r' % e)
                        try:
                            shutil.move(urlbase+'.srt',urlnew+'.srt')
                        except Exception as e:
                            pass
                            log('Rename error %r' % e)
                        try:
                            shutil.move(urlbase+'.en.srt',urlnew+'.en.srt')
                        except Exception as e:
                            pass
                            log('Rename error %r' % e)
                        try:
                            shutil.move(urlbase+'.da.srt',urlnew+'.da.srt')
                        except Exception as e:
                            pass
                            log('Rename error %r' % e)
                        try:
                            shutil.move(urlbase+'.xml',urlnew+'.xml')
                        except Exception as e:
                            pass
                            log('Rename error %r' % e)
                        try:
                            shutil.move(urlbase+'.en.xml',urlnew+'.en.xml')
                        except Exception as e:
                            pass
                            log('Rename error %r' % e)
                        try:
                            shutil.move(urlbase+'.da.xml',urlnew+'.da.xml')
                        except Exception as e:
                            pass
                            log('Rename error %r' % e)
                        try:
                            shutil.move(urlbase+'.nfo',urlnew+'.nfo')
                        except Exception as e:
                            pass
                            log('Rename error %r' % e)
                        try:
                            shutil.move(urlbase+'.tit',urlnew+'.tit')
                        except Exception as e:
                            pass
                            log('Rename error %r' % e)
                        try:
                            shutil.move(urlbase+'.log',urlnew+'.log')
                        except Exception as e:
                            pass
                            log('Rename error %r' % e)
                except Exception as e:
                    pass
                    log('Rename error %r' % e)
        else:
            log('FindCommands rename - no records found!')
        
        ### MOVE command
        c.execute("SELECT * FROM files WHERE archive=? AND command=?" , [archive,'move'])
        channels = c.fetchall()
        log('FindCommands move to/from archive= %r, count= %r' % (archive,len(channels)))
        x = len(channels)
        if x > 0:
            utils.notificationforced('Move ' + str(x) + ' records in '+archive.lower()+': ', time = 1)
            for chan in channels:
                ###c.execute("INSERT OR REPLACE INTO files(filename, ext, path, video, description, size, archive, updated, created, updatedHuman, command, options) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [filename, chan[1], chan[2], chan[3], chan[4], chan[5], archive, nowTS, chan[8], humantime(nowTS), command, options])
                try:    ### Rename information and subtitles if they are available
                    urlbase = chan[0] 
                    if chan[1] != '':
                        fileext = '.' + chan[1]
                    else:
                        fileext = ''
                    urldirectorypath = utils.geturldirectorypath(archive)
                    options = chan[11]
                    urldirectorydestinationpath = geturldirectorydestinationpath(options)
                    path = chan[2]
                    if path != '':
                        urldirectorypath = os.path.join(urldirectorypath,path)   
                        urldirectorydestinationpath = os.path.join(urldirectorydestinationpath,path)   
                    if not os.path.exists(urldirectorypath):
                        log('os.makedirs(urldirectorypath= %r' % urldirectorypath)
                        os.makedirs(urldirectorypath)   
                    if not os.path.exists(urldirectorydestinationpath):
                        log('1. os.makedirs(urldirectorydestinationpath= %r' % urldirectorydestinationpath)
                        os.makedirs(urldirectorydestinationpath)   
                    log('FindCommands move to/from archive= %r, urldirectorypath= %r' % (archive, urldirectorypath))
                    log('FindCommands move to/from archive= %r, urldirectorydestinationpath= %r' % (archive, urldirectorydestinationpath))
                    urlnewi = chan[11]
                    if urlnewi != '':
                        urlnewi = recordings.latin1_to_ascii_force(urlnewi)   ### use only acceptable characters
                        urlnewi = ' '.join(urlnewi.split())  ## Remove doublespaces etc
                        urlnew = os.path.join(urldirectorydestinationpath,urlnewi)
                        log('urlnew= %r' % urlnew)
                        urlbase = os.path.join(urldirectorypath,urlbase)
                        log('urlbase= %r' % urlbase)
                        log('move urlbase+fileext= %s, urlnew+fileext= %s' % (urlbase+fileext, urlnew+fileext))
                        shutil.move(urlbase+fileext,urlnew+fileext)
                        try:
                            shutil.move(urlbase+'.txt',urlnew+'.txt')
                        except Exception as e:
                            pass
                            log('move error %r' % e)
                        try:
                            shutil.move(urlbase+'.tit',urlnew+'.tit')
                        except Exception as e:
                            pass
                            log('move error %r' % e)    
                        try:
                            shutil.move(urlbase+'.srt',urlnew+'.srt')
                        except Exception as e:
                            pass
                            log('move error %r' % e)
                        try:
                            shutil.move(urlbase+'.en.srt',urlnew+'.en.srt')
                        except Exception as e:
                            pass
                            log('move error %r' % e)
                        try:
                            shutil.move(urlbase+'.da.srt',urlnew+'.da.srt')
                        except Exception as e:
                            pass
                            log('move error %r' % e)
                        try:
                            shutil.move(urlbase+'.xml',urlnew+'.xml')
                        except Exception as e:
                            pass
                            log('move error %r' % e)
                        try:
                            shutil.move(urlbase+'.en.xml',urlnew+'.en.xml')
                        except Exception as e:
                            pass
                            log('move error %r' % e)
                        try:
                            shutil.move(urlbase+'.da.xml',urlnew+'.da.xml')
                        except Exception as e:
                            pass
                            log('move error %r' % e)
                        try:
                            shutil.move(urlbase+'.nfo',urlnew+'.nfo')
                        except Exception as e:
                            pass
                            log('move error %r' % e)
                        try:
                            shutil.move(urlbase+'.log',urlnew+'.log')
                        except Exception as e:
                            pass
                            log('move error %r' % e)
                except Exception as e:
                    pass
                    log('move error %r' % e)
                
        else:
            log('FindCommands move - no records found!')
        
        ### MOVE to FOLDER command
        c.execute("SELECT * FROM files WHERE archive=? AND command=?" , [archive,'movetofolder'])
        channels = c.fetchall()
        log('FindCommands movetofolder= %r, count= %r' % (archive,len(channels)))
        x = len(channels)
        if x > 0:
            movecount = 1
            utils.notificationforced('Move to folder: ' + str(x) + ' records in '+archive.lower()+': ', time = 1)
            for chan in channels:
                ###c.execute("INSERT OR REPLACE INTO files(filename, ext, path, video, description, size, archive, updated, created, updatedHuman, command, options) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [filename, chan[1], chan[2], chan[3], chan[4], chan[5], archive, nowTS, chan[8], humantime(nowTS), command, options])
                try:    
                    options = chan[11]
                    log('1250 error options= %r' % options)
                    urldirectorydestinationpath = geturldirectorydestinationpath(options)
                    urlbase = chan[0] 
                    archive = chan[6] 
                    urldirectorypath = utils.geturldirectorypath(archive)
                    if chan[1] != '':
                        fileext = '.' + chan[1]
                    else:
                        fileext = ''
                    path = chan[2]
                    if path != '':
                        urldirectorypath = os.path.join(urldirectorypath,path)   
                        ###urldirectorydestinationpath = os.path.join(urldirectorydestinationpath,path)   ### Don't keep source directory
                    if not os.path.exists(urldirectorypath):
                        log('os.makedirs(urldirectorypath= %r' % urldirectorypath)
                        os.makedirs(urldirectorypath)      
                    log('1289 error FindCommands move to folder src= %r, urldirectorypath= %r' % (archive, urldirectorypath))
                    log('1290 error FindCommands move to folder dst= %r, urldirectorydestinationpath= %r' % (archive, urldirectorydestinationpath))
                    urlnewi = options
                    log('FindCommands move to folder urlnewi= %r, urlnewi[:2]= %r, urlnewi[2:]= %r' % (urlnewi, urlnewi[:2], urlnewi[2:]))
                    
                    log('1297 error FindCommands move to folder dst= %r, urldirectorydestinationpath= %r' % (options, urldirectorydestinationpath))
                    pathnew = urlnewi[2:]
                    if '\\' in urldirectorydestinationpath:
                        pathnew = pathnew.replace('/','\\')
                    urldirectorydestinationpath = os.path.join(urldirectorydestinationpath,pathnew)
                    log('urldirectorydestinationpath= %r' % urldirectorydestinationpath)
                    if not os.path.exists(urldirectorydestinationpath):
                        os.makedirs(urldirectorydestinationpath) 
                        log('Greate new folder if necessary: urldirectorydestinationpath= %r'% urldirectorydestinationpath)
                        ### 2019-09-11 Greate new folder if necessary
                    if urlnewi != '':
                        urlbase0 = urlbase[0:35]      #### 2025-06-01
                        urlnew = os.path.join(urldirectorydestinationpath,urlbase)
                        log('urlnew= %r' % urlnew)
                        urlbase = os.path.join(urldirectorypath,urlbase)
                        log('movetofolder urlbase+fileext= %s, urlnew+fileext= %s' % (urlbase+fileext, urlnew+fileext))
                        definition.ADDONresetSetting('filescanstatusmove','Moving: #%d/%d %r'% (movecount, x, urlbase0))   ### 2025-06-01
                        movecount += 1
                        shutil.move(urlbase+fileext,urlnew+fileext)
                        try:
                            shutil.move(urlbase+'.txt',urlnew+'.txt')
                        except Exception as e:
                            pass
                            log('998 move to folder error %r' % e)
                        try:
                            shutil.move(urlbase+'.tit',urlnew+'.tit')
                        except Exception as e:
                            pass
                            log('998 move to folder error %r' % e)
                        try:
                            shutil.move(urlbase+'.srt',urlnew+'.srt')
                        except Exception as e:
                            pass
                            log('1003 move to folder error %r' % e)
                        try:
                            shutil.move(urlbase+'.en.srt',urlnew+'.en.srt')
                        except Exception as e:
                            pass
                            log('1008 move to folder error %r' % e)
                        try:
                            shutil.move(urlbase+'.da.srt',urlnew+'.da.srt')
                        except Exception as e:
                            pass
                            log('1013 move to folder error %r' % e)
                        try:
                            shutil.move(urlbase+'.xml',urlnew+'.xml')
                        except Exception as e:
                            pass
                            log('1003 move to folder error %r' % e)
                        try:
                            shutil.move(urlbase+'.en.xml',urlnew+'.en.xml')
                        except Exception as e:
                            pass
                            log('1008 move to folder error %r' % e)
                        try:
                            shutil.move(urlbase+'.da.xml',urlnew+'.da.xml')
                        except Exception as e:
                            pass
                            log('1013 move to folder error %r' % e)
                        try:
                            shutil.move(urlbase+'.nfo',urlnew+'.nfo')
                        except Exception as e:
                            pass
                            log('1018 move to folder error %r' % e)
                        try:
                            shutil.move(urlbase+'.log',urlnew+'.log')
                        except Exception as e:
                            pass
                            log('1023 move to folder errorY %r' % e)
                        definition.ADDONresetSetting('filescanstatusmove','Finished #%d/%d %r'% (movecount, x, urlbase0))    ### 2025-06-11
                except Exception as e:
                    pass
                    log('1026 move to folder error %r' % e)
                
        else:
            log('error FindCommands move to folder - no records found!')
            definition.ADDONresetSetting('filescanstatusmove','No records to move')    ### 2025-06-11
        
        ### DELETE command
        c.execute("SELECT * FROM files WHERE archive=? AND command=?" , [archive,'delete'])
        channels = c.fetchall()
        log('FindCommands rename archive= %r, count= %r' % (archive,len(channels)))
        x = len(channels)
        if x > 0:
            utils.notificationforced('DELETE ' + str(x) + ' records in '+archive.lower()+': ', time = 1)
            for chan in channels:
                ###c.execute("INSERT OR REPLACE INTO files(filename, ext, path, video, description, size, archive, updated, created, updatedHuman, command, options) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [filename, chan[1], chan[2], chan[3], chan[4], chan[5], archive, nowTS, chan[8], humantime(nowTS), command, options])
                try:    ### Rename information and subtitles if they are available
                    urlbase = chan[0] 
                    if chan[1] != '':
                        fileext = '.' + chan[1]
                    else:
                        fileext = ''
                    urldirectorypath = utils.geturldirectorypath(archive)
                    path = chan[2]
                    if path != '':
                        urldirectorypath = os.path.join(urldirectorypath,path)     
                    log('Exception FindCommands delete archive= %r, urldirectorypath= %r' % (archive, urldirectorypath))
                    urlnewi = chan[11]
                    if urlbase != '':
                        urlbase = os.path.join(urldirectorypath,urlbase)
                        urlbase = urlbase.replace('\\','¤').replace('/','¤').replace('¤',os.sep)
                        log('urlbase= %r' % urlbase)
                        log('Exception delete urlbase+fileext= %s' % (urlbase+fileext))
                        os.remove(urlbase+fileext)
                        try:
                            os.remove(urlbase+'.txt')
                        except Exception as e:
                            pass
                            log('Delete error %r' % e)
                        try:
                            os.remove(urlbase+'.tit')
                        except Exception as e:
                            pass
                            log('Delete error %r' % e)
                        try:
                            os.remove(urlbase+'.srt')
                        except Exception as e:
                            pass
                            log('Delete error %r' % e)
                        try:
                            os.remove(urlbase+'.en.srt')
                        except Exception as e:
                            pass
                            log('Delete error %r' % e)
                        try:
                            os.remove(urlbase+'.da.srt')
                        except Exception as e:
                            pass
                            log('Delete error %r' % e)
                        try:
                            os.remove(urlbase+'.xml')
                        except Exception as e:
                            pass
                            log('Delete error %r' % e)
                        try:
                            os.remove(urlbase+'.en.xml')
                        except Exception as e:
                            pass
                            log('Delete error %r' % e)
                        try:
                            os.remove(urlbase+'.da.xml')
                        except Exception as e:
                            pass
                            log('Delete error %r' % e)
                        try:
                            os.remove(urlbase+'.nfo')
                        except Exception as e:
                            pass
                            log('Delete error %r' % e)
                        try:
                            os.remove(urlbase+'.log')
                        except Exception as e:
                            pass
                            log('Delete error %r' % e)
                except Exception as e:
                    pass
                    log('Exception Delete error %r' % e)
        else:
            log('Exception FindCommands Delete - no records found!')
    except Exception as e:
        pass
        log('Exception FindCommands ERROR: %r' % e)

def setFileDuration(filename,archive,duration):
    try:
        archive = archive.upper()
        log('error setFileDuration filename= %r, duration= %r' % (filename,duration) )
        conf = recordings.getFilesConnection()
        c = conf.cursor()
        if '.' in filename:
            ext = filename.split('.')[-1]
            filename = filename.split('.'+ext)[0]
        else:
            ext = ''
        c.execute("SELECT * FROM files WHERE filename=? AND ext=? AND archive = ?", [filename,ext,archive]) 
        selected = c.fetchall()
        log('error setFileDuration selected count= %r' % len(selected) )
        for chan in selected:
            ###c.execute("INSERT OR REPLACE INTO files(filename, ext, path, video, description, size, archive, updated, created, updatedHuman, command, options, realtitle, startmark) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [filename, chan[1], chan[2], chan[3], chan[4], chan[5], archive, nowTS, chan[8], humantime(nowTS), command, options, realtitle, startmark])
            log('error addFile setFileDuration filename= %r, duration= %r' % (chan[0],duration) )
            recordings.addFile(c, chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[12], chan[13], chan[14], duration)  
            
        conf.commit()
        c.close() 
    except Exception as e:
        pass
        log('setFileDuration ERROR: %r' % e )

def getMyVideosConnection():    
    MyVideos_DB = utils.MyVideos_DB()
    dbPath = xbmcvfs.translatePath('special://masterprofile/')
    log('error MyVideos dbPath= %r' % dbPath)
    log('error MyVideos os.path.join(dbPath, MyVideos_DB)= %r' % os.path.join(dbPath, 'Database', MyVideos_DB))
    conn   = sqlite3.connect(os.path.join(dbPath, 'Database', MyVideos_DB), timeout = 20, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    return conn

def getDurationFromDatabase(file,archive):
    log('errorY 1525 getDurationFromDatabase file= %r, archive= %r' % (file,archive))
    dfile = os.path.dirname(file) + os.sep
    idPath = 0
    bfile = os.path.basename(file)
    conn = getMyVideosConnection()
    c = conn.cursor()
    log('errorY 1531 getDurationFromDatabase dfile= %r' % dfile)    
    c.execute("SELECT * FROM path WHERE strPath=?",[dfile])
    idPaths = c.fetchall()
    log('errorY 1533 getDurationFromDatabase len(idPaths)= %r' % len(idPaths))   
    if len(idPaths) == 1:
        for idPathi in idPaths:
            idPath = idPathi[0]
            log('errorY 1536 getDurationFromDatabase idPath= %r' % idPath)    
            c.execute("SELECT * FROM files WHERE strFilename = ? AND idPath=?",[bfile,idPath])
            filematch = c.fetchall()
            log('error 1540 file= %r, len(filematch)= %r' % (bfile, len(filematch)))
            for ifile in filematch:
                idFile  = ifile[0]
                log('errorY 1536 getDurationFromDatabase idFile= %r' % idFile) 
                c.execute("SELECT iVideoDuration FROM streamdetails WHERE idFile = ? AND iStreamType = 0",[idFile])
                durationl = c.fetchall()
                log('error 1546 file= %r, len(durationl)= %r' % (bfile, len(durationl)))
                for durationi in durationl:
                    duration = durationi[0]
                    log('error 1549 file= %r, duration= %r' % (bfile, duration))
                    if duration != None and duration > 0:
                        hmduration = utils.hmduration(duration/60 + 1)
                        setFileDuration(bfile,archive,hmduration)
                        log('error 1513 getDurationFromDatabase hmduration= %r' % hmduration)
                        return hmduration
    return ''
   
def addDuration(TotalDuration,Duration):
    try:
        if 'h' in Duration and 'm' in Duration:
            dura = Duration.split('m')[0].split('h')
            TotalDuration += 60 * int(dura[0]) + int(dura[1])
    except Exception as e:
        pass
        log('addDuration (TotalDuration= %r, Duration= %r) Exception: %r '% (TotalDuration,Duration,e))
    log('addDuration (TotalDuration= %r, Duration= %r)'% (TotalDuration,Duration))
    return TotalDuration
    
def ScanFiles(c,folderPath,archive,excommand=True):
    if 'smb://' in folderPath.lower():
        log('Exception: No scan of smb:// folders')
        return
    log('ScanFiles(folderPath= %r, archive= %r)'% (folderPath,archive))
    freespace = utils.get_free_space_gb(folderPath,archive)
    log('utils.get_free_space_gb(folderPath= %r)= %r' % (folderPath,freespace))
    ###folderPathScan = folderPath.replace('\\','/').replace(':','').replace(' ','')   ### 2023-12-31
    folderPathScan = folderPath.replace(':','').replace(' ','')   ### 2023-12-31
    log('1771 ScanFiles folderPathScan= %r freespace= %r' % (folderPathScan,freespace))
    Length = -2
    if freespace == 0:
        notetext = 'No File Scanning of '+archive+' as it reports no room/access!'
        definition.ADDONresetSetting('filescanstatus',notetext)
        utils.notificationforced('No File Scanning of '+archive+' as it reports no room/access!')
        log('notetext 2 %r' % notetext)
    elif locking.isScanLocked('ScanFiles'+folderPathScan):
        notetext = 'No File Scanning of '+archive+' as it is still running!'
        definition.ADDONresetSetting('filescanstatus',notetext)
        utils.notificationforced('No File Scanning of '+archive+' as it is still running!')
        log('notetext 2 %r' % notetext)
    else:
        notetext = 'File Scanning Started of '+archive+'!'
        definition.ADDONresetSetting('filescanstatus',notetext)
        utils.notificationforced('File Scanning Started of '+archive+'!')
        log('notetext 1 %r' % notetext)
        locking.scanLock('ScanFiles'+folderPathScan)
        log('ScanFiles %r' % folderPathScan)
        now = datetime.now()
        i = 0
        j = 0
        TotalDuration = 0  ### Minutes
        cutoffnowTS = int(datetime.timestamp(now))
        tstart = datetime.today()
        if excommand == True:
            FindCommands(c,folderPath,archive)
        for infile in find_files(folderPath, '*'):
            Duration = ''
            if j%25 == 0 and j > 0:
                tend = datetime.today()
                notetext = TimeUsed(tend,tstart) +' Scanning videos in '+archive+': '+str(j)+ '# ' + str(TotalDuration//60).split('.')[0]+'h'  ### 2025-07-06
                definition.ADDONresetSetting('filescanstatus',notetext)
                utils.notification(notetext)  ### 2025-07-06
            i +=1
            try:
                fileext = ''
                fileextt = ''
                if '.' in infile:
                    fileext = infile.split('.')[-1]
                    log('1282 infile= %r, fileext= %r' % (infile, fileext))
                    fileextt = '.' + fileext
            except Exception as e:
                pass
                notetext = 'Exception in find_files. infile= %r\nERROR: %r' % (infile,e)
                definition.ADDONresetSetting('filescanstatus',notetext)
                log('Exception in find_files. infile= %r\nERROR: %r' % (infile,e))
                fileext = repr(e)
                fileextt = fileext
            infilebasename = os.path.basename(infile).replace(fileextt,'',-1) # the file name only
            if len(folderPath)>0:
                pathoffile = os.path.dirname(infile).replace(folderPath[:-1],'',1)
                if len(pathoffile) >0:
                    pathoffile = pathoffile[1:]
            else:
                pathoffile = ''
            video = repr(isExtKnown(infile))
            log('1. video= %r\n%r' % (video,infile))
            titlefilename = infile.replace(fileextt,'.tit',-1)
            
            descriptionfilename = infile.replace(fileextt,'.txt',-1)
            description = ''
            realtitle = infilebasename
            log('UPD realtitle= %r' % realtitle)
            startmark = '#¤#'
            if not os.path.isfile(titlefilename):
                if os.path.isfile(descriptionfilename):
                    try:
                        descf = io.open(descriptionfilename,'r') ###, encoding="utf-8")   ###io.open(infile, 'r', encoding="utf-8")
                        desc = descf.read()
                        descf.close()
                        desc = desc.split('Title= ')
                        realtitle = desc[1].split('\n')[0]
                        if realtitle != '':
                            LF = open(titlefilename, 'w')  ### 2021-02-01
                            LF.write(realtitle)
                            LF.close()
                    except Exception as e:
                        pass
                        log('realtitle/tit= %r\nException: %r ' % (titlefilename,e))        
            else:
                try:               ### Description:
                    bom = utils.bomType(titlefilename)
                    log('bom= %r\n titlefilename= %r' % (bom, titlefilename))
                    descf = io.open(titlefilename,'r', encoding="utf-8")   ###io.open(infile, 'r', encoding="utf-8")
                    desc = descf.read()
                    descf.close()
                    desc = desc.split('\n')
                    realtitle = desc[0]
                    log('realtitle= ' + repr(realtitle))
                    try:
                        startmark = desc[1]
                        log('startmark= ' + repr(startmark))
                    except Exception as e:
                        pass
                        log('startmark Error ' + repr(e))
                except Exception as e: 
                    pass
                    try:               ### Description:
                        descf = io.open(titlefilename,'r', encoding="cp1252")   ###io.open(infile, 'r', encoding="utf-8")
                        desc = descf.read()
                        descf.close()
                        desc = desc.split('\n')
                        realtitle = desc[0]
                        log('err realtitle= ' + repr(realtitle))
                        try:
                            startmark = desc[1]
                            log('startmark= ' + repr(startmark))
                        except Exception as e:
                            pass
                            log('startmark Error 1 ' + repr(e))
                    except Exception as e: 
                        pass
                        realtitle = 'Title Exception : ' + repr(e)
                        log('realtitle= %r\nERROR= %r' % (titlefilename,e))
            log('realtitle= %r' % realtitle)
            log('1887 ScanFiles(folderPath= %r, archive= %r)'% (folderPath,archive))
            if video == 'True':
                j +=1
                desc = ' NOT SET '
                if os.path.isfile(descriptionfilename):
                    try:               ### Description:
                        ###stats = os.stat(descriptionfilename)
                        ###log('1554 errorX os.stat(descriptionfilename)= %r\n%r' % (descriptionfilename,stats))  ###2023-03-15
                        bom = utils.bomType(descriptionfilename)
                        log('err bom= %r\n descriptionfilename= %r' % (bom, descriptionfilename))
                        log('err 1423 descriptionfilename= %r' % descriptionfilename, showlength=100000)
                        ###descf = io.open(descriptionfilename,'r', encoding="utf-8")   ###io.open(infile, 'r', encoding="utf-8")
                        ###xbmcvfs.File.read
                        from contextlib import closing
                        from xbmcvfs import File

                        with closing(File(descriptionfilename)) as fo:
                            desc = fo.read()
                        ###descf = open(descriptionfilename,'r')   #, encoding="utf-8")   ###io.open(infile, 'r', encoding="utf-8")
                        ###log('err 1425 descf= %r' % descf, showlength=100000)
                        ###desc = descf.read()
                        log('err 1427 desc= %r' % desc, showlength=100000)
                        descf.close()
                        description = 'Description:\n' + desc.split('Description:')[1]
                        ###log('desc= ' + repr(desc))
                    except Exception as e: 
                        pass
                        description = repr(descriptionfilename) +' Except: ' + repr(e)
                        log('1441 Error= %r\ndescription= %r' % (e,desc),showlength=100000)
                        try:
                            with open(descriptionfilename, 'r', encoding='cp1252') as f1:
                                lines = f1.read()
                                log('445 lines= %r' % lines, showlength=100000)
                                ###f2 = open(descriptionfilename, 'w', encoding='utf-8')
                                ###f2.write(lines)
                                ###f2.close()
                                description = 'Description:\n' + lines.split('Description:')[1]
                        except Exception as e: 
                            pass  
                            log('1450 Except %r\ndescription= %r' % (e,desc),showlength=100000)
                            description = repr(descriptionfilename) +' cp1252 Exception  ' + repr(e)
            log('1727 ScanFiles(folderPath= %r, archive= %r)'% (folderPath,archive))
            subtitlefilename = infile.replace(fileextt,'.en.srt',-1)
            if os.path.isfile(subtitlefilename):
                st = xbmcvfs.Stat(subtitlefilename)
                subtitlefilensize = st.st_size()
            else:
                subtitlefilensize = 0
            if video == 'True' and subtitlefilensize > 0 :
                subtitlesavailable = True
            else:
                subtitlesavailable = False
            if subtitlesavailable:
                description = 'English subtitles available\n\n' + description
                noensubtitles = False
            else:
                noensubtitles = True
            subtitlefilename = infile.replace(fileextt,'.da.srt',-1)
            if os.path.isfile(subtitlefilename):
                st = xbmcvfs.Stat(subtitlefilename)
                subtitlefilensize = st.st_size()
            else:
                subtitlefilensize = 0
            if video == 'True' and subtitlefilensize > 0 :
                subtitlesavailable = True
            else:
                subtitlesavailable = False
            if subtitlesavailable:
                description = 'Danish subtitles available\n\n' + description
            else:
                if noensubtitles:
                    description = 'No subtitles available\n\n' + description    
            
            try:
                FileData = ''
                ###FileSize = repr(float(int(long(os.stat(infile).st_size)/long(1024*1024)))/1000)
                FileSz    = float(os.stat(infile).st_size)
                FileSzGB  = FileSz/(1024*1024*1024)
                log('Has size %r size in GB %r' % (FileSz,FileSzGB))
                FileSize = format(FileSzGB, '.3f')
                log('FileSize %r' % (FileSize))
                try:
                    filenametxt = infile.replace(fileextt,'.txt',-1)
                    if not os.path.isfile(filenametxt):  
                        filenametxt = infile   ### If . txt do not exist - use video file
                    filetimetxt = recordings.humantime(int(os.path.getmtime(filenametxt)))
                    filetime = recordings.humantime(int(os.path.getmtime(infile)))
                    if filetimetxt > filetime:
                        filetime = filetimetxt
                except Exception as e:
                    pass
                    filetime = 'ERROR in filetime: ' + repr(e)
                FileData = 'Size: '+ FileSize + ' GB\nDate: ' + filetime
                log('1. FileData= %r' % FileData)
                log('errorY 1774 ScanFiles(folderPath= %r, archive= %r)'% (folderPath,archive))
                if video == 'True':
                    fDuration = getDurationFromDatabase(infile,archive)
                    log('error getDurationFromDatabase filename= %r, fileduration= %r' % (infile,fDuration) )
                    if infile[:1] == '[':   ### 2019-03-11
                        nameparts = infile.split(']',1)
                        name = nameparts[1] + ' ' + nameparts[0] + ']'
                        name = name.strip()
                    else:
                        name = infile
                    log('errorY 1784 ScanFiles(folderPath= %r, archive= %r)'% (folderPath,archive))
                    try:
                        Duration = name.split('[',1)[1].split(']',1)[0]
                        log('error Duration 1= %r' % Duration)
                        if '2h00m' in Duration or '4h00m' in Duration or Duration == '':
                            Duration = fDuration
                        elif not 'h' in Duration or not 'm' in Duration:
                            log('error Duration 2= %r' % Duration)
                            Duration = name.split(']')[-2].split('[')[-1].split(' ')[-1]
                            log('error Duration 3= %r' % Duration)
                            if not 'h' in Duration or not 'm' in Duration or Duration == '' or len(Duration) > 6:
                                Duration = fDuration
                                log('error Duration 4= %r' % Duration)
                    except Exception as e:
                        pass
                        log('infile= %r\nDuration ERROR: %r' % (infile,e))
                        Duration = fDuration
                    log('error Duration 5= %r' % Duration)
                    TotalDuration = addDuration(TotalDuration,Duration)
                    Length = 0
                    try:
                        if Duration != '':
                            Length = int(Duration.split('h')[0])*60 + int(Duration.split('h')[1].split('m')[0])
                            FileData += '\nDuration: '+Duration+' '+str(Length)+'m'
                            log('2. FileData= %r' % FileData)
                    except Exception as e:
                        pass
                        log('Duration2 ERROR: %r' % e)
                        FileData += '\n\n' + repr(e)
                    filename = infile
                    if '/' in filename:
                        filename = filename.split('/')[-1]
                    elif '\\' in filename: 
                        filename = filename.split('\\')[-1]
                    Length = utils.SeriesEpisode(realtitle,module)   
                    if Length == 0:
                        Length = utils.SeriesEpisode(filename,module)    
                    try:
                        log('7. Length= %r' % Length)
                        ###if Length != -1:
                        if Length > 0:
                            SeriesEpisode = '\nSeries/Episode: S' + str(Length//1000) + 'E' + str(Length%1000)
                            log('1. SeriesEpisode= %r' % SeriesEpisode)
                            ###utils.logdev('SeriesEpisode','Length= %r' % Length)
                            FileData += SeriesEpisode
                            log('3. FileData= %r' % FileData)
                    except Exception as e:
                        pass
                        log('SeriesEpisode Error 1: %r' % e)
                        FileData += '\n\n' + repr(e)
                
            except Exception as e:
                pass
                log('SeriesEpisode Error2: %r' % e)
                FileData += '\n\n' + repr(e)
                log('4. FileData= %r' % FileData)
            log('error 8. Length= %r' % Length)
            description = description.replace('\n\n\n','\n').replace('\n\n','\n')
            if startmark == '#¤#':
                startmark = ''
            recordings.addFile(c, infilebasename, fileext, pathoffile, video, description, FileData, archive, realtitle, startmark, Duration)  ### Archive/Local
        tend = datetime.today()
        notetext = TimeUsed(tend,tstart) + ' @ ' + datetime.today().strftime('%Y-%m-%d %H:%M:%S') + ' with: '+str(j)+ '# ' + str(TotalDuration//60)+'h'  ### 2021-06-21
        definition.ADDONresetSetting('filescanstatus',notetext)
        utils.notification('Scanning videos ended in '+archive+': '+str(j)+ '# ' + str(TotalDuration//60)+'h', time = 10)  
        if archive.lower() == 'l':
            definition.ADDONresetSetting('filescanlocal',notetext)
        elif archive.lower() == 'a':
            definition.ADDONresetSetting('filescanarchive',notetext)
        elif archive.lower() == 'b':
            definition.ADDONresetSetting('filescanarchiveb',notetext)
        elif archive.lower() == 'f':
            definition.ADDONresetSetting('filescanarchivef',notetext)
        else:
            definition.ADDONresetSetting('filescanarchive',notetext)
        ### 2021-06-21
        ### Find outdated records
        recordings.addFileCleanup(c,folderPath,archive,cutoffnowTS)
        notetext = 'File Scanning of '+archive+' Finished!'
        definition.ADDONresetSetting('filescanstatus',notetext)
        utils.notificationforced('File Scanning of '+archive+' Finished!')
        locking.scanUnlock('ScanFiles'+folderPathScan)
      
def ScanRecordings(archive):
    log('Exception ScanRecordings Start %r' % archive)
    try:
        conf = recordings.getFilesConnection()
        recordings.createFileTable(conf)
        c = conf.cursor()
        recordPathBasic = definition.ADDONgetSetting('record_path')
        if recordPathBasic == '':
            recordPathBasic = definition.ADDONgetSetting('record_path')
        recordPath = xbmcvfs.translatePath(os.path.join(recordPathBasic))
        ###ScanFiles(c,recordPath,'L')
        conf.commit()
           
        if definition.ADDONgetSetting('record_archive_path_enable') == 'true':
            recordPathBasic = definition.ADDONgetSetting('record_archive_path')
            if recordPathBasic == '':
                recordPathBasic = definition.ADDONgetSetting('record_archive_path')
            recordArchivePath = xbmcvfs.translatePath(os.path.join(recordPathBasic))
            if archive == 'a' or archive == 'all' :
                ScanFiles(c,recordArchivePath,'A')
                conf.commit()
                ###ScanFiles(c,recordPath,'L')  ###Scan local again
        
        if definition.ADDONgetSetting('record_archiveb_path_enable') == 'true':
            recordPathBasic = definition.ADDONgetSetting('record_archiveb_path')
            if recordPathBasic == '':
                recordPathBasic = definition.ADDONgetSetting('record_archiveb_path')
            recordArchivePath = xbmcvfs.translatePath(os.path.join(recordPathBasic))
            if archive == 'b' or archive == 'all' :
                ScanFiles(c,recordArchivePath,'B')
                conf.commit()
                ###ScanFiles(c,recordPath,'L')  ###Scan local again
            
        if definition.ADDONgetSetting('record_archivef_path_enable') == 'true':
            recordPathBasic = definition.ADDONgetSetting('record_archivef_path')
            if recordPathBasic == '':
                recordPathBasic = definition.ADDONgetSetting('record_archivef_path')
            recordArchivePath = xbmcvfs.translatePath(os.path.join(recordPathBasic))
            if archive == 'f' or archive == 'all' :
                ScanFiles(c,recordArchivePath,'F')
                conf.commit()
                
        ScanFiles(c,recordPath,'L')  ###Scan local again
          
        conf.commit()
        c.close() 
        recordings.copyFileBase()
    except Exception as e:
        pass
        log('ScanRecordings ERROR: %r' % e )
        
def ScanLocalRecordings():
    try:
        log('error ScanLocalRecordings')
        conf = recordings.getFilesConnection()
        recordings.createFileTable(conf)
        c = conf.cursor()
        recordPathBasic = definition.ADDONgetSetting('record_path')
        if recordPathBasic == '':
            recordPathBasic = definition.ADDONgetSetting('record_path')
        recordPath = xbmcvfs.translatePath(os.path.join(recordPathBasic))
        ScanFiles(c,recordPath,'L')
        conf.commit()
        c.close() 
        recordings.copyFileBase()
    except Exception as e:
        pass
        log('ScanRecordings Local ERROR: %r' % e )
    
def TimeUsed(ended,now):
    try:
        log('err TimeUsed(ended= %r, now= %r)' % (ended,now))
        log('err TimeUsed(ended-now)= %r)' % (ended-now))
        timeused1 = repr(ended-now)
        if 'datetime.timedelta(seconds=' in timeused1:
            timeused = int(timeused1.replace('datetime.timedelta(seconds=','').split(',')[0])
            log('err TimeUsed(seconds)= %r)' % timeused)
        else:
            timeused = 0
            log('err TimeUsed(timeused1)= %r)' % timeused1)
        log('err timeused= %r' % timeused)
        timeusedM = int(timeused//60)
        timeusedS = (timeused - timeusedM*60)
        timeusedMS = str(timeusedM) + 'm' + str(timeusedS).zfill(2) + 's'
        log('err timeusedMS= %r' % timeusedMS)
    except Exception as e:
        pass
        timeusedMS = 'timeused ERROR %r' % e
        log('timeusedMS ERROR %r' % e)
    return timeusedMS
    
    """
    allCategories = recordings.getAllCats()          ### [categori ¤ categoritype]
    activeCategories = recordings.getActiveCats()    ### [categori ¤ categoritype]
    newCategories
    """
def limitChannels(name,categoritype,categori):
    categoriandtype = categori+'¤'+categoritype
    log('1954 error limitChannels categoriandtype= %r' % categoriandtype) 
    if categori != '':
        try:
            log('1956 error limitChannels %r' % (categori)) 
            ###log('1957 error limitChannels allCategories= %r' % (allCategories)) 
            if not categoriandtype in nowCategories :
                nowCategories.append(categoriandtype)
                log('1954 error limitChannels nowCategories.append categoriandtype= %r' % categoriandtype) 
                utils.writeDataFile('nowCategories',nowCategories)
            if not categoriandtype in allCategories :
                log('1958 error limitChannels newcategori %r' % (categori+'¤'+categoritype)) 
                if not categoriandtype in newCategories :
                    newCategories.append(categoriandtype)
                    log('1968 error limitChannels newcategori OK %r' % (newCategories)) 
                    utils.writeDataFile('newCategories',newCategories)
        except Exception as e:
            pass
            log('1963 limitChannels %r\nERROR %r' % (categori,e))    
        try:
            log('1969 error limitChannels activeCategories= %r' % (activeCategories)) 
            if len(activeCategories) == 0:
                return True     ### 2024-01-16 Add channel if no activeCategories
            if categoriandtype in activeCategories:
                return True 
            else:
                return True   ### 2024-10-04 accept all channels
                return False
        except Exception as e:
            pass
            log('1971 limitChannels %r\nERROR %r' % (categori,e))   
    return True        
 
def adjustCategoryName(category_name) :
    return category_name  ### Ignore call 2023-07-07
    try:
        category_name = category_name.replace('\u27be','->').replace('âž¾','->')   ### 2023-03-20 change unicode arrow
        if 'English series -' in category_name :
            category_name = category_name.split('English series -')[0]+'English series'  ### ignore text after English series
        category_name = ' '.join(category_name.split())  ## Remove doublespaces etc
        return category_name
    except Exception as e:
        pass
        return 'Category Name Error: %r' % e

if args[1] == 'once' or args[1] == 'hourly':    
    log('Exception args= %r' % args)
    log('Exception epg_channels()= %r' % recordings.epg_channels())
    if args[1] == 'hourly':
        log('Copy recordings database to recordings folder')
        if definition.ADDONgetSetting('copyrecordingsdatabase')=='true':
            recordings.setRecordsBase()    ### Copy recordings database to recordings folder
        log('Copy recordings database from recordings folder')
        if definition.ADDONgetSetting('getrecordingsdatabase')=='true':
            recordings.getRecordsBase()    ### Copy recordings database from recordings folder
        log('HOURLY updateAlarm(nameEPGt)')
        recordings.updateAlarm('nameEPGt')
    if args[1] == 'once':
        log('ONCE updateAlarm(nameEPG)')
        recordings.updateAlarm('nameEPG')
    log('ScanRecordings started if not already running')
    if locking.isScanLocked('EPG_update'):
        log('ScanRecordings NOT started')
    else:
        log('ScanRecordings started')
        updateiconsfromEPG()  ### 2022-05-09
        log('after updateiconsfromEPG()')
        nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        
        nowCategories = utils.readDataFile('nowCategories')   ### 2023-05-17 adjust all channels from supplier
        try:
            lennowCategories = len(nowCategories)
            log('2009 error addCategories len(newCategories)= %r' % lennowCategories)
            if lennowCategories >= 1:
                ### Handle now catagories here! 2023-05-17
                definition.ADDONsetSetting('lastEPGimportInfo','Add Categories (%r)' % lennowCategories)
                recordings.addCategories(nowCategories, 'now')
        except Exception as e:
            log('2015 addCategories now ERROR %r' % e)
            pass
        
        nowCategories = []
        utils.writeDataFile('nowCategories',nowCategories)
        
        newCategories = utils.readDataFile('newCategories')   ### 2023-05-15 look if new channels have not been handled
        try:
            lennewCategories = len(newCategories)
            log('2024 error addCategories len(newCategories)= %r' % lennewCategories)
            if lennewCategories >= 1:
                ### Handle new catagories here! 2023-05-14
                definition.ADDONsetSetting('lastEPGimportInfo','Add Categories (%r)' % lennewCategories)
                recordings.addCategories(newCategories, 'new')
        except Exception as e:
            log('2030 addCategories new ERROR %r' % e)
            pass
        
        newCategories = []
        utils.writeDataFile('newCategories',newCategories)
        
        allCategories = recordings.getAllCats()          ### [categori ¤ categoritype]
        log('1995 error allCategories= %r ' % allCategories)
        utils.writeDataFile('allCategories',allCategories)
        
        activeCategories = recordings.getActiveCats()    ### [categori ¤ categoritype]
        log('1997 error activeCategories= %r ' % activeCategories)
        utils.writeDataFile('activeCategories',activeCategories)
        lenactiveCategories = len(activeCategories)
        
        definition.ADDONsetSetting('lastEPGimportInfo','Set Krogsbell Addons to switch to ' + nowS)
        krogsbellAddons()
        nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        definition.ADDONsetSetting('lastEPGimportInfo','Scan Recordings Started ' + nowS)
        ###ScanRecordings()
        if args[1] == 'hourly':  
            ScanRecordings()
        EPGimportERRORS('')
        log('error 1711')
        ### Reset Errors
        log('error Version: '+utils.version()) 
        ### log('err VersionDate: '+utils.versiondate())
        ROQuser = definition.ADDONgetSetting('user')
        ROQpass = definition.ADDONgetSetting('pass')
        log('Test recordingprograms')
        utils.testPrograms()   ### Test recordingprograms
        log('error After Test recordingprograms')
        now= datetime.today()
        if locking.isScanLocked('EPG_update') : 
            log('No EPG update as it is still running!')
            definition.ADDONsetSetting('lastEPGimportInfo','No EPG update as it is still running!')
            notification('No EPG update as it is still running!')
        else:
            notification('EPG Import Started!')
            prevEPGimportInfoData = definition.ADDONgetSetting('lastEPGimportInfoData')
            definition.ADDONresetSetting('prevEPGimportInfoData',prevEPGimportInfoData)
            log('datetime.today()'+repr(datetime.today()))
            nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
            definition.ADDONsetSetting('lastEPGimportInfo','New EPG Import Started ' + nowS)
            locking.scanLock('EPG_update')  ### 2023-08-25
            log('error Afterlocking.scanLock')
            if definition.ADDONgetSetting('enable_record')=='true':
                RecordActive = True
            else:
                RecordActive = False
            lastEPGimport = definition.ADDONgetSetting('lastEPGimport')
            if lastEPGimport == '':
                lastEPGimport = now - timedelta(hours = 24)  ### dummy lastEPGimport
                definition.ADDONsetSetting('lastEPGimport',lastEPGimport.strftime('%Y-%m-%d %H:%M:%S using'))
            log('error definition.ADDONgetSetting(lastEPGimport)'+repr(lastEPGimport))
            
            try:
                lastEPGimport = parse_date(definition.ADDONgetSetting('lastEPGimport').split(' using',1)[0])
            except:
                pass
                lastEPGimport = parse_date(definition.ADDONgetSetting('lastEPGimport'))
            log('error datetime.datetime(definition.ADDONgetSetting(lastEPGimport))' + repr(lastEPGimport))   
            
            cEPG = recordings.getConnection()
            recordings.createEPGchannelsTable(cEPG)
            recordings.createEPGProgramsTable(cEPG)
            c = cEPG.cursor()
            try:
                c.execute("PRAGMA journal_mode = WAL")  ### 2018-01-07 Try to speed up on Windows (1700 sec down to 700 sec)
            except Exception as e:
                pass
                log('PRAGMA journal_mode = WAL ERROR %r' % e)
            KrogsbellAddOns = definition.getKrogsbellAddOns()
            log('error KrogsbellAddOns= %r' % KrogsbellAddOns)
            for kaddon in KrogsbellAddOns:
                log('kaddon= %r' % kaddon)
                try:
                    kaddonID = kaddon.split('.')[2][:3].upper()
                    taddonID = ADDONid.split('.')[2][:3].upper()
                except Exception as e:
                    pass
                    EpgError = 'Error in getting AddOn ID\n' + repr(e) 
                    kaddonID = ''
                    taddonID = ''
                log('kaddonID= %r' % kaddonID)
                log('taddonID= %r' % taddonID)
                if kaddonID != '' and kaddonID != taddonID:
                    try:
                        NTVchannels = xbmcvfs.translatePath( xbmcaddon.Addon(id=kaddon).getAddonInfo('profile') + 'channels.csv')
                        log('NTVchannels= %r' % NTVchannels)
                    except Exception as e:
                        pass
                        EpgError = 'Error in getting ' + kaddonID + ' Channels\n' + repr(e)
                        log(EpgError)
                        NTVchannels = ''
                    try:  ### Get the set webport
                        webport = utils.getGuiSetting('webserverport','8080')
                    except:
                        pass
                        webport = '8080'
                    
                    if os.path.isfile(NTVchannels):
                        log('Use ChannelFile in: ' + repr(NTVchannels))
                        nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                        definition.ADDONsetSetting('lastEPGimportInfo','Import ' + kaddonID + ' @ ' + nowS)
                        ended = datetime.today()
                        notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ###+' Src= ' + kaddonID) 
                        definition.ADDONsetSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))### +' Src= ' + kaddonID)
                        for line in open(NTVchannels):  # opened in text-mode; all EOLs are converted to '\n'
                            ###log('Line: ' + repr(i) + ' - ' + line)
                            line = line.rstrip('\n').rstrip('\r')
                            if not line == '' and not line[:2] == '# ' :   # Ignore empty lines and comment lines
                                channels += 1
                                line=line.split(',')
                                stream_id = kaddonID + line[0]
                                name = line[1] + ' (' + kaddonID + ')'
                                url = 'http://127.0.0.1:' + webport + '/jsonrpc?request={"jsonrpc":"2.0","method":"Addons.ExecuteAddon","params":{"wait":false,"addonid":"' +kaddon + '","params":["url=url","cat=' + line[0] + '","mode=210","name=' + line[1] + '","recordname='+ADDONid+'"]},"id":200}'
                                epg_channel_id = line[2]
                                stream_icon = line[3]
                                ###EPGgenerator = 'NTV Available Channels'
                                EPGgenerator = ADDONid +' available_channels'
                                displaydescription = ''
                                ChannelFav = recordings.getChannelFav(c,stream_id)
                                ChannelEpg = recordings.getChannelEpgid(c,stream_id)
                                if ChannelEpg != '':
                                    epg_channel_id = ChannelEpg
                                name = ' '.join(name.split())  ## Remove doublespaces etc
                                log('1779 errXX errXX addEPGChannel(\n  c= %r, \n  stream_id= %r, \n  name= %r)' % (c, stream_id, name))
                                recordings.addEPGChannel(c, stream_id, name, url, stream_icon, epg_channel_id, EPGgenerator, epg_channel=epg_channel_id, description=displaydescription)
                                recordings.setChannelFav(c,stream_id,ChannelFav)
                                if ChannelEpg != '':
                                    recordings.setChannelEpgid(c,stream_id,ChannelEpg)
                                    recordings.setChannelIcon(c,stream_id,recordings.getIconfromEPG(ChannelEpg))
            if definition.ADDONgetSetting('unlim_api').lower() == 'true':
                KrogsbellAddOns = definition.getNTVAddOns()    ###  NTV addons like unlim.tv
                log('NTVAddOns= %r' % KrogsbellAddOns)
                streamtype = definition.ADDONgetSetting('streamtype').replace('0','m3u8').replace('1','ts').replace('2','rtmp')
                EPGgenerator = ADDONid +' available_channels'
                for kaddon in KrogsbellAddOns:
                    log('kaddon= %r' % kaddon)
                    try:
                        kaddonID = kaddon.split('.')[2][:3].upper()
                        taddonID = ADDONid.split('.')[2][:3].upper()
                    except Exception as e:
                        pass
                        EpgError = 'Error in getting AddOn ID\n' + repr(e) 
                        kaddonID = ''
                        taddonID = ''
                    log('kaddonID= %r' % kaddonID)
                    log('taddonID= %r' % taddonID)
                    if kaddonID != '' and kaddonID != taddonID:
                        try:
                            NTVchannels = xbmcvfs.translatePath( xbmcaddon.Addon(id=kaddon).getAddonInfo('profile') + 'storage/channels.json')
                            log('NTVchannels= %r' % NTVchannels)
                            NTVwww = 'https://www.touchsportstv.com' ### To be fetched from addon... 2019-10-09
                            log('NTVwww= %r' % NTVwww)
                        except Exception as e:
                            pass
                            EpgError = 'Error in getting ' + kaddonID + ' Channels\n' + repr(e)
                            log(EpgError)
                            NTVchannels = ''
                            NTVwww = ''
                        
                        if os.path.isfile(NTVchannels):
                            log('Use ChannelFile in: ' + repr(NTVchannels))
                            nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                            definition.ADDONsetSetting('lastEPGimportInfo','Import ' + kaddonID + ' @ ' + nowS)
                            ended = datetime.today()
                            notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))###+' Src= ' + kaddonID) 
                            definition.ADDONsetSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs)) ###+' Src= ' + kaddonID)
                            try:
                                file = io.open(NTVchannels,'r', encoding="utf-8")   ###io.open(infile, 'r', encoding="utf-8")
                                datapanel = file.read()
                                ###log(datapanel)
                                file.close()
                            except Exception as e:
                                pass
                                EpgError = 'Error in getting '+ NTVchannels + ' \n' + repr(e)
                                EPGimportERRORS(EpgError)
                                log('1862')
                                log(EpgError)
                                datapanel = ''
                            try:
                                datapanel = json.loads(datapanel)
                                descrpanel = 'message= %r \nStatus= %r \nExpire= %r' %(datapanel['message'],datapanel['status'],recordings.parseDate(datapanel['timestamp']).strftime('%Y-%m-%d %H:%M'))
                                log('Start datapanel' + descrpanel)
                                added = datapanel['timestamp']
                                for chan in datapanel['body']:
                                    log('name= %r, country= %r, xmltv_id= %r, id= %r dvr= %r' % (chan['name'],chan['country'],chan['xmltv_id'],chan['id'],chan['dvr']))
                                    stream_id = kaddonID + str(notnone(chan['id']))
                                    log('stream_id= %r' % stream_id)
                                    name = (notnone(chan['name']) + ' ' + kaddonID +'-'+ notnone(chan['country'])).strip()
                                    log('name= %r' % name)
                                    category_name = notnone(chan['category_name'])
                                    log('2297 error category_name= %r' % category_name)
                                    stream_icon = NTVwww + '/assets/img/channels/' + notnone(chan['logo']) 
                                    log('stream_icon= %r' % stream_icon)
                                    epg_channel_id = notnone(chan['xmltv_id'])
                                    log('epg_channel_id= %r' % epg_channel_id)
                                    tv_archive_duration = notnone(chan['dvr'])
                                    log('tv_archive_duration= %r' % tv_archive_duration)
                                    if chan['health'] != 1:   ### broken = '[COLOR blue] Broken[/COLOR]'
                                        tv_archive_duration = -1
                                    url = kaddon
                                    log('1. url= %r' % url)
                                    ChannelFav = recordings.getChannelFav(c,stream_id)
                                    ChannelEpg = recordings.getChannelEpgid(c,stream_id)
                                    if ChannelEpg != '':
                                        epg_channel_id = ChannelEpg
                                    displaydescription = 'Category: ' + category_name
                                    log('recordings.addEPGChannel(c, stream_id= %r, name= %r, url= %r, stream_icon= %r, epg_channel_id= %r, EPGgenerator= %r,  description= %r)'% (stream_id, name, url, stream_icon, epg_channel_id, EPGgenerator, displaydescription))
                                    name = ' '.join(name.split())  ## Remove doublespaces etc
                                    log('1862 errXX addEPGChannel(\n  c= %r, \n  stream_id= %r, \n  name= %r)' % (c, stream_id, name))
                                    recordings.addEPGChannel(c, stream_id, name, url, stream_icon, epg_channel_id, EPGgenerator, epg_channel=epg_channel_id, description=displaydescription)
                                    recordings.setChannelCatchup(c,stream_id,tv_archive_duration)
                                    recordings.setChannelFav(c,stream_id,ChannelFav)
                                    if ChannelEpg != '':
                                        recordings.setChannelEpgid(c,stream_id,ChannelEpg)
                                        recordings.setChannelIcon(c,stream_id,recordings.getIconfromEPG(ChannelEpg))
                                    recordings.setChannelAdded(c,stream_id,added)
                                    channels += 1
                            except Exception as e:
                                pass
                                EpgError = 'Error in getting datapanel for '+ NTVchannels + ' \n' + repr(e)
                                EPGimportERRORS(EpgError)
                                log('1907')
                                log(EpgError)
                                datapanel = ''
                            
            channelinterval = utils.intADDONgetSetting('channelinterval',maxvalue=100)
            programinterval = utils.intADDONgetSetting('programinterval',maxvalue=1000)
            ###if (lastEPGimport-now).total_seconds()/3600 < -12:
            ### >>>>>> ROQ TV PANEL
            ROQTVusername = definition.ADDONgetSetting('user')
            if ROQTVusername.lower() == 'none' or definition.ADDONgetSetting('panel_api') == 'false':
                definition.ADDONresetSetting('expiredate',ROQTVusername)
                definition.ADDONresetSetting('concurrentstreams',ROQTVusername)
                EPGgeneratorName = 'No User'
            else:
                ###linkpanel = definition.getBASEURL() + definition.getCOMMAND() + 'username=' +ROQuser+ '&password=' +ROQpass + definition.getCOMMANDEND()
                linkpanel = definition.getBASEURL() + '/panel_api.php?username=' +definition.ADDONgetSetting('user')+ '&password=' +definition.ADDONgetSetting('pass')
                EPGgeneratorName = 'panel_api'
                log('enigma2 panel_api linkpanel= %r' % linkpanel)
                ended = datetime.today()
                notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ###+' Src= ' + EPGgeneratorName) 
                
                nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                definition.ADDONsetSetting('lastEPGimportInfo','Import ' + EPGgeneratorName + ' @ ' + nowS)
                definition.ADDONsetSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs)) ###+' Src= ' + EPGgeneratorName)

                try:
                    ChannelFile = os.path.join(datapath,ADDONid) + '.info'
                    datapanel = utils.readlink(linkpanel,ChannelFile,module)
                except Exception as e:
                    pass
                    EpgError = 'Error in getting '+ linkpanel + ' \n' + repr(e)
                    EPGimportERRORS(EpgError)
                    log(EpgError)
                    notification(EpgError)
                    datapanel = ''

                try:
                    log('HTTP datapanel= %r' % datapanel)
                    datapanel = json.loads(datapanel)
                    log('dict datapanel= %r' % datapanel)
                    datapanel1 = datapanel['user_info']
                    descrpanel = 'Username= %s \nStatus= %s \nExpire= %s \nMax connections= %s' %(datapanel1['username'],datapanel1['status'],recordings.parseDate(datapanel1['exp_date']).strftime('%Y-%m-%d %H:%M'),datapanel1['max_connections'])
                    log('Start datapanel: %r' % descrpanel)
                    ### expiredate/concurrentstreams
                    forever = definition.ADDONgetSetting('forever')    
                    if forever == 'true':
                        expiredate = 'none'
                        remainingdaysS = ''
                        log('expiredate= %r' % expiredate)
                    else:
                        expiredate = recordings.parseDate(datapanel1['exp_date'])
                        expiredate = expiredate.strftime('%Y-%m-%d %H:%M')
                    definition.ADDONresetSetting('expiredate',expiredate)     
                    definition.ADDONresetSetting('concurrentstreams',str(datapanel1['max_connections']))
                    datapanelS = datapanel['server_info']
                    definition.ADDONresetSetting('server_info_url',str(datapanelS['url']))
                    definition.ADDONresetSetting('server_info_port',str(datapanelS['port']))
                    try:
                        definition.ADDONresetSetting('server_info_https_port',str(datapanelS['https_port']))
                    except Exception as e:
                        pass
                        definition.ADDONresetSetting('server_info_https_port','')
                        log('Error getting https_port: %r'% e)
                    try:
                        definition.ADDONresetSetting('server_info_protocol',str(datapanelS['server_protocol']))
                    except Exception as e:
                        pass
                        definition.ADDONsetSetting('server_info_protocol','http')
                        log('Error getting https_port: %r'% e)
                except Exception as e:
                    pass
                    EpgError = 'Error in getting '+ ADDONid + " 1-info! Don't use VPN or check your User ID\n" + repr(e)
                    EPGimportERRORS(EpgError)
                    log('1973')
                    notification(EpgError)
                    datapanel = []

                try:
                    try:
                        log('datapanel = %r' % datapanel)
                        log('datapanel[categories] = %r' % datapanel['categories'])
                        log('datapanel[categories][movie] = %r' % datapanel['categories']['movie'])
                        log('datapanel[categories][live] = %r' % datapanel['categories']['live'])
                        log('datapanel[categories][series] = %r' % datapanel['categories']['series'])
                        log('datapanel[categories][radio] = %r' % datapanel['categories']['radio'])
                    except Exception as e:
                        pass
                        log('datapanel error = %r' % e)
                    for types in datapanel['categories']:
                        log('datapanel category types = %r' % types)
                        log('datapanel[categories][types] = %r' % datapanel['categories'][types])
                        for category in datapanel['categories'][types]:
                            log('datapanel category = %r' % category)
                            category_id = notnone(category['category_id'])
                            log('datapanel category_id = %r' % category_id)
                            category_name = notnone(category['category_name'])
                            parent_id = notnone(category['parent_id'])
                            log('datapanel category= %r, %r, %r)' % (category_id,category_name,parent_id))
                            ###limitChannels(name,categoritype,categori)
                            limitChannels(category_id,types,category_name)
                except Exception as e:
                    pass
                    EpgError = 'Error in datapanel[categories] '+ ChannelFile + ' \n' + repr(e)
                    EPGimportERRORS(EpgError)
                    log(EpgError)
                """
                "available_channels":{
                "281":{
                "num":1,
                "name":"UK: BBC ONE HD",
                "stream_type":"live",
                "type_name":"Live Streams",
                "stream_id":"281",
                "stream_icon":"https://upload.wikimedia.org/wikipedia/commons/1/1a/BBC_One_2002.png",
                "epg_channel_id":"BBC One London",
                "added":"1487332455",
                "category_name":"UK: ENTERTAINMENT",
                "category_id":"14",
                "series_no":null,
                "live":"1",
                "container_extension":null,
                "custom_sid":":0:19:22e3:80d:2:11a0000:0:0:0:",
                "tv_archive":1,
                "direct_source":"",
                "tv_archive_duration":"7"},
                """
                streamtype = definition.ADDONgetSetting('streamtype').replace('0','m3u8').replace('1','ts').replace('2','rtmp')
                EPGgenerator = ADDONid +' available_channels'
                try:
                    for chan in datapanel['available_channels']:
                        if (channels % channelinterval == 0 and channels != 0) or (programs % programinterval == 0 and programs != 0) or channels <= channelinterval/10:
                            ended = datetime.today()
                            notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))  ###+' Src= ' + EPGgeneratorName)
                            nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                            definition.ADDONsetSetting('lastEPGimportInfo','Import ' + EPGgeneratorName + ' @ ' + nowS)
                            definition.ADDONsetSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))

                        description = ''
                        stream_id = notnone(datapanel['available_channels'][chan]['stream_id'])
                        name = notnone(datapanel['available_channels'][chan]['name'])
                        category_name = notnone(datapanel['available_channels'][chan]['category_name'])
                        category_name = adjustCategoryName(category_name)
                        stream_icon = notnone(datapanel['available_channels'][chan]['stream_icon'])
                        epg_channel_id = notnone(datapanel['available_channels'][chan]['epg_channel_id'])
                        tv_archive = notnone(datapanel['available_channels'][chan]['tv_archive'])
                        tv_archive_duration = notnone(datapanel['available_channels'][chan]['tv_archive_duration'])
                        stream_type = notnone(datapanel['available_channels'][chan]['stream_type'])
                        container_extension = notnone(datapanel['available_channels'][chan]['container_extension'])

                        if stream_type == '' or stream_type == definition.getDefaultStreamType():
                            stream_typefiller = ''
                            container_extensionfiller = ''
                        else:
                            stream_typefiller = stream_type + '/'
                            if container_extension == '':
                                container_extensionfiller = ''
                            else:
                                container_extensionfiller = '.' + container_extension
                        added = notnone(datapanel['available_channels'][chan]['added'])   
                        ###if limitChannels(name+'vod',stream_type):  ### 2023-03-18 test
                        if limitChannels(name+category_name,stream_type,category_name):  ### 2023-05-07 test
                            try:  
                                url = definition.getBASEURL() + '/'+stream_typefiller+ROQuser+'/'+ROQpass+'/'+stream_id+container_extensionfiller
                            except Exception as e:
                                pass
                                EpgError = 'Error in live streamtype '+ ChannelFile + ' \n' + repr(e)
                                log('error stream_type == live?? url= %r' % url)
                                ### EPGimportERRORS(EpgError)
                                log(EpgError)
                                url = 'url'  ### Dummy
                            log('url= %r' % url)
                            
                            ChannelFav = recordings.getChannelFav(c,stream_id)
                            ChannelEpg = recordings.getChannelEpgid(c,stream_id)
                            if ChannelEpg != '':
                                epg_channel_id = ChannelEpg
                            displaydescription = description
                            if category_name != '' and description != '':
                                displaydescription = 'Category: ' + category_name + '\n\nDescription:\n' + description
                            else:
                                displaydescription = category_name + displaydescription
                            if stream_type.lower() == 'live' or definition.ADDONgetSetting('notonlylive').lower() == 'true' :
                                if definition.ADDONgetSetting('titlewithcategory') == 'true' :
                                    log('error 2511 category_name= %r' % category_name)
                                    if category_name != '':
                                        category_name = ' [' + category_name + ']' 
                                else:
                                    category_name = ''
                                log('error 2515 category_name= %r' % category_name)
                                if category_name != '':
                                    category_name_marker = '[' + category_name + ']'
                                    if not category_name_marker in name :
                                        name = name + ' ' + category_name_marker  ### 2023-04-20
                                name = ' '.join(name.split())  ## Remove doublespaces etc
                                log('2021 errXX addEPGChannel(\n  c= %r, \n  stream_id= %r, \n  name= %r)' % (c, stream_id, name))
                                recordings.addEPGChannel(c, stream_id, name, url, stream_icon, epg_channel_id, EPGgenerator, epg_channel=epg_channel_id, description=displaydescription)  ### 2018-02-13
                                
                                recordings.setChannelCatchup(c,stream_id,tv_archive_duration)  ### 2018-06-08 catchup flag is number of days catchup
                                
                                recordings.setChannelFav(c,stream_id,ChannelFav)
                                if ChannelEpg != '':
                                    recordings.setChannelEpgid(c,stream_id,ChannelEpg)
                                    recordings.setChannelIcon(c,stream_id,recordings.getIconfromEPG(ChannelEpg))
                                recordings.setChannelAdded(c,stream_id,added)
                                channels += 1
                                
                except Exception as e:
                    pass
                    EpgError = 'Error in datapanel[available_channels] '+ ChannelFile + ' \n' + repr(e)
                    EPGimportERRORS(EpgError)
                    log(EpgError)
                
            cEPG.commit()
            ended = datetime.today()
            notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ###+' Src= ' + EPGgeneratorName) 
            nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
            definition.ADDONsetSetting('lastEPGimportInfo','Import ' + EPGgeneratorName + ' @ ' + nowS)
            definition.ADDONsetSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ### +' Src= ' + EPGgeneratorName)
            log('EPG Import at ' + str(int((ended-now).total_seconds())) +' sec Channels= ' + repr(channels))    
            log('err EPG Import at ' + TimeUsed(ended,now) + ' Channels= ' + repr(channels)) 
            log('err useDirectChannels# %r' % 1)
            channelsM3U= []
            ###categories= []
            useDirectChannels = definition.ADDONgetSetting('useDirectChannels')
            log('useDirectChannels= %r' % useDirectChannels)
            log('useDirectChannels# %r' % 2)
            channelsM3U= []
            ChannelFiles = []
            ChannelBasicHTTP = definition.getBASEURL() + '/get.php?username=' +definition.ADDONgetSetting('user')+ '&password=' +definition.ADDONgetSetting('pass')+'&type=m3u_plus&output=ts'
            log('ChannelBasicHTTP %r' % (ChannelBasicHTTP))
            log('definition.ADDONgetSetting(useDirectChannelsFile)= %r' % definition.ADDONgetSetting('useDirectChannelsFile'))
            log('definition.ADDONgetSetting(usedirectchannelsfromextraXMLTVfileHTTP)= %r' % definition.ADDONgetSetting('usedirectchannelsfromextraXMLTVfileHTTP'))
            ###if definition.ADDONgetSetting('useDirectChannelsFile') == 'true':
            if definition.ADDONgetSetting('usedirectchannelsfromextraXMLTVfileHTTP') == 'true':
                try:
                    ###ChannelFileBasicHTTPfile = os.path.join(datapath,'directchannelsbasichttp.m3u')
                    ChannelFileBasicHTTPfile = ''   ###TEST 2025-07-16
                    log('1 ChannelFileBasicHTTPfile %r' % (ChannelFileBasicHTTPfile))
                    if definition.ADDONgetSetting('AcceptSSLErrors') == 'true' and ChannelBasicHTTP[0:5].lower() == 'https':
                        import ssl
                        # This restores the same behavior as before.
                        context = ssl._create_unverified_context()
                        BasicHTTP = urlopen(ChannelBasicHTTP, context=context)
                    else:
                        BasicHTTP = urlopen(ChannelBasicHTTP)
                    utils.makeOldFile(ChannelFileBasicHTTPfile)
                    with open(ChannelFileBasicHTTPfile,'wb') as output:
                        output.write(BasicHTTP.read())
                    log('2 ChannelFileBasicHTTPfile %r' % (ChannelFileBasicHTTPfile))
                except Exception as e:
                    pass
                    log('ChannelFileBasicHTTPfile %r\nERROR: %r' % (ChannelFileBasicHTTPfile,e))
                    locking.deleteLockFile(ChannelFileBasicHTTPfile)
                ChannelFile = ChannelFileBasicHTTPfile
                if os.path.isfile(ChannelFile):    ### If directchannelsfromextraXMLTVfileHTTP exist in Program directory use it
                    ChannelFiles.append(ChannelFile) 
            
            ChannelFileExtraHTTP = definition.ADDONgetSetting('directchannelsfromextraXMLTVfileHTTP')
            log('ChannelFileExtraHTTP %r' % (ChannelFileExtraHTTP))
            if definition.ADDONgetSetting('usedirectchannelsfromextraXMLTVfileHTTP') == 'true':
                try:
                    ChannelFileExtraHTTPfile = os.path.join(datapath,'directchannelshttp.m3u')
                    log('1 ChannelFileExtraHTTPfile %r' % (ChannelFileExtraHTTPfile))
                    if definition.ADDONgetSetting('AcceptSSLErrors') == 'true' and ChannelFileExtraHTTP[0:5].lower() == 'https':
                        import ssl
                        # This restores the same behavior as before.
                        context = ssl._create_unverified_context()
                        ExtraHTTP = urlopen(ChannelFileExtraHTTP, context=context)
                    else:
                        ExtraHTTP = urlopen(ChannelFileExtraHTTP)
                    utils.makeOldFile(ChannelFileExtraHTTPfile)
                    with open(ChannelFileExtraHTTPfile,'wb') as output:
                        output.write(ExtraHTTP.read())
                    log('2 ChannelFileExtraHTTPfile %r' % (ChannelFileExtraHTTPfile))
                except Exception as e:
                    pass
                    log('ChannelFileExtraHTTPfile %r\nERROR: %r' % (ChannelFileExtraHTTPfile,e))
                    locking.deleteLockFile(ChannelFileExtraHTTPfile)
                ChannelFile = ChannelFileExtraHTTPfile
                if os.path.isfile(ChannelFile):    ### If directchannelsfromextraXMLTVfileHTTP exist in Program directory use it
                    ChannelFiles.append(ChannelFile) 
                    
            ### Fixed extra channel
            #ChannelFileExtra = os.path.join('Recordings','IPTV_Favorites.m3u')
            #ChannelFileExtra = definition.ADDONsetSetting('directchannelsfromextraXMLTVfile',ChannelFileExtra)
            
            ChannelFileExtra = definition.ADDONgetSetting('directchannelsfromextraXMLTVfile')
            if ChannelFileExtra == '':
                ###Recordings = xbmcvfs.translatePath(definition.FileManagerPath('Recordings'))
                ###ChannelFileExtra = os.path.join('Recordings','IPTV_Favorites.m3u')
                ChannelFileExtra = xbmcvfs.translatePath(os.path.join(definition.FileManagerPath('Recordings'),'favorites.m3u'))
                definition.ADDONresetSetting('directchannelsfromextraXMLTVfile',ChannelFileExtra)
            ###if not os.path.isfile(ChannelFileExtra):
            ###    definition.ADDONresetSetting('directchannelsfromextraXMLTVfile','')
            ###    ChannelFileExtra = ''
            ###ChannelFileExtra = definition.ADDONgetSetting('directchannelsfromextraXMLTVfile') 
            master = 'extraxmltvfile.m3u'
            infile = os.path.join(datapath,master)
            log('Exception Copy extraxmltvfile.m3u %r to %r' %  (ChannelFileExtra,infile))
            if xbmcvfs.exists(ChannelFileExtra):
                log('ChannelFileExtra exists= %r' % ChannelFileExtra)
                copyOK = xbmcvfs.copy(ChannelFileExtra, infile)
                if not copyOK:
                    log('2795 Exception Copy of %r failed - Error: %r' %  (infile,copyOK))
            else:
                log('Exception ChannelFileExtra do not exists try copy anyhow= %r' % ChannelFileExtra)   ### 2025-07-24
                copyOK = xbmcvfs.copy(ChannelFileExtra, infile)
                if not copyOK:
                    log('2800 Exception Copy of %r failed - Error: %r' %  (infile,copyOK))
            ChannelFileExtra = infile
            log('Exception extraxmltvfile.m3u= %r' % ChannelFileExtra)
            if os.path.isfile(ChannelFileExtra):   
                if definition.ADDONgetSetting('useDirectChannelsFile') == 'true' :
                    ChannelFiles.append(ChannelFileExtra) 
                    log('Exception appended extraxmltvfile.m3u= %r' % ChannelFileExtra)
            """
            ### extra file in datafolder
            ChannelFileExtra = os.path.join(datapath,'PST_FavoritesLocal.m3u')
            log('Exception directchannelsfromextraXMLTVfileLocal= %r' % ChannelFileExtra)
            definition.ADDONsetSetting('directchannelsfromextraXMLTVfillocal',ChannelFileExtra)
            ###if not os.path.isfile(ChannelFileExtra):
            ###    definition.ADDONresetSetting('directchannelsfromextraXMLTVfilelocal','')
            ###    ChannelFileExtra = ''
            ###ChannelFile = definition.ADDONgetSetting('directchannelsfromextraXMLTVfilelocal') 
            master = 'extraxmltvfilelocal.m3u'
            infile = os.path.join(datapath,master)
            log('Exception Copy PST_Favorites.m3u %r to %r' %  (ChannelFileExtra,infile))
            if xbmcvfs.exists(ChannelFileExtra):
                log('ChannelFileExtra exists= %r' % ChannelFile)
                copyOK = xbmcvfs.copy(ChannelFileExtra, infile)
                if not copyOK:
                    log('2823 Exception Copy of %r failed - Error: %r' %  (infile,copyOK))
            else:
                log('Exception ChannelFile do not exists copy anyhow= %r' % ChannelFileExtra)   ### 2025-07-24
                copyOK = xbmcvfs.copy(ChannelFileExtra, infile)
                if not copyOK:
                    log('2828 Exception Copy of %r failed - Error: %r' %  (infile,copyOK))
            ChannelFile = infile
            log('Exception extraxmltvfilelocal.m3u= %r' % ChannelFile)
            if os.path.isfile(ChannelFile):    ### If directchannelsfromextraXMLTVfile exist in Program directory use it
                if definition.ADDONgetSetting('useDirectChannelsFilelocal') == 'true' :
                    ChannelFiles.append(ChannelFile) 
                    log('Exception appended extraxmltvfilelocal.m3u= %r' % ChannelFile)
            """        
            
            if useDirectChannels == 'true':
                log('useDirectChannels# %r' % 3)
                
                ChannelFile = os.path.join(progpath,'directchannels.m3u.txt')
                if os.path.isfile(ChannelFile):    ### If ChannelFile exist in Program directory use it
                    ChannelFiles.append(ChannelFile)
                    ###if ChannelFileExtra == ChannelFile:
                    ###    definition.ADDONresetSetting('directchannelsfromextraXMLTVfile','')
                    
                ChannelFile = os.path.join(datapath,'directchannels.m3u')
                if os.path.isfile(ChannelFile):  ### Use updated directchannels if available
                    ChannelFiles.append(ChannelFile)
                    ###if ChannelFileExtra == ChannelFile:
                    ###    definition.ADDONresetSetting('directchannelsfromextraXMLTVfile','')
                
            log('ChannelFiles: %r' % ChannelFiles)
            j = -1
            for ChannelFile in ChannelFiles:
                log('2127 err ChannelFile= %r' % ChannelFile)
                j += 1
                i = 0
                if os.path.isfile(ChannelFile): 
                    log('err useDirectChannels# %r' % 4)
                    log('err Use extra ChannelFile in: ' + repr(ChannelFile))
                    nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                    definition.ADDONsetSetting('lastEPGimportInfo','Start import of m3u direct channels '+ChannelFile + ' ' + nowS)
                    ended = datetime.today()
                    notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ###+' Src= Import of m3u direct channels') 
                    definition.ADDONsetSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ###+' Src= Import of m3u direct channels')
                    """
                    #EXTM3U
                    #PLAYLIST:FHC-BOXTV
                    #EXTINF:-1,BBC One XXX
                    https://fhc-boxtv.net/api/m3u/stream/0c9b93cbe66291181d414f24fd2147536ab7990091c0fcf2ee4dd6e41a44d8.m3u8
                    #EXTINF:-1,5USA
                    https://fhc-boxtv.net/api/m3u/stream/e56544595651fb8d318aa5aa87bda41554ee4feca5296415b13557db813e4c.m3u8
                    
                    #EXTINF:-1 tvg-name="Better Call Saul S04E09" tvg-logo="http://redmonkeytv.com:8080/images/1CX9HZ1TpsR6jq_dGSnHkF7DaaYG-JnaH_5zbvTz1M5mB5g6BUIWNSoocDNYisyLtMOpncXi3-DOEuOxq3yZRaBiuVOvA5TvFoijBFCdZjE.jpg" group-title="NORDIC Series",Better Call Saul S04E09
    http://redmonkeytv.com:8080/series/mulehouseote/cWSZUcYNY2/151725.mp4
                    """
                    playlist = '<none>'
                    tvgid=''
                    tvgname=''
                    tvgnamecat = ''
                    tvglogo=''
                    grouptitle=playlist
                    name=''
                    log('error ChannelFile= %r ' % ChannelFile)  ### 2023-01-21
                    ChannelFileText = open(ChannelFile, 'rb')
                    log('error ChannelFileText= %r ' % ChannelFileText)  ### 2023-01-21
                    for line in utils.openRead(ChannelFile):  # opened in text-mode; all EOLs are converted to '\n'
                        log('error Line: ' + repr(i) + ' - ' + line) 
                        line = line.rstrip('\n').rstrip('\r').strip()
                        if not line == '' and not line[:2] == '# ' :   # Ignore empty lines and comment lines
                            log('error Line: %r' % 1) 
                            if '#EXTM3U' in line :
                                i += 1
                                log('error Skip EXTM3U in line: ' + repr(i))
                            elif '#PLAYLIST:' in line :
                                i += 1
                                try:
                                    playlist = line.split('#PLAYLIST:')[1]
                                except Exception as e:
                                    pass
                                    playlist = 'ERROR in playlist: %r' % e 
                                log('error playlist = %r' % playlist)
                            elif '#EXTINF' in line :
                                i += 1
                                log('error 2152 err Line:i %r' % i)
                                tvgid=''
                                tvgname=''
                                tvgnamecat = ''
                                tvglogo=''
                                grouptitle=playlist
                                name=''
                                try:
                                    tvgid=line.split('tvg-id="',1)[1].split('"',1)[0]
                                except Exception as e:
                                    pass
                                    tvgid=''
                                try:
                                    tvgname=line.split('tvg-name="',1)[1].split('"',1)[0]
                                except Exception as e:
                                    pass
                                    tvgname=''
                                try:
                                    tvglogo=line.split('tvg-logo="',1)[1].split('"',1)[0]
                                except Exception as e:
                                    pass
                                    tvglogo=''
                                try:
                                    grouptitle=line.split('group-title="',1)[1].split('"',1)[0]
                                except Exception as e:
                                    pass
                                    grouptitle=playlist
                                grouptitle=adjustCategoryName(grouptitle)
                                try:
                                    name=line.split(',')[-1]
                                    grouptitleS=grouptitle.split('SEASON')[0].strip()
                                    if grouptitleS != '':   ### 2023-07-04
                                        grouptitle = grouptitleS
                                except Exception as e:
                                    pass
                                    name='name ERROR: %r' % e
                                    log('2604 error name= %r' % name)
                                try:
                                    if ':' in tvgname:
                                        tvgnamecat=tvgname.split(':')[0].strip()
                                except:
                                    pass
                                    tvgnamecat= ''
                            else:
                                i += 1
                                log('2194 error Line: else i %r' % i)
                                log('2195 error Line: %r' % line)
                                
                                ### https://drlive01hls.akamaized.net/hls/live-ull/2014185/drlive01/master.m3u8
                                ### 2022-04-23
                                try:
                                    cats=line.split('live-ull/')[1].split('/')[0]
                                except:
                                    pass
                                
                                    try:
                                        cats=line.split('live/')[1].split('/')[0]
                                    except:
                                        pass
                                        try:
                                            cats=line.split('tv2danmark/')[1].split('/')[0]
                                        except:
                                            pass
                                            try:
                                                cats=line.split('i/')[1].split('/')[0]
                                            except:
                                                pass
                                                try:
                                                    if '/' in line.split('.')[-1]:   ### 2018-12-01 Selected stream type if none
                                                        streamtype = definition.ADDONgetSetting('streamtype').replace('0','m3u8').replace('1','ts').replace('2','rtmp')
                                                        line1 = line + '.' + streamtype 
                                                    else:
                                                        line1 = line ### 2018-12-01 Selected stream type if none
                                                    cats=line1.split('.')[-2].split('/')[-1]
                                                except Exception as e:
                                                    pass
                                                    EpgError = 'errX Error in m3u file: '+ repr(ChannelFile) + ' @ line= '+line+'\n' + repr(e)
                                                    EPGimportERRORS(EpgError)
                                                    notification(EpgError)
                                                    cats=''
                                catsinlink=''
                                if 'series' in line :
                                    log('2650 error with series line= %r' % line)
                                    catsinlink='! series'
                                if not 'movie' in line and not 'series' and not '[multi-subs]' in line:
                                    catsinlink='! live'
                                
                                if '_' in cats:
                                    if not 'bbc_' in cats:   ### 2017-08-28
                                        if not 'cbeebies_' in cats:
                                            if not cats[:1] == '_':  ### 2018-07-07
                                                log('errX cats no_= %r' % cats)
                                                cats = cats.split('_')[0]
                                                log('errX cats no_= %r' % cats)
                                ###grouptitle
                                if cats == 'm3u':
                                    cats = name.strip()
                                
                                if j == 0:
                                    appendData = [name.strip(),line,grouptitle,tvglogo,tvgname,tvgid,cats,catsinlink]
                                else:
                                    appendData = [name.strip()+' (D'+str(j)+')',line,grouptitle,tvglogo,tvgname,tvgid,'DIR'+str(j)+cats,catsinlink]
                                log('0 channelsM3U.append: %r' % appendData)   
                                if cats != '' and name.strip() != '' :
                                    log('1 channelsM3U.append: %r' % appendData)  
                                    channelsM3U.append(appendData)    
            
            log('Exception channelsM3U= %r' % channelsM3U)  
            j = 1
            for cat in channelsM3U:
                log('Exception Use channel in channelsM3U: %r' % cat)
                if cat[0] != '':
                    cat0 = cat[0]
                else:
                    cat0 = str(j)
                description = ''
                if cat[6] != '':
                    description += ' \n\rcat= ' + cat[6]
                if cat[5] != '':
                    description += ' \n\rtvg-id= ' + cat[5]
                if cat[4] != '':
                    description += ' \n\rtvg-name= '+cat[4]
                if cat[2] != '':
                    description += ' \n\rgroup-title= ' + cat[2] 
                if cat[7] != '':
                    description += ' \n\rcatsinlink= '+cat[7]
                if cat[1] != '' and definition.ADDONgetSetting('ShowLink') == 'true':
                    description += ' \n\rlink= '+cat[1].replace('/','/ ')
                log('errorX cat in channelsM3U name= %r' % cat0+' '+cat[2])
                ###if ' (D' in cat[0] or '/live/' in cat[1].lower() or definition.ADDONgetSetting('notonlylive').lower() == 'true' or 'fhc-boxtv.net' in cat[1].lower() or 1 == 1 :     ### 2013-03-17 test
                if 1 == 1 :     ### 2013-03-17 test
                    log('Exception recordings.addChannel(name= %r)' % cat[0]+cat[2])
                    if limitChannels(cat0+cat[2],'notonlylive',cat[2]) :   ### 2023-05-07
                        name = ' '.join(cat0.split())  ## Remove doublespaces etc
                        log('errorX recordings.addChannel(name= %r' % name+' '+cat[2])
                        if definition.ADDONgetSetting('titlewithcategory') == 'true' :
                            category_name = cat[2]
                            if category_name != '':
                                category_name = ' [' + category_name + ']' 
                        else:
                            category_name = ''
                        log('error 2812 category_name= %r' % category_name)
                        recordings.addChannel(name+category_name,cat[1],cat[3],cat[6], ADDONid+ ' available_channels',epg_channel= cat[5],description=description)  ### 2021-01-15 weight= utils.SeriesEpisode(cat[0])
                        log('Exception set Favorite True= %r' % cat[6])
                        recordings.setChannelFav(c,cat[6],'True')
                        channels += 1
                        ended = datetime.today()
                        definition.ADDONsetSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))
                j += 1
       
            ### >>>>>> ROQ TV ENIGMA
            ###link = 'http://roq-tv.net:25461/enigma2.php?username=XXX&password=XXXX'
            if ROQTVusername.lower() == 'none':
                definition.ADDONresetSetting('expiredate',ROQTVusername)
                definition.ADDONresetSetting('concurrentstreams',ROQTVusername)
                EPGgeneratorName = 'No User'
            else:
                try:
                    if enigma2:
                        log('enigma2 start')
                        linkenigma = definition.getBASEURL() + '/enigma2.php?username=' +ROQuser+ '&password=' +ROQpass
                        EPGgeneratorName = 'enigma2'
                        ended = datetime.today()
                        notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ###+' Src= ' + EPGgeneratorName) 
                        nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                        definition.ADDONsetSetting('lastEPGimportInfo','Import ' + EPGgeneratorName + ' @ ' + nowS)
                        definition.ADDONsetSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ### +' Src= ' + EPGgeneratorName)
                        ChannelFile = os.path.join(datapath,ADDONid) + '.enigma'
                        dataenigma = utils.readlink(linkenigma,ChannelFile,module)
                        log('enigma2 dataenigma= %r' % dataenigma)
                    else:
                        dataenigma = ''
                except Exception as e:
                    pass
                    EpgError = 'Error in getting '+ linkenigma + ' \n' + repr(e)
                    EPGimportERRORS(EpgError)
                    notification(EpgError)
                    dataenigma = ''
                ### Nothing done with enigma data!!! 2018-07-06  2023-07-16 add GetOriginalDescriptionsFromDict  <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                log('enigma2 dataenigma 1= %r' % dataenigma)
                log('enigma2 GetOriginalDescriptionsFromDict(line 2824)')
                GetOriginalDescriptionsFromDict('line 2824')
                log('enigma2 GetOriginalDescriptionsFromDict(line 2826)')
            httplinkEPG = ''
            httplinkEPGenable = definition.ADDONgetSetting('tvguideimporthttpenable')  ### 2018-06-12
            if httplinkEPGenable.lower() == 'true':
                ended = datetime.today()
                notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))  ###+' Src= Import HTTP guide') 
                nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                definition.ADDONsetSetting('lastEPGimportInfo','Import ' + EPGgeneratorName + ' @ ' + nowS)
                definition.ADDONsetSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ###+ ' Src= Import HTTP guide')
                httplinkEPG = definition.ADDONgetSetting('tvguideimporthttp')
                ROQTVusername = definition.ADDONgetSetting('user')
                if ROQTVusername.lower() != 'none':
                    if httplinkEPG == '':
                        httplinkEPG = definition.getBASEURL() + '/xmltv.php?username=' +ROQuser+ '&password=' +ROQpass +'&next_days=10'    ### 2026-04-19

                log('error ' + ADDONname + ' EPG link: ' + repr(httplinkEPG))
            ChannelFile1 = ''
            definition.ADDONresetSetting('tvguideimportinfo','')
            definition.ADDONresetSetting('tvguideimportfile',ChannelFile1)
            ChannelFile2 = ''
            ###2025-12-03 Start
            log('Exception master.xml 1')
            if definition.ADDONgetSetting('tvguidefromfile') == 'true':
                log('Exception master.xml 2')
                ChannelFile1 = definition.ADDONgetSetting('tvguideimport')
                log('Exception ChannelFile1= %r' % ChannelFile1)
                if 'special://' in ChannelFile1:
                    log('Exception master.xml 3')
                    ChannelFile1 = xbmcvfs.translatePath(ChannelFile1)
                    if os.path.isfile(ChannelFile1):
                        log('Exception master.xml 4')
                        definition.ADDONresetSetting('tvguideimport',ChannelFile1)
                    ###else:
                        ###ChannelFile1 = utils.FileManagerPath(ChannelFile1)   ### 2023-03-28
                        ###definition.ADDONsetSetting('tvguideimport',ChannelFile1)
                FileSize = 'missing'
                log('Exception master.xml 5')
                try:
                    ###master = 'master.xml' 
                    master = definition.ADDONgetSetting('tvguidefromfilefullfavorite') ### 2026-03-12
                    master = os.path.basename(master)  ### only use filename
                    ChannelFile1 = os.path.join(ChannelFile1,master)
                    infile = os.path.join(datapath,master)
                    log('Exception master.xml ChannelFile1= %r, age.days= %r' % (ChannelFile1,utils.fileage(ChannelFile1).days))
                    log('0 Exception master.xml infile= %r, age.days= %r' % (infile,utils.fileage(infile).days))
                    ###shutil.copyfile(ChannelFile1, infile)
                    if xbmcvfs.exists(ChannelFile1) and utils.fileage(ChannelFile1).days < 7:
                        log('Exception ChannelFile1 exists= %r' % ChannelFile1)
                        copyOK = xbmcvfs.copy(ChannelFile1, infile)
                        if not copyOK:
                            log('3135 Exception Copy of %r failed - ERROR: %r' %  (infile,copyOK))
                    ChannelFile1 = infile
                    log('1 Exception master.xml infile= %r, age.days= %r' % (infile,utils.fileage(infile).days))
                    FileSz    = float(os.stat(infile).st_size)
                    FileSzKB  = FileSz/(1024)
                    log('Exception Has size %r size in KB %r' % (FileSz,FileSzKB))
                    FileSize = str(int(FileSzKB))
                    log('Exception FileSize %r' % (FileSize))
                    filetime = recordings.humantime(int(os.path.getmtime(infile)))
                except Exception as e:
                    pass
                    log('master.xml Exception in filetime: %r' % e)
                    filetime = 'master.xml ERROR in filetime: ' + repr(e)
                FileData = 'Size: '+ FileSize + ' KB \nDate: ' + filetime
                log('Exception master.xml tvguideimportinfo= %r' % FileData)
                definition.ADDONresetSetting('tvguideimportinfo',FileData)
                definition.ADDONresetSetting('tvguideimportfile',ChannelFile1)
            ChannelFile2 = ''
            if httplinkEPG != '':
                try:
                    ChannelFile2 = os.path.join(datapath,ADDONid) + 'EPG.xml'
                    ChannelFile3 = ADDONid + 'EPG.xml'
                    ChannelFile4 = 'EPGfavorites.xml'
                    data = utils.readlink(httplinkEPG,ChannelFile2,module)
                    ### copy EPG to master.xml in Recordingsfolder
                    if os.path.exists(ChannelFile2):
                        log('Exception ChannelFile2 exists= %r' % ChannelFile2)
                        Recordings = xbmcvfs.translatePath(definition.FileManagerPath('Recordings'))
                        destf = os.path.join(Recordings,'master.xml')
                        copyOK = xbmcvfs.copy(ChannelFile2, destf)
                        if not copyOK:
                            log('3166 Exception Copy of %r failed - ERR: %r' %  (destf,copyOK))
                        destf = os.path.join(Recordings,ChannelFile3)
                        copyOK = xbmcvfs.copy(ChannelFile2, destf)
                        if not copyOK:
                            log('3170 Exception Copy of %r failed - ERR: %r' %  (destf,copyOK))
                        wanted = recordings.getFavoriteChannelsEPG()   ### 2025-07-21 Moved to own .py
                        ###wanted = ['dr1.dk','493972']
                        destf = os.path.join(Recordings,ChannelFile4)
                        SelectXMLTVchannels(wanted,ChannelFile2,destf)
                except Exception as e:
                    pass
                    log('Exception in httplinkEPG: %r' % e)
                    EpgError = 'Error in httplinkEPG '+ httplinkEPG + ' \n' + repr(e)
                    EPGimportERRORS(EpgError)
                    notification(EpgError)
            ###2025-12-03 end      
            EPGgeneratorDis = '<no name>'
            ChannelFiles = []
            
            epgfolder = os.path.join(definition.ADDONgetSetting('record_path'),'epg')
            destepgfolder = os.path.join(datapath,'epg')
            if not xbmcvfs.exists(destepgfolder):
                xbmcvfs.mkdir(destepgfolder)
            ### Get all EPG files in sourceepgfolder Recordings/epg
            files = glob.glob(xbmcvfs.translatePath(os.path.join(destepgfolder,'*')))
            log('deletable xmlfiles= %r' % files)
            for file in files:
                xbmcvfs.delete(file)
                log('Delete file %r ' %  file)
            files = glob.glob(xbmcvfs.translatePath(os.path.join(epgfolder,'*.xml')))
            log('source xmlfiles= %r' % files)
            for file in files:
                filename = file.split(os.sep)[-1]
                infile = os.path.join(destepgfolder,filename)
                log('Copy file %r to \n%r' %  (file,infile))
                copyOK = xbmcvfs.copy(file, infile)
                if not copyOK:
                    log('Copy of %r failed - ERR: %r' %  (os.path.join(epgfolder,'*.xml'),copyOK))
            
            file = xbmcvfs.translatePath(os.path.join(epgfolder,'EPGfavorites.xml'))
            localepg = xbmcvfs.translatePath(os.path.join(destepgfolder,'EPGfavorites.xml'))
            if xbmcvfs.exists(file):
                log('Copy unique file %r to \n%r' %  (file,localepg))
                copyOK = xbmcvfs.copy(file, localepg)
                if not copyOK:
                    log('Error Copy of %r failed' % file)
                    
            files = glob.glob(os.path.join(destepgfolder,'*.xml'))
            log('xmlfiles= %r' % files)
            ###i = 0
            
            for file in files:
                log('epg file age= %r \n%r' % (utils.fileage(file).days,file))
                ChannelFiles.append(file)
                """
                if utils.fileage(file).days < 7:
                    ### Only use epg files 7 days old
                    try:
                        filename = file.split(os.sep)[-1]
                        log(' filename %r\n%r ' % (filename,file))
                    except Exception as e:
                        pass
                        log('filename exception %r\n%r ' % (e,file))
                        filename = 'epg' + str(i) + '.xml'
                        i += 1
                    infile = os.path.join(destepgfolder,filename)
                    copyOK = xbmcvfs.copy(file, infile)
                    if not copyOK:
                        log('Copy of %r failed - ERR: %r' %  (infile,copyOK))
                        infile = file
                    ChannelFiles.append(infile)
                """
            if ChannelFile2 != '':
                ChannelFiles.append(ChannelFile2)
            if ChannelFile1 != '':
                ChannelFiles.append(ChannelFile1)   
            log('master.xml ChannelFiles= %r' % ChannelFiles)
            for ChannelFile in ChannelFiles:
                log('ChannelFile= %r' % ChannelFile)
                try:
                    ChannelFileMod = datetime.fromtimestamp(os.path.getmtime(ChannelFile))
                except Exception as e:
                    pass
                    EpgError = 'Exception in EPG file '+ ChannelFile + ' \n' + repr(e)
                    EPGimportERRORS(EpgError)
                    notification(EpgError)
                    ChannelFileMod = now
        
                log('ChannelFile= %r' % (ChannelFile))
                if ChannelFile == ChannelFile1:
                    log('0 time offset: %r' % (TimeZoneXML))
                else:
                    log('1 Time Offset: %r' % (TimeZone))
                log('l os.path.getmtime(ChannelFile)= %r' % (ChannelFileMod))
                try:
                    log('lastEPGimport= %r' % lastEPGimport)
                    log('ChannelFileMod= %r' % ChannelFileMod)
                    log('lastEPGimport - os.path.getmtime(ChannelFile)= %r' % (lastEPGimport - ChannelFileMod))
                    ###datetime.timedelta(seconds=73505, microseconds=568262)
                    ###log('errX lastEPGimport - os.path.getmtime(ChannelFile) in hours= %r' %((lastEPGimport - ChannelFileMod).replace('datetime.timedelta(0, ','').split(')')[0].split(',')[0]) )    ###if (lastEPGimport - ChannelFileMod).total_seconds()/3600 < 12:
                    ###log('errX lastEPGimport - os.path.getmtime(ChannelFile) in hours= %r' %(repr(lastEPGimport - ChannelFileMod).replace('datetime.timedelta(seconds=','').split(',')[0]) )    ###if (lastEPGimport - ChannelFileMod).total_seconds()/3600 < 12:
                except Exception as e:
                    pass
                    log('Exception lastEPGimport - ChannelFileMod= %r' % e)
                try:
                    log('ChannelFile= %r' % ChannelFile)
                    epgfile = io.open(ChannelFile, 'r', encoding="utf-8")
                    log('epgfile= %r' %  epgfile)
                    dataepg = epgfile.read()
                    log('len(dataepg)= %r' % len(dataepg))
                    log('dataepg= %r' % dataepg)
                    epgfile.close() 
                except Exception as e:
                    pass
                    EpgError = 'Exception in EPG file '+ ChannelFile + ' \n' + repr(e)
                    log('Exception EpgError: %r' % EpgError)
                    EPGimportERRORS(EpgError)
                try:
                    log('0 len(xmltodict.parse(dataepg))= %r' % len(dataepg))
                    dataepg = xmltodict.parse(dataepg)
                    log('1 len(xmltodict.parse(dataepg))= %r' % len(dataepg))
                except Exception as e:
                    pass
                    EpgError = 'Exception in EPG file '+ ChannelFile + ' \n' + repr(e)
                    log('Exception EpgError: %r' % EpgError)
                    EPGimportERRORS(EpgError)
                try:
                    log('len(dataepg)*= %r' % len(dataepg))
                    datapanelEPG1 = dataepg['tv']
                    log('datapanelEPG1 = dataepg[tv]= %r'%(datapanelEPG1))
                    datapanelEPG2 = dataepg['tv']['@generator-info-name']
                    log('datapanelEPG2 = dataepg[tv][@generator-info-name]= %r'%(datapanelEPG2))
                    datapanelEPG3 = dataepg['tv']['@generator-info-url']
                    log('datapanelEPG3 = dataepg[tv][@generator-info-url]= %r'%(datapanelEPG3))
                except Exception as e:
                    pass
                    EpgError = 'Exception in datapanelEPG '+ ChannelFile + ' \n' + repr(e)
                    EPGimportERRORS(EpgError)
                    notification(EpgError)
                ###log('dataepg= %r' % dataepg)  ### 2025-12-04 
                try:
                    EPGgeneratorName = getDict(dataepg,'tv','@generator-info-name')
                    log('EPGgeneratorName= %r' % EPGgeneratorName)  
                    EPGgeneratorURL  = getDict(dataepg,'tv','@generator-info-url')
                    log('EPGgeneratorURL= %r' % EPGgeneratorURL)  
                    if type(EPGgeneratorName) == dict :
                        EPGgeneratorName = str(EPGgeneratorName)
                    if type(EPGgeneratorURL) == dict :
                        EPGgeneratorURL = str(EPGgeneratorURL)
                    if EPGgeneratorName == '' or EPGgeneratorURL == '':
                        EPGgenerator = EPGgeneratorName + EPGgeneratorURL
                    else:
                        EPGgenerator = EPGgeneratorName + ' - ' + EPGgeneratorURL
                    if EPGgeneratorName != '':
                        if EPGgeneratorDis != '' and not EPGgeneratorName in EPGgeneratorDis:
                            EPGgeneratorDis = EPGgeneratorDis + ' - ' + EPGgeneratorName
                        else:
                            EPGgeneratorDis = EPGgeneratorName
                    ChannelFilesplit = ChannelFile.split('epg')
                    log('ChannelFile.split(epg) %r ' % ChannelFile.split('epg'))
                    if len(ChannelFilesplit) == 2:
                        log('ChannelFile.split(epg)[1] %r ' % ChannelFile.split('epg')[1])
                        EPGgeneratorDis += ' ' + ChannelFile.split('epg')[1]
                    log('ChannelFile.split(epg) 2 %r ' % ChannelFile.split('epg'))
                except Exception as e:
                    pass
                    EPGgeneratorDis = 'Exception in EPGgenerator: %r' % e
                definition.ADDONresetSetting('lastEPGimportInfo',EPGgeneratorDis)
                log('Exception definition.ADDONsetSetting(lastEPGimportInfo= %r ' % EPGgeneratorDis)
                ended = datetime.today()
                notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ###+' Src= ' + EPGgeneratorDis) 
                definition.ADDONsetSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))
                
                try:
                    datapanelEPG3 = dataepg['tv']['channel']
                except Exception as e:
                    pass
                    EpgError = 'Exception in datapanelEPG3 '+ ChannelFile + ' \n' + repr(e)
                    EPGimportERRORS(EpgError)
                    notification(EpgError)
                    datapanelEPG3 = []
                epgchannels = recordings.epg_channels()
                log('epg_channels()= %r' % epgchannels)
                i = 0
                for cid in datapanelEPG3:
                    log('3102 error master.xml cid= %r' % cid)
                    i += 1
                    if (channels % channelinterval == 0 and channels != 0) or (programs % programinterval == 0 and programs != 0) or channels <= channelinterval/10 :   
                        ended = datetime.today()
                        notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ###+' Src= ' + EPGgeneratorName)
                        nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                        definition.ADDONsetSetting('lastEPGimportInfo','Import ' + EPGgeneratorName + ' @ ' + nowS)
                        definition.ADDONsetSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))

                    name = getDict(cid,'display-name','#text','@lang')
                    log('3112 error master.xml display-name= %r' % name)
                    name = ' '.join(name.split())  ## Remove doublespaces etc
                    log('3114 error master.xml display-name= %r' % name)
                    try:
                        serepi = utils.SeriesEpisodeVOD(name)[0]  ### ,weight= serepi
                        iconimage = getDict(cid,'icon','@src')
                    except Exception as e:
                        pass
                        log('3120 error master.xml Exception: %r' % e)
                    if definition.ADDONgetSetting('notonlylive').lower() == 'true' :
                        stream_id = cid['@id']
                        ChannelFav = recordings.getChannelFav(c,stream_id)
                        ### ChannelEpg = recordings.getChannelEpgid(c,stream_id)
                        ChannelEpg = stream_id ### 2024-06-04
                        log('3125 error master.xml addEPGChannel(\n  c= %r, \n  stream_id= %r, \n ChannelEpg= %r \n  name= %r)' % (c, stream_id, ChannelEpg, name))
                        log('3126 error master.xml ChannelEpg= %r' % ChannelEpg)
                        if ChannelEpg != None :
                            if ChannelEpg != '' and ChannelEpg.lower() in epgchannels:   ### 2024-01-27 only accept favorites with epg.id
                            ###if ChannelEpg != '' : ### 2024-06-03 and ChannelEpg.lower() in epgchannels:   ### 2024-01-27 only accept favorites with epg.id
                                log('3130 Add error master.xml ChannelEpg= %r' % ChannelEpg)
                                recordings.addEPGChannel(c,stream_id,name,'url',iconimage,repr(cid),EPGgenerator,weight= serepi)
                                recordings.setChannelFav(c,stream_id,ChannelFav)
                                if ChannelEpg != '' and ChannelEpg in epgchannels:
                                    log('errX i= %r, stream_id= %r ,ChannelEpg= %r' % (i,stream_id,ChannelEpg))
                                    recordings.setChannelEpgid(c,stream_id,ChannelEpg)
                                    recordings.setChannelIcon(c,stream_id,recordings.getIconfromEPG(ChannelEpg))
                                channels += 1

                cEPG.commit()
                ended = datetime.today()
                log('errYYY EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ###+' Src= ' + EPGgenerator)
                try:
                    datapanelEPG4 = dataepg['tv']['programme']
                except Exception as e:
                    pass
                    EpgError = 'Error in dataepg[tv][programme] '+ ChannelFile + ' \n' + repr(e)
                    EPGimportERRORS(EpgError)
                    notification(EpgError)
                    datapanelEPG4 = ''
                
                for prog in datapanelEPG4:
                    i += 1
                    log('3131 error prog= %r' % (prog))
                    if (channels % channelinterval == 0 and channels != 0) or (programs % programinterval == 0 and programs != 0) or programs <= programinterval/10 : 
                        ended = datetime.today()
                        
                        notification('EPG Import at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ###+' Src= ' + EPGgeneratorName)
                        nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                        definition.ADDONsetSetting('lastEPGimportInfo','Import ' + EPGgeneratorName + ' @ ' + nowS)
                        definition.ADDONsetSetting('lastEPGimportInfoData','At ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))
                        
                    channel = getDict(prog,'@channel')
                    title = getDict(prog,'title','#text','@lang')
                    sub_title = getDict(prog,'sub_title','#text','@lang')
                    nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                    try:
                        description = getDict(prog,'desc','#text','@lang').replace('?n','?\n').replace('!n','!\n').replace('.nn','.\n').replace('. nn','.\n').replace('.n','.\n').replace('. n','.\n') + ' \n\nEPG Created ' + nowS  ### 2018-04-27
                    except:
                        pass
                        description = ' \n\nEPG Created ' + nowS
                    log('3207 error channel= %r' % channel)
                    log('3208 error epgchannels= %r' % epgchannels)
                    if channel != '' and channel.lower() in epgchannels:   ### 2025-02-12 only accept favorites 
                    ###if channel != '' :   ### 2024-10-04 accept all 
                        log('3211 error ACCEPTED channel= %r' % channel)
                        if ChannelFile == ChannelFile1:
                            recordings.addEPGProgram(c,prog,channel, title, sub_title, parse_date_stringXML(prog['@start']), parse_date_stringXML(prog['@stop']), description, source=EPGgenerator)
                        else:
                            recordings.addEPGProgram(c,prog,channel, title, sub_title, parse_date_string(prog['@start']), parse_date_string(prog['@stop']), description, source=EPGgenerator)
                        programs += 1
                    cEPG.commit()
                cEPG.commit()
            cEPG.commit()
            c.close()
            ended = datetime.today()
            definition.ADDONsetSetting('lastEPGimport',ended.strftime('%Y-%m-%d %H:%M:%S') + ' using ' + TimeUsed(ended,now))
            notification('EPG Import Ended in ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))
            log('errYYY err EPG Import Ended at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs))   ###+ ' Src= ' + EPGgenerator)
            locking.scanUnlock('EPG_update')  ### 2023-08-25
        
        log('err #2585 before last updateiconsfromEPG()')
        updateiconsfromEPG()  ### 2022-05-09
        log('err #2587 after last updateiconsfromEPG()')
        updateseries()   ### 2021-01-16
        ended = datetime.today()
        lastEPGimportInfoData = 'Ended in ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs)
        
        definition.ADDONresetSetting('lastEPGimportInfoData',lastEPGimportInfoData)
        log('enigma2 GetOriginalDescriptionsFromDict(second time)')
        GetOriginalDescriptionsFromDict('Line 3110')
        log('enigma2 GetOriginalDescriptionsFromDict(second time finished)')
        definition.ADDONsetSetting('lastEPGimportInfo','Force INI file')
        recordings.ftvntvlist() ### Force INI file
        definition.ADDONsetSetting('lastEPGimportInfo','Delete old programs')
        recordings.delOldEPGPrograms()  ### 7 days old programs and 2 days old channels  
        definition.ADDONsetSetting('lastEPGimportInfo','Find Doubletes')
        updatedrecordings = recordings.finddoubletes()  ### Find double programs
        if updatedrecordings >= 1:
            definition.ADDONsetSetting('lastEPGimportInfo','Reschedule Started')
            recordings.reschedule() ### Set EPG program start
            definition.ADDONsetSetting('lastEPGimportInfo','Reschedule Ended')
        ended = datetime.today()
        notification('EPG Import Ended in ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+ ' Find doublette programs ended')
        log('errYYY EPG Import Ended at ' + TimeUsed(ended,now) + ' Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= ' + EPGgenerator+ ' Find doublette programs ended')
        definition.ADDONsetSetting('lastEPGimportInfo','Find dublet channels Started')
        ###deleteDoubletChannels = recordings.deleteDoubletChannels()
        ###definition.ADDONsetSetting('lastEPGimportInfo','Find dublet channels Ended with %r deletions' % deleteDoubletChannels)
        
        definition.ADDONsetSetting('lastEPGimportInfo','Grab Started')
        findtvguidenotifications.findtvguidenotifications()
        definition.ADDONsetSetting('lastEPGimportInfo','Grab Ended')
        
        try:### fra service
            if definition.ADDONgetSetting('copyrecordingsdatabase')=='true':
                definition.ADDONsetSetting('lastEPGimportInfo','Copy Database to Recordings Folder Started')
                recordings.setRecordsBase()    ### Copy recordings database to recordings folder
                definition.ADDONsetSetting('lastEPGimportInfo','Copy Database to Recordings Folder Ended')                                                       
        except Exception as e:
            pass
            log('Copy Database to Recordings Folder error: ' + repr(e))
            definition.ADDONsetSetting('lastEPGimportInfo','Copy Database to Recordings Folder Failed: %r' % e)
            
        try:
            lennowCategories = len(nowCategories)
            log('3038 error addCategories len(nowCategories)= %r' % lennowCategories)
            if lennowCategories >= 1:
                ### Handle now catagories here! 2023-05-17
                definition.ADDONsetSetting('lastEPGimportInfo','Add Now Categories (%r)' % lennowCategories)
                recordings.addCategories(nowCategories, 'now')
                nowCategories = []
                utils.writeDataFile('nowCategories',nowCategories)
        except Exception as e:
            log('3048 addCategories now ERROR %r' % e)
            pass
        
        try:
            lennewCategories = len(newCategories)
            log('3053 error addCategories len(newCategories)= %r' % lennewCategories)
            if lennewCategories >= 1:
                ### Handle new catagories here! 2023-05-14
                definition.ADDONsetSetting('lastEPGimportInfo','Add New Categories (%r of %r)' % (lennewCategories,lennowCategories))
                recordings.addCategories(newCategories, 'new')
                newCategories = []   ### 2023-05-15 delete new categories when handled
                utils.writeDataFile('newCategories',newCategories)
        except Exception as e:
            log('3063 addCategories ERROR %r' % e)
            pass
        lennowCategories = len(recordings.getAllCats())
        lenactiveCategories = len(recordings.getActiveCats())
        lennewCategories = len(recordings.getAllNewCats())
        if lenactiveCategories == 0:
            lenactiveCategoriesT = '[B][COLOR red]' + str(lenactiveCategories) + '[/COLOR][/B]'
        else:
            lenactiveCategoriesT = '[B][COLOR lightgreen]' + str(lenactiveCategories) + '[/COLOR][/B]'
        if lennewCategories >= 1:
            lennewCategoriesT = '[B][COLOR red]' + str(lennewCategories) + '[/COLOR][/B]'
        else:
            lennewCategoriesT = '0'
        definition.ADDONsetSetting('lastEPGimportCategories',str(lennowCategories)+' / '+lenactiveCategoriesT+' / '+lennewCategoriesT)
        if lennewCategories >= 1:
            definition.ADDONsetSetting('lastEPGimportInfo','Update EPG Ended with %r of %r new categories' % (lennewCategories,lennowCategories))
        else:
            definition.ADDONsetSetting('lastEPGimportInfo','Update EPG Ended')
        locking.scanUnlock('EPG_update')
