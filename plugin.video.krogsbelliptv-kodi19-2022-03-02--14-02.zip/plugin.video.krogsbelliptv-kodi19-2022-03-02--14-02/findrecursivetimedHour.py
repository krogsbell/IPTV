#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import urllib,urllib2,sys,re,os
import datetime
import time
import utils
import net
from hashlib import md5  
import json
import recordings, glob
import findrecursive
import locking
import definition
ADDON      = definition.getADDON()
module     = 'findrecursivetimedHour.py'
utils.logdev(module,'Start')
if not locking.isAnyRecordLocked(): 
	streamtype = ADDON.getSetting('streamtype')
	if streamtype == '0':
		STREAMTYPE = 'NTV-XBMC-HLS-'
	elif streamtype == '1':
		STREAMTYPE = 'NTV-XBMC-'


	UA=STREAMTYPE + ADDON.getAddonInfo('version') 

	net=net.Net()
	datapath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
	cookie_path = os.path.join(datapath, 'cookies')
	loginurl = definition.getBASEURL() + '/index.php?' + recordings.referral()+ 'c=3&a=0'
	username    =ADDON.getSetting('user')
	password = md5(ADDON.getSetting('pass')).hexdigest()
	data     = {'email': username,
											'psw2': password,
											'rmbme': 'on'}
	headers  = {'Host':definition.getBASEURL().replace('http://',''),
											'Origin':definition.getBASEURL(),
											'Referer':definition.getBASEURL() + '/index.php?' + recordings.referral()+ 'c=3&a=0'}
	
	findrecursive.RecursiveRecordingsPlanned('Hour')
	#xbmc.executebuiltin("Container.Refresh")

def deleteFile(file):
    tries    = 0
    maxTries = 10
    while os.path.exists(file) and tries < maxTries:
        try:
            os.remove(file)
            break
        except:
            xbmc.sleep(50)
            tries = tries + 1

lockDescription = '*Stop Recording*.flv'
recordingLock = os.path.join(ADDON.getSetting('record_path'),lockDescription)
LockFiles = glob.glob(recordingLock)
# delete lock files
for file in LockFiles:
	deleteFile(file)
