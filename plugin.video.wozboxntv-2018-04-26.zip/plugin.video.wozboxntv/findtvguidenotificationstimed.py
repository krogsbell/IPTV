#!/usr/bin/python
# -*- coding: utf-8 -*-
try:
    import findtvguidenotifications
    import findrecursivetvguide
    import definition
    import utils
    ADDON      = definition.getADDON()
    findtvguidenotifications.findtvguidenotifications()
    utils.log('findtvguidenotifications.py','Ended')
    #findrecursivetvguide.RecursiveRecordingsPlanned('TVguide')
    #utils.log('findrecursivetvguide.py','Ended')
except: pass
