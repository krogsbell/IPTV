#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmcaddon,xbmc,xbmcgui,os,shutil
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)

# 0= NTV.mx, 1= WOZBOX www.wozboxtv.com, 2=www.myindian.tv, 3=www.wliptv.com, 4=roq-tv.com, 5=www.ace-tv.co.uk
# Copy the addon folder to the name of the id to copy addon to, update addon.xml and add the jpg and png icons to be used with the addon then make a zip file and install from zip!

referral= 0   ### 8 ###<===  GlowIPTV         ##########################<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
###values="NTV|WOZBOX (www.wozboxtv.com)|My Indian TV|White Label Spain (http://www.wliptv.com)|ROQ TV Rec|ACE TV Rec|ACE TV Rec Experimental|Premium IPTV (Premiumiptv.co)


BASEURL = ''
COMMAND = ''
COMMANDEND = ''
REGISTRATION = ''
REFERRALNAME = ''
REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'
DEFAULTSTREAMTYPE = ''
PLAYURL = ''  ### Not used after 2019-03-25

def nowTS():   ### Local time
    dt_obj= datetime.now()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
   
def nowutcTS():   ### UTC time
    dt_obj= datetime.utcnow()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
    
def timeZone():
    tz = (nowTS() - nowutcTS())/3600
    return tz
    
def DaylightSaving():
    dialog = xbmcgui.Dialog()
    if dialog.yesno(ADDON.getAddonInfo('name'), "[COLOR red]Are you using daylight saving[/COLOR]", '', "What Do You Want To Do","[COLOR red]Use Daylight Saving[/COLOR]","[COLOR green]No[/COLOR]"):
        ### No
        return False
    else:
        ### Yes
        return True
        
def Numeric(name,default):
    dialog = xbmcgui.Dialog()
    keyboard=dialog.numeric(0, 'Please Enter '+str(name),default)
    if keyboard:
        if keyboard[0:1] == '0':
            keyboard = str(0-int(keyboard))
    return keyboard
    
### xbmcgui.Dialog().browse(type, heading, shares[, mask, useThumbs, treatAsFolder, defaultt, enableMultiple])
def getFile(name,default):
    dialog = xbmcgui.Dialog()
    file = dialog.browse(1, 'Please Enter '+str(name), '', defaultt=default)
    return file
    
def Parameter(ADDON,name,parameter):
    VALUE = ADDON.getSetting(parameter)
    if VALUE == 'Not Set' and parameter == 'my_referral_name':
        VALUE = ADDON.getAddonInfo('name')
    newVALUE = Search(name,VALUE)
    ADDON.setSetting('parameter',str(VALUE) + '-->' + str(newVALUE))
    if newVALUE:
        ADDON.setSetting(parameter,newVALUE)
    return newVALUE
    
def Search(name,search_entered):
    keyboard = xbmc.Keyboard(search_entered, '[COLOR lightgreen][B]Please Enter '+str(name)+'[/B][CR][COLOR grey][I]<ESC> or Cancel to clear[/I][/COLOR]')
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_entered = keyboard.getText()
        if search_entered == None:
            return False 
    else:
        return False
    return search_entered 

if referral==0:
    ADDON = xbmcaddon.Addon(id='plugin.video.krogsbelliptv-2019-09-04-18')
    BASEURL = ADDON.getSetting('BASEURL')
    BASEURLlast = BASEURL
    ADDON.setSetting('BASEURLlast',BASEURLlast)
    l=0
    if not 'http://' in BASEURL and not 'https://' in BASEURL:
        try:
            my_referral_name = Parameter(ADDON,'Addon Name','my_referral_name')
            my_referral_registration = Parameter(ADDON,'IPTV Registred at','my_referral_registration')
            basicuserinfo = ADDON.getSetting('basicuserinfo')
            if 'none.txt' in basicuserinfo:
                basicuserinfo = os.path.join(ADDON.getAddonInfo('path'), 'none.txt')
            ### basicuserinfo = Parameter(ADDON,'Your Connection Details Text File','basicuserinfo')
            ### http://<url>/get.php?username=<>&password=<>&type=m3u_plus&output=ts
            basicuserinfo = getFile('Your Connection Details Text File or none',basicuserinfo)
            ADDON.setSetting('basicuserinfo',basicuserinfo)
            
            ChannelFile = ADDON.getSetting('directchannelsfromextraXMLTVfile')
            if os.path.isfile(ChannelFile):
                directchannelsdef = ChannelFile
            else:
                directchannelsdef = os.path.join(ADDON.getAddonInfo('path'), 'directchannels.m3u.txt')
            directchannels    = getFile('Your Direct Channels m3u File or keep last',directchannelsdef)
            datapath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
            if os.path.isfile(directchannels) and directchannels != directchannelsdef:
                directchannelsdata = os.path.join(datapath,'directchannels.m3u')
                ADDON.setSetting('directchannelsfromextraXMLTVfile',directchannelsdata)
                shutil.copyfile(directchannels, directchannelsdata)
            else:
                try:
                    ADDON.setSetting('directchannelsfromextraXMLTVfile','')
                    os.remove(os.path.join(datapath,'directchannels.m3u'))
                except:
                    pass
            
            file = open(basicuserinfo,'r')
            desc = file.read()
            file.close()
            basicuserinfo = desc
            l=1
            if basicuserinfo:
                if basicuserinfo.lower().replace('\n','').replace('\r','').replace("'",'') == 'none':
                    basicuserinfo = 'http://none.none:80/get.php?username=none&password=none&type=m3u_plus&output=ts'
                basicuserinfo = basicuserinfo.replace('&amp;','&')
                l=2
                ADDON.setSetting('AAA','basicuserinfo= %r' % basicuserinfo)
                if 'http://' in basicuserinfo.lower():
                    l=3
                    server = basicuserinfo.split('http://',1)[1]
                else:
                    l=4
                    server = basicuserinfo.split('https://',1)[1]
                l=5
                BASEURL = server.split('/')[0]
                l=6
                if BASEURL != BASEURLlast:
                    l=7
                    ### Reset DB and timezones
                    ADDON.setSetting('BASEURLchanged','true')
                    TIMEZONE = str(timeZone())
                    ADDON.setSetting('TIMEZONE',TIMEZONE)
                    ADDON.setSetting('AdjustTVguideTimeZoneOffset',TIMEZONE)
                    ADDON.setSetting('archiveoffset','0')  ### Archive uses GMT 2019-03-30
                    ADDON.setSetting('AdjustTVguideTimeZoneOffsetExtraXML',TIMEZONE)
                    """
                    ### Summertime?  - negative timezone?
                    DAYLIGHTSAVINGold = ADDON.getSetting('DAYLIGHTSAVING')
                    if DaylightSaving():
                        DAYLIGHTSAVING = 1
                    else:
                        DAYLIGHTSAVING = 0
                    TIMEZONE = ADDON.getSetting('TIMEZONE')
                    TIMEZONE = Numeric('Your Time Zone offset - UK=0 - negative start with zero',TIMEZONE)
                    if TIMEZONE:
                        l=8
                        ADDON.setSetting('TIMEZONE',str(TIMEZONE))
                        ADDON.setSetting('AdjustTVguideTimeZoneOffset',str(int(TIMEZONE)+DAYLIGHTSAVING))
                        ADDON.setSetting('archiveoffset','0')  ### Archive uses GMT 2019-03-30
                        ADDON.setSetting('AdjustTVguideTimeZoneOffsetExtraXML',str(int(TIMEZONE)+DAYLIGHTSAVING))
                    """
                else:
                    l=9
                    ADDON.setSetting('BASEURLchanged','false')
                l=10
                command = server.replace(BASEURL,'',1)
                BASEURL = 'http://' + BASEURL
                COMMAND = command.split('username=',1)[0]
                
                l=11
                username = command.split('username=',1)[1].split('&',1)[0]
                l=12
                password = command.split('password=',1)[1].split('&',1)[0]
                l=13
                COMMANDEND = '&type=' + command.split('&type=',1)[1]
                ADDON.setSetting('COMMAND',COMMAND)
                ADDON.setSetting('COMMANDEND',COMMANDEND)
                if BASEURL != '' and username != '' and password != '':
                    l=14
                    ADDON.setSetting('BASEURL',BASEURL)
                    ADDON.setSetting('user',str(username))
                    ADDON.setSetting('pass',str(password))
        except Exception,e:
            pass
            ADDON.setSetting('basicuserinfoerror', 'l= %r, ERROR= %r' % (l,e))
    else:
        BASEURL = ADDON.getSetting('BASEURL').replace('&amp;','&')
        COMMAND = ADDON.getSetting('COMMAND').replace('&amp;','&')
        COMMANDEND = ADDON.getSetting('COMMANDEND').replace('&amp;','&')
    REFERRALNAME = ADDON.getSetting('Addon Name')
    REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'
    DEFAULTSTREAMTYPE = 'live'
    
elif referral==1:
    ADDON = xbmcaddon.Addon(id='plugin.video.wozboxntv')
    BASEURL = 'http://www.ntv.mx'
    REGISTRATION = 'wozboxtv.com/registration'
    REFERRALNAME = 'WOZBOX (www.wozboxtv.com)'
    REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'
    
elif referral==2:
    ADDON = xbmcaddon.Addon(id='plugin.video.myindian')
    BASEURL = 'http://www.myindian.tv'
    REGISTRATION = 'http://www.myindian.tv'
    REFERRALNAME = 'My Indian TV'
    REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'
    
elif referral==3:
    ADDON = xbmcaddon.Addon(id='plugin.video.wliptv')
    BASEURL = 'http://www.wliptv.com'
    REGISTRATION = 'http://www.wliptv.com'
    REFERRALNAME = 'White Label Spain (http://www.wliptv.com)'
    REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'
    
elif referral==4:
    ADDON = xbmcaddon.Addon(id='plugin.video.roqtv.rec')
    ###BASEURL = 'http://roq-tv.net:25461'
    BASEURL = 'http://www.roq-tv.net:80'
    PLAYURL = 'http://clic-tv.org:80'
    COMMAND = '/panel_api.php?'
    COMMANDEND = '&type=m3u_plus&output=m3u8'
    REGISTRATION = 'http://roq-tv.com'
    REFERRALNAME = 'ROQ TV Rec'
    REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'

elif referral==5:
    ADDON = xbmcaddon.Addon(id='plugin.video.acetvrec')
    BASEURL = 'http://ace-tv.xyz:25461'
    REGISTRATION = 'http://www.ace-tv.co.uk'
    REFERRALNAME = 'ACE TV Rec'
    REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'

elif referral==6:
    ###ADDON = xbmcaddon.Addon(id='plugin.video.acetvrec')
    ADDON = xbmcaddon.Addon(id='plugin.video.roqtvrec')
    ###BASEURL = 'http://ace-tv.xyz:25461'
    BASEURL = 'http://ace-tv.xyz:8080'
    ###BASEURL = 'http://ace.nothingtosee.xyz:8080'   ### TEST 2017-11-23
    REGISTRATION = 'http://www.ace-tv.co.uk'
    REFERRALNAME = 'ACE TV Rec Experimental'
    REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'
    
elif referral==7:
    ###http://tv.premium.iptv.uno:8080/get.php?username=xxxx&password=xxxx&type=m3u_plus&output=m3u8
    ADDON = xbmcaddon.Addon(id='plugin.video.premiumiptv.rec')
    BASEURL = 'http://tv.premium.iptv.uno:8080'
    COMMAND = 'get.php?'
    COMMANDEND = '&type=m3u_plus&output=m3u8'
    REGISTRATION = 'http://www.premiumiptv.co'
    REFERRALNAME = 'Premium IPTV (Premiumiptvco.com)'
    REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'

elif referral==8:
    ###http://tv.glowiptv.iptv.uno:8080/get.php?username=xxx&password=xxxx&type=m3u_plus&output=m3u8
    ADDON = xbmcaddon.Addon(id='plugin.video.glowiptv.rec')
    BASEURL = 'http://tv.glowiptv.iptv.uno:80'
    PLAYURL = 'http://channels227070.clientportal.link:80'
    COMMAND = 'get.php?'
    COMMANDEND = '&type=m3u_plus&output=m3u8'
    REGISTRATION = 'http://glowiptv.com'
    REFERRALNAME = 'GlowIPTV Rec'
    REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '..................[/COLOR][/B]'

elif referral==9:
    ###http://www.e900x.com:8000/get.php?username=xxxx&password=xxxx&type=m3u_plus&output=ts
    ADDON = xbmcaddon.Addon(id='plugin.video.nordicchannels.rec')
    BASEURL = 'http://www.e900x.com:8000'
    COMMAND = 'get.php?'
    COMMANDEND = '&type=m3u_plus&output=ts'
    REGISTRATION = 'http://www.nordicchannels.com'
    REFERRALNAME = 'Krogsbell IPTV 2019-09-04 @18 Rec'
    REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '.....[/COLOR][/B]'
    DEFAULTSTREAMTYPE = 'live'

elif referral==10:
    ADDON = xbmcaddon.Addon(id='plugin.video.ntv')
    BASEURL = 'http://www.ntv.mx'
    REGISTRATION = 'http://ntv.mx/?r=Kodi&c=2&a=0&p=9'
    REFERRALNAME = 'NTV'
    REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'
else:
    ADDON = xbmcaddon.Addon(id='plugin.video.krogsbelliptv-2019-09-04-18')
    if ADDON.getSetting('BASEURL') == '':
        basicuserinfo = Search('Your connection details')
        ### http://<url>/get.php?username=<>&password=<>&type=m3u_plus&output=ts
        if basicuserinfo:
            if 'http://' in basicuserinfo.lower():
                server = basicuserinfo.split('http://',1)[1].split('/')[0]
                BASEURL = basicuserinfo.split('http://',1)[1].split('/')[0]
                COMMAND = ''
    REGISTRATION = ''
    COMMAND = '/panel_api.php?'
    COMMANDEND = '&type=m3u_plus&output=m3u8'
    REGISTRATION = ''
    REFERRALNAME = 'IPTV Rec'
    REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'

ADDON.setSetting('my_referral_link',str(referral))
REFERRALNAME = ADDON.getSetting('my_referral_name')
REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'
REGISTRATION = ADDON.getSetting('my_referral_registration')
###xbmc.log('definition.py in %s with referral= %s' % (ADDON.getAddonInfo('id'), repr(referral)))

def getADDON():
    return ADDON

def getBASEURL():
    return BASEURL  
  
def getPLAYURL():
    return PLAYURL  
    
def getCOMMAND():
    return COMMAND 
    
def getCOMMANDEND():
    return COMMANDEND  
    
def getREGISTRATION():
    return REGISTRATION 
 
def getTITLE():
    return REFERRALTITLE 
    
def getDefaultStreamType():
    return DEFAULTSTREAMTYPE
    
def getKrogsbellAddOns():
    ###return ['plugin.video.glowiptv.rec','plugin.video.premiumiptv.rec','plugin.video.roqtv.rec']
    ###return ['plugin.video.glowiptv.rec','plugin.video.nordicchannels.rec',]
    return []

def getNTVAddOns():
    return ['plugin.video.unlimtv']
    ###return []



