#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmc, xbmcvfs
import xbmcaddon
import xbmcgui
import xbmcplugin
import os
import sys
import time
import shutil
###import datetime
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import time

import signal
#import locking     #Use locking to write test messages as filenames
###import recordings
from subprocess import Popen, PIPE, STDOUT
import glob
import urllib
import ssl
import pickle
from urllib.request import urlopen

ADDON     = xbmcaddon.Addon(id='plugin.audio.dr.dk.netradio')
ADDONname = ADDON.getAddonInfo('name')
ADDONid   = ADDON.getAddonInfo('id')
ADDONpath = xbmcvfs.translatePath('special://home/addons/%s/' % ADDONid)
datapath  = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
progpath  = ADDON.getAddonInfo('path')
PATH      = progpath

###import os
###mem=str(os.popen('free -t -m').readlines())
"""
Get a whole line of memory output, it will be something like below
['             total       used       free     shared    buffers     cached\n', 
'Mem:           925        591        334         14         30        355\n', 
'-/+ buffers/cache:        205        719\n', 
'Swap:           99          0         99\n', 
'Total:        1025        591        434\n']
 So, we need total memory, usage and free memory.
 We should find the index of capital T which is unique at this string
"""
###T_ind=mem.index('T')
"""
Than, we can recreate the string with this information. After T we have,
"Total:        " which has 14 characters, so we can start from index of T +14
and last 4 characters are also not necessary.
We can create a new sub-string using this information
"""
###mem_G=mem[T_ind+14:-4]
"""
The result will be like
1025        603        422
we need to find first index of the first space, and we can start our substring
from from 0 to this index number, this will give us the string of total memory
"""
###S1_ind=mem_G.index(' ')
###mem_T=mem_G[0:S1_ind]
"""
Similarly we will create a new sub-string, which will start at the second value. 
The resulting string will be like
603        422
Again, we should find the index of first space and than the 
take the Used Memory and Free memory.
"""
###mem_G1=mem_G[S1_ind+8:]
###S2_ind=mem_G1.index(' ')
###mem_U=mem_G1[0:S2_ind]

###mem_F=mem_G1[S2_ind+8:]
"""
print 'Summary = ' + mem_G
print 'Total Memory = ' + mem_T +' MB'
print 'Used Memory = ' + mem_U +' MB'
print 'Free Memory = ' + mem_F +' MB'
"""
def get_ram_info():
    return ''  ### Do not work on Windows
    try:
        mem=str(os.popen('free -t -m').readlines())
        T_ind=mem.index('T')
        mem_G=mem[T_ind+14:-4]
        S1_ind=mem_G.index(' ')
        mem_T=mem_G[0:S1_ind]
        mem_G1=mem_G[S1_ind+8:]
        S2_ind=mem_G1.index(' ')
        mem_U=mem_G1[0:S2_ind]
        mem_F=mem_G1[S2_ind+8:]
        return 'Free Memory = ' + mem_F +' MB'
    except Exception as e:
        pass
        return 'get_ram_info %r\nException: %r' % (mem,e)
        
def ADDONsetSetting(setting,value):
    ###__log('ADDONsetSetting(setting= %r,value= %r)' % (setting,value))
    ###utils.ADDONsetSetting('findstation#','xxx')
    if setting == 'count':   ### 2023-11-14 ignore count
        return
    if setting == 'findstation#':
        nowHMS=datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        findstationrunning= ADDONgetSetting('findstationrunning')
        startstationrunning= ADDONgetSetting('startstationrunning')
        datapathF = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        if not os.path.exists(datapathF):
            os.makedirs(datapathF) 
        addonlog = os.path.join(datapathF, 'addonfind.log')
        LogDev = open(addonlog, 'a')
        LogDev.write(nowHMS + ' ' +startstationrunning+'/'+ findstationrunning+ ' ' +value +'\n')
        LogDev.close()
    setting = setting.lower()
    ###file = os.path.join(datapath,setting) + '.setall'
    ###LF = open(file, 'w')
    ###LF.write(value)
    ###LF.close()
    if setting == 'programplaying' :
        value = getKanal()
    ADDON.setSetting(setting,value)
    if value != '':
        file = os.path.join(datapath,setting) + '.set'
        LF = open(file, 'w')
        LF.write(value)
        LF.close()

def ADDONresetSetting(setting,value):
    ###__log('ADDONsetSetting(setting= %r,value= %r)' % (setting,value))
    setting = setting.lower()
    if setting == 'programplaying' :
        value = getKanal()
    ADDON.setSetting(setting,value)
    file = os.path.join(datapath,setting) + '.set'
    LF = open(file, 'w')
    LF.write(value)
    LF.close()
    
def ADDONgetSetting(setting):
    ###__log('ADDONgetSetting(setting= %r)' % (setting))
    setting = setting.lower()
    
    nofilesettings = ["autorun","noepg","addonlog","modulestoaddonlog","timebetweenupdates"]
    file = os.path.join(datapath,setting) + '.set'
    if setting == 'programplaying' :
        value = getKanal()
    elif os.path.isfile(file) == False or setting in nofilesettings:
        value = ADDON.getSetting(setting)
    else:
        LF = open(file,'r')
        value = LF.read()
    if value != '':
        ADDONsetSetting(setting,value)
    if setting == 'sharepath' :  ### 2023-08-30
        value = FileManagerPath(value)
    return value

ADDONid    = ADDON.getAddonInfo('id')
ADDONname  = ADDON.getAddonInfo('name')
xbmc.log('utils.py in %s STARTED' % ADDONname)
referral = ADDONgetSetting('my_referral_link')
###datapath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
progpath = ADDON.getAddonInfo('path')   
IMAGE = os.path.join(ADDON.getAddonInfo('path'), 'icon' + referral + '.jpg')
directrecording = ADDONgetSetting('enable_record_drdk_directly')
module = 'utils.py'

notify = ADDONgetSetting('notifyduringepgupdate')
if notify == 'true':
    notifyduringepgupdate = True
else:
    notifyduringepgupdate = False

def logbackupreset():
    datapath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    addonlog = os.path.join(datapath, 'addon.log')
    addonOLDlog = os.path.join(datapath, 'addonOLD.log')
    shutil.copyfile(addonlog, addonOLDlog)
    os.remove(addonlog)

def logdevreset():
    datapath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    addonlog = os.path.join(datapath, 'addon.log')
    addonOLDlog = os.path.join(datapath, 'addonOLD.log')
    
    try:
        size = os.path.getsize(addonlog)
        try:
            logsize = int(ADDONgetSetting('logsize'))
        except Exception:
            pass
            logsize = 10
        maxsize = logsize * 1024 * 1024 # 100 MB    2023-11-01 log size from settings
        if os.path.exists(addonlog) and size > maxsize:
 
            shutil.copyfile(addonlog, addonOLDlog)
        
            tries    = 0
            maxTries = 10
            maxSleep = 50
            while os.path.exists(addonlog) and tries < maxTries:
                try:
                    os.remove(addonlog)
                    break
                except:
                    xbmc.sleep(maxSleep)
                    tries = tries + 1
    except Exception as  e:
        pass
        xbmc.log('%r: Reset addon.log failed: %r' % (ADDONname,e)) ###, level=xbmc.LOGNOTICE)
 
def log(module,message):
    ###logdev(module,message)
    xbmc.log(ADDON.getAddonInfo('name') + ' ' + module +': ' + message)   ###, level=xbmc.LOGNOTICE)

def logdev(module,message):
    findstationrunning= ADDONgetSetting('findstationrunning')
    startstationrunning= ADDONgetSetting('startstationrunning')
    addonlog = ADDONgetSetting('addonlog')
    log(module,'addonlog= %r'% addonlog)
    if addonlog == '1' and not module in ADDONgetSetting('modulestoaddonlog'):
        log(module,message)
    elif addonlog == '2':
        return
    else:
        try:
            nowHMS=datetime.today().strftime('%Y-%m-%d %H:%M:%S')
            datapath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
            if not os.path.exists(datapath):
                os.makedirs(datapath) 
            addonlog = os.path.join(datapath, 'addon.log')
            logdevreset()
            LogDev = open(addonlog, 'a')
            # Write to our text file the information we have provided and then goto next line in our file.
            # LogDev.write(repr(module) + ': ' + repr(message) + '\n')
            ###LogDev.write(nowHMS + ' ' + module + ': ' + message + '\n')
            LogDev.write(nowHMS + ' ' + module + ': ' + startstationrunning +'/'+ findstationrunning +' ¤ '+ message + '\n')
            LogDev.close()
        except Exception as  e:
            pass
            log(module,'error in logdev: ' + repr(e))
 
def __log(message):
    logdev(module,message[0:200])
    ###logdev(module,message)   ### Test

def logasfile(filename,variable):
    nowHMS=datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    datapath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not os.path.exists(datapath):
        os.makedirs(datapath) 
    filelog = os.path.join(datapath,filename)
    with open(filelog,'wb') as output:
        output.write(b'%r  %r: %r\nLength of variable= %r\n%r'% (nowHMS,filename,filelog,len(variable),variable))
 
def logdevarray(module,array):
    logdev(module, '\n')
    try:
        if type(array) in (list, tuple, dict):
            logdev(module, 'len(array)= %r' % len(array))
            for note in array:
                if type(note) in (list, tuple, dict):
                    i = 0
                    for n in note:
                        logdev(module, 'array[%d]= %r' % (i,note))
                        i += 1
                else:
                    logdev(module, 'array[x]= %r - %r' % (note, array[note]))
            logdev(module, '\n')
        else:
            logdev(module, 'array= %r' % array)
    except Exception as  e:
        pass
        logdev(module,'error in logdevarray: ' + repr(e))
        
def onlyAscii(unicrap):
    """This takes a UNICODE string and ignores all characters 128 (0x80) and higher
    """ 
    r = ''
    for i in unicrap:
        if ord(i) >= 0x80:
            pass
        else:
            r += str(i)
    return r
    
def now():   ### Local time
    dt_obj= datetime.now()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
        
def datestr(timestamp,format):   ### Date string UTC time %Y-%m-%dT%H:%M:%S%z
    time_tuple = time.localtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)

def datestrdelta(timestamp,format):   ### Now date string UTC time %Y-%m-%dT%H:%M:%S%z
    time_tuple = time.gmtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)

def TSlts(timestamp):
    TO = datetime.fromtimestamp(timestamp)
    TOTS = int(time.mktime(TO.timetuple()))
    utcTO = datetime.utcfromtimestamp(timestamp)
    utcTOTS = int(time.mktime(utcTO.timetuple()))
    timeoffset = TOTS-utcTOTS
    ###__log('timeoffset= %r' % timeoffset)
    return(timestamp+timeoffset) 

def TSl(timestr):
    ### time format 2019-05-21T22:05:00Z to date string i local
    time_tuple = time.strptime(timestr, dateformat)
    timestamp = time.mktime(time_tuple)
    TO = datetime.fromtimestamp(timestamp)
    TOTS = int(time.mktime(TO.timetuple()))
    utcTO = datetime.utcfromtimestamp(timestamp)
    utcTOTS = int(time.mktime(utcTO.timetuple()))
    timeoffset = TOTS-utcTOTS
    ###__log('timeoffset= %r' % timeoffset)
    return(timestamp+timeoffset) 
    
def TS(timestr):
    ### time format 2019-05-21T22:05:00Z
    time_tuple = time.strptime(timestr, dateformat)
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def TSx(timestr):
    ### time format 2019-05-21T22:05:00Z
    time_tuple = time.strptime(timestr, dateformatX)
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
    
def nowTS():   ### UTC time
    dt_obj= datetime.utcnow()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def nowS(format):   ### Now date string UTC time
    time_tuple = time.localtime(nowTS())
    date_str = time.strftime(format, time_tuple)
    return(date_str)
 
def nowL(format):   ### Now date string Local time
    time_tuple = time.localtime(now())
    date_str = time.strftime(format, time_tuple)
    return(date_str)
     
def FileManagerPath(PathInput):
    try:
        sources = xbmcvfs.translatePath('special://masterprofile/sources.xml')
        file = open(sources,'r', encoding = 'utf-8')
        allsources = file.read()
        files = allsources.split('<files>')[1]
        __log('FileManagerPath files= %r' % files)
        searchtext = '<name>'+PathInput+'</name>'
        __log('FileManagerPath searchtext= %r' % searchtext)
        files = files.split(searchtext)[1]
        __log('FileManagerPath 1 files= %r' % files)
        files = files.split('>')[1]
        __log('FileManagerPath 3 files= %r' % files)
        Path = files = files.split('</path')[0]
    except Exception as e:
        pass
        Path = PathInput
        __log('error in FileManagerPath EXCEPTION: %r' % e)
        
    return Path  
 
def max_age():
    __log('max_age()')
    age = int(ADDONgetSetting('max_age'))*60
    __log('max_age= %r' % age)
    if age <= 0:
        return -1
    else:
        return age
 
def TestInfoTag(module):
    return   ### 2023-11-12 dont use for now TEST
    try:
        ###String XBMCAddon::xbmc::InfoTagRadioRDS::getProgStation	(		)	
        ProgStation = xbmc.Player().getPlayingFile()
        __log(module + ' ProgStation= %r' % ProgStation)
        tag = xbmc.Player().getMusicInfoTag()
        __log(module + ' tag= %r' % tag)
        title = tag.getTitle()
        __log(module + ' title= %r' % title)
        kanal = tag.getGenre()
        __log(module + ' kanal= %r' % kanal)
    except Exception as e:
        pass
        __log(module + ' getProgStation( ERROR: %r' % e)
   
def getKanal():
    try:
        if xbmc.Player().isPlayingAudio():
            ProgStation = xbmc.Player().getPlayingFile()
            __log(module + ' ProgStation= %r' % ProgStation)
            tag = xbmc.Player().getMusicInfoTag()
            __log(module + ' tag= %r' % tag)
            title = tag.getTitle()
            __log(module + ' title= %r' % title)
            kanal = tag.getGenre()
            __log(module + ' kanal= %r' % kanal)
            result = kanal
            if result[0:2] == 'P5':
                result = ADDONgetSetting('selectedp5station')
            elif result[0:2] == 'P4':
                result = ADDONgetSetting('selectedp4station')
            ADDON.setSetting('programplaying',result)
        elif xbmc.Player().isPlayingVideo():
            result = 'Playing Video'
        else:
            result = ''    ### Not playing
        return result
    except Exception as e:
        pass
        __log(module + ' getKanal( ERROR: %r' % e)
        return 'Exception in getKanal: %r' % e
  
def StartProgram(station_id,timestamp):
    try:
        if timestamp == 0:
            timestamp = nowTS()
        __log('StartProgram ADDON %r - %r' % (ADDONname,ADDONid))
        __log('station_id= %r Start @ %r' % (station_id,datestr(TSlts(timestamp),'%H:%M:%S')))
        __log('station_id= %r Start @ %r' % (station_id,timestamp))
        __log('station_id= %r Start @ %r' % (station_id,humantime(timestamp)))
        if not station_id:
            station_id = preferredstation
            __log('playEPG(DEFAULT station_id= %r)' % station_id)
        script = os.path.join(ADDONpath, 'startstation.py')    
        ###script = os.path.join(PATH, 'startstation.py')
        __log('script= %r' % script)
        nameAlarm = ADDONid + '-start-' + onlyAscii(str(station_id))
        __log('nameAlarm= %r' % nameAlarm)
        if timestamp != 0:
            delay = timestamp - nowTS()
        else:
            delay = 0
        if delay < 0:
            delay = 0
        __log('delay= %r' % delay)
        delayHMS = datestrdelta(delay,'%H:%M:%S')
        __log('delayHMS= %r' % delayHMS)
        if delay >= 0 and delay < 24*3600:
            cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),%s,silent)' % (nameAlarm, script, PATH,station_id,delayHMS)
            __log('StartProgram cmd= %r' % cmd)
            
            __log('LastStartStation:' + station_id + ': '+datestr(TSlts(timestamp),'d%dh%Hm%M'))
            ADDONsetSetting('LastStartStation',station_id + ': '+datestr(TSlts(timestamp),'d%dh%Hm%M'))
            ADDONsetSetting('StartStation',station_id)
            xbmc.executebuiltin(cmd)  # Active
    except Exception as e:
        pass
        __log('StartProgram(station_id= %r,timestamp= %r) ERROR: %r' % (station_id,timestamp,e))

def shareLogs(change): ### Only change = True in 'addon.py' only
    change = True   ### may work when settings are in files and not only in settings
    sharepath = ADDONgetSetting('sharepath')
    __log('603 shareLogs sharepath= %r' % sharepath)
    
    dest = 'DestinationNotSetYet'
    try:
        if sharepath != '':
            destname = (str(xbmc.getInfoLabel('System.FriendlyName'))+'_'+ADDONname).replace(' ','')+'_'
            dest = os.path.join(sharepath,destname)
            __log('613 logs to= %r' % dest)
            
            ADDONsetSetting('Excution 1', 'Before Copy Files')
            datapath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
            
            try:
                file = 'DRNU-favorites.txt'    ### Not used at the moment - Used in DR TV app!
                destf = os.path.join(sharepath,file)
                sourf = xbmcvfs.translatePath(os.path.join(datapath, 'favorites.txt'))
                copyOK = xbmcvfs.copy(destf, sourf)
                if not copyOK:
                    __log('Copy of favorites.txt failed')
                __log('619 favorites.txt to= %r' % sourf)
                __log('620 favorites.txt from= %r' % destf)
            except Exception as e:
                pass
                ADDONsetSetting('Exception favorites.txt', repr(e))
            
            if not change  or 1==1:  ### 2013-11-14 always execute
                file = destname+'kodi.log'
                destf = os.path.join(sharepath,file)
                sourf = xbmcvfs.translatePath(os.path.join('special://logpath', 'kodi.log'))
                ###xbmcvfs.copy(sourf, destf)
                if os.path.exists(sourf):
                    copyOK = xbmcvfs.copy(sourf, destf)
                    if not copyOK:
                        __log('Copy of kodi.log failed')
                __log('619 kodi.log from= %r' % sourf)
                __log('620 kodi.log to= %r' % destf)
                
                file = destname+'kodi.old.log'
                destf = os.path.join(sharepath,file)
                sourf = xbmcvfs.translatePath(os.path.join('special://logpath', 'kodi.old.log'))
                ###xbmcvfs.copy(sourf, destf)
                if os.path.exists(sourf):
                    copyOK = xbmcvfs.copy(sourf, destf)
                    if not copyOK:
                        __log('Copy of kodi.old.log failed')
                __log('619 kodi.old.log from= %r' % sourf)
                __log('620 kodi.old.log to= %r' % destf)
                
                sfile = os.path.join(datapath,'*.log')
                sFiles = glob.glob(sfile)
                __log('sfile: %r' % sfile)
                __log('sFiles: %r' % sFiles)
                for file in sFiles:
                    __log('file: %r' % file)
                    destf = os.path.join(sharepath,destname + os.path.basename(file))
                    sourf = xbmcvfs.translatePath(file)
                    __log('sourf: %r' % sourf)
                    if os.path.exists(sourf) :
                        copyOK = xbmcvfs.copy(sourf, destf)
                        if not copyOK:
                            __log('Copy of %r failed'% file)
                    __log('627 *.log from= %r' % sourf)
                    __log('628 *.log to= %r' % destf)
                
                if 1 == 0:   ### Disable: *.log are handled above               
                    file = destname+'addon.log'
                    destf = os.path.join(sharepath,file)
                    sourf = xbmcvfs.translatePath(os.path.join(datapath, 'addon.log'))
                    if os.path.exists(sourf):
                        copyOK = xbmcvfs.copy(sourf, destf)
                        if not copyOK:
                            __log('Copy of addon.log failed')
                    __log('627 addon.log from= %r' % sourf)
                    __log('628 addon.log to= %r' % destf)
                    
                    file = destname+'addonOLD.log'
                    destf = os.path.join(sharepath,file)
                    sourf = xbmcvfs.translatePath(os.path.join(datapath, 'addonOLD.log'))
                    if os.path.exists(sourf):
                        copyOK = xbmcvfs.copy(sourf, destf)
                        if not copyOK:
                            __log('Copy of addonOLD.log failed')
                    __log('627 addonOLD.log from= %r' % sourf)
                    __log('628 addonOLD.log to= %r' % destf)
                    
            ###settingUpdated = False    
            if change :
                file = destname+'settings.cng'
                cngf = os.path.join(sharepath,file)
                localcngf = xbmcvfs.translatePath(os.path.join(datapath, 'settings.cng'))
                ADDONsetSetting('Excution 2', 'cngf = %r' % cngf)
                try:
                    if xbmcvfs.exists(cngf):
                        copyOK = xbmcvfs.copy(cngf, localcngf)
                        if not copyOK:
                            __log('Copy of settings.cng failed')
                            utils.ADDONsetSetting('Exception 1', 'Copy of settings.cng failed')
                        if os.path.isfile(localcngf) :
                            ADDONsetSetting('Excution 3', 'localcngf = %r' % localcngf)
                            file = open(localcngf,'r',encoding='utf-8')
                            desc = file.read()
                            ADDONsetSetting('Excution 4', 'desc = %r' % desc)
                            file.close()
                            params = desc.split('<setting id="')[1]
                            ADDONsetSetting('Excution 5', 'params = %r' % params)
                            param = params.split('"')[0]
                            ADDONsetSetting('Excution 6', 'param = %r' % param)
                            values = params.split('>')[1].split('<')[0]
                            ADDONsetSetting('Excution 7', 'values = %r' % values)
                            ADDONsetSetting(param, values)
                            xbmcvfs.delete(cngf)
                            xbmcvfs.delete(localcngf)
                            ###settingUpdated = True
                    else:
                        __log('No settings.cng - No update')
                except Exception as e:
                    pass
                    ADDONsetSetting('Exception', repr(e))
            
            ADDONsetSetting('Excution 9', 'Before Copy settings.xml')
            if not change :
                file = destname+'settings.xml'
                destf = os.path.join(sharepath,file)
                sourf = xbmcvfs.translatePath(os.path.join(datapath, 'settings.xml'))
                if os.path.exists(sourf):
                    copyOK = xbmcvfs.copy(sourf, destf)
                    
                    if not copyOK:
                        __log('Copy of settings.xml failed')
                    
                __log('653 settings.xml from= %r' % sourf)
                __log('654 settings.xml to= %r' % destf)
                
            file = destname+'settingsOLD.xml'
            destf = os.path.join(sharepath,file)
            sourf = xbmcvfs.translatePath(os.path.join(datapath, 'settingsOLD.xml'))
            if os.path.exists(sourf):
                copyOK = xbmcvfs.copy(sourf, destf)
                
                if not copyOK:
                    __log('Copy of settingsOLD.xml failed')
                
            __log('653 settingsOLD.xml from= %r' % sourf)
            __log('654 settingsOLD.xml to= %r' % destf)
            
    except Exception as  e:
        pass 
        __log('Change setting or Copy shareLogs to sharepath= %r FAILED: %r' % (dest, e))
  
def deleteFile(file):
    tries    = 0
    maxTries = 10
    maxSleep = 50
    while os.path.exists(file) and tries < maxTries:
        try:
            os.remove(file)
            __log('remove file: %r' % file)
            break
        except Exception as e:
            __log('deleteFile Exception: %r' % e)
            xbmc.sleep(maxSleep)
            tries = tries + 1

def ADDONresetSettingsToIni():
    file = os.path.join(datapath,'*.set')
    Files = glob.glob(file)
    # delete setting*.set files
    for file in Files:
        __log('Delete file: %r' % file)
        deleteFile(file)
    
def now():   ### Local time
    dt_obj= datetime.now()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
    
def todayDate():
    dt_obj= datetime.today().date()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
      
def AdjustDateTime(dateTS,Hours,Minutes):
    logdev(module,'AdjustDateTime(dateTS= %r,Hours= %r,Minutes= %r)' % (dateTS,Hours,Minutes))
    ###dt_obj = datetime.fromtimestamp(dateTS) + timedelta(hours= int(Hours), minutes= int(Minutes), seconds= 0, milliseconds= 0)
    ###logdev(module,'AdjustDateTime x dt_obj= %r' % dt_obj)
    ###time_tuple = dt_obj.timetuple()
    ###logdev(module,'AdjustDateTime time_tuple= %r' % time_tuple)
    ###timestamp = int(time.mktime(time_tuple))
    timestamp = dateTS + int(Hours)*60*60 + int(Minutes)*60
    logdev(module,'AdjustDateTime timestamp= %r' % timestamp)
    return(timestamp)
  
def humantime(ts):   ### Timestamp to human time
    if isinstance(ts, int):
        dt = datetime.fromtimestamp(ts)
    ###elif isinstance(ts, datetime.datetime):
    elif isinstance(ts, datetime):
        dt = ts
    else:
        return ts
    ###dt = datetime.datetime.fromtimestamp(ts)
    ht = dt.strftime("%Y-%m-%d %H:%M:%S")
    ###ht = dt.strftime("%m-%d %H:%M")
    return ht
    
def getChannelVolumen(channel):
    vol = 100
    try:
        logdev(module,'getChannelVolumen channel= %r' % channel)
        volumens = ADDONgetSetting('volumenschannels').split(',')
        logdev(module,'getChannelVolumen channel= %r' % volumens)
        for volum in volumens:
            volu = volum.split('@')
            if volu[0]==channel:
                vol = int(volu[1])
                break
    except Exception as e:
        pass
        logdev(module,'getChannelVolumen for Channel= %r\nERROR: %r' % (channel,e))
    return vol

def setChannelVolumen(station_id):
    try:
        if ADDONgetSetting('autovolumen') == 'true':
            __log('Set Volume')
            ### volumens = 100@6:30, 80@23:30
            testnow = now()
            today   = todayDate()
            ChannelVolumen = getChannelVolumen(station_id)
            __log('station_id= %r' % station_id)
            __log('ChannelVolumen= %r' % ChannelVolumen)
            __log('Set testnow= %r, today= %r' % (humantime(testnow), humantime(today)))
            
            defaultvolumen = ADDONgetSetting('defaultvolumen')
            if defaultvolumen == '':
                __log("1 defaultvolumen == ''")
                defaultvolumen = ADDONgetSetting('defaultvolumen')
                if defaultvolumen == '':
                    __log("2 defaultvolumen == ''")
                    defaultvolumen = '100'
            ADDONsetSetting('defaultvolumen',defaultvolumen)
            newvol = defaultvolumen
            __log('newvol= %r' % newvol)
            volumens = ADDONgetSetting('volumens').split(',')
            __log('Set Volumens= %r' % volumens)
            for volumen in volumens:
                __log('Set Volumen= %r' % volumen)
                vol = volumen.split('@')
                volu = vol[0]
                vtim = vol[1].split(':')
                __log('Set vtim= %r' % vtim)
                vtimadjusted = AdjustDateTime(today,vtim[0],vtim[1])
                __log('Set vtimadjusted= %r' % humantime(vtimadjusted))
                if vtimadjusted <= testnow:
                    __log('1 newvol= %r' % newvol)
                    newvol = str(int(volu) * int(ChannelVolumen) * int(defaultvolumen) // 10000 )
                    __log('2 newvol= %r' % newvol)
            xbmc.executebuiltin( "SetVolume(%s,showvolumebar)" % ( newvol ) )
            __log('1 Set Volumen now to %r' % newvol)
            ADDONsetSetting('setvolumen',newvol)
            newvol = ADDONgetSetting('setvolumen')
            __log('2 Set Volumen now to %r' % newvol)
        
    except Exception as e:
        pass
        __log('Set Volumen ERROR: %r' % e)
        ADDONsetSetting('setvolumen','ERROR: %r' % e)
    
def Numeric(timeT,funk):
    dialog = xbmcgui.Dialog()
    keyboard=dialog.numeric(2, funk, timeT)
    return keyboard

def addHeader(link):
    ### urllib.request.Request(url, data=None, headers={}, origin_req_host=None, unverifiable=False, method=None)
    logdev(module,'addHeader(link= %r)' % link)
    request = urllib.request.Request(link, data=None, headers={}, origin_req_host=None, unverifiable=False, method=None)
    request.add_header('Accept', 'application/json')
    request.add_header('x-dr-mu-subscriber-id', 'Swagger')
    logdev(module,'request.get_full_url= %r' % request.get_full_url())
    return request

def readlink(link,outfile,cmodule):
    logdev(module,'err readlink(link= %r, outfile= %r) in module: %r' % (link,outfile,cmodule))
    response = urlopen(addHeader(link))
    logdev(module,'err readlink 2')
    data = response.read()
    logdev(module,'err readlink 3')
    logdev(module,'err link=%r\ndata= %r\noutfile= %r' % (link,data,outfile))
    if outfile != '':
        logdev(module,'err readlink 4')
        makeOldFile(outfile)
        logdev(module,'err readlink 5')
        with open(outfile,'wb') as output:
            logdev(module,'err readlink 6')
            output.write(data)
    logdev(module,'err readlink 7')
    return data

def file_age_in_seconds(filename): 
    try: 
        return int(time.time() - os.path.getmtime(filename)) 
    except Exception as e:
        pass
        __log('file_age_in_seconds(filename= %r) EXCEPTION: %r' % (filename, e))
        #on any failure condition 
        return -1  

def readChannelEPG(station_id,radioEPG,maxage):
    try:
        __log('403 radioEPG= %r' % radioEPG)
        if radioEPG == '':
            resp = 'No EPG'
        else:
            resp = ''
            Channelfile = os.path.join(datapath, station_id + '.pickle') 
            if xbmcvfs.exists(Channelfile):
                """
                with open('filename.pickle', 'wb') as handle:
                    pickle.dump(a, handle, protocol=pickle.HIGHEST_PROTOCOL)

                with open('filename.pickle', 'rb') as handle:
                    b = pickle.load(handle)
                """
                fileage  = file_age_in_seconds(Channelfile)
                filesize = os.path.getsize(Channelfile)
                __log('406 fileage= %r' % fileage)
                resp = ''
                if fileage != -1 and fileage < maxage and filesize > 100:
                    try:
                        with open(Channelfile, 'rb') as picklehandle:
                            resp = pickle.load(picklehandle)
                        __log('411 read Channelfile= %r' % Channelfile) 
                    except Exception as e:
                        pass
                        __log('414 read error Channelfile.pickle= %r' % e)
            if resp == '':
                # This restores the same behavior as before.
                context = ssl._create_unverified_context()
                __log('418 radioEPG= %r' % radioEPG)
                webUrl = urlopen(addHeader(radioEPG), context=context)
                __log('webUrl= %r' % webUrl)
                #get the result code and print it
                result_code = webUrl.getcode()
                __log('result_code= %r' % result_code)
                # read the data from the URL and print it
                resp = webUrl.read()
                __log('1 resp= %r' % resp)
                testtext = b'Klik her, hvis du ikke bliver sendt videre automatisk'     
                __log('429 Channelfile= %r' % Channelfile)
                try:
                    with open(Channelfile, 'wb') as picklehandle:
                        pickle.dump(resp, picklehandle, protocol=pickle.HIGHEST_PROTOCOL)
                    __log('434 Written Channelfile= %r' % Channelfile)    
                except Exception as e:
                    pass
                    __log('437 write error Channelfile.pickle= %r' % e)
                if testtext in resp:
                    resp = ''
                __log('2 resp= %r' % resp)
    except Exception as e:
        pass
        __log('readChannelEPG EXCEPTION: %r' % e)
        resp = 'EPG EXCEPTION: %r' % e
    __log('1154 resp= %r' % resp)
    return resp
    
def notnone(cat):
    if cat == None:
        return ''
    else:
        return cat
        
def makeOldFile(file):
    if os.path.isfile(file):
        ext = '.' + file.split('.')[-1]
        new = 'OLD' + ext
        oldfile = file.replace(ext,new)
        logdev(module,'oldfile= %r' % oldfile)
        shutil.copyfile(file, oldfile)

def notificationsend(name):
    # Show menuentry when finished OK - but not when run in the background
    logdev(module, name)
    liz=xbmcgui.ListItem(name)
    liz.setProperty('IsPlayable','false')
    try:
        xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url='url',listitem = liz, isFolder = False) 
        logdev(module, 'notificationsend - Finished in foreground with menu item')
    except Exception as  e:
        pass
        logdev(module,'error in notificationsend: ' + repr(e))
        logdev(module,'notificationsend - Finished in background - no menu item')

def testPrograms():
    notificationUPD('Test recording programs')
    try:  ### Get system timezone
        timezone = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Settings.GetSettingValue", "params": {"setting": "locale.timezone"}, "id": 1}')
        logdev(module,'Kodi timezone= %r' % timezone)
    except Exception as  e:
            pass
            logdev(module,'Get timezone error= %r' % e)
    try:   ### Test if ffmpeg is installed
        if runCommandTest('ffmpeg'):
            notificationUPD('FFMPEG has been installed!')
            logdev(module,'FFMPEG installed!')
        else:
            logdev(module,'FFMPEG NOT installed!')
    except Exception as  e:
            pass
            logdev(module,'Get ffmpeg error= %r' % e)
    try:   ### Test if rtmpdump is installed
        if runCommandTest('rtmpdump'):
            logdev(module,'RTMPDUMP installed!')
        else:
            logdev(module,'RTMPDUMP NOT installed!')
    except Exception as  e:
            pass
            logdev(module,'Get rtmpdump error= %r' % e)
    try:   ### Test if 7zip is installed
        if runCommandTest('7z'):
            logdev(module,'7z installed!')
        else:
            logdev(module,'7z NOT installed!')
    except Exception as  e:
            pass
            logdev(module,'Get 7z error= %r' % e)
    try:   ### Test if xarchiver -v is installed
        if runCommandTest('xarchiver -v'):
            logdev(module,'xarchiver -v installed!')
        else:
            logdev(module,'xarchiver -v NOT installed!')
    except Exception as  e:
            pass
            logdev(module,'Get xarchiver -v error= %r' % e)

def FindDirectPrograms():
    directprograms= []
    ###logdev('FindDirectPrograms','directrecording= ' + repr(directrecording))
    if directrecording == '2':   ### HD
        directfile = os.path.join(progpath,'resources','directchannelshd.csv')
        logdev(module,'FindDirectPrograms: directfile HD= ' + repr(directfile))
    if directrecording == '1':   ### SD
        directfile = os.path.join(progpath,'resources','directchannelssd.csv')
        #logdev('FindDirectPrograms','directfile SD= ' + repr(directfile))
    if not directrecording == '1' and not directrecording == '2':
        logdev(module,'FindDirectPrograms: No directfile!')
        return directprograms
        
    try: 
        csvfile = open(directfile,'r')
    except Exception as  e:
        logdev(module,'FindDirectPrograms: error in open file ' + repr(directfile) +': ' + repr(e))
        pass
        return directprograms
    line0 = csvfile.readline()
    #logdev('FindDirectPrograms','First line: ' + repr(line0))
    nextline=csvfile.readline().strip().split(',')
    #logdev('FindDirectPrograms','Next line: ' + repr(nextline))
    while not nextline == [''] :
        directprograms.append(nextline)
        #logdev('FindDirectPrograms','directprograms: ' + repr(directprograms))
        nextline=csvfile.readline().strip().split(',')
        #logdev('FindDirectPrograms','Next line: ' + repr(nextline))
        #logdev('FindDirectPrograms','len(nextline): ' + repr(len(nextline)))
        if not len(nextline) == 3:
            break 
        if len(nextline) == 0:
            break 
    csvfile.close()
    return directprograms
        
###<setting id="enable_record_drdk_directly" type="enum" values="Off|SD|HD" label="[COLOR red][B]Enable Recording DR.dk directly[/B][/COLOR]" default="0"/>
### cat='147'  DR1 http://dr01-lh.akamaihd.net/i/dr01_0@147054/master.m3u8?b=100-3000
### cat='148'  DR2 http://dr02-lh.akamaihd.net/i/dr02_0@147055/master.m3u8?b=100-3000
### cat='259'  DR3 http://dr03-lh.akamaihd.net/i/dr03_0@147056/master.m3u8?b=100-3000
### cat='230'  DRK http://dr04-lh.akamaihd.net/i/dr04_0@147057/master.m3u8?b=100-3000
### ffmpeg -v verbose -y -i "http://dr04-lh.akamaihd.net/i/dr04_0@147057/master.m3u8?b=100-3000" -c:v libx264 -c:a aac -ac 1 -strict -2 -crf 18 -profile:v baseline -maxrate 400k -bufsize 1835K  -f flv "/home/hans/Videos/test.flv"
### http://dr05-lh.akamaihd.net/i/dr05_0@147058/master.m3u8?b=100-3000
### http://dr06-lh.akamaihd.net/i/dr06_0@147059/master.m3u8?b=100-3000

###drprograms=FindDirectPrograms()
"""
directrecording = ADDONgetSetting('enable_record_drdk_directly')
drprograms=[]
if directrecording == '2':   ### HD
    
    drprograms.append(['147','DR1','http://dr01-lh.akamaihd.net/i/dr01_0@147054/master.m3u8?b=600-3000'])
    drprograms.append(['148','DR2','http://dr02-lh.akamaihd.net/i/dr02_0@147055/master.m3u8?b=600-3000'])
    drprograms.append(['259','DR3','http://dr03-lh.akamaihd.net/i/dr03_0@147056/master.m3u8?b=600-3000'])
    drprograms.append(['230','DRK','http://dr04-lh.akamaihd.net/i/dr04_0@147057/master.m3u8?b=600-3000'])
    drprograms.append(['232','DR Ramasjang','http://dr05-lh.akamaihd.net/i/dr05_0@147058/master.m3u8?b=600-3000'])
    drprograms.append(['231','DR Ultra','http://dr06-lh.akamaihd.net/i/dr06_0@147059/master.m3u8?b=600-3000'])
    drprograms.append(['17',',BBC One','http://vs-hls-uk-live.akamaized.net/pool_32/live/bbc_one_london/bbc_one_london.isml/bbc_one_london-pa3=96000-video=1604032.norewind.m3u8'])
    drprograms.append(['312','BBC One HD','http://vs-hls-uk-live.akamaized.net/pool_30/live/bbc_one_hd/bbc_one_hd.isml/bbc_one_hd-pa4%3d128000-video%3d5070016.m3u8'])
    drprograms.append(['18','BBC Two','http://vs-hls-uk-live.akamaized.net/pool_31/live/bbc_two_hd/bbc_two_hd.isml/bbc_two_hd-pa4=128000-video=5070016.m3u8'])
    drprograms.append(['311','BBC Two HD','http://vs-hls-uk-live.akamaized.net/pool_31/live/bbc_two_hd/bbc_two_hd.isml/bbc_two_hd-pa4=128000-video=5070016.m3u8'])
    drprograms.append(['25','BBC Four HD','http://vs-hls-uk-live.akamaized.net/pool_33/live/bbc_four_hd/bbc_four_hd.isml/bbc_four_hd-pa4%3d128000-video%3d5070016.m3u8'])
    drprograms.append(['27','CBeebies','http://vs-hls-uk-live.akamaized.net/pool_2/live/cbeebies_hd/cbeebies_hd.isml/cbeebies_hd-pa4=128000-video=5070016.m3u8'])
    drprograms.append(['241','BBC News','http://vs-hls-uk-live.akamaized.net/pool_34/live/bbc_news_channel_hd/bbc_news_channel_hd.isml/bbc_news_channel_hd-pa4=128000-video=5070016.m3u8'])
    drprograms.append(['3597','BBC News HD','http://vs-hls-uk-live.akamaized.net/pool_34/live/bbc_news_channel_hd/bbc_news_channel_hd.isml/bbc_news_channel_hd-pa4=128000-video=5070016.m3u8'])
    logdev('utils.py','Direct Programs= %s' % repr(drprograms))
if directrecording == '1':   ### SD
    drprograms.append(['147','DR1','http://dr01-lh.akamaihd.net/i/dr01_0@147054/master.m3u8?b=100-1000'])
    drprograms.append(['148','DR2','http://dr02-lh.akamaihd.net/i/dr02_0@147055/master.m3u8?b=100-1000'])
    drprograms.append(['259','DR3','http://dr03-lh.akamaihd.net/i/dr03_0@147056/master.m3u8?b=100-1000'])
    drprograms.append(['230','DRK','http://dr04-lh.akamaihd.net/i/dr04_0@147057/master.m3u8?b=100-1000'])
    drprograms.append(['232','DR Ramasjang','http://dr05-lh.akamaihd.net/i/dr05_0@147058/master.m3u8?b=100-1000'])
    drprograms.append(['231','DR Ultra','http://dr06-lh.akamaihd.net/i/dr06_0@147059/master.m3u8?b=100-1000'])
    drprograms.append(['17',',BBC One','http://vs-hls-uk-live.akamaized.net/pool_32/live/bbc_one_london/bbc_one_london.isml/bbc_one_london-pa3=96000-video=1604032.norewind.m3u8'])
    drprograms.append(['312','BBC One HD','http://vs-hls-uk-live.akamaized.net/pool_30/live/bbc_one_hd/bbc_one_hd.isml/bbc_one_hd-pa4%3d128000-video%3d5070016.m3u8'])
    drprograms.append(['18','BBC Two','http://vs-hls-uk-live.akamaized.net/pool_31/live/bbc_two_hd/bbc_two_hd.isml/bbc_two_hd-pa4=128000-video=5070016.m3u8'])
    drprograms.append(['311','BBC Two HD','http://vs-hls-uk-live.akamaized.net/pool_31/live/bbc_two_hd/bbc_two_hd.isml/bbc_two_hd-pa4=128000-video=5070016.m3u8'])
    drprograms.append(['25','BBC Four HD','http://vs-hls-uk-live.akamaized.net/pool_33/live/bbc_four_hd/bbc_four_hd.isml/bbc_four_hd-pa4%3d128000-video%3d5070016.m3u8'])
    drprograms.append(['27','CBeebies','http://vs-hls-uk-live.akamaized.net/pool_2/live/cbeebies_hd/cbeebies_hd.isml/cbeebies_hd-pa4=128000-video=5070016.m3u8'])
    drprograms.append(['241','BBC News','http://vs-hls-uk-live.akamaized.net/pool_34/live/bbc_news_channel_hd/bbc_news_channel_hd.isml/bbc_news_channel_hd-pa4=128000-video=5070016.m3u8'])
    drprograms.append(['3597','BBC News HD','http://vs-hls-uk-live.akamaized.net/pool_34/live/bbc_news_channel_hd/bbc_news_channel_hd.isml/bbc_news_channel_hd-pa4=128000-video=5070016.m3u8'])
    logdev('utils.py','Direct Programs= %s' % repr(drprograms)) 
if directrecording == '0':   ### Off
    logdev('utils.py','No directly recording of Programs!')
    
try:
    DiReCt=FindDirectPrograms()
    logdev('utils.py','Direct Programs from file: %s' % repr(DiReCt))
except Exception as  e:
    logdev('FindDirectPrograms','error in function  FindDirectPrograms(): ' + repr(e))
    pass
"""

def directprogramsNTV(cat):
    drprograms=FindDirectPrograms()
    recorddrdirectly=''
    if directrecording > '0':   ### SD, HD
        for index in range(0, len(drprograms)): 
            if cat ==  drprograms[index][0]:
                recorddrdirectly = drprograms[index][2]
                #xbmc.log('record-ffmpeg.py: Directly record of DR Program %s' % drprograms[index][1])
                return recorddrdirectly
    return recorddrdirectly
""" MUST RUN IN RECORDINGS  
def directprograms(cat):
    ### Channel name has (D) in the end to be Direct or not roqtv.com in url
    url = urlFromCat(cat)
    
    if not 'roq-tv.net' in url:
        return url
    else:
        return ''
"""

def getGuiSetting(guisetting,defaultsetting):
    ### guisettings.xml <webserverport>8081</webserverport>
    ### utils.getGuiSetting(guisetting,defaultsetting)
    ###utils.getGuiSetting('webserverport','8080')
    
    try:
        guisettings = xbmcvfs.translatePath(os.path.join('special://masterprofile' , 'guisettings.xml'))
        settingsfile = open(guisettings,'r')
        settings = settingsfile.read()
        webport = settings.split('<' + str(guisetting) + '>')
        webport = webport[1].split('</' + str(guisetting) + '>')[0]
    except Exception as  e:
        logdev('getGuiSetting','error in get ' + str(getGuiSetting) +': ' + repr(e))
        pass
        webport = str(defaultsetting)  ### Default
    logdev('getGuiSetting','Configured ' + str(getGuiSetting) +': ' + repr(webport))
    return webport

def TVguide():
    try:
        TVguideNr= int(ADDONgetSetting('tvguidenr'))
    except:
        pass
        TVguideNr = 0
        ADDONsetSetting('tvguidenr',str(TVguideNr))
    # 0= wozboxtvguide/roq tv rec|1= tvguide|2= ftvguide|3= ivueguide|4= custom (if empty search all known)|5= no tv guide search
    #log('TVguideNr',repr(TVguideNr))
    if TVguideNr == 0:
        ###TVguide= [['script.wozboxtvguide2.0','source.db']]
        TVguide= [[ADDONid,'recordings_adc.db']]
    elif TVguideNr == 1:
        TVguide= [['script.tvguide','source.db']]
    elif TVguideNr == 2:
        TVguide= [['script.ftvguide','source.db']]
    elif TVguideNr == 3:
        TVguide= [['script.ivueguide','master.db']]
    elif TVguideNr == 4:
        #TVguide= [ ['script.tvguide','source.db']]
        ExtraGuide= ''
        ExtraGuideDB= ''
        ExtraGuidePathDB= ADDONgetSetting('tvguidenotificationsDB')
        ExtraGuideList= ExtraGuidePathDB.split(os.sep)
        ExtraGuide= ExtraGuideList[-2]
        ExtraGuideDB= ExtraGuideList[-1]
        if ExtraGuide != '' and ExtraGuideDB != '':
            TVguide= [[ExtraGuide,ExtraGuideDB]]
        else:
            # If Extra TV Guide not complete - try all
            TVguide= [['script.wozboxtvguide2.0','source.db'], ['script.tvguide','source.db'],['script.ftvguide','source.db'],['script.ivueguide','master.db']]
    else:
        # No search in TV Guide
        TVguide= []
    #log('findtvguidenotifications TVguide',repr(TVguide))
    if len(TVguide) != 0:
        ADDONsetSetting('activetvguide',repr(TVguide[0][0]))
    else:
        ADDONsetSetting('activetvguide','none')
    return TVguide
    
def ChannelNameLookuponWeb(cat):
    ####p rint 'default.py ChannelName(cat)= %s' % str(cat)
    net.set_cookies(cookie_jar)
    imageUrl=ADDON.getAddonInfo('name') + '/res/content/tv/'
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20')
    url='&mwAction=category&xbmc=1&mwData={"id":"%s","time":"%s","type":"tv"}'%('-2',now)
    ####p rint 'default.py XXXX site+url= %s%s'  % (site,url)
    link = net.http_GET(site+url, headers={'User-Agent' : UA}).content
    ####p rint 'default.py XXXX ChannelName link= %s' % str(repr(link))
    data = json.loads(link)
    channels=data['contents']
    ####p rint 'default.py cat= %s, CHANNELS= %s' % (cat,str(repr(channels)))
    for field in channels:
        channel      =  field['id']
        if channel == cat:
            name         =  field['name'].encode("utf-8")
            #notification( 'name= %s, channel= %s' % (name,channel))
            return name
    notification( 'NOT FOUND: channel= %s' % (cat))
    return 'no name'

def logdebug(module,message):
    if ADDONgetSetting('DebugRecording')=='true':
        log(module,message)

def notificationUPD(message, time = 0):
    if notifyduringepgupdate:
        notificationUPD(message, time = 0)
      
def notificationforced(message, time = 0):
    if (not ADDONgetSetting('RecursiveSearch')=='true' or ADDONgetSetting('NotifyOnSearch')=='true'):
        message = message.replace(',',  '')     ### No commas in text allowed
        if time == 0:
            try:
                time = int(ADDONgetSetting('NotificationTime'))
            except:
                pass
            if time == 0:
                time = 30
        ### header = '[B][COLOR lightblue]' + ADDON.getAddonInfo('name') + '....................[/COLOR][/B]'
        header = ADDON.getAddonInfo('name')
        cmd  = 'Notification(%s, %s, %r, %s)' % (header, message, time*1000, IMAGE)  ### 2023-04-26  
        ### if xbmc.getCondVisibility('Player.HasMedia') != True :   ### Use this to force notification otherwhise the next 2019-03-10
        if ADDONgetSetting('ShowNotifications') == 'true' and xbmc.getCondVisibility('Player.HasMedia') != True :
            xbmc.executebuiltin(cmd)
      
def notification(message, time = 0):
    ###wid = xbmcgui.getCurrentWindowId()
    ###widActive = xbmc.getCondVisibility('Window.IsActive(wid)')
    ###wname = xbmc.getInfoLabel('currentwindow')
    ###now= datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ### #Use locking to write test messages as filenames
    ###locking.recordLock('%r WindowID= %r, widActive= %r, message= %r' % (now,wid,widActive,message))
    if (not ADDONgetSetting('RecursiveSearch')=='true' or ADDONgetSetting('NotifyOnSearch')=='true'):
        ###message = message.replace('"',  '')
        ###message = message.replace('\'', '')
        message = message.replace(',',  '')     ### No commas in text allowed
        ###message = message.replace('(',  '')
        ###message = message.replace(')',  '')
        
        if time == 0:
            try:
                time = int(ADDONgetSetting('NotificationTime'))
            except:
                pass
            if time == 0:
                time = 30

        ### header = '[B][COLOR lightblue]' + ADDON.getAddonInfo('name') + '....................[/COLOR][/B]'
        header = ADDON.getAddonInfo('name')

        ###cmd  = 'XBMC.Notification(%s, %s, %r, %s)' % (header, message, time*1000, IMAGE)  ### 2017-07-27
        cmd  = 'Notification(%s, %s, %r, %s)' % (header, message, time*1000, IMAGE)  ### 2023-04-26
        logdev(module,'notification: ' + message)
        if ADDONgetSetting('ShowNotifications') == 'true' and xbmc.getCondVisibility('Player.HasMedia') != True :
            xbmc.executebuiltin(cmd)
    
def notificationboxadd(message):
    oldmessage= ADDONgetSetting('allmessages')
    if oldmessage == '':
        allmessages= message
    else:
        allmessages= message + '/' + oldmessage
    ADDONsetSetting('allmessages',allmessages)
    
def notificationbox(message):
    oldmessage= ADDONgetSetting('allmessages')
    if oldmessage == '':
        allmessages= message
    else:
        allmessages= message + '[CR]' + oldmessage
    ADDONsetSetting('allmessages',allmessages)
    logdev('notificationbox',allmessages)
    if ADDONgetSetting('ShowNotifications') == 'true' and xbmc.getCondVisibility('Player.HasMedia') != True :
        xbmcgui.Dialog().ok( ADDON.getAddonInfo('name'), allmessages)
    ADDONsetSetting('allmessages','')
        
def folderwritable(path):
    if os.access(path, os.W_OK):
        return True
    else:
        if '://' in path:
            return True
        else:
            if path=='':
                xbmcgui.Dialog().ok( ADDON.getAddonInfo('name'), '[COLOR red]utils.py folderwritable: ERROR[/COLOR]', '[Empty path]', 'The folder is not writable! \nGoto Settings/Recording/Set Record Path \nand set that to a writable path \nor disable recording')
            else:
                xbmcgui.Dialog().ok( ADDON.getAddonInfo('name'), '[COLOR red]utils.py folderwritable: ERROR[/COLOR]', path, 'The folder is not writable! \nGoto Settings/Recording/Set Record Path \nand set that to a writable path \nor disable recording')
            
            return False

def filterfalse(predicate, iterable):
    # filterfalse(lambda x: x%2, range(10)) --> 0 2 4 6 8
    if predicate is None:
        predicate = bool
    for x in iterable:
        if not predicate(x):
            yield x

def unique_everseen(iterable, key=None):
    "List unique elements, preserving order. Remember all elements ever seen."
    # unique_everseen('AAAABBBCCDAABBB') --> A B C D
    # unique_everseen('ABBCcAD', str.lower) --> A B C D
    seen = set()
    seen_add = seen.add
    if key is None:
        for element in filterfalse(seen.__contains__, iterable):
            seen_add(element)
            yield element
    else:
        for element in iterable:
            k = key(element)
            if k not in seen:
                seen_add(k)
                yield element

def uniquecolon(items):
    # ###p rint 'utils.py uniquecolon(items)= %s' % repr(items) 
    listitems=items.split(':')
    result=':'.join(unique_everseen(listitems))
    # ###p rint 'utils.py uniquecolon(items) result= %s' % repr(result) 
    return result
    
def FindPlatform():
    # Find the actual platform
    Platform = ''
    try:
        kodilog = xbmcvfs.translatePath(os.path.join('special://logpath' , 'kodi.log'))
        try: csvfile = open(kodilog,'r')
        except:
            pass
            kodilog = xbmcvfs.translatePath(os.path.join('special://logpath' , 'xbmc.log'))
            try: csvfile = open(kodilog,'r')
            except:
                pass
                kodilog = xbmcvfs.translatePath(os.path.join('special://logpath' , 'tvmc.log'))
                try: csvfile = open(kodilog,'r')
                except:
                    pass
                    kodilog = xbmcvfs.translatePath(os.path.join('special://logpath' , 'spmc.log'))
                    try: csvfile = open(kodilog,'r')
                    except:
                        pass
                        logdev('FindPlatform','csvfile not found')
                    """
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: -----------------------------------------------------------------------
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: Starting Kodi (18.2 Git:20190422-f264356). Platform: Linux x86 64-bit
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: Using Release Kodi x64 build
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: Kodi compiled 2019-04-22 by GCC 7.3.0 for Linux x86 64-bit version 4.15.18 (266002)
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: Running on Ubuntu 18.04.2 LTS, kernel: Linux x86 64-bit version 4.18.0-17-generic
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: FFmpeg version/source: 4.0.3-Kodi
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: Host CPU: Intel(R) Core(TM) i7-3517U CPU @ 1.90GHz, 4 cores available
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: special://xbmc/ is mapped to: /usr/share/kodi
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: special://xbmcbin/ is mapped to: /usr/lib/x86_64-linux-gnu/kodi
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: special://xbmcbinaddons/ is mapped to: /usr/lib/x86_64-linux-gnu/kodi/addons
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: special://masterprofile/ is mapped to: /home/hans/.kodi/userdata
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: special://envhome/ is mapped to: /home/hans
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: special://home/ is mapped to: /home/hans/.kodi
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: special://temp/ is mapped to: /home/hans/.kodi/temp
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: special://logpath/ is mapped to: /home/hans/.kodi/temp
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: The executable running is: /usr/lib/x86_64-linux-gnu/kodi/kodi-x11
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: Local hostname: fabses-UX31A
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: Log File is located: /home/hans/.kodi/temp/kodi.log
2019-04-23 11:04:24.525 T:139655326972032  NOTICE: -----------------------------------------------------------------------
                    """


        line = csvfile.readline()   ### Read first 8 lines
        line += csvfile.readline()
        line += csvfile.readline()
        line += csvfile.readline()
        line += csvfile.readline()
        line += csvfile.readline()
        line += csvfile.readline()
        line += csvfile.readline()
        Platform = line.split('Platform: ')[1].split('-bit')[0].strip()+'-bit'
        ADDONsetSetting('platform',Platform)
        RunningOn = line.split('Running on ')[1].split(' ')[0].strip()
        ADDONsetSetting('runningon',RunningOn)
        logdev('Platform', repr(ADDONgetSetting('platform')))   # Put in LOG
        logdev('RunningOn', repr(ADDONgetSetting('runningon')))   # Put in LOG
        logdev('OS', os.environ['OS'])  # Put in LOG
    except Exception as e: 
        pass
        logdev('FindPlatform','FAILED: ' + repr(e))   # Put in LOG
    finally:
        csvfile.close()
    return Platform

def rtmpdumpFilename():
    if ADDONgetSetting('DebugRecording')=='false': #dont update Paltform if debugging recordings
        try:
            Platform = FindPlatform()
            ADDONresetSetting('osplatform','')
            if Platform == 'Windows NT x86 32-bit':
                ADDONsetSetting('os','11')
            elif Platform == 'Windows NT x86 64-bit':
                ADDONsetSetting('os','11')
            elif Platform == 'Android ARM 32-bit':
                ADDONsetSetting('os','13')
            elif Platform == 'Android x86 32-bit':
                ADDONsetSetting('os','13')
            elif Platform == 'Linux x86 64-bit':
                ADDONsetSetting('os','7')
            elif Platform == 'Linux x86 32-bit':
                ADDONsetSetting('os','6')
            else:
                log ('rtmpdumpFilename: ', 'Your platform= %s has not been set automatically!' % repr(Platform))  # Put in LOG
        except:
            pass
            log ('rtmpdumpFilename: ', 'Failed to automatically update platform!')  # Put in LOG
        ADDONsetSetting('osplatform',ADDONgetSetting('os'))
        logdev('rtmpdumpFilename','Running on %s' % repr( ADDONgetSetting('runningon')))
        if 'OpenELEC' in ADDONgetSetting('runningon'):
            ADDONsetSetting('os','12')
        if 'samsung' in ADDONgetSetting('runningon'):
            ADDONsetSetting('os','13')
        if 'WOZTEC' in ADDONgetSetting('runningon'):
            ADDONsetSetting('os','13')
        if 'MBX' in ADDONgetSetting('runningon'): 
            ADDONsetSetting('os','13')
        if 'Genymotion' in ADDONgetSetting('runningon'): 
            ADDONsetSetting('os','13')
        # Enable the following two lines to test running on Ubuntu!
        #if 'Ubuntu' in ADDONgetSetting('runningon'):  # ONLY TEST
        #   ADDONsetSetting('os','13')
    quality = ADDONgetSetting('os')
    log ('rtmpdumpFilename', 'quality= %s' %quality)
    #if quality == '0':
    #   return 'androidarm/rtmpdump'
    #elif quality == '1':
    #   return 'android86/rtmpdump'
    #el
    if quality == '2':
        return 'atv1linux/rtmpdump'
    elif quality == '3':
        return 'atv1stock/rtmpdump'
    elif quality == '4':
        return 'atv2/rtmpdump'
    elif quality == '5':
        return 'ios/rtmpdump'
    elif quality == '6':
        return 'linux32/rtmpdump'
    elif quality == '7':
        return 'linux64/rtmpdump'
    elif quality == '8':
        return 'osx106/rtmpdump'
    elif quality == '9':
        return 'osx107/rtmpdump'
    elif quality == '10':
        return 'pi/rtmpdump'
    elif quality == '11':
        return 'win/rtmpdump.exe'
    elif quality == '12':
        return '/usr/bin/rtmpdump'
    elif quality == '13' or quality == '0' or quality == '1':
        return  '/system/vendor/bin/rtmpdump' # HOTFIX Android - rtmpdump moved to /system/bin (using build in librtmp.so from kodi)
    else:
        logdev('rtmpdumpFilename: ','Your platform= %s has not been set automatically!' % repr(Platform))  # Put in LOG
        return

def libPath():
    quality = ADDONgetSetting('os')
    log ('libPath', 'quality= %s' %quality)
    #if quality == '0':
    #   return os.path.join(ADDON.getAddonInfo('path'),'rtmpdump', 'androidarm')
    #elif quality == '1':
    #   return os.path.join(ADDON.getAddonInfo('path'),'rtmpdump', 'android86')
    #el
    if quality == '2':
        return os.path.join(ADDON.getAddonInfo('path'),'rtmpdump', 'atv1linux')
    elif quality == '3':
        return os.path.join(ADDON.getAddonInfo('path'),'rtmpdump', 'atv1stock')
    elif quality == '4':
        return os.path.join(ADDON.getAddonInfo('path'),'rtmpdump', 'atv2')
    elif quality == '5':
        return os.path.join(ADDON.getAddonInfo('path'),'rtmpdump', 'ios')
    elif quality == '6':
        return os.path.join(ADDON.getAddonInfo('path'),'rtmpdump', 'linux32')
    elif quality == '7':
        return os.path.join(ADDON.getAddonInfo('path'),'rtmpdump', 'linux64')
    elif quality == '8':
        return os.path.join(ADDON.getAddonInfo('path'),'rtmpdump', 'osx106')
    elif quality == '9':
        return os.path.join(ADDON.getAddonInfo('path'),'rtmpdump', 'osx107')
    elif quality == '10':
        return os.path.join(ADDON.getAddonInfo('path'),'rtmpdump', 'pi')
    elif quality == '11':
        return 'None'   
    elif quality == '12':
        return '/usr/bin/'
    elif quality == '13' or quality == '0' or quality == '1':
        LIBpath = '/data/data/org.xbmc.kodi/lib/'
        logdev( 'libPath: ', 'os.path.exists(%s)= %s' % (repr(LIBpath),repr(os.path.exists(LIBpath))))  # Put in LOG
        logdev( 'libPath: ', 'os.path.exists(%s)= %s' % (repr(LIBpath + 'librtmp.so'),repr(os.path.exists(LIBpath + 'librtmp.so'))))  # Put in LOG
        return LIBpath
"""
def runCommandTest(cmd):
    logdev('runCommandTest','cmd= %s' % repr(cmd)) # Put in LOG
    
    # subpr = Popen(cmd, shell=True, env=env, stdin=PIPE, stdout=PIPE, stderr=STDOUT) # original
    quality = ADDONgetSetting('os')
    if quality=='13' or  quality=='0' or quality=='1':
        subpr = Popen(cmd, executable='/system/bin/sh', shell=True, close_fds=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT)
    else:
        subpr = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT) 

    x = subpr.stdout.read()
    logdev('runCommandTest','x= %r' % x) # Put in LOG
    expectedresult = 'copyright'   ### 2017-12-16
    if expectedresult.lower() in x.lower():
        return True
    expectedresult = '(c)'   ### 2017-12-16
    if expectedresult.lower() in x.lower():
        return True
    else:
        return False  
"""
        
def runCommandTest(cmd):
    logdev(module,'runCommandTest: 1.cmd= %r' % cmd) # Put in LOG
    # subpr = Popen(cmd, shell=True, env=env, stdin=PIPE, stdout=PIPE, stderr=STDOUT) # original
    quality = ADDONgetSetting('os')
    logdev(module,'runCommandTest: 2.quality= %r' % quality) # Put in LOG
    try:
        if quality != 'X':  ###Always use this path
            try:
                subpr = Popen(cmd, executable='/system/bin/sh', shell=True, close_fds=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT)
                logdev(module,'runCommandTest: 3.subpr= %r' % subpr) # Put in LOG
            except Exception as e:
                pass
                logdev(module,'runCommandTest: 4.Error= %r' % e) # Put in LOG
                try:
                    subpr = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT)
                    logdev(module,'runCommandTest: 5.subpr= %r' % subpr) # Put in LOG
                except Exception as e:
                    pass
                    logdev(module,'runCommandTest: 6.Error= %r' % e) # Put in LOG
                    return False
        elif quality=='13' or  quality=='0' or quality=='1':
            subpr = Popen(cmd, executable='/system/bin/sh', shell=True, close_fds=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT)
        else:
            subpr = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT) 

        x = subpr.stdout.read(1024)   ### Only read first part of output
        logdev(module,'runCommandTest: 7.x= %r' % x) # Put in LOG
        expectedresult = 'copyright'   ### 2017-12-16
        if expectedresult.lower() in x.lower():
            return True
        expectedresult = '(c)'   ### 2017-12-16
        if expectedresult.lower() in x.lower():
            return True
        expectedresult = 'BusyBox'   ### 2018-05-26 xz on LibreELEC
        if expectedresult.lower() in x.lower():
            return True
        expectedresult = 'usage: mkchromecast'   ### 2018-05-26 mkchromecast on Ubuntu
        if expectedresult.lower() in x.lower():
            return True
        else:
            return False 
    except Exception as e:
        pass
        logdev(module,'runCommandTest: 8.Error= %r' % e) # Put in LOG
        return False
        
def runCommand(cmd, LoopCount, libpath = None, module_path = './', nameAlarm=''):
    logdev(module,'runCommand: cmd= %s' % repr(cmd)) # Put in LOG
    logdev(module,'runCommand: LoopCount= %s' % repr(LoopCount)) # Put in LOG
    logdev(module,'runCommand: libpath= %s' % repr(libpath)) # Put in LOG
    logdev(module,'runCommand: module_path= %s' % repr(module_path)) # Put in LOG
    logdev(module,'runCommand: nameAlarm= %s' % repr(nameAlarm)) # Put in LOG
    from subprocess import Popen, PIPE, STDOUT
    # get the list of already defined env settings
    env = os.environ
    logdev(module,'runCommand: env= %s' % env)
    if LoopCount == 0:
        if (libpath):
            logdev(module,'runCommand: libpath1= %s' %repr(libpath))
            # add the additional env setting
            envname = "LD_LIBRARY_PATH"
            if (env.has_key(envname)):
                env[envname] = env[envname] + ":" + libpath
                env[envname]=uniquecolon(env[envname])
            else:
                env[envname] = libpath
            envname = "DYLD_LIBRARY_PATH"
            if (env.has_key(envname)):
                env[envname] = uniquecolon(env[envname] + ":" + libpath)
            else:
                env[envname] = libpath
        envname = 'PYTHONPATH'
        if (env.has_key(envname)):
            env[envname] = uniquecolon(env[envname] + ":" + module_path)
        else:
            env[envname] = module_path
    try:
        logdev(module,'runCommand: env[PYTHONPATH] = ' + env['PYTHONPATH'])  # Put in LOG
        logdev(module,'runCommand: env[LD_LIBRARY_PATH] = ' + env['LD_LIBRARY_PATH']) # Put in LOG
        logdev(module,'runCommand: env[DYLD_LIBRARY_PATH] = ' + env['DYLD_LIBRARY_PATH'])  # Put in LOG
    except:
        pass

    # subpr = Popen(cmd, shell=True, env=env, stdin=PIPE, stdout=PIPE, stderr=STDOUT) # original
    try:
        quality = ADDONgetSetting('os')
        if quality=='13' or  quality=='0' or quality=='1':
            subpr = Popen(cmd, executable='/system/bin/sh', shell=True, close_fds=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT)
        else:
            subpr = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT) 
    except Exception as e:
        pass
        subpr = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT)
        logdev(module,'runCommand: Error Popen \ncmd= %r\npid= %r' % (cmd,e))
        nowHM=datetime.today().strftime('%H:%M')
        ##recordings.updateRecordingPlanned(nameAlarm, '[COLOR red]Error ' + nowHM + '[/COLOR] ' + title + ' - ' + e)
    try:
        subprpid = subpr.pid
        if subprpid != 0 and ADDONgetSetting('timeshiftbase') in cmd:  ### Only save TimeShift processes
            xbmcgui.Window(10000).setProperty(ADDONname + 'subprpid', repr(subprpid))
            xbmcgui.Window(10000).setProperty(ADDONname + 'subprcmd', cmd)
            logdev(module,'runCommand: TimeShift set pid= %r, cmd= %r' % (subprpid, cmd))
        else:
            logdev(module,'runCommand: NOT TimeShift pid= %r, cmd= %r' % (subprpid, cmd))
        if subprpid != 0 and 'mkchromecast' in cmd:
            ADDONsetSetting('castsubpr',repr(subprpid))
            ADDONsetSetting('castsubprcmd',cmd)
    except Exception as e:
        pass
        logdev(module,'runCommand: Error save \ncmd= %r\nError: %r' % (cmd,e))
        nowHM=datetime.today().strftime('%H:%M')
        ##recordings.updateRecordingPlanned(nameAlarm, '[COLOR red]Error ' + nowHM + '[/COLOR] ' + title + ' - ' + e)
    x = subpr.stdout.read()   ### 2019-05-02  Read last characters?
    #xbmcgui.Dialog().ok( ADDON.getAddonInfo('name'), 'Test runCommand: 1', '', repr(x[-100:]))
    #xbmcgui.Dialog().input('Test runCommand: 1 \n' + repr(x[-100:]), defaultt='', type=xbmcgui.INPUT_ALPHANUM, autoclose=5000)
    if ADDONgetSetting('DebugRecording')=='true':
        logdev(module,'runCommand: subpr.stdout.read()= %s' % repr(x))
        if 'ERROR' in x:
            xError=x.replace('\n','[cr]')
            notification('[COLOR red]ERROR utils.py runCommand: Basic recording function failed![/COLOR]')
            xbmcgui.Dialog().ok( ADDON.getAddonInfo('name'), 'utils.py runCommand: ERROR', '', repr(xError))
    xbmc.sleep(2000)
    ###time.sleep(2)
    while subpr.poll() == None:
        xbmc.sleep(2000)
        ###time.sleep(2)
        x = subpr.stdout.read()   ### 2019-05-02  Read last characters?
        #xbmcgui.Dialog().ok( ADDON.getAddonInfo('name'), 'Test runCommand: 1', '', repr(x[-100:]))
        #xbmcgui.Dialog().input('Test runCommand: 2 \n' + repr(x[-100:]), defaultt='', type=xbmcgui.INPUT_ALPHANUM, autoclose=5000)
        if ADDONgetSetting('DebugRecording')=='true':
            if 'ERROR' in x:
                xError=x.replace('\n','[cr]')
                notification('[COLOR red]ERROR utils.py runCommand: Basic recording function failed![/COLOR]')
                xbmcgui.Dialog().ok( ADDON.getAddonInfo('name'), 'utils.py runCommand: ERROR in Loop', '', repr(xError))
    return subpr    ### 2018-02-25

def terminateSubpr(subpr):  
    ### Popen.terminate()
    """
    There's a very good explanation of how to create a new process group with python subprocess. Adding option preexec_fn=os.setsid to Popen:

process_Festival = subprocess.Popen(["festival", "--tts", "/var/log/dmesg"],preexec_fn=os.setsid)
You can then get the process group from the process id and signal it:

pgrp = os.getpgid(process_Festival.pid)
os.killpg(pgrp, signal.SIGINT)

Popen("TASKKILL /F /PID {pid} /T".format(pid=process.pid))

    """
    record_path = ADDONgetSetting('record_path')
    platform    = ADDONgetSetting('platform')
    runningon   = ADDONgetSetting('runningon')
    osplat      = ADDONgetSetting('os')
    logdev(module,'record_path= %r, platform= %r, runningon= %r, os= %r' % (record_path, platform, runningon, osplat)) 
    
    try:
        if osplat == '11':
            Popen("TASKKILL /F /PID {pid} /T".format(pid=int(subpr)))
            logdev(module,'subpr.terminate on Windows (%r)' % (subpr)) 
    except Exception as e:
        pass
        logdev(module,'Popen(TASKKILL /F /PID {pid} /T (%r) Error= %r' % (subpr,e)) 
    try:
        if osplat == '7':
            os.kill(int(subpr), signal.SIGINT)
            logdev(module,'subpr.terminate 7(%r)' % (subpr)) 
    except Exception as e:
        pass
        logdev(module,'subpr.terminate 7(%r) Error= %r' % (subpr,e)) 
          
    try:
        if osplat != '11' and osplat != '7':
            pgrp = os.getpgid(int(subpr))
            os.killpg(pgrp, signal.SIGINT)
            #os.killpg(pgrp, signal.SIGHUP)
            #os.killpg(pgrp, signal.SIGTERM)
            #os.killpg(pgrp, signal.SIGKILL)
            logdev(module,'subpr.terminate tree(%r)' % (subpr)) 
    except Exception as e:
        pass
        logdev(module,'subpr.terminate tree(%r) Error= %r' % (subpr,e)) 
        try:
            ### If you kill festival with a signal like SIGHUP rather than SIGKILL it will clean up any subprocesses properly.
            #os.kill(int(subpr), signal.SIGINT) # signal.SIGKILL or signal.SIGTERM
            #os.kill(int(subpr), signal.SIGHUP) # signal.SIGKILL or signal.SIGTERM
            os.kill(int(subpr), signal.SIGTERM) 
            #os.kill(int(subpr), signal.SIGKILL) 
            logdev(module,'subpr.terminate %r)' % (subpr)) 
        except Exception as e:
            pass
            logdev(module,'subpr.terminate(%r) Error= %r' % (subpr,e)) 
    logdev(module,'subpr.terminate() ACTIVATED!')    ### 2018-02-25
"""    
def terminateSubprOLD(subpr):  
    ### Popen.terminate()
    try:
        import os
        import signal

        os.kill(int(subpr), signal.SIGTERM) #or signal.SIGKILL 
        ### subpr.terminate()     ### 2018-02-25
        logdev(module,'subpr.terminate(%r)' % (subpr)) 
    except Exception as e:
        pass
        logdev(module,'subpr.terminate(%r) Error= %r' % (subpr,e)) 
    logdev(module,'subpr.terminate() ACTIVATED!')    ### 2018-02-25
"""    
def datetimeconversions():
    # Test date time conversions on this system
    #-------------------------------------------------
    # conversions to strings
    #-------------------------------------------------
    # datetime object to string
    dt_obj = datetime(2008, 11, 10, 17, 53, 59)
    date_str = dt_obj.strftime("%Y-%m-%d %H:%M:%S")
    ###p rint date_str

    # time tuple to string
    time_tuple = (2008, 11, 12, 13, 51, 18, 2, 317, 0)
    date_str = time.strftime("%Y-%m-%d %H:%M:%S", time_tuple)
    ###p rint date_str

    #-------------------------------------------------
    # conversions to datetime objects
    #-------------------------------------------------
    # time tuple to datetime object
    time_tuple = (2008, 11, 12, 13, 51, 18, 2, 317, 0)
    dt_obj = datetime(*time_tuple[0:6])
    ###p rint 'datetime.datetime(*time_tuple[0:6])'
    ###p rint repr(dt_obj)
    ###p rint str(dt_obj)
    
    # date string to datetime object
    date_str = "2008-11-10 17:53:59"
    ##fejler## dt_obj = datetime.datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")
    date_str = "2008-11-10 17:53:59"
    time_tuple = time.strptime(date_str, "%Y-%m-%d %H:%M:%S")
    dt_obj = datetime(*time_tuple[0:6])
    ###p rint repr(dt_obj)
    ###p rint str(dt_obj)

    # timestamp to datetime object in local time
    timestamp = 1226527167.595983
    dt_obj = datetime.fromtimestamp(timestamp)
    ###p rint repr(dt_obj)
    ###p rint str(dt_obj)

    # timestamp to datetime object in UTC
    timestamp = 1226527167.595983
    dt_obj = datetime.utcfromtimestamp(timestamp)
    ###p rint repr(dt_obj)
    ###p rint str(dt_obj)

    #-------------------------------------------------
    # conversions to time tuples
    #-------------------------------------------------
    # datetime object to time tuple
    dt_obj = datetime(2008, 11, 10, 17, 53, 59)
    time_tuple = dt_obj.timetuple()
    ###p rint repr(time_tuple)
    ###p rint str(time_tuple)

    # string to time tuple
    date_str = "2008-11-10 17:53:59"
    time_tuple = time.strptime(date_str, "%Y-%m-%d %H:%M:%S")
    ###p rint repr(time_tuple)
    ###p rint str(time_tuple)

    # timestamp to time tuple in UTC
    timestamp = 1226527167.595983
    time_tuple = time.gmtime(timestamp)
    ###p rint repr(time_tuple)
    ###p rint str(time_tuple)

    # timestamp to time tuple in local time
    timestamp = 1226527167.595983
    time_tuple = time.localtime(timestamp)
    ###p rint repr(time_tuple)
    ###p rint str(time_tuple)

    #-------------------------------------------------
    # conversions to timestamps
    #-------------------------------------------------
    # time tuple in local time to timestamp
    time_tuple = (2008, 11, 12, 13, 59, 27, 2, 317, 0)
    timestamp = time.mktime(time_tuple)
    ###p rint repr(timestamp)
    ###p rint str(timestamp)

    # time tuple in utc time to timestamp
    time_tuple_utc = (2008, 11, 12, 13, 59, 27, 2, 317, 0)
    timestamp_utc = calendar.timegm(time_tuple_utc)
    ###p rint repr(timestamp_utc)
    # time tuple in utc time to timestamp
    time_tuple_utc = (2008, 11, 12, 13, 59, 27, 2, 317, 0)
    #timestamp_utc = calendar.timegm(time_tuple_utc)
    timestamp_utc = calendar.timegm(time_tuple_utc)
    ###p rint repr(timestamp_utc)
    ###p rint str(timestamp_utc)

    #-------------------------------------------------
    # results
    #-------------------------------------------------
    # 2008-11-10 17:53:59
    # 2008-11-12 13:51:18
    # datetime.datetime(2008, 11, 12, 13, 51, 18)
    # datetime.datetime(2008, 11, 10, 17, 53, 59)
    # datetime.datetime(2008, 11, 12, 13, 59, 27, 595983)
    # datetime.datetime(2008, 11, 12, 21, 59, 27, 595983)
    # (2008, 11, 10, 17, 53, 59, 0, 315, -1)
    # (2008, 11, 10, 17, 53, 59, 0, 315, -1)
    # (2008, 11, 12, 21, 59, 27, 2, 317, 0)
    # (2008, 11, 12, 13, 59, 27, 2, 317, 0)
    # 1226527167.0
    # 1226498367
    
def username(infile):
    #Open settings file and find username/mailaddress
    # <setting id="user">xxxxxxxx</setting> ### Kodi 18!
    LF = open(infile, 'r')
    input = LF.read()
    marker = '<setting id="user">'
    markerend = '</setting>'
    user=''
    if marker in input and user == '':
        user = input.split(marker)[1].split(markerend)[0]
    # Close our file
    LF.close()
    return user

def folder(infile):
    #Open settings file and find recording folder
    LF = open(infile, 'r')
    input = LF.read()
    marker = '<setting id="record_display_path" value="'  ### NOT Kodi 18!
    markerend = '" />'
    user=''
    if marker in input and user == '':
        user = input.split(marker)[1].split(markerend)[0]
    # Close our file
    LF.close()
    return user
    
def versiondate():
    #Open addon.xml file and find version and date
    infile = os.path.join(ADDON.getAddonInfo('path'), 'addon.xml')
    LF = open(infile, 'r')
    input = LF.read()
    marker = 'Version Date'
    markerend = '</description>'
    user=''
    if marker in input and user == '':
        user = input.split(marker)[1].split(markerend)[0]
    # Close our file
    LF.close()
    return user
    
def version():
    #Open addon.xml file and find version info
    infile = os.path.join(ADDON.getAddonInfo('path'), 'addon.xml')  
    logdev ('Path to addon.xml',infile)     
    LF = open(infile, 'r')
    input = LF.read()
    marker = '<addon id='
    markerend = '>'
    user=''
    if marker in input and user == '':
        user = input.split(marker)[1].split(markerend)[0]
    # Close our file
    LF.close()
    return user
    


