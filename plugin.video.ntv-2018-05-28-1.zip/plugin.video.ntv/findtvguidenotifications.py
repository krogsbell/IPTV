#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmc,xbmcaddon
import definition
ADDON      = definition.getADDON()
import urllib,urllib2,sys,re,os
import utils
import net
from hashlib import md5  
import json
import glob
import recordings
import locking
import definition
import sqlite3
import datetime, time
from operator import itemgetter

utils.logdev('findtvguidenotifications.py','Start')
try:
    TimeZoneOffset = int(ADDON.getSetting('AdjustTVguideTimeZoneOffset'))
    if TimeZoneOffset > 24 or TimeZoneOffset < -24 :
        TimeZoneOffset = 0
except:
    pass
    TimeZoneOffset = 0
#EPG_DB = 'source.db'  Depends on actual TV Guide
RECORDS_DB = 'recordings_adc.db'
CHANNEL_DB = 'channels.db'
RECURSIVEMARKER = 'Recursive:'
streamtype = ADDON.getSetting('streamtype')
if streamtype == '0':
    STREAMTYPE = 'NTV-XBMC-HLS-'
elif streamtype == '1':
    STREAMTYPE = 'NTV-XBMC-'
UA=STREAMTYPE + ADDON.getAddonInfo('version') 
net=net.Net()
site=definition.getBASEURL() +'/index.php?' + recordings.referral()+ 'c=6&a=0'
datapath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
cookie_path = os.path.join(datapath, 'cookies')
cookie_jar = os.path.join(cookie_path, "ntv.lwp")

ADDON      = definition.getADDON()
xbmc.log('recordings.py in %s' % ADDON.getAddonInfo('name'))
dbPath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
dbPathNTV = os.path.join(xbmc.translatePath(ADDON.getAddonInfo('path')),'resources')
scriptTrig   = os.path.join(ADDON.getAddonInfo('path'), 'TrigTVGuide.py')

def adapt_datetime(ts):
    return time.mktime(ts.timetuple())

def convert_datetime(ts):
        try:
            return datetime.datetime.fromtimestamp(float(ts))
        except ValueError:

            return None
               
# http://docs.python.org/2/library/sqlite3.html#registering-an-adapter-callable
sqlite3.register_adapter(datetime.datetime, adapt_datetime)
sqlite3.register_converter('timestamp', convert_datetime)



def LOGIN():
        #xbmc.log('findtvguidenotifications.py: LOGIN')
        #restoreXml=recordings.restoreLastSetupXml()
        #xbmc.log('findtvguidenotifications.py: LOGIN restoreXml= %s' % repr(restoreXml))
        loginurl = definition.getBASEURL() +'/index.php?' + recordings.referral() + 'c=3&a=4'
        username    =ADDON.getSetting('user')
        #xbmc.log('findtvguidenotifications.py: LOGIN username= %s' % repr(username))
        if  not '@' in username:
            AUTH()
        else:
            password =md5(ADDON.getSetting('pass')).hexdigest()

        data     = {'email': username,
                                                'psw2': password,
                                                'rmbme': 'on'}
        headers  = {'Host':definition.getBASEURL().replace('http://',''),
                                                'Origin':definition.getBASEURL(),
                                                'Referer':definition.getBASEURL() +'/index.php?' + recordings.referral() + 'c=3&a=0','User-Agent' : UA}
                                                
        html = net.http_POST(loginurl, data, headers).content
        if 'success' in html and '@' in username:
            if os.path.exists(cookie_path) == False:
                    os.makedirs(cookie_path)
            net.save_cookies(cookie_jar)

def AUTH():
        ###utils.logdev('findtvguidenotifications.py','AUTH')
        try:
            os.remove(cookie_jar)
        except:
            pass
        username =ADDON.getSetting('user')
        password =md5(ADDON.getSetting('pass')).hexdigest()
        ###utils.logdev('findtvguidenotifications.py','username= %s, password= %s' % (repr(username),repr(password)))
        if not '@' in username:
            ###utils.logdev('findtvguidenotifications.py','firstrun.Launch()')
            import firstrun
        url = definition.getBASEURL() +'/?' + recordings.referral() + 'c=3&a=4&email=%s&psw2=%s&rmbme=on'%(username,password)
        ###utils.logdev('findtvguidenotifications.py','url= %s' % repr(url))
        html = net.http_GET(url, headers={'User-Agent' :UA}).content
        ###utils.logdev('findtvguidenotifications.py','html= %s' % repr(html))
        if 'success' in html and '@' in username:
            LOGIN()
            ADDON.setSetting('firstrun','true')
        else:
            utils.logdev('findtvguidenotifications.py','firstrun.Launch(1)')
            import firstrun

def MyChannels():
    LOGIN()
    cat='-2'
    net.set_cookies(cookie_jar)
    now= datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20')
    url='&mwAction=category&xbmc=1&mwData={"id":"%s","time":"%s","type":"tv"}'%(cat,now)
    link = net.http_GET(site+url, headers={'User-Agent' : UA}).content
    data = json.loads(link)
    channels=data['contents']
    from operator import itemgetter
    #Sort channels by name 
    channels = sorted(channels, key=itemgetter('name'))
    AllMyChannels=[]
    
    for field in channels:
        name         =  field['name']  ###.encode("utf-8") 2017-08-04
        channel      =  field['id']
        displaychannelnumber = (name + ' (' +channel+'):\n' )
        AllMyChannels.append(displaychannelnumber)
        ####utils.logdev('findtvguidenotifications', 'displaychannelnumber= %s' % repr(displaychannelnumber))
    ####utils.logdev('findtvguidenotifications', 'AllMyChannels= %s' % repr(AllMyChannels))
    return AllMyChannels

def findtvguidenotifications():
    if locking.isAnyRecordLocked() and ADDON.getSetting('grabduringrecord') == 'false'  :
        locking.scanUnlockAll()
        findtvguidenotificationsend('[COLOR red]Recording - Grab disabled[/COLOR]')
        return
    elif  locking.isAnyScanLocked():
        findtvguidenotificationsend('[COLOR red]Already scanning - New grab disabled[/COLOR]')
        return
    else:
        locking.scanLock('findtvguidenotifications')
    if not locking.isScanLocked('findtvguidenotifications'):
        findtvguidenotificationsend('[COLOR red]Scan lock not working - Grab disabled[/COLOR]')
        return
    TVguide= utils.TVguide()
    Recursive = RecursiveRecordings() ## Get all recursive recordings
    #guidenotifications= ADDON.getSetting('tvguidenotifications')

    for Guide in range(0, len(TVguide)):
        
        guide = TVguide[Guide][0]
        guideDB = TVguide[Guide][1]
        
        grabGuide(guide,guideDB)
        ###try:
        findrecursiverecordingsinGuide(guide,guideDB,Recursive)
        ###except Exception, e:
        ### pass
        ### utils.logdev('findrecursiverecordingsinGuide EXECUTION FAILED', 'guide= %s ERROR= %s' % (guide,repr(e)))
        ### findtvguidenotificationsend('[COLOR red]Grab from TV Guide FAILED![/COLOR] - guide= %s ERROR= %s'% (guide,repr(e)))
        ### return
    findtvguidenotificationsend('[COLOR green]Grab from TV Guide finished![/COLOR]')


def     findtvguidenotificationsend(EndText):
    # Show menuentry when finished OK - but not when run in the background
    name= EndText
    ###utils.logdev('findtvguidenotifications', name)
    locking.scanUnlockAll()
    liz=xbmcgui.ListItem(name)
    try:
        xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url='',listitem = liz, isFolder = True) 
        utils.logdev('findtvguidenotifications', 'Finished in foreground with menu item')
    except:
        pass
        utils.logdev('findtvguidenotifications', 'Finished in background - no menu item')

def RecursiveRecordings():
    conn = recordings.getConnection()
    c = conn.cursor()
    #c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE '%Recursive:%' and NOT LIKE '%COLOR orange%' COLLATE NOCASE")  # Find all active recursive recordings
    c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE ? COLLATE NOCASE",['%'+RECURSIVEMARKER+'%'])  # Find all active recursive recordings RECURSIVEMARKER
    recordingsE = c.fetchall()
    # Put recursive recordings changed last - first
    recordingsC = sorted(recordingsE, key=itemgetter(2), reverse=True)
    ###utils.logdev('Recursive recordings',repr(recordingsC))
    return recordingsC

"""
def findrecursiverecordingsinGuideOLD(guide,EPG_DB,Recursive):
    if ADDON.getSetting('DebugRecording') == 'false':
        try:
            findrecursiverecordingsinGuideCode(guide,EPG_DB,Recursive)
        except Exception, e:
            pass
            utils.logdev('findrecursiverecordingsinGuide EXECUTION FAILED', 'guide= %s ERROR= %s' % (guide,repr(e)))
    else:
        findrecursiverecordingsinGuideCode(guide,EPG_DB,Recursive)      
"""
def findrecursiverecordingsinGuide(guide,EPG_DB,Recursive):         
    ####utils.logdev('findrecursiverecordingsinGuideCode', 'guide= %s' % guide)
    ADDONguide = xbmcaddon.Addon(id=guide)

    NTVchannels = MyChannels()
    #SearchRecursiveIn: 0=Only selected channel|1=First 25 Cannels|2=First 50 Channels|3=All My Channels
    SearchRecursiveIn= int(ADDON.getSetting('SearchRecursiveIn'))
    ####utils.logdev('findtvguidenotificationsGuide', 'MyNTVchannels= %s' % repr(NTVchannels))
    
    conv   = sqlite3.connect(os.path.join(dbPath, RECORDS_DB), timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conv.execute('PRAGMA foreign_keys = ON')
    conv.row_factory = sqlite3.Row
    conv.text_factory = str
    b = conv.cursor()
    ###b.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)") ## 2016-05-15
    b.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (title, source))")

    dbPathEPG = xbmc.translatePath(ADDONguide.getAddonInfo('profile'))
    ####utils.logdev('findrecursiverecordingsinGuide', 'dbPath= %s' % dbPathEPG)
    if not os.path.exists(dbPathEPG):
        ####utils.logdev('findrecursiverecordingsinGuide', 'os.mkdir(dbPath) where dbPath= %s' % dbPathEPG)
        os.mkdir(dbPathEPG)

    conn   = sqlite3.connect(os.path.join(dbPathEPG, EPG_DB), timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    c = conn.cursor()
    ###c.execute("CREATE TABLE IF NOT EXISTS programs (channel TEXT, title TEXT, start_date TIMESTAMP, end_date TIMESTAMP, description TEXT, image_large TEXT, image_small TEXT, source TEXT, updates_id INTEGER, PRIMARY KEY (channel, updates_id), FOREIGN KEY(updates_id) REFERENCES updates(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
    c.execute("CREATE TABLE IF NOT EXISTS programs (channel TEXT, title TEXT, start_date TEXT, end_date TEXT, description TEXT, image_large TEXT, image_small TEXT, source TEXT, updates_id INTEGER, PRIMARY KEY (channel, updates_id))")
    ###c.execute("CREATE TABLE IF NOT EXISTS programsForHumans (channel TEXT, title TEXT, start_date TEXT, end_date TEXT, description TEXT, image_large TEXT, image_small TEXT, source TEXT, updates_id INTEGER, PRIMARY KEY (channel, updates_id), FOREIGN KEY(updates_id) REFERENCES updates(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
    c.execute("CREATE TABLE IF NOT EXISTS channels (id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY(id,source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
    c.execute("CREATE TABLE IF NOT EXISTS updates(id INTEGER PRIMARY KEY, source TEXT, date TEXT, programs_updated TIMESTAMP)")
    conn.commit()
    for index in range(0, len(Recursive)):
        utils.logdev('findrecursiverecordingsinGuide', 'Recursive[%s]= %s X %s X %s' % (repr(index),repr(Recursive[index][0]),repr(Recursive[index][1]),repr(Recursive[index][2])))

    for index in range(0, len(Recursive)):
        ####utils.logdev('findrecursiverecordingsinGuide', 'index= %s' % index)
        ####utils.logdev('findrecursiverecordingsinGuide', 'Recursive[index][1]= %s' % repr(Recursive[index][1].replace(RECURSIVEMARKER, '').strip()))
        cat= Recursive[index][0]
        ####utils.logdev('findrecursiverecordingsinGuide', 'cat= %s' % repr(cat))
        # Find channel name in TV Guide 1. saved conversion 2. name as used i NTV
        b.execute("SELECT * FROM channels WHERE id=? and source=?", [cat,guide])
        channelconvert = b.fetchall()
        ####utils.logdev('findrecursiverecordingsinGuide', 'channelconvert= %s' % repr(channelconvert))
        if len(channelconvert) == 1:
            channel= channelconvert[0][1]
            ###utils.logdev('findrecursiverecordingsinGuide', 'Converted: cat= (%s) channel= %s' % (repr(cat),repr(channel)))
        else:
            channel= recordings.ChannelName(cat)
            ###utils.logdev('findrecursiverecordingsinGuide', 'LookedUp: cat= (%s) channel= %s' % (repr(cat),repr(channel)))
        ####utils.logdev('findrecursiverecordingsinGuide', 'cat= (%s) channel= %s' % (repr(channel),repr(channel)))
        # Find id from TV Guide channel name
        #c.execute("SELECT * FROM channels")
        #channelconvert = c.fetchall()
        ####utils.logdev('findrecursiverecordingsinGuide', 'channelconvert= %s' % repr(channelconvert))
        c.execute("SELECT * FROM channels WHERE title=? COLLATE NOCASE", [channel])
        channelconvert = c.fetchall()
        ####utils.logdev('findrecursiverecordingsinGuide', 'channelconvert= %s' % repr(channelconvert))
        try:
            channel= channelconvert[0][0]
        except:
            pass
            channel= 0
        ###utils.logdev('findrecursiverecordingsinGuide', 'ChannelConvert: cat= (%s) channel= %s #ofchannelconvert= %s' % (repr(cat),repr(channel),repr(len(channelconvert))))
        ####utils.logdev('findrecursiverecordingsinGuide', 'channel= %s' % repr(channel))
        #c.execute("SELECT * FROM programs WHERE title LIKE ? AND channel=? COLLATE NOCASE", ['%'+(Recursive[index][1].replace(RECURSIVEMARKER, '').strip())+'%',channel])
        recursivechannel= channel  ### E! ==> E.se
        ###utils.logdev('findrecursiverecordingsinGuide', 'recursivechannel= %s' % repr(recursivechannel))
        ###SearchText = '%'+(Recursive[index][1].replace(RECURSIVEMARKER, '').strip())+'%'
        SearchText = (Recursive[index][1].replace(RECURSIVEMARKER, '').strip())
        try:
            SearchText = SearchText.split('^')
        except Exception, e:
            pass
            utils.logdev('findrecursiverecordingsinGuide split search text EXECUTION FAILED', 'SearchText= %s ERROR= %s' % (repr(SearchText),repr(e)))
            utils.logdev('findrecursiverecordingsinGuide', 'Default SearchText= %s' % repr(SearchText))
            SearchText = [SearchText.strip()]
        ###utils.logdev('findrecursiverecordingsinGuide', 'SearchText= %s' % repr(SearchText))
        ###utils.logdev('findrecursiverecordingsinGuide', 'SearchText= %s' % repr(SearchText[0]))
        ###utils.logdev('findrecursiverecordingsinGuide', 'len(SearchText)= %s' % repr(len(SearchText)))
        if len(SearchText) == 1 : 
            c.execute("SELECT * FROM programs WHERE title LIKE ? COLLATE NOCASE", ['%'+SearchText[0].strip()+'%'])
        if len(SearchText) == 2 :  
            c.execute("SELECT * FROM programs WHERE title LIKE ? AND title NOT LIKE ? COLLATE NOCASE", ['%'+SearchText[0].strip()+'%','%'+SearchText[1].strip()+'%'])
        if len(SearchText) == 3 :  
            c.execute("SELECT * FROM programs WHERE title LIKE ? AND title NOT LIKE ?  AND title NOT LIKE ? COLLATE NOCASE", ['%'+SearchText[0].strip()+'%','%'+SearchText[1].strip()+'%','%'+SearchText[2].strip()+'%'])
        if len(SearchText) > 3 :  
            c.execute("SELECT * FROM programs WHERE title LIKE ? AND title NOT LIKE ?  AND title NOT LIKE ? AND title NOT LIKE ? COLLATE NOCASE", ['%'+SearchText[0].strip()+'%','%'+SearchText[1].strip()+'%','%'+SearchText[2].strip()+'%','%'+SearchText[3].strip()+'%'])
        notifications = c.fetchall()
        ####utils.logdev('findrecursiverecordingsinGuide', 'notifications= %s' % repr(notifications))
        ###utils.logdev('findrecursiverecordingsinGuide', 'len(notifications)= %s' % repr(len(notifications)))
        if len(notifications) > 0:
            for indexN in range(0, len(notifications)): 
                channel= notifications[indexN][0]
                program= notifications[indexN][1]
                ###utils.logdev('findrecursiverecordingsinGuide', 'indexN= %s' % repr(indexN))
                ###utils.logdev('findrecursiverecordingsinGuide', '  cat= %s' % repr(cat))
                ###utils.logdev('findrecursiverecordingsinGuide', '  channel= %s' % repr(channel))
                ###utils.logdev('findrecursiverecordingsinGuide', '  SearchText= %s' % repr(SearchText))
                ###utils.logdev('findrecursiverecordingsinGuide', '  SearchNotText= %s' % repr(SearchNotText))
                ###utils.logdev('findrecursiverecordingsinGuide', '  program= %s' % repr(program))
                c.execute("SELECT DISTINCT id, title, logo, stream_url, source, visible, weight FROM channels WHERE id=?",  [channel])
                channeldata= c.fetchall()
                ###utils.logdev('findrecursiverecordingsinGuide', 'channeldata= %s' % repr(channeldata))
                if len(channeldata) > 0:
                    ###utils.logdev('findrecursiverecordingsinGuide', 'channel.weight= channeldata[0][6]= %s' % repr(channeldata[0][6]))
                    if  not recursivechannel==channel and ((SearchRecursiveIn==0) or (SearchRecursiveIn==1 and channeldata[0][6] > 25) or (SearchRecursiveIn==2 and channeldata[0][6] > 50)) :  ### channel.weight
                        ###utils.logdev('findrecursiverecordingsinGuide', 'channel.weight> 25 or 50 and recursivechannel!=channel')
                        nonsense=''
                    else:
                        now = datetime.datetime.now()
                        ###utils.logdev('findrecursiverecordingsinGuide', 'now= %s' % repr(now))
                        ###utils.logdev('findrecursiverecordingsinGuide', 'SearchRecursiveIn= %s' % repr(SearchRecursiveIn))
                        #if SearchRecursiveIn==0:
                        cz= c.execute("SELECT * FROM programs WHERE channel=? AND title=? AND start_date >= ?",  [recursivechannel, program, now]) ### Recursive Only on channel in record
                        programs= cz.fetchall()
                        ###utils.logdev('findrecursiverecordingsinGuideA', 'programs= %s' % repr(programs))
                        if SearchRecursiveIn==1:
                            #cx= c.execute("SELECT * FROM channels WHERE weight<?",  ['25']) ### Recursive first 25 visible ###################################
                            #programs= cx.fetchall()
                            ####utils.logdev('findrecursiverecordingsinGuide', '25 programs= %s' % repr(programs))
                            #cy= cx.execute("SELECT * FROM programs WHERE title=? AND start_date >= ?",  [program, now]) ### Recursive first 25 ###################################
                            ### Weight must be larger than 0 2017-08-09
                            cy= c.execute("SELECT DISTINCT p.*, c.weight FROM channels c, programs p WHERE c.weight > 0 AND c.weight < 25 AND p.channel = c.id AND p.title = ? AND p.start_date >= ?",[program, now])
                            ###cy= cx.execute('SELECT p.*, (SELECT 1 FROM notifications n WHERE n.channel=p.channel AND n.program_title=p.title AND n.source=p.source) AS notification_scheduled FROM programs p WHERE p.channel IN (\'' + ('\',\''.join(channelMap.keys())) + '\') AND p.source=? AND p.end_date > ? AND p.start_date < ?', [self.source.KEY, startTime, endTime])
                        elif SearchRecursiveIn==2:
                            ### Weight must be larger than 0 2017-08-09
                            cy= c.execute("SELECT DISTINCT p.*, c.weight FROM channels c, programs p WHERE c.weight > 0 AND c.weight < 50 AND p.channel = c.id AND p.title = ? AND p.start_date >= ?",[program, now])
                        elif SearchRecursiveIn==3:
                            cy= c.execute("SELECT * FROM programs WHERE title=? AND start_date >= ?",[program, now])  ##### All programs ######
                        else:
                            cy=c.execute("SELECT * FROM programs WHERE channel=? AND title=? AND start_date >= ?",[recursivechannel, program, now]) ### Recursive Only on channel in record
                        #cy= c.execute("SELECT * FROM programs WHERE title=?",[program])  ########### No Date - Test #########
                        programs += cy.fetchall()
                        ###utils.logdev('findrecursiverecordingsinGuideAA', 'programs= %s' % repr(programs))
                        
                        NTVchannelSelect= NTVchannels
                        for prog in range(0, len(programs)):
                            try:
                                cweight= programs[prog][9]
                                ###utils.logdev('findrecursiverecordingsinGuideAAA', 'cweight= %s' % repr(cweight))
                            except:
                                pass
                            pchannel= programs[prog][0]
                            ###utils.logdev('findrecursiverecordingsinGuide', 'pchannel= %s' % repr(pchannel))
                            ptitle= programs[prog][1]
                            ###utils.logdev('findrecursiverecordingsinGuide', 'ptitle= %s' % repr(ptitle))
                            ############# WOZBOX and ROQ TV Rec uses other DB
                            if ADDON.getSetting('tvguidenr')=='0':
                                pstart_date= convert_datetime(programs[prog][3])
                                pend_date= convert_datetime(programs[prog][4])
                                pdescription= programs[prog][5]
                            else:
                                pstart_date= programs[prog][2]
                                pend_date= programs[prog][3]
                                pdescription= programs[prog][4]
                            ###utils.logdev('findrecursiverecordingsinGuide','pstart_date= %r, type(pstart_date)= %r, pend_date= %r, type(pend_date)= %r' % (pstart_date,type(pstart_date),pend_date,type(pend_date)))
                            if not type(pstart_date) is datetime.datetime:
                                if type(pend_date) is datetime.datetime:
                                    ###utils.logdev('findrecursiverecordingsinGuide', 'pstart_date is not datetime and set to pend-2h= %s' % repr(pstart_date))
                                    pstart_date = pend_date - datetime.timedelta(hours = 2)  ### If pstart is missing sub 2 hours from pend
                                    
                                else:
                                    ###utils.logdev('findrecursiverecordingsinGuide', 'pstart_date is not datetime and set to now= %s -3h= %s' % (repr(datetime.datetime.now()),repr(pstart_date)))
                                    pstart_date = datetime.datetime.now() - datetime.timedelta(hours = 3)  ### If pstart and pend is missing sub 3h from now making it obsolete
                            if not type(pend_date) is datetime.datetime:    
                                ###utils.logdev('findrecursiverecordingsinGuide', 'pend_date (pstart_date + 2)= %s' % repr(pend_date))
                                pend_date = pstart_date + datetime.timedelta(hours = 2)  ### If pend is missing add 2 hours
                            ###pdescription= programs[prog][4]
                            ######utils.logdev('findrecursiverecordingsinGuide', 'channeldata[0][1]= %s' % (repr(channeldata[0][1])))
                            cat= recordings.CatFromChannelName(channeldata[0][1])
                            ###utils.logdev('findrecursiverecordingsinGuide', 'cat= %s' % (repr(cat)))
                            if cat == '0':  ## Channel from TVguide not found ##
                                b.execute("SELECT * FROM channels WHERE title=? and source=?", [channeldata[0][1],guide])
                                channelconvert = b.fetchall()
                                if len(channelconvert) == 0:
                                    SelectedChannel = xbmcgui.Dialog().select(guide + ': Select Channel for: ' + channeldata[0][1] + ' - ' + channeldata[0][0] + ' - ' + ptitle, NTVchannelSelect)
                                    ###utils.logdev('findrecursiverecordingsinGuide', 'SelectedChannel= %s' % (repr(SelectedChannel)))
                                    if SelectedChannel <> -1:
                                        try:
                                            id = NTVchannelSelect[SelectedChannel].split('(')[1].split(')')[0]
                                            if int(id) > 0:
                                                
                                                b.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight) VALUES(?, ?, ?, ?, ?, ?, ?)", [id, channeldata[0][1], '', '', guide, 'True', id])

                                                ###utils.logdev('findrecursiverecordingsinGuide', 'id= %s' % (repr(id)))
                                                cat = id
                                                ###utils.logdev('findrecursiverecordingsinGuide', 'Selected cat= %s' % (repr(cat)))
                                                
                                        except:
                                            pass
                                    conv.commit()
                                else:
                                    cat = channelconvert[0][0]
                                    ###utils.logdev('findrecursiverecordingsinGuide', 'Converted cat= %s' % (repr(cat)))
                            now= datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                            ###utils.logdev('findrecursiverecordingsinGuide', 'pdescription = pdescription= %r . . Created: now= %r  Recursive [%r ] from guide= %r  - channeldata[0][1]= %r - channeldata[0][0]= %r  - ptitle= %r ' % (pdescription, now, Recursive[index][1], guide, channeldata[0][1], channeldata[0][0], ptitle))
                            pdescription = pdescription + '. . Created: ' + now +' Recursive [' + Recursive[index][1].replace(RECURSIVEMARKER, '') + '] from ' + guide + ' - ' + channeldata[0][1] + ' - ' + channeldata[0][0] + ' - ' + ptitle
                            pdescription = pdescription.replace('(','[').replace(')',']')
                            ###utils.logdev('findrecursiverecordingsinGuide', 'cat= %s' % repr(cat))
                            ###utils.logdev('findrecursiverecordingsinGuide', 'pdescription= %s' % repr(pdescription))
                            ###utils.logdev('findrecursiverecordingsinGuide', 'pend_date= %s' % repr(pend_date))
                            delta = datetime.timedelta(hours = TimeZoneOffset)
                            ###utils.logdev('findrecursiverecordingsinGuide', 'datetime.timedelta(hours = TimeZoneOffset)= %s' % repr(delta))
                            if int(cat) > 0 :
                                ###utils.logdev('findrecursiverecordingsinGuide', 'recordings.schedule(cat= %r, pstart_date + datetime.timedelta(hours = TimeZoneOffset)= %r, pend_date + datetime.timedelta(hours = TimeZoneOffset)= %r, CcCc + program= %r, pdescription= %r)' % (cat, pstart_date + datetime.timedelta(hours = TimeZoneOffset), pend_date + datetime.timedelta(hours = TimeZoneOffset), program, pdescription))
                                recordings.schedule(cat, pstart_date + datetime.timedelta(hours = TimeZoneOffset), pend_date + datetime.timedelta(hours = TimeZoneOffset), 'CcCc' + program, pdescription)
                                # Set notification in TV Guide channeldata[0][0], program, ADDON.getAddonInfo('name')
                                ###utils.logdev('findrecursiverecordingsinGuide', 'Efter schedule')
                                if ADDON.getSetting('updateguide')=='true':
                                    try:
                                        c.execute("SELECT * FROM notifications WHERE channel = ? AND program_title = ? AND source = ?",  [channeldata[0][0], program, channeldata[0][4]])
                                        notify =  c.fetchall()
                                        if len(notify) == 0:  ## Only insert if not already there and set up in settings that recursive recordings are transferred
                                            c.execute("INSERT OR REPLACE INTO notifications (channel, program_title, source) VALUES(?, ?, ?)", [channeldata[0][0], program, channeldata[0][4]])
                                    except:
                                        pass
    utils.logdev('findtvguidenotifications','EMPTY programsForHumans')
    try:
        c.execute("DROP TABLE programsForHumans")
    except:
        pass
    """
    now = datetime.datetime.now()
    # Transfer programs to programsForHumans
    ####utils.logdev('findtvguidenotifications','channels= %s' % (repr(programs[prog][0])))
    c.execute("SELECT * FROM channels WHERE visible")
    channels= c.fetchall()
    ###utils.logdev('findtvguidenotifications','channels= %s' % (repr(channels)))
    for chan in range(0, len(channels)):
        if channels[chan][1] == channels[chan][0]:
            humanchannel= channels[chan][0]
        else:
            humanchannel= channels[chan][1] + ' (' + channels[chan][0] + ')'
        c.execute("SELECT * FROM programs WHERE start_date >= ? AND channel=?",  [now,channels[chan][0]]) 
        programs= c.fetchall()
        ######utils.logdev('findtvguidenotifications','programs= %s' % (repr(programs)))
        for prog in range(0, len(programs)):
            ####utils.logdev('findtvguidenotifications','channels= %s' % (repr(channels)))
            ####utils.logdev('findtvguidenotifications','channels[0][0]= %s, channels[0][1]= %s, egual= %s' % (repr(channels[0][1]), repr(channels[0][0]), repr(channels[0][1] == channels[0][0])))
            
            c.execute("SELECT * FROM programsForHumans WHERE channel=? AND title=? AND start_date=? AND end_date=? AND description=? AND source=?", [humanchannel, programs[prog][1],str(programs[prog][2]),str(programs[prog][3]),programs[prog][4],programs[prog][7]])
            programsForHumans =  c.fetchall()
            ####utils.logdev('findtvguidenotifications','len(programsForHumans)= %s' % repr(len(programsForHumans)))
            if len(programsForHumans) == 0:  ## Only insert if not already there
                c.execute("INSERT OR REPLACE INTO programsForHumans (channel, title, start_date, end_date, description, image_large, image_small, source) VALUES(?, ?, ?, ?, ?, ?, ?, ?)", [humanchannel, programs[prog][1],str(programs[prog][2]),str(programs[prog][3]),programs[prog][4],programs[prog][2],programs[prog][3],programs[prog][7]])
    """
    conn.commit()
    c.close()
    b.close()
    
    ####utils.logdev('findrecursiverecordingsinGuideCode', 'dbPath= %s' % dbPath)
    utils.logdev('findrecursiverecordingsinGuideCode EXECUTION Finished', 'guide= %s' % guide)


def adjusttvguide(conn,c,first):
    try: 
        sqlfilename= ADDON.getSetting('AdjustTVguideSqlFile')
        lineno = 0
        linemarker = '#lineno#'
        ###utils.logdev('adjusttvguide',repr(sqlfilename))
        sqlfile= open(sqlfilename,'r')
        line0 = sqlfile.readline()
        ###utils.logdev('adjusttvguide',repr(line0))
        if 'firstchannel=' in line0.lower():
            firstchannel= line0.lower().split('firstchannel=')[1].strip()
            if firstchannel != first.lower():
                line = sqlfile.readline().strip('\n')
                if linemarker in line:
                    line = line.replace(linemarker,str(lineno))   ### Automatic insert weight/linenumber
                    lineno += 1
                while line != '':
                    utils.logdev('adjusttvguide',repr(line))
                    c.execute(line)
                    line = sqlfile.readline()
                    if linemarker in line:
                        line = line.replace(linemarker,str(lineno))   ### Automatic insert weight/linenumber
                        lineno += 1
                ###utils.logdev('adjusttvguide','DROP TABLE programsForHumans')
                try:
                    c.execute("DROP TABLE programsForHumans")
                except:
                    pass
            else:
                utils.logdev('adjusttvguide','TV Guide already updated')
        else:
            utils.notificationbox('adjusttvguide: The sql file %s to adjust the TV Guide must start with: Firstchannel=' % repr(sqlfilename))
    except:
        pass
        utils.logdev('adjusttvguide','No Adjust TV GuideSQL file or not all lines executed!')
    conn.commit()   

def grabGuide(guide,EPG_DB):
    if ADDON.getSetting('DebugRecording') == 'false':
        try:
            grabGuideCode(guide,EPG_DB)
        except:
            pass
            utils.logdev('grabGuide EXECUTION FAILED', 'guide= %s' % guide)
    else:
        grabGuideCode(guide,EPG_DB)     


def grabGuideCode(guide,EPG_DB):        
    ####utils.logdev('findtvguidenotifications', 'guide= %s' % guide)
    #try:
    ADDONguide = xbmcaddon.Addon(id=guide)

    dbPathEPG = xbmc.translatePath(ADDONguide.getAddonInfo('profile'))
    ####utils.logdev('findtvguidenotifications', 'dbPath= %s' % dbPathEPG)
    if not os.path.exists(dbPathEPG):
        ####utils.logdev('findtvguidenotifications', 'os.mkdir(dbPath) where dbPath= %s' % dbPathEPG)
        os.mkdir(dbPathEPG)
    if not os.path.exists(dbPathNTV):
        os.mkdir(dbPathNTV)

    sqlite3.register_adapter(datetime.datetime, adapt_datetime)
    sqlite3.register_converter('timestamp', convert_datetime)
    
    cNTV   = sqlite3.connect(os.path.join(dbPathNTV, CHANNEL_DB), timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    cNTV.execute('PRAGMA foreign_keys = ON')
    cNTV.row_factory = sqlite3.Row
    cNTV.text_factory = str
    a = cNTV.cursor()
    ###a.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)") ## 2016-05-15
    a.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (title, source))")
    cNTV.commit()
    
    conv   = sqlite3.connect(os.path.join(dbPath, RECORDS_DB), timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conv.execute('PRAGMA foreign_keys = ON')
    conv.row_factory = sqlite3.Row
    conv.text_factory = str
    b = conv.cursor()
    ##b.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)") ## 2016-05-15
    b.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (title, source))")
    conv.commit()
    
    conn   = sqlite3.connect(os.path.join(dbPathEPG, EPG_DB), timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    c = conn.cursor()
    ###c.execute("CREATE TABLE IF NOT EXISTS notifications (channel TEXT, program_title TEXT, source TEXT, FOREIGN KEY(channel, source) REFERENCES channels(id, source) ON DELETE CASCADE)")
    c.execute("CREATE TABLE IF NOT EXISTS notifications (channel TEXT, program_title TEXT, source TEXT REFERENCES channels(id, source) ON DELETE CASCADE)")
    c.execute("CREATE TABLE IF NOT EXISTS programs (channel TEXT, title TEXT, start_date TIMESTAMP, end_date TIMESTAMP, description TEXT, image_large TEXT, image_small TEXT, source TEXT, updates_id INTEGER, PRIMARY KEY (id, updates_id), FOREIGN KEY(updates_id) REFERENCES updates(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
    c.execute("CREATE TABLE IF NOT EXISTS channels (id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY(id,source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
    conn.commit()
    
    ## Adjust TV Guide
    ####utils.logdev('findtvguidenotifications', 'SELECT * FROM channels WHERE weight=0')
    c.execute("SELECT * FROM channels WHERE weight=0")
    channels = c.fetchall()
    if len(channels) == 1:
        adjusttvguide(conn,c,channels[0][1])
    else:
        adjusttvguide(conn,c,'missing channel 0 force update')
        
    c.execute("SELECT * FROM notifications")
    notifications = c.fetchall()
    ###utils.logdev('findtvguidenotifications', 'notifications= %s' % repr(notifications))
    ####utils.logdev('findtvguidenotifications', 'len(notifications)= %s' % repr(len(notifications)))

    NTVchannels = MyChannels() #########################################
    ####utils.logdev('findtvguidenotifications', 'MyNTVchannels= %s' % repr(NTVchannels))

    #if len(NTVchannels) < 2:   ## Only Euronews is not enough (2)
    #   from operator import itemgetter
    #   a.execute("SELECT * FROM channels WHERE id=ltrim(id,'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ') ") #### id must be number!
    #   NTVchannels = a.fetchall()
    #   ####utils.logdev('findtvguidenotifications', 'NTVchannels(unsorted)= %s' % repr(NTVchannels))
    #   NTVchannels = sorted(NTVchannels, key=itemgetter(1))
    #   ####utils.logdev('findtvguidenotifications', 'NTVchannels= %s' % repr(NTVchannels))

    for index in range(0, len(notifications)): 
        channel= notifications[index][0]
        program= notifications[index][1]
        ####utils.logdev('findtvguidenotifications', 'channel= %s' % repr(channel))
        ####utils.logdev('findtvguidenotifications', 'program= %s' % repr(program))
        c.execute("SELECT DISTINCT id, title, logo, stream_url, source, visible, weight FROM channels WHERE id=?",  [channel])
        channeldata= c.fetchall()
        ####utils.logdev('findtvguidenotifications', 'channeldata= %s' % repr(channeldata))

        now = datetime.datetime.now()
        ####utils.logdev('findtvguidenotifications', 'now= %s' % repr(now))
        c.execute("SELECT * FROM programs WHERE channel=? AND title=? AND start_date >= ?",  [channel, program, now])
        programs= c.fetchall()
        ####utils.logdev('findtvguidenotifications', 'programs= %s' % repr(programs))
    
        '''
        channel= 'BBC 1 London'
        program= 'The Big Questions'
        channeldata= [(u'BBC 1 London', u'BBC One', u'http://wozboxtv.com/downloads/xmltv/logos/BBC%20One.png', None, u'xmltv', 1, 0)]
        now= datetime.datetime(2016, 2, 7, 10, 46, 51, 603477)
        programs= [(u'BBC 1 London', u'The Big Questions', datetime.datetime(2016, 2, 7, 11, 0), datetime.datetime(2016, 2, 7, 12, 0), u'Nicky Campbell presents moral and religious discussions on topical issues from King Edward VI School, Southampton.(n)', None, u'http://cdn.tvguide.co.uk/HighlightImages/Large/big_questions.jpg', u'xmltv', 1)]
        '''
    
        #NTVchannelSelect = []
        #for x in range (0,len(NTVchannels)):
        #   #try:
        #       ####utils.logdev('findtvguidenotifications', 'NTVchannels[x]= %s' % (repr(NTVchannels[x])))
        #       #if isnumeric(str(NTVchannels[x])):
        #       NTVchannelSelect.append(NTVchannels[x])
        #       ####utils.logdev('findtvguidenotifications', 'NTVchannelSelect= %s' % (repr(NTVchannelSelect)))
        #   #except:
        #   #   pass
        ####utils.logdev('findtvguidenotifications', 'guide= %s and EPG_DB= %s' % (guide,EPG_DB))
        ####utils.logdev('findtvguidenotifications', 'NTVchannelSelect= %s' % (repr(NTVchannelSelect)))
    
        NTVchannelSelect= NTVchannels
        for prog in range(0, len(programs)):
            pchannel= programs[prog][0]
            ptitle= programs[prog][1]
            pstart_date= programs[prog][2]
            pend_date= programs[prog][3]
            ###utils.logdev('findrecursiverecordingsinGuide NTVchannelSelect','pstart_date= %r, type(pstart_date)= %r, pend_date= %r, type(pend_date)= %r' % (pstart_date,type(pstart_date),pend_date,type(pend_date)))
            pdescription= programs[prog][4]
            ####utils.logdev('findtvguidenotifications', 'channeldata[0][1]= %s' % (repr(channeldata[0][1])))
            cat= recordings.CatFromChannelName(channeldata[0][1])
            ####utils.logdev('findtvguidenotifications', 'cat= %s' % (repr(cat)))
            if cat == '0':  ## Channel from TVguide not found ##
                b.execute("SELECT * FROM channels WHERE title=? and source=?", [channeldata[0][1],guide])
                channelconvert = b.fetchall()
                if len(channelconvert) == 0:
                    ###utils.logdev('findtvguidenotifications', 'Waiting for Select Channel for  %s' % (repr(guide + ': Select Channel for: ' + channeldata[0][1] + ' - ' + channeldata[0][0] + ' - ' + ptitle)))
                    SelectedChannel = xbmcgui.Dialog().select(guide + ': Select Channel for: ' + channeldata[0][1] + ' - ' + channeldata[0][0] + ' - ' + ptitle, NTVchannelSelect)
                    ###utils.logdev('findtvguidenotifications', 'SelectedChannel= %s' % (repr(SelectedChannel)))
                    if SelectedChannel <> -1:
                        try:
                            id = NTVchannelSelect[SelectedChannel].split('(')[1].split(')')[0]
                            if int(id) > 0:
                                b.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight) VALUES(?, ?, ?, ?, ?, ?, ?)", [id, channeldata[0][1], '', '', guide, 'True', id])
                                cat = str(int(id))  ### 2016-06-13
                        except:
                            pass
                    conv.commit()
                else:
                    cat = channelconvert[0][0]
            now= datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S')
            
            utils.logdev('findtvguidenotifications','pdescription = pdescription= %r . . Created: now= %r Notification from guide= %r - channeldata[0][1]= %r  - channeldata[0][0]= %r  - ptitle= %r' % (pdescription,now,guide,channeldata[0][1],channeldata[0][0],ptitle))
            pdescription = pdescription + '. . Created: ' + now + ' Notification from ' + guide + ' - ' + channeldata[0][1] + ' - ' + channeldata[0][0] + ' - ' + ptitle
            pdescription = pdescription.replace('(','[').replace(')',']')
            ###utils.logdev('findtvguidenotifications', 'cat= %s' % repr(cat))
            if int(cat) > 0:
                ###utils.logdev('findtvguidenotifications', 'pdescription= %s' % repr(pdescription))
                recordings.schedule(cat, pstart_date + datetime.timedelta(hours = TimeZoneOffset), pend_date + datetime.timedelta(hours = TimeZoneOffset), program, pdescription)
        
    c.close()
    b.close()
    utils.logdev('grabGuide', 'FINISHED!')
    #except:
    #   pass
    #   ###utils.logdev('grabGuide', 'FAILED!')

######################################################################
def RecursiveRecordingsPlanned(SearchAllFavorites):
    #import recordings
    cat = ADDON.getSetting('SearchRecursiveIn')
    if locking.isAnyRecordLocked():
        locking.scanUnlockAll()
        return
    elif  locking.isAnyScanLocked():
        return
    else:
        locking.scanLock(SearchAllFavorites)
    if not locking.isScanLocked(SearchAllFavorites):
        return
    ####utils.logdev('findrecursivetvguide.py RUNNING RecursiveRecordingsPlanned','cat= %s, SearchAllFavorites= %s' % (repr(cat), repr(SearchAllFavorites)))
    ADDON.setSetting('RecursiveSearch','true')
    
    conn = recordings.getConnection()
    c = conn.cursor()
    c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE '%Recursive:%' COLLATE NOCASE")  # Find all recursive recordings
    recordingsE = c.fetchall()
    # Put recursive recordings changed last - first
    recordingsC = sorted(recordingsE, key=itemgetter(2), reverse=True)
    ####utils.logdev('findrecursivetvguide.py: Recursive recordings',repr(recordingsC))
    for index in range(0, len(recordingsC)):
        if isinstance(recordings.parseDate(recordingsC[index][2]), datetime.date) and isinstance(recordings.parseDate(recordingsC[index][3]), datetime.date) and 'Recursive:' in recordingsC[index][1]:
            if int(ADDON.getSetting('SearchRecursiveIn')) > 0 or ((not SearchAllFavorites == 'NotAllFavorites')and(not SearchAllFavorites == 'Once')and(not SearchAllFavorites == 'Hour')):
                if not recordingsC[index][0] in uniques:
                    findrecursiveinplaychannel(recordingsC[index][0],recordingsC[index][1],index) # Allways search channel in record
                    if ADDON.getSetting('NotifyOnSearch')=='true' and not '[COLOR orange]' in recordingsC[index][1]:
                        utils.notification('Find%s [COLOR green]complete in own channel[/COLOR]' % recordingsC[index][1])
                for cat in uniques:
                    findrecursiveinplaychannel(cat,recordingsC[index][1],index)
                if ADDON.getSetting('NotifyOnSearch')=='true' and not '[COLOR orange]' in recordingsC[index][1]:
                    utils.notification('Find%s [COLOR green]complete[/COLOR]' % recordingsC[index][1])
            else:
                findrecursiveinplaychannel(recordingsC[index][0],recordingsC[index][1],index)
                if ADDON.getSetting('NotifyOnSearch')=='true' and not '[COLOR orange]' in recordingsC[index][1]:
                    utils.notification('Find%s [COLOR green]complete[/COLOR] in selected channel: %s' % (recordingsC[index][1], recordingsC[index][0]))
    conn.commit()
    c.close()
    if ADDON.getSetting('NotifyOnSearch')=='true':
        utils.notification('Find all recursives [COLOR green]complete[/COLOR]')
    locking.scanUnlockAll()
    ADDON.setSetting('RecursiveSearch','false')
    return

def findrecursiveinplaychannel(cat,title,index):
    if locking.isAnyRecordLocked():
        locking.scanUnlockAll()
        return
    if '[COLOR orange]' in title:
        utils.logdev('findrecursiveinplaychannel','DISABLED: %s' % repr(title))  # Put message in LOG
        return

    name = title
    try:
        name = name.split('Recursive:')[1]
    except:
        pass
    newname = recordings.latin1_to_ascii(name)
    newname = newname.strip()
    now= datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20')
    nowT= recordings.parseDate(datetime.datetime.today())
    
    conn = recordings.getConnection() ###################### TV Guide database
    c = conn.cursor()
    c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name CONTAINS 'Recursive:'")  ####################################################################################################
    recordingsE = c.fetchall()
    # Put recursive recordings changed last - first
    recordingsC = sorted(recordingsE, key=itemgetter(2), reverse=True)
    ####utils.logdev('findrecursivetvguide.py: Recursive recordings',repr(recordingsC))
    for field in recordingsC:
        time='[COLOR yellow](%s) - [/COLOR]'%(startDate.strftime('%H:%M'))
        recordnameT = recordings.latin1_to_ascii(recordname)
        startDateT = recordings.parseDate(startDate)
        if (newname.upper() in recordnameT.upper()) and (nowT < (startDateT + datetime.timedelta(hours = TimeZoneOffset))):
            recordings.schedule(cat, startDate + datetime.timedelta(hours = TimeZoneOffset), endDate + datetime.timedelta(hours = TimeZoneOffset), recordname, description)


