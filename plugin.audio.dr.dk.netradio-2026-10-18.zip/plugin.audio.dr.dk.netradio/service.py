#!/usr/bin/python
# -*- coding: utf-8 -*-
import utils
import xbmcaddon, xbmc, xbmcvfs
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import _strptime
import os
import shutil

ADDON     = xbmcaddon.Addon('plugin.audio.dr.dk.netradio')
ADDONname = ADDON.getAddonInfo('name')
ADDONid   = ADDON.getAddonInfo('id')
PATH      = 'special://home/addons/%s/' % ADDONid
ADDONpath = xbmcvfs.translatePath(PATH)
datapath  = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
module= 'service.py'
xbmc.log('%s in %s' % (module,ADDONname))  ###, level=xbmc.LOGNOTICE)

utils.ADDONresetSettingsToIni()   ### delete all setting*.set files

nowHMS=datetime.today().strftime('%Y-%m-%d %H:%M:%S')
if not os.path.exists(datapath):
    os.makedirs(datapath) 
addonlog = os.path.join(datapath, 'addonfind.log')
LogDev = open(addonlog, 'w')
LogDev.write(nowHMS + ' ' + 'Application restarted and the log cleared\n\n')
LogDev.close()

utils.ADDONsetSetting('startstation_running','false')
utils.ADDONsetSetting('startstationrunning','false')
utils.ADDONsetSetting('findstationrunning','false')

def __log(text):
    utils.logdev(module,text)

__log('\n\n' + nowHMS + ' ' + 'Application restarted\n\n')
__log('Start')
__log('service.py in %s' % ADDONname)

utils.shareLogs(False)
utils.logbackupreset()   ### copy log to OLDlog and delete log 2023-11-12
utils.logdevreset()

utils.ADDONresetSetting('LastFindStation','')
__log('34 setSetting(programplaying= %r' % '<space>')
utils.ADDONresetSetting('programplaying','')

settings    = os.path.join(datapath,'settings.xml')   ### 2020-11-24
settingsOLD = os.path.join(datapath,'settingsOLD.xml')
try:
    size = os.path.getsize(settings)
    ###maxsize = 10 * 1024 * 1024 # 10 MB
    __log('settings.xml size= %r' % size)
    if size < 1000:
        __log('copy settingsOLD --> settings')
        shutil.copyfile(settingsOLD, settings)
    elif os.path.exists(settings) and size >= 1000:
        __log('copy settings --> settingsOLD')
        shutil.copyfile(settings, settingsOLD)
except Exception as e:
    pass
    __log('%r: Reset settings.xml failed: %r' % (ADDONname,e))
    xbmc.log('%r: Reset settings.xml failed: %r' % (ADDONname,e))


__log('Ended')

def now():   ### Local time
    dt_obj= datetime.now()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def TS(timestr):
    ### time format 2019-05-21T22:05:00Z
    time_tuple = time.strptime(timestr, "%Y-%m-%dT%H:%M:%S%z")
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
   
def nowTS():   ### UTC time
    dt_obj= datetime.utcnow()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def nowS(format):   ### Now date string UTC time
    time_tuple = time.localtime(nowTS())
    date_str = time.strftime(format, time_tuple)
    return(date_str)
    
def nowL(format):   ### Now date string Local time
    time_tuple = time.localtime(now())
    date_str = time.strftime(format, time_tuple)
    return(date_str)
    
def datestr(timestamp,format):   ### Now date string UTC time %Y-%m-%dT%H:%M:%SZ
    time_tuple = time.localtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)

def findprograms(delayHMS):
    __log('findprograms(delayHMS= %r)' % delayHMS)
    """
    findP = utils.ADDONgetSetting('LastFindStation')  ### datestr(nowTS(),'h%Hm%Ms%S'))
    if findP == '':
        delta = 800
    else:
        delta = nowTS() - TS(findP)
    __log('delta= %r' % delta)
    if delta > 700:
    """
    __log('Start findprograms:'+nowL('d%dh%Hm%Ms%S'))
    script = os.path.join(ADDONpath, 'findstation.py')
    __log('script= %r' % script)
    nameAlarm = ADDONid + '-findstations-'+delayHMS.replace(':','')
    __log('nameAlarm= %r' % nameAlarm)
    ###delayHMS = '00:01:00'   ### Run every 1 minute
    ###delayHMS = '00:00:00'   ### Run once
    __log('delayHMS= %r' % delayHMS)
    ###cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),%s,loop,silent)' % (nameAlarm, script, PATH,delayHMS,delayHMS)
    if delayHMS == '00:00:00':
        cmd = 'AlarmClock(%s,RunScript(%s,%s,%s %r),%s,silent)' % (nameAlarm, script, PATH,delayHMS,nowL('d%dh%Hm%Ms%S'),delayHMS)
    else:
        cmd = 'AlarmClock(%s,RunScript(%s,%s,%s %r),%s,loop,silent)' % (nameAlarm, script, PATH,delayHMS,nowL('d%dh%Hm%Ms%S'),delayHMS)
    __log('cmd= %s' % cmd)
    xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarm)
    xbmc.executebuiltin(cmd)  # Activate
    __log('findprograms(delayHMS= %r) FINISHED' % delayHMS)
Level = utils.ADDONgetSetting('defaultvolumen')
utils.setAudioLevel(Level) 
utils.krogsbellNOTWatchingVideo()
if utils.ADDONgetSetting('autorunatstart').lower() == 'true' :  ### 2024-05-16 run when autorunatstart is true
    __log('106 setSetting(programplaying= %r' % '<space>')
    ADDON.setSetting('autorun','true')
    utils.ADDONresetSetting('programplaying','')
    utils.ADDONresetSetting('ProgramPlayingScheduled','')
    findprograms('00:00:00')
    try:
        timebetweenupdates = utils.ADDONgetSetting('timebetweenupdates')
    except Exception as e:
        pass
        timebetweenupdates = '00:05:00'
        utils.ADDONsetSetting('timebetweenupdates',timebetweenupdates)
    __log('timebetweenupdates= %s' % timebetweenupdates)
    findprograms(timebetweenupdates)   
