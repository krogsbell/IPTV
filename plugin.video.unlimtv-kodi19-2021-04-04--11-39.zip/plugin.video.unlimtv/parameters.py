#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
import utils
from urllib.parse import unquote_plus

def log(message):
    module = 'parameters.py'
    utils.logdev(module,message)
    
class Parameters:

    url = None
    uri = None
    name = None
    mode = None
    icon_image = None
    date = None
    description = None
    cat = None
    start_date = None
    end_date = None
    recordname = None
    prev_mode = None
    source = None
    

    def __init__(self):
        params = Parameters.read_parameters()
        log('params= %r' % params)
        try:
            self.url = unquote_plus(params["url"])
            log('url= %r' % self.url)
        except Exception as e:
            pass
            log('Exception= %r' % e)
        try:
            self.uri = unquote_plus(params["uri"])
            log('uri= %r' % self.uri)
        except Exception as e:
            pass
            log('Exception= %r' % e)
        try:
            self.name = unquote_plus(params["name"])
            log('name= %r' % self.name)
        except Exception as e:
            pass
            log('Exception= %r' % e)
        try:
            self.icon_image = unquote_plus(params["iconimage"])
            log('icon_image= %r' % self.icon_image)
        except Exception as e:
            pass
            log('Exception= %r' % e)
        try:
            self.mode = int(params["mode"])
            log('mode= %r' % self.mode)
        except Exception as e:
            pass
            log('Exception= %r' % e)
        try:
            self.prev_mode = int(params["prev_mode"])
            log('prev_mode= %r' % self.prev_mode)
        except Exception as e:
            pass
            log('Exception= %r' % e)

        try:
            self.cat = unquote_plus(params["cat"])
            log('cat= %r' % self.cat)
        except Exception as e:
            pass
            log('Exception= %r' % e)
        try:
            self.date = str(params["date"])
            log('date= %r' % self.date)
        except Exception as e:
            pass
            log('Exception= %r' % e)
        try:
            self.description = unquote_plus(params["description"])
            log('description= %r' % self.description)
        except Exception as e:
            pass
            log('Exception= %r' % e)
        try:
            self.start_date = str(params["startDate"])
            log('start_date= %r' % self.start_date)
        except Exception as e:
            pass
            log('Exception= %r' % e)
        try:
            self.end_date = str(params["endDate"])
            log('end_date= %r' % self.end_date)
        except Exception as e:
            pass
            log('Exception= %r' % e)
        try:
            self.recordname = unquote_plus(params["recordname"])
            log('recordname= %r' % self.recordname)
        except Exception as e:
            pass
            log('Exception= %r' % e)
        try:
            self.source = unquote_plus(params["source"])
            log('source= %r' % self.source)
        except Exception as e:
            pass
            log('Exception= %r' % e)

    @staticmethod
    def read_parameters():
        log('sys.argv= %r' % sys.argv)
        param = []
        paramstring = sys.argv[2]
        log('paramstring= %r' % paramstring)
        if len(paramstring) >= 2:
            params = sys.argv[2]
            cleanedparams = params.replace('?', '').replace('& ','aMp ').replace('&%20','aMp%20') 
            if (params[len(params) - 1] == '/'):
                params = params[0:len(params) - 2]
            pairsofparams = cleanedparams.split('&')
            param = {}
            for i in range(len(pairsofparams)):
                splitparams = {}
                splitparams = pairsofparams[i].split('=',1)
                if (len(splitparams)) == 2:
                    param[splitparams[0]] = splitparams[1].replace('aMp ','& ').replace('aMp%20','&%20') 
        log('param= %r' % param)
        return param
