#!/usr/bin/python
# -*- coding: utf-8 -*-
from platform import Platform
from settings import Settings
from api import Api
from parameters import Parameters
from logger import Log
from gui import Gui
from middleware import Middleware
import xbmc, xbmcvfs
import xbmcaddon
import xbmcplugin
import xbmcgui
import sys

import base64
import utils
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import time

def log(message):
    module = 'app.py'
    utils.logdev(module,message)
    

class App:

    MODE_CATEGORIES = None
    MODE_CHANNELS = 2
    MODE_FAVORITES = 3
    MODE_SEARCH = 4
    MODE_FAV_ADD = 5
    MODE_FAV_REMOVE = 6
    MODE_PLAY = 200
    MODE_PLAY_REMOTE = 2000
    MODE_RECORD = 210
    MODE_RECORD_ARCHIVE = 2100
    MODE_SYNC = 211
    MODE_EXIT = 666

    addon = None
    settings = None
    api = None
    parameters = None
    gui = None
    middleware = None

    data_path = None

    def __init__(self):
        self.addon = xbmcaddon.Addon(id = Platform.PLUGIN)
        self.data_path = xbmcvfs.translatePath(self.addon.getAddonInfo('profile'))
        self.settings = Settings(self.addon)
        self.parameters = Parameters()
        self.gui = Gui(self, self.addon, self.settings)
        self.api = Api(self, self.settings)
        self.middleware = Middleware(self, self.api)
        return

    def ts(self,ds):   ### Date string to timestamp
        if type(ds) != str:
            return ds
        ###ds = "2008-11-10 17:53:59"
        time_tuple = time.strptime(ds, "%Y-%m-%d %H:%M:%S")
        ###time_tuple = (2008, 11, 12, 13, 59, 27, 2, 317, 0)
        ts = int(time.mktime(time_tuple))
        log('int ts')
        return ts

    def tsA(self,ds):   ### Archive date string to timestamp
        ###'2020-02-15:16-57' does not match format '%Y-%m-%d %H:%M:%S'
        """
        dt_obj.strftime("%Y-%m-%d %H:%M:%S")
        date_str = "2008-11-10 17:53:59"
        time_tuple = time.strptime(date_str, "%Y-%m-%d %H:%M:%S")
        dt_obj = datetime.datetime(*time_tuple[0:6])
        startDate =
        """ 
        if type(ds) != str:
            return ds
        ###ds = "2008-11-10:17-53"
        time_tuple = time.strptime(ds, "%Y-%m-%d:%H-%M")
        ###time_tuple = (2008, 11, 12, 13, 59, 27, 2, 317, 0)
        ts = int(time.mktime(time_tuple))
        log('int tsA')
        return ts

    def humantime(self,ts):   ### Timestamp to human time
        if type(ts) != int:
            try:
                log('int humantime 0')
                ts = int(ts)
                log('int humantime 1')
            except Exception as e:
                pass
                Log.log('humantime %r ERROR: %r' % (ts,e))
                return ts
        dt = datetime.fromtimestamp(ts)
        ht = dt.strftime("%Y-%m-%d %H:%M:%S")
        ###ht = dt.strftime("%m-%d %H:%M")
        return ht
    
    def run(self):

        auth = False

        # if we have cookies, lets just use it
        if self.api.have_cookies_in_file():
            Log.log('---- have cookies ----')
            self.api.load_cookies()
            auth = True

        # first we try to auth with saved creds
        if not auth:
            Log.log('---- no cookies ----')
            email = self.settings.get(Settings.EMAIL)
            password = self.settings.get(Settings.PASSWORD)
            if len(email) > 0 and len(password) > 0:
                Log.log('---- have settings ----')
                data = self.api.login(email, password)
                if data['status'] == 1:
                    auth = True
                    self.api.save_cookies()
                else:
                    self.api.erase_cookies()

        # saved creds did not work, ask for sign in or register
        if not auth:
            Log.log('---- could not auto auth ----')
            auth = self.signin()
            '''
            if self.gui.signin_or_register():
                auth = self.signin()
            else:
                if self.register():
                    # succesful reg, lets try to auth again
                    email = self.settings.get(Settings.EMAIL)
                    password = self.settings.get(Settings.PASSWORD)
                    if len(email) > 0 and len(password) > 0:
                        data = self.api.login(email, password)
                        if(data['status'] == 1):
                            auth = True
                            self.api.save_cookies()
                        else:
                            self.api.erase_cookies()
            '''

        if auth:
            mode = self.parameters.mode
#            if mode is None:
#                mode = self.App.MODE_EXIT
        else:
            mode = App.MODE_EXIT
        Log.log('self.parameters= %r' % self.parameters)
        if mode == App.MODE_CATEGORIES:
            self.mode_categories()

        elif mode == App.MODE_CHANNELS:
            self.mode_channels(self.parameters.cat)

        elif mode == App.MODE_FAVORITES:
            self.mode_favorites()

        elif mode == App.MODE_PLAY:
            Log.log('MODE_PLAY cat= %r' % self.parameters.cat)
            Log.log('MODE_PLAY description= %r' % self.parameters.description)
            Log.log('MODE_PLAY source= %r' % self.parameters.source)
            self.mode_play(self.parameters.cat,self.parameters.description,self.parameters.source)
            
        elif mode == App.MODE_PLAY_REMOTE:
            Log.log('MODE_PLAY_REMOTE cat= %r' % self.parameters.cat)
            Log.log('MODE_PLAY_REMOTE url= %r' % self.parameters.url)
            Log.log('MODE_PLAY_REMOTE uri= %r' % self.parameters.uri)
            self.mode_play_remote(self.parameters.cat,self.parameters.uri,self.parameters.url)

        elif mode == App.MODE_RECORD:
            Log.log('MODE_RECORD cat= %r' % self.parameters.cat)
            Log.log('MODE_RECORD url= %r' % self.parameters.url)
            Log.log('MODE_RECORD uri= %r' % self.parameters.uri)
            self.mode_record(self.parameters.cat,self.parameters.uri,self.parameters.url)
            
        elif mode == App.MODE_RECORD_ARCHIVE:
            Log.log('MODE_RECORD_ARCHIVE cat= %r' % self.parameters.cat)
            Log.log('MODE_RECORD_ARCHIVE url= %r' % self.parameters.url)
            Log.log('MODE_RECORD_ARCHIVE uri= %r' % self.parameters.uri)
            self.mode_record_archive(self.parameters.cat,self.parameters.uri,self.parameters.url)
            
        elif mode == App.MODE_SYNC:
            Log.log('MODE_SYNC cat= %r' % self.parameters.cat)
            Log.log('MODE_SYNC url= %r' % self.parameters.url)
            Log.log('MODE_SYNC uri= %r' % self.parameters.uri)
            self.mode_sync(self.parameters.cat,self.parameters.url)

        elif mode == App.MODE_SEARCH:
            self.mode_search()

        elif mode == App.MODE_FAV_ADD:
            self.mode_fav_add(self.parameters.cat)

        elif mode == App.MODE_FAV_REMOVE:
            self.mode_fav_remove(self.parameters.cat)

        elif mode == App.MODE_EXIT:
            App.exit()

        xbmcplugin.endOfDirectory(int(sys.argv[1]))




    def signin(self):
        Log.log('---- app.signin ----')
        email, password = self.gui.signin()
        data = self.api.login(email, password)
        if data['status'] == 0:
            if self.gui.please_try_again(data['message']):
                return self.signin()
            else:
                return False
        else:
            Log.log('---- app signin success, saving settings ----')
            self.settings.set(Settings.EMAIL, email)
            self.settings.set(Settings.PASSWORD, password)
            self.api.save_cookies()
            return True

    def register(self):
        firstname, lastname, email, password = self.gui.register()
        data = self.api.register(firstname, lastname, email, password)
        if data['status'] == 0:
            if self.gui.exit_and_restart(data['message']):
                return self.register()
            else:
                return False
        else:
            self.gui.register_success()
            self.settings.set(Settings.EMAIL, email)
            self.settings.set(Settings.PASSWORD, password)
            return True


    def mode_categories(self):
        Log.log('---- mode categories ----')
        categories = self.middleware.get_categories()
        self.gui.categories(categories)

    def mode_channels(self, category):
        log('mode_channels category= %r' % category)
        channels = self.middleware.get_channels(category)
        log('mode_channels channels= %r' % channels)
        self.gui.channels(channels)

    def mode_search(self, name = ''):
        if len(name) == 0:
            name = self.gui.search('channel name')
        channels = self.middleware.search_channel(name)
        self.gui.channels(channels)

    def mode_favorites(self):
        channels = self.middleware.get_favs()
        self.gui.channels(channels)

    def mode_play_remote(self, channel_id,description,source):
        Log.log('mode_play_remote channel_id= %r' % channel_id)
        Log.log('mode_play_remote description= %r' % description)
        Log.log('mode_play_remote source= %r' % source)
        """
        __log('default_list_item= %r' % default_list_item)
        win = xbmcgui.Window(xbmcgui.getCurrentWindowId())
        __log('xbmcgui.Window= %r' % win)
        cid = win.getFocusId()
        __log('win.getFocusId= %r' % cid)
        xbmc.executebuiltin('SetFocus(%s, %s)' % (cid, show_list_item))
        
        xbmc.executebuiltin("ActivateWindow(%s)" % EPGWindowId.replace("'",""))
        """
        CurrentWindowId = repr(xbmcgui.getCurrentWindowId())
        WindowId = self.addon.getSetting('WindowId')
        Log.log('1.CurrentWindowId= %r, WindowId= %r' % (CurrentWindowId, WindowId))
        
        if CurrentWindowId != WindowId :
            Log.log('ActivateWindow(%s)' % WindowId.replace("'",""))
            if WindowId != '':
                xbmc.executebuiltin("ActivateWindow(%s)" % WindowId.replace("'",""))
            CurrentWindowId = repr(xbmcgui.getCurrentWindowId())
            self.addon.setSetting('WindowId',str(CurrentWindowId))
        Log.log('2.CurrentWindowId= %r, WindowId= %r' % (CurrentWindowId, WindowId))
        log('get_channel 1 channel_id= %r' % channel_id)
        channel = self.middleware.get_channel(channel_id)
        if channel['health'] == 1:
            data = self.middleware.get_channel_link(channel_id)
            if data['status'] == 1:
                if source != None and source != '' : ### and 1==0:  ### Only run else - test
                    Log.log('return_stream source= %r' % source)
                    self.gui.return_stream(channel['name'], data['body'], channel['logo'], description, source)
                else:
                    Log.log('play_stream_remote source= %r' % source)
                    self.gui.play_stream(channel['name'], data['body'], channel['logo'],source)
            else:
                self.gui.show_message(data['message'])
        else:
            self.gui.show_message('Channel is temporarily unavailable', 'We are working to have it fixed')

    def mode_play(self, channel_id,description,source):
        Log.log('mode_play channel_id= %r' % channel_id)
        Log.log('mode_play description= %r' % description)
        Log.log('mode_play source= %r' % source)
        log('get_channel 2 channel_id= %r' % channel_id)
        channel = self.middleware.get_channel(channel_id)
        if channel['health'] == 1:
            data = self.middleware.get_channel_link(channel_id)
            if data['status'] == 1:
                if source != None and source != '' : ### and 1==0:  ### Only run else - test
                    Log.log('return_stream source= %r' % source)
                    self.gui.return_stream(channel['name'], data['body'], channel['logo'], description, source)
                else:
                    Log.log('play_stream source= %r' % source)
                    self.gui.play_stream(channel['name'], data['body'], channel['logo'],source)
            else:
                self.gui.show_message(data['message'])
        else:
            self.gui.show_message('Channel is temporarily unavailable', 'We are working to have it fixed')
    """
    2020-02-18 09:49:04 Original UnLim.tv APP: ----------- Api::play_channel html u'{"status":1,"body":"https:\\/\\/68.gibberish.live:443\\/edge\\/1059\\/index.m3u8?token=3.1.1187.cc2721cf160b5f8a22e39b157a340d75.1.2.3.73.0.0.68f43b0b354e21dd009d826c6e755683","message":null}'
    2020-02-18 09:49:04 Original UnLim.tv APP: ----------- Api::play_channel data {u'status': 1, u'body': u'https://68.gibberish.live:443/edge/1059/index.m3u8?token=3.1.1187.cc2721cf160b5f8a22e39b157a340d75.1.2.3.73.0.0.68f43b0b354e21dd009d826c6e755683', u'message': None}
    2020-02-18 09:49:04 Original UnLim.tv APP: fetch(self, url= 'https://www.touchsportstv.com/channels/get-record/951/1578598800/6900', data= {}
    #EXTM3U
    #EXT-X-STREAM-INF:CLOSED-CAPTIONS=NONE,RESOLUTION=640x360,FRAME-RATE=25.000,CODECS="avc1.4d001f,mp4a.40.2",AVERAGE-BANDWIDTH=973182,BANDWIDTH=1216477
    tracks-v1a1/mono.m3u8?token=3.1.1187.cc2721cf160b5f8a22e39b157a340d75.1.2.3.66.0.0.b3f44f1c39a2f68c43c6d53f20c78960

    https://61.gibberish.live:443/edge/1066/index.mp4?token=3.1.1187.cc2721cf160b5f8a22e39b157a340d75.1.2.3.66.0.0.b3f44f1c39a2f68c43c6d53f20c78960
    """
    def mode_record(self, channel_id,description,source):
        Log.log('mode_record channel_id= %r' % channel_id)
        Log.log('mode_record description= %r' % description)
        Log.log('mode_record source= %r' % source)
        log('get_channel 3 channel_id= %r' % channel_id)
        channel = self.middleware.get_channel(channel_id)
        if channel['health'] == 1:
            data = self.middleware.get_channel_link(channel_id)
            if data['status'] == 1:
                ###self.gui.record_stream(channel['name'], data['body'], channel['logo'], description, source)
                self.gui.return_stream(channel['name'], data['body'], channel['logo'], description, source)
            else:
                self.gui.show_message(data['message'])
        else:
            self.gui.show_message('Channel is temporarily unavailable', 'We are working to have it fixed')
            
    def mode_record_archive(self, channel_id,description,source):
        Log.log('mode_record_archive channel_id= %r' % channel_id)
        Log.log('mode_record_archive description= %r' % description)
        Log.log('mode_record_archive source= %r' % source)
        
        FullDescription = description
        if description != None and description != '':
            try:
                if description[:3] == 'b64':
                    decoded = base64.b64decode(description[3:])
                else:
                    decoded = description
            except Exception as e:
                pass
                Log.log('base64.b64decode Error %r' % e)
                decoded = description
            FullDescription = decoded
        
        Log.log('base64.b64decode(FullDescription=\n%r' % FullDescription)
        
        """
        <div class="js-evt-play event-pop-up__button" data-dvr-link="" data-channel-id="967" data-dvr-event-start="1574883600" data-dvr-event-duration="7800" data-dvr-event="Hvidsten Gruppen">PLAY</div>
        
        base64.b64decode(description=
'recordfromunlimcat=UNL967recordfromunlimtitle=Test af TV/2 Charlierecordfromunlimduration=5600recordfromunlimdescription=TV2 Charlie UNL-DK (UNL967): \nStart 2020-01-05 02:40 \nDuration [01:10]. \nEPG Created 2020-01-04 00:15:24\n\nEfter den voldsomme trafikulykke er Hanssen splittet mellem at hj\xc3\xa6lpe Malick og redde Chantelles liv - men kan han redde dem begge? \n\nEPG Created 2020-01-04 00:15:24recordfromunlimstartDate=2020-01-09 00:15:00'
        """
        try:
            """
            2021-01-30 01:54:47 Original UnLim.tv APP: cat= 'UNL949'
            2021-01-30 01:54:47 Original UnLim.tv APP: name= 'Helt lyrisk [Underholdning. Programmer]. (E3) (2019) (DR1 UNL-DK)'
            2021-01-30 01:54:47 Original UnLim.tv APP: evtDuration= '2021-01-29:12-37'
            2021-01-30 01:54:47 Original UnLim.tv APP: description= '48'
            2021-01-30 01:54:47 Original UnLim.tv APP: startDate= 'DR1 UNL-DK (UNL949): \nStart 2021-01-29 14:40 \nDuration [00:30]. \nEPG Created 2021-01-30 01:32:25\n\nLise R\xc3\xb8nne stiller Infernal-sangerinden Lina Rafn og popkometen Hjalmer den vanskelige udfordring at skrive hver deres sang ud fra samme digt. Men ikke nok med d\xc3\xa9t. Digtet er skrevet af national-klenodiet Halfdan Rasmussen, og sangen skal opf\xc3\xb8res live. Digtet er ikke en af de sjove Halfdan Rasmussen-tekster, men meget alvorlig lyrik om at miste sin k\xc3\xa6re, som is\xc3\xa6r Lina Rafn bliver ber\xc3\xb8rt af. Begge sangere er bange for, at de vil komme til at lave den samme melodi, n\xc3\xa5r de til sidst st\xc3\xa5r overfor publikum. \n\nEPG Created 2021-01-30 01:32:25'
            """
            Log.log('FullDescription= %r' % FullDescription)
            description3 = FullDescription.split('recordfromunlim')
            Log.log('description3= %r' % description3)
            cat = description3[1].split('=',1)[1]
            Log.log('cat= %r' % cat)
            name = description3[2].split('=',1)[1]
            Log.log('name= %r' % name)
            startDate = description3[3].split('=',1)[1]
            Log.log('startDate= %r' % startDate)
            evtDuration = description3[4].split('=',1)[1]
            Log.log('evtDuration= %r' % evtDuration)
            description = description3[5].split('=',1)[1]
            Log.log('description= %r' % description)
            evtStart = str(self.tsA(startDate))
            Log.log('evtStart= %r' % evtStart)
            humanStart = self.humantime(evtStart)
            Log.log('humanStart= %r' % humanStart)
        
        except Exception as e:
            pass
            Log.log('mode_record_archive ERROR: %r' % e)
            evtStart = '1574883600'
            evtDuration = '120'
            
        ##evtStart = '1578598800'
        ##evtDuration = '6900'
        ### https://www.touchsportstv.com/channels/get-record/967/1578599100/6900
        log('get_channel 4 channel_id= %r' % channel_id)
        channel = self.middleware.get_channel(channel_id)
        if channel['health'] == 1:
            ### data = self.middleware.get_channel_link(channel_id)
            
            data = self.middleware.get_channel_link(channel_id)   ### 2020-10-06
            Log.log('get_channel_link(channel_id= %r)= %r' % (channel_id,data))
            stream = self.gui.return_stream(channel['name'], data['body'], channel['logo'], description, source)
            Log.log('get_channel_link stream= %r' % stream)
            
            data = self.middleware.get_archive_link(channel_id, evtStart, evtDuration)
            Log.log('get_archive_link data= %r' % data)
            if data['status'] == 1:
                url = data['body']
                Log.log('url= %r' % url)
                """
                Log.log('play_stream(self, name= %r, url= %r, logo)' % (name,url))
                remote_icon = Platform.SITE + '/assets/img/channels/' + logo + '|auth=TLS&verifypeer=false'
                item = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = remote_icon)
                item.setInfo(type="Video", infoLabels={"Title": name})
                item.setProperty("IsPlayable", "true")
                item.setPath(url)
                Log.log('play_stream(self, name= %r, url= %r\nsys.argv= %r)' % (name,url,sys.argv))
                HANDLE = int(sys.argv[1])
                if HANDLE != -1:
                    xbmcplugin.setResolvedUrl(HANDLE, True, item)
                """
                self.gui.record_stream_archive(channel['name'], data['body'], channel['logo'], FullDescription, source) ### 2020-10-04
            else:
                self.gui.show_message(data['message'])
        else:
            self.gui.show_message('Channel is temporarily unavailable', 'We are working to have it fixed')
            
    def mode_sync(self, channel_id, url):
        Log.log('mode_sync channel_id= %r\n%r' % (channel_id,url))
        evtStart = 1111111111
        evtDuration = 120
        channel = self.middleware.get_archive_link(channel_id, evtStart, evtDuration)
        if channel['health'] == 1:
            data = self.middleware.get_archive_link(channel_id, evtStart, evtDuration)
            if data['status'] == 1:
                self.gui.sync_stream(channel['name'], data['body'], channel['logo'])
            else:
                self.gui.show_message(data['message'])
        else:
            self.gui.show_message('Channel is temporarily unavailable', 'We are working to have it fixed')

    def exit_with_message(self, message):
        self.gui.show_message(message)
        App.exit()

    def mode_fav_add(self, channel_id):
        self.middleware.fav_add(channel_id)

    def mode_fav_remove(self, channel_id):
        self.middleware.fav_remove(channel_id)

    def remove_auth(self):
        self.api.erase_cookies()
        #self.settings.set(Settings.EMAIL, "")
        #self.settings.set(Settings.PASSWORD, "")

    @staticmethod
    def exit():
        xbmc.executebuiltin("XBMC.Container.Update(path,replace)")
        xbmc.executebuiltin("XBMC.ActivateWindow(Home)")

