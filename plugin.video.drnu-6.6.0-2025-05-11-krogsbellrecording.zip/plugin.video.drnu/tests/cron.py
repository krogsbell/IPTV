

class CronManager():
    def getJobs(self):
        return []


class CronJob():
    pass