#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
import sys
import urllib
import time
import datetime
import base64
from platformunl import Platform
from settings import Settings
import utils

ADDON   = xbmcaddon.Addon()
ADDONid = ADDON.getAddonInfo('id')

def log(message):
    module = 'gui.py'
    utils.logdev(module,message)
    
class Gui:
    dialog = None
    addon = None
    settings = None
    app = None

    def __init__(self, _app, _addon, _settings):
        self.dialog = xbmcgui.Dialog()
        self.app = _app
        self.addon = _addon
        self.settings = _settings
    
    @staticmethod
    def log(message):
        module = 'Gui.gui.py'
        utils.logdev(module,message)
    
    @staticmethod
    def search(name):
        search_entered = None
        keyboard = xbmc.Keyboard(search_entered, 'Please Enter ' + str(name))
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText()
        return search_entered

    def numeric(self, name):
        keyboard = self.dialog.numeric(0, 'Please Enter ' + str(name))
        return keyboard

    @staticmethod
    def signin():
        email = Gui.search('Email')
        password = Gui.search('Password')
        return email, password

    @staticmethod
    def register():
        firstname = Gui.search('First Name')
        lastname = Gui.search('Last name')
        email = Gui.search('Email')
        password = Gui.search('Password')
        return firstname, lastname, email, password

    def signin_or_register(self):
        return self.dialog.yesno(Platform.BRAND, 'Do you Wish To Register', '', "Or Sign In", 'Register', 'Sign In')

    def register_success(self):
        self.dialog.ok(Platform.BRAND, 'Thank You For Registering', 'Please Open Your Email Client',
                       'And Verify Your Email Address')

    def show_message(self, line1 = '', line2 = '', line3 = ''):
        self.dialog.ok(Platform.BRAND, line1, line2, line3)

    def exit_and_restart(self, message):
        return self.dialog.yesno(Platform.BRAND, message, '', 'Exit And Restart Again')

    def please_try_again(self, message):
        return self.dialog.yesno(Platform.BRAND, message, '', 'Please Try Again')

    def categories(self, categories):
        imageUrl = ''
        # if ADDON.getSetting('enable_record') == 'true':
        #    addDir('My Recordings', 'url', 6, '', '', '', '')
        # addDir('My Account', 'url', 8, '', '', '', '')
        self.add_folder('Favorites', self.app.MODE_FAVORITES, '')
        self.add_folder('All channels', self.app.MODE_CHANNELS, '')
        self.add_folder('Search by name', self.app.MODE_SEARCH, '')
        log('categoriesXyX= %r' % categories)
        categories = sorted(categories.items(), key = lambda kv: kv[1])
        log('categoriesXyZ= %r' % categories)
        for tuple in categories:
            self.add_folder(tuple[1], self.app.MODE_CHANNELS, str(tuple[0]))
            #self.addDir(categories[k], 'url', self.app.MODE_CHANNELS, imageUrl + '/tvicon.jpg', str(k), '', '')
        self.setView('movies', 'main-view')

    def channels(self, channels):
        ###log('channels= %r' % channels)
        try:
            Channels = []
            log('len(channels)= %r' % len(channels))
            for k in channels:
                thischannel = channels[k]
                log('channelK= %r' % thischannel)
                log('channelKname= %r' % thischannel['name'])
                Channels.append([thischannel['name'].replace(' ',''),channels[k]])
            Channels = sorted(Channels)
            log('ChannelsXyX= %r' % Channels)
            for i in range(0, len(Channels)):
                self.add_channel(Channels[i][1])
        except Exception as e:
            pass
            log('channels= ERROR %r' % e)
        self.setView('movies', 'channels-view')

    def play_stream(self, name, url, logo, source):
        log('play_stream(self, name= %r, url= %r, logo= %r, source= %r)' % (name,url,logo,source))
        remote_icon = Platform.SITE + '/assets/img/channels/' + logo + '|auth=TLS&verifypeer=false'
        item = xbmcgui.ListItem(name)
        item.setArt({ 'icon': "DefaultVideo.png", 'thumb' : remote_icon })
        item.setInfo(type="Video", infoLabels={"Title": name})
        item.setProperty("IsPlayable", "true")
        item.setPath(url)
        log('play_stream(self, name= %r, url= %r\nsys.argv= %r)' % (name,url,sys.argv))
        HANDLE = int(sys.argv[1])
        log('play_stream HANDLE= %r' % HANDLE)
        log('play_stream source= %r' % source)
        if HANDLE != -1 and source == None: ### If source != None - link is reported back elswhere
            log('setResolvedUrl/PlayMedia')
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            ###xbmc.executebuiltin("PlayMedia("+url+")")
            
            xbmcplugin.setResolvedUrl(HANDLE, True, item)
        else:
            log('Use vlc')
            cmd = 'vlc --fullscreen --play-and-stop "%s"' % url 
            LoopCount = 1
            log('runCommand(cmd= %r)' % cmd )
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            utils.runCommand(cmd, LoopCount, libpath = None, module_path = './', nameAlarm='')
        log('Play started')
            
    def return_stream(self, name, url, logo, description, source):
        log('return_stream(self, name= %r, url= %r, logo= %r, description= %r)' % (name,url,logo,description))
        log('return_stream(self, source= %r)' % (source))
        remote_icon = Platform.SITE + '/assets/img/channels/' + logo + '|auth=TLS&verifypeer=false'

        ###URI='plugin://plugin.video.dreamiptv/?url=url&mode=2012&source='+ADDONid+'&name=' + name+ ' [unlim.tv]&uri='+ url.replace(' ','AAabBB').replace('?','aAabBb').replace('=','BBabAA').replace(',','###').replace('&','AaAaA') + '&description='+description
        name = (name + ' [unlim.tv]').replace(' ','%20')
        log('name= %r'% name)
        log('description= %r'% description)
        if description == None:
            description = ''
        try:
            markerd = 'recordfromunlimdescription=b64'
            markerde = 'recordfromunlimdescription='
            if markerd in description:
                desc = description.split(markerd)
                log('desc= %r' % desc)
                log('desc[1].encode()= %r' % desc[1].encode())
                log('base64.b64decode(desc[1].encode()).decode()= %r' % base64.b64decode(desc[1].encode()).decode())
                description= desc[0] + markerde + base64.b64decode(desc[1].encode()).decode()
        except Exception as e:
            pass 
            log('description decode ERROR: %r' % e)
        log('url= %r'% url)
        log('url.encode()= %r'% url.encode())
        log('base64.b64encode(url.encode())= %r'% base64.b64encode(url.encode())) 
        log('description= %r'% description)
        log('description.encode()= %r'% description.encode())
        log('base64.b64encode(description.encode())= %r'% base64.b64encode(description.encode()))
        URI= source + '?url=url&mode=2012&cat=UNL&source=' + ADDONid + '&name=' + name + '&uri=b64'+ base64.b64encode(url.encode()).decode() + '&description=b64' + base64.b64encode(description.encode()).decode()
        ##64encode    
        log('unlim.tv-->recorduri.py: URI= %r' % URI)
        tries    = 0
        maxTries = 10
        maxSleep = 500
        try:
            log(repr(URI))
            xbmc.executebuiltin('RunPlugin(%s)' % URI) 
            xbmc.sleep(maxSleep)
        except Exception as e:
            pass 
            log('record_stream ERROR: %r' % e)
            
    def record_stream_archive(self, name, url, logo, description, source):
        """
        ###https://63.gibberish.live:443/dvr_storage/949/tracks-v1a1/2021/02/03/05/40/17-05000.ts?token=3.1.1262.57540cf0f6e1bf3aa6f4373a13a29697.1.2.3.64.1612323420.2280.f60fcc8a201f01e22ab69870c2ebaa95   ### 07:40 with 2 hours offset
        # https://63.gibberish.live:443/dvr_storage/_definst_/949/index.m3u8?token=3.1.1262.57540cf0f6e1bf3aa6f4373a13a29697.1.2.3.64.1612323420.2280.f60fcc8a201f01e22ab69870c2ebaa95
        #EXTM3U
        #EXT-X-STREAM-INF:CLOSED-CAPTIONS=NONE,RESOLUTION=640x360,FRAME-RATE=25.000,CODECS="avc1.64001e,mp4a.40.2",AVERAGE-BANDWIDTH=2001440,BANDWIDTH=2501800
        #tracks-v1a1/mono.m3u8?token=3.1.1262.57540cf0f6e1bf3aa6f4373a13a29697.1.2.3.64.1612323420.2280.f60fcc8a201f01e22ab69870c2ebaa95

        #https://63.gibberish.live:443/dvr_storage/949/tracks-v1a1/mono.m3u8?token=3.1.1262.57540cf0f6e1bf3aa6f4373a13a29697.1.2.3.64.1612323420.2280.f60fcc8a201f01e22ab69870c2ebaa95
        
        #EXTM3U
        #EXT-X-TARGETDURATION:5
        #EXT-X-VERSION:3
        #EXT-X-MEDIA-SEQUENCE:172652
        #EXT-X-PROGRAM-DATE-TIME:2021-02-03T10:04:52Z
        #EXTINF:5.000,
        2021/02/03/10/04/52-05000.ts?token=3.1.1262.57540cf0f6e1bf3aa6f4373a13a29697.1.2.3.64.1612323420.2280.f60fcc8a201f01e22ab69870c2ebaa95
        #EXTINF:5.000,
        2021/02/03/10/04/57-05000.ts?token=3.1.1262.57540cf0f6e1bf3aa6f4373a13a29697.1.2.3.64.1612323420.2280.f60fcc8a201f01e22ab69870c2ebaa95
        #EXTINF:5.000,
        2021/02/03/10/05/02-05000.ts?token=3.1.1262.57540cf0f6e1bf3aa6f4373a13a29697.1.2.3.64.1612323420.2280.f60fcc8a201f01e22ab69870c2ebaa95
        #EXTINF:5.000,
        2021/02/03/10/05/07-05000.ts?token=3.1.1262.57540cf0f6e1bf3aa6f4373a13a29697.1.2.3.64.1612323420.2280.f60fcc8a201f01e22ab69870c2ebaa95
        """
        log('record_stream_archive(self, name= %r, url= %r, logo, description= %r)' % (name,url,description))
        log('record_stream_archive(self, source= %r)' % (source))
        remote_icon = Platform.SITE + '/assets/img/channels/' + logo + '|auth=TLS&verifypeer=false'
        log('record_stream_archive(self, #= 1)')
        try:
            a= base64.b64encode(description.encode())
            a= a.decode()
        except Exception as e:
            pass
            log('record_stream_archive(self, description err= %r)' % e)
            a= base64.b64encode(description)
        log('record_stream_archive(self, #= 1.1)')
        try:
            b= base64.b64encode(url.encode())
            b= b.decode()
        except Exception as e:
            pass
            log('record_stream_archive(self, url err= %r)' % e)
            b= base64.b64encode(url)
        log('record_stream_archive(self, #= 1.2)')
        log('record_stream_archive(self, #= 1.3)\na= %r\nb= %r' % (a,b))
        URI= source + '?url=url&mode=2012&source=' + ADDONid + '&name=' + name + ' [unlim.tv]&uri=b64'+ b + '&description=b64' + a
        log('record_stream_archive(self, #= 2)')  
        log('unlim.tv-->recorduri.py: URI= %s' % repr(URI))
        log('record_stream_archive(self, #= 3)')
        tries    = 0
        maxTries = 10
        maxSleep = 500
        try:
            log('record_stream_archive(self, #= 4)')
            log(repr(URI))
            xbmc.executebuiltin('RunPlugin(%s)' % URI) 
            log('record_stream_archive(self, #= 5)')
            xbmc.sleep(maxSleep)
            log('record_stream_archive(self, #= 6)')
        except Exception as e:
            pass 
            log('record_stream_archive(self, #= 7)')
            log('record_stream_archive ERROR: %r' % e)
           
    def sync_stream(self, name, url, logo):
        log('sync_stream(self, name= %r, url= %r, logo)' % (name,url))
        remote_icon = Platform.SITE + '/assets/img/channels/' + logo + '|auth=TLS&verifypeer=false'
        ###URI='plugin://plugin.video.unlimtv/?url=url&mode=211&source='+ADDONid+'&cat=' + cat[3:] +'&startdate=' + str(startDateTS) +'&duration='+ duration
        log('url 1= %r' % url)
        url += '&'
        cat = Log.param(url,'stream')
        duration = Log.param(url,'duration')
        startDate = Log.param(url,'start')
        ### 2017-05-21:16-00
        time_tuple = time.strptime(startDate, "%Y-%m-%d:%H-%M")
        log('int startDateTS 0')
        startDateTS = int(time.mktime(time_tuple))
        log('int startDateTS 1')
        ### Get url: '/channels/get-record/' + chId + '/' + evtStart + '/' + evtDuration
        ### https://www.unlim.tv:443/channels/get-record/949/1557407400/6000
        ###url = 'https://www.unlim.tv:443/channels/get-record/'+cat+'/'+str(startDateTS)+'/'+duration
        ###log('url 2= %r' % url)
        url = Api.get_archive_link(self, channel_id, evtStart, evtDuration)
        
        ###URI='plugin://plugin.video.unlimtv/?url=url&mode=211&source='+ADDONid+'&cat=' + cat[3:] +'&startdate=' + str(startDateTS) +'&duration='+ duration
        #### 2021-04-01
        URI='plugin://plugin.video.krogsbelliptv.rec/?url=url&mode=2012&source='+ADDONid+'&name=' + name + ' [unlim.tv]&uri='+ base64.b64encode(url)
            
        log('unlim.tv-->recorduri.py: URI= %s' % repr(URI))
        tries    = 0
        maxTries = 10
        maxSleep = 500
        try:
            log(repr(URI))
            xbmc.executebuiltin('RunPlugin(%s)' % URI) 
            xbmc.sleep(maxSleep)
        except Exception as e:
            pass 
            log('sync_stream ERROR: %r' % e)

    def add_folder(self, name, mode, cat):
        item = xbmcgui.ListItem(name)
        item.setArt({ 'icon': 'DefaultFolder.png'})
        item.addContextMenuItems([])
        url = sys.argv[0] + '?mode=' + str(mode) + '&cat=' + cat
        xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = url, listitem = item, isFolder = True)

    def add_channel(self, channel):
        log('Channel= %r' % channel)
        name = channel['name']   ###.encode('utf-8')
        log('1 name= %r' % name)
        epgnow = channel['epg_now']
        plot = ''
        event = ''
        try:
            event = epgnow['event_name']   ###.encode('utf-8')
            desc = epgnow['description']   ###.encode("utf-8")
            if len(desc) > 0:
                plot = desc
        except Exception as e:
            pass 
            log('record_stream ERROR: %r' % e)

        if channel['health'] == 1:
            if len(event) > 0:
                name = name + ' [COLOR yellow]' + event + '[/COLOR]'
        else:
            name = '[COLOR grey][I]' + name + '[/I][/COLOR] [COLOR blue]broken[/COLOR]'
        log('2 name= %r' % name)
        log('plot= %r' % plot)
        log('event= %r' % event)
        remote_icon = Platform.SITE + '/assets/img/channels/' + channel['logo'] + '|auth=TLS&verifypeer=false'
        item = xbmcgui.ListItem(name)
        item.setArt({ 'icon': "DefaultFolder.png", 'thumb' : remote_icon })
        item.setInfo(type = "Video", infoLabels = {'title': name, 'plot': plot, 'playcount': 0})

        if channel['health'] == 1:
            log('Item is playable')
            item.setProperty('IsPlayable', 'true')

        menu = []
        url = 'RunPlugin(' + sys.argv[0] + '?mode=';
        log('url= %r' % url)
        ###text = 'Toggle favorites'
        if channel['favorite'] == 0:
            text = 'Add Favorites'
            url = url + str(self.app.MODE_FAV_ADD)
        else:
            text = 'Remove Favorite'
            url = url + str(self.app.MODE_FAV_REMOVE)
        url = url + '&cat=' + str(channel['id']) + ')'
        text = '[COLOR orange][B]' + text + '[/B][/COLOR]'
        menu.append((text, url))
        item.addContextMenuItems(items = menu, replaceItems = True)

        url = sys.argv[0] + '?mode=' + str(self.app.MODE_PLAY) + '&cat=' + str(channel['id'])
        log('1 url= %r' % url)
        ###url = url.replace('/?','?')
        xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = url, listitem = item, isFolder = False)
        log('2 url= %r' % url)


    def setView(self, content, viewType):
        # set content type so library shows more views and info
        if content:
            xbmcplugin.setContent(int(sys.argv[1]), content)
        if self.addon.getSetting('auto-view') == 'true':  # <<<----see here if auto-view is enabled(true)
            xbmc.executebuiltin(
                "Container.SetViewMode(%s)" % self.addon.getSetting(viewType))  # <<<-----then get the view type
