#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmc, xbmcvfs
# For Python 3.0 and later
from urllib.request import urlopen
import sys
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import definition
import utils
import recordings
    
try:
    ADDON     = definition.getADDON()
    ADDONid   = definition.ADDONgetAddonInfo('id')
    ADDONname = definition.ADDONgetAddonInfo('name')
    datapath  = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
    progpath  = definition.ADDONgetAddonInfo('path')
    module    = 'http-keep-alive.py'
    utils.logdev(module,'error Http Keep Alive Started')
    utils.logdev(module,'error sys.argv= %r' % sys.argv)
    alarmName = 'http-keep-alive'
    marker    = 'once'
    try:
        marker = sys.argv[1]
    except Exception as e:
        pass
        utils.logdev(module,'30 ERROR: %r' % e)
    alarmName = alarmName + '-' + marker   
    recordings.updateAlarm(alarmName)
    utils.logdev(module,'error Http Keep Alive after updateAlarm')
    ###utils.notification('Http Keep Alive Started')
    ### SmartDNS Proxy servers: 46.166.189.68, 54.93.173.153, 81.17.17.188
    ### SmartDNS Proxy activation command: https://www.smartdnsproxy.com/api/IP/update/XXXXXXXXXXXXXXX (XXX.. Your direct link)
    
    link = definition.ADDONgetSetting('http-keep-alive')
    data = 'Request not executed! - Less then 5 characters'

    utils.shareLogs()    ### this is responsible for copying shared logs!

    try:
        if len(link) > 5:
            file = urlopen(link)
            deflink = 'https://www.smartdnsproxy.com/api/IP/update/'
            if deflink in link:
                link = deflink + '...'  ### Don't log full link
            data = file.read(500)
            file.close()
            definition.ADDONsetSetting('http-keep-alive-result',repr(data))
            definition.ADDONsetSetting('http-keep-alive-time',repr(datetime.today().strftime('%Y-%m-%d %H:%M:%S')))
            utils.logdev(module,'error Request: %s,\n Result: %s' % (repr(link),repr(data)))
    except Exception as  e:
        pass
        utils.logdev(module, 'Error in http-keep-alive= %s ERROR= %s' % (repr(link),repr(e)))
        
except Exception as  e:
    pass
    utils.logdev(module, 'Error in http-keep-alive= %s ERROR= %s' % (repr(link),repr(e)))
utils.logdev(module,'Ended')

