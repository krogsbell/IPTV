#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmcplugin,xbmcgui,xbmc,xbmcaddon
import definition
ADDON = definition.getADDON()
import urllib,urllib2,sys,re,os
import utils
###import net
###from hashlib import md5  
import json
import glob
import recordings
import locking
import definition
###import sqlite3
from sqlite3 import dbapi2 as sqlite3
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
from operator import itemgetter

ADDONname  = ADDON.getAddonInfo('name')
ADDONid    = ADDON.getAddonInfo('id')
module = 'findtvguidenotifications.py'
utils.logdev(module,'Start')
utils.logdev(module,'Start %r' % sys.argv)

TimeZoneOffset = 0
#EPG_DB = 'source.db'  Depends on actual TV Guide
RECORDS_DB = 'recordings_adc.db'
###CHANNEL_DB = 'channels.db'
CHANNEL_DB = 'recordings_adc.db'
RECURSIVEMARKER = 'Recursive:'
TVguideNR = ADDON.getSetting('tvguidenr')

dbPath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
###dbPathNTV = os.path.join(xbmc.translatePath(ADDON.getAddonInfo('path')),'resources')
dbPathNTV = dbPath
scriptTrig   = os.path.join(ADDON.getAddonInfo('path'), 'TrigTVGuide.py')

def log(infotext):
    if 'err' in infotext.lower():
        utils.logdev('err',module + ': ' + infotext)
    else:
        utils.logdev(module,infotext)

def logd(infotext):
    log(infotext)
    
def logd1(infotext):
    log('err: ' + infotext)

def logdev(module,infotext):
    log(infotext)
    
def HT(ts):  ### Human Time from timestamp
    try:
        return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts))
    except Exception,e:
        pass
        return 'HT(%r) ERROR: %r' % (ts,e)
  
def MyChannels():
    channels = recordings.getAllChannels()
    #channelsLC = []
    #for cha in channels:
    #    channelsLC.append(cha[1].lower(),cha)
    ##channels = sorted(channels, key=itemgetter(1))
    # sorted_list = sorted(unsorted_list, key=lambda s: s.lower())
    #channelsLC = sorted(channelsLC, key=itemgetter(0))
    #channels = sorted(channels, key=lambda s: s.lower())
    channels = sorted(channels,key=lambda i:i[1].lower())  ### Sort ignore case coloum 1
    
    AllMyChannels=[]
    ### Limit search to special sources
    utils.logdev(module,'limitsources')
    limitsourcesSQ = recordings.getAllChannelSources()
    utils.logdev(module,'limitsources= %r' % limitsourcesSQ)
    limitsources = []
    for sourceSQ in limitsourcesSQ:
        if not ADDONid in sourceSQ[0]:
            limitsources.append(sourceSQ[0])
    ##limitsources = ['IPTV','Rytec']
    if len(limitsources) != 1:
        limitsources = sorted(limitsources)    # sort alphabetically
        limitsource = limitsources[xbmcgui.Dialog().select('Select Source for EPG', limitsources)]
    else:
        limitsource = limitsources[0]
    utils.logdev(module,'limitsource= %r' % limitsource)
    for field in channels:
        cat          = field[0]
        name         = field[1]    ###.encode("utf-8")
        iconimage    = field[2]
        url          = field[3]
        source       = field[4]
        if '-' in source:
            sourceID = source.split('-')[0].strip()
        elif '.' in source:
            sourceID = source.split('.')[2].split(' ')[0].strip()
        else:
            sourceID = field[4]
        visible      = field[5]
        weight       = field[6]
        ###if not source == ADDONid:
        ### utils.logdev(module, 'source= %s, module= %s' % (source,module))
        ###if source == ADDONid and not '/movie/' in url:   
        if not '/movie/' in url and not sourceID == ADDONid and not sourceID == ADDONid + ' available_channels':
            displaychannelnumber = (name + ' (' +cat+' - ' + sourceID + ')\n' )
            if source == limitsource: 
                AllMyChannels.append(displaychannelnumber)
        
    return AllMyChannels

def MyPlayChannels():
    channels = recordings.getAllChannels()
    channels = sorted(channels, key=itemgetter(1))
    
    AllMyChannels=[]
    
    for field in channels:
        cat          = field[0]
        name         = field[1]    ###.encode("utf-8")
        iconimage    = field[2]
        url          = field[3]
        source       = field[4]
        utils.logdev(module,'source 0= %r' % source)
        if '-' in source:
            source = source.split('-')[0].strip()
        elif '.' in source:
            source = source.split('.')[2].split(' ')[0].strip()
        elif ' ' in source:
            source = source.split(' ')[0].strip()   ### 2017-09-17
        else:
            source = field[4]
        utils.logdev(module,'source 1= %r' % source)
        visible      = field[5]
        weight       = field[6]
        ###if not source == ADDONid:
        ### utils.logdev(module, 'source= %s, module= %s' % (source,module))
        ###if source == ADDONid and not '/movie/' in url:   
        if not url == 'url' and not url == '' and not '/movie/' in url and not source == ADDONid:
            displaychannelnumber = (name + ' (' +cat+' - ' + source + ')\n' )
            AllMyChannels.append(displaychannelnumber)
    utils.logdev(module,'AllMyChannels= %r' % AllMyChannels)    
    return AllMyChannels


def findtvguidenotifications():
    logd1('findtvguidenotifications START')
    if locking.isAnyRecordLocked() and ADDON.getSetting('grabduringrecord') == 'false'  :
        locking.scanUnlockAll()
        findtvguidenotificationsend('[COLOR red]Recording - Grab disabled[/COLOR]')
        return
    elif  locking.isAnyScanLocked():
        findtvguidenotificationsend('[COLOR red]Already scanning - New grab disabled[/COLOR]')
        return
    else:
        locking.scanLock('findtvguidenotifications')
    if not locking.isScanLocked('findtvguidenotifications'):
        findtvguidenotificationsend('[COLOR red]Scan lock not working - Grab disabled[/COLOR]')
        return
    TVguide= utils.TVguide()
    logd1('TVguide= %r' % TVguide)
    Recursive = RecursiveRecordings() ## Get all recursive recordings
    logd1('Recursive= %r' % Recursive)
    #guidenotifications= ADDON.getSetting('tvguidenotifications')
    scheduled = 0
    for Guide in range(0, len(TVguide)):
        
        guide = TVguide[Guide][0]
        guideDB = TVguide[Guide][1]
        
        scheduled += grabGuide(guide,guideDB)
        ###try:
        logd1('guide= %r, guideDB= %r' % (guide,guideDB))
        logarray('Recursive',Recursive,nelements=2)
        
        scheduled += findrecursiverecordingsinGuide(guide,guideDB,Recursive)
        ###except Exception, e:
        ### pass
        ### utils.logdev('findrecursiverecordingsinGuide EXECUTION FAILED 1', 'guide= %s ERROR= %s' % (guide,repr(e)))
        ### findtvguidenotificationsend('[COLOR red]Grab from TV Guide FAILED![/COLOR] - guide= %s ERROR= %s'% (guide,repr(e)))
        ### return
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    findtvguidenotificationsend('[COLOR green]Grab from TV Guide finished! - Use Refresh to update view[/COLOR] %r\n[I][COLOR grey]Updated or new recordings: %r  [/COLOR][/I]' % (now,scheduled))


def findtvguidenotificationsend(EndText):
    # Show menuentry when finished OK - but not when run in the background
    locking.scanUnlockAll()
    utils.notificationsend(EndText)

def RecursiveRecordings():
    conn = recordings.getConnection()
    c = conn.cursor()
    c.execute("PRAGMA journal_mode = WAL")  ### 2018-01-07 Try to speed up on Windows 
    #c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE '%Recursive:%' and NOT LIKE '%COLOR orange%' COLLATE NOCASE")  # Find all active recursive recordings
    try:
        c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE ? COLLATE NOCASE",['%'+RECURSIVEMARKER+'%'])  # Find all active recursive recordings RECURSIVEMARKER
    except Exception, e:
        pass
        utils.logdev(module, 'c.execute(SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE ? COLLATE NOCASE,[RECURSIVEMARKER]) failed! \nERROR= %r' % e)
    recordingsE = c.fetchall()
    # Put recursive recordings changed last - first
    recordingsC = sorted(recordingsE, key=itemgetter(2), reverse=True)
    try:
        utils.logdev(module,'Recursive recordings= %r'%recordingsC)
        utils.logdev(module,'Recursive recordings[1]= %r'%recordingsC[1])
        utils.logdev(module,'Recursive recordings[2]= %r'%recordingsC[2])
    except Exception,e:
        pass
        utils.logdev(module,'Recursive recordings ERROR: %r' % e)
    conn.commit()
    c.close()
    return recordingsC

def logarray(Name,Array,nelements=1):
    i = 0
    for rec in Array:
        try:
            if nelements==1:
                logd1('logarray in %s= %r %r' % (Name,i,rec))
                i += 1
            else:
                records = []
                for index in range(0, nelements):
                    records.append(rec[index])
                logd1('logarray in %s= %r %r' % (Name,i,records))
                i += 1
        except Exception,e:
            pass
            logd1('ERROR: logarray in %s= %r' % (Name,e))

def findrecursiverecordingsinGuide(guide,EPG_DB,Recursive):         
    logd1('findrecursiverecordingsinGuideCode guide= %s' % guide)
    ADDONguide = xbmcaddon.Addon(id=guide)
    scheduled = 0
    NTVchannels = MyPlayChannels()
    logarray('NTVchannels',NTVchannels,nelements=1)
    
    #SearchRecursiveIn: 0=Only selected channel|1=First 25 Cannels|2=First 50 Channels|3=All My Channels
    #SearchRecursiveIn= int(ADDON.getSetting('SearchRecursiveIn'))
    #logd1('findtvguidenotificationsGuide SearchRecursiveIn= %r' % SearchRecursiveIn)
    ###utils.logdev(module,'Start DB Create')
    """
    conv   = sqlite3.connect(os.path.join(dbPath, RECORDS_DB), timeout = 20, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conv.execute('PRAGMA foreign_keys = ON')
    conv.row_factory = sqlite3.Row
    conv.text_factory = str
    """
    conv = recordings.getDatabaseConnection(os.path.join(dbPath, RECORDS_DB))
    b = conv.cursor()
    b.execute("PRAGMA journal_mode = WAL")  ### 2018-01-07 Try to speed up on Windows 
    ###b.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)") ## 2016-05-15
    ###b.execute("CREATE TABLE IF NOT EXISTS channelslookup(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, favorite BOLEAN, catchup BOLEAN, description TEXT, PRIMARY KEY (title, source))")   ### 2017-07-24 channels --> channelslookup - Removed 2017-09-12
    ###utils.logdev(module,'Start DB Create1')
    dbPathEPG = xbmc.translatePath(ADDONguide.getAddonInfo('profile'))
    #utils.logdev('findrecursiverecordingsinGuide', 'dbPath= %s' % dbPathEPG)
    if not os.path.exists(dbPathEPG):
        #utils.logdev('findrecursiverecordingsinGuide', 'os.mkdir(dbPath) where dbPath= %s' % dbPathEPG)
        os.mkdir(dbPathEPG)
    ###utils.logdev(module,'Start DB Create2')
    """
    conn   = sqlite3.connect(os.path.join(dbPathEPG, EPG_DB), timeout = 20, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    """
    conn = recordings.getDatabaseConnection(os.path.join(dbPath, EPG_DB))
    c = conn.cursor()
    c.execute("PRAGMA journal_mode = WAL")  ### 2018-01-07 Try to speed up on Windows 
    ###c = conv.cursor()
    if TVguideNR == '0':
        logd1('Start DB Create WB0')
        """
        c.execute("CREATE TABLE IF NOT EXISTS programs(channel TEXT, title TEXT, sub_title TEXT, start_date TIMESTAMP, end_date TIMESTAMP, description TEXT, categories TEXT, image_large TEXT, image_small TEXT, season TEXT, episode TEXT, is_movie TEXT, language TEXT, source TEXT, updates_id INTEGER, UNIQUE (channel, start_date, end_date), FOREIGN KEY(channel, source) REFERENCES channels(id, source) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED, FOREIGN KEY(updates_id) REFERENCES updates(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
        c.execute("CREATE TABLE IF NOT EXISTS programsForHumans (channel TEXT, title TEXT, start_date TEXT, end_date TEXT, description TEXT, image_large TEXT, image_small TEXT, source TEXT, updates_id INTEGER, PRIMARY KEY (channel, updates_id), FOREIGN KEY(updates_id) REFERENCES updates(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
        c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, lineup TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
        """
        ###utils.logdev(module,'Start DB Create WB1')
        c.execute("CREATE TABLE IF NOT EXISTS programs(channel TEXT, title TEXT, sub_title TEXT, start_date INTEGER, end_date INTEGER, description TEXT, categories TEXT, image_large TEXT, image_small TEXT, season TEXT, episode TEXT, is_movie TEXT, language TEXT, source TEXT, updates_id INTEGER, UNIQUE (channel, start_date, end_date), PRIMARY KEY (channel, start_date, end_date))")
        ###utils.logdev(module,'Start DB Create WB2')
        ###  Stop using programsForHumans
        ###c.execute("CREATE TABLE IF NOT EXISTS programsForHumans (channel TEXT, title TEXT, sub_title TEXT, start_date TEXT, end_date TEXT, description TEXT, image_large TEXT, image_small TEXT, source TEXT, updates_id INTEGER, PRIMARY KEY (channel, updates_id))")
        ###utils.logdev(module,'Start DB Create WB3')
        ###c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, lineup TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, source))")
        c.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, lineup TEXT, visible BOOLEAN, weight INTEGER, epg_channel TEXT, description TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (id, title, source))")
        ###utils.logdev(module,'Start DB Create WB4')
    else:
        logd1('Start DB Create NoWB')
        c.execute("CREATE TABLE IF NOT EXISTS programs (channel TEXT, title TEXT, start_date TIMESTAMP, end_date TIMESTAMP, description TEXT, image_large TEXT, image_small TEXT, source TEXT, updates_id INTEGER, PRIMARY KEY (channel, updates_id), FOREIGN KEY(updates_id) REFERENCES updates(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
        ###  Stop using programsForHumans
        ###c.execute("CREATE TABLE IF NOT EXISTS programsForHumans (channel TEXT, title TEXT, start_date TEXT, end_date TEXT, description TEXT, image_large TEXT, image_small TEXT, source TEXT, updates_id INTEGER, PRIMARY KEY (channel, updates_id), FOREIGN KEY(updates_id) REFERENCES updates(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
        c.execute("CREATE TABLE IF NOT EXISTS channels (id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY(id,title, source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
    conn.commit()
    ###conv.commit()
    for index in range(0, len(Recursive)):
        logd1('Recursive[%r]= %r X %r X %r' % (index,Recursive[index][0],Recursive[index][1],Recursive[index][2]))

    for index in range(0, len(Recursive)):
        logd1('index= %r' % index)
        logd1('Recursive[index][1]= %r' % Recursive[index][1].replace(RECURSIVEMARKER, '').strip())
        cat= Recursive[index][0]
        logd1('cat= %r, source= %r' % (cat,guide))
        # Find channel name in TV Guide 1. saved conversion 2. name as used i NTV
        try:
            b.execute("SELECT * FROM channels WHERE id=? and source=? and visible=?", [cat,guide,1])
            channelconvert = b.fetchall()
            logarray('channelconvert',channelconvert,nelements=2)
            ###utils.logdev(module,'channelconvert= %r' % channelconvert)
        except Exception,e:
            pass
            logd1('channelconvert ERROR: %r' % e)
            channelconvert = []
        if len(channelconvert) == 1:
            channel= channelconvert[0][1]
            logd1('Converted: cat= (%r) channel= %r' % (cat,channel))
        else:
            channel= recordings.ChannelName(cat)
            logd1('LookedUp: cat= (%r) channel= %r, len(channelconvert)= %r' % (cat,channel,len(channelconvert)))
        #utils.logdev('findrecursiverecordingsinGuide', 'cat= (%s) channel= %s' % (repr(channel),repr(channel)))
        # Find id from TV Guide channel name
        #c.execute("SELECT * FROM channels")
        #channelconvert = c.fetchall()
        logd1('channelconvert= %r' % channelconvert)
        try:
            c.execute("SELECT * FROM channels WHERE title=? and visible=? COLLATE NOCASE", [channel,1])
            channelconvert = c.fetchall()
            logd1('channelconvert= %r' % channelconvert)
            logarray('channelconvert',channelconvert,nelements=2)
            channel= channelconvert[0][0]
        except Exception,e:
            pass
            logd1('ERROR: channelconvert= %r' % e)
            channel= 0
        logd1('ChannelConvert: cat= (%r) channel= %r #ofchannelconvert= %r' % (cat,channel,len(channelconvert)))
        #utils.logdev('findrecursiverecordingsinGuide', 'channel= %s' % repr(channel))
        #c.execute("SELECT * FROM programs WHERE title LIKE ? AND channel=? COLLATE NOCASE", ['%'+(Recursive[index][1].replace(RECURSIVEMARKER, '').strip())+'%',channel])
        recursivechannel= channel  ### E! ==> E.se  ### NO must be EPG Channel 2018-08-28
        logd1('recursivechannel= %r' % recursivechannel)
        ###SearchText = '%'+(Recursive[index][1].replace(RECURSIVEMARKER, '').strip())+'%'
        SearchText = (Recursive[index][1].replace(RECURSIVEMARKER, '').strip())
        logd1('SearchText= %r' % SearchText)
        try:
            SearchText = SearchText.split('^')
        except Exception, e:
            pass
            logd1('split search text EXECUTION FAILED 3 SearchText= %s\nERROR= %s' % (repr(SearchText),repr(e)))
            logd1('Default SearchText= %r' % SearchText)
            SearchText = [SearchText.strip()]
        logd1('SearchText= %r' % SearchText)
        logd1('SearchText[0]= %r' % SearchText[0])
        logd1('len(SearchText)= %r' % len(SearchText))
        if '[COLOR orange]' in SearchText[0]:
            mark = True
            SearchText[0] = SearchText[0].replace('[COLOR orange]','',1).replace('[/COLOR]','',1)
        else:
            mark = False
        logd1('mark= %r' % mark)
        if SearchText[0] == '' or len(SearchText[0].strip()) < 3:
            logd1('SearchText is empty or less than 3 chars long')
        else:
            logd1('SearchText is more than 3 chars long')
            ###cy= c.execute("SELECT DISTINCT p.*, c.weight FROM channels c, programs p WHERE c.weight < 25 AND p.channel = c.id AND p.title = ? AND p.start_date >= ?",[program, now])
            ### channelsRecursive(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created)
            
            nowTS = time.mktime(datetime.now().timetuple())
            logd1('nowTS= %r' % nowTS)
            ###c.execute("SELECT DISTINCT p.title, p.channel, c.id, c.title, c.epg_channel, c.id, p.start_date  FROM programs p, channelsRecursive c WHERE p.title LIKE ? and p.channel = c.epg_channel and p.start_date > ? COLLATE NOCASE", ['%'+SearchText[0].strip()+'%', nowTS])
            searchtext = '%'+SearchText[0].strip()+'%'
            logd1('SearchText[0].strip()= %r' % (searchtext))
            try:
                c.execute("SELECT DISTINCT p.title, p.channel, c.id, c.title, c.epg_channel, c.id, p.start_date  FROM programs p, channels c WHERE p.channel = c.epg_channel AND p.title LIKE ?  and (c.epg_channel like '% (R)%' or c.favorite <> ? and c.favorite <> ? or c.catchup=?) and c.visible=? and p.start_date > ? COLLATE NOCASE", [searchtext,'false','False',1,1, nowTS])
            except Exception,e:
                pass
                logd1('c.execute(SELECT DISTINCT p.title ERROR: %r' % e)
            logd1('After c.execute')
            ###[searchText,'True',1,1,origin])...c.title like '% (D)%' or 
            ###c.execute("SELECT DISTINCT p.title, p.channel, c.id, c.title, c.epg_channel, c.id, p.start_date  FROM programs p, channels c WHERE p.title LIKE ? and p.channel = c.epg_channel and p.start_date > ? COLLATE NOCASE", ['%'+SearchText[0].strip()+'%', nowTS])
            notifications = c.fetchall()
            
            if len(notifications) > 0:
                for indexN in range(0, len(notifications)): 
                    ptitle=       notifications[indexN][0]
                    pchannel=     notifications[indexN][1]
                    cid=          notifications[indexN][2]
                    ctitle=       notifications[indexN][3]
                    cepg_channel= notifications[indexN][4]
                    cid=          notifications[indexN][5]
                    pstart_date=  notifications[indexN][6]
                    
                    logd1('TEST - Found SearchText= %r' % ('%'+SearchText[0].strip()+'%'))
                    logd1('TEST - p.title= %r, \np.channel=     %r, c.id= %r, c.title= %r, \nc.epg_channel= %r \nc.id= %r \np.start_date= %r' % (ptitle, pchannel, cid, ctitle, cepg_channel, cid, time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(pstart_date))))
            else:
                logd1('TEST - Nothing found: %r' % ('%'+SearchText[0].strip()+'%'))
            
            logd1('len(SearchText)= %r, SearchText= %r' % (len(SearchText),SearchText))       
            if len(SearchText) == 1 : ##################################################################
                logd1('1. SearchText= %r' % ('%'+SearchText[0].strip()+'%'))
                c.execute("SELECT * FROM programs p, channelsRecursive c WHERE p.title LIKE ? and p.channel = c.epg_channel and p.start_date > ? COLLATE NOCASE", ['%'+SearchText[0].strip()+'%', nowTS])
            if len(SearchText) == 2 :  
                logd1('2. SearchText= %r' % ('%'+SearchText[0].strip()+'%'))
                c.execute("SELECT * FROM programs p, channelsRecursive c WHERE p.title LIKE ? AND p.title NOT LIKE ? AND p.channel = c.epg_channel and p.start_date > ? COLLATE NOCASE", ['%'+SearchText[0].strip()+'%','%'+SearchText[1].strip()+'%', nowTS])
            if len(SearchText) == 3 :  
                logd1('3. SearchText= %r' % ('%'+SearchText[0].strip()+'%'))
                c.execute("SELECT * FROM programs p, channelsRecursive c WHERE p.title LIKE ? AND p.title NOT LIKE ? AND p.title NOT LIKE ? AND p.channel = c.epg_channel and p.start_date > ? COLLATE NOCASE", ['%'+SearchText[0].strip()+'%','%'+SearchText[1].strip()+'%','%'+SearchText[2].strip()+'%', nowTS])
            if len(SearchText) > 3 :  
                logd1('4. SearchText= %r' % ('%'+SearchText[0].strip()+'%'))
                c.execute("SELECT * FROM programs p, channelsRecursive c WHERE p.title LIKE ? AND p.title NOT LIKE ? AND p.title NOT LIKE ? AND p.title NOT LIKE ? AND p.channel = c.epg_channel and p.start_date > ? COLLATE NOCASE", ['%'+SearchText[0].strip()+'%','%'+SearchText[1].strip()+'%','%'+SearchText[2].strip()+'%','%'+SearchText[3].strip()+'%', nowTS])
            notifications = c.fetchall()
            
            logd1('len(notifications)= %r' % len(notifications))
            if len(notifications) > 0:
                logarray('2. notifications',notifications,len(notifications[0]))
                ###programs(0channel, 1title, 2sub_title, 3start_date, 4end_date, description, categories, image_large, image_small, season, episode, is_movie, language, source)
                ###channelsRecursive(0id TEXT, 1title TEXT, 2logo TEXT, 3stream_url TEXT, 4source TEXT, 5visible BOOLEAN, 6weight INTEGER, 7favorite BOLEAN, 8catchup BOLEAN, 9epg_channel TEXT, description TEXT, updated INTEGER, created INTEGER, PRIMARY KEY (title, source))")
                for indexN in range(0, len(notifications)): 
                    ptitle=       notifications[indexN][1]
                    pchannel=     notifications[indexN][0]
                    cid=          notifications[indexN][15]  #2 - 0 +15
                    ctitle=       notifications[indexN][16]  #3 - 1
                    cepg_channel= notifications[indexN][24]  #4 - 9
                    cid=          notifications[indexN][15]  #5 - 0
                    pstart_date=  notifications[indexN][3]  
                    
                    logd1('2. TEST - Found SearchText= %r' % ('%'+SearchText[0].strip()+'%'))
                    logd1('2. TEST - p.title= %r, \np.channel=     %r, c.id= %r, c.title= %r, \nc.epg_channel= %r \nc.id= %r \np.start_date= %r' % (ptitle, pchannel, cid, ctitle, cepg_channel, cid, HT(pstart_date)))
            else:
                logd1('TEST - Nothing found: %r' % ('%'+SearchText[0].strip()+'%'))
               
            if len(notifications) > 0:
                for indexN in range(0, len(notifications)): 
                    channel= notifications[indexN][0]
                    program= notifications[indexN][1]
                    logd1('indexN= %r' % indexN)
                    logd1('channel= %r' % channel)
                    logd1('SearchText= %r' % SearchText)
                    logd1('  program= %r' % program)
                    c.execute("SELECT DISTINCT id, title, logo, stream_url, source, visible, weight, epg_channel FROM channelsRecursive WHERE epg_channel=? and visible=?",  [channel,1])   ### 2018-08-28
                    logd1('epg_channel= %r' % (channel))
                    channeldata= c.fetchall()
                    if len(channeldata) > 0:
                        logd1('1. len(channeldata)= %r' % len(channeldata))
                        logd1('1. len(channeldata[0])= %r' % len(channeldata[0]))
                        logarray('1. channeldata',channeldata,nelements=len(channeldata[0]))
                        now = int(time.mktime(datetime.now().timetuple()))
                        cz= c.execute("SELECT * FROM programs WHERE channel=? AND title=? AND start_date >= ?",  [channel, program, now]) ### Recursive Only on channel in record
                        logd1('[channel= %r, program= %r, now= %r]' % (channel, program, now))
                        programs= cz.fetchall()
                        if len(programs) > 0:
                            logd1('*dr1.dk len(programs)= %r' % len(programs))
                            logarray('cz programs 1',programs,nelements=len(programs[0]))
                        
                        cy= c.execute("SELECT DISTINCT p.*, c.epg_channel FROM programs p, channelsRecursive c WHERE p.channel = c.epg_channel AND p.title = ? AND p.start_date >= ? AND c.epg_channel = ?",[program, now, channel])
                        logd1('[program= %r, now= %r, epg= %r]' % (program, now, channel))
                        ###programs += cy.fetchall()   ### TEST just test original channel 2017-08-25
                        programs = cy.fetchall()  
                        if len(programs) > 0:
                            logd1('**dr1.dk len(programs)= %r' % len(programs))
                            logarray('cy program 2',programs,nelements=len(programs[0]))
                        
                        NTVchannelSelect= NTVchannels
                        for prog in range(0, len(programs)):
                            try:
                                cweight= programs[prog][9]
                                logd1('cweight= %r' % cweight)
                            except:
                                pass
                            pchannel= programs[prog][0]
                            logd1('*** dr1.dk pchannel= %r' % pchannel)
                            ptitle= programs[prog][1]
                            logd1('ptitle= %r' % ptitle)
                            if TVguideNR == '0':
                                pstart_date= programs[prog][3]
                                pend_date= programs[prog][4]
                            else:
                                pstart_date= programs[prog][2]
                                pend_date= programs[prog][3]
                            logd1('pstart_date= %r pend_date= %r type(pstart_date)= %r' % (HT(pstart_date),HT(pend_date),type(pstart_date)))
                            
                            if not type(pstart_date) is int:
                                if type(pend_date) is int:
                                    logd1('pstart_date is not int and set to pend-2h= %r' % pstart_date)
                                    pstart_date = datetime.fromtimestamp(pend_date) - timedelta(hours = 2)  ### If pstart is missing sub 2 hours from pend
                                    
                                else:
                                    logd1('pstart_date is not datetime and set to now= %r -3h= %r' % (datetime.now(),pstart_date))
                                    pstart_date = datetime.now() - timedelta(hours = 3)  ### If pstart and pend is missing sub 3h from now making it obsolete
                            else:
                                pstart_date = datetime.fromtimestamp(pstart_date)
                            if not type(pend_date) is int:  
                                logd1('pend_date (pstart_date + 2)= %r' % pend_date)
                                pend_date = pstart_date + timedelta(hours = 2)  ### If pend is missing add 2 hours
                            else:
                                pend_date = datetime.fromtimestamp(pend_date)
                            ### pstart_date and pend_date are now datetime
                            
                            if TVguideNR == '0':
                                pdescription= programs[prog][5]
                            else:
                                pdescription= programs[prog][4]
                            logd1('*** dr1.dk channeldata[0][1]= %r' % (channeldata[0][1]))
                            try:
                                logd1('*** dr1.dk channeldata[1][1]= %r' % (channeldata[1][1]))
                                logd1('*** dr1.dk channeldata[2][1]= %r' % (channeldata[2][1]))
                            except:
                                pass
                            cat= recordings.CatFromChannelName(channeldata[0][1])
                            logd1('CatFromChannelName cat= %r' % cat)
                            cat= recordings.catFromEPGcat(cat)
                            ###cat= recursivechannel  ### 2017-09-23
                            logd1('**** dr1.dk catFromEPGcat cat= %r' % (cat))
                            if cat == '0' or cat == '-1':  ## Channel from TVguide not found - ignore
                                ###b.execute("SELECT * FROM channels WHERE title=? and source=? and visible=?", [channeldata[0][1],guide,1])
                                b.execute("SELECT * FROM channels WHERE epg_channel=? and source=? and visible=?", [pchannel,guide,1])  ### 2020-04-05
                                channelconvert = b.fetchall()
                                if len(channelconvert) == 0:
                                    SelectedChannel = xbmcgui.Dialog().select(guide + ': Select Channel for: ' + channeldata[0][1] + ' - ' + channeldata[0][0] + ' - ' + ptitle, NTVchannelSelect)
                                    logd1('SelectedChannel= %r' % SelectedChannel)
                                    if SelectedChannel <> -1:
                                        try:
                                            logd1('NTVchannelSelect[SelectedChannel]= %r' % NTVchannelSelect[SelectedChannel])
                                            id = NTVchannelSelect[SelectedChannel].replace(' (D)','').replace(' (VPN OR UK ONLY)','').split('(')[1].split(')')[0].split(' -')[0]  ### 2017-08-24
                                            logd1('findrecursiverecordingsinGuide id= %r' % id)
                                            if id != '' and id != '0' and id != 0 :
                                                b.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight) VALUES(?, ?, ?, ?, ?, ?, ?)", [id, channeldata[0][1], '', '', guide, 'True', id])

                                                logd1('findrecursiverecordingsinGuide id= %s' % (repr(id)))
                                                cat = id
                                                logd1('findrecursiverecordingsinGuide Selected cat= %s' % (repr(cat)))
                                                
                                        except Exception, e:
                                            pass
                                            cat = '0'
                                            logd1('findrecursiverecordingsinGuide SelectedChannel FAILED guide= %s ERROR= %s' % (guide,repr(e)))
                                    conv.commit()
                                else:
                                    cat = channelconvert[0][0]
                                    logd1('findrecursiverecordingsinGuide Converted cat= %r' % cat)
                            now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                            try:
                                
                                logd1('findrecursiverecordingsinGuide guide= %s Recursive= %s' % (guide,Recursive[index]))
                                if type(pdescription) != str:
                                    pdescription = 'empty1'
                                if type(now) != str:
                                    now = 'empty2'
                                if type(Recursive[index][1]) != str:
                                    Recursive[index][1] = 'empty3'
                                if type(guide) != str:
                                    guide = 'empty4'
                                if type(channeldata[0][1]) != str:
                                    channeldata[0][1] = 'empty5'
                                if type(channeldata[0][0]) != str:
                                    channeldata[0][0] = 'empty6'
                                if type(ptitle) != str:
                                    ptitle = 'empty7'
                                pdescription = pdescription + ' \n\nCreated: ' + now +' \nRecursive [' + Recursive[index][1].replace(RECURSIVEMARKER, '') + '] from ' + guide + ' - ' + channeldata[0][1] + ' - ' + channeldata[0][0] + ' \n\n' + ptitle
                                pdescription = pdescription.replace('(','[').replace(')',']')
                            except Exception, e:
                                pass
                                logd1('findrecursiverecordingsinGuide Description FAILED guide= %s ERROR= %s' % (guide,repr(e)))
                            logd1('findrecursiverecordingsinGuide cat= %s' % repr(cat))
                            logd1('findrecursiverecordingsinGuide pdescription= %s' % repr(pdescription))
                            logd1('findrecursiverecordingsinGuide pend_date= %s' % repr(pend_date))
                            delta = timedelta(hours = TimeZoneOffset)
                            logd1('findrecursiverecordingsinGuide timedelta(hours = TimeZoneOffset)= %s' % repr(delta))
                            ###if not cat == '' :
                            logd1('1. recordings.schedule(cat= %r, pstart_date + timedelta(hours = TimeZoneOffset)= %r, pend_date + timedelta(hours = TimeZoneOffset)= %r, CcCc + program= %r, pdescription= %r)' % (cat, pstart_date + timedelta(hours = TimeZoneOffset), pend_date + timedelta(hours = TimeZoneOffset), 'CcCc' + program, pdescription))
                            if cat != '' and cat != '0' and cat != 0 :
                                logd1('recordings.schedule DB= %r' % c)
                                if mark:
                                    scheduleflag = recordings.schedule(cat, pstart_date + timedelta(hours = TimeZoneOffset), pend_date + timedelta(hours = TimeZoneOffset), '*' + program, pdescription,c)   ### Disable recording
                                    logd1('2. recordings.schedule(cat= %r, pstart_date + timedelta(hours = TimeZoneOffset)= %r, pend_date + timedelta(hours = TimeZoneOffset)= %r, CcCc + program= %r, pdescription= %r)' % (cat, pstart_date + timedelta(hours = TimeZoneOffset), pend_date + timedelta(hours = TimeZoneOffset), '*' + program, pdescription))
                                else:
                                    scheduleflag = recordings.schedule(cat, pstart_date + timedelta(hours = TimeZoneOffset), pend_date + timedelta(hours = TimeZoneOffset), 'CcCc' + program, pdescription,c)
                                    logd1('3. recordings.schedule(cat= %r, pstart_date + timedelta(hours = TimeZoneOffset)= %r, pend_date + timedelta(hours = TimeZoneOffset)= %r, CcCc + program= %r, pdescription= %r)' % (cat, pstart_date + timedelta(hours = TimeZoneOffset), pend_date + timedelta(hours = TimeZoneOffset), 'CcCc' + program, pdescription))
                                logd1('scheduleflag= %r' % scheduleflag)
                                if scheduleflag == True:
                                    scheduled +=1
                                # Set notification in TV Guide channeldata[0][0], program, ADDON.getAddonInfo('name')
                                try:
                                    c.execute("SELECT * FROM notifications WHERE channel = ? AND program_title = ? AND source = ?",  [channeldata[0][0], program, channeldata[0][4]])
                                    notify =  c.fetchall()
                                    logarray('notify',notify,nelements=2)
                                    if len(notify) == 0 and ADDON.getSetting('updateguide')=='true':  ## Only insert if not already there and set up in settings that recursive recordings are transferred
                                        if mark:
                                            c.execute("INSERT OR REPLACE INTO notifications (channel, program_title, source) VALUES(?, ?, ?)", [channeldata[0][0], '[COLOR orange]'+program+'[/COLOR]', channeldata[0][4]])
                                        else:
                                            c.execute("INSERT OR REPLACE INTO notifications (channel, program_title, source) VALUES(?, ?, ?)", [channeldata[0][0], program, channeldata[0][4]])
                                except Exception, e:
                                    pass
                                    utils.logdev('findrecursiverecordingsinGuide not cat ==  FAILED', 'guide= %s ERROR= %s' % (guide,repr(e)))
                    
    utils.logdev('findtvguidenotifications','EMPTY programsForHumans')
    try:
        c.execute("DROP TABLE programsForHumans")
    except:
        pass
    """
    now = datetime.now()
    # Transfer programs to programsForHumans
    #utils.logdev('findtvguidenotifications','channels= %s' % (repr(programs[prog][0])))
    c.execute("SELECT * FROM channels WHERE visible")
    channels= c.fetchall()
    ###utils.logdevarray(module+ '-channels',channels)
    for chan in range(0, len(channels)):
        time.sleep(1/100)
        if channels[chan][1] == channels[chan][0]:
            humanchannel= channels[chan][0]
        else:
            humanchannel= channels[chan][1] + ' (' + channels[chan][0] + ')'
        try:
            c.execute("SELECT * FROM programs WHERE start_date >= ? AND channel=?",  [now,channels[chan][0]]) 
            programs= c.fetchall()
        except Exception, e:
            pass
            utils.logdev('findrecursiverecordingsinGuide FAILED', 'now= %r, channel= %r, ERROR= %r' % (now,channels[chan][0],repr(e)))
            ###utils.logdev('findtvguidenotifications','programs= %s' % (repr(programs)))
        for prog in range(0, len(programs)):
            #utils.logdev('findtvguidenotifications','channels= %s' % (repr(channels)))
            #utils.logdev('findtvguidenotifications','channels[0][0]= %s, channels[0][1]= %s, egual= %s' % (repr(channels[0][1]), repr(channels[0][0]), repr(channels[0][1] == channels[0][0])))
            
            c.execute("SELECT * FROM programsForHumans WHERE channel=? AND title=? AND start_date=? AND end_date=? AND description=? AND source=?", [humanchannel, programs[prog][1],str(programs[prog][2]),str(programs[prog][3]),programs[prog][4],programs[prog][7]])
            programsForHumans =  c.fetchall()
            ###utils.logdev('findtvguidenotifications','len(programsForHumans)= %s' % repr(len(programsForHumans)))
            if len(programsForHumans) == 0:  ## Only insert if not already there
                c.execute("INSERT OR REPLACE INTO programsForHumans (channel, title, start_date, end_date, description, image_large, image_small, source) VALUES(?, ?, ?, ?, ?, ?, ?, ?)", [humanchannel, programs[prog][1],str(programs[prog][2]),str(programs[prog][3]),programs[prog][4],programs[prog][2],programs[prog][3],programs[prog][7]])
    """
    conn.commit()
    conv.commit()
    c.close()
    b.close()
    
    #utils.logdev('findrecursiverecordingsinGuideCode', 'dbPath= %s' % dbPath)
    utils.logdev('findrecursiverecordingsinGuideCode EXECUTION Finished', 'guide= %s' % guide)
    return scheduled

def adjusttvguide(conn,c,first):
    try: 
        sqlfilename= ADDON.getSetting('AdjustTVguideSqlFile')
        lineno = 0
        linemarker = '#lineno#'
        utils.logdev('adjusttvguide',repr(sqlfilename))
        sqlfile= open(sqlfilename,'r')
        line0 = sqlfile.readline()
        utils.logdev('adjusttvguide',repr(line0))
        if 'firstchannel=' in line0.lower():
            firstchannel= line0.lower().split('firstchannel=')[1].strip()
            if firstchannel != first.lower():
                line = sqlfile.readline().strip('\n')
                if linemarker in line:
                    line = line.replace(linemarker,str(lineno))   ### Automatic insert weight/linenumber
                    lineno += 1
                while line != '':
                    utils.logdev('adjusttvguide',repr(line))
                    c.execute(line)
                    line = sqlfile.readline()
                    if linemarker in line:
                        line = line.replace(linemarker,str(lineno))   ### Automatic insert weight/linenumber
                        lineno += 1
                utils.logdev('adjusttvguide','DROP TABLE programsForHumans')
                c.execute("DROP TABLE programsForHumans")
            else:
                utils.logdev('adjusttvguide','TV Guide already updated')
        else:
            utils.notificationbox('adjusttvguide: The sql file %s to adjust the TV Guide must start with: Firstchannel=' % repr(sqlfilename))
    except Exception, e:
        pass
        utils.logdev('adjusttvguide','No Adjust TV Guide SQL file or not all lines executed! ERROR= %r' % (e))
    conn.commit()   

def grabGuide(guide,EPG_DB):
    scheduled = 0
    if ADDON.getSetting('DebugRecording') == 'false' or True:
        try:
            scheduled = grabGuideCode(guide,EPG_DB)
        except Exception, e:
            pass
            logd1('grabGuide EXECUTION FAILED 4: guide= %r, ERROR= %r' % (guide,e))
    else:
        scheduled = grabGuideCode(guide,EPG_DB)  
    logd1('findtvguidenotifications scheduled= %r' % scheduled)
    return scheduled


def grabGuideCode(guide,EPG_DB):        
    logd1('*dr2.dk grabGuideCode guide= %r' % guide)
    #try:
    ADDONguide = xbmcaddon.Addon(id=guide)
    scheduled = 0
    dbPathEPG = xbmc.translatePath(ADDONguide.getAddonInfo('profile'))
    ###utils.logdev('grabGuideCode', 'dbPath= %s' % dbPathEPG)
    if not os.path.exists(dbPathEPG):
        #utils.logdev('findtvguidenotifications', 'os.mkdir(dbPath) where dbPath= %s' % dbPathEPG)
        os.mkdir(dbPathEPG)
    if not os.path.exists(dbPathNTV):
        os.mkdir(dbPathNTV)
    """
    cNTV   = sqlite3.connect(os.path.join(dbPathNTV, CHANNEL_DB), timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    cNTV.execute('PRAGMA foreign_keys = ON')
    cNTV.row_factory = sqlite3.Row
    cNTV.text_factory = str
    """
    cNTV = recordings.getDatabaseConnection(os.path.join(dbPath, CHANNEL_DB))
    a = cNTV.cursor()
    a.execute("PRAGMA journal_mode = WAL")  ### 2018-01-07 Try to speed up on Windows 
    ###a.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)") ## 2016-05-15
    a.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, title, source))")
    cNTV.commit()
    ###utils.logdev('grabGuideCode', 'cNTV.commit() dbPath= %s' % dbPathEPG)
    """
    conv   = sqlite3.connect(os.path.join(dbPath, RECORDS_DB), timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conv.execute('PRAGMA foreign_keys = ON')
    conv.row_factory = sqlite3.Row
    conv.text_factory = str
    """
    conv = recordings.getDatabaseConnection(os.path.join(dbPath, RECORDS_DB))
    b = conv.cursor()
    b.execute("PRAGMA journal_mode = WAL")  ### 2018-01-07 Try to speed up on Windows 
    ##b.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)") ## 2016-05-15
    b.execute("CREATE TABLE IF NOT EXISTS channels(id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY (id, title, source))")
    conv.commit()
    ###utils.logdev('grabGuideCode', 'conv.commit() dbPath= %s' % dbPathEPG)
    """
    conn   = sqlite3.connect(os.path.join(dbPathEPG, EPG_DB), timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False, isolation_level=None)
    conn.execute('PRAGMA foreign_keys = ON')
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    """
    conn = recordings.getDatabaseConnection(os.path.join(dbPath, EPG_DB))
    c = conn.cursor()
    c.execute("PRAGMA journal_mode = WAL")  ### 2018-01-07 Try to speed up on Windows 
    ###utils.logdev('grabGuideCode', 'conXX.commit() dbPath= %s' % dbPathEPG)
    ###c.execute("CREATE TABLE IF NOT EXISTS notifications (channel TEXT, program_title TEXT, source TEXT, FOREIGN KEY(channel, source) REFERENCES channels(id, source) ON DELETE CASCADE)")
    c.execute("CREATE TABLE IF NOT EXISTS notifications (channel TEXT, program_title TEXT, source TEXT)")
    ###c.execute("CREATE TABLE IF NOT EXISTS programs (channel TEXT, title TEXT, start_date TIMESTAMP, end_date TIMESTAMP, description TEXT, image_large TEXT, image_small TEXT, source TEXT, updates_id INTEGER, PRIMARY KEY (id, updates_id), FOREIGN KEY(updates_id) REFERENCES updates(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
    ###utils.logdev('grabGuideCode', 'conXXXX.commit() dbPath= %s' % dbPathEPG)
    c.execute("CREATE TABLE IF NOT EXISTS programs (channel TEXT, title TEXT, start_date TIMESTAMP, end_date TIMESTAMP, description TEXT, image_large TEXT, image_small TEXT, source TEXT, updates_id INTEGER, PRIMARY KEY (id, updates_id))")
    ###c.execute("CREATE TABLE IF NOT EXISTS channels (id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY(id,source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)")
    ###utils.logdev('grabGuideCode', 'conXXXXXX.commit() dbPath= %s' % dbPathEPG)
    c.execute("CREATE TABLE IF NOT EXISTS channels (id TEXT, title TEXT, logo TEXT, stream_url TEXT, source TEXT, visible BOOLEAN, weight INTEGER, PRIMARY KEY(id,title, source))")
    conn.commit()
    ###utils.logdev('grabGuideCode', 'conn.commit() dbPath= %s' % dbPathEPG)
    ## Adjust TV Guide
    ###utils.logdev('grabGuideCode', 'SELECT * FROM channels WHERE weight=0')
    c.execute("SELECT * FROM channels WHERE weight=0")
    ###c.execute("SELECT * FROM channels")
    channels = c.fetchall()
    ###utils.logdev('grabGuideCode', 'len(channels)= %r' % len(channels))
    if len(channels) == 1:
        adjusttvguide(conn,c,channels[0][1])
    else:
        adjusttvguide(conn,c,'missing channel 0 force update')
        
    c.execute("SELECT * FROM notifications")
    notifications = c.fetchall()
    ###utils.logdev('grabGuideCode', 'notifications= %r' % notifications)
    ###utils.logdevarray('grabGuideCode-notifications', notifications)
    
    NTVchannels = MyPlayChannels() ######################################### 2017-08-25
    ###utils.logdev('grabGuideCode', 'MyNTVchannels= %r' % NTVchannels)

    #if len(NTVchannels) < 2:   ## Only Euronews is not enough (2)
    #   from operator import itemgetter
    #   a.execute("SELECT * FROM channels WHERE id=ltrim(id,'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ') ") #### id must be number!
    #   NTVchannels = a.fetchall()
    #   #utils.logdev('findtvguidenotifications', 'NTVchannels(unsorted)= %s' % repr(NTVchannels))
    #   NTVchannels = sorted(NTVchannels, key=itemgetter(1))
    #   #utils.logdev('findtvguidenotifications', 'NTVchannels= %s' % repr(NTVchannels))

    for index in range(0, len(notifications)): 
        time.sleep(1/100)
        channel= notifications[index][0]
        program= notifications[index][1]
        logd1('*dr2.dk grabGuideCode channel= %r' % channel)
        logd1('*dr2.dk grabGuideCode program= %r' % program)
        c.execute("SELECT DISTINCT id, title, logo, stream_url, source, visible, weight FROM channels WHERE id=? and visible=?",  [channel,1])
        channeldata= c.fetchall()
        logarray('* dr2.dk grabGuideCode-channeldata', channeldata,nelements=3)
        
        now = datetime.now()
        
        c.execute("SELECT * FROM programs WHERE channel=? AND title=? AND start_date >= ?",  [channel, program, now])
        
        programs= c.fetchall()
        logarray('* dr2.dk grabGuideCode-programs', programs,nelements=3)
    
        '''
        channel= 'BBC 1 London'
        program= 'The Big Questions'
        channeldata= [(u'BBC 1 London', u'BBC One', u'http://wozboxtv.com/downloads/xmltv/logos/BBC%20One.png', None, u'xmltv', 1, 0)]
        now= datetime(2016, 2, 7, 10, 46, 51, 603477)
        programs= [(u'BBC 1 London', u'The Big Questions', datetime(2016, 2, 7, 11, 0), datetime(2016, 2, 7, 12, 0), u'Nicky Campbell presents moral and religious discussions on topical issues from King Edward VI School, Southampton.(n)', None, u'http://cdn.tvguide.co.uk/HighlightImages/Large/big_questions.jpg', u'xmltv', 1)]
        '''
    
        #NTVchannelSelect = []
        #for x in range (0,len(NTVchannels)):
        #   #try:
        #       #utils.logdev('findtvguidenotifications', 'NTVchannels[x]= %s' % (repr(NTVchannels[x])))
        #       #if isnumeric(str(NTVchannels[x])):
        #       NTVchannelSelect.append(NTVchannels[x])
        #       #utils.logdev('findtvguidenotifications', 'NTVchannelSelect= %s' % (repr(NTVchannelSelect)))
        #   #except:
        #   #   pass
        #utils.logdev('findtvguidenotifications', 'guide= %s and EPG_DB= %s' % (guide,EPG_DB))
        #utils.logdev('findtvguidenotifications', 'NTVchannelSelect= %s' % (repr(NTVchannelSelect)))
    
        NTVchannelSelect= NTVchannels
        for prog in range(0, len(programs)):
            time.sleep(1/100)
            pchannel= programs[prog][0]
            ptitle= programs[prog][1]
            if TVguideNR == '0':
                pstart_date= programs[prog][3]
                pend_date= programs[prog][4]
                pdescription= programs[prog][5]
            else:
                pstart_date= programs[prog][2]
                pend_date= programs[prog][3]
                pdescription= programs[prog][4]

            cat= recordings.CatFromChannelName(channeldata[0][1])
            logd1('*dr2.dk CatFromChannelName cat= %r <-- %r' % (cat,channeldata[0][1]))
            if cat == '0':  ## Channel from TVguide not found ##
                logd1('*dr2.dk grabGuideCode-channelconvert [channeldata[0][1]= %r,guide= %r]'% (channeldata[0][1],guide))
                b.execute("SELECT * FROM channels WHERE title=? and source=? and visible=?", [channeldata[0][1],guide,1])
                channelconvert = b.fetchall()
                logarray('grabGuideCode-channelconvert', channelconvert, nelements=3)
                if len(channelconvert) == 0:
                    logd1('findtvguidenotifications Waiting for Select Channel for  %s' % (repr(guide + ': Select Channel for: ' + channeldata[0][1] + ' - ' + channeldata[0][0] + ' - ' + ptitle)))
                    SelectedChannel = xbmcgui.Dialog().select(guide + ': Select Channel for: ' + channeldata[0][1] + ' - ' + channeldata[0][0] + ' - ' + ptitle, NTVchannelSelect)
                    logd1('findtvguidenotifications SelectedChannel= %r' % (SelectedChannel))
                    if SelectedChannel <> -1:
                        try:
                            id = NTVchannelSelect[SelectedChannel].split('(')[1].split(')')[0]
                            if not id == '' and not id == '0':
                                b.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight) VALUES(?, ?, ?, ?, ?, ?, ?)", [id, channeldata[0][1], '', '', guide, 'True', id])
                                cat = id  ### 2016-06-13
                        except Exception, e:
                            pass
                            utils.logdev(module,'grabGuide SelectedChannel <> -1 FAILED 4 guide= %r, ERROR= %r' % (guide,e))
                    conv.commit()
                else:
                    cat = channelconvert[0][0]
            logd1('* dr2.dk grabGuideCode-channelconvert cat= %r,guide= %r]'% (cat,guide))
            now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
            utils.logdev(module,'grabGuideCode-channelconvert now= %r,guide= %r]'% (now,guide))
            pdescription = pdescription + ' \n\nCreated: ' + now + ' \nNotification from ' + guide + ' - ' + channeldata[0][1] + ' - ' + channeldata[0][0] + ' \n\n' + ptitle
            utils.logdev(module,'grabGuideCode-channelconvert pdescription= %r,guide= %r]'% (pdescription,guide))
            pdescription = pdescription.replace('(','[').replace(')',']')
            logd1('4. recordings.schedule(cat= %r, pstart_date + timedelta(hours = TimeZoneOffset)= %r, pend_date + timedelta(hours = TimeZoneOffset)= %r, program= %r, pdescription= %r)' % (cat, HT(pstart_date + timedelta(hours = TimeZoneOffset)), HT(pend_date + timedelta(hours = TimeZoneOffset)), program, pdescription))
            if not cat == '' and not cat == '0':
                scheduleflag = recordings.schedule(cat, pstart_date + timedelta(hours = TimeZoneOffset), pend_date + timedelta(hours = TimeZoneOffset), program, pdescription)
                if scheduleflag == True:
                    scheduled +=1
        
    c.close()
    b.close()
    return scheduled
    utils.logdev(module,'grabGuide FINISHED!')
    #except:
    #   pass
    #   utils.logdev('grabGuide', 'FAILED!')

######################################################################
"""
def RecursiveRecordingsPlanned(SearchAllFavorites):
    #import recordings
    ###cat = ADDON.getSetting('SearchRecursiveIn')
    if locking.isAnyRecordLocked():
        locking.scanUnlockAll()
        return
    elif  locking.isAnyScanLocked():
        return
    else:
        locking.scanLock(SearchAllFavorites)
    if not locking.isScanLocked(SearchAllFavorites):
        return
    #utils.logdev('findrecursivetvguide.py RUNNING RecursiveRecordingsPlanned','cat= %s, SearchAllFavorites= %s' % (repr(cat), repr(SearchAllFavorites)))
    ###ADDON.setSetting('RecursiveSearch','true')
    
    conn = recordings.getConnection()
    c = conn.cursor()
    c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name LIKE '%Recursive:%' COLLATE NOCASE")  # Find all recursive recordings
    recordingsE = c.fetchall()
    # Put recursive recordings changed last - first
    recordingsC = sorted(recordingsE, key=itemgetter(2), reverse=True)
    #utils.logdev('findrecursivetvguide.py: Recursive recordings',repr(recordingsC))
    for index in range(0, len(recordingsC)):
        if isinstance(recordings.parseDate(recordingsC[index][2]), datetime.date) and isinstance(recordings.parseDate(recordingsC[index][3]), datetime.date) and 'Recursive:' in recordingsC[index][1]:
            if int(ADDON.getSetting('SearchRecursiveIn')) > 0 or ((not SearchAllFavorites == 'NotAllFavorites')and(not SearchAllFavorites == 'Once')and(not SearchAllFavorites == 'Hour')):
                if not recordingsC[index][0] in uniques:
                    findrecursiveinplaychannel(recordingsC[index][0],recordingsC[index][1],index) # Allways search channel in record
                    if ADDON.getSetting('NotifyOnSearch')=='true' and not '[COLOR orange]' in recordingsC[index][1]:
                        utils.notification('Find%s [COLOR green]complete in own channel[/COLOR]' % recordingsC[index][1])
                for cat in uniques:
                    findrecursiveinplaychannel(cat,recordingsC[index][1],index)
                if ADDON.getSetting('NotifyOnSearch')=='true' and not '[COLOR orange]' in recordingsC[index][1]:
                    utils.notification('Find%s [COLOR green]complete[/COLOR]' % recordingsC[index][1])
            else:
                findrecursiveinplaychannel(recordingsC[index][0],recordingsC[index][1],index)
                if ADDON.getSetting('NotifyOnSearch')=='true' and not '[COLOR orange]' in recordingsC[index][1]:
                    utils.notification('Find%s [COLOR green]complete[/COLOR] in selected channel: %s' % (recordingsC[index][1], recordingsC[index][0]))
    conn.commit()
    c.close()
    if ADDON.getSetting('NotifyOnSearch')=='true':
        utils.notification('Find all recursives [COLOR green]complete[/COLOR]')
    locking.scanUnlockAll()
    ###ADDON.setSetting('RecursiveSearch','false')
    return

def findrecursiveinplaychannel(cat,title,index):
    if locking.isAnyRecordLocked():
        locking.scanUnlockAll()
        return
    if '[COLOR orange]' in title:
        utils.logdev('findrecursiveinplaychannel','DISABLED: %s' % repr(title))  # Put message in LOG
        return

    name = title
    try:
        name = name.split('Recursive:')[1]
    except Exception, e:
        pass
        utils.logdev('grabGuide name.split(Recursive:)[1] FAILED ', 'guide= %r, ERROR= %r' % (guide,e))
    newname = recordings.latin1_to_ascii(name)
    newname = newname.strip()
    now= datetime.today().strftime('%Y-%m-%d %H:%M:%S').replace(' ','%20')
    nowT= recordings.parseDate(datetime.today())
    
    conn = recordings.getConnection() ###################### TV Guide database
    c = conn.cursor()
    c.execute("SELECT DISTINCT cat, name, start, end, alarmname, description, playchannel FROM recordings_adc WHERE name CONTAINS 'Recursive:'")  ####################################################################################################
    recordingsE = c.fetchall()
    # Put recursive recordings changed last - first
    recordingsC = sorted(recordingsE, key=itemgetter(2), reverse=True)
    #utils.logdev('findrecursivetvguide.py: Recursive recordings',repr(recordingsC))
    for field in recordingsC:
        time='[COLOR yellow](%s) - [/COLOR]'%(startDate.strftime('%H:%M'))
        recordnameT = recordings.latin1_to_ascii(recordname)
        startDateT = recordings.parseDate(startDate)
        if (newname.upper() in recordnameT.upper()) and (nowT < (startDateT + timedelta(hours = TimeZoneOffset))):
            recordings.schedule(cat, startDate + timedelta(hours = TimeZoneOffset), endDate + timedelta(hours = TimeZoneOffset), recordname, description)
"""

