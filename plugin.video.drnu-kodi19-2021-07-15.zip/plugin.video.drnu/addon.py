#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#      Copyright (C) 2014 Tommy Winther
#      http://tommy.winther.nu
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
import pickle
import os
import sys
import urllib.parse as urlparse
import re
import datetime
import time
import _strptime
from operator import itemgetter

import xbmc, xbmcvfs
import xbmcgui
import xbmcaddon
import xbmcplugin

import tvapi
import tvgui
###import buggalo   ### removed 2021-06-22

import shutil
import base64

###from operator import itemgetter
ADDON      = xbmcaddon.Addon()
ADDONname  = ADDON.getAddonInfo('name')
ADDONid    = ADDON.getAddonInfo('id')
if ADDON.getSetting('enable.debug') == 'true' :
    DEBUGGING  = True
else:
    DEBUGGING  = False
xbmc.log('DRNU: Start')

def RecordFlagSet(sourceApp,flag):   ### 2018-11-08
    if sourceApp == '':
        ADDONsource = xbmcaddon.Addon()
    else:
        ADDONsource = xbmcaddon.Addon(sourceApp)
    datapath = xbmcvfs.translatePath(ADDONsource.getAddonInfo('profile'))
    recordflag = os.path.join(datapath, 'RecordFlag.txt')
    FlagFile = open(recordflag, 'w')
    # Write to our text file the information we have provided and then goto next line in our file.
    # LogDev.write(repr(module) + ': ' + repr(message) + '\n')
    FlagFile.write(flag)
    FlagFile.close()

def RecordFlagGet(sourceApp):   ### 2018-11-08
    if sourceApp == '':
        ADDONsource = xbmcaddon.Addon()
    else:
        ADDONsource = xbmcaddon.Addon(sourceApp)
    datapath = xbmcvfs.translatePath(ADDONsource.getAddonInfo('profile'))
    recordflag = os.path.join(datapath, 'RecordFlag.txt')
    if os.path.isfile(recordflag):
        FlagFile = open(recordflag, 'r')
        # Write to our text file the information we have provided and then goto next line in our file.
        # LogDev.write(repr(module) + ': ' + repr(message) + '\n')
        flag = FlagFile.read()
    else:
        flag = ''
    return flag

def logdev(module,message):
    if DEBUGGING :
        nowHMS=datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        datapath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        addonlog = os.path.join(datapath, 'addon.log')
        ###xbmc.log('DRNU: logdev before reset')
        logdevreset(addonlog)
        # create lock file
        LogDev = open(addonlog, 'a')
        # Write to our text file the information we have provided and then goto next line in our file.
        # LogDev.write(repr(module) + ': ' + repr(message) + '\n')
        LogDev.write('%s %s: %s\n\n' % (nowHMS, module, message))

def logdevreset(addonlog): 
    xbmc.log('DRNU: logdevreset')
    addonOLDlog = addonlog.replace('.log','OLD.log')
    try:
        size = os.path.getsize(addonlog)
        xbmc.log('DRNU: addon.log size= %r' % size)
        maxsize = 1 * 1024 * 1024 # 1 MB 
        xbmc.log('DRNU: log size= %r' % size)
        if os.path.exists(addonlog) and size > maxsize:
            shutil.copyfile(addonlog, addonOLDlog)
            tries    = 0
            maxTries = 10
            maxSleep = 50
            while os.path.exists(addonlog) and tries < maxTries:
                try:
                    os.remove(addonlog)
                    break
                except:
                    xbmc.sleep(maxSleep)
                    tries = tries + 1
    except Exception as e:
        pass
        xbmc.log('DRNU: Reset addon.log failed: %r' % e)
        
def __log(text):
    if DEBUGGING :
        logdev('addon.py',text.encode("utf-8"))
    
def printL(message, module = 'addon.py', size=250):
    if DEBUGGING :
        if len(message) > size:
            logdev(module,message[0:size]+'...\n...\n...'+message[-250:]+'\n')
        else:
            logdev(module,message)

def cmp_to_key(mycmp):
    'Convert a cmp= function into a key= function'
    class K:
        def __init__(self, obj, *args):
            self.obj = obj
        def __lt__(self, other):
            return mycmp(self.obj, other.obj) < 0
        def __gt__(self, other):
            return mycmp(self.obj, other.obj) > 0
        def __eq__(self, other):
            return mycmp(self.obj, other.obj) == 0
        def __le__(self, other):
            return mycmp(self.obj, other.obj) <= 0
        def __ge__(self, other):
            return mycmp(self.obj, other.obj) >= 0
        def __ne__(self, other):
            return mycmp(self.obj, other.obj) != 0
    return K

def krogsbellAddons():
    ### Krogsbell IPTV addons have the file 'definition.py'
    addons = []
    try:
        SwFileFolder = os.path.join(xbmcvfs.translatePath('special://masterprofile/'), 'addon_data','krogsbell.switchaddons')
        SwFile = os.path.join(SwFileFolder,'switchaddons.txt')
        if not os.path.exists(SwFileFolder):
            os.mkdir(SwFileFolder)
            open(SwFile, 'a').close()
        printL('SwFile= %r' % SwFile)
        switchfile = open(SwFile, 'r')
        addonsO = switchfile.read()
        switchfile.close() 
        if not ADDONid in addonsO:
            addonsO += '\n' + ADDONrefer + ':' + ADDONid
            addonsO = addonsO.replace('\n\n\n\n','\n').replace('\n\n\n','\n').replace('\n\n','\n')
            LF = open(SwFile, 'w')
            LF.write(addonsO)
            LF.close()
        ADDON.setSetting('switchaddons',addonsO)
        if addonsO != '' :
            addonsO = addonsO.split('\n')
            for addon in addonsO:
                if addon != '':
                    newaddon = addon.split(':')
                    if newaddon[1] != ADDONid:
                        try:
                            testAddon = xbmcaddon.Addon(id=newaddon[1])
                            pathTOaddon = os.path.join(xbmcvfs.translatePath('special://home/addons'), newaddon[1])
                            if os.path.exists(pathTOaddon):
                                addons.append(newaddon)
                        except Exception as e:
                            pass
                            printL('testAddon FAILED= %r' % e)
    except Exception as e:
        pass
        addons.append(['ERROR',repr(e)])
    ###[['GlowIPTV','plugin.video.glowiptv.rec'],['DR NU','plugin.video.drnu'],['BBC iPlayer','plugin.video.iplayerwww'],['ITV Player','plugin.video.itv']]
    addons = sorted(addons)
    choises = []
    for choise in addons:
       choises.append(choise[0] + ': ' + choise[1])
    return choises

def krogsbellAddonsSelect():
    printL('krogsbellAddonsSelect: Start')
    choisesall = krogsbellAddons()
    choises    = []
    progpath   = ADDON.getAddonInfo('path')
    datapath   = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    for choise in choisesall:
        try:
            newADDONid = choise.replace(': ',':').split(':')[1]
            progpathnew= os.path.join(progpath.replace(ADDONid,newADDONid),'definition.py')
            printL('progpathnew= %r' % progpathnew)
            if os.path.exists(progpathnew):
                ### ...\addon_data\...\storage\channels.json
                datapathnew= os.path.join(datapath.replace(ADDONid,newADDONid),'storage','channels.json')
                printL('datapathnew= %r' % datapathnew)
                if not os.path.exists(datapathnew):
                    targetADDON = xbmcaddon.Addon(id=newADDONid)
                    enable_record = targetADDON.getSetting('enable_record')
                    printL('targetADDON= %r, enable_record= %r'% (targetADDON, enable_record))            
                    if enable_record == 'true':
                        printL('choises.append(choise)= %r' % choise)
                        choises.append(choise)
        except Exception as e:
            pass
            choises.append('Error: %r' % e)
    selected = -1
    if len(choises) > 0:
        dialog = xbmcgui.Dialog()
        printL('select(choises)= %r' % choises)
        selected = dialog.select('[B]'+ADDON.getAddonInfo('name') +'[/B][I]'+ ADDON.getLocalizedString(30031)+'[/I]', choises) ####################
        printL('selected choise#= %r' % selected)
    if selected != -1:
        printL('selected Addon = %r ' % choises[selected])
        return choises[selected].replace(': ',':').split(':')[1]
    return ''

def krogsbell(name,url,there_are_subtitles,subtitles_file):
    ###def PLAY_STREAM_HLS_LIVE(name,url,iconimage):
    ### Krogsbell 2019-01-14 VVVVVVV#####################################################
    printL('krogsbell(name=%r\n,url=%r\n,there_are_subtitles=%r\n,subtitles_file=%r\n)'% (name,url,there_are_subtitles,subtitles_file))
    cmd  = 'XBMC.Notification(%s, %s, %r, %s)' % (name, url, 10000, '') 
    xbmc.executebuiltin(cmd) 
    description = 'From DRNU Addon'
    if there_are_subtitles == 1:
        subtitles_url = subtitles_file
    else:
        subtitles_url = ''
    name = name.replace(',','') 
    printL('replace , in name with (nothing) name= %r' % name)
    iconimage = 'DefaultVideo.png'
    krogsbellAddonID = krogsbellAddonsSelect()
    recording = False
    if krogsbellAddonID != '' :
        if not '&description=' in url:
            URI='plugin://'+krogsbellAddonID+'/?url=url&mode=2011&name='+base64b64encode(name+' [ITV Player]')+'&uri='+base64b64encode(url+'&description=' + description+'&subtitlesurl='+subtitles_url+'&subtitlesoffset=0')
        else:
            URI='plugin://'+krogsbellAddonID+'/?url=url&mode=2011&name='+base64b64encode(name+' [ITV Player]')+'&uri='+base64b64encode(url+'&subtitlesurl='+subtitles_url+'&subtitlesoffset=0')
        printL('URI= %r' % URI)
        try:
            xbmc.executebuiltin('RunPlugin(%s)' % URI)
            recording = True
        except:
            pass
            printL('No valid Addon to record stream!')
            printL('Play Video')
    return recording


def recordingaddons():
    try:
        addons = []
        SwFileFolder = os.path.join(xbmcvfs.translatePath('special://masterprofile/'), 'addon_data','krogsbell.switchaddons')
        SwFile = os.path.join(SwFileFolder,'switchaddons.txt')
        if not os.path.exists(SwFileFolder):
            os.mkdir(SwFileFolder)
            open(SwFile, 'a').close()
        __log('SwFile= %r' % SwFile)
        switchfile = open(SwFile, 'r')
        addonsO = switchfile.read()
        switchfile.close() 
        if addonsO != '' :
            addonsO = addonsO.split('\n')
            for addon in addonsO:
                if addon != '':
                    __log('addon= %r' % addon)
                    newaddon = addon.split(':')
                    if newaddon[1] != ADDONid:
                        if 'video.' in newaddon[1]:
                            pathTOaddon = os.path.join(xbmcvfs.translatePath('special://home/addons'), newaddon[1])
                            if os.path.exists(pathTOaddon):
                                addons.append(newaddon)
    except Exception as e:
        pass
        addons.append(['ERROR',repr(e)])
    addons = sorted(addons)
    return addons

def TS(timestr):
    ### time format 2019-05-21T22:05:00Z
    time_tuple = time.strptime(timestr, "%Y-%m-%dT%H:%M:%SZ")
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def now():   ### Local time
    dt_obj= datetime.datetime.now()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
   
def nowTS():   ### UTC time
    dt_obj= datetime.datetime.utcnow()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def nowS(format):   ### Now date string UTC time
    time_tuple = time.localtime(nowTS())
    date_str = time.strftime(format, time_tuple)
    return(date_str)
    
def datestr(timestamp,format):   ### Date string UTC time %Y-%m-%dT%H:%M:%SZ
    time_tuple = time.localtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)

def datestrdelta(timestamp,format):   ### Now date string UTC time %Y-%m-%dT%H:%M:%SZ
    time_tuple = time.gmtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)

def base64b64encode(texttoencode):
    ###printL('0 texttoencode= %r' % texttoencode)
    try:
        result = base64.b64encode(texttoencode.encode())
        ###printL('1 result= %r' % result)
    except Exception as e:
        pass
        printL('base64b64encode() ERROR: %r' % e)
        result = base64.b64encode(texttoencode)
        ###printL('2 result= %r' % result)
        
    ###printL('3 result= %r' % result)
    texttoencode = 'b64' + result.decode()
    ###printL('1 texttoencode= %r' % texttoencode)
    return texttoencode
    
    
def switch(x):
    findP = ADDON.getSetting('LastSwitch')  ### datestr(nowTS(),'h%Hm%Ms%S'))
    if findP == '':
        delta = 10
    else:
        delta = nowTS() - TS(findP)
    __log('delta= %r' % delta)
    if delta > 9:
        ADDON.setSetting('LastSwitch',datestr(nowTS(),'%Y-%m-%dT%H:%M:%SZ'))
        dialog = xbmcgui.Dialog()
        addons = []
        try:
            SwFileFolder = os.path.join(xbmcvfs.translatePath('special://masterprofile/'), 'addon_data','krogsbell.switchaddons')
            SwFile = os.path.join(SwFileFolder,'switchaddons.txt')
            if not os.path.exists(SwFileFolder):
                os.mkdir(SwFileFolder)
                open(SwFile, 'a').close()
            __log('SwFile= %r' % SwFile)
            switchfile = open(SwFile, 'r')
            addonsO = switchfile.read()
            switchfile.close() 
            if not ADDONid in addonsO:
                addonsO += '\n' + ADDONname + ':' + ADDONid
                addonsO = addonsO.replace('\n\n\n\n','\n').replace('\n\n\n','\n').replace('\n\n','\n')
                LF = open(SwFile, 'w')
                LF.write(addonsO)
                LF.close()
            ADDON.setSetting('switchaddons',addonsO)
            if addonsO != '' :
                addonsO = addonsO.split('\n')
                for addon in addonsO:
                    if addon != '':
                        __log('addon= %r' % addon)
                        newaddon = addon.split(':')
                        if newaddon[1] != ADDONid:
                            try:
                                testAddon = xbmcaddon.Addon(id=newaddon[1])
                                pathTOaddon = os.path.join(xbmcvfs.translatePath('special://home/addons'), newaddon[1])
                                if os.path.exists(pathTOaddon):
                                    addons.append(newaddon)
                            except Exception as e:
                                pass
                                __log('testAddon FAILED= %r' % e)
        except Exception as e:
            pass
            addons.append(['ERROR',repr(e)])
        addons = sorted(addons)
        choises = []
        for choise in addons:
           choises.append(choise[0] + ': ' + choise[1])
        if len(choises) > 0:
            selected = dialog.select(ADDON.getAddonInfo('name') + ' - Select an Addon to switch to:', choises)
            if selected != -1:
                __log('selected Addon= %r - %r' % (addons[selected][0],addons[selected][1]))
                IDdoADDON = addons[selected][1]
                __log('Start Addon= %r' % IDdoADDON)
                xbmc.executebuiltin('Dialog.Close(busydialog)')   ### 2019-09-03 needed to allow switch addon
                xbmc.executebuiltin('RunAddon(%s)' % IDdoADDON)
     
class DrDkTvAddon(object):
    
    def __init__(self):
        self.api = tvapi.Api(CACHE_PATH)
        self.favorites = list()
        self.recentlyWatched = list()

        self.menuItems = list()
        runScript = "RunAddon(plugin.video.drnu,?show=areaselector&random=%d)" % HANDLE
        self.menuItems.append((ADDON.getLocalizedString(30511), runScript))


    def _saveORG(self):
        # save favorites
        try:
            printL('save FAVORITES_PATH= %r' % FAVORITES_PATH)
            printL('favorites = pickle.dump 1= %r' % self.favorites)
            self.favorites.sort()
            printL('favorites = pickle.dump 2= %r' % self.favorites)
            pickle.dump(self.favorites, open(FAVORITES_PATH, 'wb'))
            self.textfilesave(self.favorites)
            printL('favorites = pickle.dump 3= %r' % self.favorites)
            printL('save FRECENT_PATH= %r' % RECENT_PATH)
            self.recentlyWatched = self.recentlyWatched[0:25]  # Limit to 25 items
            pickle.dump(self.recentlyWatched, open(RECENT_PATH, 'wb'))
        except Exception as e:
            pass
            printL('_save ERROR= %r' % e)

    def _loadORG(self):
        # load favorites
        printL('load FAVORITES_PATH= %r' % FAVORITES_PATH)
        if os.path.exists(FAVORITES_PATH):
            try:
                self.favorites = pickle.load(open(FAVORITES_PATH, 'rb'), encoding='utf-8')
                printL('favorites = pickle.load= %r' % self.favorites)
                self.textfilesave()
            except Exception as e:
                pass
                printL('FAVORITES_PATH ERROR= %r' % e)
                

        # load recently watched
        printL('load RECENT_PATH= %r' % RECENT_PATH)
        if os.path.exists(RECENT_PATH):
            try:
                self.recentlyWatched = pickle.load(open(RECENT_PATH, 'rb'), encoding='utf-8')
                printL('frecentlyWatched = pickle.load= %r' % self.recentlyWatched)
            except Exception as e:
                pass
                printL('FRECENT_PATH ERROR= %r' % e)
    
    def _load(self):
        if os.path.exists(FAVORITES_PATH_TXT):
            try:
                favoritesfile = open(FAVORITES_PATH_TXT, 'r')
                self.favorites = favoritesfile.read().split('\n')
                printL('ORG favorites= %r' % self.favorites)
                self.favorites = [x for x in self.favorites if x != '']
                ###self.favorites = self.favorites.replace('\n\n','\n').split('\n')
                printL('RES favorites= %r' % self.favorites)
                favoritesfile.close() 
            except Exception as e:
                pass
                printL('FAVORITES_PATH_TXT LOAD ERROR= %r' % e)
        if os.path.exists(RECENT_PATH_TXT):
            try:
                favoritesfile = open(RECENT_PATH_TXT, 'r')
                self.recentlyWatched = favoritesfile.read().split('\n')
                favoritesfile.close() 
            except Exception as e:
                pass
                printL('FAVORITES_PATH_TXT LOAD ERROR= %r' % e)
        
        
    def _save(self):
        try:
            favoritesfile = open(FAVORITES_PATH_TXT, 'w')
            favoritesfile.write('\n'.join(self.favorites))
            favoritesfile.close()
        except Exception as e:
            pass
            printL('FAVORITES_PATH_TXT SAVE ERROR= %r' % e)
        try:
            favoritesfile = open(RECENT_PATH_TXT, 'w')
            favoritesfile.write('\n'.join(self.recentlyWatched))
            favoritesfile.close()
        except Exception as e:
            pass
            printL('RECENT_PATH_TXT SAVE ERROR= %r' % e)

    def showAreaSelector(self):
        gui = tvgui.AreaSelectorDialog()
        gui.doModal()
        areaSelected = gui.areaSelected
        del gui

        if areaSelected == 'none':
            pass
        elif areaSelected == 'drtv':
            self.showMainMenu()
        else:
            items = self.api.getChildrenFrontItems('dr-' + areaSelected)
            #xbmc.executebuiltin('Container.SetViewMode(500)')
            self.listSeries(items)

    def showMainMenu(self):
        items = list()
        # Live TV
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30027))
        iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'livetv.png')
        item.setArt({ 'icon': iconImage, 'thumb' : iconImage })
        item.setProperty('Fanart_Image', FANART_IMAGE)
        item.addContextMenuItems(self.menuItems, False)
        items.append((PATH + '?show=liveTV', item, True))

        # A-Z Program Series
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30000))
        iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'all.png')
        item.setArt({ 'icon': iconImage, 'thumb' : iconImage })
        item.setProperty('Fanart_Image', FANART_IMAGE)
        item.addContextMenuItems(self.menuItems, False)
        items.append((PATH + '?show=listAZ', item, True))

        # Latest
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30001))
        iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'all.png')
        item.setArt({ 'icon': iconImage, 'thumb' : iconImage })
        item.setProperty('Fanart_Image', FANART_IMAGE)
        item.addContextMenuItems(self.menuItems, False)
        items.append((PATH + '?show=latest', item, True))

        # Premiere
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30025))
        iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'new.png')
        item.setArt({ 'icon': iconImage, 'thumb' : iconImage })
        item.setProperty('Fanart_Image', FANART_IMAGE)
        item.addContextMenuItems(self.menuItems, False)
        items.append((PATH + '?listVideos=%s' % tvapi.SLUG_PREMIERES, item, True))

        # Themes / Repremiere
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30028))
        iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'all.png')
        item.setArt({ 'icon': iconImage, 'thumb' : iconImage })
        item.setProperty('Fanart_Image', FANART_IMAGE)
        item.addContextMenuItems(self.menuItems, False)
        items.append((PATH + '?show=themes', item, True))

        # Most viewed
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30011))
        iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'eye.png')
        item.setArt({ 'icon': iconImage, 'thumb' : iconImage })
        item.setProperty('Fanart_Image', FANART_IMAGE)
        item.addContextMenuItems(self.menuItems, False)
        items.append((PATH + '?show=mostViewed', item, True))

        # Spotlight
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30002))
        iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'star.png')
        item.setArt({ 'icon': iconImage, 'thumb' : iconImage })
        item.setProperty('Fanart_Image', FANART_IMAGE)
        item.addContextMenuItems(self.menuItems, False)
        items.append((PATH + '?show=highlights', item, True))

        # Search videos
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30003))
        iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'search.png')
        item.setArt({ 'icon': iconImage, 'thumb' : iconImage })
        item.setProperty('Fanart_Image', FANART_IMAGE)
        item.addContextMenuItems(self.menuItems, False)
        items.append((PATH + '?show=search', item, True))

        # Recently watched Program Series
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30007))
        iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'eye-star.png')
        item.setArt({ 'icon': iconImage, 'thumb' : iconImage })
        item.setProperty('Fanart_Image', FANART_IMAGE)
        item.addContextMenuItems(self.menuItems, False)
        items.append((PATH + '?show=recentlyWatched', item, True))

        # Favorite Program Series
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30008))
        iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'plusone.png')
        item.setArt({ 'icon': iconImage, 'thumb' : iconImage })
        item.setProperty('Fanart_Image', FANART_IMAGE)
        items.append((PATH + '?show=favorites', item, True))
        item.addContextMenuItems(self.menuItems, False)
        
        # Switch Krogsbell Addons
        doyouhavekrogsbellAddons = krogsbellAddons()
        printL('doyouhavekrogsbellAddons= %r' % doyouhavekrogsbellAddons)
        if not 'error' in str(krogsbellAddons()).lower():
            item = xbmcgui.ListItem(ADDON.getLocalizedString(30030))
            iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'eye-star.png')
            item.setArt({ 'icon': iconImage, 'thumb' : iconImage })
            item.setProperty('Fanart_Image', FANART_IMAGE)
            items.append((PATH + '?switch=x', item, True))
            item.addContextMenuItems(self.menuItems, False)

        xbmcplugin.addDirectoryItems(HANDLE, items)
        xbmcplugin.endOfDirectory(HANDLE)

    def showFavorites(self):
        self._load()
        if not self.favorites:
            xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'),ADDON.getLocalizedString(30013))
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        else:
            series = []
            episodes = []
            for slug in self.favorites:
                printL('self.favorites:slug= %r' % slug)
                if slug != '':
                    serie = self.api.searchSeries(slug)
                    printL('self.favorites:Serie= %r' % serie[0])
                    series.extend(serie)
                    printL('self.favorites:series= %r' % series)
                    SeriesTitle = serie[0]['SeriesSlug']
                    printL('self.favorites:SeriesTitle= %r' % SeriesTitle)
                    episode = self.api.getEpisodes(SeriesTitle)
                    printL('self.favorites:episode= %r' % episode)
                    episodes.extend(episode)
                    printL('self.favorites:episodes= %r' % episodes)
            ###self.listSeriesFlat(series, addToFavorites=False) 
            self.listSeries(series, addToFavorites=False)  
            
            """
            try:
                    series.extend(self.api.searchSeries(slug))
                    item = self.api.getEpisode(slug)
                    series.append(item)
                except Exception as e:
                    pass
                    printL('self.favorites:slug error= %r' % e)
            self.listEpisodes(series)
                series.extend(self.api.searchSeries(slug))
            self.listSeries(series, addToFavorites=False)
            """
    def showRecentlyWatched(self):
        self._load()
        videos = list()
        for slug in self.recentlyWatched:
            printL('self.showRecentlyWatched:slug= %r' % slug)
            try:
                item = self.api.getEpisode(slug)
                if item is None:
                    self.recentlyWatched.remove(slug)
                else:
                    videos.append(item)
            except tvapi.ApiException:
                # probably a 404 - non-existent slug
                self.recentlyWatched.remove(slug)

        self._save()
        if not videos:
            xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'),ADDON.getLocalizedString(30013)+'\n'+ADDON.getLocalizedString(30020))
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        else:
            self.listEpisodes(videos)

    def showLiveTV(self):
        items = list()
        itemnames = list()
        for channel in self.api.getLiveTV():
            if channel['WebChannel']:
                continue

            server = None
            for streamingServer in channel['StreamingServers']:
                if streamingServer['LinkType'] == 'HLS':
                    server = streamingServer
                    break

            if server is None:
                continue

            item = xbmcgui.ListItem(channel['Title'])
            iconImage=channel['PrimaryImageUri']
            item.setArt({ 'icon': iconImage, 'thumb' : iconImage })
            item.setProperty('Fanart_Image', channel['PrimaryImageUri'])
            item.addContextMenuItems(self.menuItems, False)

            url = server['Server'] + '/' + server['Qualities'][0]['Streams'][0]['Stream']
            items.append((url, item, False))
            itemnames.append((channel['Title'].replace(' ',''),url, item, False))
        printL('0 items= %r' % items)
        ###mycmp = lambda mine, yours: cmp(mine[1].getLabel().replace(' ', ''), yours[1].getLabel().replace(' ', ''))
        ###mycmp = (mine[1].getLabel().replace(' ', ''), yours[1].getLabel().replace(' ', ''))
        ###key = cmp_to_key(mycmp)
        ###printL('key= %r' % key)
        ###items = sorted(items, lambda mine, yours: cmp(mine[1].getLabel().replace(' ', ''), yours[1].getLabel().replace(' ', '')))
        
        itemnames = sorted(itemnames)
        items = list()
        for item in itemnames:
            items.append((item[1], item[2], item[3]))
        printL('3 items= %r' % items)
        printL('3 itemnames= %r' % itemnames)
        xbmcplugin.addDirectoryItems(HANDLE, items)
        xbmcplugin.endOfDirectory(HANDLE)

    def showAZ(self):
        # All Program Series
        iconImage = os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'all.png')

        items = list()
        for programIndex in self.api.getProgramIndexes():
            item = xbmcgui.ListItem(programIndex['Title'])
            item.setArt({ 'icon': iconImage, 'thumb' : iconImage })
            item.setProperty('Fanart_Image', FANART_IMAGE)
            item.addContextMenuItems(self.menuItems, False)
            url = PATH + '?listProgramSeriesByLetter=' + programIndex['_Param']
            items.append((url, item, True))
            printL('showAZ #= %r url= %r' % (len(items),url))

        ###items = sorted(items) ### 2018-01-02
        xbmcplugin.addDirectoryItems(HANDLE, items)
        xbmcplugin.endOfDirectory(HANDLE)

    def showThemes(self):
        items = list()
        for theme in self.api.getThemes():
            item = xbmcgui.ListItem(theme['ThemeTitle'], iconImage=theme['PrimaryImageUri'])
            
            item.setProperty('Fanart_Image', theme['PrimaryImageUri'])
            item.addContextMenuItems(self.menuItems, False)

            url = PATH + '?listVideos=' + theme['ThemeSlug']
            items.append((url, item, True))

        ###items = sorted(items) ### 2018-01-02
        xbmcplugin.addDirectoryItems(HANDLE, items)
        xbmcplugin.endOfDirectory(HANDLE)

    def searchSeries(self):
        keyboard = xbmc.Keyboard('', ADDON.getLocalizedString(30003))
        keyboard.doModal()
        if keyboard.isConfirmed():
            keyword = keyboard.getText()
            self.listSeries(self.api.getSeries(keyword)) 

    def listSeries(self, items, addToFavorites=True):
        if not items:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            if not addToFavorites:
                xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'),ADDON.getLocalizedString(30013)+'\n'+ADDON.getLocalizedString(30018)+'\n'+ADDON.getLocalizedString(30019))
            else:
                xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'),ADDON.getLocalizedString(30013))
        else:
            directoryItems = list()
            directoryItemsTitles = list()
            ###items = sorted(items) ### 2018-01-02
            for item in items:
                menuItems = list(self.menuItems)
                printL('listSeries item= %r' % item)
                
                try:
                    if item['PrimaryAsset']['RestrictedToDenmark']:
                        RestrictedToDenmark = True
                    else: 
                        RestrictedToDenmark = False
                except Exception as e:
                    pass
                    printL('RestrictedToDenmark ERROR: %r' % e)
                    RestrictedToDenmark = False
                if RestrictedToDenmark == True:
                    RestrictedToDenmarkMarker = ' [COLOR red]Kun DK[/COLOR]'
                else:
                    RestrictedToDenmarkMarker = ''
                
                try:
                    count = self.favorites.count(item['SeriesTitle'])
                    printL('favorites.count(item[SeriesTitle])= %r' % count)
                    if count == 0:
                        runScript = "RunPlugin(plugin://plugin.video.drnu/?addfavorite=%s)" % (item['SeriesTitle']).replace('&', '%26').replace(',', '%2C')
                        menuItems.append((ADDON.getLocalizedString(30200), runScript))
                    else:
                        runScript = "RunPlugin(plugin://plugin.video.drnu/?delfavorite=%s)" % (item['SeriesTitle']).replace('&', '%26').replace(',', '%2C')
                        menuItems.append((ADDON.getLocalizedString(30201), runScript))
                except Exception as e:
                    pass
                    printL('Error in favorites.count(item[SeriesTitle]): %r' % e)

                iconImage = item['PrimaryImageUri']
                printL('listSeries item[SeriesTitle]= %r' % item['SeriesTitle'])
                printL('listSeries item= %r' % item)
                episodeCount = self.countEpisodes(item)
                printL('listSeries episodeCount= %r' % episodeCount)
                listItem = xbmcgui.ListItem(item['SeriesTitle']+RestrictedToDenmarkMarker+episodeCount)
                ###listItem = xbmcgui.ListItem(item['SeriesTitle']+RestrictedToDenmarkMarker)
                listItem.setArt({ 'icon': iconImage, 'thumb' : iconImage })
                listItem.setProperty('Fanart_Image', iconImage)
                listItem.addContextMenuItems(menuItems, False)
                
                url = PATH + '?listVideos=' + item['SeriesSlug']
                printL('listSeries.url= %r' % url)
                printL('len(directoryItems)= %r' % len(directoryItems))
                if len(directoryItems) > 0:
                    printL('directoryItems= %r' % directoryItems)
                    printL('directoryItemsTitles]= %r' % directoryItemsTitles)
                    if not (item['SeriesTitle']).lower() in directoryItemsTitles:
                        directoryItemsTitles.append((item['SeriesTitle']).lower())
                        directoryItems.append(((item['SeriesTitle']+RestrictedToDenmarkMarker).lower(),url, listItem, True))
                else:
                    directoryItemsTitles.append((item['SeriesTitle']).lower())
                    directoryItems.append(((item['SeriesTitle']+RestrictedToDenmarkMarker).lower(),url, listItem, True))

            printL('directoryItems0-1 %r' % directoryItems)
            directoryItems= self.sorteditems(directoryItems)
            
            xbmcplugin.addDirectoryItems(HANDLE, directoryItems)
            xbmcplugin.endOfDirectory(HANDLE)
    
    def sorteditems(self,items):
        ### Sort list from first column and then remove first column
        printL('items0-1 %r' % items)
        
        items = sorted(items, key=itemgetter(0)) 
        
        printL('items0-2 %r' % items,size=2500)
        ItemsNoTitle = []
        for diri in items:
            ItemsNoTitle.append((diri[1],diri[2],diri[3]))
        printL('ItemsNoTitle1-1 %r' % ItemsNoTitle)
        return ItemsNoTitle
    
    def listSeriesFlat(self, items, addToFavorites=True):
        ###printL('listSeriesFlat:items= %r' % items)
        if not items:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            if not addToFavorites:
                xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'),ADDON.getLocalizedString(30013)+'\n'+ADDON.getLocalizedString(30018)+'\n'+ADDON.getLocalizedString(30019))
            else:
                xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'),ADDON.getLocalizedString(30013))
        else:
            directoryItems = list()
            ###items = sorted(items) ### 2018-01-02
            for item in items:
                printL('listSeriesFlat:\nitem.Title= %r\nitem.SeriesTitle= %r\nitem.SeriesSlug= %r' % (item['Title'],item['SeriesTitle'],item['SeriesSlug']))
                ### url = PATH + '?listVideos=' + item['SeriesSlug']
                episodes = self.api.getSeries(item['SeriesSlug'])
                printL('listSeriesFlat:episodes= %r' % episodes)
                for episode in episodes:
                    printL('listSeriesFlat:episode= %r' % episode)
                    directoryItems.append(episode)
                printL(repr(directoryItems))
            """
            printL('directoryItems0 %r' % directoryItems)
            directoryItems = sorted(directoryItems) ### 2018-01-02
            directoryItemsNoTitle = []
            for dir in directoryItems:
                directoryItemsNoTitle.append((dir[1],dir[2],dir[3]))
            printL('directoryItems1-2 %r' % directoryItemsNoTitle)
            xbmcplugin.addDirectoryItems(HANDLE, directoryItemsNoTitle)
            xbmcplugin.endOfDirectory(HANDLE)
            """
    
    def countEpisodes(self, item):
        printL('countEpisodes item= %r' % item, size=5000)
        IsRerun = 0
        IsExpiresSoon = 0
        IsRestricted = 0
        IsItem = 0
        try:
            printL('countEpisodes len(item)= %r' % len(item))   
            printL('countEpisodes SeriesTitle= %r' % item['SeriesTitle'])
            printL('countEpisodes SeriesSlug= %r' % item['SeriesSlug'])
            
            episodes = self.api.getEpisodes(item['SeriesSlug'])
            ###episodes = self.api.getEpisodes(item['SeriesTitle'])
            printL('countEpisodes countSeriesFlat:episodes= %r' % episodes, size=5000)
            for episode in episodes:
                printL('countEpisodes episode #%r' % IsItem)
                printL('countEpisodes countSeriesFlat:episode= %r' % episode, size=5000)
        
                printL('countEpisodes PrimaryAsset= %r' % item['PrimaryAsset'])
                printL('countEpisodes PrimaryAsset= %r' % item)
                IsItem += 1 
                try:    
                    printL('countEpisodes item[RestrictedToDenmark]= %r' % item['RestrictedToDenmark'])
                    if item['RestrictedToDenmark'] == True:
                        printL('countEpisodes [RestrictedToDenmark]= True')
                        IsRestricted += 1
                except:
                    pass
                try:
                    printL('countEpisodes item(all [PrimaryBroadcast][IsRerun])= %r' % item['PrimaryBroadcast'], size=5000)
                    printL('countEpisodes item[PrimaryBroadcast][IsRerun]= %r' % item['PrimaryBroadcast']['IsRerun'])
                    if item['PrimaryBroadcast']['IsRerun'] == True:
                        printL('countEpisodes [IsRerun]= True')
                        IsRerun += 1    
                except:
                    pass
                try:
                    printL('countEpisodes item[ExpiresSoon]= %r' % item['ExpiresSoon'])
                    if item['ExpiresSoon'] == True:
                        printL('countEpisodes [ExpiresSoon]= True')
                        IsExpiresSoon += 1
                except:
                    pass
                printL('countEpisodes= #%r *%r Ex%r Re%r' % (IsItem, IsRestricted, IsExpiresSoon, IsRerun)) 
        except:
            pass
        ###return ' [COLOR grey](%r Ex%r Re%r)[/COLOR]' % (IsItem, IsExpiresSoon, IsRerun)    
        return ' [COLOR grey](%r)[/COLOR]' % (IsItem)    
           
           
    
    def listEpisodes(self, items, addSortMethods=True):
        directoryItems = list()
        printL('items= %r' % items)
        ###items = sorted(items) ### 2021-03-04
        for item in items:
            printL('listEpisodes item= %r' % item)  ### 2018-12-19
            if 'PrimaryAsset' not in item or 'Uri' not in item['PrimaryAsset'] or not item['PrimaryAsset']['Uri']:
                continue
            ###printL('1')
            IsRerun = 0
            IsExpiresSoon = 0
            infoLabels = {
                'title': item['Title']
            }
            ###printL('2')
            duration = ''
            Title = item['Title']
            ###printL('3')
            try:
                year = str(item['ProductionYear'])
                if year < '1920':
                    year = ''
                ###printL('4')
            except Exception as e:
                pass
                printL('Error geting Year: ' + repr(e))
                try:
                   year = str(item['Year']) 
                   ###printL('5')
                except Exception as e:
                    pass
                    printL('Error geting Year: ' + repr(e))
                    year = ''
            printL('year= %r, item= %r' % (year, item))
            
            try:
                if item['PrimaryAsset']['RestrictedToDenmark']:
                    RestrictedToDenmark = True
                else: 
                    RestrictedToDenmark = False
                ###printL('6')
            except Exception as e:
                pass
                printL('RestrictedToDenmark ERROR: %r' % e)
                RestrictedToDenmark = False
            try:
                if item['PrimaryBroadcast']['BroadcastDate']:
                    FirstAired = str(item['PrimaryBroadcast']['BroadcastDate'])
                    ###printL('7')
                else: 
                    FirstAired = ''
                    ###printL('8')
            except Exception as e:
                pass
                printL('FirstAired ERROR: %r' % e)
                FirstAired = ''
            if 'T' in FirstAired:
                FirstAired = FirstAired.split('T')[0]
            if FirstAired:
                FirstAired = '[COLOR blue]'+ FirstAired + ' [/COLOR] '
            if RestrictedToDenmark == True:
                RestrictedToDenmarkMarker = '[COLOR red]Kun DK [/COLOR] '
            else:
                RestrictedToDenmarkMarker = ''
            
            try:
                ### IsRerun = Genudsendelse  "SeasonSlug"
                duration = int(item['PrimaryAsset']['DurationInMilliseconds'])
                ###printL('9')
                duration = duration/1000/60
                ###printL('10')
                if duration:
                    ###duration = ' [' + str(duration) + ' min]'
                    duration = str(int(item['PrimaryAsset']['DurationInMilliseconds'])/1000/60)
                    ###printL('11 duration= %r' % duration)
                    durationH = int(int(duration.split('.')[0])/60)
                    ###printL('12')
                    durationM = (int(duration.split('.')[0]) - durationH*60)
                    ###printL('13')
                    duration =  '[' + str(durationH) + 'h' + str(durationM).zfill(2) + 'm] '
                    ###printL('14')
                else:
                    duration = ''
                    ###printL('15')
                ###duration = duration
                
                SeasonTitle = item['SeasonTitle']
                printL('16 SeasonTitle= %r' % SeasonTitle)
                if not SeasonTitle.lower() in Title.lower():
                    duration = duration + SeasonTitle+ ' ' 
                if year != '' and not year in Title and not year in duration:
                    duration = year + ' ' + duration
                try:
                    IsRerun = item['PrimaryBroadcast']['IsRerun']
                except:
                    pass
                    IsRerun = 0
                if IsRerun:
                    ###duration = duration + ' [COLOR red]Genudsendelse[/COLOR]'
                    rerun = '[COLOR red]Genudsendelse[/COLOR] '
                else:
                    rerun = ''
                try:
                    IsExpiresSoon = item['ExpiresSoon']
                except:
                    pass
                    IsExpiresSoon = 0
                if IsExpiresSoon:
                    ###duration = duration + ' \n[COLOR lightgreen]Udløber snart[/COLOR]'
                    expiresoon = '[COLOR lightgreen]Udløber snart[/COLOR] '
                else:
                    expiresoon = ''
                try:
                    bct = '[COLOR grey]'+ broadcastTime.strftime('%Y-%m-%d') + ' [/COLOR] '
                except:
                    pass
                    bct = ''
                duration = duration +'\n[I]'+ rerun + expiresoon + FirstAired + RestrictedToDenmarkMarker  + bct + '[/I]'### 2020-02-11 
            except Exception as e:
                pass
                printL('Title duration fails: %r, \n%r' % (item,e))
                duration = duration + ' [ '+repr(e)+']'
                duration = str(duration)   ### 2018-02-09
            ###duration = duration.decode('utf-8')   ### 2018-02-09
            if IsRerun or IsExpiresSoon:
                infoLabels = {
                    'title': ('[COLOR red]*[/COLOR] [B]' + item['Title'] + '[/B] ' + duration)  
                } 
            else:
                if IsExpiresSoon:
                    infoLabels = {
                        'title': ('[COLOR red]¤[/COLOR][COLOR lightgreen][B]' + item['Title'] + '[/COLOR][/B] ' + duration)  
                    }   
                else:
                        infoLabels = {
                        'title': ('[COLOR lightgreen][B]' + item['Title'] + '[/COLOR][/B] ' + duration)  
                        ###infoLabels = {
                        ###'title': ('[COLOR lightgreen][B]' + item['Title'] + '[/COLOR][/B] ' + duration)  
                    }   

                
            if 'Description' in item:
                infoLabels['plot'] = item['Description']
            iconImage = item['PrimaryImageUri']
            if 'PrimaryBroadcastStartTime' in item and item['PrimaryBroadcastStartTime'] is not None:
                broadcastTime = self.parseDate(item['PrimaryBroadcastStartTime'])
                if broadcastTime:
                    infoLabels['date'] = broadcastTime.strftime('%d.%m.%Y')
                    infoLabels['aired'] = broadcastTime.strftime('%Y-%m-%d')
                    infoLabels['year'] = int(broadcastTime.strftime('%Y'))
                    ###infoLabels['year'] = int(year)
            printL('Slug to Title ' +  item['Slug'] + '==>' +item['Title'])        
            ###listItem = xbmcgui.ListItem(item['Slug'] + '==>' +item['Title'], iconImage=iconImage)  ### 2018-02-02
            listItem = xbmcgui.ListItem(item['Title'])
            listItem.setArt({ 'icon': iconImage, 'thumb' : iconImage })
            listItem.setInfo('video', infoLabels)
            listItem.setProperty('Fanart_Image', iconImage)
            url = PATH + '?playVideo=' + item['Slug']
            printL('url= %r' % url)
            listItem.setProperty('IsPlayable', 'true')
            listItem.addContextMenuItems(self.menuItems, False)
            directoryItems.append((item['Title'].lower(),url, listItem))

        ###printL('directoryItems2 %r' % directoryItems)
        directoryItems = sorted(directoryItems) ### 2018-01-02
        ###printL('directoryItems3 %r' % directoryItems)
        directoryItemsNoTitle = []
        for dir in directoryItems:
            directoryItemsNoTitle.append((dir[1],dir[2]))  ### 2018-02-02
        printL('directoryItems3-3 %r' % directoryItemsNoTitle)
        xbmcplugin.addDirectoryItems(HANDLE, directoryItemsNoTitle)
        if addSortMethods:
            xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_DATE)
            xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_TITLE)
        xbmcplugin.endOfDirectory(HANDLE)
  
    def playVideo(self, slug):
        self.updateRecentlyWatched(slug)
        item = self.api.getEpisode(slug)
        ###u'PrimaryAsset': {u'Kind': u'VideoResource', u'Target': u'Default', u'StartPublish': u'2019-01-24T21:24:52Z', u'Uri': u'https://www.dr.dk/mu-online/api/1.4/bar/5c45d4a36187a51250a0dac7'
        
        printL( 'drnu addon.py: \nself= %r\nslug= %r\nitem= %r' % (self,slug,item))
        if not 'PrimaryAsset' in item:
            self.displayError(ADDON.getLocalizedString(30904))
            return

        video = self.api.getVideoUrl(item[u'PrimaryAsset'][u'Uri'])
        printL('err FullScreen 0')
        ### fullscreen = xbmc.getCondVisibility('videoplayer.isfullscreen')
        fullscreen = xbmc.getCondVisibility('System.IsFullscreen')
        if not fullscreen:
            xbmc.executebuiltin("Action(togglefullscreen)")
        xbmc.executebuiltin("SetVolume(100,showvolumebar)")
        printL('err 1 FullScreen= %r' % fullscreen)
        xbmc.executebuiltin( "SetVolume(%s,showvolumebar)" % ( '100' ) )
        ###fullscreen = xbmc.getCondVisibility('videoplayer.isfullscreen')
        fullscreen = xbmc.getCondVisibility('System.IsFullscreen')
        printL('err 2 FullScreen= %r' % fullscreen)
        printL('video= %r' % video)
        try:
            Title = item['Title']
            OrgTitle = Title
            printL('TitleUTF-8= %r' % Title)
            Title = latin1_to_ascii_force(Title)   ### No UTF-8 in filename 
            printL('TitleNoUTF-8= %r' % Title)
            Title = Title.replace(':',';').replace('\\','-').replace('/','-').replace(',',';')
            printL('1 Title= %r' % Title)
        except Exception as e:
            pass
            Title = '%r - Error in Title: %r' % (Title,e)
        try:
            year = item['ProductionYear']
            if year > 1900:
                year = str(year)
            else:
                year = ''
            ###year = item['Year'] 
        except Exception as  e:
            pass
            #year = 'Error geting Year: ' + repr(e)
            year = ''
        try:
            description = item['Description'].replace('/n','NewLine').encode("utf-8")  ### 2017-01-28
        except Exception as  e:
            pass
            description = 'Error geting description/Plot: ' + repr(e)
        try:
            printL('item[PrimaryAsset][DurationInMilliseconds]= %r' % item['PrimaryAsset']['DurationInMilliseconds'])
            duration = str((item['PrimaryAsset']['DurationInMilliseconds'])/1000/60 +1)    ### 2019-01-24 add the last full minute
            duration = duration.split('.')[0]
            printL('duration= %r' % duration)
            durationH = int(int(duration)/60)
            durationM = (int(duration) - durationH*60)
            orgduration =  str(durationH) + 'h' + str(durationM).zfill(2) + 'm'
        except Exception as  e:
            pass
            orgduration = ''
            duration = 'Error geting duration: ' + repr(e)    
        itemX = xbmcgui.ListItem(path=video['Uri'])
        try:
            thumbnailImage=item['PrimaryImageUri']
            printL( 'thumbnailImage= %r' % thumbnailImage)
            itemX.setArt({ 'icon': thumbnailImage, 'thumb' : thumbnailImage })
        except Exception as e:
            pass
            thumbnailImage = None
            printL( 'thumbnailImage ERROR %r' % e)
        printL( 'video= %s' % repr(video).replace(',','###'))
        printL( 'URI= %s' % repr(video['Uri']))
        printL( repr(PATH))
        ADDON      = xbmcaddon.Addon()
        datapath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        playlist = os.path.join(datapath, 'DRarkiv') + '.m3u'
        if os.path.isfile(playlist ) == False: 
            LF = open(playlist , 'a')
            LF.write('#EXTM3U \n')
            LF.write(str(video['Uri']) + '\n')
        else:
            LF = open(playlist , 'a')
            LF.write(str(video['Uri']) + '\n')
        try:
            printL('duration= %r' % duration)
            durationVideo = '&duration='+duration
        except Exception as e:
            pass
            printL('Error in duration= %r\n%r' %(0,e))
            duration = ''
            durationVideo = ''
        try:
            if year == '' or year == '0':
                descriptionE = '&description='+description.decode()
            else:
                descriptionE = '&description='+year+': '+description.decode()
        except Exception as e:
            pass
            printL('Error in descriptionE= %r\n%r' %(e,description))
            descriptionE = ''
        printL('descriptionE= %r' %descriptionE)
        if video['SubtitlesUri']:  ### Previous used '+ str(slug).title()'
            descriptionE += '&subtitlesurl=' + video['SubtitlesUri'] + '&subtitlesoffset=0'
        printL('1 descriptionE= %r' %descriptionE)
        printL('3 Title= %r' % Title)
        printL('year= %r' % year)
        if not year in Title:
            Title += ' ' + year
            OrgTitle += ' ' + year
        OrgTitle = (OrgTitle +' ['+orgduration+']' + '[DR NU]')
        printL('err OrgTitle= %r' % OrgTitle)
        ###OrgTitleb64 = '&OrgTitle=b64' + base64.b64encode(OrgTitle)
        OrgTitleb64 = '&OrgTitle=' + base64b64encode(OrgTitle.encode())   ### 2021-03-05
        RecordingFromOtherAddon = ADDON.getSetting('enable.recording')
        if RecordingFromOtherAddon.lower() == 'true':
            RecordingFromOtherAddon = RecordFlagGet('')   ###ADDON.getSetting('RecordingFromOtherAddon')
            printL(repr(RecordingFromOtherAddon))
            printL(repr(ADDON))
            RecordFlagSet('','yyy') 
            printL('Reset RecordingFromOtherAddon to yyy')
            
            RecordingFromOtherAddon = RecordFlagGet('')
            printL('RecordingFromOtherAddon= %r' % RecordingFromOtherAddon)
            printL('ADDON= %r' % ADDON)
            recAddons = krogsbellAddonsSelect() 
            printL('1 recAddons= %r' % recAddons)
            tries    = 0
            maxTries = 10
            maxSleep = 500
            if recAddons != '':
                """
                printL('recAddons= %r' % recAddons)
                printL('Title= %r' % Title)
                printL('ADDONid= %r' % ADDONid)
                printL('orgduration= %r' % orgduration)
                printL('video[Uri]= %r' % video['Uri'])
                printL('descriptionE= %r' % descriptionE)
                printL('durationVideo= %r' % durationVideo)
                printL('OrgTitleb64= %r' % OrgTitleb64)
                printL('video[Uri]= %r' % video['Uri'])
                printL('base64b64encode(video[Uri] + descriptionE + durationVideo + OrgTitleb64)= %r' % base64b64encode(video['Uri'] + descriptionE + durationVideo + OrgTitleb64))
                """
                URI='plugin://' +recAddons+ '/?url=url&mode=2011&source=' + ADDONid + '&name=' + base64b64encode(Title + ' ['+ orgduration +']' + '[DR NU]') + '&uri=' + base64b64encode(video['Uri'] + descriptionE + durationVideo + OrgTitleb64)
                
                printL('drnu-->recorduri.py: URI= %r' % URI)

                try:
                    xbmc.executebuiltin('RunPlugin(%s)' % URI) 
                    xbmc.sleep(maxSleep)
                    
                    RecordingFromOtherAddon = RecordFlagGet('') 
                    ###printL('RecordingFromOtherAddon= %r Flag= %r' (ADDON,RecordingFromOtherAddon))
                except Exception as e:
                    pass 
                    printL('drnu-->recorduri.py ERROR %r' % e)
            
            printL('Play Video')
            if ADDON.getSetting('enable.subtitles') == 'true':
                if video['SubtitlesUri']:
                    itemX.setSubtitles([video['SubtitlesUri']])
            
            RecordingFromOtherAddon = RecordFlagGet('') 
            ###printL(RecordingFromOtherAddon)
            ###printL(repr(ADDON))
            ###printL(repr(tries))
      
            while RecordingFromOtherAddon != 'False' and RecordingFromOtherAddon != 'True' and tries < maxTries:
                try:
                    xbmc.sleep(maxSleep)
                    RecordingFromOtherAddon = RecordFlagGet('')   
                    ###printL(repr(RecordingFromOtherAddon))
                    ###printL(repr(ADDON))
                    ###printL(repr(tries))
                    if RecordingFromOtherAddon == 'False' or RecordingFromOtherAddon == 'True':
                        printL(repr('Break'))
                        break
                    else:
                        tries = tries + 1
                except Exception as e:
                    pass
                    printL(repr('Exception'))
                    printL(repr('e'))
                    RecordingFromOtherAddon = 'False' 
            printL('RecordingFromOtherAddon %r tries= %r' % (RecordingFromOtherAddon,tries))
            
            if RecordingFromOtherAddon == 'False' or tries >= maxTries:
                printL(repr('Play URI: ')+ repr(video['Uri']))
                xbmcplugin.setResolvedUrl(HANDLE, video['Uri'] is not None, itemX)
        else:
            printL(repr('Play URI: ')+ repr(video['Uri']))
            xbmcplugin.setResolvedUrl(HANDLE, video['Uri'] is not None, itemX)
    
    def parseDate(self, dateString):
        if dateString is not None:
            try:
                m = re.search('(\d+)-(\d+)-(\d+)T(\d+):(\d+):(\d+)', dateString)
                year = int(m.group(1))
                month = int(m.group(2))
                day = int(m.group(3))
                hours = int(m.group(4))
                minutes = int(m.group(5))
                seconds = int(m.group(6))
                return datetime.datetime(year, month, day, hours, minutes, seconds)
            except ValueError:
                return None
        else:
            return None
    
    def addFavorite(self, key):
        printL('addFavorite(self, key= %r)' % key)
        self._load()
        if not self.favorites.count(key):
            printL('append addFavorite(self, key= %r)' % key)
            self.favorites.append(key)
        self._save()

        xbmcgui.Dialog().ok(ADDON.getLocalizedString(30008), ADDON.getLocalizedString(30009))

    def delFavorite(self, key):
        self._load()
        if self.favorites.count(key):
            self.favorites.remove(key)
        self._save()
        xbmcgui.Dialog().ok(ADDON.getLocalizedString(30008), ADDON.getLocalizedString(30010))

    def updateRecentlyWatched(self, assetUri):
        self._load()
        if self.recentlyWatched.count(assetUri):
            self.recentlyWatched.remove(assetUri)
        self.recentlyWatched.insert(0, assetUri)
        self._save()

    def displayError(self, message='n/a'):
        heading = ADDONname
        line1 = ADDON.getLocalizedString(30900)
        line2 = ADDON.getLocalizedString(30901)
        xbmcgui.Dialog().ok(heading,line1+'\n'+line2+'\n'+message)

    def displayIOError(self, message='n/a'):
        heading = ADDONname
        line1 = ADDON.getLocalizedString(30902)
        line2 = ADDON.getLocalizedString(30903)
        xbmcgui.Dialog().ok(heading,line1+'\n'+line2+'\n'+message)

def latin1_to_ascii_force(unitext):
    """
2020-02-02 13:43:56 default.py: l TEST i= 127, str(j)= '\x7f'=, unicrap(j)= '\x7f'
2020-02-02 13:43:56 default.py: l TEST i= 128, str(j)= '\x80'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 129, str(j)= '\x81'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 130, str(j)= '\x82'=, unicrap(j)= 'Euro'
2020-02-02 13:43:56 default.py: l TEST i= 131, str(j)= '\x83'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 132, str(j)= '\x84'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 133, str(j)= '\x85'=, unicrap(j)= 'AA'
2020-02-02 13:43:56 default.py: l TEST i= 134, str(j)= '\x86'=, unicrap(j)= 'AE'
2020-02-02 13:43:56 default.py: l TEST i= 135, str(j)= '\x87'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 136, str(j)= '\x88'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 137, str(j)= '\x89'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 138, str(j)= '\x8a'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 139, str(j)= '\x8b'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 140, str(j)= '\x8c'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 141, str(j)= '\x8d'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 142, str(j)= '\x8e'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 143, str(j)= '\x8f'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 144, str(j)= '\x90'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 145, str(j)= '\x91'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 146, str(j)= '\x92'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 147, str(j)= '\x93'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 148, str(j)= '\x94'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 149, str(j)= '\x95'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 150, str(j)= '\x96'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 151, str(j)= '\x97'=, unicrap(j)= ''
2020-02-02 13:43:56 default.py: l TEST i= 152, str(j)= '\x98'=, unicrap(j)= 'OE'
2020-02-02 13:43:56 default.py: l TEST i= 153, str(j)= '\x99'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 154, str(j)= '\x9a'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 155, str(j)= '\x9b'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 156, str(j)= '\x9c'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 157, str(j)= '\x9d'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 158, str(j)= '\x9e'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 159, str(j)= '\x9f'=, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 160, str(j)= '\xa0'= , unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 161, str(j)= '\xa1'=¡, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 162, str(j)= '\xa2'=¢, unicrap(j)= 'c'
2020-02-02 13:43:57 default.py: l TEST i= 163, str(j)= '\xa3'=£, unicrap(j)= 'L'
2020-02-02 13:43:57 default.py: l TEST i= 164, str(j)= '\xa4'=¤, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 165, str(j)= '\xa5'=¥, unicrap(j)= 'Y'
2020-02-02 13:43:57 default.py: l TEST i= 166, str(j)= '\xa6'=¦, unicrap(j)= ':'
2020-02-02 13:43:57 default.py: l TEST i= 167, str(j)= '\xa7'=§, unicrap(j)= 's'
2020-02-02 13:43:57 default.py: l TEST i= 168, str(j)= '\xa8'=¨, unicrap(j)= '..'
2020-02-02 13:43:57 default.py: l TEST i= 169, str(j)= '\xa9'=©, unicrap(j)= 'c'
2020-02-02 13:43:57 default.py: l TEST i= 170, str(j)= '\xaa'=ª, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 171, str(j)= '\xab'=«, unicrap(j)= '<<'
2020-02-02 13:43:57 default.py: l TEST i= 172, str(j)= '\xac'=¬, unicrap(j)= '-'
2020-02-02 13:43:57 default.py: l TEST i= 173, str(j)= '\xad'=­, unicrap(j)= '-'
2020-02-02 13:43:57 default.py: l TEST i= 174, str(j)= '\xae'=®, unicrap(j)= 'R'
2020-02-02 13:43:57 default.py: l TEST i= 175, str(j)= '\xaf'=¯, unicrap(j)= '_'
2020-02-02 13:43:57 default.py: l TEST i= 176, str(j)= '\xb0'=°, unicrap(j)= 'deg'
2020-02-02 13:43:57 default.py: l TEST i= 177, str(j)= '\xb1'=±, unicrap(j)= '+/-'
2020-02-02 13:43:57 default.py: l TEST i= 178, str(j)= '\xb2'=², unicrap(j)= '^2'
2020-02-02 13:43:57 default.py: l TEST i= 179, str(j)= '\xb3'=³, unicrap(j)= '^3'
2020-02-02 13:43:57 default.py: l TEST i= 180, str(j)= '\xb4'=´, unicrap(j)= "'"
2020-02-02 13:43:57 default.py: l TEST i= 181, str(j)= '\xb5'=µ, unicrap(j)= 'm'
2020-02-02 13:43:57 default.py: l TEST i= 182, str(j)= '\xb6'=¶, unicrap(j)= 'pi'
2020-02-02 13:43:57 default.py: l TEST i= 183, str(j)= '\xb7'=·, unicrap(j)= '*'
2020-02-02 13:43:57 default.py: l TEST i= 184, str(j)= '\xb8'=¸, unicrap(j)= ''
2020-02-02 13:43:57 default.py: l TEST i= 185, str(j)= '\xb9'=¹, unicrap(j)= '^1'
2020-02-02 13:43:57 default.py: l TEST i= 186, str(j)= '\xba'=º, unicrap(j)= '^0'
2020-02-02 13:43:57 default.py: l TEST i= 187, str(j)= '\xbb'=», unicrap(j)= '>>'
2020-02-02 13:43:57 default.py: l TEST i= 188, str(j)= '\xbc'=¼, unicrap(j)= '1/4'
2020-02-02 13:43:57 default.py: l TEST i= 189, str(j)= '\xbd'=½, unicrap(j)= '1/2'
2020-02-02 13:43:57 default.py: l TEST i= 190, str(j)= '\xbe'=¾, unicrap(j)= '3/4'
2020-02-02 13:43:57 default.py: l TEST i= 191, str(j)= '\xbf'=¿, unicrap(j)= '?'
2020-02-02 13:43:57 default.py: l TEST i= 192, str(j)= '\xc0'=À, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 193, str(j)= '\xc1'=Á, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 194, str(j)= '\xc2'=Â, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 195, str(j)= '\xc3'=Ã, unicrap(j)= 'A'
2020-02-02 13:43:57 default.py: l TEST i= 196, str(j)= '\xc4'=Ä, unicrap(j)= 'AA'
2020-02-02 13:43:57 default.py: l TEST i= 197, str(j)= '\xc5'=Å, unicrap(j)= 'AA'
2020-02-02 13:43:57 default.py: l TEST i= 198, str(j)= '\xc6'=Æ, unicrap(j)= 'AE'
2020-02-02 13:43:57 default.py: l TEST i= 199, str(j)= '\xc7'=Ç, unicrap(j)= 'C'
2020-02-02 13:43:57 default.py: l TEST i= 200, str(j)= '\xc8'=È, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 201, str(j)= '\xc9'=É, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 202, str(j)= '\xca'=Ê, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 203, str(j)= '\xcb'=Ë, unicrap(j)= 'E'
2020-02-02 13:43:57 default.py: l TEST i= 204, str(j)= '\xcc'=Ì, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 205, str(j)= '\xcd'=Í, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 206, str(j)= '\xce'=Î, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 207, str(j)= '\xcf'=Ï, unicrap(j)= 'I'
2020-02-02 13:43:57 default.py: l TEST i= 208, str(j)= '\xd0'=Ð, unicrap(j)= 'Th'
2020-02-02 13:43:57 default.py: l TEST i= 209, str(j)= '\xd1'=Ñ, unicrap(j)= 'N'
2020-02-02 13:43:57 default.py: l TEST i= 210, str(j)= '\xd2'=Ò, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 211, str(j)= '\xd3'=Ó, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 212, str(j)= '\xd4'=Ô, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 213, str(j)= '\xd5'=Õ, unicrap(j)= 'O'
2020-02-02 13:43:57 default.py: l TEST i= 214, str(j)= '\xd6'=Ö, unicrap(j)= 'OE'
2020-02-02 13:43:57 default.py: l TEST i= 215, str(j)= '\xd7'=×, unicrap(j)= '*'
2020-02-02 13:43:57 default.py: l TEST i= 216, str(j)= '\xd8'=Ø, unicrap(j)= 'OE'
2020-02-02 13:43:57 default.py: l TEST i= 217, str(j)= '\xd9'=Ù, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 218, str(j)= '\xda'=Ú, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 219, str(j)= '\xdb'=Û, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 220, str(j)= '\xdc'=Ü, unicrap(j)= 'U'
2020-02-02 13:43:57 default.py: l TEST i= 221, str(j)= '\xdd'=Ý, unicrap(j)= 'Y'
2020-02-02 13:43:57 default.py: l TEST i= 222, str(j)= '\xde'=Þ, unicrap(j)= 'th'
2020-02-02 13:43:57 default.py: l TEST i= 223, str(j)= '\xdf'=ß, unicrap(j)= 'ss'
2020-02-02 13:43:57 default.py: l TEST i= 224, str(j)= '\xe0'=à, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 225, str(j)= '\xe1'=á, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 226, str(j)= '\xe2'=â, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 227, str(j)= '\xe3'=ã, unicrap(j)= 'a'
2020-02-02 13:43:57 default.py: l TEST i= 228, str(j)= '\xe4'=ä, unicrap(j)= 'ae'
2020-02-02 13:43:57 default.py: l TEST i= 229, str(j)= '\xe5'=å, unicrap(j)= 'aa'
2020-02-02 13:43:57 default.py: l TEST i= 230, str(j)= '\xe6'=æ, unicrap(j)= 'ae'
2020-02-02 13:43:57 default.py: l TEST i= 231, str(j)= '\xe7'=ç, unicrap(j)= 'c'
2020-02-02 13:43:57 default.py: l TEST i= 232, str(j)= '\xe8'=è, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 233, str(j)= '\xe9'=é, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 234, str(j)= '\xea'=ê, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 235, str(j)= '\xeb'=ë, unicrap(j)= 'e'
2020-02-02 13:43:57 default.py: l TEST i= 236, str(j)= '\xec'=ì, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 237, str(j)= '\xed'=í, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 238, str(j)= '\xee'=î, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 239, str(j)= '\xef'=ï, unicrap(j)= 'i'
2020-02-02 13:43:57 default.py: l TEST i= 240, str(j)= '\xf0'=ð, unicrap(j)= 'th'
2020-02-02 13:43:57 default.py: l TEST i= 241, str(j)= '\xf1'=ñ, unicrap(j)= 'n'
2020-02-02 13:43:57 default.py: l TEST i= 242, str(j)= '\xf2'=ò, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 243, str(j)= '\xf3'=ó, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 244, str(j)= '\xf4'=ô, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 245, str(j)= '\xf5'=õ, unicrap(j)= 'o'
2020-02-02 13:43:57 default.py: l TEST i= 246, str(j)= '\xf6'=ö, unicrap(j)= 'oe'
2020-02-02 13:43:57 default.py: l TEST i= 247, str(j)= '\xf7'=÷, unicrap(j)= '/'
2020-02-02 13:43:57 default.py: l TEST i= 248, str(j)= '\xf8'=ø, unicrap(j)= 'oe'
2020-02-02 13:43:57 default.py: l TEST i= 249, str(j)= '\xf9'=ù, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 250, str(j)= '\xfa'=ú, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 251, str(j)= '\xfb'=û, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 252, str(j)= '\xfc'=ü, unicrap(j)= 'u'
2020-02-02 13:43:57 default.py: l TEST i= 253, str(j)= '\xfd'=ý, unicrap(j)= 'y'
2020-02-02 13:43:57 default.py: l TEST i= 254, str(j)= '\xfe'=þ, unicrap(j)= 'th'
2020-02-02 13:43:57 default.py: l TEST i= 255, str(j)= '\xff'=ÿ, unicrap(j)= 'y'
N\xc3\xa5r st\xc3\xb8vet har lagt sig
N      å r st      ø vet har lagt sig 
S\xc3\xb8ren Ryge pr\xc3\xa6senterer
S      ø ren Ryge pr      æ senterer 
    """
    printL('latin1_to_ascii_force(unitext= %r)' % unitext)
    xc3flag = False
    xlatec3={0x82:'Euro', 0x85:'AA', 0x86:'AE', 0x98:'OE', 
        0xa0:'',
        0xa1:'', 0xa2:'c', 0xa3:'L', 0xa4:'ae',
        0xa5:'aa', 0xa6:'ae', 0xa7:'s', 0xa8:'..',
        0xa9:'e', 0xaa:'a', 0xab:'<<', 0xac:'-',
        0xad:'-', 0xae:'R', 0xaf:'_', 
        0xb0:'deg',
        0xb1:'+/-', 0xb2:'^2', 0xb3:'o', 0xb4:"'",
        0xb5:'m', 0xb6:'oe', 0xb7:'*', 0xb8:'oe',
        0xb9:'^1', 0xba:'^0', 0xbb:'>>', 
        0xbc:'1/4', 0xbd:'1/2', 0xbe:'3/4', 0xbf:'?',
        0xc0:'A', 0xc1:'A', 0xc2:'A', 0xc3:'', 0xc4:'AA', 0xc5:'AA',
        0xc6:'AE', 0xc7:'C',
        0xc8:'E', 0xc9:'E', 0xca:'E', 0xcb:'E',
        0xcc:'I', 0xcd:'I', 0xce:'I', 0xcf:'I',
        0xd0:'Th', 0xd1:'N',
        0xd2:'O', 0xd3:'O', 0xd4:'O', 0xd5:'O', 0xd6:'OE', 
        0xd7:'*', 
        0xd8:'OE',
        0xd9:'U', 0xda:'U', 0xdb:'U', 0xdc:'U',
        0xdd:'Y', 0xde:'th', 0xdf:'ss',
        0xe0:'a', 0xe1:'a', 0xe2:'a', 0xe3:'a', 0xe4:'ae', 0xe5:'aa',
        0xe6:'ae', 0xe7:'c',
        0xe8:'e', 0xe9:'e', 0xea:'e', 0xeb:'e',
        0xec:'i', 0xed:'i', 0xee:'i', 0xef:'i',
        0xf0:'th', 0xf1:'n',
        0xf2:'o', 0xf3:'o', 0xf4:'o', 0xf5:'o', 0xf6:'oe', 0xf7:'/', 0xf8:'oe',
        0xf9:'u', 0xfa:'u', 0xfb:'u', 0xfc:'u',
        0xfd:'y', 0xfe:'th', 0xff:'y',
        }
    xlate={0x82:'Euro', 0x85:'AA', 0x86:'AE', 0x98:'OE', 
        0xa0:'',
        0xa1:'', 0xa2:'c', 0xa3:'L', 0xa4:'o',
        0xa5:'aa', 0xa6:':', 0xa7:'s', 0xa8:'..',
        0xa9:'c', 0xaa:'a', 0xab:'<<', 0xac:'-',
        0xad:'-', 0xae:'R', 0xaf:'_', 
        0xb0:'deg',
        0xb1:'+/-', 0xb2:'^2', 0xb3:'o', 0xb4:"'",
        0xb5:'m', 0xb6:'pi', 0xb7:'*', 0xb8:'oe',
        0xb9:'^1', 0xba:'^0', 0xbb:'>>', 
        0xbc:'1/4', 0xbd:'1/2', 0xbe:'3/4', 0xbf:'?',
        0xc0:'A', 0xc1:'A', 0xc2:'A', 0xc3:'', 0xc4:'AA', 0xc5:'AA',
        0xc6:'AE', 0xc7:'C',
        0xc8:'E', 0xc9:'E', 0xca:'E', 0xcb:'E',
        0xcc:'I', 0xcd:'I', 0xce:'I', 0xcf:'I',
        0xd0:'Th', 0xd1:'N',
        0xd2:'O', 0xd3:'O', 0xd4:'O', 0xd5:'O', 0xd6:'OE', 
        0xd7:'*', 
        0xd8:'OE',
        0xd9:'U', 0xda:'U', 0xdb:'U', 0xdc:'U',
        0xdd:'Y', 0xde:'th', 0xdf:'ss',
        0xe0:'a', 0xe1:'a', 0xe2:'a', 0xe3:'a', 0xe4:'ae', 0xe5:'aa',
        0xe6:'ae', 0xe7:'c',
        0xe8:'e', 0xe9:'e', 0xea:'e', 0xeb:'e',
        0xec:'i', 0xed:'i', 0xee:'i', 0xef:'i',
        0xf0:'th', 0xf1:'n',
        0xf2:'o', 0xf3:'o', 0xf4:'o', 0xf5:'o', 0xf6:'oe', 0xf7:'/', 0xf8:'oe',
        0xf9:'u', 0xfa:'u', 0xfb:'u', 0xfc:'u',
        0xfd:'y', 0xfe:'th', 0xff:'y', 
        }
    r = ''
    printL('unitext= %r' % unitext)
    ###unitext = unitext.encode("utf-8")
    ###printL('unitext-utf-8= %r' % unitext)
    unitext = unitext.replace('\xef\xbb\xbf','')   ### Remove: byte order mark (BOM)
    printL('unitext-noBOM= %r' % unitext)
    for i in unitext:
        printL('i= %r, ord(i)= %r' %  (i,ord(i)))
        try:
            if ord(i) == 0xc3:
                xc3flag = True
            else:
                if xc3flag == True:
                    ###if xlatec3.has_key(ord(i)):
                    if ord(i) in xlatec3:
                        r += xlatec3[ord(i)]
                    elif ord(i) >= 0x80:
                        pass
                    else:
                        r += str(i)
                    xc3flag = False
                else:
                    ###if xlate.has_key(ord(i)):
                    if ord(i) in xlate:
                        r += xlate[ord(i)]
                    elif ord(i) >= 0x80:
                        pass
                    else:
                        r += str(i)
        except Exception as e:
            pass
            printL('latin1_to_ascii_force(unitext) ERROR= %r)' % e)
    printL('latin1_to_ascii_force(unitext-->r= %r)' % r)
    return r

if __name__ == '__main__':
    try:
        ###xbmc.executebuiltin('Dialog.Close(busydialog)')   ### 2019-06-27 needed to allow switch addon
        ADDON      = xbmcaddon.Addon()
        ADDONname  = ADDON.getAddonInfo('name')
        ADDONid    = ADDON.getAddonInfo('id')
        PATH = sys.argv[0]
        HANDLE = int(sys.argv[1])
        PARAMS = urlparse.parse_qs(sys.argv[2][1:])

        CACHE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("Profile"))
        if not os.path.exists(CACHE_PATH):
            os.makedirs(CACHE_PATH)

        FAVORITES_PATH = os.path.join(CACHE_PATH, 'favorites.pickle')
        FAVORITES_PATH_TXT = os.path.join(CACHE_PATH, 'favorites.txt')
        printL('FAVORITES_PATH= %r' % FAVORITES_PATH)
        RECENT_PATH = os.path.join(CACHE_PATH, 'recent.pickle')
        RECENT_PATH_TXT = os.path.join(CACHE_PATH, 'recent.txt')
        printL('RECENT_PATH= %r' % RECENT_PATH)
        FANART_IMAGE = os.path.join(ADDON.getAddonInfo('path'), 'fanart.jpg')

        ###buggalo.SUBMIT_URL = 'http://tommy.winther.nu/exception/submit.php'
        ###buggalo.addExtraData('cache_path', CACHE_PATH)
        drDkTvAddon = DrDkTvAddon()
        printL('PARAMS= %r' % PARAMS)
        if 'switch' in PARAMS:
            switch(PARAMS['switch'][0])
        elif 'show' in PARAMS:
            if PARAMS['show'][0] == 'liveTV':
                printL('liveTV')
                drDkTvAddon.showLiveTV()
            elif PARAMS['show'][0] == 'listAZ':
                printL('listAZ')
                drDkTvAddon.showAZ()
            elif PARAMS['show'][0] == 'latest':
                printL('latest')
                drDkTvAddon.listEpisodes(drDkTvAddon.api.getLatestPrograms(), addSortMethods=False)
            elif PARAMS['show'][0] == 'mostViewed':
                printL('mostViewed')
                drDkTvAddon.listEpisodes(drDkTvAddon.api.getMostViewed())
            elif PARAMS['show'][0] == 'highlights':
                printL('highlights')
                drDkTvAddon.listEpisodes(drDkTvAddon.api.getSelectedList())
            elif PARAMS['show'][0] == 'search':
                printL('search')
                drDkTvAddon.searchSeries()
            elif PARAMS['show'][0] == 'favorites':
                printL('favorites')
                drDkTvAddon.showFavorites()
            elif PARAMS['show'][0] == 'recentlyWatched':
                printL('recentlyWatched')
                drDkTvAddon.showRecentlyWatched()
            elif PARAMS['show'][0] == 'areaselector':
                printL('areaselector')
                drDkTvAddon.showAreaSelector()
            elif PARAMS['show'][0] == 'themes':
                printL('themes')
                drDkTvAddon.showThemes()

        elif 'listProgramSeriesByLetter' in PARAMS:
            drDkTvAddon.listSeries(drDkTvAddon.api.getSeries(PARAMS['listProgramSeriesByLetter'][0]))

        elif 'listVideos' in PARAMS:
            drDkTvAddon.listEpisodes(drDkTvAddon.api.getEpisodes(PARAMS['listVideos'][0]))

        elif 'playVideo' in PARAMS:
            drDkTvAddon.playVideo(PARAMS['playVideo'][0])

        elif 'addfavorite' in PARAMS:
            printL('addfavorite PARAMS= %r' % PARAMS)
            drDkTvAddon.addFavorite(PARAMS['addfavorite'][0])

        elif 'delfavorite' in PARAMS:
            drDkTvAddon.delFavorite(PARAMS['delfavorite'][0])

        else:
            try:
                area = int(ADDON.getSetting('area'))
            except:
                area = 0

            if area == 0:
                drDkTvAddon.showAreaSelector()
            elif area == 1:
                drDkTvAddon.showMainMenu()
            elif area == 2:
                items = drDkTvAddon.api.getChildrenFrontItems('dr-ramasjang')
                drDkTvAddon.listSeries(items)
            elif area == 3:
                items = drDkTvAddon.api.getChildrenFrontItems('dr-ultra')
                drDkTvAddon.listSeries(items)

    except tvapi.ApiException as ex:
        printL('tvapi.ApiException as ex= %r' % ex)
        drDkTvAddon.displayError(str(ex))

    except IOError as ex:
        printL('IOError as ex= %r' % ex)
        drDkTvAddon.displayIOError(str(ex))

    except Exception as ex:
        printL('Exception as ex= %r' % ex)
        ###buggalo.onExceptionRaised()

