import sys

from app import App
import utils

def log(message):
    module = 'default.py'
    utils.logdev(module,message)


app = App()
try:
    ###reload(sys)  
    ###sys.setdefaultencoding('utf8')
    log('defaultencoding= %r' % sys.getdefaultencoding())
    app.run()
except Exception as e:
    pass
    log('app.run failed: %r' % e)


