firstchannel=DRx
UPDATE channels SET weight = weight + 1000 WHERE weight < 1000
UPDATE channels SET weight = 0 WHERE id = 'DR1.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wozboxntv/?url=url&mode=200&name=DR+1+-+%5BCOLOR+green%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fcloud.yousee.tv%2Fstatic%2Fimg%2Flogos%2FLarge_DR_1.png&cat=147' WHERE id = 'DR1.dk' COLLATE NOCASE
UPDATE channels SET weight = 1 WHERE id = 'DR2.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wozboxntv/?url=url&mode=200&name=DR+2+-+%5BCOLOR+green%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fcloud.yousee.tv%2Fstatic%2Fimg%2Flogos%2FLarge_DR_2.png&cat=148' WHERE id = 'DR2.dk' COLLATE NOCASE
UPDATE channels SET weight = 2 WHERE id = 'DR3.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wozboxntv/?url=url&mode=200&name=DR+3+-+%5BCOLOR+green%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fcloud.yousee.tv%2Fstatic%2Fimg%2Flogos%2FLarge_DR_3.png&cat=259' WHERE id = 'DR3.dk' COLLATE NOCASE
UPDATE channels SET weight = 3 WHERE id = 'DRK.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wozboxntv/?url=url&mode=200&name=DR+K+-+%5BCOLOR+green%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fcloud.yousee.tv%2Fstatic%2Fimg%2Flogos%2FLarge_DR_K.png&cat=230' WHERE id = 'DRK.dk' COLLATE NOCASE
UPDATE channels SET weight = 4 WHERE id = 'TV2.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wozboxntv/?url=url&mode=200&name=TV+2+DK+-+%5BCOLOR+green%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fcloud.yousee.tv%2Fstatic%2Fimg%2Flogos%2FLarge_TV2_ny.png&cat=115' WHERE id = 'TV2.dk' COLLATE NOCASE
UPDATE channels SET weight = 5 WHERE id = 'TV2Charlie.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wozboxntv/?url=url&mode=200&name=TV+2+Charlie+-+%5BCOLOR+green%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fcloud.yousee.tv%2Fstatic%2Fimg%2Flogos%2FLarge_TV2Charlie.png&cat=137' WHERE id = 'TV2Charlie.dk' COLLATE NOCASE
UPDATE channels SET weight = 6 WHERE id = 'TV2fri.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wozboxntv/?url=url&mode=200&name=TV+2+Fri+-+%5BCOLOR+green%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fcloud.yousee.tv%2Fstatic%2Fimg%2Flogos%2FLarge_TV2Fri.png&cat=261' WHERE id = 'TV2fri.dk' COLLATE NOCASE
UPDATE channels SET weight = 7 WHERE id = 'TV3.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wozboxntv/?url=url&mode=200&name=TV+3+DK+-+%5BCOLOR+green%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fcloud.yousee.tv%2Fstatic%2Fimg%2Flogos%2FLarge_TV3.png&cat=140' WHERE id = 'TV3.dk' COLLATE NOCASE
UPDATE channels SET weight = 8 WHERE id = 'TV3Plus.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wozboxntv/?url=url&mode=200&name=TV+3+Plus+-+%5BCOLOR+green%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fcloud.yousee.tv%2Fstatic%2Fimg%2Flogos%2Flarge_tv3plus.png&cat=262' WHERE id = 'TV3Plus.dk' COLLATE NOCASE
UPDATE channels SET weight = 9 WHERE id = 'TV3Sport1.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wozboxntv/?url=url&mode=200&name=TV+3+Sport+1+-+%5BCOLOR+green%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fstatic.timefor.tv%2Fimgs%2Fepg%2Flogos%2Ftv3sport1_big.png&cat=93' WHERE id = 'TV3Sport1.dk' COLLATE NOCASE
UPDATE channels SET weight = 10 WHERE id = 'TV3Sport2.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wozboxntv/?url=url&mode=200&name=TV+3+Sport+2+-+%5BCOLOR+green%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fstatic.timefor.tv%2Fimgs%2Fepg%2Flogos%2Ftv3sport2_big.png&cat=237' WHERE id = 'TV3Sport2.dk' COLLATE NOCASE
UPDATE channels SET weight = 11 WHERE id = 'Eurosport.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wozboxntv/?url=url&mode=200&name=Eurosport+DK+-+%5BCOLOR+green%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fcloud.yousee.tv%2Fstatic%2Fimg%2Flogos%2FLarge_Eurosport_DK.png&cat=265' WHERE id = 'Eurosport.dk' COLLATE NOCASE
UPDATE channels SET weight = 12 WHERE id = 'Eurosport2.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wozboxntv/?url=url&mode=200&name=Eurosport+Denmark+-+%5BCOLOR+green%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fwozboxtv.com%2Fdownloads%2Fxmltv%2Flogos%2FEurosport%25202.png&cat=112' WHERE id = 'Eurosport2.dk' COLLATE NOCASE
UPDATE channels SET weight = 13 WHERE id = '6eren.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wozboxntv/?url=url&mode=200&name=6eren+-+%5BCOLOR+green%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fcloud.yousee.tv%2Fstatic%2Fimg%2Flogos%2FLarge_6eren.png&cat=235' WHERE id = '6eren.dk' COLLATE NOCASE
UPDATE channels SET weight = 14 WHERE id = 'Euronews.nws' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wozboxntv/?url=url&mode=200&name=Euronews+-+%5BCOLOR+green%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fwozboxtv.com%2Fdownloads%2Fxmltv%2Flogos%2FEuronews.png&cat=240' WHERE id = 'Euronews.nws' COLLATE NOCASE
UPDATE channels SET weight = 15 WHERE id = 'CMoreAction.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wozboxntv/?url=url&mode=200&name=C+More+Action+-+%5BCOLOR+green%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fntv.mx%2Fres%2Fntvsmall.png&cat=3938' WHERE id = 'CMoreAction.dk' COLLATE NOCASE
UPDATE channels SET weight = 16 WHERE id = 'CMoreEmotion.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wozboxntv/?url=url&mode=200&name=C+More+First+-+%5BCOLOR+green%5Dn+a%5B%2FCOLOR%5D&iconimage=https%3A%2F%2Fwww.boxer.se%2Fsiteassets%2Ftv%2Ftv-kanaler%2Fchannel-thumbnails%2Fchannel_logo_thumbnail_cmore_first.png&cat=300' WHERE id = 'CMoreEmotion.dk' COLLATE NOCASE
UPDATE channels SET weight = 17 WHERE id = 'CMoreFirst.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wozboxntv/?url=url&mode=200&name=C+More+First+-+%5BCOLOR+green%5Dn+a%5B%2FCOLOR%5D&iconimage=https%3A%2F%2Fwww.boxer.se%2Fsiteassets%2Ftv%2Ftv-kanaler%2Fchannel-thumbnails%2Fchannel_logo_thumbnail_cmore_first.png&cat=300' WHERE id = 'CMoreFirst.dk' COLLATE NOCASE
UPDATE channels SET weight = 18 WHERE id = 'CMoreHits.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wozboxntv/?url=url&mode=200&name=C+More+Hits+-+%5BCOLOR+green%5Dn+a%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fwww.tv-logo.com%2Fpt-data%2Fuploads%2Fimages%2Flogo%2Fc_more_hits.jpg&cat=299' WHERE id = 'CMoreFirst.dk' COLLATE NOCASE
UPDATE channels SET visible = 0 WHERE weight > 0
UPDATE channels SET visible = 1 WHERE weight < 19

