firstchannel=DRx
UPDATE channels SET weight = weight + 1000 WHERE weight < 1000
UPDATE channels SET weight = #lineno# WHERE id = 'DR1.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'http://dr01-lh.akamaihd.net/i/dr01_0@147054/master.m3u8?b=600-3000' WHERE id = 'DR1.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'DR2.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'http://dr02-lh.akamaihd.net/i/dr02_0@147055/master.m3u8?b=600-3000' WHERE id = 'DR2.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'DR3.dk' COLLATE NOCASE
UPDATE channels SET title = 'DR3' WHERE id = 'DR3.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'http://dr03-lh.akamaihd.net/i/dr03_0@147056/master.m3u8?b=600-3000' WHERE id = 'DR3.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'DRK.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'http://dr04-lh.akamaihd.net/i/dr04_0@147057/master.m3u8?b=600-3000' WHERE id = 'DRK.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'TV2.dk' COLLATE NOCASE
UPDATE channels SET title = 'TV2 DK' WHERE id = 'TV2.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wliptv/?url=url&mode=200&name=TV+2+DK+-+TV+2+DK&iconimage=http%3A%2F%2Fcloud.yousee.tv%2Fstatic%2Fimg%2Flogos%2FLarge_TV2_ny.png&cat=115' WHERE id = 'TV2.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'TV2Charlie.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wliptv/?url=url&mode=200&name=TV+2+Charlie+-+TV+2+Charlie&iconimage=http%3A%2F%2Fcloud.yousee.tv%2Fstatic%2Fimg%2Flogos%2FLarge_TV2Charlie.png&cat=137' WHERE id = 'TV2Charlie.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'TV2Zulu.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wliptv/?url=url&mode=200&name=TV+2+Zulu+-+TV+2+Zulu&iconimage=http%3A%2F%2Fcloud.yousee.tv%2Fstatic%2Fimg%2Flogos%2FLarge_CVI_TV2Zulu.png&cat=138' WHERE id = 'TV2Zulu.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'TV2fri.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wliptv/?url=url&mode=200&name=TV+2+Fri+-+TV+2+Fri&iconimage=http%3A%2F%2Fcloud.yousee.tv%2Fstatic%2Fimg%2Flogos%2FLarge_TV2Fri.png&cat=261' WHERE id = 'TV2fri.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'TV3.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wliptv/?url=url&mode=200&name=TV+3+DK+-+TV+3+DK&iconimage=http%3A%2F%2Fcloud.yousee.tv%2Fstatic%2Fimg%2Flogos%2FLarge_TV3.png&cat=140' WHERE id = 'TV3.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'TV3Plus.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wliptv/?url=url&mode=200&name=TV+3+Plus+-+TV+3+Plus&iconimage=http%3A%2F%2Fcloud.yousee.tv%2Fstatic%2Fimg%2Flogos%2Flarge_tv3plus.png&cat=262' WHERE id = 'TV3Plus.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'SkySportsF1.uk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wliptv/?url=url&mode=200&name=Sky+Sports+F1+-+Sky+Sports+F1&iconimage=http%3A%2F%2Fwozboxtv.com%2Fdownloads%2Fxmltv%2Flogos%2FSky%2520Sports%2520F1.png&cat=42' WHERE id = 'SkySportsF1.uk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'TV3Sport1.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wliptv/?url=url&mode=200&name=TV+3+Sport+1+-+TV+3+Sport+1&iconimage=http%3A%2F%2Fstatic.timefor.tv%2Fimgs%2Fepg%2Flogos%2Ftv3sport1_big.png&cat=93' WHERE id = 'TV3Sport1.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'TV3Sport2.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wliptv/?url=url&mode=200&name=TV+3+Sport+2+-+TV+3+Sport+2&iconimage=http%3A%2F%2Fstatic.timefor.tv%2Fimgs%2Fepg%2Flogos%2Ftv3sport2_big.png&cat=237' WHERE id = 'TV3Sport2.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'Eurosport.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wliptv/?url=url&mode=200&name=Eurosport+DK+-+Eurosport+DK&iconimage=http%3A%2F%2Fcloud.yousee.tv%2Fstatic%2Fimg%2Flogos%2FLarge_Eurosport_DK.png&cat=265' WHERE id = 'Eurosport.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'Eurosport2.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wliptv/?url=url&mode=200&name=Eurosport+Denmark+-+Eurosport+Denmark&iconimage=http%3A%2F%2Fwozboxtv.com%2Fdownloads%2Fxmltv%2Flogos%2FEurosport%25202.png&cat=112' WHERE id = 'Eurosport2.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = '6eren.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wliptv/?url=url&mode=200&name=6eren+-+6eren&iconimage=http%3A%2F%2Fcloud.yousee.tv%2Fstatic%2Fimg%2Flogos%2FLarge_6eren.png&cat=235' WHERE id = '6eren.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'Euronews.nws' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wliptv/?url=url&mode=200&name=Euronews+-+Euronews&iconimage=http%3A%2F%2Fwozboxtv.com%2Fdownloads%2Fxmltv%2Flogos%2FEuronews.png&cat=240' WHERE id = 'Euronews.nws' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'CMoreAction.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wliptv/?url=url&mode=200&name=C+More+Action+-+C+More+Action&iconimage=http%3A%2F%2Fntv.mx%2Fres%2Fntvsmall.png&cat=3938' WHERE id = 'CMoreAction.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'CMoreFirst.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wliptv/?url=url&mode=200&name=C+More+First+-+C+More+First&iconimage=https%3A%2F%2Fwww.boxer.se%2Fsiteassets%2Ftv%2Ftv-kanaler%2Fchannel-thumbnails%2Fchannel_logo_thumbnail_cmore_first.png&cat=300' WHERE id = 'CMoreFirst.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'CMoreHits.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wliptv/?url=url&mode=200&name=C+More+Hits+-+C+More+Hits&iconimage=http%3A%2F%2Fwww.tv-logo.com%2Fpt-data%2Fuploads%2Fimages%2Flogo%2Fc_more_hits.jpg&cat=299' WHERE id = 'CMoreHits.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'CMoreSeries.dk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wliptv/?url=url&mode=200&name=C+More+Series+-+C+More+Series&iconimage=https%3A%2F%2Fwww.boxer.se%2Fsiteassets%2Ftv%2Ftv-kanaler%2Fchannel-thumbnails%2Fchannel_logo_thumbnail_cmore_series.png&cat=293' WHERE id = 'CMoreSeries.dk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'BBCOneHD.uk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wliptv/?url=url&mode=200&name=BBC+One+HQ+-+BBC+One+HQ&iconimage=http%3A%2F%2Fwozboxtv.com%2Fdownloads%2Fxmltv%2Flogos%2FBBC%2520One%2520HD.png&cat=1261' WHERE id = 'BBCOneHD.uk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'BBC2.uk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wliptv/?url=url&mode=200&name=BBC+Two+HQ+-+BBC+Two+HQ&iconimage=http%3A%2F%2Fwozboxtv.com%2Fdownloads%2Fxmltv%2Flogos%2FBBC%2520Two%2520HD.png&cat=1262' WHERE id = 'BBC2.uk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'ITV1London.uk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wliptv/?url=url&mode=200&name=ITV+1+HQ+-+ITV+1+HQ&iconimage=http%3A%2F%2Fwozboxtv.com%2Fdownloads%2Fxmltv%2Flogos%2FITV%2520HD.png&cat=1263' WHERE id = 'ITV1London.uk' COLLATE NOCASE
UPDATE channels SET weight = #lineno# WHERE id = 'ITV2.uk' COLLATE NOCASE
UPDATE channels SET stream_url = 'plugin://plugin.video.wliptv/?url=url&mode=200&name=ITV+2+-+ITV+2&iconimage=http%3A%2F%2Fwozboxtv.com%2Fdownloads%2Fxmltv%2Flogos%2FITV2.png&cat=29' WHERE id = 'ITV2.uk' COLLATE NOCASE
UPDATE channels SET visible = 0 WHERE weight > 0
UPDATE channels SET visible = 1 WHERE weight < #lineno#

