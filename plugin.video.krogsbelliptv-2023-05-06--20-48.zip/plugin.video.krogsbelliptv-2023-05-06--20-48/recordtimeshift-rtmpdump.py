#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs,os
import datetime
import time
import utils, recordings
import net
from hashlib import md5
import json

#ADDON      = xbmcaddon.Addon(id='plugin.video.wozboxntv')
import definition
ADDON      = definition.getADDON()
timeshiftfilename = 'timeshift'
#xbmc.log('recordtimeshift.py: sys.argv= %s' %(str(repr(sys.argv))))
try:
	program  = sys.argv[0]
	uri           = sys.argv[1].replace('AAabBB',' ').replace('aAabBb','?').replace('BBabAA','=')
	title         = sys.argv[2]
except:
	pass
	title = 'TimeShift'
try:
	xbmc.log('recordtimeshift.py: os.environ= %s' % os.environ['OS'] ) #put in LOG
except: pass

timeshiftsetting = utils.ADDONgetSetting('timeshift')
#print timeshiftsetting
#utils.notification('TimeShift Setting = ' + repr(timeshiftsetting))
if timeshiftsetting == '0':
	#utils.notification('TimeShift %s [COLOR red]NOT enabled[/COLOR]' % (title))
	utils.notificationbox('TimeShift %s [COLOR red]NOT enabled[/COLOR]' % (title))

else:

	LoopCountMax = int(utils.ADDONgetSetting('LoopCount'))

	rtmpdumpEXEp = utils.rtmpdumpFilename()
	rtmpdumpEXE = os.path.join(utils.ADDONgetAddonInfo('path'),'rtmpdump',rtmpdumpEXEp)
	xbmc.log('recordtimeshift.py: stats os.F_OK: %s' % os.access(rtmpdumpEXE, os.F_OK))
	xbmc.log('recordtimeshift.py: stats os.W_OK: %s' % os.access(rtmpdumpEXE, os.W_OK))
	xbmc.log('recordtimeshift.py: stats os.X_OK: %s' % os.access(rtmpdumpEXE, os.X_OK))
	#xbmc.log('1')
	if not xbmc.getCondVisibility('system.platform.windows'):
		if os.access(rtmpdumpEXE, os.X_OK):
			print 'Permissions ------ 0777 ----- GREAT !!'  # Put in LOG
		else:
			print 'Permissions -----------------   BAD !!'  # Put in LOG
			for dirpath, dirnames, filenames in os.walk(os.path.join(utils.ADDONgetAddonInfo('path'),'rtmpdump')):
				for filename in filenames:
					path = os.path.join(dirpath, filename)
					try:
						os.chmod(path, 0o777)
						print 'Permissions set with: CHMOD 0777 !!'  # Put in LOG
					except: pass
	if os.access(rtmpdumpEXE, os.X_OK):
		RecordingDisabled = False
	else:
		time.sleep(1)
		utils.notification('Recording %s [COLOR red]NOT possible! Set this program executable:[/COLOR] %s' % (title,rtmpdumpEXE))
		time.sleep(1000)
		RecordingDisabled = True
	recordPath = xbmcvfs.translatePath(os.path.join(utils.ADDONgetSetting('record_path')))
	if not utils.folderwritable(recordPath):
		utils.notification('Recording %s [COLOR red]FAILED - You must set the recording path writable![/COLOR]' % title)
	else:
		if xbmc.getCondVisibility('system.platform.linux'):
		    for dirpath, dirnames, filenames in os.walk(os.path.join(utils.ADDONgetAddonInfo('path'),'rtmpdump')):
			for filename in filenames:
			    path = os.path.join(dirpath, filename)
			    os.chmod(path, 0o777)
		datapath = xbmcvfs.translatePath(utils.ADDONgetAddonInfo('profile'))
		nowHM=datetime.datetime.today().strftime('%H:%M:%S')
		rtmp  = uri.replace('xXx',' ').replace('###',',')
		cmd  =  os.path.join(utils.ADDONgetAddonInfo('path'),'rtmpdump', utils.rtmpdumpFilename())
		cmdoption = ' -V '
		quality = utils.ADDONgetSetting('os')
		cmd += cmdoption + ' -i "' + rtmp + '"'
		cmd += ' -o '
		filetitle = recordings.latin1_to_ascii_force(timeshiftfilename)
		filetitle = filetitle.replace('?', '')
		filetitle = filetitle.replace(':', ' -')
		filetitle = filetitle.replace('/', '')
		filetitle = filetitle.replace('+', '')
		filetitle = filetitle.replace('\\', '')
		filetitle = re.sub('[,:\\/*?\<>|"]+', '', filetitle)
		filetitle = " ".join(filetitle.split())  # Remove extra spaces from filename
		source = ''
		cmd += '"' + recordPath + filetitle + '.flv"'
		timeshiftfile = recordPath + filetitle + '.flv'
		utils.ADDONsetSetting('timeshiftfile',timeshiftfile)
		xbmc.log( 'recordtimeshift: cmd= %s' % repr(cmd))
		nowHM=datetime.datetime.today().strftime('%H:%M')
		if not RecordingDisabled:
			utils.log('TimeShift', 'Recording %s [COLOR green]started %s[/COLOR]' % (title, nowHM))
		
		if utils.ADDONgetSetting('os')=='11':
			utils.runCommand(cmd, LoopCount=0, libpath=None)
		else:
			libpath = utils.libPath()
			utils.runCommand(cmd, LoopCount=0, libpath=libpath)

		if not RecordingDisabled:
			nowHM=datetime.datetime.today().strftime('%H:%M')
			utils.log('TimeShift', 'Recording %s [COLOR red]complete[/COLOR] %s' % (title, nowHM))
