#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmcaddon,xbmc,xbmcvfs,xbmcgui,os,shutil
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)

# 0= NTV.mx, 1= WOZBOX www.wozboxtv.com, 2=www.myindian.tv, 3=www.wliptv.com, 4=roq-tv.com, 5=www.ace-tv.co.uk
# Copy the addon folder to the name of the id to copy addon to, update addon.xml and add the jpg and png icons to be used with the addon then make a zip file and install from zip!

referral= 0   ### 8 ###<===  GlowIPTV         ##########################<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
###values="NTV|WOZBOX (www.wozboxtv.com)|My Indian TV|White Label Spain (http://www.wliptv.com)|ROQ TV Rec|ACE TV Rec|ACE TV Rec Experimental|Premium IPTV (Premiumiptv.co)


BASEURL = ''
COMMAND = ''
COMMANDEND = ''
REGISTRATION = ''
###REFERRALNAME = ''   ### 2023-08-12
###REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'   ### 2023-08-12
DEFAULTSTREAMTYPE = ''
PLAYURL = ''  ### Not used after 2019-03-25
module = 'definition.py'

def log(infotext,showlength=1024):
    logtext = ADDONgetSetting('basicuserinfoerror')
    logtext = infotext + ' ¤ ' + logtext
    ADDONsetSetting('basicuserinfoerror', logtext[0:showlength])

def nowTS():   ### Local time
    dt_obj= datetime.now()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
   
def nowutcTS():   ### UTC time
    dt_obj= datetime.utcnow()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
    
def timeZone():
    tz = (nowTS() - nowutcTS())//3600
    return tz
    
def DaylightSaving():
    dialog = xbmcgui.Dialog()
    if dialog.yesno(ADDONgetAddonInfo('name'), "[COLOR red]Are you using daylight saving[/COLOR]", '', "What Do You Want To Do","[COLOR red]Use Daylight Saving[/COLOR]","[COLOR green]No[/COLOR]"):
        ### No
        return False
    else:
        ### Yes
        return True
        
def Numeric(name,default):
    dialog = xbmcgui.Dialog()
    keyboard=dialog.numeric(0, 'Please Enter '+str(name),default)
    if keyboard:
        if keyboard[0:1] == '0':
            keyboard = str(0-int(keyboard))
    return keyboard
    
### xbmcgui.Dialog().browse(type, heading, shares[, mask, useThumbs, treatAsFolder, defaultt, enableMultiple])
def getFile(name,default):
    dialog = xbmcgui.Dialog()
    file = dialog.browse(1, 'Please Enter '+str(name), '', defaultt=default)
    return file
    
def Parameter(ADDON,name,parameter):
    VALUE = ADDON.getSetting(parameter)
    if VALUE == 'Not Set' and parameter == 'my_referral_name':
        VALUE = ADDON.getSetting(parameter)
        if VALUE == 'Krogsbell_IPTV':
            VALUE = ADDON.getAddonInfo('name')
    if VALUE == '' and parameter == 'my_referral_name':
        VALUE = ADDON.getAddonInfo('name')
        if VALUE == '':
            VALUE = 'Krogsbell_IPTV'
    newVALUE = Search(name,VALUE)
    ADDON.setSetting('parameter',str(VALUE) + '-->' + str(newVALUE))
    if newVALUE == '' and parameter == 'my_referral_name':
        newVALUE = ADDON.getAddonInfo('name')
        if newVALUE == '':
            newVALUE = 'Krogsbell_IPTV'
    if newVALUE:
        ADDON.setSetting(parameter,newVALUE)
    return newVALUE
    
def Search(name,search_entered):
    keyboard = xbmc.Keyboard(search_entered, '[COLOR lightgreen][B]Please Enter '+str(name)+'[/B][CR][COLOR grey][I]<ESC> or Cancel to clear[/I][/COLOR]')
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_entered = keyboard.getText()
        if search_entered == None:
            return False 
    else:
        return False
    return search_entered 

def ADDONgetAddonInfo(info):
    file = os.path.join(datapath,'ADDON-' + info) + '.set'
    if os.path.isfile(file) == False:
        value = ADDON.getAddonInfo(info)
        LF = open(file, 'w')
        LF.write(value)
        LF.close()
    else:
        LF = open(file,'r')
        value = LF.read()
    return value
   
def ADDONsetSetting(setting,value):
    ADDON.setSetting(setting,value)
    file = os.path.join(datapath,'ADDONsetting-'+setting) + '.set'
    LF = open(file, 'w')
    LF.write(value)
    LF.close()
    
def ADDONgetSetting(setting):
    file = os.path.join(datapath,'ADDONsetting-'+setting) + '.set'
    if os.path.isfile(file) == False:
        value = ADDON.getSetting(setting)
        ADDONsetSetting(setting,value)
    LF = open(file,'r')
    try:
        value = LF.read()
    except Exception as e:
        pass
        log('error ADDONgetSetting Exception %r' % e)
        LF = open(file,'rb')
        valueb = LF.read()
        try:
            value = valueb.decode('utf8')
        except Exception as e:
            pass
            log('error ADDONgetSetting Exception %r' % e)
            value = 'Error getting setting: %r' % setting
    ADDONsetSetting(setting,value)
    if setting == 'record_path' or setting == 'record_archive_path' or setting == 'record_archiveb_path' or setting == 'sharepath' or setting == 'tvguideimport' :  ### 2023-03-10
        log('error FileManagerPath 0(value= %r)' % value)
        value = FileManagerPath(value)
        log('error FileManagerPath 1(value= %r)' % value)
    return value

if referral==0:
    ADDON = xbmcaddon.Addon(id='plugin.video.krogsbelliptv-2023-12-30--14-57')
    datapath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not xbmcvfs.exists(datapath):
        xbmcvfs.mkdir(datapath)
    ADDONsetSetting('addon_program_path',ADDONgetAddonInfo('path'))
    ADDONsetSetting('versionofsetting',ADDONgetAddonInfo('version'))
    BASEURLlast = ADDONgetSetting('BASEURLlast')
    log('err BASEURLlast= %r' % BASEURLlast)
    BASEURL = ADDONgetSetting('BASEURL')
    log('err BASEURL= %r' % BASEURL)
    if BASEURLlast != BASEURL :
        ADDONsetSetting('BASEURLlast',BASEURL)
        log('err BASEURLlast changed to= %r' % BASEURL)
    l=0
    log('100 %r' % l)
    
    log('timeZone= %r' % timeZone())
    TIMEZONE = str(timeZone())
    ADDONsetSetting('TIMEZONE',TIMEZONE)
    log('setSetting(TIMEZONE= %r' % TIMEZONE)
    ADDONsetSetting('AdjustTVguideTimeZoneOffset',TIMEZONE)
    log('setSetting(AdjustTVguideTimeZoneOffset= %r' % TIMEZONE)
    ###ADDONsetSetting('archiveoffset','0')  ### Archive uses GMT 2019-03-30
    ADDONsetSetting('AdjustTVguideTimeZoneOffsetExtraXML',TIMEZONE)
    log('setSetting(AdjustTVguideTimeZoneOffsetExtraXML= %r' % TIMEZONE)
    log('err BASEURL= %r' % BASEURL)
    allownamechange = ADDONgetSetting('allownamechange') 
    if allownamechange.lower() == 'true' :   ### 2022-10-26 set user automatically if allowed
        if not 'http://' in BASEURL and not 'https://' in BASEURL:
            try:
                log('try %r' % l)
                my_referral_name = Parameter(ADDON,'Addon Name','my_referral_name')
                log('my_referral_name= %r' % my_referral_name)
                my_referral_registration = Parameter(ADDON,'IPTV Registred at','my_referral_registration')
                log('my_referral_registration= %r' % my_referral_registration)
                basicuserinfo = ADDONgetSetting('basicuserinfo')
                log('basicuserinfo= %r' % basicuserinfo)
                if 'none.txt' in basicuserinfo:
                    basicuserinfo = os.path.join(ADDONgetAddonInfo('path'), 'none.txt')
                ### basicuserinfo = Parameter(ADDON,'Your Connection Details Text File','basicuserinfo')
                ### http://<url>/get.php?username=<>&password=<>&type=m3u_plus&output=ts
                log('2 basicuserinfo= %r' % basicuserinfo)
                basicuserinfo = getFile('Your Connection Details Text File or none',basicuserinfo)
                log('3 basicuserinfo= %r' % basicuserinfo)
                ADDONsetSetting('basicuserinfo',basicuserinfo)
                
                ChannelFile = ADDONgetSetting('directchannelsfromextraXMLTVfile')
                if os.path.isfile(ChannelFile):
                    directchannelsdef = ChannelFile
                else:
                    directchannelsdef = os.path.join(ADDONgetAddonInfo('path'), 'directchannels.m3u.txt')
                directchannels    = getFile('Your Direct Channels m3u File or keep last',directchannelsdef)
                datapath = xbmcvfs.translatePath(ADDONgetAddonInfo('profile'))
                if os.path.isfile(directchannels) and directchannels != directchannelsdef:
                    directchannelsdata = os.path.join(datapath,'directchannels.m3u')
                    ADDONsetSetting('directchannelsfromextraXMLTVfile',directchannelsdata)
                    shutil.copyfile(directchannels, directchannelsdata)
                else:
                    try:
                        ADDONsetSetting('directchannelsfromextraXMLTVfile','')
                        os.remove(os.path.join(datapath,'directchannels.m3u'))
                    except:
                        pass
                
                file = open(basicuserinfo,'r')
                desc = file.read()
                file.close()
                basicuserinfo = desc
                l=1
                log('152 %r' % l)
                if basicuserinfo:
                    if basicuserinfo.lower().replace('\n','').replace('\r','').replace("'",'') == 'none':
                        basicuserinfo = 'http://none.none:80/get.php?username=none&password=none&type=m3u_plus&output=ts'
                    basicuserinfo = basicuserinfo.replace('&amp;','&')
                    l=2
                    log('158 %r' % l)
                    ADDONsetSetting('AAA','basicuserinfo= %r' % basicuserinfo)
                    if 'http://' in basicuserinfo.lower():
                        l=3
                        log('162 %r' % l)
                        server = basicuserinfo.split('http://',1)[1]
                    else:
                        l=4
                        log('166 %r' % l)
                        server = basicuserinfo.split('https://',1)[1]
                    l=5
                    log('169 %r' % l)
                    BASEURL = server.split('/')[0]
                    l=6
                    log('172 %r' % l)
                    """
                    if BASEURL != BASEURLlast: 
                        l=7
                        log('176 %r' % l)
                        ### Reset DB and timezones
                        ADDON.setSetting('BASEURLchanged','true')
                        log('179 %r' % timeZone())
                        TIMEZONE = str(timeZone())
                        ADDON.setSetting('TIMEZONE',TIMEZONE)
                        ADDON.setSetting('AdjustTVguideTimeZoneOffset',TIMEZONE)
                        ADDON.setSetting('archiveoffset','0')  ### Archive uses GMT 2019-03-30
                        ADDON.setSetting('AdjustTVguideTimeZoneOffsetExtraXML',TIMEZONE)
                    
                        ¤¤¤
                        d = datetime.now()
                        #get month number
                        mo = int(d.strftime("%m"))
                        NoDST = ADDON.getSetting('AdjustTVguideTimeZoneOffsetExtraXMLNoDST')
                        if NoDST == '':
                            NoDST = 0
                        else:
                            NoDST = int(NoDST)
                        DST = ADDON.getSetting('AdjustTVguideTimeZoneOffsetExtraXML')
                        if DST == '':
                            DST = 0
                        else:
                            DST = int(DST)
                        if mo < 6:
                            EPGoffset = NoDST + 1
                        else:
                            EPGoffset = NoDST
                        ADDON.setSetting('AdjustTVguideTimeZoneOffsetExtraXML',str(EPGoffset)) 
                                
                        ### Summertime?  - negative timezone?
                        DAYLIGHTSAVINGold = ADDON.getSetting('DAYLIGHTSAVING')
                        if DaylightSaving():
                            DAYLIGHTSAVING = 1
                        else:
                            DAYLIGHTSAVING = 0
                        TIMEZONE = ADDON.getSetting('TIMEZONE')
                        TIMEZONE = Numeric('Your Time Zone offset - UK=0 - negative start with zero',TIMEZONE)
                        if TIMEZONE:
                            l=8
                            ADDON.setSetting('TIMEZONE',str(TIMEZONE))
                            ADDON.setSetting('AdjustTVguideTimeZoneOffset',str(int(TIMEZONE)+DAYLIGHTSAVING))
                            ADDON.setSetting('archiveoffset','0')  ### Archive uses GMT 2019-03-30
                            ADDON.setSetting('AdjustTVguideTimeZoneOffsetExtraXML',str(int(TIMEZONE)+DAYLIGHTSAVING))
                   
                    else:
                        l=9
                        log('223 %r' % l)
                        ADDON.setSetting('BASEURLchanged','false')
                    """
                    l=10
                    log('227 %r' % l)
                    command = server.replace(BASEURL,'',1)
                    BASEURL = 'http://' + BASEURL
                    COMMAND = command.split('username=',1)[0]
                    
                    l=11
                    log('233 %r' % l)
                    username = command.split('username=',1)[1].split('&',1)[0]
                    l=12
                    log('236 %r' % l)
                    password = command.split('password=',1)[1].split('&',1)[0]
                    l=13
                    log('239 %r' % l)
                    COMMANDEND = '&type=' + command.split('&type=',1)[1]
                    ADDONsetSetting('COMMAND',COMMAND)
                    ADDONsetSetting('COMMANDEND',COMMANDEND)
                    if BASEURL != '' and username != '' and password != '':
                        l=14
                        log('245 %r' % l)
                        ADDONsetSetting('BASEURL',BASEURL)
                        ADDONsetSetting('user',str(username))
                        ADDONsetSetting('pass',str(password))
            except Exception as e:
                pass
                ADDONsetSetting('basicuserinfoerror', 'l= %r, ERROR= %r' % (l,e))
        else:
            BASEURL = ADDONgetSetting('BASEURL').replace('&amp;','&')
            COMMAND = ADDONgetSetting('COMMAND').replace('&amp;','&')
            COMMANDEND = ADDONgetSetting('COMMANDEND').replace('&amp;','&')
        REFERRALNAME = ADDONgetSetting('Addon Name')
        REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'
        DEFAULTSTREAMTYPE = 'live'
    
elif referral==1:
    ADDON = xbmcaddon.Addon(id='plugin.video.wozboxntv')
    BASEURL = 'http://www.ntv.mx'
    REGISTRATION = 'wozboxtv.com/registration'
    REFERRALNAME = 'WOZBOX (www.wozboxtv.com)'
    REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'
    
elif referral==2:
    ADDON = xbmcaddon.Addon(id='plugin.video.myindian')
    BASEURL = 'http://www.myindian.tv'
    REGISTRATION = 'http://www.myindian.tv'
    REFERRALNAME = 'My Indian TV'
    REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'
    
elif referral==3:
    ADDON = xbmcaddon.Addon(id='plugin.video.wliptv')
    BASEURL = 'http://www.wliptv.com'
    REGISTRATION = 'http://www.wliptv.com'
    REFERRALNAME = 'White Label Spain (http://www.wliptv.com)'
    REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'
    
elif referral==4:
    ADDON = xbmcaddon.Addon(id='plugin.video.roqtv.rec')
    ###BASEURL = 'http://roq-tv.net:25461'
    BASEURL = 'http://www.roq-tv.net:80'
    PLAYURL = 'http://clic-tv.org:80'
    COMMAND = '/panel_api.php?'
    COMMANDEND = '&type=m3u_plus&output=m3u8'
    REGISTRATION = 'http://roq-tv.com'
    REFERRALNAME = 'ROQ TV Rec'
    REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'

elif referral==5:
    ADDON = xbmcaddon.Addon(id='plugin.video.acetvrec')
    BASEURL = 'http://ace-tv.xyz:25461'
    REGISTRATION = 'http://www.ace-tv.co.uk'
    REFERRALNAME = 'ACE TV Rec'
    REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'

elif referral==6:
    ###ADDON = xbmcaddon.Addon(id='plugin.video.acetvrec')
    ADDON = xbmcaddon.Addon(id='plugin.video.roqtvrec')
    ###BASEURL = 'http://ace-tv.xyz:25461'
    BASEURL = 'http://ace-tv.xyz:8080'
    ###BASEURL = 'http://ace.nothingtosee.xyz:8080'   ### TEST 2017-11-23
    REGISTRATION = 'http://www.ace-tv.co.uk'
    REFERRALNAME = 'ACE TV Rec Experimental'
    REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'
    
elif referral==7:
    ###http://tv.premium.iptv.uno:8080/get.php?username=xxxx&password=xxxx&type=m3u_plus&output=m3u8
    ADDON = xbmcaddon.Addon(id='plugin.video.premiumiptv.rec')
    BASEURL = 'http://tv.premium.iptv.uno:8080'
    COMMAND = 'get.php?'
    COMMANDEND = '&type=m3u_plus&output=m3u8'
    REGISTRATION = 'http://www.premiumiptv.co'
    REFERRALNAME = 'Premium IPTV (Premiumiptvco.com)'
    REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'

elif referral==8:
    ###http://tv.glowiptv.iptv.uno:8080/get.php?username=xxx&password=xxxx&type=m3u_plus&output=m3u8
    ADDON = xbmcaddon.Addon(id='plugin.video.glowiptv.rec')
    BASEURL = 'http://tv.glowiptv.iptv.uno:80'
    PLAYURL = 'http://channels227070.clientportal.link:80'
    COMMAND = 'get.php?'
    COMMANDEND = '&type=m3u_plus&output=m3u8'
    REGISTRATION = 'http://glowiptv.com'
    REFERRALNAME = 'GlowIPTV Rec'
    REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '..................[/COLOR][/B]'

elif referral==9:
    ###http://www.e900x.com:8000/get.php?username=xxxx&password=xxxx&type=m3u_plus&output=ts
    ADDON = xbmcaddon.Addon(id='plugin.video.krogsbelliptv-2023-12-30--14-57.rec')
    BASEURL = 'http://www.e900x.com:8000'
    COMMAND = 'get.php?'
    COMMANDEND = '&type=m3u_plus&output=ts'
    REGISTRATION = 'http://www.nordicchannels.com'
    REFERRALNAME = 'Krogsbell IPTV 2021-11-29--12-16 2021-05-23--19-28 2019-12-01 Rec'
    REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '.....[/COLOR][/B]'
    DEFAULTSTREAMTYPE = 'live'

elif referral==10:
    ADDON = xbmcaddon.Addon(id='plugin.video.ntv')
    BASEURL = 'http://www.ntv.mx'
    REGISTRATION = 'http://ntv.mx/?r=Kodi&c=2&a=0&p=9'
    REFERRALNAME = 'NTV'
    REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'
else:
    ADDON = xbmcaddon.Addon(id='plugin.video.krogsbelliptv-2023-12-30--14-57')
    if ADDONgetSetting('BASEURL') == '':
        basicuserinfo = Search('Your connection details')
        ### http://<url>/get.php?username=<>&password=<>&type=m3u_plus&output=ts
        if basicuserinfo:
            if 'http://' in basicuserinfo.lower():
                server = basicuserinfo.split('http://',1)[1].split('/')[0]
                BASEURL = basicuserinfo.split('http://',1)[1].split('/')[0]
                COMMAND = ''
    REGISTRATION = ''
    COMMAND = '/panel_api.php?'
    COMMANDEND = '&type=m3u_plus&output=m3u8'
    REGISTRATION = ''
    REFERRALNAME = 'IPTV Rec'
    REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'

ADDONsetSetting('my_referral_link',str(referral))
REFERRALNAME = ADDONgetSetting('my_referral_name')
REFERRALTITLE = '[B][COLOR lightblue]' + REFERRALNAME + '....................[/COLOR][/B]'
REGISTRATION = ADDONgetSetting('my_referral_registration')
###xbmc.log('definition.py in %s with referral= %s' % (ADDON.getAddonInfo('id'), repr(referral)))

def getADDON():
    return ADDON

def getBASEURL():
    return BASEURL  
  
def getPLAYURL():
    return PLAYURL  
    
def getCOMMAND():
    return COMMAND 
    
def getCOMMANDEND():
    return COMMANDEND  
    
def getREGISTRATION():
    return REGISTRATION 
 
def getTITLE():
    return REFERRALTITLE 
    
def getDefaultStreamType():
    return DEFAULTSTREAMTYPE
    
def getKrogsbellAddOns():
    ###return ['plugin.video.glowiptv.rec','plugin.video.premiumiptv.rec','plugin.video.roqtv.rec']
    ###return ['plugin.video.glowiptv.rec','plugin.video.krogsbelliptv-2023-12-30--14-57.rec',]
    return []

def getNTVAddOns():
    return ['plugin.video.unlimtv']
    ###return []



