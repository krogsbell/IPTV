#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmc, xbmcvfs
# For Python 3.0 and later
from urllib.request import urlopen
import sys
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import definition
import utils
import recordings
import updateepg
    
try:
    ADDON     = definition.getADDON()
    ADDONid   = definition.ADDONgetAddonInfo('id')
    ADDONname = definition.ADDONgetAddonInfo('name')
    datapath  = xbmcvfs.translatePath(definition.ADDONgetAddonInfo('profile'))
    progpath  = definition.ADDONgetAddonInfo('path')
    module    = 'updatefiles.py'
    utils.logdev(module,'Exception updatefiles Started')
    utils.logdev(module,'Exception sys.argv= %r' % sys.argv)
    alarmName = 'updatefiles'
    marker    = 'l'
    try:
        marker = sys.argv[1]
    except Exception as e:
        pass
        utils.logdev(module,'30 Exception: %r' % e)
    alarmName = alarmName + '-' + marker   
    recordings.updateAlarm(alarmName)
    utils.logdev(module,'Exception updatefiles after updateAlarm %r' % alarmName)
    
    try:
        if marker == 'l':
            utils.logdev(module,'Exception updatefiles local %r' % marker)
            updateepg.ScanLocalRecordings()
        else:
            utils.logdev(module,'Exception updatefiles archive %r' % marker)
            updateepg.ScanRecordings(marker)
    except Exception as  e:
        pass
        utils.logdev(module, 'Exception in updatefiles= %r ERROR= %r' % (marker,e))
        
except Exception as  e:
    pass
    utils.logdev(module, 'Exception in updatefiles= %r ERROR= %r' % (marker,e))
utils.logdev(module,'Exception Ended')

