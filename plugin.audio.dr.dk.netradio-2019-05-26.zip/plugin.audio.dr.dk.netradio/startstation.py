#!/usr/bin/python
# -*- coding: utf-8 -*-

import urllib2    ### krogsbell 2019-05-21
import xmltodict  ### pip install xmltodict (Ubuntu first: sudo apt install python-pip)
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import os
import xbmcgui, xbmcplugin
import utils

def __log(text):
    utils.logdev(sys.argv[0],text)
    
try:
    program    = sys.argv[0]
    station_id = sys.argv[1]
    timestamp  = sys.argv[2]
except:
    pass
    title = 'StartStation'
    timestamp = ''
try:
    __log('sys.argv= %r' % sys.argv)
    __log('os.environ= %s' % os.environ['OS'] ) #put in LOG
except: pass

try:
    __log('code part')
    HANDLE = int(sys.argv[1])
    item = xbmcgui.ListItem(path='http://live-icy.gss.dr.dk:8000/A/A08H.mp3.m3u', thumbnailImage='')
    item.setInfo(type='music', infoLabels={
        'title': 'Radio'
    })
    xbmcplugin.setResolvedUrl(HANDLE, True, item)
    """
    ### plugin://plugin.audio.radio_de/station/11315
    ###cmd = 'XBMC.RunPlugin(plugin://plugin.audio.radio_de/play/'+station_id+')'
    cmd = 'XBMC.RunPlugin(plugin://plugin.audio.radio_de/play/)'
    xbmc.log('cmd= %s' % cmd)
    
    xbmc.executebuiltin(cmd)  # Active
    xbmc.sleep(32000)
    """
except Exception,e:
    pass
    __log('StartStation ERROR: %r' % e)