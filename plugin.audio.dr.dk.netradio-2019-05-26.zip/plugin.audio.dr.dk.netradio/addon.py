#
#      Copyright (C) 2014 Tommy Winther
#      http://tommy.winther.nu
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt. If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
import os
import sys
import simplejson
import urllib2
import urlparse

import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import channels
import buggalo
import utils
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import xmltodict

CHANNELS_URL = 'http://www.dr.dk/mu-online/api/1.0/channel/all-active-dr-radio-channels'

ADDON     = xbmcaddon.Addon()
ADDONname = ADDON.getAddonInfo('name')
ADDONid   = ADDON.getAddonInfo('id')
ADDONpath = xbmc.translatePath('special://home/addons/%s/' % ADDONid)
ProgramPlaying = ADDON.getSetting('ProgramPlaying')
ADDON.setSetting('ProgramPlaying',ProgramPlaying)
programswanted = ['madsen']
programsnogo   = ['funk','povlsen']
preferredstation = '11315'  ### DR P4
backupstation    = '12573'  ### DR P5
radioEPGs = [['12566','https://www.dr.dk/Tjenester/epglive/epg.radio.P1.drxml'],['12577','https://www.dr.dk/Tjenester/epglive/epg.radio.P2.drxml'],['10773','https://www.dr.dk/Tjenester/epglive/epg.radio.P3.drxml'],['11315','https://www.dr.dk/Tjenester/epglive/epg.radio.P4KBH.drxml'],['12573','https://www.dr.dk/Tjenester/epglive/epg.radio.P5.drxml'],['12826','https://www.dr.dk/Tjenester/epglive/epg.radio.P6Beat.drxml'],['12827','https://www.dr.dk/Tjenester/epglive/epg.radio.P7M.drxml',],['12828','https://www.dr.dk/Tjenester/epglive/epg.radio.P8Jazz.drxml']]

def __log(text):
    utils.logdev(sys.argv[0],text)
    
def TS(timestr):
    ### time format 2019-05-21T22:05:00Z
    time_tuple = time.strptime(timestr, "%Y-%m-%dT%H:%M:%SZ")
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)
   
def nowTS():   ### UTC time
    dt_obj= datetime.utcnow()
    time_tuple = dt_obj.timetuple()
    timestamp = int(time.mktime(time_tuple))
    return(timestamp)

def nowS(format):   ### Now date string UTC time
    time_tuple = time.localtime(nowTS())
    date_str = time.strftime(format, time_tuple)
    return(date_str)
    
def datestr(timestamp,format):   ### Now date string UTC time
    time_tuple = time.localtime(timestamp)
    date_str = time.strftime(format, time_tuple)
    return(date_str)
    
def takeSecond(elem): 
    return elem[1]
    
def StartProgram(station_id,timestamp):
    __log('ADDON %r - %r' % (ADDONname,ADDONid))
    __log('station_id= %r Start @ %r' % (station_id,datestr(timestamp,'%H:%M:%S')))
    ###ADDONpath =  = xbmc.translatePath('special://home/addons/%s/' % ADDONid)
    script = os.path.join(ADDONpath, 'startstation.py')
    __log('script= %r' % script)
    nameAlarm = ADDONid + '-startstation-' + str(timestamp)
    #delay = timestamp - now.....
    cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),00:00:00,silent)' % (nameAlarm, script, station_id, str(timestamp))
    __log('cmd= %s' % cmd)
    ###ADDONpath =  = xbmc.translatePath('special://home/addons/%s/' % ADDONid)
    script = os.path.join(ADDONpath, 'startstation.py')
    __log('script= %r' % script)
    nameAlarm = ADDONid + '-startstation-' + str(timestamp)
    #delay = timestamp - now.....
    cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),00:00:00,silent)' % (nameAlarm, script, HANDLE,station_id)
    __log('cmd= %s' % cmd)
    ADDON.setSetting('StartStation',station_id)
    xbmc.executebuiltin(cmd)  # Active
   
def StopProgram(station_id,timestamp):
    __log('ADDON %r - %r' % (ADDONname,ADDONid))
    __log('station_id= %r Start @ %r' % (station_id,datestr(timestamp,'%H:%M:%S')))
    ###ADDONpath =  = xbmc.translatePath('special://home/addons/%s/' % ADDONid)
    script = os.path.join(ADDONpath, 'startstation.py')
    __log('script= %r' % script)
    nameAlarm = ADDONid + '-startstation-' + str(timestamp)
    #delay = timestamp - now.....
    cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),00:00:00,silent)' % (nameAlarm, script, station_id, str(timestamp))
    __log('cmd= %s' % cmd)
    ###ADDONpath =  = xbmc.translatePath('special://home/addons/%s/' % ADDONid)
    script = os.path.join(ADDONpath, 'startstation.py')
    __log('script= %r' % script)
    nameAlarm = ADDONid + '-startstation-' + str(timestamp)
    #delay = timestamp - now.....
    cmd = 'AlarmClock(%s,RunScript(%s,%s,%s),00:00:00,silent)' % (nameAlarm, script, station_id, str(timestamp))
    __log('cmd= %s' % cmd)
    ADDON.setSetting('StopStation',station_id)
    xbmc.executebuiltin(cmd)  # Active
def showOverview():
    item = xbmcgui.ListItem(ADDON.getLocalizedString(30100), iconImage=ICON)
    item.setProperty('Fanart_Image', FANART)
    xbmcplugin.addDirectoryItem(HANDLE, PATH + '?show=dr', item, True)
    
    item = xbmcgui.ListItem(ADDON.getLocalizedString(30102), iconImage=ICON)
    item.setProperty('Fanart_Image', FANART)
    xbmcplugin.addDirectoryItem(HANDLE, PATH + '?show=epg', item, True)

    item = xbmcgui.ListItem(ADDON.getLocalizedString(30101), iconImage=ICON)
    item.setProperty('Fanart_Image', FANART)
    xbmcplugin.addDirectoryItem(HANDLE, PATH + '?show=other', item, True)

    xbmcplugin.endOfDirectory(HANDLE)


def showDRChannels():
    try:
        u = urllib2.urlopen(CHANNELS_URL)
        channelList = simplejson.loads(u.read())
        u.close()
    except Exception, ex:
        showError(str(ex))
        return

    for channel in channelList:
        title = channel['Title']
        if title[0:3] == 'DR ':
            title = title[3:]
        sourceUrl = channel['SourceUrl']
        logoImage = os.path.join(LOGO_PATH, sourceUrl[sourceUrl.rindex('/') + 1:] + '.png')
        if xbmcvfs.exists(logoImage):
            item = xbmcgui.ListItem(title, iconImage=logoImage)
        else:
            item = xbmcgui.ListItem(title, iconImage=ICON)

        item.setProperty('IsPlayable', 'true')
        item.setProperty('Fanart_Image', FANART)
        item.setInfo(type='music', infoLabels={
            'title': title
        })

        url = None

        if 'StreamingServers' in channel:
            for server in channel['StreamingServers']:
                if 'LinkType' in server and server['LinkType'] == 'ICY' and 'Qualities' in server:
                    try:
                        url = server['Server'] + '/' + server['Qualities'][0]['Streams'][0]['Stream']
                        break
                    except:
                        pass

        if url:
            xbmcplugin.addDirectoryItem(HANDLE, url, item)

    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.endOfDirectory(HANDLE)


def showOtherChannels():
    for channel in channels.CHANNELS:
        logoImage = os.path.join(LOGO_PATH, str(channel.id) + '.png')
        if xbmcvfs.exists(logoImage):
            item = xbmcgui.ListItem(channel.name, iconImage=logoImage)
        else:
            item = xbmcgui.ListItem(channel.name, iconImage=ICON)

        item.setProperty('IsPlayable', 'true')
        item.setProperty('Fanart_Image', FANART)
        item.setInfo(type='music', infoLabels={
            'title': channel.name
        })
        xbmcplugin.addDirectoryItem(HANDLE, PATH + '?playOther=%d' % channel.id, item)

    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(HANDLE)

def showEPG():
    __log('Maintenance START')
    try:
        items = []
        WantedPrograms = []
        NogoPrograms   = []
        __log('radioEPGs= %r ' % radioEPGs)
        for radioEPGi in radioEPGs:
            station_id = radioEPGi[0]
            radioEPG  = radioEPGi[1]
            __log('station_id= %r ' % station_id)
            file = urllib2.urlopen(radioEPG)
            dataepg = file.read()
            file.close() 
            datadict = xmltodict.parse(dataepg)
            name = datadict['m_sch:message']['schedule']['channel']['name']
            type = datadict['m_sch:message']['schedule']['channel']['type']
            datadict1 = datadict['m_sch:message']['schedule']['programs']
            
            titlename = '[COLOR yellow][B]' + datadict['m_sch:message']['schedule']['channel']['type'].upper() + ': ' + datadict['m_sch:message']['schedule']['channel']['name'] + '  -  ' + datadict['m_sch:message']['schedule']['broadcastdate'] + '[/B]' + '  Now ' + nowS('%H:%M') + ' GMT[/COLOR]'
            item = xbmcgui.ListItem(titlename, iconImage=ICON)

            item.setProperty('IsPlayable', 'true')
            item.setProperty('Fanart_Image', FANART)
            item.setInfo(type='music', infoLabels={
                'title': titlename
            })
            xbmcplugin.addDirectoryItem(HANDLE, PATH + '?playOther=%s' % station_id, item)
            
            """
            item=('label': '[B]' + datadict['m_sch:message']['schedule']['channel']['type'].upper() + ': ' + datadict['m_sch:message']['schedule']['channel']['name'] + '  -  ' + datadict['m_sch:message']['schedule']['broadcastdate'] + '[/B]' + '  Now ' + nowS('%H:%M') + ' GMT','path': station_id,'is_playable': True,)
            __log('addDir item: %r' % item)
            xbmcplugin.addDirectoryItem(HANDLE, PATH + '?showepg=%s' % station_id, item)
            #__log('added items= %r' % items)
            """
            
            i = 0
            for program in datadict1['program']:
                stop = program['pro_publish']['ppu_stop_timestamp_presentation_utc']
                start = program['pro_publish']['ppu_start_timestamp_announced_utc']
                startactual = program['pro_publish']['ppu_start_timestamp_presentation_utc']
                if TS(stop) > nowTS():
                    title = program['pro_publish']['ppu_title']  
                    for wanted in programswanted:
                        if wanted in title.lower():
                            title = '[COLOR lightgreen]' + title + '[/COLOR]'
                            WantedPrograms.append([station_id,startactual,stop])
                    for notwanted in programsnogo:
                        if notwanted in title.lower():
                            title = '[I][COLOR red]' + title + '[/COLOR][/I]' 
                            NogoPrograms.append([station_id,startactual,stop])
                    title = '[B]' + title + '[/B]'
                    punchline= program['pro_publish']['ppu_punchline']
                    if punchline:
                        title += ' - ' + punchline
                    description= program['pro_publish']['ppu_description']
                    if description:
                        title += '\n' + description
                    channel= program['pro_publish']['ppu_channel']
                    if start != startactual:
                        try:
                            ### 2019-05-21T22:05:00Z
                            timediff = repr(TS(startactual) - TS(start))
                        except Exception,e:
                            pass
                            timediff = repr(e)
                        title = '[COLOR lightblue]'+timediff+'[/COLOR] ' + title
                    ###stop = program['pro_publish']['ppu_stop_timestamp_presentation_utc']
                    if i < 2:
                        i += 1
                        
                        titlename = startactual[11:-4] + ' - ' + stop[11:-4] + '  ' + title
                        item = xbmcgui.ListItem(titlename, iconImage=ICON)

                        item.setProperty('IsPlayable', 'true')
                        item.setProperty('Fanart_Image', FANART)
                        item.setInfo(type='music', infoLabels={
                            'title': titlename
                        })
                        xbmcplugin.addDirectoryItem(HANDLE, PATH + '?playOther=%s' % station_id, item)
                        """
                        item=({
                            'label': startactual[11:-4] + ' - ' + stop[11:-4] + '  ' + title,
                            'path': station_id,'is_playable': True,
                        })
                        __log('addDir item: %r' % item)
                        xbmcplugin.addDirectoryItem(HANDLE, PATH + '?showepg=%s' % station_id, item)
                        """
            
    except Exception,e:
        pass
        __log('radioEPG ERROR: %r' % e)
    Programs = []
    if WantedPrograms != []:
        __log('WantedPrograms= %r' % WantedPrograms)
        for prog in WantedPrograms:
            Programs.append(prog)
    if NogoPrograms != []:
        __log('NogoPrograms= %r' % NogoPrograms)
        for prog in NogoPrograms:
            if prog[0] == preferredstation:
                Programs.append((backupstation,prog[1],prog[2]))
    __log('Programs= %r' % Programs)
    Programs = sorted(Programs, key=takeSecond)
    __log('Programs= %r' % Programs)
    ProgramPlaying = ADDON.getSetting('ProgramPlaying')
    __log('ProgramPlaying= %r' % ProgramPlaying)
    if ProgramPlaying == '':
        ProgramPlaying = preferredstation
        ADDON.setSetting('ProgramPlaying',ProgramPlaying)
        StartProgram(preferredstation,nowTS())
    StartProgram(preferredstation,nowTS())
    if Programs != []:
        try:
            if Programs[0][0] != ProgramPlaying:
                ProgramPlaying = Programs[0][0]
                StartProgram(Programs[0][0],TS(Programs[0][1]))
                EndProgram(preferredstation,TS(Programs[0][2]))
        except Exception,e:
            pass
            __log('Programs[0][0] ERROR: %r' % e)
            __log('No Program Change needed')
    else:
        __log('No Program Change needed')

    ###xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(HANDLE)

def playOther(idx):
    channel = None
    for c in channels.CHANNELS:
        if c.id == int(idx):
            channel = c
            break

    if channel is None:
        return

    logoImage = os.path.join(LOGO_PATH, str(channel.id) + '.png')
    item = xbmcgui.ListItem(path=channel.url, thumbnailImage=logoImage)
    item.setInfo(type='music', infoLabels={
        'title': channel.name
    })
    xbmcplugin.setResolvedUrl(HANDLE, True, item)


def showError(message):
    heading = buggalo.getRandomHeading()
    line1 = ADDON.getLocalizedString(30900)
    line2 = ADDON.getLocalizedString(30901)
    xbmcgui.Dialog().ok(heading, line1, line2, message)


if __name__ == '__main__':
    ADDON = xbmcaddon.Addon()
    PATH = sys.argv[0]
    HANDLE = int(sys.argv[1])
    PARAMS = urlparse.parse_qs(sys.argv[2][1:])

    LOGO_PATH = os.path.join(ADDON.getAddonInfo('path'), 'resources', 'logos')
    ICON = os.path.join(ADDON.getAddonInfo('path'), 'icon.png')
    FANART = os.path.join(ADDON.getAddonInfo('path'), 'fanart.jpg')
    ADDON.setSetting('PATH',str(PATH))
    __log('PATH= %r' % PATH)
    __log('PARAMS= %r' % PARAMS)
    buggalo.SUBMIT_URL = 'http://tommy.winther.nu/exception/submit.php'
    try:
        if 'show' in PARAMS and PARAMS['show'][0] == 'dr':
            showDRChannels()
        elif 'show' in PARAMS and PARAMS['show'][0] == 'other':
            showOtherChannels()
        elif 'show' in PARAMS and PARAMS['show'][0] == 'epg':
            showEPG()
        elif 'playOther' in PARAMS:
            playOther(PARAMS['playOther'][0])
        else:
            showOverview()

    except Exception:
        buggalo.onExceptionRaised()

