#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import sys
import xbmc
import utils
import definition

args = sys.argv
ADDON       = definition.getADDON()
ADDONid     = ADDON.getAddonInfo('id')
ADDONname   = ADDON.getAddonInfo('name')
datapath    = xbmc.translatePath(ADDON.getAddonInfo('profile'))
progpath    = ADDON.getAddonInfo('path')
module      = 'startrepeatprog.py'
utils.logdev(module,'Start - args= %r' % args)

interval = args[1].replace('h',':').replace('m',':')
utils.logdev(module,'interval= %r' % args[1])
utils.notification('Start EPG import with interval '+args[1] + 's')
nameAlarmEPGfirst = ADDONname +'nameEPGfirst' 
nameAlarmEPGt = ADDONname +'nameEPGt' 
scriptEPGt   = os.path.join(ADDON.getAddonInfo('path'), 'updateepg.py')
cmdEPGfirst = 'AlarmClock(%s,RunScript(%s,%s),00:00:00,silent)' % (nameAlarmEPGfirst.encode('utf-8', 'replace'), scriptEPGt.encode('utf-8', 'replace'), 'hourly')
cmdEPGt = 'AlarmClock(%s,RunScript(%s,%s),%s,loop,silent)' % (nameAlarmEPGt.encode('utf-8', 'replace'), scriptEPGt.encode('utf-8', 'replace'), 'hourly',interval)
utils.logdev(module,'cmdEPGfirst= %r' % cmdEPGfirst)
utils.logdev(module,'cmdEPGt= %r' % cmdEPGt)
xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmEPGfirst)
xbmc.executebuiltin(cmdEPGfirst)  # Active
xbmc.executebuiltin('CancelAlarm(%s,True)' % nameAlarmEPGt)
xbmc.executebuiltin(cmdEPGt)  # Active
