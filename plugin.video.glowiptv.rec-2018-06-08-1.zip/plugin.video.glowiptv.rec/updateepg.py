#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os
import time
from datetime import datetime, timedelta  #### Important ####
### futuredate = datetime.now() + timedelta(days=10)
import calendar
import net
import json
import locking,utils
import recordings
import glob
import definition
import shutil
import urllib2
import xmltodict
import base64
from operator import itemgetter

ADDON      = definition.getADDON()
ADDONname  = ADDON.getAddonInfo('name')
ADDONid    = ADDON.getAddonInfo('id')
args = sys.argv  ### args[1] == 'once' or 'hourly'
module = 'updateepg.py'
utils.logdev(module,'Start')
utils.logdev(module,'args: '+ repr(args))
datapath   = xbmc.translatePath(ADDON.getAddonInfo('profile'))
progpath   = ADDON.getAddonInfo('path')
referral = ADDON.getSetting('my_referral_link')
dateStringDummy = '20200625070000 +0100'

def notnone(cat):
    if cat == None:
        return ''
    else:
        return cat
        
def testPrograms():
    try:  ### Get system timezone
        timezone = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Settings.GetSettingValue", "params": {"setting": "locale.timezone"}, "id": 1}')
        utils.logdev(module,'Kodi timezone= %r' % timezone)
    except Exception, e:
            pass
            utils.logdev(module,'Get timezone error= %r' % e)
    try:   ### Test if ffmpeg is installed
        if utils.runCommandTest('ffmpeg'):
            utils.logdev(module,'FFMPEG installed!')
    except Exception, e:
            pass
            utils.logdev(module,'Get ffmpeg error= %r' % e)
    try:   ### Test if rtmpdump is installed
        if utils.runCommandTest('rtmpdump'):
            utils.logdev(module,'RTMPDUMP installed!')
    except Exception, e:
            pass
            utils.logdev(module,'Get rtmpdump error= %r' % e)
    try:   ### Test if 7zip is installed
        if utils.runCommandTest('7z'):
            utils.logdev(module,'7z installed!')
        else:
            utils.logdev(module,'7z NOT installed!')
    except Exception, e:
            pass
            utils.logdev(module,'Get 7z error= %r' % e)
    ### xarchiver -v
    try:   ### Test if xarchiver -v is installed
        if utils.runCommandTest('xarchiver -v'):
            utils.logdev(module,'xarchiver -v installed!')
        else:
            utils.logdev(module,'xarchiver -v NOT installed!')
    except Exception, e:
            pass
            utils.logdev(module,'Get xarchiver -v error= %r' % e)
tz = ADDON.getSetting('AdjustTVguideTimeZoneOffset')
if tz == '':
    TimeZone = 0
else:
    TimeZone = int(tz)  
tzx = ADDON.getSetting('AdjustTVguideTimeZoneOffsetExtraXML')

if tzx == '':
    TimeZoneXML = 0
else:
    TimeZoneXML = int(tzx)  
utils.logdev(module,'TimeZone= %r, TimeZoneXML= %r' % (TimeZone,TimeZoneXML))   
datapanel = []
dataepg = []
data= []
EPGgenerator = ''
ChannelFile = ''
channels = 0
programs = 0

def EPGimportERRORS(ERROR):
    if ERROR == '':
        ERROR = 'No Errors'
    else:
        ERROR = ERROR + ', ' + ADDON.getSetting('lastEPGimportERRORS')
    ADDON.setSetting('lastEPGimportERRORS',ERROR)

def parse_date(dateString):
    return datetime.fromtimestamp(time.mktime(time.strptime(dateString.encode('utf-8', 'replace'), "%Y-%m-%d %H:%M:%S")))
    
def parse_date_string(dateString):
    ###ValueError: time data '20170625070000 +0100' does not match format '%Y%m%d%H%M%S z'
    ###return time.mktime(time.strptime(dateString.encode('utf-8', 'replace'), '%Y%m%d%H%M%S Z'))  ### UTC time
    ###utils.logdev('resulttime0',repr(dateString))
    dt = dateString.split(' ')
    if int(dt[0]) < 0:
        dateStringOLD = dateString
        utils.logdev('resulttime0',repr(dateString))
        utils.logdev('parse_date_string0','dt[0]= %r' % dt[0])
        dateString = dateStringDummy
        dt = dateString.split(' ')
        resulttime = time.mktime(time.strptime(dt[0], '%Y%m%d%H%M%S'))
        utils.logdev('parse_date_string1a','dt= %r' % dt)
        EPGimportERRORS('ERROR in date HTML: %r using dummy time: %r' % (dateStringOLD,dateString))
    resulttime = time.mktime(time.strptime(dt[0], '%Y%m%d%H%M%S'))
    ###utils.logdev('resulttime1',repr(resulttime))
    resulttime =  int(resulttime) - (int(dt[1])/100 - TimeZone)*3600
    ###utils.logdev('resulttime2',repr(resulttime))
    ###utils.logdev('resulttime3',repr(datetime.fromtimestamp(resulttime)))
    return str(resulttime)
    
def parse_date_stringXML(dateString):
    dt = dateString.split(' ')
    if int(dt[0]) < 0:
        dateStringOLD = dateString
        utils.logdev('resulttime0',repr(dateString))
        utils.logdev('parse_date_string0','dt[0]= %r' % dt[0])
        dateString = dateStringDummy
        dt = dateString.split(' ')
        resulttime = time.mktime(time.strptime(dt[0], '%Y%m%d%H%M%S'))
        utils.logdev('parse_date_string1a','dt= %r' % dt)
        EPGimportERRORS('ERROR in date XML: %r using dummy time: %r' % (dateStringOLD,dateString))
    resulttime = time.mktime(time.strptime(dt[0], '%Y%m%d%H%M%S'))
    resulttime =  int(resulttime) - (int(dt[1])/100 - TimeZoneXML)*3600
    return str(resulttime)

def getDict(dictA,name,ntype='',dtype=''):
    ###if ADDON.getSetting('KeyErrorStop') != '':
    ### return ''
    element = ''
    en = "KeyError('" + name + "',)"
    ex = "KeyError('" + ntype + "',)"
    ey = "KeyError('" + dtype + "',)"
    if name == 'sub_title':
        return repr(dictA) + ' \n' + en  ### Debug option
    try:
        if dtype != '' and ntype != '':
            elementd = dictA[name][dtype]
            element = dictA[name][ntype]
            ###if type(element) in (list, tuple, dict):
            ### for elem in element:
            ###     return elem
            ###else:
            ###return repr(element)
            return element
    except Exception, e:
        pass
        err = repr(e)
        if err==en:
            return ''
        if err==ey:
            return 'ey1'
        if err==ex:
            return 'ex1'
    try:
        if ntype != '':
            element = dictA[name][ntype]
            ###if type(element) in (list, tuple, dict):
            ### for elem in element:
            ###     return elem
            ###else:
            ###return repr(element)
            return element
    except Exception, e:
        pass
        err = repr(e)
        if err==en:
            return ''
        if err==ex:
            return 'ex2'
    try:
        element = dictA[name]
        ###if type(element) in (list, tuple, dict):
        ### for elem in element:
        ###     return elem
        ###else:
        ###return repr(element)
        return element
    except Exception, e:
        pass
        err = repr(e)
        if err==en:
            return 'en3'
    return 'nothing'

def getEPGChannel(cat):
    try:
        utils.logdev(module,'getEPGChannel(cat)')
        conn = recordings.getConnection()
        c = conn.cursor()
        c.execute("SELECT DISTINCT title, epg_channel, source FROM channels WHERE id=?", [cat])
        favorites = c.fetchall()
        if len(favorites) > 0:
            result = [favorites[0][0],favorites[0][1],favorites[0][2]]  ### Title, EPG Channel
        else:
            result = ''
        c.close() 
        return result
    except Exception, e:
        pass
        utils.notification('Error in getEPGChannel(cat) '+ cat + ' \n' + repr(e))
    
def setEPGChannel(cat,channel):
    try:
        utils.logdev(module,'setEPGChannel(cat)')
        conn = recordings.getConnection()
        c = conn.cursor()
        c.execute("SELECT * FROM channels WHERE id=?", [cat])
        favorites = c.fetchall()
        result = []

        for index in range(0, len(favorites)):
            ch = []
            for i in range(0, len(favorites[index])):
                if favorites[index][i] == None:
                    ch.append('')
                else:
                    ch.append(favorites[index][i])
            c.execute("INSERT OR REPLACE INTO channels(id, title, logo, stream_url, source, visible, weight, favorite, catchup, epg_channel, description, updated, created) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [ch[0], ch[1], ch[2], ch[3], ch[4], ch[5], ch[6], ch[7], ch[8], channel,ch[10],ch[11],ch[12]])
        if result == []:
            utils.logdev(module,'EPG not found for cat= %r' % cat)
        conn.commit()
        c.close() 
    except Exception, e:
        pass
        utils.notification('Error in setEPGChannel(cat) '+ cat + ' \n' + repr(e))

def getEPGnow(cat):
    ###now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    ###now= datetime.today()
    ###utils.logdev(module,'getEPGnow(cat)')
    conn = recordings.getConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM channels WHERE id=?", [cat])
    favorites = c.fetchall()
    result = []
    for index in range(0, len(favorites)):
        if result == []:
            ch = []
            for i in range(0, len(favorites[index])):
                if favorites[index][i] == None:
                    ch.append('')
                else:
                    ch.append(favorites[index][i])
            ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
            name = ch[1]
            tv_archive = ch[8]
            tv_archive_duration = 7
            epg_channel_id = ch[9].replace(' (R)','')  ### Ignore Recursive marker
            result = [recordings.getEPGProgramsNow(epg_channel_id), name, tv_archive, tv_archive_duration, epg_channel_id]
    if result == []:
        utils.logdev(module,'EPG not found for cat= %r' % cat)
    c.close() 
    return result
    
def getEPG(cat):
    try:
        ###now= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        ###now= datetime.today()
        ###utils.logdev(module,'getEPG(cat)')
        conn = recordings.getConnection()
        c = conn.cursor()
        c.execute("SELECT * FROM channels WHERE id=?", [cat])
        favorites = c.fetchall()
        result = []
        for index in range(0, len(favorites)):
            if result == []:
                ch = []
                for i in range(0, len(favorites[index])):
                    if favorites[index][i] == None:
                        ch.append('')
                    else:
                        ch.append(favorites[index][i])
                ###c.execute("INSERT OR REPLACE INTO channels(id0, title1, logo2, stream_url3, source4, visible5, weight6, favorite7, catchup8, description9) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [chan[0], chan[1], chan[2], chan[3], chan[4], chan[5], chan[6], chan[7], chan[8], chan[9]])
                name = ch[1]
                tv_archive = ch[8]  ### Holds duration in days - 0 means no archive
                default_tv_archive_duration = int(ADDON.getSetting('tv_archive_duration'))
                try:
                    tv_archive_duration = tv_archive
                except:
                    pass
                    tv_archive_duration = default_tv_archive_duration
                if tv_archive_duration > default_tv_archive_duration:
                    ADDON.setSetting('tv_archive_duration',str(tv_archive_duration))
                if not tv_archive == 0:
                    tv_archive = 1
                epg_channel_id = ch[9].replace(' (R)','')  ### Ignore Recursive marker
                result = [recordings.getEPGPrograms(epg_channel_id), name, tv_archive, tv_archive_duration, epg_channel_id]
        if result == []:
            utils.logdev(module,'EPG not found for cat= %r' % cat)
        c.close() 
        return result
    except Exception, e:
        pass
        utils.logdev(module,'Error in getEPG!\n' + repr(e))
    return []
    """
    ### Find name, tv_archive, tv_archive_duration, epg_channel_id in database... 2017-07-14
    linkpanel = 'http://roq-tv.net:25461/panel_api.php?username=' +ROQuser+ '&password=' +ROQpass
    file = urllib2.urlopen(linkpanel)
    datapanel = file.read()
    file.close()
    try:
        datapanel = json.loads(datapanel)
        name = datapanel['available_channels'][cat]['name']
        tv_archive = datapanel['available_channels'][cat]['tv_archive']
        tv_archive_duration = datapanel['available_channels'][cat]['tv_archive_duration']
        epg_channel_id = datapanel['available_channels'][cat]['epg_channel_id']
    except Exception, e:
        pass
        ### or Find epg_channel_id based on cat....
        utils.notification('Error in getting '+ ADDONid + ' info or your channel is from XML file!\n' + repr(e))
        return ''
    
    return [recordings.getEPGPrograms(epg_channel_id), name, tv_archive, tv_archive_duration, epg_channel_id]
    """
    """
    httplinkEPG = 'http://roq-tv.net:25461/xmltv.php?username=' +ROQuser+ '&password=' +ROQpass
    file = urllib2.urlopen(httplinkEPG)
    dataepg = file.read()
    file.close()
    try:
        dataepg = xmltodict.parse(dataepg)
    except Exception, e:
        pass
        utils.notification('Error in EPG file '+ httplinkEPG + ' \n' + repr(e))
        return ''
    try:
        epg = dataepg['tv']['programme']
        utils.logdev(module,repr(dataepg['tv']['programme']))
    except Exception, e:
        pass
        utils.notification('Error in EPG programme '+ httplinkEPG + ' \n' + repr(e))
        return ''
    return
    """
    
if args[1] == 'once' or args[1] == 'hourly':    
    nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    EPGimportERRORS('')    ### Reset Errors
    utils.logdev('Version',utils.version()) 
    utils.logdev('VersionDate',utils.versiondate())
    ROQuser = ADDON.getSetting('user')
    ROQpass = ADDON.getSetting('pass')
    utils.testPrograms()   ### Test recordingprograms
    if locking.isScanLocked('EPG_update') and not ADDON.getSetting('blockduringepgimport') == 'true':
        utils.logdev(module,'No EPG update as it is still running!')
    else:
        utils.notification('EPG Import Started!')
        utils.logdev('datetime.today()',repr(datetime.today()))
        nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        ADDON.setSetting('lastEPGimportInfo','New EPG Import Started ' + nowS)
        ###if not locking.isAnyScanLocked():
        ### utils.logdev(module,'No scanning try EPG Update!')
        if ADDON.getSetting('blockduringepgimport') == 'true':
            locking.scanLock('EPG_update')
        ###utils.notification('%s in %s started' % (module,ADDONid))
        if ADDON.getSetting('enable_record')=='true':
            RecordActive = True
        else:
            RecordActive = False

        now= datetime.today()
        lastEPGimport = ADDON.getSetting('lastEPGimport')
        if lastEPGimport == '':
            lastEPGimport = now - timedelta(hours = 24)  ### dummy lastEPGimport
            ADDON.setSetting('lastEPGimport',lastEPGimport.strftime('%Y-%m-%d %H:%M:%S using'))
        utils.logdev('ADDON.getSetting(lastEPGimport)',repr(lastEPGimport))
        
        try:
            lastEPGimport = parse_date(ADDON.getSetting('lastEPGimport').split(' using',1)[0])
        except:
            pass
            lastEPGimport = parse_date(ADDON.getSetting('lastEPGimport'))
        utils.logdev('datetime.datetime(ADDON.getSetting(lastEPGimport))',repr(lastEPGimport))
        
        cEPG = recordings.getConnection()
        recordings.createEPGchannelsTable(cEPG)
        recordings.createEPGProgramsTable(cEPG)
        c = cEPG.cursor()
        try:
            c.execute("PRAGMA journal_mode = WAL")  ### 2018-01-07 Try to speed up on Windows (1700 sec down to 700 sec)
        except Exception, e:
            pass
            utils.logdev(module,'PRAGMA journal_mode = WAL ERROR %r' % e)
        
        ###ADDON = xbmcaddon.Addon(id='plugin.video.wozboxntv')
        ###open(channelsxml, 'w')
        try:
            NTVchannels = xbmc.translatePath( xbmcaddon.Addon(id='plugin.video.wozboxntv').getAddonInfo('profile') + 'channels.csv')
        except Exception, e:
            pass
            EpgError = 'Error in getting NTV Channels\n' + repr(e)
            #EPGimportERRORS(EpgError)
            #utils.notification(EpgError)
            utils.logdev(module,EpgError)
            NTVchannels = ''
        try:  ### Get the set webport
            webport = utils.getGuiSetting('webserverport','8080')
        except:
            pass
            webport = '8080'
        if os.path.isfile(NTVchannels):
            utils.logdev(module,'Use ChannelFile in: ' + repr(NTVchannels))
            nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
            ADDON.setSetting('lastEPGimportInfo','Import NTV Channels Started ' + nowS)
            for line in open(NTVchannels):  # opened in text-mode; all EOLs are converted to '\n'
                ###utils.logdev(module,'Line: ' + repr(i) + ' - ' + line)
                line = line.rstrip('\n').rstrip('\r')
                if not line == '' and not line[:2] == '# ' :   # Ignore empty lines and comment lines
                    channels += 1
                    line=line.split(',')
                    stream_id = 'NTV' + line[0]
                    name = line[1] + ' (NTV)'
                    url = 'http://127.0.0.1:' + webport + '/jsonrpc?request={"jsonrpc":"2.0","method":"Addons.ExecuteAddon","params":{"wait":false,"addonid":"plugin.video.wozboxntv","params":["url=url","cat=' + line[0] + '","mode=210","name=' + line[1] + '","recordname='+ADDONid+'"]},"id":200}'
                    stream_icon = ''
                    epg_channel_id = ''
                    ###EPGgenerator = 'NTV Available Channels'
                    EPGgenerator = ADDONid +' available_channels'
                    displaydescription = ''
                    recordings.addEPGChannel(c, stream_id, name, url, stream_icon, epg_channel_id, EPGgenerator, epg_channel=epg_channel_id, description=displaydescription)
        ###ADDON = xbmcaddon.Addon(id='plugin.video.tvawayrec')
        ###open(channelsxml, 'w')
        try:
            NTVchannels = xbmc.translatePath( xbmcaddon.Addon(id='plugin.video.tvawayrec').getAddonInfo('profile') + 'channels.csv')
        except Exception, e:
            pass
            EpgError = 'Error in getting TVawayrec Channels\n' + repr(e)
            #EPGimportERRORS(EpgError)
            #utils.notification(EpgError)
            utils.logdev(module,EpgError)
            NTVchannels = ''
        try:  ### Get the set webport
            webport = utils.getGuiSetting('webserverport','8080')
        except:
            pass
            webport = '8080'
        if os.path.isfile(NTVchannels):
            utils.logdev(module,'Use ChannelFile in: ' + repr(NTVchannels))
            nowS= datetime.today().strftime('%Y-%m-%d %H:%M:%S')
            ADDON.setSetting('lastEPGimportInfo','Import TVawayrec Channels Started ' + nowS)
            for line in open(NTVchannels):  # opened in text-mode; all EOLs are converted to '\n'
                ###utils.logdev(module,'Line: ' + repr(i) + ' - ' + line)
                line = line.rstrip('\n').rstrip('\r')
                if not line == '' and not line[:2] == '# ' :   # Ignore empty lines and comment lines
                    channels += 1
                    line=line.split(',')
                    stream_id = 'TVA' + line[0]
                    name = line[1] + ' (TVA)'
                    url = 'http://127.0.0.1:' + webport + '/jsonrpc?request={"jsonrpc":"2.0","method":"Addons.ExecuteAddon","params":{"wait":false,"addonid":"plugin.video.tvawayrec","params":["url=url","cat=' + line[0] + '","mode=210","name=' + line[1] + '","recordname='+ADDONid+'"]},"id":200}'
                    stream_icon = ''
                    epg_channel_id = ''
                    ###EPGgenerator = 'TVA Available Channels'
                    EPGgenerator = ADDONid +' available_channels'
                    displaydescription = ''
                    recordings.addEPGChannel(c, stream_id, name, url, stream_icon, epg_channel_id, EPGgenerator, epg_channel=epg_channel_id, description=displaydescription)
        ###if (lastEPGimport-now).total_seconds()/3600 < -12:
        ### >>>>>> ROQ TV PANEL
        ROQTVusername = ADDON.getSetting('user')
        if ROQTVusername.lower() == 'none':
            ADDON.setSetting('expiredate',ROQTVusername)
            ADDON.setSetting('concurrentstreams',ROQTVusername)
        else:
            ###linkpanel = definition.getBASEURL() + definition.getCOMMAND() + 'username=' +ROQuser+ '&password=' +ROQpass + definition.getCOMMANDEND()
            linkpanel = definition.getBASEURL() + '/panel_api.php?username=' +ADDON.getSetting('user')+ '&password=' +ADDON.getSetting('pass')
            ###if referral == 7:
            ###    ###http://tv.premium.iptv.uno:8080/get.php?username=xxxx&password=xxxx&type=m3u_plus&output=m3u8
            ###    linkpanel = definition.getBASEURL() + '/get.php?username=' +ROQuser+ '&password=' +ROQpass+ '&type=m3u_plus&output=m3u8'
            try:
                file = urllib2.urlopen(linkpanel)
                datapanel = file.read()
                file.close()
            except Exception, e:
                pass
                EpgError = 'Error in getting '+ linkpanel + ' \n' + repr(e)
                EPGimportERRORS(EpgError)
                utils.notification(EpgError)
                datapanel = ''
                
            ChannelFile = os.path.join(datapath,ADDONid) + '.info'
            utils.makeOldFile(ChannelFile)
            with open(ChannelFile,'wb') as output:
                output.write(datapanel)
            
            ### ADDON.setSetting('lastEPGimportInfo','Pannel data fetched ' + nowS)

            ###name= Status,url= url,mode= 11,iconimage= ,cat= ,date= ,description= {u'username': u'XXX', u'status': u'Active', u'is_trial': u'0', u'created_at': u'1493734688', u'auth': 1, u'allowed_output_formats': [u'm3u8', u'ts', u'rtmp'], u'exp_date': u'1499005088', u'active_cons': u'0', u'password': u'XXXX', u'max_connections': u'1'},startDate= ,endDate= ,recordname= )
            try:
                datapanel = json.loads(datapanel)
                datapanel1 = datapanel['user_info']
                descrpanel = 'Username= %s \nStatus= %s \nExpire= %s \nMax connections= %s' %(datapanel1['username'],datapanel1['status'],recordings.parseDate(datapanel1['exp_date']).strftime('%Y-%m-%d %H:%M'),datapanel1['max_connections'])
                utils.logdev(module+' Start datapanel',descrpanel)
                ### expiredate/concurrentstreams
                ADDON.setSetting('expiredate',str(recordings.parseDate(datapanel1['exp_date']).strftime('%Y-%m-%d %H:%M')))
                ADDON.setSetting('concurrentstreams',str(datapanel1['max_connections']))
            except Exception, e:
                pass
                EpgError = 'Error in getting '+ ADDONid + ' info! Check your User ID\n' + repr(e)
                EPGimportERRORS(EpgError)
                utils.notification(EpgError)
                datapanel = []

            """
            "available_channels":{
            "281":{
            "num":1,
            "name":"UK: BBC ONE HD",
            "stream_type":"live",
            "type_name":"Live Streams",
            "stream_id":"281",
            "stream_icon":"https:\/\/upload.wikimedia.org\/wikipedia\/commons\/1\/1a\/BBC_One_2002.png",
            "epg_channel_id":"BBC One London",
            "added":"1487332455",
            "category_name":"UK: ENTERTAINMENT",
            "category_id":"14",
            "series_no":null,
            "live":"1",
            "container_extension":null,
            "custom_sid":":0:19:22e3:80d:2:11a0000:0:0:0:",
            "tv_archive":1,
            "direct_source":"",
            "tv_archive_duration":"7"},
            """
            streamtype = ADDON.getSetting('streamtype').replace('0','m3u8').replace('1','ts').replace('2','rtmp')
            EPGgenerator = ADDONid +' available_channels'
            try:
            ###if 1==1:
                for chan in datapanel['available_channels']:
                    """
                    utils.logdev(module,repr(chan))
                    try:
                        utils.logdev(module,repr(datapanel['available_channels'][chan]))
                    except Exception, e:
                        pass
                        utils.notification('Info Error ' + repr(e)) 
                    """
                    description = ''
                    stream_id = notnone(datapanel['available_channels'][chan]['stream_id'])
                    name = notnone(datapanel['available_channels'][chan]['name'])
                    """
                    if ': ' in name:  ### Move category to end of name
                        chnameColon = name.split(': ') 
                        name = chnameColon[1] + ' (ROQ TV: ' + chnameColon[0]+ ')'
                    if '(RADIO' in name:   ### Move RADIO categoty to end of name
                        if ') ' in name:
                            chnameColon = name.split(') ')
                            name = chnameColon[1] + ' ' + chnameColon[0]+ ')'
                    """
                    category_name = notnone(datapanel['available_channels'][chan]['category_name'])
                    stream_icon = notnone(datapanel['available_channels'][chan]['stream_icon'])
                    epg_channel_id = notnone(datapanel['available_channels'][chan]['epg_channel_id'])
                    tv_archive = notnone(datapanel['available_channels'][chan]['tv_archive'])
                    tv_archive_duration = notnone(datapanel['available_channels'][chan]['tv_archive_duration'])
                    stream_type = notnone(datapanel['available_channels'][chan]['stream_type'])
                    container_extension = notnone(datapanel['available_channels'][chan]['container_extension'])
                    added = notnone(datapanel['available_channels'][chan]['added'])
                
                    if stream_type == 'live':
                        utils.logdev(module,'stream_type == live')
                        try:
                            url = definition.getBASEURL() + '/'+stream_type+'/'+ROQuser+'/'+ROQpass+'/'+stream_id+'.'+streamtype
                        except Exception, e:
                            pass
                            EpgError = 'Error in live container_extension '+ ChannelFile + ' \n' + repr(e)
                            utils.logdev(module,'stream_type == live?? url= %r' % url)
                            ### EPGimportERRORS(EpgError)
                            utils.logdev(module,EpgError)
                            url = 'url'  ### Dummy
                    else:
                        utils.logdev(module,'stream_type != live')
                        try:
                            url = definition.getBASEURL() + '/'+stream_type+'/'+ROQuser+'/'+ROQpass+'/'+stream_id+'.'+container_extension
                        
                        except Exception, e:
                            pass
                            EpgError = 'Error in container_extension '+ ChannelFile + ' \n' + repr(e)
                            utils.logdev(module,EpgError)
                            utils.logdev(module,'stream_type != live?? url= %r' % url)
                            ### EPGimportERRORS(EpgError)
                            utils.logdev(module,EpgError)
                            url = 'url'  ### Dummy
                    ChannelFav = recordings.getChannelFav(c,stream_id)
                    ###utils.logdev(module,'1. ChannelFav= %r, stream_id= %r' % (ChannelFav, stream_id))
                    ###recordings.addEPGChannel(c,stream_id,name,url,stream_icon,epg_channel_id,EPGgenerator,epg_channel=epg_channel_id)
                    ###addEPGChannel(c,cid,name,url,iconimage,cat,origin,visible=1,weight=0,epg_channel='',description='')
                    ###utils.logdev('XYZxyz','name= %r, category= %r' % (name,category_name))
                    displaydescription = description
                    if category_name != '' and description != '':
                        displaydescription = 'Category: ' + category_name + '\n\nDescription:\n' + description
                    else:
                        displaydescription = category_name + displaydescription
                    utils.logdev('XYZxyz','name= %r, category= %r' % (name,displaydescription))
                    recordings.addEPGChannel(c, stream_id, name, url, stream_icon, epg_channel_id, EPGgenerator, epg_channel=epg_channel_id, description=displaydescription)  ### 2018-02-13
                    recordings.setChannelCatchup(c,stream_id,tv_archive_duration)  ### 2018-06-08 catchup flag is number of days catchup
                    ###utils.logdev(module,'2. ChannelFav= %r, stream_id= %r' % (ChannelFav, stream_id))
                    recordings.setChannelFav(c,stream_id,ChannelFav)
                    recordings.setChannelAdded(c,stream_id,added)
                    channels += 1
                    utils.logdev(module,'channels= %r, name= %r' % (channels,name))
            
            except Exception, e:
                pass
                EpgError = 'Error in datapanel[available_channels] '+ ChannelFile + ' \n' + repr(e)
                EPGimportERRORS(EpgError)
                utils.logdev(module,EpgError)
            
        cEPG.commit()
        ended = datetime.today()
        ###utils.logdev(module,'EPG Import at ' + str(int((ended-now).total_seconds())) +' sec Channels= ' + repr(channels))    
        utils.logdev(module,'EPG Import at ' + repr(ended-now).replace('datetime.timedelta(0, ','').split(',')[0] +' sec Channels= ' + repr(channels))  
        ################################
        ###ADDON.setSetting('lastEPGimportInfo','Start import of m3u direct channels ' + nowS)
        i = 0
        ###categories= []
        channelsM3U= []
        ChannelFile = ADDON.getSetting('directchannelsfromextraXMLTVfile') 
        if not os.path.isfile(ChannelFile):
            ChannelFile = os.path.join(datapath,'directchannels.m3u')
            ADDON.setSetting('directchannelsfromextraXMLTVfile','')  ###Remove old value
        if not os.path.isfile(ChannelFile):    ### If ChannelFile exist in Data directory use it
            ChannelFile = os.path.join(progpath,'directchannels.m3u.txt')  ### Otherwise try program directory
        if os.path.isfile(ChannelFile): 
            utils.logdev(module,'Use extra ChannelFile in: ' + repr(ChannelFile))
            ADDON.setSetting('directchannelsfromextraXMLTVfile',ChannelFile)
            for line in open(ChannelFile):  # opened in text-mode; all EOLs are converted to '\n'
                ######utils.logdev(module,'Line: ' + repr(i) + ' - ' + line)
                line = line.rstrip('\n').rstrip('\r').strip()
                if not line == '' and not line[:2] == '# ' :   # Ignore empty lines and comment lines
                    if '#EXTM3U' in line :
                        i += 1
                        ######utils.logdev(module,'Skip EXTM3U in line: ' + repr(i))
                    elif '#EXTINF' in line :
                        i += 1
                        ######utils.logdev(module,'Use EXTINF in line: ' + repr(i) + ' - ' + line)
                        ###if ',' in line:
                        ### utils.logdev(module,'Comma(,) in line: ' + repr(i) + ' - ' + line)
                        tvgid=''
                        tvgname=''
                        tvgnamecat = ''
                        tvglogo=''
                        grouptitle=''
                        name=''
                        try:
                            tvgid=line.split('tvg-id="',1)[1].split('"',1)[0]
                            ######utils.logdev(module,'Use tvg-id in line: ' + repr(tvgid) + ' - ' + line)
                        except:
                            pass
                        try:
                            tvgname=line.split('tvg-name="',1)[1].split('"',1)[0]
                            ######utils.logdev(module,'Use tvg-name in line: ' + repr(tvgname) + ' - ' + line)
                        except:
                            pass
                        try:
                            tvglogo=line.split('tvg-logo="',1)[1].split('"',1)[0]
                            ######utils.logdev(module,'Use tvg-logo in line: ' + repr(tvglogo) + ' - ' + line)
                        except:
                            pass
                        try:
                            grouptitle=line.split('group-title="',1)[1].split('"',1)[0]
                            ######utils.logdev(module,'Use group-title in line: ' + repr(grouptitle) + ' - ' + line)
                        except:
                            pass
                        try:
                            name=line.split(',')[-1]
                            ######utils.logdev(module,'Use name in line: ' + repr(name) + ' - ' + line)
                            grouptitle=grouptitle.split('SEASON')[0].strip()
                        except:
                            pass
                        try:
                            if ':' in tvgname:
                                tvgnamecat=tvgname.split(':')[0].strip()
                        except:
                            pass
                    else:
                        i += 1
                        try:
                            cats=line.split('live/')[1].split('/')[0]
                        except:
                            pass
                            try:
                                cats=line.split('tv2danmark/')[1].split('/')[0]
                            except:
                                pass
                                try:
                                    cats=line.split('i/')[1].split('/')[0]
                                except:
                                    pass
                                    cats=line.split('.')[-2].split('/')[-1]
                        if 'live' in line:
                            catsinlink='! live'
                        else:
                            catsinlink=''
                        ###utils.logdev(module,'Use cname= ' + repr(cname) + ' - grouptitle= ' + repr(grouptitle))
                        ###if cname == grouptitle or cname == tvgnamecat or cname == catsinlink or cname == 'Channels':
                        if '_' in cats:
                            if not 'bbc_' in cats:   ### 2017-08-28
                                if not 'cbeebies_' in cats:
                                    utils.logdev(module,'cats no_= %r' % cats)
                                    cats = cats.split('_')[0]
                                    utils.logdev(module,'cats no_= %r' % cats)
                        ###grouptitle
                        channelsM3U.append([name.strip()+' (D)',line,grouptitle,tvglogo,tvgname,tvgid,cats,catsinlink])
                        ###elif  cname == 'Categories':
                        ### if not grouptitle in categories and grouptitle != None :
                        ###     categories.append(grouptitle)
                        ### if not tvgnamecat == '' and not tvgnamecat in categories and tvgnamecat != None:
                        ###     categories.append(tvgnamecat)
                        ### if not catsinlink == '' and not catsinlink in categories and catsinlink != None :
                        ###     categories.append(catsinlink)
                        ##utils.logdev(module,'Use URL in line: ' + repr(repr(i)) + ' - ' + line)
                        ###addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
                        ###addDir(name,line,200,tvglogo,cat,'','cat= ' + cat + '\n\rtvg-id= ' + tvgid + '\n\rtvg-name= '+tvgname + '\n\rgroup-title= ' + grouptitle,'','',tvgname)
        ChannelFile = os.path.join(datapath,ADDONid) + '.m3u'
        if os.path.isfile(ChannelFile):
            utils.logdev(module,'Use ChannelFile in: ' + repr(ChannelFile))
            for line in open(ChannelFile):  # opened in text-mode; all EOLs are converted to '\n'
                ###utils.logdev(module,'Line: ' + repr(i) + ' - ' + line)
                line = line.rstrip('\n').rstrip('\r')
                if not line == '' and not line[:2] == '# ' :   # Ignore empty lines and comment lines
                    if '#EXTM3U' in line :
                        i += 1
                        ####utils.logdev(module,'Skip EXTM3U in line: ' + repr(i))
                    elif '#EXTINF' in line :
                        i += 1
                        ###if ',' in line:
                        ### utils.logdev(module,'Comma(,) in line: ' + repr(i) + ' - ' + line)
                        tvgid=''
                        tvgname=''
                        tvgnamecat = ''
                        tvglogo=''
                        grouptitl=''
                        name=''
                        ####utils.logdev(module,'Use EXTINF in line: ' + repr(i) + ' - ' + line)
                        tvgid=line.split('tvg-id="',1)[1].split('"',1)[0]
                        ####utils.logdev(module,'Use tvg-id in line: ' + repr(tvgid) + ' - ' + line)
                        tvgname=line.split('tvg-name="',1)[1].split('"',1)[0]
                        ####utils.logdev(module,'Use tvg-name in line: ' + repr(tvgname) + ' - ' + line)
                        tvglogo=line.split('tvg-logo="',1)[1].split('"',1)[0]
                        ####utils.logdev(module,'Use tvg-logo in line: ' + repr(tvglogo) + ' - ' + line)
                        grouptitle=line.split('group-title="',1)[1].split('"',1)[0]
                        ####utils.logdev(module,'Use group-title in line: ' + repr(grouptitle) + ' - ' + line)
                        name=line.split(',')[-1]
                        ####utils.logdev(module,'Use name in line: ' + repr(name) + ' - ' + line)
                        grouptitle=grouptitle.split('SEASON')[0].strip()
                        tvgnamecat = ''
                        if ':' in tvgname:
                            tvgnamecat=tvgname.split(':')[0].strip()
                    else:
                        i += 1
                        cats=line.split('.')[-2].split('/')[-1]
                        catsinlink='! ' + line.split('/')[3]
                        if  catsinlink == '! rt':
                            catsinlink = ''
                        ######utils.logdev(module,'Use cname= ' + repr(cname) + ' - grouptitle= ' + repr(grouptitle))
                        ###if cname == grouptitle or cname == tvgnamecat or cname == catsinlink or cname == 'Channels':
                        channelsM3U.append([name.strip(),line,grouptitle,tvglogo,tvgname,tvgid,cats,catsinlink])
                        ###elif  cname == 'Categories':
                        ### if not grouptitle in categories:
                        ###     categories.append(grouptitle)
                        ### if not tvgnamecat == '' and not tvgnamecat in categories:
                        ###     categories.append(tvgnamecat)
                        ### if not catsinlink == '' and not catsinlink in categories:
                        ###     categories.append(catsinlink)
                        ######utils.logdev(module,'Use URL in line: ' + repr(repr(i)) + ' - ' + line)
                        ###addDir(name,url,mode,iconimage,cat,date,description,startDate='',endDate='',recordname='')
                        ###addDir(name,line,200,tvglogo,cat,'','cat= ' + cat + '\n\rtvg-id= ' + tvgid + '\n\rtvg-name= '+tvgname + '\n\rgroup-title= ' + grouptitle,'','',tvgname)
        ###channels = sorted(channels)
        ######utils.logdev(module,'Use channels: ' + repr(channels))
        ###categories = sorted(categories)
        ######utils.logdev(module,'Use categories: ' + repr(categories))
        ###for cat in categories:
            ######utils.logdev(module,'Use categories: ' + repr(cat))
        ### if cat != '':
        ###     addDir(cat,'url',2,'','','',channeldescription)
        ###cEPG = recordings.getConnection()
        ###recordings.createEPGchannelsTable(cEPG)
        ###c = cEPG.cursor()
        j = 1
        for cat in channelsM3U:
            ######utils.logdev(module,'Use channels: ' + repr(cat))
            if cat[0] != '':
                ###if RecordActive :  ###
                ### addChannel(name,url,iconimage,cat,source)
                ###recordings.addChannel(cat[0],cat[1],cat[3],cat[6], ADDONid)
                description = ''
                if cat[6] != '':
                    description += ' \n\rcat= ' + cat[6]
                if cat[5] != '':
                    description += ' \n\rtvg-id= ' + cat[5]
                if cat[4] != '':
                    description += ' \n\rtvg-name= '+cat[4]
                if cat[2] != '':
                    description += ' \n\rgroup-title= ' + cat[2]
                if cat[7] != '':
                    description += ' \n\rcatsinlink= '+cat[7]
                if cat[1] != '' and ADDON.getSetting('ShowLink') == 'true':
                    description += ' \n\rlink= '+cat[1].replace('/','/ ')
                recordings.addChannel(cat[0],cat[1],cat[3],cat[6], ADDONid+ ' available_channels',weight= j,epg_channel= cat[5],description=description)
                j += 1
                ###addDir(cat[0],cat[1],200,cat[3],cat[6],'',description,'','',cat[4])
        
                ###ChannelFav = recordings.getChannelFav(c,cat[0])
                ###recordings.addEPGChannel(c,cat[0],name,url,stream_icon,epg_channel_id,EPGgenerator)
                ###recordings.setChannelCatchup(c,cat[0],'False')
                ###recordings.setChannelFav(c,cat[0],ChannelFav)
        
                ###addDir(cat[0],cat[1],200,cat[3],cat[6],'','cat= ' + cat[6] + '\n\rtvg-id= ' + cat[5] + '\n\rtvg-name= '+cat[4] + '\n\rgroup-title= ' + cat[2] + ' \n\rcatsinlink= '+cat[7]+ ' \n\rlink= '+cat[1].replace('/','/ '),'','',cat[4])
                ###addDir(cat[0]+'*',cat[1].replace('.ts','.txt').replace('.mp4','.txt'),200,cat[3],cat[6],'',cat[1].replace('.ts','.txt').replace('.mp4','.txt'),'','',cat[4])
    
        
        
        ################################
        ###c.close() #### test
        ###if 1 == 0:
        
        ### >>>>>> ROQ TV ENIGMA
        ###link = 'http://roq-tv.net:25461/enigma2.php?username=XXX&password=XXXX'
        ###linkenigma = 'http://roq-tv.net:25461/enigma2.php?username=' +ROQuser+ '&password=' +ROQpass
        ###file = urllib2.urlopen(linkenigma)
        ###dataenigma = file.read()
        ###file.close()
        ###ADDON.setSetting('lastEPGimportInfo','Import HTTP guide ' + nowS)
        httplinkEPG = ADDON.getSetting('tvguideimporthttp')
        ROQTVusername = ADDON.getSetting('user')
        if ROQTVusername.lower() != 'none':
            if httplinkEPG == '':
                httplinkEPG = definition.getBASEURL() + '/xmltv.php?username=' +ROQuser+ '&password=' +ROQpass
        utils.logdev(module,'roq-tv EPG link: ' + repr(httplinkEPG))
        if ADDON.getSetting('tvguidefromfile') == 'true':
            ChannelFile1 = ADDON.getSetting('tvguideimport')
        else:
            ChannelFile1 = ''
        ###if ChannelFile == '':
        ChannelFile2 = ''
        if httplinkEPG != '':
            try:
                m3ufile = urllib2.urlopen(httplinkEPG)
                ChannelFile2 = os.path.join(datapath,ADDONid) + 'EPG.xml'
                utils.makeOldFile(ChannelFile2)
                with open(ChannelFile2,'wb') as output:
                    output.write(m3ufile.read())
            except Exception, e:
                pass
                EpgError = 'Error in httplinkEPG '+ httplinkEPG + ' \n' + repr(e)
                EPGimportERRORS(EpgError)
                utils.notification(EpgError)
        ###utils.logdev(module,'roq-tv EPG file downloaded: ' + repr(ChannelFile))
        #########utils.logdev('Decoded XML file',repr(newdata))
        ###########2017-06-14
        ###else:
            ###ChannelFile = '/home/hans/.kodi/userdata/addon_data/script.ivueguide/merged_epg.xml'  ### Rytec EPG <<<<<<<
        EPGgeneratorDis = ''
        ChannelFiles = []
        if ChannelFile2 != '':
            ChannelFiles.append(ChannelFile2)
        if ChannelFile1 != '':
            ChannelFiles.append(ChannelFile1)   
        for ChannelFile in ChannelFiles:
            try:
                ChannelFileMod = datetime.fromtimestamp(os.path.getmtime(ChannelFile))
            except Exception, e:
                pass
                EpgError = 'Error in EPG file '+ ChannelFile + ' \n' + repr(e)
                EPGimportERRORS(EpgError)
                utils.notification(EpgError)
                ChannelFileMod = now
    
            utils.logdev('ChannelFile', repr(ChannelFile))
            if ChannelFile == ChannelFile1:
                utils.logdev(module,'time offset: %r' % (TimeZoneXML))
            else:
                utils.logdev(module,'Time Offset: %r' % (TimeZone))
            utils.logdev('os.path.getmtime(ChannelFile)',repr(ChannelFileMod))
            try:
                utils.logdev('lastEPGimport - os.path.getmtime(ChannelFile) in hours',repr(lastEPGimport - ChannelFileMod).replace('datetime.timedelta(0, ','').split(')')[0].split(',')[0])            ###if (lastEPGimport - ChannelFileMod).total_seconds()/3600 < 12:
            except:
                pass
            try:
                epgfile = open(ChannelFile, 'r')
                ###ADDON.setSetting('KeyErrorStop','')
                ###utils.logdev('KeyErrorStop Reset',ADDON.getSetting('KeyErrorStop'))

                dataepg = epgfile.read()
                epgfile.close() 
            except Exception, e:
                pass
                EpgError = 'Error in EPG file '+ ChannelFile + ' \n' + repr(e)
                EPGimportERRORS(EpgError)
                utils.notification(EpgError)
                dataepg = ''


            try:
                dataepg = xmltodict.parse(dataepg)
            except Exception, e:
                pass
                EpgError = 'Error in EPG file '+ ChannelFile + ' \n' + repr(e)
                EPGimportERRORS(EpgError)
                utils.notification(EpgError)
                dataepg = ''

            #########utils.logdev('Decoded Dict',repr(data))
            ###channelsxml = os.path.join(datapath, 'channelsdictEPG')  + '.dict'
            ###LF = open(channelsxml, 'w')
            ###LF.write(repr(dataepg))
            ###LF.close()
            ###ADDON.setSetting('lastEPGimportInfo','Extract from datapannel ' + nowS)
            try:
                datapanelEPG1 = dataepg['tv']
                datapanelEPG2 = dataepg['tv']['@generator-info-name']
                datapanelEPG3 = dataepg['tv']['@generator-info-url']
                utils.logdev('datapanelEPG2 = dataepg[tv][@generator-info-name]',repr(datapanelEPG2))
            except Exception, e:
                pass
                EpgError = 'Error in datapanelEPG '+ ChannelFile + ' \n' + repr(e)
                EPGimportERRORS(EpgError)
                utils.notification(EpgError)
                
            ###c.execute("CREATE TABLE IF NOT EXISTS programs(channel TEXT, title TEXT, sub_title TEXT, start_date TIMESTAMP, end_date TIMESTAMP, description TEXT, categories TEXT, image_large TEXT, image_small TEXT, season TEXT, episode TEXT, is_movie TEXT, language TEXT, source TEXT, updates_id INTEGER, UNIQUE (channel, start_date, end_date))")
            ###cEPG.commit()
            ###c.close()
            EPGgeneratorName = getDict(dataepg,'tv','@generator-info-name')
            EPGgeneratorURL  = getDict(dataepg,'tv','@generator-info-url')
            if EPGgeneratorName == '' or EPGgeneratorURL == '':
                EPGgenerator = EPGgeneratorName + EPGgeneratorURL
            else:
                EPGgenerator = EPGgeneratorName + ' - ' + EPGgeneratorURL
            
            if EPGgeneratorName != '':
                if EPGgeneratorDis != '':
                    EPGgeneratorDis = EPGgeneratorDis + ', ' + EPGgeneratorName
                else:
                    EPGgeneratorDis = EPGgeneratorName
            ADDON.setSetting('lastEPGimportInfo',EPGgeneratorDis)
            
            try:
                datapanelEPG3 = dataepg['tv']['channel']
            except Exception, e:
                pass
                EpgError = 'Error in datapanelEPG3 '+ ChannelFile + ' \n' + repr(e)
                EPGimportERRORS(EpgError)
                utils.notification(EpgError)
                datapanelEPG3 = []
            i = 0
            for cid in datapanelEPG3:
                xbmc.sleep(1)
                ###time.sleep(1/100)
                i += 1
                if i % 10000 == 0:
                    ended = datetime.today()
                    ###utils.notification('EPG Import at ' + str(int((ended-now).total_seconds())) +' sec Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= ' + EPGgeneratorName)
                    utils.notification('EPG Import at ' + repr(ended-now).replace('datetime.timedelta(0, ','').split(',')[0] +' sec Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= ' + EPGgeneratorName)        
                ###if ADDON.getSetting('KeyErrorStop') == '':
                ###utils.logdev('datapanelEPG3: for cid in datapanelEPG3',repr(cid))
                ###utils.logdev('datapanelEPG3: for cid in datapanelEPG3[@id]',repr(cid['@id']))
                ###OrderedDict([(u'@lang', u'en'), ('#text', u'Deutsche Welle (English)')])
                name = getDict(cid,'display-name','#text','@lang')
                iconimage = getDict(cid,'icon','@src')
                """
                try:
                    name = cid['display-name']['#text']
                    ###utils.logdev('datapanelEPG3: for cid in datapanelEPG3[display-name][@lang]',repr(cid['display-name']['#text']) + '[' + repr(cid['display-name']['@lang'])+']')
                except:
                    pass
                    name = cid['display-name']
                    ###utils.logdev('datapanelEPG3: for cid in datapanelEPG3[display-name]',repr(cid['display-name']))
                iconimage = ''
                try:
                    iconimage = cid['icon']['@src']
                    ###utils.logdev('datapanelEPG3: for cid in datapanelEPG3[icon]',repr(cid['icon']))
                except:
                    pass
                    try:
                        iconimage = cid['icon']
                    except: pass
                """
                ###def addChannel(name,url,iconimage,cat,origin,visible=True,weight=0,description=''):
                recordings.addEPGChannel(c,cid['@id'],name,'url',iconimage,repr(cid),EPGgenerator)
                channels += 1
                utils.logdev(module,'channels= %r, name= %r' % (channels,name))
            cEPG.commit()
            ended = datetime.today()
            ###utils.logdev(module,'EPG Import at ' + str(int((ended-now).total_seconds())) +' sec Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= ' + EPGgenerator)
            utils.logdev(module,'EPG Import at ' + repr(ended-now).replace('datetime.timedelta(0, ','').split(',')[0] +' sec Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= ' + EPGgenerator)

            ### (u'programme', [OrderedDict([(u'@start', u'20170613130000 +0100'), (u'@stop', u'20170613133000 +0100'), (u'@channel', u'I46817.labs.zap2it.com'), (u'title', u'ESPNEWS'), (u'desc', u'Sports news round-the-clock: highlights, scores, updates.')]),
            ### OrderedDict([(u'@start', u'20170618060000 +0000'), (u'@stop', u'20170618070000 +0000'), (u'@channel', u'BET:BlackEntTv.uk'), (u'title', OrderedDict([(u'@lang', u'en'), ('#text', u'Soul Sessions')])), (u'desc', OrderedDict([(u'@lang', u'en'), ('#text', u"The best of Neo-Soul, R&B and classic hits, and features music videos from today's hottest artist and music legends")]))]),
            try:
                datapanelEPG4 = dataepg['tv']['programme']
            except Exception, e:
                pass
                EpgError = 'Error in dataepg[tv][programme] '+ ChannelFile + ' \n' + repr(e)
                EPGimportERRORS(EpgError)
                utils.notification(EpgError)
                datapanelEPG4 = ''
            ###ADDON.setSetting('lastEPGimportInfo','Pannel EPG4 extracting ' + nowS)
            for prog in datapanelEPG4:
                xbmc.sleep(1)
                ###time.sleep(1/100)
                i += 1
                if i % 10000 == 0:
                    ended = datetime.today()
                    ###utils.notification('EPG Import at ' + str(int((ended-now).total_seconds())) +' sec Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= ' + EPGgeneratorName)
                    utils.notification('EPG Import at ' + repr(ended-now).replace('datetime.timedelta(0, ','').split(',')[0] +' sec Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= ' + EPGgeneratorName)
                    ADDON.setSetting('lastEPGimportInfoData','At ' + repr(ended-now).replace('datetime.timedelta(0, ','').split(',')[0] +' sec Channels= ' + repr(channels) + ' Programs= ' + repr(programs))
                    
                ###if ADDON.getSetting('KeyErrorStop') == '':
                ###utils.logdev('datapanelEPG4: for prog in datapanelEPG4[@start]',repr(prog['@start']))
                ###utils.logdev('datapanelEPG4: for prog in datapanelEPG4[@channel]',repr(prog['@channel']))
                channel = getDict(prog,'@channel')
                title = getDict(prog,'title','#text','@lang')
                sub_title = getDict(prog,'sub_title','#text','@lang')
                try:
                    description = getDict(prog,'desc','#text','@lang').replace('?n','?\n').replace('!n','!\n').replace('.nn','.\n').replace('. nn','.\n').replace('.n','.\n').replace('. n','.\n') + ' \n\nEPG Created ' + nowS  ### 2018-04-27
                except:
                    pass
                    description = ' \n\nEPG Created ' + nowS
                """
                channel = ''
                try:
                    channel = prog['@channel']['#text']
                    ###utils.logdev('datapanelEPG4: for prog in datapanelEPG4[title][@lang]',repr(prog['title']['#text']) + '[' + repr(prog['title']['@lang'])+']')
                except:
                    pass
                    try:
                        channel = prog['@channel']
                    except: pass
                title = ''
                try:
                    title = prog['title']['#text']
                    ###utils.logdev('datapanelEPG4: for prog in datapanelEPG4[title][@lang]',repr(prog['title']['#text']) + '[' + repr(prog['title']['@lang'])+']')
                except:
                    pass
                    try:
                        title = prog['title']
                    except: pass
                sub_title = ''
                try:
                    sub_title = prog['sub_title']['#text']
                    ###utils.logdev('datapanelEPG4: for prog in datapanelEPG4[title][@lang]',repr(prog['title']['#text']) + '[' + repr(prog['title']['@lang'])+']')
                except:
                    pass
                    try:
                        sub_title = prog['sub_title']
                    except: pass
                description = ''
                try:
                    description = prog['desc']['#text']
                    ###utils.logdev('datapanelEPG4: for prog in datapanelEPG4[title][@lang]',repr(prog['title']['#text']) + '[' + repr(prog['title']['@lang'])+']')
                except:
                    pass
                    try:
                        description = prog['desc']
                    except: pass
                    ###utils.logdev('datapanelEPG4: for prog in datapanelEPG4[title]',repr(prog['title']))
                """
                ###descrpanelEPG = 'channel\n@id= %r \ndisplay-name= %r \nicon[src]= %r' %(dataepg['tv']['channel']['@id'],dataepg['tv']['channel']['display-name'],dataepg['tv']['channel']['icon']['@src'])
                ###utils.logdev(module+' Start EPG',descrpanelEPG)
                ###def addEPGProgram(channel, title, sub_title, start_date, end_date, description='', categories='', image_large='', image_small='', season= '', episode='', is_movie='', language='', source='')
                ###.datetime.strptime(thetime, "%Y-%m-%dT%H:%M:%S%z")
                if ChannelFile == ChannelFile1:
                    recordings.addEPGProgram(c,prog,channel, title, sub_title, parse_date_stringXML(prog['@start']), parse_date_stringXML(prog['@stop']), description, source=EPGgenerator)
                else:
                    recordings.addEPGProgram(c,prog,channel, title, sub_title, parse_date_string(prog['@start']), parse_date_string(prog['@stop']), description, source=EPGgenerator)
                programs += 1
            cEPG.commit()
        cEPG.commit()
        c.close()
        ended = datetime.today()
        ADDON.setSetting('lastEPGimport',ended.strftime('%Y-%m-%d %H:%M:%S') + ' using ' + repr(ended-now).replace('datetime.timedelta(0, ','').split(',')[0] +' sec')
        """
        if EPGgeneratorName != '':
            if EPGgeneratorDis != '':
                EPGgeneratorDis = EPGgeneratorDis + ', ' + EPGgeneratorName
            else:
                EPGgeneratorDis = EPGgeneratorName
        ADDON.setSetting('lastEPGimportInfo',EPGgeneratorDis)
        """
        ###ADDON.setSetting('lastEPGimportInfoData','Ended in ' + str(int((ended-now).total_seconds())) +' sec Channels= ' + repr(channels) + ' Programs= ' + repr(programs))
        ###utils.notification('EPG Import Ended in ' + str(int((ended-now).total_seconds())) +' sec Cha= ' + repr(channels) + ' Pro= ' + repr(programs))
        ###utils.logdev(module,'EPG Import Ended at ' + str(int((ended-now).total_seconds())) +' sec Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= ' + EPGgenerator)
        ADDON.setSetting('lastEPGimportInfoData','Ended in ' + repr(ended-now).replace('datetime.timedelta(0, ','').split(',')[0] +' sec Channels= ' + repr(channels) + ' Programs= ' + repr(programs))
        utils.notification('EPG Import Ended in ' + repr(ended-now).replace('datetime.timedelta(0, ','').split(',')[0] +' sec Cha= ' + repr(channels) + ' Pro= ' + repr(programs))
        utils.logdev(module,'EPG Import Ended at ' + repr(ended-now).replace('datetime.timedelta(0, ','').split(',')[0] +' sec Cha= ' + repr(channels) + ' Pro= ' + repr(programs)+' Src= ' + EPGgenerator)
        locking.scanUnlock('EPG_update')
    ### Delete program entries more than 7 days old
    recordings.delOldEPGPrograms()  
    ### Make a new ftv.ini file
    recordings.ftvntvlist()

