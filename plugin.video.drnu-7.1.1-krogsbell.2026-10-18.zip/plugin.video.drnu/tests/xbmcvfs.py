# Copyright: (c) 2019, Dag Wieers (@dagwieers) <dag@wieers.com>
# GNU General Public License v3.0 (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
"""This file implements the Kodi xbmcvfs module, either using stubs or alternative functionality"""

# pylint: disable=invalid-name,too-few-public-methods

import os
from pathlib import Path
from shutil import copyfile

basedir = Path(__file__).parent.parent.resolve()

def File(path, flags='r'):
    """A reimplementation of the xbmcvfs File() function"""
    assert isinstance(path, str)
    assert isinstance(flags, str)
    return open(path, flags)  # pylint: disable=consider-using-with


def Stat(path):
    """A reimplementation of the xbmcvfs Stat() function"""

    class stat:
        """A reimplementation of the xbmcvfs stat class"""

        def __init__(self, path):
            """The constructor xbmcvfs stat class"""
            assert isinstance(path, str)
            self._stat = os.stat(path)

        def st_mtime(self):
            """The xbmcvfs stat class st_mtime method"""
            return self._stat.st_mtime

    return stat(path)


def copy(src, dst):
    """A reimplementation of the xbmcvfs mkdir() function"""
    assert isinstance(src, str)
    assert isinstance(dst, str)
    return copyfile(src, dst) == dst


def delete(path):
    """A reimplementation of the xbmcvfs delete() function"""
    assert isinstance(path, str)
    try:
        os.remove(path)
    except OSError:
        pass


def exists(path):
    """A reimplementation of the xbmcvfs exists() function"""
    assert isinstance(path, str)
    return os.path.exists(path)


def listdir(path):
    """A reimplementation of the xbmcvfs listdir() function"""
    assert isinstance(path, str)
    files = []
    dirs = []
    if not exists(path):
        return dirs, files
    for filename in os.listdir(path):
        fullname = os.path.join(path, filename)
        if os.path.isfile(fullname):
            files.append(filename)
        if os.path.isdir(fullname):
            dirs.append(filename)
    return dirs, files


def mkdir(path):
    """A reimplementation of the xbmcvfs mkdir() function"""
    assert isinstance(path, str)
    return os.mkdir(path)


def mkdirs(path):
    """A reimplementation of the xbmcvfs mkdirs() function"""
    assert isinstance(path, str)
    return os.makedirs(path)


def rmdir(path):
    """A reimplementation of the xbmcvfs rmdir() function"""
    assert isinstance(path, str)
    return os.rmdir(path)


def translatePath(path):
    """A stub implementation of the xbmc translatePath() function"""
    assert isinstance(path, str)
    if path.startswith('special://home'):
        return path.replace('special://home', str(basedir/'tests') + '/')
    if path.startswith('special://masterprofile'):
        return path.replace('special://masterprofile', str(basedir/'tests/userdata') + '/')
    if path.startswith('special://profile'):
        return path.replace('special://profile',  str(basedir/'tests/userdata') + '/')
    if path.startswith('special://userdata'):
        return path.replace('special://userdata',  str(basedir/'tests/userdata') + '/')
    return path
