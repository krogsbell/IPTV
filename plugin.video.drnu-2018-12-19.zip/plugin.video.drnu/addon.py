#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#      Copyright (C) 2014 Tommy Winther
#      http://tommy.winther.nu
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
import pickle
import os
import sys
import urlparse
import re
import datetime

import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin

import tvapi
import tvgui
import buggalo

import shutil
###from operator import itemgetter
ADDON      = xbmcaddon.Addon()
ADDONname  = ADDON.getAddonInfo('name')
ADDONid    = ADDON.getAddonInfo('id')
xbmc.log('DRNU: Start')

def RecordFlagSet(sourceApp,flag):   ### 2018-11-08
    if sourceApp == '':
        ADDONsource = xbmcaddon.Addon()
    else:
        ADDONsource = xbmcaddon.Addon(sourceApp)
    datapath = xbmc.translatePath(ADDONsource.getAddonInfo('profile'))
    recordflag = os.path.join(datapath, 'RecordFlag.txt')
    FlagFile = open(recordflag, 'w')
    # Write to our text file the information we have provided and then goto next line in our file.
    # LogDev.write(repr(module) + ': ' + repr(message) + '\n')
    FlagFile.write(flag)
    FlagFile.close()

def RecordFlagGet(sourceApp):   ### 2018-11-08
    if sourceApp == '':
        ADDONsource = xbmcaddon.Addon()
    else:
        ADDONsource = xbmcaddon.Addon(sourceApp)
    datapath = xbmc.translatePath(ADDONsource.getAddonInfo('profile'))
    recordflag = os.path.join(datapath, 'RecordFlag.txt')
    if os.path.isfile(recordflag):
        FlagFile = open(recordflag, 'r')
        # Write to our text file the information we have provided and then goto next line in our file.
        # LogDev.write(repr(module) + ': ' + repr(message) + '\n')
        flag = FlagFile.read()
    else:
        flag = ''
    return flag

def logdev(module,message):
    nowHMS=datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    datapath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
    addonlog = os.path.join(datapath, 'addon.log')
    xbmc.log('DRNU: logdev before reset')
    logdevreset(addonlog)
    # create lock file
    LogDev = open(addonlog, 'a')
    # Write to our text file the information we have provided and then goto next line in our file.
    # LogDev.write(repr(module) + ': ' + repr(message) + '\n')
    LogDev.write(nowHMS + ' ' + module + ': ' + message + '\n')

def logdevreset(addonlog):
    xbmc.log('DRNU: logdevreset')
    addonOLDlog = addonlog.replace('.log','OLD.log')
    try:
        size = os.path.getsize(addonlog)
        xbmc.log('DRNU: addon.log size= %r' % size)
        maxsize = 1 * 1024 * 1024 # 1 MB 
        xbmc.log('DRNU: log size= %r' % size)
        if os.path.exists(addonlog) and size > maxsize:
            shutil.copyfile(addonlog, addonOLDlog)
            tries    = 0
            maxTries = 10
            maxSleep = 50
            while os.path.exists(addonlog) and tries < maxTries:
                try:
                    os.remove(addonlog)
                    break
                except:
                    xbmc.sleep(maxSleep)
                    tries = tries + 1
    except Exception, e:
        pass
        xbmc.log('DRNU: Reset addon.log failed: %r' % e)

def printL(message):
        xbmc.log('DRNU: %r' % message)
        logdev('addon.py',message.encode("utf-8"))


class DrDkTvAddon(object):
    
    def __init__(self):
        self.api = tvapi.Api(CACHE_PATH)
        self.favorites = list()
        self.recentlyWatched = list()

        self.menuItems = list()
        runScript = "RunAddon(plugin.video.drnu,?show=areaselector&random=%d)" % HANDLE
        self.menuItems.append((ADDON.getLocalizedString(30511), runScript))


    def _save(self):
        # save favorites
        self.favorites.sort()
        pickle.dump(self.favorites, open(FAVORITES_PATH, 'wb'))

        self.recentlyWatched = self.recentlyWatched[0:25]  # Limit to 25 items
        pickle.dump(self.recentlyWatched, open(RECENT_PATH, 'wb'))

    def _load(self):
        # load favorites
        if os.path.exists(FAVORITES_PATH):
            try:
                self.favorites = pickle.load(open(FAVORITES_PATH, 'rb'))
            except Exception:
                pass

        # load recently watched
        if os.path.exists(RECENT_PATH):
            try:
                self.recentlyWatched = pickle.load(open(RECENT_PATH, 'rb'))
            except Exception:
                pass

    def showAreaSelector(self):
        gui = tvgui.AreaSelectorDialog()
        gui.doModal()
        areaSelected = gui.areaSelected
        del gui

        if areaSelected == 'none':
            pass
        elif areaSelected == 'drtv':
            self.showMainMenu()
        else:
            items = self.api.getChildrenFrontItems('dr-' + areaSelected)
            #xbmc.executebuiltin('Container.SetViewMode(500)')
            self.listSeries(items)

    def showMainMenu(self):
        items = list()
        # Live TV
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30027), iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'livetv.png'))
        item.setProperty('Fanart_Image', FANART_IMAGE)
        item.addContextMenuItems(self.menuItems, False)
        items.append((PATH + '?show=liveTV', item, True))

        # A-Z Program Series
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30000), iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'all.png'))
        item.setProperty('Fanart_Image', FANART_IMAGE)
        item.addContextMenuItems(self.menuItems, False)
        items.append((PATH + '?show=listAZ', item, True))

        # Latest
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30001), iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'all.png'))
        item.setProperty('Fanart_Image', FANART_IMAGE)
        item.addContextMenuItems(self.menuItems, False)
        items.append((PATH + '?show=latest', item, True))

        # Premiere
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30025), iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'new.png'))
        item.setProperty('Fanart_Image', FANART_IMAGE)
        item.addContextMenuItems(self.menuItems, False)
        items.append((PATH + '?listVideos=%s' % tvapi.SLUG_PREMIERES, item, True))

        # Themes / Repremiere
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30028), iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'all.png'))
        item.setProperty('Fanart_Image', FANART_IMAGE)
        item.addContextMenuItems(self.menuItems, False)
        items.append((PATH + '?show=themes', item, True))

        # Most viewed
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30011), iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'eye.png'))
        item.setProperty('Fanart_Image', FANART_IMAGE)
        item.addContextMenuItems(self.menuItems, False)
        items.append((PATH + '?show=mostViewed', item, True))

        # Spotlight
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30002), iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'star.png'))
        item.setProperty('Fanart_Image', FANART_IMAGE)
        item.addContextMenuItems(self.menuItems, False)
        items.append((PATH + '?show=highlights', item, True))

        # Search videos
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30003), iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'search.png'))
        item.setProperty('Fanart_Image', FANART_IMAGE)
        item.addContextMenuItems(self.menuItems, False)
        items.append((PATH + '?show=search', item, True))

        # Recently watched Program Series
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30007), iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'eye-star.png'))
        item.setProperty('Fanart_Image', FANART_IMAGE)
        item.addContextMenuItems(self.menuItems, False)
        items.append((PATH + '?show=recentlyWatched', item, True))

        # Favorite Program Series
        item = xbmcgui.ListItem(ADDON.getLocalizedString(30008), iconImage=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'plusone.png'))
        item.setProperty('Fanart_Image', FANART_IMAGE)
        items.append((PATH + '?show=favorites', item, True))
        item.addContextMenuItems(self.menuItems, False)

        xbmcplugin.addDirectoryItems(HANDLE, items)
        xbmcplugin.endOfDirectory(HANDLE)

    def showFavorites(self):
        self._load()
        if not self.favorites:
            xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'), ADDON.getLocalizedString(30013))
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        else:
            series = []
            for slug in self.favorites:
                printL('self.favorites:slug= %r' % slug)
                series.extend(self.api.searchSeries(slug))
                printL('self.favorites:series= %r' % series)
            ###self.listSeriesFlat(series, addToFavorites=False) 
            self.listSeries(series, addToFavorites=False)  
            
            """
            try:
                    series.extend(self.api.searchSeries(slug))
                    item = self.api.getEpisode(slug)
                    series.append(item)
                except Exception,e:
                    pass
                    printL('self.favorites:slug error= %r' % e)
            self.listEpisodes(series)
                series.extend(self.api.searchSeries(slug))
            self.listSeries(series, addToFavorites=False)
            """
    def showRecentlyWatched(self):
        self._load()
        videos = list()
        for slug in self.recentlyWatched:
            printL('self.showRecentlyWatched:slug= %r' % slug)
            try:
                item = self.api.getEpisode(slug)
                if item is None:
                    self.recentlyWatched.remove(slug)
                else:
                    videos.append(item)
            except tvapi.ApiException:
                # probably a 404 - non-existent slug
                self.recentlyWatched.remove(slug)

        self._save()
        if not videos:
            xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'), ADDON.getLocalizedString(30013), ADDON.getLocalizedString(30020))
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        else:
            self.listEpisodes(videos)

    def showLiveTV(self):
        items = list()
        for channel in self.api.getLiveTV():
            if channel['WebChannel']:
                continue

            server = None
            for streamingServer in channel['StreamingServers']:
                if streamingServer['LinkType'] == 'HLS':
                    server = streamingServer
                    break

            if server is None:
                continue

            item = xbmcgui.ListItem(channel['Title'], iconImage=channel['PrimaryImageUri'])
            item.setProperty('Fanart_Image', channel['PrimaryImageUri'])
            item.addContextMenuItems(self.menuItems, False)

            url = server['Server'] + '/' + server['Qualities'][0]['Streams'][0]['Stream']
            items.append((url, item, False))

        items = sorted(items, lambda mine, yours: cmp(mine[1].getLabel().replace(' ', ''), yours[1].getLabel().replace(' ', '')))

        xbmcplugin.addDirectoryItems(HANDLE, items)
        xbmcplugin.endOfDirectory(HANDLE)

    def showAZ(self):
        # All Program Series
        iconImage = os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons', 'all.png')

        items = list()
        for programIndex in self.api.getProgramIndexes():
            item = xbmcgui.ListItem(programIndex['Title'], iconImage=iconImage)
            item.setProperty('Fanart_Image', FANART_IMAGE)
            item.addContextMenuItems(self.menuItems, False)

            url = PATH + '?listProgramSeriesByLetter=' + programIndex['_Param']
            items.append((url, item, True))

        items = sorted(items) ### 2018-01-02
        xbmcplugin.addDirectoryItems(HANDLE, items)
        xbmcplugin.endOfDirectory(HANDLE)

    def showThemes(self):
        items = list()
        for theme in self.api.getThemes():
            item = xbmcgui.ListItem(theme['ThemeTitle'], iconImage=theme['PrimaryImageUri'])
            item.setProperty('Fanart_Image', theme['PrimaryImageUri'])
            item.addContextMenuItems(self.menuItems, False)

            url = PATH + '?listVideos=' + theme['ThemeSlug']
            items.append((url, item, True))

        items = sorted(items) ### 2018-01-02
        xbmcplugin.addDirectoryItems(HANDLE, items)
        xbmcplugin.endOfDirectory(HANDLE)

    def searchSeries(self):
        keyboard = xbmc.Keyboard('', ADDON.getLocalizedString(30003))
        keyboard.doModal()
        if keyboard.isConfirmed():
            keyword = keyboard.getText()
            self.listSeries(self.api.getSeries(keyword)) 

    def listSeries(self, items, addToFavorites=True):
        if not items:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            if not addToFavorites:
                xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'), ADDON.getLocalizedString(30013),
                                    ADDON.getLocalizedString(30018), ADDON.getLocalizedString(30019))
            else:
                xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'), ADDON.getLocalizedString(30013))
        else:
            directoryItems = list()
            items = sorted(items) ### 2018-01-02
            for item in items:
                menuItems = list(self.menuItems)
                try:
                    if self.favorites.count(item['SeriesTitle']) > 0:
                        runScript = "XBMC.RunPlugin(plugin://plugin.video.drnu/?delfavorite=%s)" % item['SeriesTitle'].replace('&', '%26').replace(',', '%2C')
                        menuItems.append((ADDON.getLocalizedString(30201), runScript))
                    else:
                        runScript = "XBMC.RunPlugin(plugin://plugin.video.drnu/?addfavorite=%s)" % item['SeriesTitle'].replace('&', '%26').replace(',', '%2C')
                        menuItems.append((ADDON.getLocalizedString(30200), runScript))
                except Exception,e:
                    pass
                    prontL('Error in favorites.count(item[SeriesTitle]): %r' % e)

                iconImage = item['PrimaryImageUri']
                printL(repr(item['SeriesTitle']))
                listItem = xbmcgui.ListItem(item['SeriesTitle'], iconImage=iconImage)
                listItem.setProperty('Fanart_Image', iconImage)
                listItem.addContextMenuItems(menuItems, False)
                
                url = PATH + '?listVideos=' + item['SeriesSlug']
                printL('listSeries.url= %r' % url)
                directoryItems.append((item['SeriesTitle'].lower(),url, listItem, True))

            printL('directoryItems0 %r' % directoryItems)
            directoryItems = sorted(directoryItems) ### 2018-01-02
            directoryItemsNoTitle = []
            for dir in directoryItems:
                directoryItemsNoTitle.append((dir[1],dir[2],dir[3]))
            printL('directoryItems1 %r' % directoryItemsNoTitle)
            xbmcplugin.addDirectoryItems(HANDLE, directoryItemsNoTitle)
            xbmcplugin.endOfDirectory(HANDLE)
            
    def listSeriesFlat(self, items, addToFavorites=True):
        ###printL('listSeriesFlat:items= %r' % items)
        if not items:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            if not addToFavorites:
                xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'), ADDON.getLocalizedString(30013),
                                    ADDON.getLocalizedString(30018), ADDON.getLocalizedString(30019))
            else:
                xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'), ADDON.getLocalizedString(30013))
        else:
            directoryItems = list()
            ###items = sorted(items) ### 2018-01-02
            for item in items:
                printL('listSeriesFlat:\nitem.Title= %r\nitem.SeriesTitle= %r\nitem.SeriesSlug= %r' % (item['Title'],item['SeriesTitle'],item['SeriesSlug']))
                ### url = PATH + '?listVideos=' + item['SeriesSlug']
                episodes = self.api.getSeries(item['SeriesSlug'])
                printL('listSeriesFlat:episodes= %r' % episodes)
                for episode in episodes:
                    printL('listSeriesFlat:episode= %r' % episode)
                    directoryItems.append(episode)
                printL(repr(directoryItems))
            """
            printL('directoryItems0 %r' % directoryItems)
            directoryItems = sorted(directoryItems) ### 2018-01-02
            directoryItemsNoTitle = []
            for dir in directoryItems:
                directoryItemsNoTitle.append((dir[1],dir[2],dir[3]))
            printL('directoryItems1 %r' % directoryItemsNoTitle)
            xbmcplugin.addDirectoryItems(HANDLE, directoryItemsNoTitle)
            xbmcplugin.endOfDirectory(HANDLE)
            """
    def listEpisodes(self, items, addSortMethods=True):
        directoryItems = list()
        items = sorted(items) ### 2018-01-02
        for item in items:
            printL('item= %r' % item)  ### 2018-12-19
            if 'PrimaryAsset' not in item or 'Uri' not in item['PrimaryAsset'] or not item['PrimaryAsset']['Uri']:
                continue
            
            IsRerun = 0
            IsExpiresSoon = 0
            infoLabels = {
                'title': item['Title']
            }
            duration = ''
            Title = item['Title']
            try:
                year = str(item['ProductionYear'])
                if year < '1920':
                    year = ''
                ###year = item['Year'] 
            except Exception, e:
                pass
                #year = 'Error geting Year: ' + repr(e)
                year = ''
            printL('year= %r, item= %r' % (year, item))
            
            try:
                if item['PrimaryAsset']['RestrictedToDenmark']:
                    RestrictedToDenmark = True
                else: 
                    RestrictedToDenmark = False
            except Exception,e:
                pass
                printL('RestrictedToDenmark ERROR: %r' % e)
                RestrictedToDenmark = False
            if RestrictedToDenmark == True:
                RestrictedToDenmarkMarker = ' [COLOR red]Only DK[/COLOR]'
            else:
                RestrictedToDenmarkMarker = ''
            try:
                ### IsRerun = Genudsendelse  "SeasonSlug"
                duration = int(item['PrimaryAsset']['DurationInMilliseconds'])
                duration = duration/1000/60
                if duration:
                    ###duration = ' [' + str(duration) + ' min]'
                    duration = str(int(item['PrimaryAsset']['DurationInMilliseconds'])/1000/60)
                    durationH = int(int(duration)/60)
                    durationM = (int(duration) - durationH*60)
                    duration =  ' [' + str(durationH) + 'h' + str(durationM).zfill(2) + 'm]'
                else:
                    duration = ''
                duration = duration.encode('utf-8')
                duration = RestrictedToDenmarkMarker + duration
                SeasonTitle = item['SeasonTitle']
                if not SeasonTitle.lower() in Title.lower():
                    duration = duration + ' ' + SeasonTitle.encode("utf-8")  ### 2018-02-01
                if not year in Title and not year in duration:
                    duration = ' ' + year + duration  ### 2018-02-09
                try:
                    IsRerun = item['PrimaryBroadcast']['IsRerun']
                except:
                    pass
                    IsRerun = 0
                if IsRerun:
                    duration = duration + ' \n[COLOR red]Genudsendelse[/COLOR]'
                try:
                    IsExpiresSoon = item['ExpiresSoon']
                except:
                    pass
                    IsExpiresSoon = 0
                if IsExpiresSoon:
                    duration = duration + ' \n[COLOR lightgreen]Udløber snart[/COLOR]'
            except Exception,e:
                pass
                printL('Title duration fails: %r, \n%r' % (item,e))
                ###duration = duration + ' [ '+repr(e)+']'
                duration = str(duration)   ### 2018-02-09
            duration = duration.decode('utf-8').encode('utf-8')   ### 2018-02-09
            if IsRerun or IsExpiresSoon:
                infoLabels = {
                    'title': ('[COLOR red]*[/COLOR] ' + item['Title'].encode('utf-8') + duration)  
                } 
            else:
                if IsExpiresSoon:
                    infoLabels = {
                        'title': ('[COLOR red]¤[/COLOR][COLOR lightgreen]' + item['Title'].encode('utf-8') + '[/COLOR]' + duration)  
                    }   
                else:
                        infoLabels = {
                        'title': ('[COLOR lightgreen]' + item['Title'].encode('utf-8') + '[/COLOR]' + duration)  
                    }   

                
            if 'Description' in item:
                infoLabels['plot'] = item['Description']
            iconImage = item['PrimaryImageUri']
            if 'PrimaryBroadcastStartTime' in item and item['PrimaryBroadcastStartTime'] is not None:
                broadcastTime = self.parseDate(item['PrimaryBroadcastStartTime'])
                if broadcastTime:
                    infoLabels['date'] = broadcastTime.strftime('%d.%m.%Y')
                    infoLabels['aired'] = broadcastTime.strftime('%Y-%m-%d')
                    infoLabels['year'] = int(broadcastTime.strftime('%Y'))
                    ###infoLabels['year'] = int(year)
            printL('XXYYZZ ' +  item['Slug'] + '==>' +item['Title'])        
            ###listItem = xbmcgui.ListItem(item['Slug'] + '==>' +item['Title'], iconImage=iconImage)  ### 2018-02-02
            listItem = xbmcgui.ListItem(item['Title'], iconImage=iconImage)  ### 2018-02-09
            listItem.setInfo('video', infoLabels)
            listItem.setProperty('Fanart_Image', iconImage)
            url = PATH + '?playVideo=' + item['Slug']
            listItem.setProperty('IsPlayable', 'true')
            listItem.addContextMenuItems(self.menuItems, False)
            directoryItems.append((item['Title'].lower(),url, listItem))

        printL('directoryItems2 %r' % directoryItems)
        directoryItems = sorted(directoryItems) ### 2018-01-02
        directoryItemsNoTitle = []
        for dir in directoryItems:
            directoryItemsNoTitle.append((dir[1],dir[2]))  ### 2018-02-02
        printL('directoryItems1 %r' % directoryItemsNoTitle)
        xbmcplugin.addDirectoryItems(HANDLE, directoryItemsNoTitle)
        if addSortMethods:
            xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_DATE)
            xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_TITLE)
        xbmcplugin.endOfDirectory(HANDLE)
    """ 
    def playVideo(self, slug):
        self.updateRecentlyWatched(slug)
        item = self.api.getEpisode(slug)

        if not 'PrimaryAsset' in item:
            self.displayError(ADDON.getLocalizedString(30904))
            return

        video = self.api.getVideoUrl(item['PrimaryAsset']['Uri'])
        item = xbmcgui.ListItem(path=video['Uri'], thumbnailImage=item['PrimaryImageUri'])

        if ADDON.getSetting('enable.subtitles') == 'true':
            if video['SubtitlesUri']:
                item.setSubtitles([video['SubtitlesUri']])
                
        xbmcplugin.setResolvedUrl(HANDLE, video['Uri'] is not None, item)

    """   
    def playVideo(self, slug):
        self.updateRecentlyWatched(slug)
        item = self.api.getEpisode(slug)
        printL( 'drnu addon.py: self= %r, slug= %r' % (self,slug))
        if not 'PrimaryAsset' in item:
            self.displayError(ADDON.getLocalizedString(30904))
            return

        video = self.api.getVideoUrl(item['PrimaryAsset']['Uri'])
        try:
            Title = item['Title'].replace(':','-').replace('\\','-').replace('/','-').replace(',',';')
            Title = latin1_to_ascii_force(Title)  ###.encode("utf-8")   ### No UTF-8 in filename
            printL('Title= %r' % Title)
        except Exception, e:
            pass
            Title = 'X'
        try:
            year = item['ProductionYear']
            if year > 1900:
                year = str(year)
            else:
                year = ''
            ###year = item['Year'] 
        except Exception, e:
            pass
            #year = 'Error geting Year: ' + repr(e)
            year = ''
        try:
            description = item['Description'].replace('/n','NewLine').encode("utf-8")  ### 2017-01-28
        except Exception, e:
            pass
            description = 'Error geting description/Plot: ' + repr(e)
        try:
            duration = str(int(item['PrimaryAsset']['DurationInMilliseconds'])/1000/60)
            durationH = int(int(duration)/60)
            durationM = (int(duration) - durationH*60)
            orgduration =  str(durationH) + 'h' + str(durationM).zfill(2) + 'm'
        except Exception, e:
            pass
            orgduration = ''
            duration = 'Error geting duration: ' + repr(e)    
        item = xbmcgui.ListItem(path=video['Uri'], thumbnailImage=item['PrimaryImageUri'])
        
        printL( 'video= %s' % repr(video).replace(',','###'))
        printL( 'URI= %s' % repr(video['Uri']))
        printL( repr(PATH))
        ADDON      = xbmcaddon.Addon()
        datapath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
        playlist = os.path.join(datapath, 'DRarkiv') + '.m3u'
        if os.path.isfile(playlist ) == False: 
            LF = open(playlist , 'a')
            LF.write('#EXTM3U \n')
            LF.write(str(video['Uri']) + '\n')
        else:
            LF = open(playlist , 'a')
            LF.write(str(video['Uri']) + '\n')
        try:
            printL('duration= %r' % duration)
            durationVideo = '&duration='+duration
        except Exception,e:
            pass
            printL('Error in duration= %r\n%r' %(0,e))
            duration = ''
            durationVideo = ''
        try:
            if year == '' or year == '0':
                descriptionE = '&description='+description
            else:
                descriptionE = '&description='+year+': '+description
        except:
            pass
            descriptionE = ''
        if video['SubtitlesUri']:  ### Previous used '+ str(slug).title()'
            descriptionE += '&subtitlesurl=' + video['SubtitlesUri'].encode("utf-8") + '&subtitlesoffset=0'
        if not year in Title:
            Title += ' ' + year
        RecordingFromOtherAddon = ADDON.getSetting('RecordingFromOtherAddon')
        RecordingFromOtherAddon = RecordFlagGet('')   ###ADDON.getSetting('RecordingFromOtherAddon')
        printL(repr(RecordingFromOtherAddon))
        printL(repr(ADDON))
        ###ADDON      = xbmcaddon.Addon()
        ###ADDON.setSetting('RecordingFromOtherAddon','yyy')
        RecordFlagSet('','yyy') 
        printL('Reset RecordingFromOtherAddon to yyy')
        
        RecordingFromOtherAddon = RecordFlagGet('')   ###ADDON.getSetting('RecordingFromOtherAddon')
        printL(repr(RecordingFromOtherAddon))
        printL(repr(ADDON))
        URI='plugin://plugin.video.roqtv.rec/?url=url&mode=2011&source='+ADDONid+'&name=' + Title.encode("utf-8") + ' ['+orgduration+']' + ' [DR NU]&uri='+ (str(video['Uri'])+ descriptionE+ durationVideo).replace(' ','AAabBB').replace('?','aAabBb').replace('=','BBabAA').replace(',','###').replace('&','AaAaA')
        
        printL('drnu-->recorduri.py: URI= %s' % repr(URI))
        ###URI= URI.split('?')[0] + '?' + URI.split('?')[1]
        ###printL('drnu-->recorduri.py: URI= %s' % repr(URI))
        #xbmc.executebuiltin('XBMC.RunPlugin(%s)' % URI)
        ###URI += descriptionE + durationVideo  ### 2017-01-28
        tries    = 0
        maxTries = 40
        maxSleep = 500
        try:
            printL(repr(URI))
            xbmc.executebuiltin('XBMC.RunPlugin(%s)' % URI) 
            xbmc.sleep(maxSleep)
            
            RecordingFromOtherAddon = RecordFlagGet('')   ###ADDON.getSetting('RecordingFromOtherAddon')
            printL(repr(RecordingFromOtherAddon))
            printL(repr(ADDON))
        except:
            pass 
        URI=URI.replace('plugin.video.roqtv.rec','plugin.video.roqtvrec')
        printL(repr(URI))
        try:
            xbmc.executebuiltin('XBMC.RunPlugin(%s)' % URI) 
            xbmc.sleep(maxSleep)
            
            RecordingFromOtherAddon = RecordFlagGet('')   ###ADDON.getSetting('RecordingFromOtherAddon')
            printL(repr(RecordingFromOtherAddon))
            printL(repr(ADDON))
        except:
            pass 
        URI=URI.replace('plugin.video.roqtvrec','plugin.video.glowiptv.rec')
        printL(repr(URI))
        try:
            xbmc.executebuiltin('XBMC.RunPlugin(%s)' % URI) 
            xbmc.sleep(maxSleep)
            
            RecordingFromOtherAddon = RecordFlagGet('')   ###ADDON.getSetting('RecordingFromOtherAddon')
            printL(repr(RecordingFromOtherAddon))
            printL(repr(ADDON))
        except:
            pass 
        URI=URI.replace('plugin.video.glowiptv.rec','plugin.video.nordicchannels.rec')
        printL(repr(URI))
        try:
            xbmc.executebuiltin('XBMC.RunPlugin(%s)' % URI) 
            xbmc.sleep(maxSleep)
            
            RecordingFromOtherAddon = RecordFlagGet('')   ###ADDON.getSetting('RecordingFromOtherAddon')
            printL(repr(RecordingFromOtherAddon))
            printL(repr(ADDON))
        except:
            pass 
        URI=URI.replace('plugin.video.nordicchannels.rec','plugin.video.myindiantv')
        printL(repr(URI))
        try:
            xbmc.executebuiltin('XBMC.RunPlugin(%s)' % URI) 
            xbmc.sleep(maxSleep)
            
            RecordingFromOtherAddon = RecordFlagGet('')   ###ADDON.getSetting('RecordingFromOtherAddon')
            printL(repr(RecordingFromOtherAddon))
            printL(repr(ADDON))
        except:
            pass
            printL('No valid Addon to record stream!')
            ###RecordingFromOtherAddon = ADDON.getSetting('RecordingFromOtherAddon')
            RecordingFromOtherAddon = 'False'   ### No recording
            printL(repr(RecordingFromOtherAddon))
            printL(repr(ADDON))

        printL('Play Video')
        if ADDON.getSetting('enable.subtitles') == 'true':
            if video['SubtitlesUri']:
                item.setSubtitles([video['SubtitlesUri']])
        
        ###RecordingFromOtherAddon = ADDON.onSettingsChanged()
        ###printL('RecordingFromOtherAddon = ADDON.onSettingsChanged(): %r' % RecordingFromOtherAddon)
        RecordingFromOtherAddon = RecordFlagGet('')   ###ADDON.getSetting('RecordingFromOtherAddon')
        printL(RecordingFromOtherAddon)
        printL(repr(ADDON))
        printL(repr(tries))
  
        while RecordingFromOtherAddon != 'False' and RecordingFromOtherAddon != 'True' and tries < maxTries:
                try:
                    xbmc.sleep(maxSleep)
                    ###RecordingFromOtherAddon = ADDON.onSettingsChanged()
                    ###printL('RecordingFromOtherAddon = ADDON.onSettingsChanged(): %r' % RecordingFromOtherAddon)
                    RecordingFromOtherAddon = RecordFlagGet('')   ###ADDON.getSetting('RecordingFromOtherAddon')
                    printL(repr(RecordingFromOtherAddon))
                    printL(repr(ADDON))
                    printL(repr(tries))
                    if RecordingFromOtherAddon == 'False' or RecordingFromOtherAddon == 'True':
                    	printL(repr('Break'))
                    	break
                    else:
                    	tries = tries + 1
                except Exception,e:
                    pass
                    printL(repr('Exception'))
                    printL(repr('e'))
                    RecordingFromOtherAddon = 'False' 
        printL(repr(RecordingFromOtherAddon))
        printL(repr(ADDON))
        printL(repr(tries))
        if RecordingFromOtherAddon == 'False':
        	printL(repr('Play URI: ')+ repr(video['Uri']))
        	xbmcplugin.setResolvedUrl(HANDLE, video['Uri'] is not None, item)
                
    def parseDate(self, dateString):
        if dateString is not None:
            try:
                m = re.search('(\d+)-(\d+)-(\d+)T(\d+):(\d+):(\d+)', dateString)
                year = int(m.group(1))
                month = int(m.group(2))
                day = int(m.group(3))
                hours = int(m.group(4))
                minutes = int(m.group(5))
                seconds = int(m.group(6))
                return datetime.datetime(year, month, day, hours, minutes, seconds)
            except ValueError:
                return None
        else:
            return None
    
    def addFavorite(self, key):
        self._load()
        if not self.favorites.count(key):
            self.favorites.append(key)
        self._save()

        xbmcgui.Dialog().ok(ADDON.getLocalizedString(30008), ADDON.getLocalizedString(30009))

    def delFavorite(self, key):
        self._load()
        if self.favorites.count(key):
            self.favorites.remove(key)
        self._save()
        xbmcgui.Dialog().ok(ADDON.getLocalizedString(30008), ADDON.getLocalizedString(30010))

    def updateRecentlyWatched(self, assetUri):
        self._load()
        if self.recentlyWatched.count(assetUri):
            self.recentlyWatched.remove(assetUri)
        self.recentlyWatched.insert(0, assetUri)
        self._save()

    def displayError(self, message='n/a'):
        heading = buggalo.getRandomHeading()
        line1 = ADDON.getLocalizedString(30900)
        line2 = ADDON.getLocalizedString(30901)
        xbmcgui.Dialog().ok(heading, line1, line2, message)

    def displayIOError(self, message='n/a'):
        heading = buggalo.getRandomHeading()
        line1 = ADDON.getLocalizedString(30902)
        line2 = ADDON.getLocalizedString(30903)
        xbmcgui.Dialog().ok(heading, line1, line2, message)

def latin1_to_ascii_force (unicrap):
    """This takes a UNICODE string and replaces Latin-1 characters with
        something equivalent in 7-bit ASCII. It returns a plain ASCII string. 
        This function makes a best effort to convert Latin-1 characters into 
        ASCII equivalents. It does not just strip out the Latin-1 characters.
        All characters in the standard 7-bit ASCII range are preserved. 
        In the 8th bit range all the Latin-1 accented letters are converted 
        to unaccented equivalents. Most symbol characters are converted to 
        something meaningful. Anything not converted is deleted.
    """ 
    #return unicrap
    ###utils.logdev('TEST-unicrap',repr(unicrap))
    xlate={0x82:'Euro', 0x85:'Aa', 0x86:'Ae', 0x98:'Oe', 0xc0:'A', 0xc1:'A', 0xc2:'', 0xc3:'', 0xc4:'A', 0xc5:'A',
        0xc6:'Ae', 0xc7:'C',
        0xc8:'E', 0xc9:'E', 0xca:'E', 0xcb:'E',
        0xcc:'I', 0xcd:'I', 0xce:'I', 0xcf:'I',
        0xd0:'Th', 0xd1:'N',
        0xd2:'O', 0xd3:'O', 0xd4:'O', 0xd5:'O', 0xd6:'O', 0xd7:'x', 0xd8:'O',
        0xd9:'U', 0xda:'U', 0xdb:'U', 0xdc:'U',
        0xdd:'Y', 0xde:'th', 0xdf:'ss',
        0xe0:'a', 0xe1:'a', 0xe3:'a', 0xe4:'a', 0xe5:'a',
        0xe6:'ae', 0xe7:'.0xe7.',
        0xe8:'e', 0xe9:'e', 0xea:'e', 0xeb:'e',
        0xec:'i', 0xed:'i', 0xee:'i', 0xef:'i',
        0xf0:'th', 0xf1:'n',
        0xf2:'o', 0xf3:'o', 0xf4:'o', 0xf5:'o', 0xf6:'o', 0xf8:'o',
        0xf9:'u', 0xfa:'u', 0xfb:'u', 0xfc:'u',
        0xfd:'y', 0xfe:'th', 0xff:'y',0xa0:'a',
        0xa1:'a', 0xa2:'.0xa2.', 0xa3:'', 0xa4:'a',
        0xa5:'aa', 0xa6:'ae', 0xa7:'s', 0xa8:'u',
        0xa9:'e', 0xaa:'e', 0xab:'<<', 0xac:'',
        0xad:'-', 0xae:'R', 0xaf:'_', 0xb0:'d',
        0xb1:'+/-', 0xb2:'^2', 0xb3:'^3', 0xb4:"'",
        0xb5:'m', 0xb6:'o', 0xb7:'*', 0xb8:'oe',
        0xb9:'^1', 0xba:'^o', 0xbb:'>>', 
        0xbc:'u', 0xbd:'1/2', 0xbe:'3/4', 0xbf:'?',
        0xd7:'*', 0xf7:'/'
        }
    r = ''
    for i in unicrap:
        if xlate.has_key(ord(i)):
            r += xlate[ord(i)]
        elif ord(i) >= 0x80:
            pass
        else:
            r += str(i)
    ###utils.logdev('TEST-unicrap',repr(r))
    return r


if __name__ == '__main__':
    ADDON      = xbmcaddon.Addon()
    ADDONname  = ADDON.getAddonInfo('name')
    ADDONid    = ADDON.getAddonInfo('id')
    PATH = sys.argv[0]
    HANDLE = int(sys.argv[1])
    PARAMS = urlparse.parse_qs(sys.argv[2][1:])

    CACHE_PATH = xbmc.translatePath(ADDON.getAddonInfo("Profile"))
    if not os.path.exists(CACHE_PATH):
        os.makedirs(CACHE_PATH)

    FAVORITES_PATH = os.path.join(CACHE_PATH, 'favorites.pickle')
    RECENT_PATH = os.path.join(CACHE_PATH, 'recent.pickle')
    FANART_IMAGE = os.path.join(ADDON.getAddonInfo('path'), 'fanart.jpg')

    buggalo.SUBMIT_URL = 'http://tommy.winther.nu/exception/submit.php'
    buggalo.addExtraData('cache_path', CACHE_PATH)
    drDkTvAddon = DrDkTvAddon()
    ###try:
    if 'show' in PARAMS:
        if PARAMS['show'][0] == 'liveTV':
            drDkTvAddon.showLiveTV()
        elif PARAMS['show'][0] == 'listAZ':
            drDkTvAddon.showAZ()
        elif PARAMS['show'][0] == 'latest':
            drDkTvAddon.listEpisodes(drDkTvAddon.api.getLatestPrograms(), addSortMethods=False)
        elif PARAMS['show'][0] == 'mostViewed':
            drDkTvAddon.listEpisodes(drDkTvAddon.api.getMostViewed())
        elif PARAMS['show'][0] == 'highlights':
            drDkTvAddon.listEpisodes(drDkTvAddon.api.getSelectedList())
        elif PARAMS['show'][0] == 'search':
            drDkTvAddon.searchSeries()
        elif PARAMS['show'][0] == 'favorites':
            drDkTvAddon.showFavorites()
        elif PARAMS['show'][0] == 'recentlyWatched':
            drDkTvAddon.showRecentlyWatched()
        elif PARAMS['show'][0] == 'areaselector':
            drDkTvAddon.showAreaSelector()
        elif PARAMS['show'][0] == 'themes':
            drDkTvAddon.showThemes()

    elif 'listProgramSeriesByLetter' in PARAMS:
        drDkTvAddon.listSeries(drDkTvAddon.api.getSeries(PARAMS['listProgramSeriesByLetter'][0]))

    elif 'listVideos' in PARAMS:
        drDkTvAddon.listEpisodes(drDkTvAddon.api.getEpisodes(PARAMS['listVideos'][0]))

    elif 'playVideo' in PARAMS:
        drDkTvAddon.playVideo(PARAMS['playVideo'][0])

    elif 'addfavorite' in PARAMS:
        drDkTvAddon.addFavorite(PARAMS['addfavorite'][0])

    elif 'delfavorite' in PARAMS:
        drDkTvAddon.delFavorite(PARAMS['delfavorite'][0])

    else:
        try:
            area = int(ADDON.getSetting('area'))
        except:
            area = 0

        if area == 0:
            drDkTvAddon.showAreaSelector()
        elif area == 1:
            drDkTvAddon.showMainMenu()
        elif area == 2:
            items = drDkTvAddon.api.getChildrenFrontItems('dr-ramasjang')
            drDkTvAddon.listSeries(items)
        elif area == 3:
            items = drDkTvAddon.api.getChildrenFrontItems('dr-ultra')
            drDkTvAddon.listSeries(items)
"""
    except tvapi.ApiException, ex:
        drDkTvAddon.displayError(str(ex))

    except IOError, ex:
        drDkTvAddon.displayIOError(str(ex))

    except Exception:
        buggalo.onExceptionRaised()
"""
